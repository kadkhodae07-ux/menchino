# PULSE ARENA — Build 13 Analyzer Hotfix

Version: `1.7.1+13`  
Workflow: `WF8`

This release fixes the GitHub Actions failure reported in `PULSE-ARENA-failure-logs-62.zip`. The failure occurred during static analysis, before tests or APK compilation.

## Fixes

- Removed the unused optional `key` parameter from `_PageScaffold`.
- Applied safe analyzer lint corrections in the affected source files.
- Changed the workflow so analyzer warnings and informational lints remain visible in logs but do not abort the build. Analyzer errors still fail the workflow.
- Preserved all Build 12 functionality: full graphical UI pages, centered Home navigation, ranking, 10-goal match rule, low-latency direct paddle tracking, sustained-performance guards, and victory effects.

## Workflow output

WF8 selects the newest valid Flutter source ZIP, validates project invariants, runs dependency resolution, static analysis, all tests, and produces separate Bazaar and Myket release APKs. On failure it uploads a complete diagnostics package.
