#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

EXPECTED_VERSION = '1.5.0+8'
EXPECTED_PACKAGE = 'mk.kadkhodai.zarbu'
EXPECTED_AVATARS = 10
EXPECTED_WORKFLOW = 'ZARBU_BUILD_LATEST_ZIP_AUTO_FIXED_V10_JVM17_STORE_ISOLATION.yml'

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
errors: list[str] = []

for generated in ('.dart_tool', 'build', 'outputs', '__pycache__'):
    for path in root.rglob(generated):
        if path.is_dir():
            errors.append(f'generated directory must not ship: {path.relative_to(root)}')
for path in root.rglob('*.pyc'):
    errors.append(f'generated Python bytecode must not ship: {path.relative_to(root)}')


def require_file(relative: str, *, nonempty: bool = True) -> Path:
    path = root / relative
    if not path.is_file():
        errors.append(f'missing file: {relative}')
    elif nonempty and path.stat().st_size <= 0:
        errors.append(f'empty file: {relative}')
    return path


def read(relative: str) -> str:
    path = require_file(relative)
    if not path.is_file():
        return ''
    return path.read_text(encoding='utf-8')


pubspec = read('pubspec.yaml')
match = re.search(r'(?m)^version:\s*([^\s]+)\s*$', pubspec)
if not match or match.group(1) != EXPECTED_VERSION:
    errors.append(f'pubspec version must be {EXPECTED_VERSION}')
# The shipped source defaults to offline. Store SDKs are injected one-at-a-time
# by prepare_store_variant.py during CI; linking both causes duplicate billing classes.
if re.search(r'(?m)^\s{2}(flutter_poolakey|myket_iap):', pubspec):
    errors.append('default source pubspec must not link a native store SDK')
if 'assets/images/avatars/' not in pubspec or 'assets/images/zarbu_league_cup.webp' not in pubspec:
    errors.append('required game assets are not declared in pubspec.yaml')

required_files = (
    'lib/main.dart',
    'lib/core/balance.dart',
    'lib/core/data.dart',
    'lib/core/league.dart',
    'lib/core/state/app_state.dart',
    'lib/core/store/store_config.dart',
    'lib/core/store/store_product.dart',
    'lib/core/store/store_billing_service.dart',
    'lib/core/store/store_billing_backend.dart',
    'lib/game/engine.dart',
    'lib/ui/screens/game_screen.dart',
    'lib/ui/screens/shop_screen.dart',
    'test/balance_test.dart',
    'test/data_test.dart',
    'test/engine_rules_test.dart',
    'test/league_test.dart',
    'test/state_rules_test.dart',
    'test/storage_service_test.dart',
    'test/settlement_state_test.dart',
    'test/store_config_test.dart',
    'test/store_ledger_test.dart',
    'FINAL_RELEASE_CANDIDATE_v1.5.0_build8.md',
    'QA_MATRIX_v1.5.0_build8.md',
    'STORE_BILLING_REQUIREMENTS.md',
    'PREDELIVERY_VERIFICATION_v1.5.0_build8.md',
    'SOURCE_MANIFEST.md',
    'tool/prepare_android.py',
    'tool/prepare_store_variant.py',
    'tool/store_variants/offline_backend.dart.txt',
    'tool/store_variants/bazaar_backend.dart.txt',
    'tool/store_variants/myket_backend.dart.txt',
    'release/bazikhone_release_key.jks',
    'release/key.properties',
    'assets/images/zarbu_league_cup.webp',
    f'.github/workflows/{EXPECTED_WORKFLOW}',
)
for required in required_files:
    require_file(required)

prepare_android = read('tool/prepare_android.py')
for marker in (EXPECTED_PACKAGE, "jvm_target = '17'", 'jvmToolchain({jvm_target})', 'https://jitpack.io', 'marketApplicationId'):
    if marker not in prepare_android:
        errors.append(f'prepare_android.py missing billing/release prerequisite: {marker}')

workflow = read(f'.github/workflows/{EXPECTED_WORKFLOW}')
for marker in ('JAVA_VERSION: "17"', 'ZARBU_BAZAAR_RSA_KEY', 'ZARBU_MYKET_RSA_KEY', '--dart-define=ZARBU_STORE=offline', '--obfuscate', 'prepare_store_variant.py'):
    if marker not in workflow:
        errors.append(f'Workflow V10 missing final-build guard: {marker}')


variant_script = read('tool/prepare_store_variant.py')
for marker in ('flutter_poolakey: ^2.2.0+1.0.0', 'myket_iap: ^1.1.11', "'offline': None", 'Never allow both native billing SDKs'):
    if marker not in variant_script:
        errors.append(f'store isolation script missing: {marker}')
for relative, package_marker in (
    ('tool/store_variants/bazaar_backend.dart.txt', 'package:flutter_poolakey/flutter_poolakey.dart'),
    ('tool/store_variants/myket_backend.dart.txt', 'package:myket_iap/myket_iap.dart'),
):
    if package_marker not in read(relative):
        errors.append(f'store backend template invalid: {relative}')
if 'flutter_poolakey' in read('tool/store_variants/myket_backend.dart.txt') or 'myket_iap' in read('tool/store_variants/bazaar_backend.dart.txt'):
    errors.append('store backend templates are cross-linked')

avatar_dir = root / 'assets/images/avatars'
avatars = sorted(avatar_dir.glob('*.webp')) if avatar_dir.is_dir() else []
if len(avatars) != EXPECTED_AVATARS:
    errors.append(f'expected exactly {EXPECTED_AVATARS} avatar WebPs, found {len(avatars)}')
for avatar in avatars:
    raw = avatar.read_bytes()
    if len(raw) < 20 or raw[:4] != b'RIFF' or raw[8:12] != b'WEBP':
        errors.append(f'invalid WebP avatar: {avatar.name}')
        continue
    if b'ALPH' not in raw:
        errors.append(f'avatar WebP does not contain an alpha chunk: {avatar.name}')

cup_asset = root / 'assets/images/zarbu_league_cup.webp'
if cup_asset.is_file():
    cup_raw = cup_asset.read_bytes()
    if len(cup_raw) < 20 or cup_raw[:4] != b'RIFF' or cup_raw[8:12] != b'WEBP' or b'ALPH' not in cup_raw:
        errors.append('league cup must be a transparent WebP asset')

if (root / 'lib/ui/screens/chat_screen.dart').exists():
    errors.append('offline/final source must not contain legacy chat_screen.dart')

lib_files = sorted((root / 'lib').rglob('*.dart'))
forbidden = {
    'TODO': re.compile(r'\bTODO\b'),
    'FIXME': re.compile(r'\bFIXME\b'),
    'placeholder': re.compile(r'placeholder', re.IGNORECASE),
    'coming-soon copy': re.compile(r'به\s*زودی'),
}
for path in lib_files:
    text = path.read_text(encoding='utf-8')
    for label, pattern in forbidden.items():
        if pattern.search(text):
            errors.append(f'{label} marker remains in {path.relative_to(root)}')

all_lib = '\n'.join(path.read_text(encoding='utf-8') for path in lib_files)
for unsafe_pattern, label in (
    (r'\bbool\s+debug\b', 'runtime debug state'),
    (r'engine\.state\.debug', 'debug painter'),
    (r'ChatScreen', 'chat UI reference'),
    (r'publicChat|privateChat|sendPublic|sendPrivate', 'legacy chat persistence'),
):
    if re.search(unsafe_pattern, all_lib):
        errors.append(f'{label} remains in runtime source')

store_config = read('lib/core/store/store_config.dart')
if "String.fromEnvironment('ZARBU_STORE_RSA')" not in store_config:
    errors.append('store RSA must come from build configuration, not source literals')
if re.search(r'MIHNMA[0-9A-Za-z+/=]{40,}', all_lib):
    errors.append('a Bazaar/Myket RSA key appears hardcoded in runtime source')
for sku in (
    'zarbu_coin_1000', 'zarbu_coin_5000', 'zarbu_coin_12000',
    'zarbu_gem_50', 'zarbu_gem_150', 'zarbu_bundle_6000_100',
):
    if sku not in store_config:
        errors.append(f'canonical store SKU missing: {sku}')

shop = read('lib/ui/screens/shop_screen.dart')
if "label: 'سکه و جم'" not in shop or 'StoreConfig.isConfigured' not in shop:
    errors.append('real currency store must exist only behind verified store configuration')
if 'قیمت از ${StoreConfig.storeLabel}' not in shop:
    errors.append('store UI must not hardcode fake monetary prices')

state = read('lib/core/state/app_state.dart')
for marker in ('processedStorePurchaseTokens', 'pendingStoreConsumes', 'applyStorePurchase', 'recoverPendingStoreConsumes'):
    if marker not in state:
        errors.append(f'exactly-once store ledger guard missing: {marker}')
if 'addCoins(canonical.coins)' not in state or 'addGems(canonical.gems)' not in state:
    errors.append('store grant must use canonical StoreConfig values, not UI-supplied pack values')
if "expectedPayloadPrefix = 'zarbu:${canonical.id}:'" not in state:
    errors.append('store receipt payload validation is missing')

if '_pool = []' not in read('lib/core/services/audio_service.dart'):
    errors.append('AudioPlayer pool must stay lazy to keep logic tests platform-independent')

settings = read('lib/ui/screens/settings_screen.dart')
if f'نسخه {EXPECTED_VERSION}' not in settings:
    errors.append('settings version label does not match pubspec version')

game = read('lib/ui/screens/game_screen.dart')
if 'settleMatch' not in game or 'settledMatchTokens' not in state:
    errors.append('central match settlement / duplicate protection is missing')
if "engine.mode == 'practice' || engine.mode == 'local'" not in game:
    errors.append('practice/local restart guard is missing')

if errors:
    print('ZARBU FINAL RELEASE GATE: FAILED')
    for item in errors:
        print(f' - {item}')
    raise SystemExit(1)

print('ZARBU FINAL RELEASE GATE: PASSED')
print(f' - version: {EXPECTED_VERSION}')
print(f' - package: {EXPECTED_PACKAGE}')
print(f' - avatar WebPs: {len(avatars)} (alpha-preserved)')
print(' - release keystore: present')
print(' - central match/economy/store ledgers: present')
print(' - Bazaar/Myket keys: build-time only; no fake payment values in source')
print(' - Workflow V10: JVM17 + isolated offline/Bazaar/Myket dependency graphs')
