import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'shop_items.dart';

class MatchHistoryEntry {
  const MatchHistoryEntry({
    required this.won,
    required this.mode,
    required this.playerScore,
    required this.opponentScore,
    required this.playedAt,
  });

  final bool won;
  final String mode;
  final int playerScore;
  final int opponentScore;
  final DateTime playedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'won': won,
        'mode': mode,
        'playerScore': playerScore,
        'opponentScore': opponentScore,
        'playedAt': playedAt.toIso8601String(),
      };

  factory MatchHistoryEntry.fromJson(Map<String, dynamic> json) {
    return MatchHistoryEntry(
      won: json['won'] == true,
      mode: json['mode'] as String? ?? 'bot',
      playerScore: (json['playerScore'] as num?)?.toInt() ?? 0,
      opponentScore: (json['opponentScore'] as num?)?.toInt() ?? 0,
      playedAt: DateTime.tryParse(json['playedAt'] as String? ?? '') ?? DateTime.now(),
    );
  }
}


class StoredChatMessage {
  const StoredChatMessage({required this.name, required this.emoji, required this.text, this.isMe = false});

  final String name;
  final String emoji;
  final String text;
  final bool isMe;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'name': name,
        'emoji': emoji,
        'text': text,
        'isMe': isMe,
      };

  factory StoredChatMessage.fromJson(Map<String, dynamic> json) {
    return StoredChatMessage(
      name: json['name'] as String? ?? 'بازیکن',
      emoji: json['emoji'] as String? ?? '😎',
      text: json['text'] as String? ?? '',
      isMe: json['isMe'] == true,
    );
  }
}

class MatchReward {
  const MatchReward({required this.coins, required this.xp});

  final int coins;
  final int xp;
}

class SaveData extends ChangeNotifier {
  SaveData._(this._preferences);

  static const String _saveKey = 'neonPongSaveV3';
  static late final SaveData instance;

  final SharedPreferences _preferences;

  String name = 'بازیکن';
  int coins = 300;
  int xp = 0;
  int wins = 0;
  int losses = 0;
  int matches = 0;
  String lastClaim = '';
  int winsToday = 0;
  String challengeDay = '';
  int streak = 0;
  int bestStreak = 0;
  int totalPowerups = 0;
  bool muted = false;

  List<String> owned = <String>[
    'pad_classic',
    'ball_classic',
    'trail_neon',
    'theme_space',
    'av_cool',
    'boom_neon',
  ];

  Map<String, String> selected = <String, String>{
    'paddle': 'pad_classic',
    'ball': 'ball_classic',
    'trail': 'trail_neon',
    'theme': 'theme_space',
    'avatar': 'av_cool',
    'boom': 'boom_neon',
  };

  List<MatchHistoryEntry> history = <MatchHistoryEntry>[];
  List<StoredChatMessage> chatMessages = <StoredChatMessage>[
    const StoredChatMessage(name: 'نئون‌مستر', emoji: '👾', text: 'به چت پونگ نئونی خوش اومدی! 🎉'),
    const StoredChatMessage(name: 'سارا', emoji: '🌸', text: 'کسی هست یه دست دو نفره بازی کنه؟'),
    const StoredChatMessage(name: 'پیکسل', emoji: '🎮', text: 'راکت طلایی رو گرفتم، خیلی خفنه ✨'),
  ];

  static Future<SaveData> initialize() async {
    final SharedPreferences preferences = await SharedPreferences.getInstance();
    final SaveData data = SaveData._(preferences);
    data._load();
    instance = data;
    return data;
  }

  void _load() {
    final String? raw = _preferences.getString(_saveKey);
    if (raw == null || raw.isEmpty) {
      return;
    }

    try {
      final Map<String, dynamic> map = jsonDecode(raw) as Map<String, dynamic>;
      name = map['name'] as String? ?? name;
      coins = (map['coins'] as num?)?.toInt() ?? coins;
      xp = (map['xp'] as num?)?.toInt() ?? xp;
      wins = (map['wins'] as num?)?.toInt() ?? wins;
      losses = (map['losses'] as num?)?.toInt() ?? losses;
      matches = (map['matches'] as num?)?.toInt() ?? matches;
      lastClaim = map['lastClaim'] as String? ?? lastClaim;
      winsToday = (map['winsToday'] as num?)?.toInt() ?? winsToday;
      challengeDay = map['challengeDay'] as String? ?? challengeDay;
      streak = (map['streak'] as num?)?.toInt() ?? streak;
      bestStreak = (map['bestStreak'] as num?)?.toInt() ?? bestStreak;
      totalPowerups = (map['totalPowerups'] as num?)?.toInt() ?? totalPowerups;
      muted = map['muted'] == true;

      final Object? ownedValue = map['owned'];
      if (ownedValue is List) {
        owned = ownedValue.whereType<String>().toSet().toList();
      }
      for (final String mandatory in <String>[
        'pad_classic',
        'ball_classic',
        'trail_neon',
        'theme_space',
        'av_cool',
        'boom_neon',
      ]) {
        if (!owned.contains(mandatory)) owned.add(mandatory);
      }

      final Object? selectedValue = map['selected'];
      if (selectedValue is Map) {
        for (final MapEntry<dynamic, dynamic> entry in selectedValue.entries) {
          if (entry.key is String && entry.value is String) {
            selected[entry.key as String] = entry.value as String;
          }
        }
      }
      selected.putIfAbsent('boom', () => 'boom_neon');

      final Object? chatValue = map['chatMessages'];
      if (chatValue is List) {
        final List<StoredChatMessage> loadedChat = chatValue
            .whereType<Map>()
            .map((Map<dynamic, dynamic> item) => StoredChatMessage.fromJson(Map<String, dynamic>.from(item)))
            .where((StoredChatMessage item) => item.text.isNotEmpty)
            .toList();
        if (loadedChat.isNotEmpty) chatMessages = loadedChat;
      }

      final Object? historyValue = map['history'];
      if (historyValue is List) {
        history = historyValue
            .whereType<Map>()
            .map((Map<dynamic, dynamic> item) => MatchHistoryEntry.fromJson(Map<String, dynamic>.from(item)))
            .toList();
      }
    } catch (_) {
      // Corrupt saves are ignored; defaults remain usable.
    }

    _refreshDailyState(notify: false);
  }

  String _todayKey() {
    final DateTime now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  void _refreshDailyState({bool notify = true}) {
    final String today = _todayKey();
    if (challengeDay != today) {
      challengeDay = today;
      winsToday = 0;
      _persist();
      if (notify) notifyListeners();
    }
  }

  Future<void> _persist() async {
    await _preferences.setString(
      _saveKey,
      jsonEncode(<String, dynamic>{
        'name': name,
        'coins': coins,
        'xp': xp,
        'wins': wins,
        'losses': losses,
        'matches': matches,
        'lastClaim': lastClaim,
        'winsToday': winsToday,
        'challengeDay': challengeDay,
        'streak': streak,
        'bestStreak': bestStreak,
        'totalPowerups': totalPowerups,
        'muted': muted,
        'owned': owned,
        'selected': selected,
        'history': history.map((entry) => entry.toJson()).toList(),
        'chatMessages': chatMessages.map((entry) => entry.toJson()).toList(),
      }),
    );
  }

  int get level => (xp ~/ 150) + 1;
  int get levelProgress => xp % 150;
  int get points => (wins * 30 - losses * 10).clamp(0, 999999).toInt();
  double get winRate => matches == 0 ? 0 : wins / matches;

  String get avatarEmoji => itemById(selected['avatar'], fallbackCategory: ItemCategory.avatar).emoji ?? '😎';

  ShopItem selectedItem(ItemCategory category) {
    return itemById(selected[categoryKeys[category]], fallbackCategory: category);
  }

  bool canClaimDaily() => lastClaim != _todayKey();

  Future<bool> claimDaily() async {
    if (!canClaimDaily()) return false;
    lastClaim = _todayKey();
    coins += 100;
    await _persist();
    notifyListeners();
    return true;
  }

  Future<void> updateName(String value) async {
    final String clean = value.trim();
    if (clean.isEmpty) return;
    name = clean.length > 12 ? clean.substring(0, 12) : clean;
    await _persist();
    notifyListeners();
  }

  Future<bool> buy(ShopItem item) async {
    if (owned.contains(item.id)) return true;
    if (coins < item.price) return false;
    coins -= item.price;
    owned.add(item.id);
    selected[categoryKeys[item.category]!] = item.id;
    await _persist();
    notifyListeners();
    return true;
  }

  Future<void> select(ShopItem item) async {
    if (!owned.contains(item.id)) return;
    selected[categoryKeys[item.category]!] = item.id;
    await _persist();
    notifyListeners();
  }

  Future<void> setMuted(bool value) async {
    muted = value;
    await _persist();
    notifyListeners();
  }

  void appendChat(StoredChatMessage message) {
    chatMessages.add(message);
    if (chatMessages.length > 60) chatMessages.removeAt(0);
    _persist();
    notifyListeners();
  }

  void recordPowerUp() {
    totalPowerups++;
    _persist();
    notifyListeners();
  }

  MatchReward recordMatch({
    required bool won,
    required String mode,
    required int playerScore,
    required int opponentScore,
  }) {
    _refreshDailyState(notify: false);
    matches++;
    if (won) {
      wins++;
      winsToday++;
      streak++;
      if (streak > bestStreak) bestStreak = streak;
    } else {
      losses++;
      streak = 0;
    }

    final int rewardCoins = won ? 60 : (mode == 'bot' ? 25 : 20);
    final int rewardXp = won ? 40 : 15;
    coins += rewardCoins;
    xp += rewardXp;

    history.add(
      MatchHistoryEntry(
        won: won,
        mode: mode,
        playerScore: playerScore,
        opponentScore: opponentScore,
        playedAt: DateTime.now(),
      ),
    );
    if (history.length > 12) {
      history.removeRange(0, history.length - 12);
    }

    _persist();
    notifyListeners();
    return MatchReward(coins: rewardCoins, xp: rewardXp);
  }
}
