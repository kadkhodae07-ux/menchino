import 'package:flutter/material.dart';

enum ItemCategory { paddle, ball, trail, theme, avatar, boom }

class ShopItem {
  const ShopItem({
    required this.id,
    required this.category,
    required this.name,
    required this.price,
    this.color1,
    this.color2,
    this.color3,
    this.emoji,
    this.rainbow = false,
    this.background,
    this.starColor,
    this.courtColor,
    this.accentColor,
    this.boomColors = const <Color>[],
  });

  final String id;
  final ItemCategory category;
  final String name;
  final int price;
  final Color? color1;
  final Color? color2;
  final Color? color3;
  final String? emoji;
  final bool rainbow;
  final List<Color>? background;
  final Color? starColor;
  final Color? courtColor;
  final Color? accentColor;
  final List<Color> boomColors;
}

const List<ShopItem> shopItems = <ShopItem>[
  ShopItem(id: 'pad_classic', category: ItemCategory.paddle, name: 'کلاسیک', price: 0, color1: Color(0xFF00E5FF), color2: Color(0xFF0066FF)),
  ShopItem(id: 'pad_fire', category: ItemCategory.paddle, name: 'آتشین', price: 200, color1: Color(0xFFFF9500), color2: Color(0xFFFF2D00)),
  ShopItem(id: 'pad_toxic', category: ItemCategory.paddle, name: 'سمی', price: 250, color1: Color(0xFF7CFF00), color2: Color(0xFF00C853)),
  ShopItem(id: 'pad_ice', category: ItemCategory.paddle, name: 'یخی', price: 300, color1: Color(0xFFEAFFFF), color2: Color(0xFF4FC3F7)),
  ShopItem(id: 'pad_shadow', category: ItemCategory.paddle, name: 'سایه', price: 400, color1: Color(0xFFCFD8DC), color2: Color(0xFF455A64)),
  ShopItem(id: 'pad_gold', category: ItemCategory.paddle, name: 'طلایی', price: 550, color1: Color(0xFFFFE259), color2: Color(0xFFFFA751)),
  ShopItem(id: 'pad_royal', category: ItemCategory.paddle, name: 'سلطنتی', price: 650, color1: Color(0xFFE040FB), color2: Color(0xFF536DFE)),
  ShopItem(id: 'pad_rainbow', category: ItemCategory.paddle, name: 'رنگین‌کمان', price: 900, rainbow: true),

  ShopItem(id: 'ball_classic', category: ItemCategory.ball, name: 'کلاسیک', price: 0, color1: Color(0xFFFFFFFF), color2: Color(0xFFBFF6FF), color3: Color(0xFF37D6FF)),
  ShopItem(id: 'ball_lemon', category: ItemCategory.ball, name: 'لیمویی', price: 150, color1: Color(0xFFFFFDE7), color2: Color(0xFFFFF176), color3: Color(0xFFFFD600)),
  ShopItem(id: 'ball_lava', category: ItemCategory.ball, name: 'گدازه', price: 250, color1: Color(0xFFFFF3E0), color2: Color(0xFFFF6E40), color3: Color(0xFFDD2C00)),
  ShopItem(id: 'ball_plasma', category: ItemCategory.ball, name: 'پلاسما', price: 350, color1: Color(0xFFFCE4EC), color2: Color(0xFFE040FB), color3: Color(0xFF7C4DFF)),
  ShopItem(id: 'ball_void', category: ItemCategory.ball, name: 'تاریک', price: 500, color1: Color(0xFFB388FF), color2: Color(0xFF5E35B1), color3: Color(0xFF311B92)),
  ShopItem(id: 'ball_rainbow', category: ItemCategory.ball, name: 'رنگین‌کمان', price: 800, rainbow: true),

  ShopItem(id: 'trail_neon', category: ItemCategory.trail, name: 'نئون', price: 0, color1: Color(0xFF4DE8FF)),
  ShopItem(id: 'trail_none', category: ItemCategory.trail, name: 'بدون دنباله', price: 50),
  ShopItem(id: 'trail_fire', category: ItemCategory.trail, name: 'آتش', price: 200, color1: Color(0xFFFF7043)),
  ShopItem(id: 'trail_ice', category: ItemCategory.trail, name: 'یخ', price: 250, color1: Color(0xFFB3E5FC)),
  ShopItem(id: 'trail_gold', category: ItemCategory.trail, name: 'طلایی', price: 450, color1: Color(0xFFFFD54F)),
  ShopItem(id: 'trail_galaxy', category: ItemCategory.trail, name: 'کهکشانی', price: 600, color1: Color(0xFFB388FF)),

  ShopItem(id: 'theme_space', category: ItemCategory.theme, name: 'فضا', price: 0, background: <Color>[Color(0xFF070A1A), Color(0xFF0B1030), Color(0xFF070A1A)], starColor: Color(0xFF9FD8FF), courtColor: Color(0x5978A0FF), accentColor: Color(0xFF00E5FF)),
  ShopItem(id: 'theme_sunset', category: ItemCategory.theme, name: 'غروب', price: 300, background: <Color>[Color(0xFF1A0B1E), Color(0xFF3D1030), Color(0xFF120714)], starColor: Color(0xFFFFB27D), courtColor: Color(0x59FF8C78), accentColor: Color(0xFFFF7043)),
  ShopItem(id: 'theme_ice', category: ItemCategory.theme, name: 'قطبی', price: 350, background: <Color>[Color(0xFF04121F), Color(0xFF0A2A44), Color(0xFF04121F)], starColor: Color(0xFFDFF3FF), courtColor: Color(0x59A0DCFF), accentColor: Color(0xFF81D4FA)),
  ShopItem(id: 'theme_matrix', category: ItemCategory.theme, name: 'ماتریکس', price: 400, background: <Color>[Color(0xFF020D02), Color(0xFF042009), Color(0xFF020D02)], starColor: Color(0xFF7DFF9B), courtColor: Color(0x4D50FF78), accentColor: Color(0xFF00E676)),
  ShopItem(id: 'theme_candy', category: ItemCategory.theme, name: 'آبنباتی', price: 500, background: <Color>[Color(0xFF1C0B2A), Color(0xFF38124D), Color(0xFF160820)], starColor: Color(0xFFFFD6F2), courtColor: Color(0x59FF78DC), accentColor: Color(0xFFFF4FD8)),
  ShopItem(id: 'theme_void', category: ItemCategory.theme, name: 'تاریکی مطلق', price: 700, background: <Color>[Color(0xFF000000), Color(0xFF0D0208), Color(0xFF000000)], starColor: Color(0xFFFF5577), courtColor: Color(0x4DFF3C5A), accentColor: Color(0xFFFF2F5A)),

  ShopItem(id: 'av_cool', category: ItemCategory.avatar, name: 'باحال', price: 0, emoji: '😎'),
  ShopItem(id: 'av_robot', category: ItemCategory.avatar, name: 'ربات', price: 100, emoji: '🤖'),
  ShopItem(id: 'av_alien', category: ItemCategory.avatar, name: 'فضایی', price: 150, emoji: '👽'),
  ShopItem(id: 'av_rocket', category: ItemCategory.avatar, name: 'موشک', price: 150, emoji: '🚀'),
  ShopItem(id: 'av_fox', category: ItemCategory.avatar, name: 'روباه', price: 200, emoji: '🦊'),
  ShopItem(id: 'av_skull', category: ItemCategory.avatar, name: 'جمجمه', price: 250, emoji: '💀'),
  ShopItem(id: 'av_brain', category: ItemCategory.avatar, name: 'نابغه', price: 300, emoji: '🧠'),
  ShopItem(id: 'av_dragon', category: ItemCategory.avatar, name: 'اژدها', price: 450, emoji: '🐲'),
  ShopItem(id: 'av_unicorn', category: ItemCategory.avatar, name: 'تک‌شاخ', price: 550, emoji: '🦄'),
  ShopItem(id: 'av_crown', category: ItemCategory.avatar, name: 'پادشاه', price: 800, emoji: '👑'),

  ShopItem(id: 'boom_neon', category: ItemCategory.boom, name: 'نئون', price: 0, boomColors: <Color>[Color(0xFF00E5FF), Color(0xFFFFFFFF)]),
  ShopItem(id: 'boom_fire', category: ItemCategory.boom, name: 'آتش‌بازی', price: 300, boomColors: <Color>[Color(0xFFFF9500), Color(0xFFFF2D00), Color(0xFFFFE259)]),
  ShopItem(id: 'boom_galaxy', category: ItemCategory.boom, name: 'کهکشانی', price: 500, boomColors: <Color>[Color(0xFFB388FF), Color(0xFF7C4DFF), Color(0xFFFF4FD8)]),
  ShopItem(id: 'boom_gold', category: ItemCategory.boom, name: 'طلایی', price: 700, boomColors: <Color>[Color(0xFFFFD54F), Color(0xFFFFF8E1), Color(0xFFFFA751)]),
];

const Map<ItemCategory, String> categoryNames = <ItemCategory, String>{
  ItemCategory.paddle: '🏓 راکت‌ها',
  ItemCategory.ball: '⚪ توپ‌ها',
  ItemCategory.trail: '💫 دنباله‌ها',
  ItemCategory.theme: '🌌 زمین‌ها',
  ItemCategory.avatar: '😀 آواتارها',
  ItemCategory.boom: '💥 افکت گل',
};

const Map<ItemCategory, String> categoryKeys = <ItemCategory, String>{
  ItemCategory.paddle: 'paddle',
  ItemCategory.ball: 'ball',
  ItemCategory.trail: 'trail',
  ItemCategory.theme: 'theme',
  ItemCategory.avatar: 'avatar',
  ItemCategory.boom: 'boom',
};

ShopItem itemById(String? id, {ItemCategory? fallbackCategory}) {
  return shopItems.firstWhere(
    (item) => item.id == id,
    orElse: () => shopItems.firstWhere(
      (item) => fallbackCategory == null || item.category == fallbackCategory,
    ),
  );
}
