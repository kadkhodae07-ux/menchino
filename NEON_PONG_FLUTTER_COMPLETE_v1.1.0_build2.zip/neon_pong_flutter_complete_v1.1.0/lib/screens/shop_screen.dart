import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../utils/fa_digits.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  ItemCategory _category = ItemCategory.paddle;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) {
          final List<ShopItem> items = shopItems.where((ShopItem item) => item.category == _category).toList();
          return CustomScrollView(
            slivers: <Widget>[
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: <Widget>[
                      const Expanded(child: Text('🛍️ فروشگاه', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
                      _coin(save.coins),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                sliver: SliverToBoxAdapter(
                  child: Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: ItemCategory.values.map((ItemCategory category) {
                      final bool selected = category == _category;
                      return ChoiceChip(
                        selected: selected,
                        label: Text(categoryNames[category]!),
                        onSelected: (_) => setState(() => _category = category),
                        selectedColor: const Color(0xFF00E5FF).withOpacity(0.25),
                        backgroundColor: Colors.white.withOpacity(0.04),
                        side: BorderSide(color: selected ? const Color(0xFF00E5FF) : Colors.white.withOpacity(0.15)),
                        labelStyle: TextStyle(color: selected ? Colors.white : const Color(0xFFB8C6E8), fontSize: 12.5),
                      );
                    }).toList(),
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 130),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 190,
                    mainAxisExtent: 190,
                    mainAxisSpacing: 11,
                    crossAxisSpacing: 11,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) => _itemCard(context, save, items[index]),
                    childCount: items.length,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _coin(int coins) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFFFD54F).withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFFFD54F).withOpacity(0.5)),
      ),
      child: Text('🪙 ${faNumber(coins)}', style: const TextStyle(color: Color(0xFFFFE259), fontWeight: FontWeight.w900)),
    );
  }

  Widget _itemCard(BuildContext context, SaveData save, ShopItem item) {
    final bool owned = save.owned.contains(item.id);
    final bool selected = save.selected[categoryKeys[item.category]] == item.id;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: selected ? const Color(0xFF38FFB0) : Colors.white.withOpacity(0.15)),
        boxShadow: selected ? <BoxShadow>[BoxShadow(color: const Color(0xFF38FFB0).withOpacity(0.25), blurRadius: 18)] : null,
      ),
      child: Column(
        children: <Widget>[
          Expanded(child: Center(child: _preview(item))),
          Text(item.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13.5)),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 36,
            child: selected
                ? FilledButton(
                    onPressed: null,
                    style: FilledButton.styleFrom(disabledBackgroundColor: const Color(0xFF38FFB0).withOpacity(0.14), disabledForegroundColor: const Color(0xFF7DFFC4)),
                    child: const Text('✓ انتخاب شد', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                  )
                : owned
                    ? OutlinedButton(
                        onPressed: () => save.select(item),
                        style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF8FF4FF), side: BorderSide(color: const Color(0xFF00E5FF).withOpacity(0.5))),
                        child: const Text('انتخاب', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                      )
                    : FilledButton(
                        onPressed: save.coins >= item.price
                            ? () async {
                                final bool purchased = await save.buy(item);
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(purchased ? '🎉 «${item.name}» خریداری شد!' : '😅 سکه کافی نیست')));
                                }
                              }
                            : () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('😅 سکه کافی نیست! بازی کن و سکه جمع کن'))),
                        style: FilledButton.styleFrom(backgroundColor: save.coins >= item.price ? const Color(0xFFFFD54F) : Colors.white.withOpacity(0.08), foregroundColor: save.coins >= item.price ? Colors.black : const Color(0xFF66739A)),
                        child: Text('🪙 ${faNumber(item.price)}', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _preview(ShopItem item) {
    switch (item.category) {
      case ItemCategory.paddle:
        return Container(
          width: 18,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            gradient: item.rainbow
                ? const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[Colors.red, Colors.orange, Colors.yellow, Colors.green, Colors.blue, Colors.purple])
                : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[item.color1!, Colors.white, item.color2!]),
            boxShadow: <BoxShadow>[BoxShadow(color: (item.color1 ?? const Color(0xFFFF00FF)).withOpacity(0.55), blurRadius: 14)],
          ),
        );
      case ItemCategory.ball:
        final List<Color> colors = item.rainbow
            ? const <Color>[Colors.white, Color(0xFFFF00FF), Color(0xFF00FFFF)]
            : <Color>[item.color1!, item.color2!, item.color3!];
        return Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(center: const Alignment(-0.3, -0.3), colors: colors), boxShadow: <BoxShadow>[BoxShadow(color: colors[1].withOpacity(0.5), blurRadius: 16)]),
        );
      case ItemCategory.trail:
        return Container(
          width: 78,
          height: 10,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            gradient: item.color1 == null ? null : LinearGradient(colors: <Color>[item.color1!.withOpacity(0), item.color1!]),
            color: item.color1 == null ? const Color(0xFF30354A) : null,
          ),
        );
      case ItemCategory.theme:
        return Container(
          width: 72,
          height: 50,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: item.background!)),
          child: Stack(children: <Widget>[
            Positioned(top: 8, left: 13, child: _dot(item.starColor!)),
            Positioned(top: 20, right: 16, child: _dot(item.starColor!)),
            Positioned(bottom: 10, left: 34, child: _dot(item.accentColor!, size: 4)),
          ]),
        );
      case ItemCategory.avatar:
        return Text(item.emoji!, style: const TextStyle(fontSize: 43));
      case ItemCategory.boom:
        return Row(mainAxisSize: MainAxisSize.min, children: item.boomColors.map((Color color) => Container(width: 13, height: 13, margin: const EdgeInsets.symmetric(horizontal: 3), decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: <BoxShadow>[BoxShadow(color: color, blurRadius: 10)]))).toList());
    }
  }

  Widget _dot(Color color, {double size = 3}) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}
