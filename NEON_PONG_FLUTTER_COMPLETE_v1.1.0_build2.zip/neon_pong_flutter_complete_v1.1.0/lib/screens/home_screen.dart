import 'package:flutter/material.dart';

import '../data/rank_data.dart';
import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../game/game_engine.dart';
import '../utils/fa_digits.dart';
import 'friend_screen.dart';
import 'game_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.onOpenShop,
    required this.onOpenRank,
    required this.onOpenProfile,
  });

  final VoidCallback onOpenShop;
  final VoidCallback onOpenRank;
  final VoidCallback onOpenProfile;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return AnimatedBuilder(
      animation: save,
      builder: (BuildContext context, Widget? child) {
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 128),
            children: <Widget>[
              _header(context, save),
              const SizedBox(height: 14),
              _stats(save),
              const SizedBox(height: 12),
              _hero(context),
              const SizedBox(height: 12),
              _challenge(save),
              const SizedBox(height: 12),
              _daily(context, save),
              const SizedBox(height: 12),
              _records(save),
              const SizedBox(height: 12),
              _feature(context, save),
            ],
          ),
        );
      },
    );
  }

  Widget _header(BuildContext context, SaveData save) {
    return Row(
      children: <Widget>[
        InkWell(
          onTap: onOpenProfile,
          borderRadius: BorderRadius.circular(17),
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: const Color(0xFF00E5FF).withOpacity(0.1),
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.45), width: 2),
              boxShadow: <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.2), blurRadius: 16)],
            ),
            child: Center(child: Text(save.avatarEmoji, style: const TextStyle(fontSize: 27))),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text('خوش اومدی 👋', style: TextStyle(color: Color(0xFF8FA3C8), fontSize: 11.5)),
              Text(save.name, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
        _pill('🪙 ${faNumber(save.coins)}', const Color(0xFFFFE259), const Color(0xFFFFD54F)),
        const SizedBox(width: 7),
        _pill('⭐ سطح ${faNumber(save.level)}', const Color(0xFF8FF4FF), const Color(0xFF00E5FF)),
      ],
    );
  }

  Widget _pill(String text, Color foreground, Color border) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(
        color: border.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: border.withOpacity(0.45)),
      ),
      child: Text(text, style: TextStyle(color: foreground, fontWeight: FontWeight.w900, fontSize: 12.5)),
    );
  }

  Widget _stats(SaveData save) {
    final int rank = 1 + rankBots.where((RankBot bot) => bot.points > save.points).length;
    return Row(
      children: <Widget>[
        _stat('🎮', faNumber(save.matches), 'بازی', onOpenProfile),
        const SizedBox(width: 7),
        _stat('🏆', faNumber(save.wins), 'برد', onOpenProfile),
        const SizedBox(width: 7),
        _stat('🎖️', faNumber(rank), 'رتبه', onOpenRank),
        const SizedBox(width: 7),
        _stat('🎯', '${faNumber(save.owned.length)}/${faNumber(shopItems.length)}', 'آیتم', onOpenShop),
      ],
    );
  }

  Widget _stat(String icon, String value, String label, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 3),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            children: <Widget>[
              Text(icon, style: const TextStyle(fontSize: 19)),
              Text(value, style: const TextStyle(color: Color(0xFF8FF4FF), fontSize: 15, fontWeight: FontWeight.w900), maxLines: 1),
              Text(label, style: const TextStyle(color: Color(0xFF8FA3C8), fontSize: 10.5)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hero(BuildContext context) {
    return _card(
      child: Column(
        children: <Widget>[
          const Text('آماده‌ای برای مسابقه؟ ⚡', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, shadows: <Shadow>[Shadow(color: Color(0xFF00E5FF), blurRadius: 20)])),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: FilledButton(
              onPressed: () => _showDifficulty(context),
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00E5FF), foregroundColor: const Color(0xFF031018), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
              child: const Text('🚀 بازی با ربات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const FriendScreen())),
              style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFFB8EC), backgroundColor: const Color(0xFFFF2FD6).withOpacity(0.1), side: BorderSide(color: const Color(0xFFFF2FD6).withOpacity(0.55)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: const Text('👥 دو نفره با دوست', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(height: 13),
          const Text('🎁 با هر برد سکه، تجربه و Power-Up بگیر!', style: TextStyle(color: Color(0xFF8FA3C8), fontSize: 12)),
        ],
      ),
    );
  }

  Widget _challenge(SaveData save) {
    const int target = 5;
    final double progress = (save.winsToday / target).clamp(0, 1).toDouble();
    return _card(
      border: const Color(0xFFFF2FD6),
      gradient: <Color>[const Color(0xFFFF2FD6).withOpacity(0.12), const Color(0xFF7A2BFF).withOpacity(0.16)],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('🔥 چالش روزانه: ۵ برد', style: TextStyle(color: Color(0xFFFFB8EC), fontSize: 15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('امروز ${faNumber(save.winsToday)} از ${faNumber(target)} برد انجام دادی!', style: const TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: Colors.white.withOpacity(0.08), valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFF2FD6))),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              const Text('🎯 پیشرفت', style: TextStyle(color: Color(0xFFFFB8EC), fontSize: 11.5)),
              Text(save.winsToday >= target ? '🏆 تکمیل شد!' : '${faNumber(target - save.winsToday)} مونده', style: const TextStyle(color: Color(0xFFFFB8EC), fontSize: 11.5)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _daily(BuildContext context, SaveData save) {
    final bool canClaim = save.canClaimDaily();
    return _card(
      child: Row(
        children: <Widget>[
          Text(canClaim ? '🎁' : '✅', style: const TextStyle(fontSize: 36)),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(canClaim ? 'جایزه روزانه' : 'جایزه امروزت رو گرفتی!', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
                Text(canClaim ? 'امروز ۱۰۰ سکه رایگان بگیر!' : 'فردا دوباره سر بزن 🌙', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 12.5)),
              ],
            ),
          ),
          if (canClaim)
            FilledButton(
              onPressed: () async {
                final bool claimed = await save.claimDaily();
                if (context.mounted && claimed) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('🎉 ۱۰۰ سکه گرفتی!')));
              },
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFD54F), foregroundColor: Colors.black),
              child: const Text('دریافت', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
        ],
      ),
    );
  }

  Widget _records(SaveData save) {
    return _card(
      border: const Color(0xFF38FFB0),
      gradient: <Color>[const Color(0xFF38FFB0).withOpacity(0.08), const Color(0xFF00E5FF).withOpacity(0.12)],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('📊 رکوردهای شخصی', style: TextStyle(color: Color(0xFF7DFFC4), fontSize: 14, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Row(children: <Widget>[
            Expanded(child: _record('🔥 بهترین Streak', '${faNumber(save.bestStreak)} برد')),
            const SizedBox(width: 8),
            Expanded(child: _record('🎯 نرخ برد', '${faNumber((save.winRate * 100).round())}٪')),
          ]),
          const SizedBox(height: 8),
          Row(children: <Widget>[
            Expanded(child: _record('✨ Power-Ups', faNumber(save.totalPowerups))),
            const SizedBox(width: 8),
            Expanded(child: _record('🏆 امتیاز لیگ', faNumber(save.points))),
          ]),
        ],
      ),
    );
  }

  Widget _record(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text(label, style: const TextStyle(color: Color(0xFFB8D6E8), fontSize: 11.5)),
        Text(value, style: const TextStyle(color: Color(0xFF7DFFC4), fontSize: 14, fontWeight: FontWeight.w900)),
      ]),
    );
  }

  Widget _feature(BuildContext context, SaveData save) {
    final List<ShopItem> unowned = shopItems.where((ShopItem item) => !save.owned.contains(item.id)).toList()..sort((ShopItem a, ShopItem b) => b.price.compareTo(a.price));
    final ShopItem? feature = unowned.isEmpty ? null : unowned.first;
    return _card(
      child: Row(
        children: <Widget>[
          Text(feature == null ? '🌟' : '🔥', style: const TextStyle(fontSize: 36)),
          const SizedBox(width: 13),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(feature == null ? 'همه آیتم‌ها مال توئه!' : 'پیشنهاد ویژه فروشگاه', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
              Text(feature == null ? 'کلکسیونت کامل شد 🎉' : '${categoryNames[feature.category]} • ${feature.name} • ${faNumber(feature.price)} سکه', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 12)),
            ]),
          ),
          OutlinedButton(onPressed: onOpenShop, child: const Text('مشاهده')),
        ],
      ),
    );
  }

  Widget _card({required Widget child, Color? border, List<Color>? gradient}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: gradient ?? const <Color>[Color(0xFF141A3A), Color(0xFF0A0C1E)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (border ?? const Color(0xFF00E5FF)).withOpacity(0.3)),
        boxShadow: <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.05), blurRadius: 30)],
      ),
      child: child,
    );
  }

  Future<void> _showDifficulty(BuildContext context) async {
    final int? difficulty = await showDialog<int>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        backgroundColor: const Color(0xFF141A3A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: const Color(0xFF00E5FF).withOpacity(0.3))),
        title: const Text('🤖 سطح ربات را انتخاب کن', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _difficultyButton(context, 0, '🌱 آسان', 'برای گرم کردن'),
            _difficultyButton(context, 1, '⚡ متوسط', 'یه چالش معمولی'),
            _difficultyButton(context, 2, '🔥 سخت', 'فقط حرفه‌ای‌ها'),
            _difficultyButton(context, 3, '💀 غیرممکن', 'شبیه‌ساز دیوار!'),
          ],
        ),
      ),
    );
    if (difficulty != null && context.mounted) {
      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => GameScreen(mode: GameMode.bot, difficulty: difficulty)));
    }
  }

  Widget _difficultyButton(BuildContext context, int value, String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SizedBox(
        width: double.infinity,
        child: OutlinedButton(
          onPressed: () => Navigator.pop(context, value),
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), side: BorderSide(color: Colors.white.withOpacity(0.2)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: <Widget>[Text(title), Text(subtitle, style: const TextStyle(color: Color(0xFF8FA3C8), fontSize: 12))]),
        ),
      ),
    );
  }
}
