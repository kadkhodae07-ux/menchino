import 'package:flutter/material.dart';

import '../data/save_data.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'shop_screen.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 2;

  void _go(int index) {
    if (_currentIndex == index) return;
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    final List<Widget> screens = <Widget>[
      const ShopScreen(),
      const RankScreen(),
      HomeScreen(
        onOpenShop: () => _go(0),
        onOpenRank: () => _go(1),
        onOpenProfile: () => _go(3),
      ),
      ProfileScreen(onOpenShop: () => _go(0)),
      const ChatScreen(),
    ];

    return AnimatedBuilder(
      animation: save,
      builder: (BuildContext context, Widget? child) {
        return Scaffold(
          backgroundColor: const Color(0xFF05060F),
          body: Stack(
            children: <Widget>[
              IndexedStack(index: _currentIndex, children: screens),
              Positioned(
                left: 0,
                right: 0,
                bottom: 10,
                child: SafeArea(
                  top: false,
                  child: Center(child: _buildNavigation()),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNavigation() {
    const List<(IconData, String)> items = <(IconData, String)>[
      (Icons.storefront_rounded, 'فروشگاه'),
      (Icons.emoji_events_rounded, 'رتبه'),
      (Icons.home_rounded, 'خانه'),
      (Icons.person_rounded, 'پروفایل'),
      (Icons.chat_bubble_rounded, 'چت'),
    ];

    return Container(
      constraints: const BoxConstraints(maxWidth: 430),
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xE60C1026),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 40, offset: const Offset(0, 8)),
          BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.12), blurRadius: 24),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List<Widget>.generate(items.length, (int index) {
          final bool selected = _currentIndex == index;
          if (index == 2) {
            return GestureDetector(
              onTap: () => _go(index),
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  width: 58,
                  height: 58,
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: <Color>[Color(0xFF00E5FF), Color(0xFF7A2BFF)]),
                    border: Border.all(color: const Color(0xFF0A0E20), width: 3),
                    boxShadow: <BoxShadow>[
                      BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.55), blurRadius: 26),
                    ],
                  ),
                  child: const Icon(Icons.home_rounded, size: 27, color: Colors.white),
                ),
              ),
            );
          }
          return Expanded(
            child: InkWell(
              onTap: () => _go(index),
              borderRadius: BorderRadius.circular(18),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
                decoration: BoxDecoration(
                  color: selected ? const Color(0xFF00E5FF).withOpacity(0.13) : Colors.transparent,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Icon(items[index].$1, size: 20, color: selected ? Colors.white : const Color(0xFF7D8DB3)),
                    const SizedBox(height: 2),
                    Text(items[index].$2, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: selected ? Colors.white : const Color(0xFF7D8DB3))),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
