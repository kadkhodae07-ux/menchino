import 'package:flutter/material.dart';

import '../data/rank_data.dart';
import '../data/save_data.dart';
import '../utils/fa_digits.dart';

class RankScreen extends StatelessWidget {
  const RankScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) {
          final List<_RankEntry> players = <_RankEntry>[
            ...rankBots.map((RankBot bot) => _RankEntry(name: bot.name, emoji: bot.emoji, points: bot.points)),
            _RankEntry(name: save.name, emoji: save.avatarEmoji, points: save.points, isMe: true),
          ]..sort((_RankEntry a, _RankEntry b) => b.points.compareTo(a.points));
          final int myIndex = players.indexWhere((_RankEntry player) => player.isMe);
          final int pointsNeeded = myIndex > 0 ? players[myIndex - 1].points - save.points + 1 : 0;
          return ListView(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 130),
            children: <Widget>[
              const Text('🏆 رتبه‌بندی', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              _season(),
              const SizedBox(height: 12),
              _myRank(save, myIndex + 1, players.length, pointsNeeded),
              const SizedBox(height: 14),
              _podium(players),
              const SizedBox(height: 14),
              ...List<Widget>.generate(players.length - 3, (int index) => _rankRow(players[index + 3], index + 4)),
            ],
          );
        },
      ),
    );
  }

  Widget _season() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: <Color>[const Color(0xFF00E5FF).withOpacity(0.14), const Color(0xFF7A2BFF).withOpacity(0.16)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.35)),
      ),
      child: const Column(children: <Widget>[
        Text('⚡ لیگ نئونی — فصل ۱', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF8FF4FF))),
        SizedBox(height: 4),
        Text('هر برد ۳۰+ امتیاز • هر باخت ۱۰- امتیاز', style: TextStyle(fontSize: 12, color: Color(0xFF9FB2D8))),
      ]),
    );
  }

  Widget _myRank(SaveData save, int rank, int total, int pointsNeeded) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF141A3A), Color(0xFF0A0C1E)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.16)),
      ),
      child: Column(children: <Widget>[
        Text('🎖️ رتبه تو: ${faNumber(rank)} از ${faNumber(total)} — امتیاز: ${faNumber(save.points)}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(color: const Color(0xFF00E5FF).withOpacity(0.1), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3))),
          child: Text(rank == 1 ? '👑 صدرنشین لیگی!' : '⬆️ تا رتبه ${faNumber(rank - 1)} فقط ${faNumber(pointsNeeded)} امتیاز مونده!', style: const TextStyle(fontSize: 12, color: Color(0xFF8FF4FF))),
        ),
      ]),
    );
  }

  Widget _podium(List<_RankEntry> players) {
    return Row(crossAxisAlignment: CrossAxisAlignment.end, children: <Widget>[
      Expanded(child: _podiumItem(players[1], 2)),
      const SizedBox(width: 9),
      Expanded(child: _podiumItem(players[0], 1)),
      const SizedBox(width: 9),
      Expanded(child: _podiumItem(players[2], 3)),
    ]);
  }

  Widget _podiumItem(_RankEntry player, int place) {
    final List<String> medals = <String>['🥇', '🥈', '🥉'];
    final List<Color> colors = <Color>[const Color(0xFFFFD54F), const Color(0xFFC8D7EB), const Color(0xFFFF965A)];
    return Transform.translate(
      offset: Offset(0, place == 1 ? -6 : 0),
      child: Container(
        padding: EdgeInsets.fromLTRB(6, place == 1 ? 24 : 15, 6, 15),
        decoration: BoxDecoration(
          color: place == 1 ? const Color(0xFFFFD54F).withOpacity(0.08) : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: colors[place - 1].withOpacity(place == 1 ? 0.75 : 0.5)),
          boxShadow: place == 1 ? <BoxShadow>[BoxShadow(color: const Color(0xFFFFD54F).withOpacity(0.28), blurRadius: 28)] : null,
        ),
        child: Column(children: <Widget>[
          Text(medals[place - 1], style: const TextStyle(fontSize: 22)),
          Text(player.emoji, style: const TextStyle(fontSize: 36)),
          Text('${player.name}${player.isMe ? ' (تو)' : ''}', textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          Text('${faNumber(player.points)} امتیاز', style: const TextStyle(fontSize: 11, color: Color(0xFF8FA3C8))),
        ]),
      ),
    );
  }

  Widget _rankRow(_RankEntry player, int rank) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: player.isMe ? const Color(0xFF00E5FF).withOpacity(0.1) : Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: player.isMe ? const Color(0xFF00E5FF) : Colors.transparent),
        boxShadow: player.isMe ? <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.2), blurRadius: 16)] : null,
      ),
      child: Row(children: <Widget>[
        CircleAvatar(radius: 16, backgroundColor: Colors.white.withOpacity(0.07), child: Text(faNumber(rank), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Color(0xFF8FA3C8)))),
        const SizedBox(width: 12),
        Text(player.emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(width: 12),
        Expanded(child: Text('${player.name}${player.isMe ? ' ⭐' : ''}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
        Text(faNumber(player.points), style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF8FF4FF))),
      ]),
    );
  }
}

class _RankEntry {
  const _RankEntry({required this.name, required this.emoji, required this.points, this.isMe = false});
  final String name;
  final String emoji;
  final int points;
  final bool isMe;
}
