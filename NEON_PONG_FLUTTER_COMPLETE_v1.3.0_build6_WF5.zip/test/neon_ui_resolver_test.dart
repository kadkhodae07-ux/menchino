import 'package:flutter_test/flutter_test.dart';
import 'package:neon_pong/data/shop_items.dart';
import 'package:neon_pong/game/game_engine.dart';
import 'package:neon_pong/ui/icons/neon_icon_resolver.dart';
import 'package:neon_pong/ui/resolvers/neon_format.dart';

void main() {
  test('Persian number formatter converts every digit', () {
    expect(NeonFormat.fa(1203456789), '۱۲۰۳۴۵۶۷۸۹');
  });

  test('every shop category resolves to a neon icon', () {
    for (final ItemCategory category in ItemCategory.values) {
      expect(NeonIconResolver.category(category), isNotNull);
    }
  });

  test('all twelve power-ups resolve to a neon icon', () {
    expect(PowerUpType.values.length, 12);
    for (final PowerUpType type in PowerUpType.values) {
      expect(NeonIconResolver.powerUp(type), isNotNull);
    }
  });
}
