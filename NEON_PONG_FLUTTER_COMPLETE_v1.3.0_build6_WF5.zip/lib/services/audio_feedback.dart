import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

import '../data/save_data.dart';

enum FeedbackEvent {
  tap,
  select,
  send,
  launch,
  paddle,
  wall,
  score,
  losePoint,
  buy,
  claim,
  pickup,
  shield,
  error,
  win,
  lose,
}

class AudioFeedbackService {
  AudioFeedbackService._();

  static final AudioFeedbackService instance = AudioFeedbackService._();

  final Map<FeedbackEvent, AudioPlayer> _players = <FeedbackEvent, AudioPlayer>{};

  String _fileFor(FeedbackEvent event) {
    switch (event) {
      case FeedbackEvent.tap:
        return 'click.wav';
      case FeedbackEvent.select:
        return 'select.wav';
      case FeedbackEvent.send:
        return 'send.wav';
      case FeedbackEvent.launch:
        return 'serve.wav';
      case FeedbackEvent.paddle:
        return 'hit_paddle.wav';
      case FeedbackEvent.wall:
        return 'hit_wall.wav';
      case FeedbackEvent.score:
        return 'score_win.wav';
      case FeedbackEvent.losePoint:
        return 'score_lose.wav';
      case FeedbackEvent.buy:
        return 'buy.wav';
      case FeedbackEvent.claim:
        return 'claim.wav';
      case FeedbackEvent.pickup:
        return 'powerup.wav';
      case FeedbackEvent.shield:
        return 'shield.wav';
      case FeedbackEvent.error:
        return 'error.wav';
      case FeedbackEvent.win:
        return 'victory.wav';
      case FeedbackEvent.lose:
        return 'defeat.wav';
    }
  }

  double _volumeFor(FeedbackEvent event) {
    switch (event) {
      case FeedbackEvent.paddle:
      case FeedbackEvent.wall:
      case FeedbackEvent.tap:
      case FeedbackEvent.select:
        return 0.70;
      case FeedbackEvent.score:
      case FeedbackEvent.losePoint:
      case FeedbackEvent.pickup:
      case FeedbackEvent.shield:
        return 0.84;
      case FeedbackEvent.win:
      case FeedbackEvent.lose:
        return 0.92;
      default:
        return 0.80;
    }
  }

  Future<void> play(FeedbackEvent event) async {
    if (SaveData.instance.muted) return;

    final AudioPlayer player = _players.putIfAbsent(
      event,
      AudioPlayer.new,
    );

    try {
      await player.setPlayerMode(PlayerMode.lowLatency);
      await player.stop();
      await player.play(
        AssetSource('sounds/${_fileFor(event)}'),
        volume: _volumeFor(event),
      );
    } catch (_) {
      await SystemSound.play(
        event == FeedbackEvent.win ||
                event == FeedbackEvent.lose ||
                event == FeedbackEvent.score ||
                event == FeedbackEvent.losePoint ||
                event == FeedbackEvent.error
            ? SystemSoundType.alert
            : SystemSoundType.click,
      );
    }

    switch (event) {
      case FeedbackEvent.paddle:
      case FeedbackEvent.pickup:
      case FeedbackEvent.shield:
        await HapticFeedback.lightImpact();
        break;
      case FeedbackEvent.score:
      case FeedbackEvent.buy:
      case FeedbackEvent.claim:
      case FeedbackEvent.lose:
        await HapticFeedback.mediumImpact();
        break;
      case FeedbackEvent.win:
        await HapticFeedback.heavyImpact();
        break;
      case FeedbackEvent.error:
      case FeedbackEvent.losePoint:
      case FeedbackEvent.select:
        await HapticFeedback.selectionClick();
        break;
      case FeedbackEvent.tap:
      case FeedbackEvent.send:
      case FeedbackEvent.launch:
      case FeedbackEvent.wall:
        break;
    }
  }

  Future<void> dispose() async {
    for (final AudioPlayer player in _players.values) {
      await player.dispose();
    }
    _players.clear();
  }
}
