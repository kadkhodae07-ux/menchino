import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'data/save_data.dart';
import 'screens/main_navigation.dart';
import 'ui/theme/neon_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SaveData.initialize();
  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(const NeonPongApp());
}

class NeonPongApp extends StatelessWidget {
  const NeonPongApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'پونگ نئونی',
        debugShowCheckedModeBanner: false,
        theme: NeonTheme.build(),
        builder: (BuildContext context, Widget? child) => Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        ),
        home: const MainNavigation(),
      );
}
