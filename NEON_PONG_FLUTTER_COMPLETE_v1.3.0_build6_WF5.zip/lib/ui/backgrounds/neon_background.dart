import 'package:flutter/material.dart';

import '../theme/neon_colors.dart';

class NeonBackground extends StatelessWidget {
  const NeonBackground({super.key, this.child});

  final Widget? child;

  @override
  Widget build(BuildContext context) => Stack(
        children: <Widget>[
          Positioned.fill(
            child: RepaintBoundary(child: CustomPaint(painter: _BackgroundPainter())),
          ),
          if (child != null) child!,
        ],
      );
}

class _BackgroundPainter extends CustomPainter {
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect bounds = Offset.zero & size;
    canvas.drawRect(
      bounds,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF070A18), NeonColors.bg, Color(0xFF04050B)],
        ).createShader(bounds),
    );

    _halo(canvas, size, Offset(size.width * 0.85, size.height * 0.1), NeonColors.cyan);
    _halo(canvas, size, Offset(size.width * 0.12, size.height * 0.9), NeonColors.pink);

    final Paint grid = Paint()
      ..color = NeonColors.a(NeonColors.edge, 0.045)
      ..strokeWidth = 1;
    const double step = 48;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final Paint dot = Paint()..color = NeonColors.a(NeonColors.cyan, 0.14);
    for (int index = 0; index < 26; index++) {
      final double x = (index * 137.51) % size.width;
      final double y = (index * 91.7) % size.height;
      canvas.drawCircle(Offset(x, y), index % 3 == 0 ? 1.6 : 1, dot);
    }

    canvas.drawRect(
      bounds,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 0.95,
          colors: <Color>[
            Colors.transparent,
            NeonColors.a(const Color(0xFF000008), 0.5),
          ],
        ).createShader(bounds),
    );
  }

  void _halo(Canvas canvas, Size size, Offset center, Color color) {
    final double radius = size.width * 0.55;
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[NeonColors.a(color, 0.05), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: radius)),
    );
  }
}
