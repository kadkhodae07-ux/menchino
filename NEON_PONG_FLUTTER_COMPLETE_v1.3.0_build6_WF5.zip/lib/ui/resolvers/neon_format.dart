/// لایه نمایشی اعداد فارسی — بدون تغییر داده‌های ذخیره‌شده.
abstract class NeonFormat {
  static const String _fa = '۰۱۲۳۴۵۶۷۸۹';

  static String fa(Object? value) => (value ?? '').toString().replaceAllMapped(
        RegExp(r'\d'),
        (Match match) => _fa[int.parse(match.group(0)!)],
      );

  static String tier(int price) => price == 0
      ? 'پایه'
      : price < 250
          ? 'معمولی'
          : price < 500
              ? 'کمیاب'
              : price < 700
                  ? 'حماسی'
                  : 'افسانه‌ای';
}
