import 'package:flutter/material.dart';

import '../../widgets/pressable_surface.dart';
import '../icons/neon_icon.dart';
import '../theme/neon_colors.dart';
import '../theme/neon_radius.dart';
import '../theme/neon_spacing.dart';
import '../theme/neon_typography.dart';

enum NeonButtonKind { primary, secondary, gold, danger, ghost }

class NeonButton extends StatelessWidget {
  const NeonButton({
    super.key,
    this.label,
    this.icon,
    this.onPressed,
    this.kind = NeonButtonKind.primary,
    this.enabled = true,
    this.selected = false,
    this.big = false,
    this.expanded = false,
  });

  final String? label;
  final NeonIconId? icon;
  final VoidCallback? onPressed;
  final NeonButtonKind kind;
  final bool enabled;
  final bool selected;
  final bool big;
  final bool expanded;

  Color get _accent => switch (kind) {
        NeonButtonKind.primary => NeonColors.cyan,
        NeonButtonKind.secondary => NeonColors.purple,
        NeonButtonKind.gold => NeonColors.gold,
        NeonButtonKind.danger => NeonColors.red,
        NeonButtonKind.ghost => NeonColors.edge,
      };

  @override
  Widget build(BuildContext context) {
    final bool isEnabled = enabled && onPressed != null;
    final Color foreground = kind == NeonButtonKind.primary || kind == NeonButtonKind.gold
        ? const Color(0xFF031018)
        : NeonColors.text;
    final Widget content = Container(
      padding: EdgeInsets.symmetric(
        horizontal: big ? NeonSpacing.xl : NeonSpacing.lg,
        vertical: big ? NeonSpacing.md + 2 : NeonSpacing.md - 1,
      ),
      child: Row(
        mainAxisSize: expanded ? MainAxisSize.max : MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          if (icon != null) ...<Widget>[
            NeonIcon(
              icon!,
              size: big ? 20 : 17,
              color: isEnabled ? foreground : NeonColors.faint,
            ),
            if (label != null) const SizedBox(width: NeonSpacing.sm),
          ],
          if (label != null)
            Flexible(
              child: Text(
                label!,
                style: (big ? NeonType.btn.copyWith(fontSize: 16) : NeonType.btn).copyWith(
                  color: isEnabled ? foreground : NeonColors.faint,
                  fontWeight: FontWeight.w900,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
        ],
      ),
    );

    final Widget button = PressableSurface(
      onTap: onPressed,
      enabled: isEnabled,
      selected: selected,
      accent: _accent,
      radius: NeonRadius.md + 2,
      lip: 5,
      padding: EdgeInsets.zero,
      fill: kind == NeonButtonKind.ghost
          ? const LinearGradient(
              colors: <Color>[NeonColors.surface3, NeonColors.surface2],
            )
          : LinearGradient(
              colors: kind == NeonButtonKind.primary
                  ? const <Color>[
                      Color(0xFF7FF3FF),
                      NeonColors.cyan,
                      Color(0xFF00B8D4),
                    ]
                  : kind == NeonButtonKind.gold
                      ? const <Color>[
                          Color(0xFFFFF3B0),
                          NeonColors.gold,
                          Color(0xFFFFA751),
                        ]
                      : kind == NeonButtonKind.danger
                          ? const <Color>[
                              Color(0xFFFF8FA3),
                              NeonColors.red,
                              Color(0xFFD32F4F),
                            ]
                          : const <Color>[NeonColors.surface3, NeonColors.surface2],
            ),
      child: content,
    );

    return expanded ? SizedBox(width: double.infinity, child: button) : button;
  }
}
