import 'package:flutter/material.dart';

import '../theme/neon_colors.dart';
import '../theme/neon_radius.dart';
import '../theme/neon_shadows.dart';

/// BoxDecoration حجمی مرکزی: گرادیان، حاشیه، Lip و Glow محدود.
abstract class NeonSurface {
  static BoxDecoration box({
    Color accent = NeonColors.cyan,
    double glow = 0.12,
    double radius = NeonRadius.lg,
    bool disabled = false,
    bool selected = false,
  }) {
    final Color top = disabled
        ? const Color(0xFF0C101E)
        : Color.lerp(NeonColors.surface3, NeonColors.surface2, 0.2)!;
    final Color edge = disabled
        ? NeonColors.a(NeonColors.edge, 0.10)
        : selected
            ? NeonColors.a(NeonColors.green, 0.75)
            : NeonColors.a(accent, 0.32);
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[top, NeonColors.surface, NeonColors.a(NeonColors.lipDark, 0.9)],
        stops: const <double>[0, 0.72, 1],
      ),
      borderRadius: NeonRadius.r(radius),
      border: Border.all(color: edge, width: selected ? 1.4 : 1),
      boxShadow: disabled
          ? NeonShadows.pressed()
          : NeonShadows.lift(accent, selected ? 0.3 : glow),
    );
  }

  static Widget topHighlight(double radius, [double opacity = 0.2]) => Positioned(
        top: 1,
        left: radius,
        right: radius,
        height: 1,
        child: IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: <Color>[
                  Colors.transparent,
                  NeonColors.a(Colors.white, opacity),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      );
}
