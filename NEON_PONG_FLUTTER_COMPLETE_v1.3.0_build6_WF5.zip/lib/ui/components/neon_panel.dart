import 'package:flutter/material.dart';

import '../icons/neon_icon.dart';
import '../theme/neon_colors.dart';
import '../theme/neon_radius.dart';
import '../theme/neon_spacing.dart';
import '../theme/neon_typography.dart';
import 'neon_surface.dart';

class NeonPanel extends StatelessWidget {
  const NeonPanel({
    super.key,
    this.child,
    this.title,
    this.icon,
    this.trailing,
    this.accent = NeonColors.cyan,
    this.padding = const EdgeInsets.all(NeonSpacing.lg),
    this.radius = NeonRadius.lg,
    this.dense = false,
  });

  final Widget? child;
  final String? title;
  final NeonIconId? icon;
  final Widget? trailing;
  final Color accent;
  final EdgeInsets padding;
  final double radius;
  final bool dense;

  @override
  Widget build(BuildContext context) => RepaintBoundary(
        child: Container(
          decoration: NeonSurface.box(accent: accent, radius: radius),
          padding: padding,
          child: Stack(
            children: <Widget>[
              NeonSurface.topHighlight(radius),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  if (title != null)
                    Padding(
                      padding: EdgeInsets.only(bottom: dense ? NeonSpacing.sm : NeonSpacing.md),
                      child: Row(
                        children: <Widget>[
                          if (icon != null) ...<Widget>[
                            NeonIcon(icon!, size: 18, color: accent),
                            const SizedBox(width: 6),
                          ],
                          Expanded(
                            child: Text(
                              title!,
                              style: NeonType.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (trailing != null) trailing!,
                        ],
                      ),
                    ),
                  if (child != null) child!,
                ],
              ),
            ],
          ),
        ),
      );
}
