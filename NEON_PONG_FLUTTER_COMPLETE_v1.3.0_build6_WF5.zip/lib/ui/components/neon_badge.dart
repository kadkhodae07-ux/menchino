import 'package:flutter/material.dart';

import '../icons/neon_icon.dart';
import '../theme/neon_colors.dart';
import '../theme/neon_radius.dart';
import '../theme/neon_spacing.dart';
import '../theme/neon_typography.dart';

class NeonBadge extends StatelessWidget {
  const NeonBadge({
    super.key,
    this.icon,
    required this.text,
    this.accent = NeonColors.cyan,
    this.filled = false,
    this.size = 12,
  });

  final NeonIconId? icon;
  final String text;
  final Color accent;
  final bool filled;
  final double size;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(
          horizontal: NeonSpacing.md - 2,
          vertical: NeonSpacing.xs + 1,
        ),
        decoration: BoxDecoration(
          gradient: filled
              ? LinearGradient(
                  colors: <Color>[
                    NeonColors.a(accent, 0.28),
                    NeonColors.a(accent, 0.12),
                  ],
                )
              : null,
          color: filled ? null : NeonColors.a(accent, 0.08),
          borderRadius: NeonRadius.r(NeonRadius.pill),
          border: Border.all(color: NeonColors.a(accent, 0.55), width: 1),
          boxShadow: <BoxShadow>[
            BoxShadow(color: NeonColors.a(accent, 0.15), blurRadius: 6),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (icon != null) ...<Widget>[
              NeonIcon(icon!, size: size + 2, color: accent),
              const SizedBox(width: 4),
            ],
            Text(
              text,
              style: NeonType.btnSm.copyWith(color: accent, fontSize: size),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      );
}
