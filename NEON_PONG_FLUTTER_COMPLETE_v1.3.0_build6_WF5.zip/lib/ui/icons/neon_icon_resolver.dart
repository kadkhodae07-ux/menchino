import 'package:flutter/material.dart';

import '../../data/shop_items.dart';
import '../../game/game_engine.dart';
import 'neon_icon.dart';

/// نگاشت داده‌های موجود پروژه به هویت آیکنی جدید، بدون تغییر مدل داده.
abstract class NeonIconResolver {
  static NeonIconId category(ItemCategory category) => switch (category) {
        ItemCategory.paddle => NeonIconId.paddle,
        ItemCategory.ball => NeonIconId.ball,
        ItemCategory.trail => NeonIconId.trail,
        ItemCategory.theme => NeonIconId.arena,
        ItemCategory.avatar => NeonIconId.avatar,
        ItemCategory.boom => NeonIconId.goalFx,
      };

  static NeonIconId powerUp(PowerUpType type) => switch (type) {
        PowerUpType.big => NeonIconId.puBig,
        PowerUpType.small => NeonIconId.puSmall,
        PowerUpType.multi => NeonIconId.puMulti,
        PowerUpType.slow => NeonIconId.puSlow,
        PowerUpType.fast => NeonIconId.puFast,
        PowerUpType.shield => NeonIconId.puShield,
        PowerUpType.giantBall => NeonIconId.puGiantBall,
        PowerUpType.paddleBoost => NeonIconId.puPaddleBoost,
        PowerUpType.freeze => NeonIconId.puFreeze,
        PowerUpType.curve => NeonIconId.puCurve,
        PowerUpType.doublePoint => NeonIconId.puDoublePoint,
        PowerUpType.coin => NeonIconId.puCoin,
      };

  static NeonIconId difficulty(int index) => switch (index) {
        0 => NeonIconId.diffEasy,
        1 => NeonIconId.diffMedium,
        2 => NeonIconId.diffHard,
        _ => NeonIconId.diffImpossible,
      };

  static NeonIconId place(int place) => place == 1
      ? NeonIconId.crown
      : place == 2
          ? NeonIconId.medal2
          : NeonIconId.medal3;

  static NeonIconId avatarItem(String id) => switch (id) {
        'av_cool' => NeonIconId.face,
        'av_robot' => NeonIconId.robot,
        'av_alien' => NeonIconId.alien,
        'av_rocket' => NeonIconId.rocket,
        'av_fox' => NeonIconId.fox,
        'av_skull' => NeonIconId.skull,
        'av_brain' => NeonIconId.spark,
        'av_dragon' => NeonIconId.flame,
        'av_unicorn' => NeonIconId.star,
        'av_crown' => NeonIconId.crown,
        'av_samurai' => NeonIconId.special,
        'av_ghost' => NeonIconId.spark,
        'av_astronaut' => NeonIconId.rocket,
        'av_lightning' => NeonIconId.xp,
        _ => NeonIconId.face,
      };

  static NeonIconId chatAvatar(String name) => switch (name) {
        'نئون‌مستر' => NeonIconId.alien,
        'سارا' => NeonIconId.star,
        'توفان' => NeonIconId.puCurve,
        'پیکسل' => NeonIconId.match,
        'کیان' => NeonIconId.fox,
        _ => NeonIconId.face,
      };

  static Color avatarColor(String seed) {
    int hash = 0;
    for (final int rune in seed.runes) {
      hash = (hash * 31 + rune) & 0x7fffffff;
    }
    const List<Color> pool = <Color>[
      Color(0xFF00E5FF),
      Color(0xFFFF2FD6),
      Color(0xFF7A2BFF),
      Color(0xFF38FFB0),
      Color(0xFFFFD54F),
    ];
    return pool[hash % pool.length];
  }
}

class NeonAvatar extends StatelessWidget {
  const NeonAvatar({
    super.key,
    required this.seed,
    this.icon,
    this.size = 44,
  });

  final String seed;
  final NeonIconId? icon;
  final double size;

  @override
  Widget build(BuildContext context) {
    final Color color = NeonIconResolver.avatarColor(seed);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[color.withAlpha(50), color.withAlpha(14)],
        ),
        shape: BoxShape.circle,
        border: Border.all(color: color.withAlpha(140), width: 1.6),
        boxShadow: <BoxShadow>[BoxShadow(color: color.withAlpha(50), blurRadius: 8)],
      ),
      child: Center(
        child: NeonIcon(
          icon ?? NeonIconResolver.chatAvatar(seed),
          size: size * 0.52,
          color: color,
        ),
      ),
    );
  }
}
