import 'package:flutter/material.dart';

import '../theme/neon_colors.dart';

enum NeonIconId {
  home, shop, rank, profile, chat,
  coin, level, match, win, lose, medal, items, winRate, xp,
  botMatch, friendMatch, online, diffEasy, diffMedium, diffHard, diffImpossible,
  paddle, ball, trail, arena, avatar, goalFx, buy, equipped, lock, owned, special,
  soundOn, soundOff, pause, play, replay, send, edit,
  gift, flag, chart, history, sliders, league, crown, medal2, medal3,
  face, robot, alien, rocket, fox, skull, spark, flame, star,
  puBig, puSmall, puMulti, puSlow, puFast, puShield,
  puGiantBall, puPaddleBoost, puFreeze, puCurve, puDoublePoint, puCoin,
}

/// مجموعه آیکن یکپارچه با ضخامت، Glow و قاب بصری ثابت.
class NeonIcon extends StatelessWidget {
  const NeonIcon(
    this.id, {
    super.key,
    this.size = 22,
    this.color = NeonColors.cyan,
    this.glow = 0.35,
  });

  final NeonIconId id;
  final double size;
  final Color color;
  final double glow;

  IconData get _data => switch (id) {
        NeonIconId.home => Icons.home_rounded,
        NeonIconId.shop => Icons.storefront_rounded,
        NeonIconId.rank => Icons.leaderboard_rounded,
        NeonIconId.profile => Icons.person_rounded,
        NeonIconId.chat => Icons.chat_bubble_rounded,
        NeonIconId.coin => Icons.monetization_on_rounded,
        NeonIconId.puCoin => Icons.monetization_on_rounded,
        NeonIconId.level => Icons.star_rounded,
        NeonIconId.star => Icons.star_rounded,
        NeonIconId.match => Icons.sports_esports_rounded,
        NeonIconId.win => Icons.emoji_events_rounded,
        NeonIconId.lose => Icons.close_rounded,
        NeonIconId.medal => Icons.workspace_premium_rounded,
        NeonIconId.medal2 => Icons.workspace_premium_rounded,
        NeonIconId.medal3 => Icons.workspace_premium_rounded,
        NeonIconId.items => Icons.inventory_2_rounded,
        NeonIconId.winRate => Icons.percent_rounded,
        NeonIconId.xp => Icons.bolt_rounded,
        NeonIconId.puFast => Icons.bolt_rounded,
        NeonIconId.botMatch => Icons.smart_toy_rounded,
        NeonIconId.robot => Icons.smart_toy_rounded,
        NeonIconId.friendMatch => Icons.group_rounded,
        NeonIconId.online => Icons.public_rounded,
        NeonIconId.diffEasy => Icons.sentiment_satisfied_rounded,
        NeonIconId.diffMedium => Icons.trending_up_rounded,
        NeonIconId.diffHard => Icons.local_fire_department_rounded,
        NeonIconId.flame => Icons.local_fire_department_rounded,
        NeonIconId.diffImpossible => Icons.dangerous_rounded,
        NeonIconId.skull => Icons.dangerous_rounded,
        NeonIconId.paddle => Icons.sports_tennis_rounded,
        NeonIconId.ball => Icons.circle_rounded,
        NeonIconId.puGiantBall => Icons.circle_rounded,
        NeonIconId.trail => Icons.blur_on_rounded,
        NeonIconId.arena => Icons.grid_4x4_rounded,
        NeonIconId.avatar => Icons.account_circle_rounded,
        NeonIconId.goalFx => Icons.auto_awesome_rounded,
        NeonIconId.spark => Icons.auto_awesome_rounded,
        NeonIconId.buy => Icons.shopping_cart_rounded,
        NeonIconId.equipped => Icons.check_circle_rounded,
        NeonIconId.lock => Icons.lock_rounded,
        NeonIconId.owned => Icons.verified_rounded,
        NeonIconId.special => Icons.diamond_rounded,
        NeonIconId.soundOn => Icons.volume_up_rounded,
        NeonIconId.soundOff => Icons.volume_off_rounded,
        NeonIconId.pause => Icons.pause_rounded,
        NeonIconId.play => Icons.play_arrow_rounded,
        NeonIconId.replay => Icons.replay_rounded,
        NeonIconId.send => Icons.send_rounded,
        NeonIconId.edit => Icons.edit_rounded,
        NeonIconId.gift => Icons.card_giftcard_rounded,
        NeonIconId.flag => Icons.flag_rounded,
        NeonIconId.chart => Icons.bar_chart_rounded,
        NeonIconId.history => Icons.history_rounded,
        NeonIconId.sliders => Icons.tune_rounded,
        NeonIconId.league => Icons.shield_rounded,
        NeonIconId.puShield => Icons.shield_rounded,
        NeonIconId.crown => Icons.emoji_events_rounded,
        NeonIconId.face => Icons.face_rounded,
        NeonIconId.alien => Icons.psychology_rounded,
        NeonIconId.rocket => Icons.rocket_launch_rounded,
        NeonIconId.fox => Icons.pets_rounded,
        NeonIconId.puBig => Icons.open_in_full_rounded,
        NeonIconId.puSmall => Icons.close_fullscreen_rounded,
        NeonIconId.puMulti => Icons.bubble_chart_rounded,
        NeonIconId.puSlow => Icons.hourglass_bottom_rounded,
        NeonIconId.puPaddleBoost => Icons.speed_rounded,
        NeonIconId.puFreeze => Icons.ac_unit_rounded,
        NeonIconId.puCurve => Icons.gesture_rounded,
        NeonIconId.puDoublePoint => Icons.filter_2_rounded,
      };

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox.square(
        dimension: size,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            if (glow > 0)
              Icon(
                _data,
                size: size + 2.2,
                color: NeonColors.a(color, glow * 0.34),
              ),
            Icon(_data, size: size, color: color),
          ],
        ),
      ),
    );
  }
}
