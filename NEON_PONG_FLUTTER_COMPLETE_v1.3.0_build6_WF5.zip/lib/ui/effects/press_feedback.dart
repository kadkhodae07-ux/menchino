import 'package:flutter/services.dart';

import '../../data/save_data.dart';
import '../../services/audio_feedback.dart';

/// بازخورد UI با سرویس صوتی موجود پروژه؛ بدون پکیج Native اضافه.
abstract class PressFeedback {
  static Future<void> tap({bool haptic = true, bool sound = true}) async {
    if (haptic) await HapticFeedback.selectionClick();
    if (sound && !SaveData.instance.muted) {
      await AudioFeedbackService.instance.play(FeedbackEvent.tap);
    }
  }
}
