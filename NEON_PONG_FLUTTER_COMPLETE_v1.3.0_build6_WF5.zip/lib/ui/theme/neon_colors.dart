import 'package:flutter/material.dart';

/// پالت مرکزی هویت نئونی — تنها منبع رنگ در کل UI.
abstract class NeonColors {
  static const Color bg = Color(0xFF05060F);
  static const Color surface = Color(0xFF0A0E20);
  static const Color surface2 = Color(0xFF10162E);
  static const Color surface3 = Color(0xFF182042);
  static const Color cyan = Color(0xFF00E5FF);
  static const Color pink = Color(0xFFFF2FD6);
  static const Color purple = Color(0xFF7A2BFF);
  static const Color green = Color(0xFF38FFB0);
  static const Color gold = Color(0xFFFFD54F);
  static const Color red = Color(0xFFFF5577);
  static const Color silver = Color(0xFFC8D7EB);
  static const Color bronze = Color(0xFFFF965A);
  static const Color text = Color(0xFFDFE8FF);
  static const Color dim = Color(0xFF8FA3C8);
  static const Color faint = Color(0xFF66739A);
  static const Color edge = Color(0xFF7C96FF);
  static const Color lipDark = Color(0xFF04050C);

  static Color a(Color color, double opacity) {
    final double safe = opacity.clamp(0.0, 1.0).toDouble();
    return color.withAlpha((safe * 255).round());
  }
}
