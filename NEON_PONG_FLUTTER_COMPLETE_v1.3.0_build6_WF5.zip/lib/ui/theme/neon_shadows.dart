import 'package:flutter/material.dart';

import 'neon_colors.dart';

/// سایه‌های جهت‌دار و Glow کنترل‌شده.
abstract class NeonShadows {
  static List<BoxShadow> lift(Color accent, [double glow = 0.14]) => <BoxShadow>[
        BoxShadow(color: Colors.black.withAlpha(150), blurRadius: 8, offset: const Offset(0, 5)),
        BoxShadow(color: NeonColors.a(accent, glow), blurRadius: 10, offset: const Offset(0, 2)),
      ];

  static List<BoxShadow> pressed() => <BoxShadow>[
        BoxShadow(color: Colors.black.withAlpha(130), blurRadius: 3, offset: const Offset(0, 1)),
      ];

  static List<BoxShadow> glow(Color color, [double opacity = 0.4]) => <BoxShadow>[
        BoxShadow(color: NeonColors.a(color, opacity), blurRadius: 12),
      ];
}
