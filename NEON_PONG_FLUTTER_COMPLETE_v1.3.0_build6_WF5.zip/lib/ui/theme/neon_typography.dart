import 'package:flutter/material.dart';

import 'neon_colors.dart';

abstract class NeonType {
  static const TextStyle page = TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: NeonColors.text, height: 1.5);
  static const TextStyle title = TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: NeonColors.text, height: 1.6);
  static const TextStyle stat = TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: NeonColors.cyan, height: 1.3);
  static const TextStyle score = TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: NeonColors.text, height: 1.2);
  static const TextStyle body = TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: NeonColors.text, height: 1.9);
  static const TextStyle label = TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: NeonColors.dim, height: 1.6);
  static const TextStyle tiny = TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: NeonColors.faint, height: 1.5);
  static const TextStyle btn = TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: NeonColors.text, height: 1.4);
  static const TextStyle btnSm = TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: NeonColors.text, height: 1.4);
}
