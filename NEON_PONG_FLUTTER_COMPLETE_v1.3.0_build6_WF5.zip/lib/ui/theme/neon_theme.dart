import 'package:flutter/material.dart';

import 'neon_colors.dart';

abstract class NeonTheme {
  static ThemeData build() => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: NeonColors.bg,
        splashFactory: NoSplash.splashFactory,
        highlightColor: Colors.transparent,
        colorScheme: const ColorScheme.dark(
          primary: NeonColors.cyan,
          secondary: NeonColors.pink,
          surface: NeonColors.surface,
          error: NeonColors.red,
        ),
        appBarTheme: const AppBarThemeData(
          backgroundColor: Colors.transparent,
          foregroundColor: NeonColors.text,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationThemeData(
          filled: true,
          fillColor: NeonColors.a(NeonColors.surface3, 0.58),
          hintStyle: const TextStyle(color: NeonColors.faint),
          labelStyle: const TextStyle(color: NeonColors.dim),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: NeonColors.a(NeonColors.edge, 0.24)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: NeonColors.a(NeonColors.edge, 0.22)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: NeonColors.cyan, width: 1.2),
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: NeonColors.surface2,
          contentTextStyle: const TextStyle(color: NeonColors.text, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: NeonColors.cyan, width: 1),
          ),
        ),
        dialogTheme: DialogThemeData(
          backgroundColor: NeonColors.surface2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: BorderSide(color: NeonColors.a(NeonColors.cyan, 0.35), width: 1),
          ),
        ),
      );
}
