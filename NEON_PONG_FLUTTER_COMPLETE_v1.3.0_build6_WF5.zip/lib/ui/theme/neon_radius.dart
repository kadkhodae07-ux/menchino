import 'package:flutter/material.dart';

abstract class NeonRadius {
  static const double sm = 10;
  static const double md = 14;
  static const double lg = 18;
  static const double xl = 24;
  static const double pill = 999;

  static BorderRadius r(double value) => BorderRadius.circular(value);
}
