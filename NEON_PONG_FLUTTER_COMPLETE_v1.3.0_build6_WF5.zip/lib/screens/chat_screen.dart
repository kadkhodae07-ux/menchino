import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../data/chat_data.dart';
import '../data/save_data.dart';
import '../services/audio_feedback.dart';
import '../ui/components/neon_badge.dart';
import '../ui/components/neon_panel.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/icons/neon_icon_resolver.dart';
import '../ui/resolvers/neon_format.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_radius.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';
import '../widgets/pressable_surface.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, this.embedded = false});

  final bool embedded;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final Random _random = Random();
  Timer? _timer;
  int _online = 27;

  @override
  void initState() {
    super.initState();
    _scheduleBot();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scheduleBot() {
    _timer?.cancel();
    _timer = Timer(Duration(seconds: 9 + _random.nextInt(10)), () {
      if (!mounted) return;
      final ChatBot bot = chatBots[_random.nextInt(chatBots.length)];
      SaveData.instance.appendChat(
        StoredChatMessage(
          name: bot.name,
          emoji: bot.emoji,
          text: chatLines[_random.nextInt(chatLines.length)],
        ),
      );
      setState(() => _online = 18 + _random.nextInt(29));
      _scroll();
      _scheduleBot();
    });
  }

  void _send() {
    final String text = _controller.text.trim();
    if (text.isEmpty) return;
    final SaveData save = SaveData.instance;
    save.appendChat(
      StoredChatMessage(
        name: save.name,
        emoji: save.avatarEmoji,
        text: text,
        isMe: true,
      ),
    );
    AudioFeedbackService.instance.play(FeedbackEvent.send);
    _controller.clear();
    _scroll();
    Future<void>.delayed(Duration(milliseconds: 1200 + _random.nextInt(1600)), () {
      if (!mounted) return;
      final ChatBot bot = chatBots[_random.nextInt(chatBots.length)];
      SaveData.instance.appendChat(
        StoredChatMessage(
          name: bot.name,
          emoji: bot.emoji,
          text: chatReplies[_random.nextInt(chatReplies.length)],
        ),
      );
      _scroll();
    });
  }

  void _scroll() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      bottom: false,
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) => Padding(
          padding: EdgeInsets.only(
            bottom: widget.embedded ? NeonSpacing.navClearance - 4 : 12,
          ),
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
                child: Row(
                  children: <Widget>[
                    const NeonIcon(NeonIconId.chat, size: 22),
                    const SizedBox(width: NeonSpacing.sm),
                    Expanded(child: Text('چت سراسری', style: NeonType.page)),
                    NeonBadge(
                      icon: NeonIconId.online,
                      text: '${NeonFormat.fa(_online)} آنلاین',
                      accent: NeonColors.green,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  itemCount: save.chatMessages.length,
                  itemBuilder: (BuildContext context, int index) =>
                      _bubble(save, save.chatMessages[index]),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                child: NeonPanel(
                  accent: NeonColors.cyan,
                  padding: const EdgeInsets.all(8),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          maxLength: 120,
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _send(),
                          decoration: const InputDecoration(
                            counterText: '',
                            hintText: 'پیامت رو بنویس...',
                            isDense: true,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      SizedBox.square(
                        dimension: 50,
                        child: PressableSurface(
                          accent: NeonColors.cyan,
                          radius: NeonRadius.md,
                          lip: 5,
                          padding: EdgeInsets.zero,
                          playTapSound: false,
                          onTap: _send,
                          fill: const LinearGradient(
                            colors: <Color>[Color(0xFF7FF3FF), NeonColors.cyan],
                          ),
                          child: const Center(
                            child: NeonIcon(
                              NeonIconId.send,
                              size: 22,
                              color: Color(0xFF031018),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bubble(SaveData save, StoredChatMessage message) {
    final Color accent = message.isMe ? NeonColors.cyan : NeonColors.purple;
    final NeonIconId icon = message.isMe
        ? NeonIconResolver.avatarItem(save.selected['avatar'] ?? 'av_cool')
        : NeonIconResolver.chatAvatar(message.name);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: message.isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (!message.isMe) ...<Widget>[
            NeonAvatar(seed: message.name, icon: icon, size: 38),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment:
                  message.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: <Widget>[
                Text(message.isMe ? 'تو' : message.name, style: NeonType.tiny),
                const SizedBox(height: 3),
                NeonPanel(
                  accent: accent,
                  radius: NeonRadius.md,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Text(message.text, style: NeonType.body.copyWith(height: 1.65)),
                ),
              ],
            ),
          ),
          if (message.isMe) ...<Widget>[
            const SizedBox(width: 8),
            NeonAvatar(seed: save.name, icon: icon, size: 38),
          ],
        ],
      ),
    );
  }
}
