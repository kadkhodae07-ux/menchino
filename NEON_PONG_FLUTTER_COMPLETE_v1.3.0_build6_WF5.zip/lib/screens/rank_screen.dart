import 'package:flutter/material.dart';

import '../data/rank_data.dart';
import '../data/save_data.dart';
import '../ui/components/neon_badge.dart';
import '../ui/components/neon_panel.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/icons/neon_icon_resolver.dart';
import '../ui/resolvers/neon_format.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';

class RankScreen extends StatelessWidget {
  const RankScreen({super.key, this.embedded = false});

  final bool embedded;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      bottom: false,
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) {
          final List<_RankEntry> players = <_RankEntry>[
            ...rankBots.map(
              (RankBot bot) => _RankEntry(
                name: bot.name,
                points: bot.points,
                icon: NeonIconResolver.chatAvatar(bot.name),
              ),
            ),
            _RankEntry(
              name: save.name,
              points: save.points,
              isMe: true,
              icon: NeonIconResolver.avatarItem(save.selected['avatar'] ?? 'av_cool'),
            ),
          ]..sort((_RankEntry a, _RankEntry b) => b.points.compareTo(a.points));
          final int myIndex = players.indexWhere((_RankEntry player) => player.isMe);
          final int pointsNeeded = myIndex > 0
              ? players[myIndex - 1].points - save.points + 1
              : 0;

          return ListView(
            padding: EdgeInsets.fromLTRB(
              14,
              12,
              14,
              embedded ? NeonSpacing.navClearance : 18,
            ),
            children: <Widget>[
              Row(
                children: <Widget>[
                  const NeonIcon(NeonIconId.rank, size: 23, color: NeonColors.gold),
                  const SizedBox(width: NeonSpacing.sm),
                  Expanded(child: Text('رتبه‌بندی', style: NeonType.page)),
                  const NeonBadge(
                    icon: NeonIconId.league,
                    text: 'فصل ۱',
                    accent: NeonColors.purple,
                  ),
                ],
              ),
              const SizedBox(height: NeonSpacing.md),
              _season(),
              const SizedBox(height: NeonSpacing.md),
              _myRank(save, myIndex + 1, players.length, pointsNeeded),
              const SizedBox(height: NeonSpacing.lg),
              _podium(players),
              const SizedBox(height: NeonSpacing.md),
              ...List<Widget>.generate(
                players.length - 3,
                (int index) => _rankRow(players[index + 3], index + 4),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _season() => NeonPanel(
        accent: NeonColors.purple,
        icon: NeonIconId.league,
        title: 'لیگ نئونی — فصل ۱',
        dense: true,
        child: Text(
          'هر برد ۳۰+ امتیاز • هر باخت ۱۰- امتیاز',
          textAlign: TextAlign.center,
          style: NeonType.label,
        ),
      );

  Widget _myRank(SaveData save, int rank, int total, int pointsNeeded) => NeonPanel(
        accent: NeonColors.cyan,
        icon: NeonIconId.medal,
        title: 'جایگاه تو',
        trailing: NeonBadge(
          text: '${NeonFormat.fa(rank)} از ${NeonFormat.fa(total)}',
          accent: NeonColors.cyan,
        ),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                NeonAvatar(
                  seed: save.name,
                  icon: NeonIconResolver.avatarItem(save.selected['avatar'] ?? 'av_cool'),
                  size: 54,
                ),
                const SizedBox(width: NeonSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(save.name, style: NeonType.title),
                      Text(
                        '${NeonFormat.fa(save.points)} امتیاز لیگ',
                        style: NeonType.label,
                      ),
                    ],
                  ),
                ),
                NeonIcon(
                  rank == 1 ? NeonIconId.crown : NeonIconId.chart,
                  size: 30,
                  color: rank == 1 ? NeonColors.gold : NeonColors.cyan,
                ),
              ],
            ),
            const SizedBox(height: NeonSpacing.md),
            NeonBadge(
              icon: rank == 1 ? NeonIconId.crown : NeonIconId.xp,
              text: rank == 1
                  ? 'صدرنشین لیگی!'
                  : 'تا رتبه ${NeonFormat.fa(rank - 1)} فقط ${NeonFormat.fa(pointsNeeded)} امتیاز',
              accent: rank == 1 ? NeonColors.gold : NeonColors.cyan,
              filled: true,
            ),
          ],
        ),
      );

  Widget _podium(List<_RankEntry> players) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Expanded(child: _podiumItem(players[1], 2)),
          const SizedBox(width: 8),
          Expanded(child: _podiumItem(players[0], 1)),
          const SizedBox(width: 8),
          Expanded(child: _podiumItem(players[2], 3)),
        ],
      );

  Widget _podiumItem(_RankEntry player, int place) {
    final Color color = place == 1
        ? NeonColors.gold
        : place == 2
            ? NeonColors.silver
            : NeonColors.bronze;
    return Transform.translate(
      offset: Offset(0, place == 1 ? -8 : 0),
      child: NeonPanel(
        accent: color,
        padding: EdgeInsets.fromLTRB(7, place == 1 ? 20 : 13, 7, 13),
        child: Column(
          children: <Widget>[
            NeonIcon(NeonIconResolver.place(place), size: 24, color: color),
            const SizedBox(height: 6),
            NeonAvatar(seed: player.name, icon: player.icon, size: place == 1 ? 50 : 44),
            const SizedBox(height: 7),
            Text(
              '${player.name}${player.isMe ? ' (تو)' : ''}',
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: NeonType.btnSm,
            ),
            Text(
              '${NeonFormat.fa(player.points)} امتیاز',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: NeonType.tiny.copyWith(color: color),
            ),
          ],
        ),
      ),
    );
  }

  Widget _rankRow(_RankEntry player, int rank) {
    final Color accent = player.isMe ? NeonColors.cyan : NeonColors.edge;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: NeonPanel(
        accent: accent,
        dense: true,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: <Widget>[
            NeonBadge(
              text: NeonFormat.fa(rank),
              accent: player.isMe ? NeonColors.cyan : NeonColors.dim,
            ),
            const SizedBox(width: 10),
            NeonAvatar(seed: player.name, icon: player.icon, size: 36),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '${player.name}${player.isMe ? ' • تو' : ''}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: NeonType.btnSm.copyWith(
                  color: player.isMe ? NeonColors.cyan : NeonColors.text,
                ),
              ),
            ),
            Text(
              NeonFormat.fa(player.points),
              style: NeonType.btn.copyWith(color: accent),
            ),
          ],
        ),
      ),
    );
  }
}

class _RankEntry {
  const _RankEntry({
    required this.name,
    required this.points,
    required this.icon,
    this.isMe = false,
  });

  final String name;
  final int points;
  final NeonIconId icon;
  final bool isMe;
}
