import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../data/save_data.dart';
import '../game/game_engine.dart';
import '../game/pong_painter.dart';
import '../services/audio_feedback.dart';
import '../ui/components/neon_badge.dart';
import '../ui/components/neon_button.dart';
import '../ui/components/neon_panel.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/icons/neon_icon_resolver.dart';
import '../ui/resolvers/neon_format.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_radius.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';
import '../widgets/pressable_surface.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({
    super.key,
    required this.mode,
    this.difficulty = 1,
  });

  final GameMode mode;
  final int difficulty;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late final GameEngine _engine;
  late final Ticker _ticker;
  final FocusNode _focusNode = FocusNode();
  final Map<int, bool> _pointerSides = <int, bool>{};
  Duration? _lastElapsed;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    _engine = GameEngine(save: SaveData.instance, onEvent: _handleEvent);
    _ticker = createTicker(_tick)..start();
    _enterGameMode();
    WidgetsBinding.instance.addPostFrameCallback((_) => _focusNode.requestFocus());
  }

  Future<void> _enterGameMode() async {
    await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _engine.dispose();
    _focusNode.dispose();
    SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _tick(Duration elapsed) {
    if (_lastElapsed == null) {
      _lastElapsed = elapsed;
      return;
    }
    final double delta = (elapsed - _lastElapsed!).inMicroseconds / 1000000;
    _lastElapsed = elapsed;
    _engine.update(delta);
  }

  void _handleEvent(GameEvent event) {
    final AudioFeedbackService audio = AudioFeedbackService.instance;
    switch (event) {
      case GameEvent.launch:
        audio.play(FeedbackEvent.launch);
        break;
      case GameEvent.paddleHit:
        audio.play(FeedbackEvent.paddle);
        break;
      case GameEvent.wallHit:
        audio.play(FeedbackEvent.wall);
        break;
      case GameEvent.playerPoint:
        audio.play(FeedbackEvent.score);
        break;
      case GameEvent.opponentPoint:
        audio.play(FeedbackEvent.losePoint);
        break;
      case GameEvent.pickup:
        audio.play(FeedbackEvent.pickup);
        break;
      case GameEvent.shield:
        audio.play(FeedbackEvent.shield);
        break;
      case GameEvent.win:
        audio.play(FeedbackEvent.win);
        break;
      case GameEvent.lose:
        audio.play(FeedbackEvent.lose);
        break;
    }
  }

  void _handlePointer(PointerEvent event) {
    final bool left = _pointerSides[event.pointer] ??
        (event.localPosition.dx < _engine.viewport.width / 2);
    _pointerSides[event.pointer] = left;
    if (widget.mode == GameMode.friend) {
      if (left) {
        _engine.movePlayer(event.localPosition.dy);
      } else {
        _engine.moveOpponent(event.localPosition.dy);
      }
    } else {
      _engine.movePlayer(event.localPosition.dy);
    }
  }

  void _key(KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) return;
    const double step = 45;
    switch (event.logicalKey) {
      case LogicalKeyboardKey.keyW:
        _engine.nudgePlayer(-step);
        break;
      case LogicalKeyboardKey.keyS:
        _engine.nudgePlayer(step);
        break;
      case LogicalKeyboardKey.arrowUp:
        if (widget.mode == GameMode.friend) {
          _engine.nudgeOpponent(-step);
        } else {
          _engine.nudgePlayer(-step);
        }
        break;
      case LogicalKeyboardKey.arrowDown:
        if (widget.mode == GameMode.friend) {
          _engine.nudgeOpponent(step);
        } else {
          _engine.nudgePlayer(step);
        }
        break;
      case LogicalKeyboardKey.keyP:
      case LogicalKeyboardKey.escape:
        _engine.togglePause();
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_engine.state == GameState.over) return true;
        if (_engine.state == GameState.pause) return _confirmExit();
        if (_engine.state == GameState.play || _engine.state == GameState.serve) {
          _engine.togglePause();
        }
        return false;
      },
      child: Scaffold(
        backgroundColor: NeonColors.bg,
        body: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            _engine.setSize(constraints.maxWidth, constraints.maxHeight);
            if (!_started && constraints.maxWidth > 0 && constraints.maxHeight > 0) {
              _started = true;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _engine.startMatch(
                  gameMode: widget.mode,
                  diff: widget.difficulty,
                );
              });
            }
            return KeyboardListener(
              focusNode: _focusNode,
              onKeyEvent: _key,
              child: AnimatedBuilder(
                animation: _engine,
                builder: (BuildContext context, Widget? child) => Stack(
                  fit: StackFit.expand,
                  children: <Widget>[
                    Listener(
                      behavior: HitTestBehavior.opaque,
                      onPointerDown: _handlePointer,
                      onPointerMove: _handlePointer,
                      onPointerUp: (PointerUpEvent event) =>
                          _pointerSides.remove(event.pointer),
                      onPointerCancel: (PointerCancelEvent event) =>
                          _pointerSides.remove(event.pointer),
                      child: CustomPaint(
                        painter: PongPainter(_engine, SaveData.instance),
                      ),
                    ),
                    Positioned(
                      top: 12,
                      right: 12,
                      child: _roundButton(
                        icon: _engine.state == GameState.pause
                            ? NeonIconId.play
                            : NeonIconId.pause,
                        accent: NeonColors.cyan,
                        onTap: _engine.togglePause,
                      ),
                    ),
                    Positioned(
                      top: 12,
                      left: 12,
                      child: _roundButton(
                        icon: SaveData.instance.muted
                            ? NeonIconId.soundOff
                            : NeonIconId.soundOn,
                        accent: SaveData.instance.muted
                            ? NeonColors.red
                            : NeonColors.green,
                        onTap: () async {
                          await SaveData.instance.setMuted(!SaveData.instance.muted);
                          if (mounted) setState(() {});
                        },
                      ),
                    ),
                    _playerHudStrip(),
                    if (_engine.activeEffects.isNotEmpty || _engine.shieldActive)
                      _effectChips(),
                    if (_engine.state == GameState.pause) _pauseOverlay(),
                    if (_engine.state == GameState.over) _gameOverOverlay(),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _roundButton({
    required NeonIconId icon,
    required Color accent,
    required VoidCallback onTap,
  }) => SizedBox.square(
        dimension: 50,
        child: PressableSurface(
          onTap: onTap,
          accent: accent,
          radius: NeonRadius.pill,
          lip: 5,
          padding: EdgeInsets.zero,
          child: Center(child: NeonIcon(icon, size: 22, color: accent)),
        ),
      );

  Widget _playerHudStrip() => Positioned(
        top: 13,
        left: 72,
        right: 72,
        child: IgnorePointer(
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                _playerChip(
                  icon: NeonIconResolver.avatarItem(
                    SaveData.instance.selected['avatar'] ?? 'av_cool',
                  ),
                  name: widget.mode == GameMode.friend ? 'بازیکن ۱' : 'تو',
                  accent: NeonColors.cyan,
                  score: _engine.scorePlayer,
                  leftSide: true,
                ),
                _playerChip(
                  icon: widget.mode == GameMode.bot
                      ? NeonIconId.robot
                      : NeonIconId.match,
                  name: widget.mode == GameMode.bot ? 'ربات' : 'بازیکن ۲',
                  accent: NeonColors.pink,
                  score: _engine.scoreOpponent,
                  leftSide: false,
                ),
              ],
            ),
          ),
        ),
      );

  Widget _playerChip({
    required NeonIconId icon,
    required String name,
    required Color accent,
    required int score,
    required bool leftSide,
  }) => Directionality(
        textDirection: TextDirection.rtl,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 166),
          child: NeonPanel(
            accent: accent,
            radius: NeonRadius.lg,
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                if (!leftSide) ...<Widget>[
                  _scoreBubble(score, accent),
                  const SizedBox(width: 7),
                ],
                NeonAvatar(seed: name, icon: icon, size: 34),
                const SizedBox(width: 7),
                Flexible(
                  child: Column(
                    crossAxisAlignment:
                        leftSide ? CrossAxisAlignment.start : CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: NeonType.btnSm,
                      ),
                      const SizedBox(height: 3),
                      Container(
                        width: 42,
                        height: 4,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: <Color>[accent, NeonColors.a(accent, 0.2)],
                          ),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ],
                  ),
                ),
                if (leftSide) ...<Widget>[
                  const SizedBox(width: 7),
                  _scoreBubble(score, accent),
                ],
              ],
            ),
          ),
        ),
      );

  Widget _scoreBubble(int value, Color accent) => NeonBadge(
        text: NeonFormat.fa(value),
        accent: accent,
        filled: true,
        size: 14,
      );

  Widget _effectChips() => Positioned(
        top: 72,
        left: 12,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ..._engine.activeEffects.map((ActiveEffect effect) {
              final FieldPowerUp data = effect.descriptor;
              return Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: NeonBadge(
                  icon: NeonIconResolver.powerUp(effect.type),
                  text:
                      '${data.name} • ${NeonFormat.fa(effect.remaining.ceil())} ثانیه',
                  accent: data.color,
                  filled: true,
                ),
              );
            }),
            if (_engine.shieldActive)
              const NeonBadge(
                icon: NeonIconId.puShield,
                text: 'سپر فعال',
                accent: NeonColors.purple,
                filled: true,
              ),
          ],
        ),
      );

  Widget _pauseOverlay() => _overlay(
        accent: NeonColors.cyan,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const NeonIcon(NeonIconId.pause, size: 42),
            const SizedBox(height: 8),
            Text('بازی متوقف شد', style: NeonType.page),
            const SizedBox(height: NeonSpacing.lg),
            NeonButton(
              expanded: true,
              big: true,
              icon: NeonIconId.play,
              label: 'ادامه بازی',
              onPressed: _engine.togglePause,
            ),
            const SizedBox(height: NeonSpacing.sm),
            NeonButton(
              expanded: true,
              kind: NeonButtonKind.danger,
              icon: NeonIconId.home,
              label: 'خروج به خانه',
              onPressed: () async {
                if (await _confirmExit() && mounted) Navigator.pop(context);
              },
            ),
          ],
        ),
      );

  Widget _gameOverOverlay() {
    final MatchResult? result = _engine.result;
    final bool won = result?.won ?? false;
    final String title = widget.mode == GameMode.bot
        ? (won ? 'برنده شدی!' : 'ربات برنده شد!')
        : (won ? 'بازیکن ۱ برنده شد!' : 'بازیکن ۲ برنده شد!');
    final Color accent = won || widget.mode == GameMode.friend
        ? NeonColors.green
        : NeonColors.red;
    return _overlay(
      accent: accent,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          NeonIcon(won ? NeonIconId.crown : NeonIconId.lose, size: 44, color: accent),
          const SizedBox(height: 8),
          Text(
            title,
            textAlign: TextAlign.center,
            style: NeonType.page.copyWith(color: accent, fontSize: 28),
          ),
          const SizedBox(height: 6),
          Text(
            'نتیجه: ${NeonFormat.fa(_engine.scorePlayer)} — ${NeonFormat.fa(_engine.scoreOpponent)}',
            style: NeonType.label.copyWith(fontSize: 14),
          ),
          if (result != null) ...<Widget>[
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: <Widget>[
                NeonBadge(
                  icon: NeonIconId.coin,
                  text: '+${NeonFormat.fa(result.reward.coins)}',
                  accent: NeonColors.gold,
                  filled: true,
                ),
                NeonBadge(
                  icon: NeonIconId.xp,
                  text: '+${NeonFormat.fa(result.reward.xp)} تجربه',
                  accent: NeonColors.cyan,
                  filled: true,
                ),
              ],
            ),
          ],
          const SizedBox(height: NeonSpacing.lg),
          NeonButton(
            expanded: true,
            big: true,
            icon: NeonIconId.replay,
            label: 'بازی دوباره',
            onPressed: () => _engine.startMatch(
              gameMode: widget.mode,
              diff: widget.difficulty,
            ),
          ),
          const SizedBox(height: NeonSpacing.sm),
          NeonButton(
            expanded: true,
            kind: NeonButtonKind.ghost,
            icon: NeonIconId.home,
            label: 'بازگشت به خانه',
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  Widget _overlay({required Color accent, required Widget child}) => Container(
        color: const Color(0xC0040612),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: NeonPanel(
                accent: accent,
                radius: NeonRadius.xl,
                padding: const EdgeInsets.all(24),
                child: child,
              ),
            ),
          ),
        ),
      );

  Future<bool> _confirmExit() async {
    final bool? result = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Row(
          children: <Widget>[
            const NeonIcon(NeonIconId.home, size: 21, color: NeonColors.red),
            const SizedBox(width: 8),
            Text('خروج از مسابقه؟', style: NeonType.title),
          ],
        ),
        content: Text(
          'امتیاز این مسابقه ذخیره نمی‌شود.',
          style: NeonType.body.copyWith(color: NeonColors.dim),
        ),
        actions: <Widget>[
          NeonButton(
            kind: NeonButtonKind.ghost,
            label: 'ادامه بازی',
            onPressed: () => Navigator.pop(dialogContext, false),
          ),
          NeonButton(
            kind: NeonButtonKind.danger,
            label: 'خروج',
            onPressed: () => Navigator.pop(dialogContext, true),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}
