import 'package:flutter/material.dart';

import '../data/shop_items.dart';
import '../ui/backgrounds/neon_background.dart';
import '../ui/components/neon_surface.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_typography.dart';
import '../widgets/pressable_surface.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'shop_screen.dart';

/// پنل کنترل پایین با ترتیب ثابت: فروشگاه، رتبه، خانه، پروفایل، چت.
class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _index = 2;
  final ValueNotifier<ItemCategory> _shopCategory =
      ValueNotifier<ItemCategory>(ItemCategory.paddle);

  static const List<_Destination> _destinations = <_Destination>[
    _Destination(NeonIconId.shop, 'فروشگاه'),
    _Destination(NeonIconId.rank, 'رتبه'),
    _Destination(NeonIconId.home, 'خانه'),
    _Destination(NeonIconId.profile, 'پروفایل'),
    _Destination(NeonIconId.chat, 'چت'),
  ];

  @override
  void dispose() {
    _shopCategory.dispose();
    super.dispose();
  }

  void _go(int index) {
    if (_index == index) return;
    setState(() => _index = index);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: NeonColors.bg,
        body: NeonBackground(
          child: Stack(
            children: <Widget>[
              Positioned.fill(
                child: IndexedStack(
                  index: _index,
                  children: <Widget>[
                    ShopScreen(
                      embedded: true,
                      categoryController: _shopCategory,
                    ),
                    const RankScreen(embedded: true),
                    HomeScreen(
                      embedded: true,
                      onOpenShop: () => _go(0),
                      onOpenProfile: () => _go(3),
                    ),
                    ProfileScreen(
                      embedded: true,
                      onOpenShop: () => _go(0),
                      onOpenCategory: (ItemCategory category) {
                        _shopCategory.value = category;
                        _go(0);
                      },
                    ),
                    const ChatScreen(embedded: true),
                  ],
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 480),
                        child: RepaintBoundary(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                            decoration: NeonSurface.box(
                              accent: NeonColors.cyan,
                              radius: 26,
                              glow: 0.18,
                            ),
                            child: Stack(
                              clipBehavior: Clip.none,
                              alignment: Alignment.center,
                              children: <Widget>[
                                NeonSurface.topHighlight(26),
                                Row(
                                  children: List<Widget>.generate(
                                    _destinations.length,
                                    (int index) => _navItem(index),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );

  Widget _navItem(int index) {
    final _Destination destination = _destinations[index];
    final bool isHome = index == 2;
    final bool selected = _index == index;
    if (isHome) {
      return Expanded(
        child: Transform.translate(
          offset: const Offset(0, -14),
          child: Center(
            child: SizedBox.square(
              dimension: 58,
              child: PressableSurface(
                accent: NeonColors.purple,
                radius: 999,
                lip: 5,
                selected: selected,
                padding: EdgeInsets.zero,
                onTap: () => _go(index),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: selected
                          ? const <Color>[
                              Color(0xFF8FF7FF),
                              NeonColors.cyan,
                              NeonColors.purple,
                            ]
                          : <Color>[
                              NeonColors.a(NeonColors.cyan, 0.7),
                              NeonColors.purple,
                            ],
                    ),
                    border: Border.all(color: NeonColors.lipDark, width: 3),
                  ),
                  child: const Center(
                    child: NeonIcon(
                      NeonIconId.home,
                      size: 25,
                      color: Color(0xFF031018),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: PressableSurface(
          accent: NeonColors.cyan,
          radius: 16,
          lip: 4,
          selected: selected,
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 2),
          onTap: () => _go(index),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              NeonIcon(
                destination.icon,
                size: 20,
                color: selected ? NeonColors.cyan : NeonColors.faint,
                glow: selected ? 0.6 : 0.1,
              ),
              const SizedBox(height: 2),
              Text(
                destination.label,
                style: NeonType.tiny.copyWith(
                  color: selected ? NeonColors.text : NeonColors.faint,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Destination {
  const _Destination(this.icon, this.label);

  final NeonIconId icon;
  final String label;
}
