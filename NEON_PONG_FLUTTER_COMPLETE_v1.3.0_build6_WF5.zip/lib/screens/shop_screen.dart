import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../services/audio_feedback.dart';
import '../ui/components/neon_badge.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/icons/neon_icon_resolver.dart';
import '../ui/resolvers/neon_format.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_radius.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';
import '../widgets/pressable_surface.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({
    super.key,
    this.embedded = false,
    this.initialCategory,
    this.categoryController,
  });

  final bool embedded;
  final ItemCategory? initialCategory;
  final ValueNotifier<ItemCategory>? categoryController;

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  late ItemCategory _category = widget.initialCategory ??
      widget.categoryController?.value ??
      ItemCategory.paddle;

  @override
  void initState() {
    super.initState();
    widget.categoryController?.addListener(_syncCategory);
  }

  @override
  void didUpdateWidget(covariant ShopScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.categoryController != widget.categoryController) {
      oldWidget.categoryController?.removeListener(_syncCategory);
      widget.categoryController?.addListener(_syncCategory);
      _syncCategory();
    }
  }

  @override
  void dispose() {
    widget.categoryController?.removeListener(_syncCategory);
    super.dispose();
  }

  void _syncCategory() {
    final ItemCategory? next = widget.categoryController?.value;
    if (next == null || next == _category || !mounted) return;
    setState(() => _category = next);
  }

  static const Map<ItemCategory, Color> _accents = <ItemCategory, Color>{
    ItemCategory.paddle: NeonColors.cyan,
    ItemCategory.ball: NeonColors.silver,
    ItemCategory.trail: NeonColors.purple,
    ItemCategory.theme: NeonColors.pink,
    ItemCategory.avatar: NeonColors.green,
    ItemCategory.boom: NeonColors.gold,
  };

  static const Map<ItemCategory, String> _labels = <ItemCategory, String>{
    ItemCategory.paddle: 'راکت‌ها',
    ItemCategory.ball: 'توپ‌ها',
    ItemCategory.trail: 'دنباله‌ها',
    ItemCategory.theme: 'زمین‌ها',
    ItemCategory.avatar: 'آواتارها',
    ItemCategory.boom: 'افکت گل',
  };

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      bottom: false,
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) {
          final List<ShopItem> visible = shopItems
              .where((ShopItem item) => item.category == _category)
              .toList(growable: false);
          return Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
                child: Row(
                  children: <Widget>[
                    const NeonIcon(NeonIconId.shop, size: 22),
                    const SizedBox(width: NeonSpacing.sm),
                    Expanded(child: Text('فروشگاه', style: NeonType.page)),
                    NeonBadge(
                      icon: NeonIconId.coin,
                      text: NeonFormat.fa(save.coins),
                      accent: NeonColors.gold,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 50,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  children: ItemCategory.values.map((ItemCategory category) {
                    final bool selected = _category == category;
                    final Color accent = _accents[category]!;
                    return Padding(
                      padding: const EdgeInsets.only(left: NeonSpacing.sm),
                      child: PressableSurface(
                        accent: accent,
                        radius: NeonRadius.pill,
                        lip: 4,
                        selected: selected,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                        onTap: () {
                          final ValueNotifier<ItemCategory>? controller =
                              widget.categoryController;
                          if (controller != null) {
                            controller.value = category;
                          } else {
                            setState(() => _category = category);
                          }
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            NeonIcon(
                              NeonIconResolver.category(category),
                              size: 16,
                              color: selected ? accent : NeonColors.faint,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _labels[category]!,
                              style: NeonType.btnSm.copyWith(
                                color: selected ? NeonColors.text : NeonColors.dim,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: EdgeInsets.fromLTRB(
                    14,
                    8,
                    14,
                    widget.embedded ? NeonSpacing.navClearance : 18,
                  ),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 180,
                    childAspectRatio: 0.72,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: visible.length,
                  itemBuilder: (BuildContext context, int index) => _card(
                    context,
                    save,
                    visible[index],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _card(BuildContext context, SaveData save, ShopItem item) {
    final bool owned = save.owned.contains(item.id);
    final bool selected = save.selected[categoryKeys[item.category]] == item.id;
    final bool affordable = save.coins >= item.price;
    final Color accent = _accents[item.category]!;

    return PressableSurface(
      accent: accent,
      radius: NeonRadius.lg,
      lip: 6,
      selected: selected,
      locked: !owned && !affordable,
      padding: const EdgeInsets.all(NeonSpacing.md - 2),
      onTap: selected
          ? null
          : () async {
              if (owned) {
                await save.select(item);
                AudioFeedbackService.instance.play(FeedbackEvent.select);
                if (context.mounted) _message(context, '${item.name} تجهیز شد');
                return;
              }
              final bool purchased = await save.buy(item);
              if (!context.mounted) return;
              if (purchased) {
                AudioFeedbackService.instance.play(FeedbackEvent.buy);
                _message(context, '${item.name} خریداری و تجهیز شد');
              } else {
                AudioFeedbackService.instance.play(FeedbackEvent.error);
                _message(context, 'سکه کافی نیست');
              }
            },
      child: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: NeonColors.a(NeonColors.lipDark, 0.6),
                borderRadius: NeonRadius.r(NeonRadius.md),
                border: Border.all(color: NeonColors.a(accent, 0.2)),
              ),
              child: Center(child: _preview(item, accent)),
            ),
          ),
          const SizedBox(height: NeonSpacing.sm),
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  item.name,
                  style: NeonType.btnSm.copyWith(color: NeonColors.text),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                NeonFormat.tier(item.price),
                style: NeonType.tiny.copyWith(color: accent),
              ),
            ],
          ),
          const SizedBox(height: NeonSpacing.xs + 2),
          if (selected)
            const NeonBadge(
              icon: NeonIconId.equipped,
              text: 'مجهز',
              accent: NeonColors.green,
            )
          else if (owned)
            const NeonBadge(
              icon: NeonIconId.sliders,
              text: 'تجهیز',
              accent: NeonColors.cyan,
            )
          else
            NeonBadge(
              icon: NeonIconId.coin,
              text: NeonFormat.fa(item.price),
              accent: affordable ? NeonColors.gold : NeonColors.faint,
            ),
        ],
      ),
    );
  }

  Widget _preview(ShopItem item, Color accent) {
    switch (item.category) {
      case ItemCategory.paddle:
        final Color first = item.color1 ?? accent;
        final Color second = item.color2 ?? NeonColors.cyan;
        return Container(
          width: 16,
          height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            gradient: item.rainbow
                ? const LinearGradient(
                    colors: <Color>[
                      Colors.red,
                      Colors.orange,
                      Colors.yellow,
                      Colors.green,
                      Colors.blue,
                      Colors.purple,
                    ],
                  )
                : LinearGradient(colors: <Color>[first, Colors.white, second]),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: NeonColors.a(item.rainbow ? Colors.purple : first, 0.5),
                blurRadius: 10,
              ),
            ],
          ),
        );
      case ItemCategory.ball:
        final Color first = item.color1 ?? Colors.white;
        final Color second = item.color2 ?? accent;
        return Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: item.rainbow
                ? const RadialGradient(
                    colors: <Color>[Colors.white, Colors.purple, Colors.cyan],
                  )
                : RadialGradient(
                    center: const Alignment(-0.3, -0.3),
                    colors: <Color>[first, second],
                  ),
            boxShadow: <BoxShadow>[
              BoxShadow(color: NeonColors.a(second, 0.55), blurRadius: 12),
            ],
          ),
        );
      case ItemCategory.trail:
        if (item.color1 == null) {
          return Container(
            width: 68,
            height: 8,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: NeonColors.surface3,
            ),
          );
        }
        return Container(
          width: 68,
          height: 8,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            gradient: LinearGradient(
              colors: <Color>[item.color1!, Colors.transparent],
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(color: NeonColors.a(item.color1!, 0.5), blurRadius: 8),
            ],
          ),
        );
      case ItemCategory.theme:
        final List<Color> colors = item.background ??
            const <Color>[NeonColors.surface3, NeonColors.surface2];
        return Container(
          width: 74,
          height: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: colors,
            ),
            border: Border.all(color: NeonColors.a(item.accentColor ?? accent, 0.45)),
          ),
          child: CustomPaint(
            painter: _ThemePreviewPainter(
              court: item.courtColor ?? accent,
              star: item.starColor ?? Colors.white,
            ),
          ),
        );
      case ItemCategory.avatar:
        return NeonAvatar(
          seed: item.id,
          icon: NeonIconResolver.avatarItem(item.id),
          size: 54,
        );
      case ItemCategory.boom:
        final List<Color> colors = item.boomColors.isEmpty
            ? <Color>[accent, Colors.white]
            : item.boomColors;
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List<Widget>.generate(3, (int index) {
            final Color color = colors[index % colors.length];
            return Container(
              width: 12,
              height: 12,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color,
                boxShadow: <BoxShadow>[
                  BoxShadow(color: NeonColors.a(color, 0.7), blurRadius: 8),
                ],
              ),
            );
          }),
        );
    }
  }

  void _message(BuildContext context, String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), duration: const Duration(milliseconds: 1000)),
    );
  }
}

class _ThemePreviewPainter extends CustomPainter {
  const _ThemePreviewPainter({required this.court, required this.star});

  final Color court;
  final Color star;

  @override
  bool shouldRepaint(covariant _ThemePreviewPainter oldDelegate) =>
      oldDelegate.court != court || oldDelegate.star != star;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint line = Paint()
      ..color = court
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawRect(Rect.fromLTWH(7, 6, size.width - 14, size.height - 12), line);
    canvas.drawLine(
      Offset(size.width / 2, 6),
      Offset(size.width / 2, size.height - 6),
      line,
    );
    canvas.drawCircle(
      Offset(size.width / 2, size.height / 2),
      8,
      line,
    );
    final Paint dot = Paint()..color = star;
    for (int i = 0; i < 7; i++) {
      canvas.drawCircle(
        Offset(8 + (i * 17.0) % (size.width - 16), 8 + (i * 11.0) % (size.height - 16)),
        i.isEven ? 1.2 : 0.8,
        dot,
      );
    }
  }
}
