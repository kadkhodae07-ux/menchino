import 'package:flutter/material.dart';

import '../data/rank_data.dart';
import '../data/save_data.dart';
import '../game/game_engine.dart';
import '../services/audio_feedback.dart';
import '../ui/components/neon_badge.dart';
import '../ui/components/neon_button.dart';
import '../ui/components/neon_panel.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/icons/neon_icon_resolver.dart';
import '../ui/resolvers/neon_format.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_radius.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';
import '../widgets/pressable_surface.dart';
import 'friend_screen.dart';
import 'game_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    this.embedded = false,
    this.onOpenShop,
    this.onOpenProfile,
  });

  final bool embedded;
  final VoidCallback? onOpenShop;
  final VoidCallback? onOpenProfile;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      bottom: false,
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) => ListView(
          padding: EdgeInsets.fromLTRB(
            14,
            12,
            14,
            embedded ? NeonSpacing.navClearance : 18,
          ),
          children: <Widget>[
            _playerBar(context, save),
            const SizedBox(height: NeonSpacing.md),
            _matchConsole(context, save),
            const SizedBox(height: NeonSpacing.md),
            _statModules(save),
            const SizedBox(height: NeonSpacing.md),
            _challenge(save),
            const SizedBox(height: NeonSpacing.md),
            _daily(context, save),
            const SizedBox(height: NeonSpacing.md),
            _records(save),
          ],
        ),
      ),
    );
  }

  Widget _playerBar(BuildContext context, SaveData save) => Row(
        children: <Widget>[
          PressableSurface(
            accent: NeonColors.cyan,
            radius: NeonRadius.lg,
            lip: 5,
            padding: const EdgeInsets.all(4),
            onTap: onOpenProfile ?? () => _message(context, 'پروفایل بازیکن'),
            child: NeonAvatar(
              seed: save.name,
              icon: NeonIconResolver.avatarItem(save.selected['avatar'] ?? 'av_cool'),
              size: 46,
            ),
          ),
          const SizedBox(width: NeonSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  save.name,
                  style: NeonType.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 3),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: save.levelProgress / 150,
                    minHeight: 5,
                    backgroundColor: NeonColors.a(Colors.white, 0.08),
                    valueColor: const AlwaysStoppedAnimation<Color>(NeonColors.cyan),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: NeonSpacing.sm),
          PressableSurface(
            accent: NeonColors.gold,
            radius: NeonRadius.pill,
            lip: 4,
            padding: EdgeInsets.zero,
            onTap: onOpenShop ?? () => _message(context, 'فروشگاه'),
            child: NeonBadge(
              icon: NeonIconId.coin,
              text: NeonFormat.fa(save.coins),
              accent: NeonColors.gold,
            ),
          ),
          const SizedBox(width: NeonSpacing.xs),
          NeonBadge(
            icon: NeonIconId.level,
            text: 'سطح ${NeonFormat.fa(save.level)}',
            accent: NeonColors.cyan,
          ),
        ],
      );

  Widget _matchConsole(BuildContext context, SaveData save) => NeonPanel(
        accent: NeonColors.cyan,
        padding: const EdgeInsets.all(NeonSpacing.lg),
        child: Stack(
          children: <Widget>[
            const Positioned.fill(
              child: RepaintBoundary(child: CustomPaint(painter: _ArenaArt())),
            ),
            Column(
              children: <Widget>[
                const SizedBox(height: 96),
                Text('آماده‌ای برای مسابقه؟', style: NeonType.page),
                const SizedBox(height: NeonSpacing.md),
                NeonButton(
                  expanded: true,
                  big: true,
                  icon: NeonIconId.botMatch,
                  label: 'بازی با ربات',
                  onPressed: () => _difficulty(context),
                ),
                const SizedBox(height: NeonSpacing.sm),
                NeonButton(
                  expanded: true,
                  kind: NeonButtonKind.secondary,
                  icon: NeonIconId.friendMatch,
                  label: 'دو نفره با دوست',
                  onPressed: () => Navigator.push<void>(
                    context,
                    MaterialPageRoute<void>(builder: (_) => const FriendScreen()),
                  ),
                ),
                const SizedBox(height: NeonSpacing.sm),
                Text('با هر برد سکه و تجربه بگیر', style: NeonType.tiny),
              ],
            ),
          ],
        ),
      );

  Widget _statModules(SaveData save) => Row(
        children: <Widget>[
          _stat(NeonIconId.match, NeonFormat.fa(save.matches), 'بازی', NeonColors.cyan),
          const SizedBox(width: NeonSpacing.sm),
          _stat(NeonIconId.win, NeonFormat.fa(save.wins), 'برد', NeonColors.green),
          const SizedBox(width: NeonSpacing.sm),
          _stat(NeonIconId.medal, NeonFormat.fa(_rank(save)), 'رتبه', NeonColors.gold),
          const SizedBox(width: NeonSpacing.sm),
          _stat(
            NeonIconId.items,
            '${NeonFormat.fa(save.owned.length)}/${NeonFormat.fa(65)}',
            'آیتم',
            NeonColors.pink,
          ),
        ],
      );

  Widget _stat(NeonIconId icon, String value, String label, Color color) => Expanded(
        child: PressableSurface(
          accent: color,
          radius: NeonRadius.md,
          lip: 5,
          padding: const EdgeInsets.symmetric(vertical: NeonSpacing.md - 2),
          child: Column(
            children: <Widget>[
              NeonIcon(icon, size: 18, color: color),
              const SizedBox(height: 4),
              Text(
                value,
                style: NeonType.stat.copyWith(color: color),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(label, style: NeonType.tiny, maxLines: 1),
            ],
          ),
        ),
      );

  Widget _challenge(SaveData save) {
    const int target = 5;
    final int done = save.winsToday;
    final double progress = (done / target).clamp(0.0, 1.0).toDouble();
    return NeonPanel(
      accent: NeonColors.pink,
      icon: NeonIconId.flag,
      title: 'چالش روزانه',
      dense: true,
      trailing: NeonBadge(
        text: done >= target ? 'تکمیل شد' : '${NeonFormat.fa(target - done)} مونده',
        accent: done >= target ? NeonColors.green : NeonColors.pink,
      ),
      child: Column(
        children: <Widget>[
          Text(
            '${NeonFormat.fa(done)} از ${NeonFormat.fa(target)} برد امروز',
            style: NeonType.label,
          ),
          const SizedBox(height: NeonSpacing.sm),
          Container(
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              color: NeonColors.lipDark,
              border: Border.all(color: NeonColors.a(NeonColors.pink, 0.35)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                backgroundColor: Colors.transparent,
                valueColor: const AlwaysStoppedAnimation<Color>(NeonColors.pink),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _daily(BuildContext context, SaveData save) {
    final bool canClaim = save.canClaimDaily();
    return NeonPanel(
      accent: canClaim ? NeonColors.gold : NeonColors.green,
      padding: const EdgeInsets.all(NeonSpacing.md + 2),
      child: Row(
        children: <Widget>[
          NeonIcon(
            canClaim ? NeonIconId.gift : NeonIconId.win,
            size: 30,
            color: canClaim ? NeonColors.gold : NeonColors.green,
          ),
          const SizedBox(width: NeonSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  canClaim ? 'جایزه روزانه' : 'جایزه امروز دریافت شد',
                  style: NeonType.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  canClaim ? '۱۰۰ سکه رایگان آماده دریافت' : 'فردا دوباره سر بزن',
                  style: NeonType.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (canClaim)
            NeonButton(
              kind: NeonButtonKind.gold,
              icon: NeonIconId.coin,
              label: 'دریافت',
              onPressed: () async {
                final bool claimed = await save.claimDaily();
                if (!context.mounted || !claimed) return;
                AudioFeedbackService.instance.play(FeedbackEvent.claim);
                _message(context, '۱۰۰ سکه دریافت شد');
              },
            )
          else
            const NeonBadge(
              icon: NeonIconId.equipped,
              text: 'دریافت شد',
              accent: NeonColors.green,
            ),
        ],
      ),
    );
  }

  Widget _records(SaveData save) => NeonPanel(
        accent: NeonColors.purple,
        icon: NeonIconId.chart,
        title: 'رکوردها',
        dense: true,
        padding: const EdgeInsets.all(NeonSpacing.md + 2),
        child: Row(
          children: <Widget>[
            _mini(NeonIconId.winRate, '${NeonFormat.fa((save.winRate * 100).round())}٪', 'نرخ برد'),
            _mini(NeonIconId.league, NeonFormat.fa(save.points), 'لیگ'),
            _mini(NeonIconId.history, NeonFormat.fa(save.history.length), 'آخرین‌ها'),
            _mini(NeonIconId.special, NeonFormat.fa(save.owned.length), 'کلکسیون'),
          ],
        ),
      );

  Widget _mini(NeonIconId icon, String value, String label) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Column(
            children: <Widget>[
              NeonIcon(icon, size: 15, color: NeonColors.purple),
              const SizedBox(height: 2),
              Text(
                value,
                style: NeonType.btnSm.copyWith(color: NeonColors.text),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(label, style: NeonType.tiny, maxLines: 1),
            ],
          ),
        ),
      );

  int _rank(SaveData save) {
    final List<int> points = <int>[...rankBots.map((RankBot bot) => bot.points), save.points]
      ..sort((int a, int b) => b.compareTo(a));
    return points.indexOf(save.points) + 1;
  }

  void _message(BuildContext context, String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), duration: const Duration(milliseconds: 900)),
    );
  }

  void _difficulty(BuildContext context) {
    const List<String> names = <String>['آسان', 'متوسط', 'سخت', 'غیرممکن'];
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) => Dialog(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: const EdgeInsets.all(NeonSpacing.xl),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    const NeonIcon(NeonIconId.botMatch, size: 26),
                    const SizedBox(width: NeonSpacing.sm),
                    Text('سطح ربات را انتخاب کن', style: NeonType.title),
                  ],
                ),
                const SizedBox(height: NeonSpacing.lg),
                ...List<Widget>.generate(difficulties.length, (int index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: NeonSpacing.sm),
                    child: NeonButton(
                      expanded: true,
                      kind: index == 3
                          ? NeonButtonKind.danger
                          : index == 2
                              ? NeonButtonKind.gold
                              : NeonButtonKind.secondary,
                      icon: NeonIconResolver.difficulty(index),
                      label: names[index],
                      onPressed: () {
                        Navigator.pop(dialogContext);
                        Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) => GameScreen(
                              mode: GameMode.bot,
                              difficulty: index,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ArenaArt extends CustomPainter {
  const _ArenaArt();

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;

  @override
  void paint(Canvas canvas, Size size) {
    final double centerX = size.width / 2;
    canvas.drawLine(
      Offset(centerX, 8),
      Offset(centerX, 92),
      Paint()
        ..color = NeonColors.a(NeonColors.edge, 0.3)
        ..strokeWidth = 2,
    );
    canvas.drawCircle(
      Offset(centerX, 50),
      26,
      Paint()
        ..color = NeonColors.a(NeonColors.cyan, 0.2)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
    for (final double side in <double>[-1, 1]) {
      final Color color = side < 0 ? NeonColors.cyan : NeonColors.pink;
      final double x = centerX + side * (size.width * 0.36);
      canvas.drawRRect(
        RRect.fromLTRWH(x - 4, 26, 8, 48, const Radius.circular(4)),
        Paint()..color = NeonColors.a(color, 0.25),
      );
      canvas.drawRRect(
        RRect.fromLTRWH(x - 3, 27, 6, 46, const Radius.circular(3)),
        Paint()..color = color,
      );
    }
    canvas.drawCircle(
      Offset(centerX + 30, 42),
      10,
      Paint()..color = NeonColors.a(NeonColors.cyan, 0.15),
    );
    canvas.drawCircle(Offset(centerX + 30, 42), 5, Paint()..color = Colors.white);
    canvas.drawArc(
      Rect.fromLTWH(centerX - 10, 46, 60, 30),
      0.2,
      1.6,
      false,
      Paint()
        ..color = NeonColors.a(NeonColors.cyan, 0.35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round,
    );
  }
}
