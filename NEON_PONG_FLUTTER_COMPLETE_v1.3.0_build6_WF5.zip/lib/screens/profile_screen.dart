import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../services/audio_feedback.dart';
import '../ui/components/neon_badge.dart';
import '../ui/components/neon_button.dart';
import '../ui/components/neon_panel.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/icons/neon_icon_resolver.dart';
import '../ui/resolvers/neon_format.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_radius.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';
import '../widgets/pressable_surface.dart';
import 'shop_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({
    super.key,
    this.embedded = false,
    this.onOpenShop,
    this.onOpenCategory,
  });

  final bool embedded;
  final VoidCallback? onOpenShop;
  final ValueChanged<ItemCategory>? onOpenCategory;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      bottom: false,
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) => ListView(
          padding: EdgeInsets.fromLTRB(
            14,
            12,
            14,
            embedded ? NeonSpacing.navClearance : 18,
          ),
          children: <Widget>[
            Row(
              children: <Widget>[
                const NeonIcon(NeonIconId.profile, size: 23),
                const SizedBox(width: NeonSpacing.sm),
                Expanded(child: Text('پروفایل', style: NeonType.page)),
                NeonBadge(
                  icon: NeonIconId.coin,
                  text: NeonFormat.fa(save.coins),
                  accent: NeonColors.gold,
                ),
              ],
            ),
            const SizedBox(height: NeonSpacing.md),
            _header(context, save),
            const SizedBox(height: NeonSpacing.md),
            _stats(save),
            const SizedBox(height: NeonSpacing.md),
            _equipment(context, save),
            const SizedBox(height: NeonSpacing.md),
            _avatars(save),
            const SizedBox(height: NeonSpacing.md),
            _history(save),
            const SizedBox(height: NeonSpacing.md),
            _settings(save),
          ],
        ),
      ),
    );
  }

  Widget _header(BuildContext context, SaveData save) => NeonPanel(
        accent: NeonColors.cyan,
        child: Row(
          children: <Widget>[
            PressableSurface(
              accent: NeonColors.cyan,
              radius: NeonRadius.xl,
              lip: 6,
              padding: const EdgeInsets.all(5),
              onTap: () => _openAvatarShop(context),
              child: NeonAvatar(
                seed: save.name,
                icon: NeonIconResolver.avatarItem(save.selected['avatar'] ?? 'av_cool'),
                size: 72,
              ),
            ),
            const SizedBox(width: NeonSpacing.lg),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          save.name,
                          style: NeonType.page,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      NeonButton(
                        kind: NeonButtonKind.ghost,
                        icon: NeonIconId.edit,
                        label: 'ویرایش',
                        onPressed: () => _editName(context, save),
                      ),
                    ],
                  ),
                  const SizedBox(height: NeonSpacing.xs),
                  Wrap(
                    spacing: NeonSpacing.xs,
                    runSpacing: NeonSpacing.xs,
                    children: <Widget>[
                      NeonBadge(
                        icon: NeonIconId.level,
                        text: 'سطح ${NeonFormat.fa(save.level)}',
                        accent: NeonColors.cyan,
                      ),
                      NeonBadge(
                        icon: NeonIconId.xp,
                        text: '${NeonFormat.fa(save.levelProgress)}/۱۵۰',
                        accent: NeonColors.purple,
                      ),
                    ],
                  ),
                  const SizedBox(height: NeonSpacing.sm),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: LinearProgressIndicator(
                      value: save.levelProgress / 150,
                      minHeight: 7,
                      backgroundColor: NeonColors.a(Colors.white, 0.08),
                      valueColor: const AlwaysStoppedAnimation<Color>(NeonColors.cyan),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _stats(SaveData save) {
    final List<_StatData> values = <_StatData>[
      _StatData(NeonIconId.match, NeonFormat.fa(save.matches), 'بازی', NeonColors.cyan),
      _StatData(NeonIconId.win, NeonFormat.fa(save.wins), 'برد', NeonColors.green),
      _StatData(NeonIconId.lose, NeonFormat.fa(save.losses), 'باخت', NeonColors.red),
      _StatData(
        NeonIconId.winRate,
        '${NeonFormat.fa((save.winRate * 100).round())}٪',
        'نرخ برد',
        NeonColors.pink,
      ),
      _StatData(NeonIconId.league, NeonFormat.fa(save.points), 'امتیاز لیگ', NeonColors.purple),
      _StatData(NeonIconId.coin, NeonFormat.fa(save.coins), 'سکه', NeonColors.gold),
    ];

    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final int columns = constraints.maxWidth < 350 ? 2 : 3;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: values.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            crossAxisSpacing: 9,
            mainAxisSpacing: 9,
            childAspectRatio: columns == 2 ? 1.55 : 1.12,
          ),
          itemBuilder: (BuildContext context, int index) {
            final _StatData data = values[index];
            return PressableSurface(
              accent: data.color,
              radius: NeonRadius.md,
              lip: 5,
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  NeonIcon(data.icon, size: 20, color: data.color),
                  const SizedBox(height: 3),
                  Text(
                    data.value,
                    style: NeonType.stat.copyWith(color: data.color),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(data.label, style: NeonType.tiny, maxLines: 1),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _equipment(BuildContext context, SaveData save) {
    const List<ItemCategory> categories = <ItemCategory>[
      ItemCategory.paddle,
      ItemCategory.ball,
      ItemCategory.trail,
      ItemCategory.theme,
      ItemCategory.boom,
    ];
    return NeonPanel(
      accent: NeonColors.purple,
      icon: NeonIconId.items,
      title: 'تجهیزات من',
      dense: true,
      child: Column(
        children: categories.map((ItemCategory category) {
          final ShopItem item = save.selectedItem(category);
          return Padding(
            padding: const EdgeInsets.only(bottom: 7),
            child: PressableSurface(
              accent: NeonColors.purple,
              radius: NeonRadius.md,
              lip: 4,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              onTap: () => _openCategory(context, category),
              child: Row(
                children: <Widget>[
                  NeonIcon(
                    NeonIconResolver.category(category),
                    size: 19,
                    color: NeonColors.purple,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _categoryLabel(category),
                      style: NeonType.label.copyWith(color: NeonColors.text),
                    ),
                  ),
                  Text(
                    item.name,
                    style: NeonType.btnSm.copyWith(color: NeonColors.cyan),
                  ),
                  const SizedBox(width: 8),
                  const NeonIcon(NeonIconId.edit, size: 15, color: NeonColors.dim),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _avatars(SaveData save) {
    final List<ShopItem> avatars = shopItems
        .where(
          (ShopItem item) =>
              item.category == ItemCategory.avatar && save.owned.contains(item.id),
        )
        .toList(growable: false);
    return NeonPanel(
      accent: NeonColors.green,
      icon: NeonIconId.avatar,
      title: 'آواتارهای من',
      dense: true,
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: avatars.map((ShopItem item) {
          final bool selected = save.selected['avatar'] == item.id;
          return SizedBox.square(
            dimension: 60,
            child: PressableSurface(
              accent: NeonColors.green,
              radius: NeonRadius.lg,
              lip: 5,
              selected: selected,
              padding: const EdgeInsets.all(3),
              onTap: selected
                  ? null
                  : () async {
                      await save.select(item);
                      AudioFeedbackService.instance.play(FeedbackEvent.select);
                    },
              child: NeonAvatar(
                seed: item.id,
                icon: NeonIconResolver.avatarItem(item.id),
                size: 48,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _history(SaveData save) => NeonPanel(
        accent: NeonColors.pink,
        icon: NeonIconId.history,
        title: 'تاریخچه بازی‌ها',
        dense: true,
        child: save.history.isEmpty
            ? Text('هنوز بازی نکردی!', style: NeonType.label)
            : Wrap(
                spacing: 8,
                runSpacing: 8,
                children: save.history.reversed.map((MatchHistoryEntry entry) {
                  final Color color = entry.won ? NeonColors.green : NeonColors.red;
                  return NeonBadge(
                    icon: entry.mode == 'bot'
                        ? NeonIconId.botMatch
                        : NeonIconId.friendMatch,
                    text:
                        '${NeonFormat.fa(entry.playerScore)}–${NeonFormat.fa(entry.opponentScore)} ${entry.won ? 'برد' : 'باخت'}',
                    accent: color,
                  );
                }).toList(),
              ),
      );

  Widget _settings(SaveData save) => NeonPanel(
        accent: NeonColors.edge,
        icon: NeonIconId.sliders,
        title: 'تنظیمات',
        dense: true,
        child: PressableSurface(
          accent: save.muted ? NeonColors.red : NeonColors.green,
          radius: NeonRadius.md,
          lip: 4,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          onTap: () => save.setMuted(!save.muted),
          child: Row(
            children: <Widget>[
              NeonIcon(
                save.muted ? NeonIconId.soundOff : NeonIconId.soundOn,
                color: save.muted ? NeonColors.red : NeonColors.green,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  save.muted ? 'صدای بازی خاموش است' : 'صدای بازی روشن است',
                  style: NeonType.btnSm,
                ),
              ),
              NeonBadge(
                text: save.muted ? 'خاموش' : 'روشن',
                accent: save.muted ? NeonColors.red : NeonColors.green,
              ),
            ],
          ),
        ),
      );

  String _categoryLabel(ItemCategory category) => switch (category) {
        ItemCategory.paddle => 'راکت',
        ItemCategory.ball => 'توپ',
        ItemCategory.trail => 'دنباله',
        ItemCategory.theme => 'زمین',
        ItemCategory.avatar => 'آواتار',
        ItemCategory.boom => 'افکت گل',
      };

  void _openAvatarShop(BuildContext context) => _openCategory(context, ItemCategory.avatar);

  void _openCategory(BuildContext context, ItemCategory category) {
    if (onOpenCategory != null) {
      onOpenCategory!(category);
      return;
    }
    if (onOpenShop != null) {
      onOpenShop!();
      return;
    }
    Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          backgroundColor: NeonColors.bg,
          body: ShopScreen(initialCategory: category),
        ),
      ),
    );
  }

  Future<void> _editName(BuildContext context, SaveData save) async {
    final TextEditingController controller = TextEditingController(text: save.name);
    final String? value = await showDialog<String>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Row(
          children: <Widget>[
            const NeonIcon(NeonIconId.edit, size: 20),
            const SizedBox(width: 8),
            Text('ویرایش نام', style: NeonType.title),
          ],
        ),
        content: TextField(
          controller: controller,
          maxLength: 12,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'نام خود را وارد کنید'),
        ),
        actions: <Widget>[
          NeonButton(
            kind: NeonButtonKind.ghost,
            label: 'انصراف',
            onPressed: () => Navigator.pop(dialogContext),
          ),
          NeonButton(
            label: 'ذخیره',
            onPressed: () => Navigator.pop(dialogContext, controller.text),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value != null) await save.updateName(value);
  }
}

class _StatData {
  const _StatData(this.icon, this.value, this.label, this.color);

  final NeonIconId icon;
  final String value;
  final String label;
  final Color color;
}
