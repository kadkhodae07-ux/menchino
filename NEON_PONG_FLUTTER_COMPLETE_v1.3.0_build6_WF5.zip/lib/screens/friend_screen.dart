import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../game/game_engine.dart';
import '../ui/backgrounds/neon_background.dart';
import '../ui/components/neon_badge.dart';
import '../ui/components/neon_button.dart';
import '../ui/components/neon_panel.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_spacing.dart';
import '../ui/theme/neon_typography.dart';
import 'game_screen.dart';

class FriendScreen extends StatelessWidget {
  const FriendScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return Scaffold(
      backgroundColor: NeonColors.bg,
      body: NeonBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: <Widget>[
              Row(
                children: <Widget>[
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                  const NeonIcon(NeonIconId.friendMatch, size: 24),
                  const SizedBox(width: 8),
                  Expanded(child: Text('بازی با دوستان', style: NeonType.page)),
                ],
              ),
              const SizedBox(height: 12),
              NeonPanel(
                accent: NeonColors.cyan,
                icon: NeonIconId.friendMatch,
                title: 'دو نفره روی یک دستگاه',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      'بازیکن ۱: لمس نیمه چپ یا W / S\n'
                      'بازیکن ۲: لمس نیمه راست یا ↑ / ↓\n'
                      'اولین نفر با ۷ امتیاز برنده است.',
                      style: NeonType.body.copyWith(color: NeonColors.dim),
                    ),
                    const SizedBox(height: 14),
                    NeonButton(
                      expanded: true,
                      big: true,
                      icon: NeonIconId.play,
                      label: 'شروع مسابقه',
                      onPressed: () => Navigator.of(context).push<void>(
                        MaterialPageRoute<void>(
                          builder: (_) => const GameScreen(mode: GameMode.friend),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              NeonPanel(
                accent: NeonColors.purple,
                icon: NeonIconId.online,
                title: 'بازی آنلاین با دوستان',
                trailing: const NeonBadge(
                  text: 'به‌زودی',
                  accent: NeonColors.purple,
                ),
                child: Text(
                  'دعوت دوست از راه دور در نسخه بعدی فعال می‌شود.',
                  style: NeonType.label,
                ),
              ),
              const SizedBox(height: 12),
              NeonPanel(
                accent: NeonColors.gold,
                icon: NeonIconId.items,
                title: 'تجهیزات فعلی',
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    NeonBadge(
                      icon: NeonIconId.paddle,
                      text: save.selectedItem(ItemCategory.paddle).name,
                      accent: NeonColors.cyan,
                    ),
                    NeonBadge(
                      icon: NeonIconId.ball,
                      text: save.selectedItem(ItemCategory.ball).name,
                      accent: NeonColors.silver,
                    ),
                    NeonBadge(
                      icon: NeonIconId.arena,
                      text: save.selectedItem(ItemCategory.theme).name,
                      accent: NeonColors.pink,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
