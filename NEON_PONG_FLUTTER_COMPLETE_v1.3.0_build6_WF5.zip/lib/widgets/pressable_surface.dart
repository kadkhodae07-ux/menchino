import 'package:flutter/material.dart';

import '../ui/effects/press_feedback.dart';
import '../ui/icons/neon_icon.dart';
import '../ui/theme/neon_colors.dart';
import '../ui/theme/neon_radius.dart';
import '../ui/theme/neon_shadows.dart';
import '../ui/theme/neon_spacing.dart';

/// سطح حجمی فشاری یکپارچه؛ در لمس پایین می‌آید و Lip و سایه جمع می‌شوند.
class PressableSurface extends StatefulWidget {
  const PressableSurface({
    super.key,
    required this.child,
    this.onTap,
    this.accent = NeonColors.cyan,
    this.radius = NeonRadius.lg,
    this.lip = 6,
    this.enabled = true,
    this.selected = false,
    this.locked = false,
    this.fill,
    this.padding = const EdgeInsets.all(NeonSpacing.md),
    this.haptic = true,
    this.playTapSound = true,
    this.pressedScale = 0.985,
    this.pressedOffset = const Offset(0, 3.5),
    this.duration = const Duration(milliseconds: 110),
    this.borderRadius,
  });

  final Widget child;
  final VoidCallback? onTap;
  final Color accent;
  final double radius;
  final double lip;
  final bool enabled;
  final bool selected;
  final bool locked;
  final Gradient? fill;
  final EdgeInsets padding;
  final bool haptic;
  final bool playTapSound;
  final double pressedScale;
  final Offset pressedOffset;
  final Duration duration;
  final BorderRadius? borderRadius;

  @override
  State<PressableSurface> createState() => _PressableSurfaceState();
}

class _PressableSurfaceState extends State<PressableSurface>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: widget.duration,
  );

  bool get _active => widget.enabled && !widget.locked && widget.onTap != null;

  double get _radius => widget.borderRadius?.topLeft.x ?? widget.radius;

  void _down() {
    if (!_active) return;
    _controller.forward();
    PressFeedback.tap(haptic: widget.haptic, sound: widget.playTapSound);
  }

  void _release() {
    if (!_active) return;
    _controller.reverse();
  }

  void _cancel() => _controller.reverse();

  @override
  void didUpdateWidget(covariant PressableSurface oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.duration != widget.duration) {
      _controller.duration = widget.duration;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool disabled = !widget.enabled;
    final Color accent = widget.locked || disabled
        ? NeonColors.faint
        : widget.selected
            ? NeonColors.green
            : widget.accent;

    return Semantics(
      button: widget.onTap != null,
      enabled: _active,
      selected: widget.selected,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: _active ? (_) => _down() : null,
        onTapUp: _active ? (_) => _release() : null,
        onTapCancel: _active ? _cancel : null,
        onTap: _active ? widget.onTap : null,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (BuildContext context, Widget? child) {
            final double t = _controller.value;
            final double lipNow = widget.lip - (widget.lip - 1) * t;
            final double dark = 0.12 * t;
            final Gradient gradient = widget.fill ??
                LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                    Color.lerp(NeonColors.surface3, Colors.black, dark)!,
                    Color.lerp(NeonColors.surface, Colors.black, dark)!,
                    NeonColors.lipDark,
                  ],
                  stops: const <double>[0, 0.72, 1],
                );
            return Transform.translate(
              offset: Offset(
                widget.pressedOffset.dx * t,
                widget.pressedOffset.dy * t,
              ),
              child: Transform.scale(
                scale: 1 - (1 - widget.pressedScale) * t,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(minHeight: NeonSpacing.touchMin),
                  child: Container(
                    padding: EdgeInsets.only(bottom: lipNow),
                    decoration: BoxDecoration(
                      color: NeonColors.lipDark,
                      borderRadius: NeonRadius.r(_radius),
                      boxShadow: t > 0.5
                          ? NeonShadows.pressed()
                          : NeonShadows.lift(
                              accent,
                              widget.selected ? 0.3 : 0.12,
                            ),
                    ),
                    child: Container(
                      padding: widget.padding,
                      decoration: BoxDecoration(
                        gradient: gradient,
                        borderRadius: NeonRadius.r((_radius - 1).clamp(0, 999).toDouble()),
                        border: Border.all(
                          color: widget.locked
                              ? NeonColors.a(NeonColors.faint, 0.3)
                              : widget.selected
                                  ? NeonColors.a(NeonColors.green, 0.8)
                                  : NeonColors.a(accent, disabled ? 0.12 : 0.35),
                          width: widget.selected ? 1.4 : 1,
                        ),
                      ),
                      child: Stack(
                        children: <Widget>[
                          Positioned(
                            top: 0,
                            left: _radius,
                            right: _radius,
                            height: 1,
                            child: IgnorePointer(
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: <Color>[
                                      Colors.transparent,
                                      NeonColors.a(Colors.white, 0.2 - 0.12 * t),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          child!,
                          if (widget.locked)
                            const Positioned(
                              top: 4,
                              left: 4,
                              child: NeonIcon(
                                NeonIconId.lock,
                                size: 14,
                                color: NeonColors.faint,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
          child: widget.child,
        ),
      ),
    );
  }
}
