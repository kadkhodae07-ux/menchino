import wave
import struct
import math
import os

SR = 44100
OUT = os.path.join('assets', 'sounds')
os.makedirs(OUT, exist_ok=True)


def wave_samples(freq, dur, wtype, vol):
    n = int(SR * dur)
    out = []
    for i in range(n):
        t = i / SR
        ph = (t * freq) % 1.0
        if wtype == 'sine':
            v = math.sin(2 * math.pi * freq * t)
        elif wtype == 'square':
            v = 1.0 if math.sin(2 * math.pi * freq * t) >= 0 else -1.0
        elif wtype == 'triangle':
            v = 4 * ph if ph < .25 else (2 - 4 * ph if ph < .75 else 4 * ph - 4)
        else:
            v = 2 * ph - 1
        env = vol * (0.0001 / vol) ** (t / dur) if dur > 0 else vol
        out.append(v * env)
    return out


def build(parts):
    total = int(SR * max(d + delay for (_, d, _, _, delay) in parts)) + 1
    buf = [0.0] * total
    for freq, dur, wtype, vol, delay in parts:
        samples = wave_samples(freq, dur, wtype, vol)
        start = int(SR * delay)
        for i, value in enumerate(samples):
            if start + i < total:
                buf[start + i] += value
    return buf


def save(name, buf):
    with wave.open(os.path.join(OUT, name + '.wav'), 'w') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        for value in buf:
            wav.writeframes(struct.pack('<h', int(max(-1, min(1, value)) * 32767)))
    print('created', name + '.wav')


SOUNDS = {
    'click': [(600, .04, 'sine', .06, 0)],
    'select': [(600, .06, 'sine', .09, 0)],
    'send': [(700, .05, 'sine', .08, 0)],
    'serve': [(440, .06, 'sine', .12, 0)],
    'hit_wall': [(230, .05, 'triangle', .07, 0)],
    'hit_paddle': [(500, .06, 'square', .10, 0)],
    'score_win': [(520, .09, 'square', .12, 0), (760, .12, 'square', .12, .09)],
    'score_lose': [(320, .10, 'square', .12, 0), (190, .16, 'square', .12, .10)],
    'buy': [(700, .08, 'square', .10, 0), (950, .10, 'square', .10, .09)],
    'claim': [(700, .08, 'square', .10, 0), (1000, .12, 'square', .10, .10)],
    'powerup': [(1200, .10, 'sine', .15, 0), (1600, .10, 'sine', .15, .10)],
    'shield': [(900, .10, 'square', .15, 0)],
    'error': [(180, .15, 'sawtooth', .09, 0)],
    'victory': [(523, .12, 'square', .12, 0), (659, .12, 'square', .12, .13), (784, .22, 'square', .12, .26)],
    'defeat': [(300, .20, 'sawtooth', .10, 0), (200, .30, 'sawtooth', .10, .18)],
}

for sound_name, parts in SOUNDS.items():
    save(sound_name, build(parts))

print('All sounds created in:', OUT)
