import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'lobby_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'rewards_screen.dart';
import 'shop_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 2;

  static const _screens = [
    ShopScreen(),
    RewardsScreen(),
    LobbyScreen(),
    RankScreen(),
    ProfileScreen(),
  ];

  static const _tabs = [
    ('shop', 'فروشگاه'),
    ('gift', 'جوایز'),
    ('home', 'خانه'),
    ('rank', 'رتبه‌بندی'),
    ('profile', 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return Scaffold(
      backgroundColor: theme.bg,
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        child: NeonPanel(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
          child: Row(
            children: List.generate(_tabs.length, (index) {
              final active = index == _index;
              final home = index == 2;
              final accent = active ? (home ? theme.primary : theme.primary) : theme.dim;
              return Expanded(
                child: GestureDetector(
                  onTap: () {
                    context.read<AppState>().audio.play('tap');
                    setState(() => _index = index);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOut,
                    transform: Matrix4.translationValues(0, home ? (active ? -8 : -6) : 0, 0),
                    margin: EdgeInsets.only(top: home ? 0 : 6, bottom: home ? 0 : 2, left: 2, right: 2),
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(home ? 18 : 14),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: active
                            ? [theme.primary.withOpacity(home ? .22 : .16), theme.panel.withOpacity(.92)]
                            : [Colors.transparent, Colors.transparent],
                      ),
                      border: Border.all(color: active ? theme.primary.withOpacity(home ? .45 : .24) : Colors.transparent),
                      boxShadow: active
                          ? [
                              BoxShadow(color: theme.primary.withOpacity(home ? .22 : .12), blurRadius: home ? 18 : 12),
                              BoxShadow(color: Colors.black.withOpacity(.26), blurRadius: 14, offset: const Offset(0, 8)),
                            ]
                          : null,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AppIcons.icon(_tabs[index].$1, size: home ? 26 : 22, color: accent),
                        const SizedBox(height: 4),
                        Text(
                          _tabs[index].$2,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: accent),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
