import 'package:flutter/material.dart';

class GameTheme {
  final String id;
  final String label;
  final Brightness brightness;
  final Color bg;
  final Color panel;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color danger;
  final Color gold;
  final Color text;
  final Color dim;
  final Color canvasBg;
  final Color grid;
  final Color center;
  final Color top;
  final Color bottom;
  final Color ball;
  final Color trail;

  const GameTheme({
    required this.id,
    required this.label,
    required this.brightness,
    required this.bg,
    required this.panel,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.danger,
    required this.gold,
    required this.text,
    required this.dim,
    required this.canvasBg,
    required this.grid,
    required this.center,
    required this.top,
    required this.bottom,
    required this.ball,
    required this.trail,
  });
}

class Themes {
  static const dark = GameTheme(
    id: 'dark',
    label: 'تاریک',
    brightness: Brightness.dark,
    bg: Color(0xFF030612),
    panel: Color(0xF0121C33),
    primary: Color(0xFF2DE2FF),
    secondary: Color(0xFF8B63FF),
    accent: Color(0xFF00F5C8),
    danger: Color(0xFFFF4E98),
    gold: Color(0xFFFFD96A),
    text: Color(0xFFF1F7FF),
    dim: Color(0xFF9FB1D3),
    canvasBg: Color(0xFF020612),
    grid: Color(0x1B34DFFF),
    center: Color(0xFF38E5FF),
    top: Color(0xFF9C6BFF),
    bottom: Color(0xFF00FFC8),
    ball: Color(0xFFEFF7FF),
    trail: Color(0xFF48DFFF),
  );

  static const light = GameTheme(
    id: 'light',
    label: 'روشن',
    brightness: Brightness.light,
    bg: Color(0xFFF0F5FF),
    panel: Color(0xF7FFFFFF),
    primary: Color(0xFF2563EB),
    secondary: Color(0xFF7C3AED),
    accent: Color(0xFF0891B2),
    danger: Color(0xFFDB2777),
    gold: Color(0xFFD97706),
    text: Color(0xFF081120),
    dim: Color(0xFF55647F),
    canvasBg: Color(0xFFEAF2FF),
    grid: Color(0x1A2563EB),
    center: Color(0xFF2563EB),
    top: Color(0xFF7C3AED),
    bottom: Color(0xFF0891B2),
    ball: Color(0xFF081120),
    trail: Color(0xFF2563EB),
  );

  static const girly = GameTheme(
    id: 'girly',
    label: 'دخترونه',
    brightness: Brightness.dark,
    bg: Color(0xFF140516),
    panel: Color(0xF0250B2C),
    primary: Color(0xFFFF73D3),
    secondary: Color(0xFFD18BFF),
    accent: Color(0xFFFFB4E8),
    danger: Color(0xFFFF4C8A),
    gold: Color(0xFFFFD670),
    text: Color(0xFFFFF0FB),
    dim: Color(0xFFE0A7D5),
    canvasBg: Color(0xFF160517),
    grid: Color(0x1FFF73D3),
    center: Color(0xFFFF86DB),
    top: Color(0xFFD794FF),
    bottom: Color(0xFFFFB4E8),
    ball: Color(0xFFFFF0FB),
    trail: Color(0xFFFF73D3),
  );

  static const boyish = GameTheme(
    id: 'boyish',
    label: 'پسرونه',
    brightness: Brightness.dark,
    bg: Color(0xFF031018),
    panel: Color(0xF0081C27),
    primary: Color(0xFF39C6FF),
    secondary: Color(0xFF23D18B),
    accent: Color(0xFFA7F64A),
    danger: Color(0xFFFF7A45),
    gold: Color(0xFFF9D548),
    text: Color(0xFFE8FAFF),
    dim: Color(0xFF88AABD),
    canvasBg: Color(0xFF031018),
    grid: Color(0x1639C6FF),
    center: Color(0xFF3CCBFF),
    top: Color(0xFF23D18B),
    bottom: Color(0xFFA7F64A),
    ball: Color(0xFFE8FAFF),
    trail: Color(0xFF39C6FF),
  );

  static const child = GameTheme(
    id: 'child',
    label: 'بچگونه',
    brightness: Brightness.light,
    bg: Color(0xFFFFF7E6),
    panel: Color(0xF8FFFFFF),
    primary: Color(0xFFFF8A00),
    secondary: Color(0xFF8B5CF6),
    accent: Color(0xFF00BFA5),
    danger: Color(0xFFFF4D6D),
    gold: Color(0xFFFFC837),
    text: Color(0xFF2C1E54),
    dim: Color(0xFF6C5CA6),
    canvasBg: Color(0xFFFFF4DE),
    grid: Color(0x1CFF8A00),
    center: Color(0xFFFF8A00),
    top: Color(0xFF8B5CF6),
    bottom: Color(0xFF00BFA5),
    ball: Color(0xFF2C1E54),
    trail: Color(0xFFFF8A00),
  );

  static const all = [dark, light, girly, boyish, child];

  static GameTheme byId(String? id) =>
      all.firstWhere((theme) => theme.id == id, orElse: () => dark);
}
