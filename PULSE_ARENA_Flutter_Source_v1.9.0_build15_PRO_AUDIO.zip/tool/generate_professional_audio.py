from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, resample

SR = 44100
OUT = Path(__file__).resolve().parents[1] / 'assets' / 'audio'
RNG = np.random.default_rng(20260730)


def tvec(duration: float) -> np.ndarray:
    return np.arange(int(SR * duration), dtype=np.float64) / SR


def exp_decay(t: np.ndarray, tau: float) -> np.ndarray:
    return np.exp(-t / max(tau, 1e-5))


def adsr(t: np.ndarray, attack: float, decay: float, sustain: float, release: float) -> np.ndarray:
    duration = t[-1] + 1 / SR
    env = np.ones_like(t) * sustain
    a = np.clip(t / max(attack, 1 / SR), 0, 1)
    env = np.where(t < attack, np.sin(a * np.pi / 2) ** 2, env)
    decay_end = attack + decay
    d = np.clip((t - attack) / max(decay, 1 / SR), 0, 1)
    env = np.where((t >= attack) & (t < decay_end), 1 - (1 - sustain) * d, env)
    release_start = max(0.0, duration - release)
    r = np.clip((t - release_start) / max(release, 1 / SR), 0, 1)
    env = np.where(t >= release_start, env * (np.cos(r * np.pi / 2) ** 2), env)
    return env


def sine(freq: float | np.ndarray, t: np.ndarray, phase: float = 0.0) -> np.ndarray:
    if np.isscalar(freq):
        return np.sin(2 * np.pi * float(freq) * t + phase)
    phase_arr = 2 * np.pi * np.cumsum(np.asarray(freq)) / SR + phase
    return np.sin(phase_arr)


def triangle(freq: float, t: np.ndarray) -> np.ndarray:
    return 2 / np.pi * np.arcsin(np.sin(2 * np.pi * freq * t))


def filtered_noise(duration: float, low: float | None = None, high: float | None = None) -> np.ndarray:
    x = RNG.normal(0, 1, int(SR * duration))
    if low is not None and high is not None:
        sos = butter(3, [low, high], btype='bandpass', fs=SR, output='sos')
        return sosfilt(sos, x)
    if low is not None:
        sos = butter(3, low, btype='highpass', fs=SR, output='sos')
        return sosfilt(sos, x)
    if high is not None:
        sos = butter(3, high, btype='lowpass', fs=SR, output='sos')
        return sosfilt(sos, x)
    return x


def soft_clip(x: np.ndarray, drive: float = 1.15) -> np.ndarray:
    return np.tanh(x * drive) / np.tanh(drive)


def delay_mix(x: np.ndarray, taps: list[tuple[float, float]]) -> np.ndarray:
    y = x.copy()
    for seconds, gain in taps:
        n = int(seconds * SR)
        if n <= 0 or n >= len(x):
            continue
        y[n:] += gain * x[:-n]
    return y


def stereo(x: np.ndarray, width: float = 0.18, delay_ms: float = 7.0) -> np.ndarray:
    if x.ndim == 2:
        return x
    n = max(1, int(delay_ms * SR / 1000))
    delayed = np.pad(x[:-n], (n, 0))
    left = x * (1 - width * 0.35) + delayed * width
    right = x * (1 - width * 0.35) - delayed * width * 0.25
    return np.column_stack([left, right])



def pitch_variant(x: np.ndarray, factor: float) -> np.ndarray:
    new_len = max(8, int(len(x) / factor))
    return resample(x, new_len, axis=0)

def peak_normalize(x: np.ndarray, peak_db: float = -3.0) -> np.ndarray:
    x = np.nan_to_num(x)
    x -= np.mean(x, axis=0, keepdims=True)
    peak = float(np.max(np.abs(x)))
    target = 10 ** (peak_db / 20)
    if peak > 1e-9:
        x = x * (target / peak)
    return np.clip(x, -1, 1)


def save(name: str, x: np.ndarray, peak_db: float = -3.0) -> None:
    x = peak_normalize(soft_clip(x), peak_db=peak_db)
    wavfile.write(OUT / name, SR, (x * 32767).astype(np.int16))


def button() -> np.ndarray:
    t = tvec(0.115)
    f = np.linspace(780, 1120, len(t))
    tonal = 0.72 * sine(f, t) * exp_decay(t, 0.036)
    body = 0.28 * sine(np.linspace(190, 120, len(t)), t) * exp_decay(t, 0.055)
    click = 0.07 * filtered_noise(len(t) / SR, 1400, 5200) * exp_decay(t, 0.009)
    return (tonal + body + click) * np.sin(np.clip(t / 0.004, 0, 1) * np.pi / 2)


def paddle() -> np.ndarray:
    t = tvec(0.135)
    thump = 0.68 * sine(np.linspace(175, 82, len(t)), t) * exp_decay(t, 0.052)
    snap = 0.24 * sine(np.linspace(950, 620, len(t)), t) * exp_decay(t, 0.025)
    air = 0.11 * filtered_noise(len(t) / SR, 700, 3800) * exp_decay(t, 0.018)
    return thump + snap + air


def wall() -> np.ndarray:
    t = tvec(0.095)
    tick = 0.58 * sine(np.linspace(510, 330, len(t)), t) * exp_decay(t, 0.027)
    body = 0.24 * sine(np.linspace(125, 78, len(t)), t) * exp_decay(t, 0.045)
    air = 0.07 * filtered_noise(len(t) / SR, 900, 2600) * exp_decay(t, 0.016)
    return tick + body + air


def countdown() -> np.ndarray:
    t = tvec(0.205)
    env = adsr(t, 0.006, 0.04, 0.32, 0.12)
    pulse = 0.68 * sine(470, t) + 0.22 * sine(940, t, 0.25)
    low = 0.18 * sine(np.linspace(115, 92, len(t)), t) * exp_decay(t, 0.095)
    return pulse * env + low


def perfect() -> np.ndarray:
    t = tvec(0.47)
    env = adsr(t, 0.003, 0.08, 0.12, 0.28)
    chime = (
        0.58 * sine(880, t)
        + 0.26 * sine(1320, t, 0.1)
        + 0.16 * sine(1760, t, 0.3)
    ) * env
    low = 0.18 * sine(np.linspace(210, 130, len(t)), t) * exp_decay(t, 0.11)
    return stereo(delay_mix(chime + low, [(0.052, 0.20), (0.092, 0.10)]), width=0.24)


def power() -> np.ndarray:
    t = tvec(0.62)
    sweep = sine(np.geomspace(135, 1160, len(t)), t)
    shimmer = sine(np.geomspace(620, 2100, len(t)), t, 0.2)
    env = adsr(t, 0.018, 0.19, 0.42, 0.22)
    pulse = (0.52 * sweep + 0.18 * shimmer) * env
    impact_t = np.maximum(0, t - 0.40)
    impact = 0.42 * sine(np.linspace(145, 72, len(t)), t) * np.where(t >= 0.40, exp_decay(impact_t, 0.09), 0)
    noise = 0.06 * filtered_noise(len(t) / SR, 1200, 6000) * env
    return stereo(delay_mix(pulse + impact + noise, [(0.063, 0.16), (0.121, 0.08)]), width=0.28)


def score() -> np.ndarray:
    duration = 0.72
    t = tvec(duration)
    x = np.zeros_like(t)
    notes = [(523.25, 0.00), (659.25, 0.11), (783.99, 0.22), (1046.50, 0.35)]
    for freq, start in notes:
        local = np.maximum(0, t - start)
        active = t >= start
        tone = (0.54 * sine(freq, local) + 0.16 * sine(freq * 2, local, 0.2))
        x += np.where(active, tone * exp_decay(local, 0.19), 0)
    thump = 0.34 * sine(np.linspace(135, 70, len(t)), t) * exp_decay(t, 0.12)
    sparkle = 0.04 * filtered_noise(duration, 1800, 6500) * exp_decay(t, 0.22)
    return stereo(delay_mix(x + thump + sparkle, [(0.075, 0.18), (0.145, 0.09)]), width=0.31)


def win() -> np.ndarray:
    duration = 1.85
    t = tvec(duration)
    x = np.zeros_like(t)
    sequence = [
        ([293.66, 369.99, 440.00], 0.00, 0.50),
        ([349.23, 440.00, 523.25], 0.42, 0.52),
        ([392.00, 493.88, 587.33], 0.86, 0.88),
    ]
    for chord, start, length in sequence:
        local = np.maximum(0, t - start)
        active = (t >= start) & (t <= start + length)
        env = np.where(active, np.sin(np.clip(local / 0.045, 0, 1) * np.pi / 2) * exp_decay(local, length * 0.92), 0)
        for i, freq in enumerate(chord):
            x += (0.26 - i * 0.025) * sine(freq, local, i * 0.21) * env
            x += 0.06 * sine(freq * 2, local, i * 0.13) * env
    rise = sine(np.geomspace(160, 1550, len(t)), t) * adsr(t, 0.03, 0.45, 0.15, 0.75)
    low = 0.25 * sine(np.linspace(125, 62, len(t)), t) * exp_decay(t, 0.36)
    sparkle = 0.035 * filtered_noise(duration, 2200, 7800) * adsr(t, 0.02, 0.25, 0.16, 0.9)
    return stereo(delay_mix(x + 0.12 * rise + low + sparkle, [(0.084, 0.16), (0.168, 0.09), (0.252, 0.05)]), width=0.38)


def lose() -> np.ndarray:
    duration = 1.25
    t = tvec(duration)
    x = np.zeros_like(t)
    notes = [(392.0, 0.00), (349.23, 0.22), (293.66, 0.46), (220.0, 0.72)]
    for i, (freq, start) in enumerate(notes):
        local = np.maximum(0, t - start)
        active = t >= start
        env = np.where(active, exp_decay(local, 0.28 + i * 0.03), 0)
        x += (0.42 - i * 0.055) * (sine(freq, local) + 0.12 * sine(freq * 0.5, local)) * env
    low = 0.23 * sine(np.linspace(105, 54, len(t)), t) * exp_decay(t, 0.42)
    air = 0.025 * filtered_noise(duration, 500, 2200) * exp_decay(t, 0.5)
    return stereo(delay_mix(x + low + air, [(0.11, 0.12), (0.22, 0.06)]), width=0.22)


def arena_loop() -> np.ndarray:
    duration = 16.0
    t = tvec(duration)
    x = np.zeros_like(t)
    chords = [
        [73.42, 110.00, 146.83, 174.61],   # Dm7
        [58.27, 87.31, 116.54, 146.83],    # Bbmaj7
        [87.31, 130.81, 174.61, 220.00],   # Fmaj7
        [65.41, 98.00, 130.81, 164.81],    # Cmaj7
    ]
    section = 4.0
    for idx, chord in enumerate(chords):
        start = idx * section
        local = t - start
        active = (local >= 0) & (local < section)
        # Gentle crossfades inside each four-second section.
        env = np.where(active, np.sin(np.clip(local / 0.65, 0, 1) * np.pi / 2), 0)
        env *= np.where(active, np.sin(np.clip((section - local) / 0.65, 0, 1) * np.pi / 2), 0)
        for j, freq in enumerate(chord):
            drift = freq * (1 + 0.0016 * np.sin(2 * np.pi * (0.055 + j * 0.011) * t + j))
            layer = sine(drift, t, j * 0.4) + 0.18 * triangle(freq * 0.5, t)
            x += (0.115 - j * 0.012) * layer * env
    # Quiet pulse, intentionally below the effects band.
    beat_phase = np.mod(t, 0.5)
    beat_env = np.exp(-beat_phase / 0.075)
    kick = sine(np.linspace(78, 48, len(t)), t) * beat_env
    x += 0.055 * kick
    # Sparse deterministic high-tech ticks.
    for start in [1.0, 3.5, 5.0, 7.5, 9.0, 11.5, 13.0, 15.0]:
        local = np.maximum(0, t - start)
        active = (t >= start) & (t < start + 0.24)
        x += np.where(active, 0.025 * sine(1320 + (start % 2) * 180, local) * exp_decay(local, 0.06), 0)
    # Subtle filtered texture, faded at boundaries to avoid loop clicks.
    texture = filtered_noise(duration, 180, 1500)
    texture /= max(np.max(np.abs(texture)), 1e-9)
    x += 0.018 * texture
    boundary = np.ones_like(t)
    fade = 0.32
    boundary *= np.sin(np.clip(t / fade, 0, 1) * np.pi / 2) ** 2
    boundary *= np.sin(np.clip((duration - t) / fade, 0, 1) * np.pi / 2) ** 2
    x *= boundary
    left = delay_mix(x, [(0.19, 0.10), (0.37, 0.05)])
    right = delay_mix(x, [(0.23, 0.10), (0.43, 0.05)])
    return np.column_stack([left, right])


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    button_base = button()
    paddle_base = paddle()
    wall_base = wall()
    save('button_1.wav', pitch_variant(button_base, 0.97), peak_db=-5.0)
    save('button_2.wav', pitch_variant(button_base, 1.03), peak_db=-5.5)
    save('paddle_1.wav', pitch_variant(paddle_base, 0.96), peak_db=-4.5)
    save('paddle_2.wav', paddle_base, peak_db=-4.0)
    save('paddle_3.wav', pitch_variant(paddle_base, 1.045), peak_db=-4.5)
    save('wall_1.wav', pitch_variant(wall_base, 0.97), peak_db=-6.0)
    save('wall_2.wav', pitch_variant(wall_base, 1.035), peak_db=-6.5)
    save('countdown.wav', countdown(), peak_db=-5.0)
    save('perfect.wav', perfect(), peak_db=-4.0)
    save('power.wav', power(), peak_db=-4.0)
    save('score.wav', score(), peak_db=-4.0)
    save('win.wav', win(), peak_db=-3.5)
    save('lose.wav', lose(), peak_db=-5.0)
    save('arena_loop.wav', arena_loop(), peak_db=-8.5)
    print(f'Generated professional original audio assets in {OUT}')
