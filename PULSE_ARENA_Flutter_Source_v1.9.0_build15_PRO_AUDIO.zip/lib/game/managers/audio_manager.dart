import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/services.dart';

class AudioManager {
  AudioManager._();

  static final AudioManager instance = AudioManager._();

  bool soundEnabled = true;
  bool musicEnabled = true;
  bool vibrationEnabled = true;
  bool _bgmStarted = false;
  int _lastHapticMicros = 0;
  int _buttonCursor = 0;
  int _paddleCursor = 0;
  int _wallCursor = 0;
  final Map<String, int> _lastSoundMicros = <String, int>{};

  static const List<String> _buttonSounds = <String>[
    'button_1.wav',
    'button_2.wav',
  ];

  static const List<String> _paddleSounds = <String>[
    'paddle_1.wav',
    'paddle_2.wav',
    'paddle_3.wav',
  ];

  static const List<String> _wallSounds = <String>[
    'wall_1.wav',
    'wall_2.wav',
  ];

  static const List<String> _sounds = <String>[
    ..._buttonSounds,
    ..._paddleSounds,
    ..._wallSounds,
    'score.wav',
    'power.wav',
    'win.wav',
    'lose.wav',
    'countdown.wav',
    'perfect.wav',
    'arena_loop.wav',
  ];

  Future<void> preload() async {
    try {
      await FlameAudio.audioCache.loadAll(_sounds);
    } catch (_) {
      // Audio failure must never block gameplay.
    }
  }

  Future<void> startBgm() async {
    if (!musicEnabled || _bgmStarted) return;
    try {
      await FlameAudio.bgm.play('arena_loop.wav', volume: 0.12);
      _bgmStarted = true;
    } catch (_) {
      _bgmStarted = false;
    }
  }

  Future<void> stopBgm() async {
    try {
      await FlameAudio.bgm.stop();
    } catch (_) {
      // Ignore unavailable audio backends.
    }
    _bgmStarted = false;
  }

  Future<void> setSoundEnabled(bool enabled) async {
    soundEnabled = enabled;
  }

  Future<void> setMusicEnabled(bool enabled) async {
    musicEnabled = enabled;
    if (enabled) {
      await startBgm();
    } else {
      await stopBgm();
    }
  }

  Future<void> playButton() {
    final String sound = _buttonSounds[_buttonCursor % _buttonSounds.length];
    _buttonCursor += 1;
    return _play(
      sound,
      cooldownKey: 'button',
      volume: 0.27,
      minimumGapMs: 95,
    );
  }

  Future<void> playPaddle() {
    final String sound = _paddleSounds[_paddleCursor % _paddleSounds.length];
    _paddleCursor += 1;
    return _play(
      sound,
      cooldownKey: 'paddle',
      volume: 0.34,
      minimumGapMs: 58,
    );
  }

  Future<void> playPerfect() =>
      _play('perfect.wav', volume: 0.43, minimumGapMs: 110);

  Future<void> playCountdown() =>
      _play('countdown.wav', volume: 0.34, minimumGapMs: 190);

  Future<void> playWall() {
    final String sound = _wallSounds[_wallCursor % _wallSounds.length];
    _wallCursor += 1;
    return _play(
      sound,
      cooldownKey: 'wall',
      volume: 0.18,
      minimumGapMs: 72,
    );
  }

  Future<void> playScore() =>
      _play('score.wav', volume: 0.42, minimumGapMs: 300);

  Future<void> playPower() =>
      _play('power.wav', volume: 0.39, minimumGapMs: 135);

  Future<void> playWin() =>
      _play('win.wav', volume: 0.50, minimumGapMs: 700);

  Future<void> playLose() =>
      _play('lose.wav', volume: 0.40, minimumGapMs: 700);

  Future<void> _play(
    String fileName, {
    String? cooldownKey,
    double volume = 1,
    int minimumGapMs = 0,
  }) async {
    if (!soundEnabled) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    final String key = cooldownKey ?? fileName;
    final int last = _lastSoundMicros[key] ?? 0;
    if (minimumGapMs > 0 && now - last < minimumGapMs * 1000) return;
    _lastSoundMicros[key] = now;
    try {
      await FlameAudio.play(fileName, volume: volume);
    } catch (_) {
      // Keep gameplay functional even when a device audio backend fails.
    }
  }

  Future<void> lightImpact() async {
    if (!vibrationEnabled) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    if (now - _lastHapticMicros < 85000) return;
    _lastHapticMicros = now;
    await HapticFeedback.lightImpact();
  }

  Future<void> importantImpact() async {
    if (!vibrationEnabled) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    if (now - _lastHapticMicros < 120000) return;
    _lastHapticMicros = now;
    await HapticFeedback.mediumImpact();
  }
}
