# منچینو — مار و پله سه‌بعدی Android

نسخه سورس: `0.1.11`  
موتور هدف: `Unity 2022.3.62f1 LTS`  
رندر: Built-in Render Pipeline  
نمایش: Portrait  
شناسه بسته: `com.menchino.game`

## اصلاح نسخه 0.1.11

- وابستگی نامعتبر `com.unity.modules.inputlegacy` از `Packages/manifest.json` حذف شد.
- Legacy Input Manager جزو قابلیت‌های داخلی Unity است و Package UPM مستقلی با این شناسه در Unity 2022.3 وجود ندارد.
- `StandaloneInputModule` توسط `com.unity.ugui` فراهم می‌شود؛ UGUI و ارجاع `Unity.ugui` حفظ شده‌اند.
- ماژول معتبر `com.unity.modules.physics` برای `UnityEngine.Collider` حفظ شده است.
- `MenchinoBuildConfigurator` و Workflow شماره‌گذاری‌شده `WF-20` وجود وابستگی نامعتبر را قبل از Build رد می‌کنند.

## خروجی Android

Build از متد `Menchino.Editor.AndroidBuilder.Build` انجام می‌شود و دقیقاً دو فایل تولید می‌کند:

- `Builds/Android/Menchino-arm64-v8a.apk`
- `Builds/Android/Menchino-universal.apk`

Workflow این دو APK را بدون فایل اضافی داخل `Menchino-Android-Latest.zip` قرار می‌دهد.

## GitHub Actions

1. فایل سورس `menchino_unity_v0.1.11_inputlegacy_fix_wf20_source.zip` را در ریشه Repository خصوصی قرار دهید.
2. Workflow مستقل را در مسیر `.github/workflows/menchino-build-wf20.yml` قرار دهید.
3. Workflowهای قدیمی منچینو را از `.github/workflows` حذف کنید.
4. عنوان اجرای صحیح با `Menchino WF-20` شروع می‌شود.

Workflow جدیدترین ZIP معتبر را براساس SemVer انتخاب می‌کند، ساختار ZIP و Manifest را بررسی می‌کند، لایسنس داخلی را در Home پاک و نوشتنی Runner فعال می‌کند، دو APK مستقل می‌سازد و در صورت خطا بسته لاگ شماره‌گذاری‌شده تحویل می‌دهد.

> فایل لایسنس و اطلاعات حساب Unity طبق درخواست مالک داخل `.unity-ci` قرار دارند؛ Repository باید خصوصی باقی بماند.
