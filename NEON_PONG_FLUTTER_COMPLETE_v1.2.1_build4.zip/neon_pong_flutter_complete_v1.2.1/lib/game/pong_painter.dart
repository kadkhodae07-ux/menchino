import 'dart:math';

import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../utils/fa_digits.dart';
import 'game_engine.dart';

class PongPainter extends CustomPainter {
  PongPainter(this.engine, this.save);

  final GameEngine engine;
  final SaveData save;

  @override
  void paint(Canvas canvas, Size size) {
    final double width = size.width;
    final double height = size.height;
    final ShopItem theme = save.selectedItem(ItemCategory.theme);
    final List<Color> background = theme.background ??
        const <Color>[
          Color(0xFF070A1A),
          Color(0xFF0B1030),
          Color(0xFF070A1A),
        ];

    canvas.save();
    if (engine.shake > 0) {
      final Random random = Random();
      canvas.translate(
        (random.nextDouble() - 0.5) * engine.shake,
        (random.nextDouble() - 0.5) * engine.shake,
      );
    }

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: background,
        ).createShader(Offset.zero & size),
    );

    _drawArenaDepth(canvas, size, theme);
    _drawStars(canvas, theme);
    _drawCourt(canvas, size, theme);
    _drawFlash(canvas, size);
    _drawTrail(canvas);
    _drawPowerUp(canvas);
    _drawPaddles(canvas);
    _drawShield(canvas);
    _drawBall(canvas, engine.ball, opacity: 1);
    for (final BallBody extra in engine.extraBalls) {
      _drawBall(canvas, extra, opacity: 0.86);
    }
    _drawParticles(canvas);
    _drawVignette(canvas, size);
    _drawScore(canvas, width);
    if (engine.state == GameState.serve) _drawServe(canvas, size);
    canvas.restore();
  }

  void _drawArenaDepth(Canvas canvas, Size size, ShopItem theme) {
    final Color accent = theme.accentColor ?? const Color(0xFF00E5FF);
    final Color star = theme.starColor ?? const Color(0xFF9FD8FF);

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 0.72,
          colors: <Color>[
            accent.withOpacity(0.16),
            accent.withOpacity(0.05),
            Colors.transparent,
          ],
        ).createShader(Offset.zero & size),
    );

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.92, 0),
          radius: 1.0,
          colors: <Color>[
            const Color(0xFF00E5FF).withOpacity(0.13),
            Colors.transparent,
          ],
        ).createShader(Offset.zero & size),
    );

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0.92, 0),
          radius: 1.0,
          colors: <Color>[
            const Color(0xFFFF2FD6).withOpacity(0.12),
            Colors.transparent,
          ],
        ).createShader(Offset.zero & size),
    );

    final Paint grid = Paint()
      ..color = star.withOpacity(0.045)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final double gapY = max(48.0, size.height / 7.8);
    double y = size.height * 0.12;
    while (y < size.height) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      y += gapY;
    }

    final Rect leftWall = Rect.fromLTWH(0, size.height * 0.22, 10 * engine.scale, size.height * 0.56);
    final Rect rightWall = Rect.fromLTWH(size.width - 10 * engine.scale, size.height * 0.22, 10 * engine.scale, size.height * 0.56);
    final Paint wall = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          accent.withOpacity(0),
          accent.withOpacity(0.17),
          accent.withOpacity(0),
        ],
      ).createShader(leftWall);
    canvas.drawRRect(RRect.fromRectAndRadius(leftWall, Radius.circular(24 * engine.scale)), wall);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rightWall, Radius.circular(24 * engine.scale)),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            const Color(0xFFFF2FD6).withOpacity(0),
            const Color(0xFFFF2FD6).withOpacity(0.17),
            const Color(0xFFFF2FD6).withOpacity(0),
          ],
        ).createShader(rightWall),
    );
  }

  void _drawStars(Canvas canvas, ShopItem theme) {
    final Color color = theme.starColor ?? const Color(0xFF9FD8FF);
    for (final StarBody star in engine.stars) {
      final double opacity = max(star.depth * (0.38 + 0.44 * sin(engine.time * 2 + star.phase)), 0.08);
      canvas.drawCircle(
        Offset(star.x, star.y),
        star.depth * 1.05,
        Paint()..color = color.withOpacity(opacity.clamp(0, 1).toDouble()),
      );
    }
  }

  void _drawCourt(Canvas canvas, Size size, ShopItem theme) {
    final Color court = theme.courtColor ?? const Color(0x5978A0FF);
    final Paint edge = Paint()..color = court.withOpacity(0.62);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, 2.4), edge);
    canvas.drawRect(Rect.fromLTWH(0, size.height - 2.4, size.width, 2.4), edge);

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withOpacity(0.03),
            Colors.transparent,
            Colors.transparent,
            Colors.white.withOpacity(0.02),
          ],
          stops: const <double>[0.0, 0.08, 0.92, 1.0],
        ).createShader(Offset.zero & size),
    );

    final Paint lineGlow = Paint()
      ..color = court.withOpacity(0.16)
      ..strokeWidth = 8 * engine.scale
      ..style = PaintingStyle.stroke
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    final Paint line = Paint()
      ..color = court.withOpacity(0.78)
      ..strokeWidth = 3.2
      ..style = PaintingStyle.stroke;

    const double dash = 14;
    const double gap = 12;
    double y = 10;
    while (y < size.height - 10) {
      final Offset from = Offset(size.width / 2, y);
      final Offset to = Offset(size.width / 2, min(y + dash, size.height - 10));
      canvas.drawLine(from, to, lineGlow);
      canvas.drawLine(from, to, line);
      y += dash + gap;
    }

    final Offset center = Offset(size.width / 2, size.height / 2);
    final double radius = min(size.width, size.height) * 0.12;
    canvas.drawCircle(center, radius, lineGlow);
    canvas.drawCircle(center, radius, line..color = court.withOpacity(0.72));
    canvas.drawCircle(center, radius * 0.62, Paint()..color = court.withOpacity(0.045));
  }

  void _drawFlash(Canvas canvas, Size size) {
    if (engine.flash <= 0.02) return;
    final Offset center = Offset(engine.flashSide > 0 ? size.width : 0, size.height / 2);
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: engine.flashSide > 0 ? Alignment.centerRight : Alignment.centerLeft,
          radius: 1.1,
          colors: <Color>[
            engine.flashColor.withOpacity((engine.flash * 0.5).clamp(0, 1).toDouble()),
            engine.flashColor.withOpacity(0),
          ],
        ).createShader(Rect.fromCircle(center: center, radius: max(size.width, size.height) * 0.75)),
    );
  }

  void _drawTrail(Canvas canvas) {
    final ShopItem trailItem = save.selectedItem(ItemCategory.trail);
    final Color? color = trailItem.color1;
    if (color == null) return;
    for (final TrailBody point in engine.trail) {
      canvas.drawCircle(
        Offset(point.x, point.y),
        engine.ball.radius * (0.48 + point.life * 0.95),
        Paint()..color = color.withOpacity((point.life * 0.38).clamp(0, 1).toDouble()),
      );
    }
  }

  void _drawPowerUp(Canvas canvas) {
    final FieldPowerUp? powerUp = engine.activePowerUp;
    if (powerUp == null) return;
    final Offset center = Offset(powerUp.x, powerUp.y);
    final double pulse = 0.72 + 0.32 * sin(powerUp.pulse);
    canvas.drawCircle(center, powerUp.radius * 1.85, Paint()..color = powerUp.color.withOpacity(0.17 * pulse));
    canvas.drawCircle(center, powerUp.radius * 1.35, Paint()..color = powerUp.color.withOpacity(0.08 * pulse));
    canvas.drawCircle(
      center,
      powerUp.radius,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            Colors.white.withOpacity(0.98),
            powerUp.color.withOpacity(0.94),
            powerUp.color.withOpacity(0.56),
          ],
        ).createShader(Rect.fromCircle(center: center, radius: powerUp.radius)),
    );
    canvas.drawCircle(
      center,
      powerUp.radius + sin(powerUp.pulse * 2) * 6,
      Paint()
        ..color = powerUp.color.withOpacity(0.62)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.9,
    );
    canvas.drawCircle(
      center,
      powerUp.radius + 12 + sin(powerUp.pulse * 1.4) * 4,
      Paint()
        ..color = powerUp.color.withOpacity(0.25)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6,
    );
    final TextPainter text = TextPainter(
      text: TextSpan(text: powerUp.emoji, style: TextStyle(fontSize: powerUp.radius * 1.22)),
      textDirection: TextDirection.rtl,
    )..layout();
    text.paint(canvas, Offset(powerUp.x - text.width / 2, powerUp.y - text.height / 2 - 2));
    _paintCenteredText(
      canvas,
      powerUp.name,
      Offset(powerUp.x, powerUp.y + powerUp.radius + 6),
      TextStyle(fontSize: 10.8 * engine.scale, fontWeight: FontWeight.w800, color: powerUp.color.withOpacity(0.98)),
    );
  }

  void _drawPaddles(Canvas canvas) {
    final ShopItem selected = save.selectedItem(ItemCategory.paddle);
    Color first = selected.color1 ?? const Color(0xFF00E5FF);
    Color second = selected.color2 ?? const Color(0xFF0066FF);
    if (selected.rainbow) {
      final double hue = (engine.time * 90) % 360;
      first = HSVColor.fromAHSV(1, hue, 1, 1).toColor();
      second = HSVColor.fromAHSV(1, (hue + 80) % 360, 1, 0.95).toColor();
    }
    _drawPaddle(canvas, engine.player, first, second, sideGlow: const Color(0xFF00E5FF));
    _drawPaddle(canvas, engine.opponent, const Color(0xFFFF2FD6), const Color(0xFF7A2BFF), sideGlow: const Color(0xFFFF2FD6));
  }

  void _drawPaddle(Canvas canvas, PaddleBody paddle, Color first, Color second, {required Color sideGlow}) {
    final Rect rect = Rect.fromCenter(
      center: Offset(paddle.x, paddle.y),
      width: paddle.width,
      height: paddle.height,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect.inflate(7), Radius.circular(paddle.width / 2 + 8)),
      Paint()..color = sideGlow.withOpacity(0.10),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect.inflate(2.2), Radius.circular(paddle.width / 2 + 2.2)),
      Paint()..color = first.withOpacity(0.32),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, Radius.circular(paddle.width / 2)),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[first, Colors.white, second],
          stops: const <double>[0.0, 0.48, 1.0],
        ).createShader(rect),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(rect.left + rect.width * 0.18, rect.top + 4, rect.width * 0.26, rect.height - 8),
        Radius.circular(paddle.width / 4),
      ),
      Paint()..color = Colors.white.withOpacity(0.17),
    );
  }

  void _drawShield(Canvas canvas) {
    if (!engine.shieldActive) return;
    final PaddleBody paddle = engine.player;
    final double pulse = 0.62 + sin(engine.time * 8) * 0.24;
    final double wallHeight = min(engine.viewport.height * 0.68, paddle.height * 2.35);
    final Rect wall = Rect.fromCenter(
      center: Offset(max(10 * engine.scale, paddle.x - paddle.width * 2.4), paddle.y),
      width: 8 * engine.scale,
      height: wallHeight,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(wall.inflate(8 * engine.scale), Radius.circular(12 * engine.scale)),
      Paint()..color = const Color(0xFFB388FF).withOpacity(0.10 * pulse),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(wall, Radius.circular(6 * engine.scale)),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            const Color(0xFFB388FF).withOpacity(0.25),
            const Color(0xFFE1BEE7).withOpacity(pulse),
            const Color(0xFF7C4DFF).withOpacity(0.30),
          ],
        ).createShader(wall),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(wall.inflate(4 * engine.scale), Radius.circular(9 * engine.scale)),
      Paint()
        ..color = const Color(0xFFB388FF).withOpacity(0.50 * pulse)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8 * engine.scale,
    );
  }

  void _drawBall(Canvas canvas, BallBody ball, {required double opacity}) {
    final ShopItem selected = save.selectedItem(ItemCategory.ball);
    Color core = selected.color1 ?? Colors.white;
    Color middle = selected.color2 ?? const Color(0xFFBFF6FF);
    Color edge = selected.color3 ?? const Color(0xFF37D6FF);
    if (selected.rainbow) {
      final double hue = (engine.time * 140) % 360;
      middle = HSVColor.fromAHSV(1, hue, 1, 1).toColor();
      edge = HSVColor.fromAHSV(1, (hue + 60) % 360, 1, 0.95).toColor();
      core = Colors.white;
    }
    final Rect rect = Rect.fromCircle(center: Offset(ball.x, ball.y), radius: ball.radius);
    canvas.drawCircle(Offset(ball.x, ball.y), ball.radius * 1.7, Paint()..color = middle.withOpacity(0.28 * opacity));
    canvas.drawCircle(
      Offset(ball.x, ball.y),
      ball.radius,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.3, -0.3),
          colors: <Color>[
            core.withOpacity(opacity),
            middle.withOpacity(opacity),
            edge.withOpacity(opacity),
          ],
        ).createShader(rect),
    );
  }

  void _drawParticles(Canvas canvas) {
    for (final ParticleBody particle in engine.particles) {
      canvas.drawCircle(
        Offset(particle.x, particle.y),
        particle.size,
        Paint()..color = particle.color.withOpacity((particle.life / particle.maxLife).clamp(0, 1).toDouble()),
      );
    }
  }

  void _drawVignette(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const RadialGradient(
          radius: 0.88,
          colors: <Color>[Colors.transparent, Color(0x8800000A)],
        ).createShader(Offset.zero & size),
    );
  }

  void _drawScore(Canvas canvas, double width) {
    if (engine.state == GameState.menu) return;
    final double cardWidth = 232 * engine.scale;
    final double cardHeight = 84 * engine.scale;
    final RRect panel = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(width / 2, 56 * engine.scale), width: cardWidth, height: cardHeight),
      Radius.circular(28 * engine.scale),
    );
    canvas.drawRRect(
      panel,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xA41B2143), Color(0xD00B1023)],
        ).createShader(panel.outerRect),
    );
    canvas.drawRRect(
      panel,
      Paint()
        ..color = Colors.white.withOpacity(0.06)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2,
    );
    canvas.drawLine(
      Offset(width / 2, 26 * engine.scale),
      Offset(width / 2, 82 * engine.scale),
      Paint()..color = Colors.white.withOpacity(0.08)..strokeWidth = 1.1,
    );

    final TextStyle base = TextStyle(fontSize: 50 * engine.scale, fontWeight: FontWeight.w900);
    _paintCenteredText(canvas, faNumber(engine.scorePlayer), Offset(width / 2 - 56 * engine.scale, 18 * engine.scale), base.copyWith(color: const Color(0xFF00E5FF)));
    _paintCenteredText(canvas, faNumber(engine.scoreOpponent), Offset(width / 2 + 56 * engine.scale, 18 * engine.scale), base.copyWith(color: const Color(0xFFFF2FD6)));
    final TextStyle label = TextStyle(fontSize: 12.4 * engine.scale, fontWeight: FontWeight.w700);
    _paintCenteredText(canvas, engine.mode == GameMode.bot ? 'تو' : 'بازیکن ۱', Offset(width / 2 - 56 * engine.scale, 54 * engine.scale), label.copyWith(color: const Color(0xAA8FF4FF)));
    _paintCenteredText(canvas, engine.mode == GameMode.bot ? 'ربات' : 'بازیکن ۲', Offset(width / 2 + 56 * engine.scale, 54 * engine.scale), label.copyWith(color: const Color(0xAAFFB8EC)));
  }

  void _drawServe(Canvas canvas, Size size) {
    final double progress = 1 - engine.serveTimer;
    canvas.drawCircle(
      Offset(engine.ball.x, engine.ball.y),
      engine.ball.radius + progress * 46 * engine.scale,
      Paint()
        ..color = Colors.white.withOpacity((0.72 * (1 - progress)).clamp(0, 1).toDouble())
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
    _paintCenteredText(
      canvas,
      'آماده...',
      Offset(size.width / 2, size.height / 2 - 74 * engine.scale),
      TextStyle(
        fontSize: 22 * engine.scale,
        fontWeight: FontWeight.w800,
        color: Colors.white.withOpacity(0.64 + 0.34 * sin(engine.time * 8)),
      ),
    );
  }

  void _paintCenteredText(Canvas canvas, String value, Offset center, TextStyle style) {
    final TextPainter painter = TextPainter(
      text: TextSpan(text: value, style: style),
      textDirection: TextDirection.rtl,
      textAlign: TextAlign.center,
    )..layout();
    painter.paint(canvas, Offset(center.dx - painter.width / 2, center.dy));
  }

  @override
  bool shouldRepaint(covariant PongPainter oldDelegate) => true;
}
