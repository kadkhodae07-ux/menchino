import 'package:flutter/material.dart';

class GameTheme {
  final String id;
  final String label;
  final Brightness brightness;
  final Color bg;
  final Color panel;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color danger;
  final Color gold;
  final Color text;
  final Color dim;
  final Color canvasBg;
  final Color grid;
  final Color center;
  final Color top;
  final Color bottom;
  final Color ball;
  final Color trail;

  const GameTheme({
    required this.id,
    required this.label,
    required this.brightness,
    required this.bg,
    required this.panel,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.danger,
    required this.gold,
    required this.text,
    required this.dim,
    required this.canvasBg,
    required this.grid,
    required this.center,
    required this.top,
    required this.bottom,
    required this.ball,
    required this.trail,
  });
}

class Themes {
  static const dark = GameTheme(
    id: 'dark',
    label: 'نئون شب',
    brightness: Brightness.dark,
    bg: Color(0xFF050915),
    panel: Color(0xF011192B),
    primary: Color(0xFF52C7E8),
    secondary: Color(0xFF8978E8),
    accent: Color(0xFF35D8B2),
    danger: Color(0xFFE85C91),
    gold: Color(0xFFE9C768),
    text: Color(0xFFF3F7FC),
    dim: Color(0xFF9CA9C2),
    canvasBg: Color(0xFF030712),
    grid: Color(0x103BC0E0),
    center: Color(0xFF4AC6E6),
    top: Color(0xFF8A79E7),
    bottom: Color(0xFF32D3AE),
    ball: Color(0xFFF2F7FC),
    trail: Color(0xFF55C8E7),
  );

  static const light = GameTheme(
    id: 'light',
    label: 'کریستال',
    brightness: Brightness.light,
    bg: Color(0xFFF2F5FA),
    panel: Color(0xFAFFFFFF),
    primary: Color(0xFF3F6FB6),
    secondary: Color(0xFF6F5AB8),
    accent: Color(0xFF2C8F7B),
    danger: Color(0xFFC74C78),
    gold: Color(0xFFB9852F),
    text: Color(0xFF182131),
    dim: Color(0xFF667187),
    canvasBg: Color(0xFFE8EEF6),
    grid: Color(0x103F6FB6),
    center: Color(0xFF4A78B8),
    top: Color(0xFF7563BC),
    bottom: Color(0xFF328F7D),
    ball: Color(0xFF172231),
    trail: Color(0xFF4A78B8),
  );

  static const girly = GameTheme(
    id: 'girly',
    label: 'بلوسوم',
    brightness: Brightness.dark,
    bg: Color(0xFF140B16),
    panel: Color(0xF0241428),
    primary: Color(0xFFE58BB8),
    secondary: Color(0xFFB28BD8),
    accent: Color(0xFFE9B7CF),
    danger: Color(0xFFE2638C),
    gold: Color(0xFFE8C66C),
    text: Color(0xFFFFF4F9),
    dim: Color(0xFFC9A2B9),
    canvasBg: Color(0xFF110812),
    grid: Color(0x10E58BB8),
    center: Color(0xFFE496BC),
    top: Color(0xFFB995DD),
    bottom: Color(0xFFE7B4CD),
    ball: Color(0xFFFFF3F9),
    trail: Color(0xFFE38CB8),
  );

  static const boyish = GameTheme(
    id: 'boyish',
    label: 'سایبر اسپرت',
    brightness: Brightness.dark,
    bg: Color(0xFF071014),
    panel: Color(0xF00E1C24),
    primary: Color(0xFF4DA7D0),
    secondary: Color(0xFF48B58A),
    accent: Color(0xFF9ECA58),
    danger: Color(0xFFD77B50),
    gold: Color(0xFFD9BC58),
    text: Color(0xFFF0F8FA),
    dim: Color(0xFF91A8B0),
    canvasBg: Color(0xFF041014),
    grid: Color(0x104DA7D0),
    center: Color(0xFF54AED4),
    top: Color(0xFF4AB98D),
    bottom: Color(0xFF9BCB56),
    ball: Color(0xFFF1F8FA),
    trail: Color(0xFF4FA9D0),
  );

  static const child = GameTheme(
    id: 'child',
    label: 'فان پاپ',
    brightness: Brightness.light,
    bg: Color(0xFFFFF6E8),
    panel: Color(0xFAFFFDF8),
    primary: Color(0xFFE9893F),
    secondary: Color(0xFF7869C8),
    accent: Color(0xFF43A994),
    danger: Color(0xFFD65E77),
    gold: Color(0xFFD6A936),
    text: Color(0xFF362A4D),
    dim: Color(0xFF756887),
    canvasBg: Color(0xFFFFF0D8),
    grid: Color(0x10E9893F),
    center: Color(0xFFE99043),
    top: Color(0xFF7A6AC9),
    bottom: Color(0xFF45AA94),
    ball: Color(0xFF392D4F),
    trail: Color(0xFFE78A40),
  );

  static const all = [dark, light, girly, boyish, child];

  static GameTheme byId(String? id) =>
      all.firstWhere((theme) => theme.id == id, orElse: () => dark);
}
