import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class ChatScreen extends StatefulWidget {
  final String? initialFriendId;

  const ChatScreen({super.key, this.initialFriendId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _public = true;
  String? _friendId;

  @override
  void initState() {
    super.initState();
    _friendId = widget.initialFriendId;
    _public = _friendId == null;
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final selectedFriend = _findFriend(state);
    final messages = _public
        ? state.publicChat
        : _friendId == null
            ? const <Map<String, dynamic>>[]
            : state.privateChat[_friendId] ?? const <Map<String, dynamic>>[];

    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: theme.bg,
      appBar: AppBar(
        title: const Text('چت'),
        actions: [
          IconButton(
            tooltip: 'پاک کردن گفتگو',
            onPressed: messages.isEmpty
                ? null
                : () async {
                    final ok = await showNeonConfirm(
                      context,
                      title: 'پاک کردن گفتگو',
                      message: 'پیام‌های این گفتگو از روی دستگاه پاک می‌شوند.',
                      confirmLabel: 'پاک کردن',
                      danger: true,
                    );
                    if (!ok) return;
                    await state.clearChat(isPublic: _public, friendId: _friendId);
                  },
            icon: AppIcons.icon('close', color: messages.isEmpty ? theme.dim : theme.danger),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
              child: NeonPanel(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                      child: _ModeButton(
                        label: 'عمومی',
                        icon: 'chat',
                        active: _public,
                        color: theme.primary,
                        onTap: () => setState(() {
                          _public = true;
                          _friendId = null;
                        }),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ModeButton(
                        label: 'خصوصی',
                        icon: 'friends',
                        active: !_public,
                        color: theme.secondary,
                        onTap: () => setState(() => _public = false),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: NeonPanel(
                  padding: EdgeInsets.zero,
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(14, 11, 14, 10),
                        decoration: BoxDecoration(
                          border: Border(bottom: BorderSide(color: theme.dim.withOpacity(.10))),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(shape: BoxShape.circle, color: theme.accent.withOpacity(.85)),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _public
                                    ? 'گفتگوی محلی • پیام‌ها روی همین دستگاه ذخیره می‌شوند'
                                    : selectedFriend == null
                                        ? 'یک بازیکن محلی را انتخاب کن'
                                        : 'گفتگو با ${selectedFriend['name']}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(color: theme.dim, fontSize: 11, fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: !_public && selectedFriend == null
                            ? _friendPicker(state)
                            : messages.isEmpty
                                ? _emptyState(theme)
                                : ListView.builder(
                                    controller: _scrollController,
                                    padding: const EdgeInsets.fromLTRB(12, 14, 12, 8),
                                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                                    itemCount: messages.length,
                                    itemBuilder: (context, index) => _bubble(messages[index], theme),
                                  ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (_public || selectedFriend != null)
              AnimatedPadding(
                duration: const Duration(milliseconds: 120),
                padding: EdgeInsets.fromLTRB(16, 10, 16, 12 + MediaQuery.viewPaddingOf(context).bottom),
                child: _composer(state, theme),
              ),
          ],
        ),
      ),
    );
  }

  Widget _friendPicker(AppState state) {
    final theme = state.theme;
    if (state.friends.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppIcons.icon('friends', size: 38, color: theme.dim),
              const SizedBox(height: 10),
              Text('هنوز بازیکن محلی اضافه نکردی.', textAlign: TextAlign.center, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text('از بخش «دوستانه» یک نام اضافه کن تا گفتگو و مسابقه محلی داشته باشی.', textAlign: TextAlign.center, style: TextStyle(color: theme.dim, height: 1.6, fontSize: 12)),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: state.friends.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final friend = state.friends[index];
        final id = '${friend['id']}';
        final count = (state.privateChat[id] ?? const []).length;
        return GestureDetector(
          onTap: () => setState(() => _friendId = id),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: theme.secondary.withOpacity(.07),
              border: Border.all(color: theme.secondary.withOpacity(.18)),
            ),
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: theme.secondary.withOpacity(.14)),
                  child: Center(child: AppIcons.icon('profile', size: 19, color: theme.secondary)),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text('${friend['name']}', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900))),
                StatBadge('$count پیام', color: theme.secondary),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _emptyState(dynamic theme) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppIcons.icon('chat', size: 40, color: theme.dim),
              const SizedBox(height: 10),
              Text('هنوز پیامی نیست', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text('اولین پیام را بنویس.', style: TextStyle(color: theme.dim, fontSize: 12)),
            ],
          ),
        ),
      );

  Widget _composer(AppState state, dynamic theme) => Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: theme.panel.withOpacity(.92),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.primary.withOpacity(.18)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 14, offset: const Offset(0, 8))],
        ),
        child: Row(
          children: [
            if (!_public)
              IconButton(
                tooltip: 'تغییر بازیکن',
                onPressed: () => setState(() => _friendId = null),
                icon: AppIcons.icon('friends', color: theme.secondary),
              ),
            Expanded(
              child: TextField(
                controller: _controller,
                style: TextStyle(color: theme.text),
                minLines: 1,
                maxLines: 3,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(state),
                decoration: InputDecoration(
                  isDense: true,
                  hintText: 'پیام بنویس...',
                  hintStyle: TextStyle(color: theme.dim),
                  filled: true,
                  fillColor: theme.bg.withOpacity(.28),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _send(state),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: theme.accent.withOpacity(.16),
                  border: Border.all(color: theme.accent.withOpacity(.28)),
                ),
                child: Center(child: AppIcons.icon('send', color: theme.accent)),
              ),
            ),
          ],
        ),
      );

  Map<String, dynamic>? _findFriend(AppState state) {
    for (final friend in state.friends) {
      if ('${friend['id']}' == _friendId) return friend;
    }
    return null;
  }

  Widget _bubble(Map<String, dynamic> message, dynamic theme) {
    final me = message['from'] == 'me';
    final color = me ? theme.accent : theme.secondary;
    return Align(
      alignment: me ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 310),
        margin: const EdgeInsets.only(bottom: 9),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(17),
            topRight: const Radius.circular(17),
            bottomLeft: Radius.circular(me ? 5 : 17),
            bottomRight: Radius.circular(me ? 17 : 5),
          ),
          color: color.withOpacity(.10),
          border: Border.all(color: color.withOpacity(.24)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_public && !me) ...[
              Text('${message['name'] ?? ''}', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 11)),
              const SizedBox(height: 3),
            ],
            Text('${message['text'] ?? ''}', style: TextStyle(color: theme.text, height: 1.5)),
            const SizedBox(height: 4),
            Text('${message['time'] ?? ''}', style: TextStyle(color: theme.dim, fontSize: 9)),
          ],
        ),
      ),
    );
  }

  Future<void> _send(AppState state) async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _controller.clear();
    if (_public) {
      await state.sendPublic(text);
    } else if (_friendId != null) {
      await state.sendPrivate(_friendId!, text);
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
    );
  }
}

class _ModeButton extends StatelessWidget {
  final String label;
  final String icon;
  final bool active;
  final Color color;
  final VoidCallback onTap;

  const _ModeButton({required this.label, required this.icon, required this.active, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: active ? color.withOpacity(.14) : Colors.transparent,
          border: Border.all(color: active ? color.withOpacity(.42) : state.theme.dim.withOpacity(.10)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppIcons.icon(icon, size: 17, color: active ? color : state.theme.dim),
            const SizedBox(width: 7),
            Text(label, style: TextStyle(color: active ? state.theme.text : state.theme.dim, fontWeight: FontWeight.w900, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
