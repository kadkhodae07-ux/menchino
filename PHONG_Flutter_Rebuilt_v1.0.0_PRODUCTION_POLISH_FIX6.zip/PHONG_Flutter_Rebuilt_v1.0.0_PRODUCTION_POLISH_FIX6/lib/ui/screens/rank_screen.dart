import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class RankScreen extends StatelessWidget {
  const RankScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final tier = _tierFor(state.leaguePoints);
    final next = _nextTier(state.leaguePoints);
    final start = tier.min;
    final end = next?.min ?? tier.min + 400;
    final ratio = ((state.leaguePoints - start) / (end - start)).clamp(0.0, 1.0).toDouble();

    return SafeArea(
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('لیگ شخصی', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 24)),
            const SizedBox(height: 4),
            Text('این نسخه رتبه ساختگی نمایش نمی‌دهد؛ فقط پیشرفت واقعی خودت ثبت می‌شود.', style: TextStyle(color: theme.dim, fontSize: 12, height: 1.55)),
            const SizedBox(height: 14),
            NeonPanel(
              borderColor: tier.color,
              child: Column(
                children: [
                  Container(
                    width: 84,
                    height: 84,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: tier.color.withOpacity(.10),
                      border: Border.all(color: tier.color.withOpacity(.34)),
                      boxShadow: [BoxShadow(color: tier.color.withOpacity(.16), blurRadius: 24)],
                    ),
                    child: Center(child: AppIcons.icon('rank', size: 40, color: tier.color)),
                  ),
                  const SizedBox(height: 10),
                  Text(tier.name, style: TextStyle(color: theme.text, fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text('${state.leaguePoints} امتیاز لیگ', style: TextStyle(color: tier.color, fontWeight: FontWeight.w900, fontSize: 16)),
                  const SizedBox(height: 14),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      minHeight: 10,
                      value: ratio,
                      color: tier.color,
                      backgroundColor: tier.color.withOpacity(.10),
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    next == null ? 'بالاترین سطح لیگ' : '${next.min - state.leaguePoints} امتیاز تا ${next.name}',
                    style: TextStyle(color: theme.dim, fontSize: 11),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            NeonPanel(
              child: Column(
                children: [
                  _row(theme, 'فصل', state.season),
                  _divider(theme),
                  _row(theme, 'مسابقه‌ها', '${state.stats['matches'] ?? 0}'),
                  _divider(theme),
                  _row(theme, 'بردها', '${state.stats['wins'] ?? 0}'),
                  _divider(theme),
                  _row(theme, 'بهترین رالی', '${state.stats['bestRally'] ?? 0}'),
                  _divider(theme),
                  _row(theme, 'بهترین برد پیاپی', '${state.stats['bestStreak'] ?? 0}'),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Text('سطوح لیگ', style: TextStyle(color: theme.text, fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            for (final item in _tiers) ...[
              NeonPanel(
                borderColor: item.color,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Row(
                  children: [
                    AppIcons.icon('rank', size: 22, color: item.color),
                    const SizedBox(width: 10),
                    Expanded(child: Text(item.name, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900))),
                    Text('${item.min}+ امتیاز', style: TextStyle(color: item.color, fontWeight: FontWeight.w800, fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(height: 9),
            ],
          ],
        ),
      ),
    );
  }

  Widget _row(dynamic theme, String label, String value) => Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: theme.dim, fontSize: 13))),
          Text(value, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
        ],
      );

  Widget _divider(dynamic theme) => Divider(height: 18, color: theme.dim.withOpacity(.10));

  _LeagueTier _tierFor(int points) {
    var current = _tiers.first;
    for (final tier in _tiers) {
      if (points >= tier.min) current = tier;
    }
    return current;
  }

  _LeagueTier? _nextTier(int points) {
    for (final tier in _tiers) {
      if (tier.min > points) return tier;
    }
    return null;
  }
}

class _LeagueTier {
  final String name;
  final int min;
  final Color color;

  const _LeagueTier(this.name, this.min, this.color);
}

const _tiers = [
  _LeagueTier('برنزی', 0, Color(0xFFC98055)),
  _LeagueTier('نقره‌ای', 200, Color(0xFFC7D2E5)),
  _LeagueTier('طلایی', 500, Color(0xFFFFD66A)),
  _LeagueTier('پلاتینیوم', 900, Color(0xFF62E6FF)),
  _LeagueTier('الماس', 1400, Color(0xFF9A84FF)),
];
