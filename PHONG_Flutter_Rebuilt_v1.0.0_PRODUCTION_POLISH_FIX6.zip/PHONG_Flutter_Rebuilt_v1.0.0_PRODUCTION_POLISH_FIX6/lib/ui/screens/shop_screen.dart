import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  String _tab = 'rackets';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('فروشگاه تجهیزات', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 23)),
                      const SizedBox(height: 3),
                      Text('پیش‌نمایش هر آیتم قبل از خرید یا تجهیز', style: TextStyle(color: theme.dim, fontSize: 12)),
                    ],
                  ),
                ),
                Chip3D(text: '${state.coins}'),
              ],
            ),
            const SizedBox(height: 12),
            NeonPanel(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(child: _TabButton(label: 'راکت‌ها', icon: 'racket', active: _tab == 'rackets', onTap: () => setState(() => _tab = 'rackets'))),
                  const SizedBox(width: 8),
                  Expanded(child: _TabButton(label: 'توپ‌ها', icon: 'ball', active: _tab == 'balls', onTap: () => setState(() => _tab = 'balls'))),
                  const SizedBox(width: 8),
                  Expanded(child: _TabButton(label: 'آرناها', icon: 'arena', active: _tab == 'arenas', onTap: () => setState(() => _tab = 'arenas'))),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.only(bottom: 20),
                itemCount: Catalog.of(_tab).length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final item = Catalog.of(_tab)[index];
                  final owned = state.owned.contains(item.id);
                  final equipped = state.selected[item.type] == item.id;
                  final color = rarityColor[item.rarity] ?? theme.primary;
                  return NeonPanel(
                    borderColor: color,
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _ItemPreview(item: item, color: color),
                        const SizedBox(height: 12),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: color.withOpacity(.08),
                                border: Border.all(color: color.withOpacity(.20)),
                              ),
                              child: Center(child: AppIcons.icon(item.icon, size: 24, color: color)),
                            ),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 16)),
                                  const SizedBox(height: 3),
                                  Text(rarityLabel[item.rarity] ?? item.rarity, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
                                  const SizedBox(height: 4),
                                  Text(item.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim, fontSize: 12, height: 1.5)),
                                ],
                              ),
                            ),
                            if (equipped) StatBadge('فعال', color: theme.accent),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Wrap(spacing: 6, runSpacing: 6, children: _itemStats(item).map((text) => StatBadge(text, color: color)).toList()),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            if (!owned) Chip3D(text: item.price == 0 ? 'رایگان' : '${item.price}'),
                            if (owned) StatBadge('خریداری شده', color: theme.accent),
                            const Spacer(),
                            if (equipped)
                              NeonButton(label: 'تجهیز شده', icon: 'check', small: true, color: theme.accent, onTap: null)
                            else if (owned)
                              NeonButton(
                                label: 'تجهیز',
                                icon: 'check',
                                small: true,
                                color: theme.accent,
                                onTap: () async {
                                  await state.equip(item);
                                  if (context.mounted) showNeonMessage(context, '${item.name} تجهیز شد.');
                                },
                              )
                            else
                              NeonButton(
                                label: 'خرید',
                                icon: 'shop',
                                small: true,
                                color: theme.gold,
                                onTap: () async {
                                  final success = await state.buy(item);
                                  if (!context.mounted) return;
                                  showNeonMessage(context, success ? '${item.name} خریداری شد.' : 'سکه کافی نیست.');
                                },
                              ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<String> _itemStats(Item item) {
    final stats = item.stats;
    final result = <String>[];
    void add(String key, String label, {double defaultValue = 1}) {
      final value = stats[key];
      if (value != null && value != defaultValue) result.add('$label ×${_fmt(value)}');
    }

    add('widthMult', 'عرض');
    add('spinMult', 'اسپین');
    add('moveSpeedMult', 'سرعت حرکت');
    add('speedMult', 'سرعت توپ');
    add('radiusMult', 'اندازه');
    add('powerRate', 'پاورآپ');
    add('speedIncrementMult', 'رشد سرعت');
    add('baseSpeedMult', 'سرعت پایه');
    add('maxSpeedMult', 'حداکثر سرعت');
    add('powerDurationMult', 'مدت پاورآپ');
    add('aiSpeedMult', 'سرعت حریف');
    if ((stats['hitSpeed'] ?? 0) > 0) result.add('ضربه +${_fmt(stats['hitSpeed']!)}');
    if ((stats['magnet'] ?? 0) > 0) result.add('جذب توپ');
    if ((stats['startShield'] ?? 0) > 0) result.add('سپر ابتدایی');
    if ((stats['echoSlow'] ?? 0) > 0) result.add('اکو');
    if ((stats['aiErrorBonus'] ?? 0) > 0) result.add('خطای دید حریف');
    if ((stats['coinBonus'] ?? 0) > 0) result.add('سکه +${(stats['coinBonus']! * 100).round()}٪');
    if ((stats['curve'] ?? 0) > 0) result.add('مسیر خمیده');
    if ((stats['minVerticalBonus'] ?? 0) > 0) result.add('کنترل بیشتر');
    if ((stats['sideInset'] ?? 0) > 0) result.add('زمین فشرده');
    if (result.isEmpty) result.add('متعادل');
    return result;
  }

  String _fmt(double value) => value == value.roundToDouble() ? value.round().toString() : value.toStringAsFixed(2);
}

class _TabButton extends StatelessWidget {
  final String label;
  final String icon;
  final bool active;
  final VoidCallback onTap;

  const _TabButton({required this.label, required this.icon, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final theme = state.theme;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: active ? theme.primary.withOpacity(.14) : Colors.transparent,
          border: Border.all(color: active ? theme.primary.withOpacity(.38) : theme.dim.withOpacity(.08)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppIcons.icon(icon, size: 17, color: active ? theme.primary : theme.dim),
            const SizedBox(width: 6),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? theme.text : theme.dim, fontWeight: FontWeight.w900, fontSize: 12))),
          ],
        ),
      ),
    );
  }
}

class _ItemPreview extends StatelessWidget {
  final Item item;
  final Color color;

  const _ItemPreview({required this.item, required this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return SizedBox(
      height: 104,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: CustomPaint(
          painter: _PreviewPainter(item: item, color: color, bg: theme.canvasBg, grid: theme.grid),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

class _PreviewPainter extends CustomPainter {
  final Item item;
  final Color color;
  final Color bg;
  final Color grid;

  _PreviewPainter({required this.item, required this.color, required this.bg, required this.grid});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = bg);
    final soft = Paint()..color = color.withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .22, size.height * .35), size.height * .65, soft);
    canvas.drawCircle(Offset(size.width * .80, size.height * .70), size.height * .55, Paint()..color = color.withOpacity(.06));

    if (item.type == 'racket') {
      final length = (size.width * (.34 * (item.stats['widthMult'] ?? 1)).clamp(.25, .48)).toDouble();
      final r = Rect.fromCenter(center: Offset(size.width / 2, size.height / 2), width: length, height: 16);
      canvas.drawRRect(RRect.fromRectAndRadius(r.inflate(7), const Radius.circular(16)), Paint()..color = color.withOpacity(.10));
      canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(12)), Paint()..color = color);
      if (item.id == 'r_spin') {
        canvas.drawCircle(r.center, 9, Paint()..color = Colors.white.withOpacity(.38)..style = PaintingStyle.stroke..strokeWidth = 2);
      } else if (item.id == 'r_turbo') {
        for (var i = -2; i <= 2; i++) {
          canvas.drawLine(Offset(r.center.dx + i * 18, r.top + 2), Offset(r.center.dx + i * 18 + 9, r.bottom - 2), Paint()..color = Colors.white.withOpacity(.28)..strokeWidth = 2);
        }
      } else if (item.id == 'r_guardian') {
        canvas.drawRRect(RRect.fromRectAndRadius(r.inflate(7), const Radius.circular(18)), Paint()..color = color.withOpacity(.75)..style = PaintingStyle.stroke..strokeWidth = 2);
      }
    } else if (item.type == 'ball') {
      final radius = (14 * (item.stats['radiusMult'] ?? 1)).toDouble();
      final center = Offset(size.width / 2, size.height / 2);
      final ballColor = item.color ?? color;
      canvas.drawCircle(center, radius + 12, Paint()..color = ballColor.withOpacity(.10));
      canvas.drawCircle(center, radius, Paint()..color = ballColor);
      if (item.id == 'b_gold') {
        canvas.drawCircle(center, radius + 5, Paint()..color = color.withOpacity(.85)..style = PaintingStyle.stroke..strokeWidth = 2);
      } else if (item.id == 'b_plasma') {
        canvas.drawCircle(center, radius + 7, Paint()..color = ballColor.withOpacity(.60)..style = PaintingStyle.stroke..strokeWidth = 1.5);
        canvas.drawCircle(center, radius + 13, Paint()..color = ballColor.withOpacity(.25)..style = PaintingStyle.stroke..strokeWidth = 1);
      } else if (item.id == 'b_ghost') {
        canvas.drawCircle(center + const Offset(8, 0), radius, Paint()..color = ballColor.withOpacity(.22));
      }
    } else {
      final line = Paint()..color = grid.withOpacity(.55)..strokeWidth = 1;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(12, 12, size.width - 24, size.height - 24), const Radius.circular(18)), Paint()..color = color.withOpacity(.45)..style = PaintingStyle.stroke..strokeWidth = 1.2);
      canvas.drawLine(Offset(size.width / 2, 12), Offset(size.width / 2, size.height - 12), line);
      canvas.drawCircle(Offset(size.width / 2, size.height / 2), 13, Paint()..color = color.withOpacity(.34)..style = PaintingStyle.stroke..strokeWidth = 1.2);
      if (item.id == 'a_speed') {
        for (var y = 28.0; y < size.height - 18; y += 24) {
          canvas.drawLine(Offset(28, y), Offset(50, y), Paint()..color = color.withOpacity(.34)..strokeWidth = 3);
          canvas.drawLine(Offset(size.width - 50, y), Offset(size.width - 28, y), Paint()..color = color.withOpacity(.34)..strokeWidth = 3);
        }
      } else if (item.id == 'a_void') {
        canvas.drawCircle(Offset(size.width / 2, size.height / 2), 30, Paint()..color = Colors.black.withOpacity(.40));
        canvas.drawCircle(Offset(size.width / 2, size.height / 2), 34, Paint()..color = color.withOpacity(.40)..style = PaintingStyle.stroke..strokeWidth = 1.4);
      } else if (item.id == 'a_fortune') {
        canvas.drawCircle(const Offset(30, 30), 5, Paint()..color = color);
        canvas.drawCircle(Offset(size.width - 30, size.height - 30), 5, Paint()..color = color);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PreviewPainter oldDelegate) => oldDelegate.item.id != item.id || oldDelegate.color != color || oldDelegate.bg != bg;
}
