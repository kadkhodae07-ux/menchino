import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'lobby_screen.dart';
import 'missions_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'shop_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 2;

  static const _screens = [
    ShopScreen(),
    MissionsScreen(),
    LobbyScreen(),
    RankScreen(),
    ProfileScreen(),
  ];

  static const _tabs = [
    ('shop', 'فروشگاه'),
    ('mission', 'ماموریت'),
    ('home', 'خانه'),
    ('rank', 'لیگ'),
    ('profile', 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return Scaffold(
      backgroundColor: theme.bg,
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        child: NeonPanel(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
          child: Row(
            children: List.generate(_tabs.length, (index) {
              final active = index == _index;
              final home = index == 2;
              final color = active ? theme.primary : theme.dim;
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    context.read<AppState>().audio.play('tap');
                    setState(() => _index = index);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 170),
                    transform: Matrix4.translationValues(0, home ? -5 : 0, 0),
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 170),
                          width: home ? 48 : 42,
                          height: home ? 48 : 42,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: active ? theme.primary.withOpacity(home ? .17 : .11) : Colors.transparent,
                            border: Border.all(color: active ? theme.primary.withOpacity(.36) : theme.dim.withOpacity(.08)),
                            boxShadow: active ? [BoxShadow(color: theme.primary.withOpacity(.13), blurRadius: 16)] : null,
                          ),
                          child: Center(child: AppIcons.icon(_tabs[index].$1, size: home ? 24 : 21, color: color)),
                        ),
                        AnimatedSize(
                          duration: const Duration(milliseconds: 150),
                          child: active
                              ? Padding(
                                  padding: const EdgeInsets.only(top: 3),
                                  child: Text(_tabs[index].$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontSize: 9, fontWeight: FontWeight.w900)),
                                )
                              : const SizedBox(height: 0),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
