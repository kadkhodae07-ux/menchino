# PULSE ARENA — نسخه 2.0.0+16

PULSE ARENA یک بازی رقابتی آفلاین Flutter/Flame با رابط کاربری فارسی، صفحات Portrait و مسابقه Landscape است. این نسخه بازطراحی حرفه‌ای Cyber-Neon را بر مبنای رنگ‌های Cyan و Magenta، پنل‌های گرافیکی، مسیر انتخاب حالت بازی، مأموریت و جایزه روزانه، فروشگاه، پروفایل، رتبه‌بندی آفلاین و تنظیمات کامل صدا ارائه می‌کند.

## مشخصات انتشار

- نسخه برنامه: `2.0.0+16`
- Package Name: `com.manyshah.pulsearena`
- Workflow: `WF12`
- خروجی‌های Android: Bazaar و Myket
- حالت‌های واقعی: بازی آفلاین و تمرین آزاد
- شرط برد مسابقه اصلی: اولین بازیکن با ۱۰ گل
- معماری ذخیره‌سازی: محلی و پایدار در Android SharedPreferences

## ساختار مهم

- `lib/core/design/`: توکن‌ها، پنل‌ها و نوارهای پیشرفت گرافیکی
- `lib/screens/hub_screen.dart`: هاب اصلی و کامپوننت‌های مشترک
- `lib/screens/hub/`: پروفایل، مأموریت‌ها، فروشگاه، رتبه‌بندی و تنظیمات
- `lib/screens/mode_selection_screen.dart`: انتخاب حالت واقعی بازی
- `lib/screens/game_screen.dart`: HUD، Pause، نتیجه برد/باخت و کنترل‌های مسابقه
- `lib/game/`: موتور Flame، فیزیک، مدیریت مسابقه، صدا و انتقال صحنه
- `test/`: تست‌های منطق، عملکرد و کنترل Release
- `tool/validate_release.py`: اعتبارسنجی ساختاری بدون وابستگی Flutter
- `.github/workflows/build-apk.yml`: Workflow ساخت بازار و مایکت

## اجرای کنترل‌ها

در محیط دارای Flutter 3.41.8 و Java 17:

```bash
flutter pub get
python3 tool/validate_release.py
dart format --output=none --set-exit-if-changed lib test
flutter analyze
flutter test
flutter build apk --release --flavor bazaar
flutter build apk --release --flavor myket
```

Workflow `WF12` همین مراحل را انجام می‌دهد، APKهای بازار و مایکت را با SHA-256 تحویل می‌دهد و در صورت شکست، بسته خطای کامل ایجاد می‌کند.

## وضعیت اعتبارسنجی این تحویل

کنترل ساختاری، توازن فایل‌های Dart، XMLهای Android، ابعاد Branding، محتوای Workflow، دو Flavor، Persistence، حالت تمرین، نبود حالت آنلاین ساختگی، سیستم صدا و بهینه‌سازی Asset در محیط فعلی با موفقیت انجام شده است.

Flutter SDK، Android SDK، Emulator و دستگاه Android در محیط محلی این تحویل در دسترس نبودند؛ بنابراین `flutter analyze`، `flutter test`، Build APK و بررسی تصویری Runtime به‌صورت محلی اجرا نشده‌اند. تأیید نهایی انتشار منوط به موفقیت `WF12` و تست APK روی دستگاه واقعی است.

گزارش‌های دقیق در پوشه `docs/` قرار دارند.
