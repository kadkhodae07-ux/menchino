# Workflow WF12

WF12 یک Hotfix زیرساختی برای خطای شناسایی سورس در اجرای شماره `30619550241` است.
نسخه برنامه و کد بازی بدون تغییر و برابر `2.0.0+16` باقی مانده‌اند.

## اصلاح اصلی

- شناسایی سورس از ZIP معتبر در هر عمق Repository
- شناسایی پروژه Flutter استخراج‌شده در ریشه یا پوشه‌های داخلی
- انتخاب جدیدترین سورس معتبر بر پایه زمان Commit و شماره‌های نام فایل
- کپی پروژه استخراج‌شده به مسیر موقت و Build خارج از Working Tree
- پشتیبانی از ZIP کامل تحویل، ZIP مستقل سورس و پوشه `Flutter_Source`
- ردکردن Failure Log، Keystore، APK/AAB Output، Git LFS Pointer و ZIP نامعتبر
- استخراج امن ZIP با جلوگیری از Path Traversal و Symbolic Link
- ثبت `source_kind`، `source_ref` و مسیر نهایی پروژه در Failure Logs
- اجرای Workflow روی هر Push شاخه `main`، نه فقط تغییر فایل ZIP

## زنجیره Build

- Flutter 3.41.8
- Java 17
- Gradle 8.9
- بررسی نسخه `2.0.0+16` و Package Name
- Validator داخلی، Flutter Clean، Pub Get، Dart Format، Analyze و Test
- ساخت APKهای Bazaar و Myket
- تولید `SHA256SUMS.txt`
- بارگذاری APKهای موفق یا Failure Logs کامل

## Secrets لازم برای Signing واقعی

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

اگر هیچ Secretای تنظیم نشده باشد، Debug Signing فقط برای تست Build استفاده می‌شود. خروجی فروشگاهی باید با Secrets واقعی ساخته شود.
