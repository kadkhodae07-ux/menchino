# گزارش ممیزی و ارتقای UI/UX — PULSE ARENA 2.0.0+16

## دامنه بررسی

کدهای هاب، صفحات فرعی، صفحه انتخاب حالت، HUD مسابقه، Pause، نتیجه مسابقه، Design System، Persistence، AudioManager، انتقال جهت صفحه، تست‌ها و Workflow بررسی و اصلاح شدند. اسکرین‌شات‌های مرجع صرفاً به‌عنوان معیار Art Direction استفاده شده‌اند و داخل برنامه قرار نگرفته‌اند.

## صفحات ارتقایافته

### خانه

- CTA اصلی «شروع بازی» به صفحه انتخاب حالت متصل شد.
- بازی آفلاین سریع و رتبه‌بندی آفلاین به Actionهای واقعی متصل هستند.
- رنگ‌های Cyan/Magenta/Gold با Design Token جدید هماهنگ شدند.
- انیمیشن Preview و پنل‌های موجود حفظ شدند تا هیچ منطق سالمی حذف نشود.

### انتخاب حالت بازی

- صفحه جدید Responsive و قابل‌ویرایش با CustomPainter ساخته شد.
- کارت‌های گرافیکی مستقل برای بازی آفلاین و تمرین آزاد ایجاد شدند.
- توضیح شفاف Offline بودن نسخه جایگزین نمایش قابلیت آنلاین ساختگی شد.

### پروفایل

- هدر بازیکن در بالای صفحه یکپارچه شد.
- آمار واقعی برد، باخت، مسابقه، نرخ برد، لیگ، تجهیزات و Match History حفظ شد.
- سازگاری تعداد مسابقات با مجموع برد و باخت در Persistence اصلاح شد.

### مأموریت‌ها

- پنل جایزه روزانه با Chest Graphic، Reward Chips، Streak و Claim State افزوده شد.
- Daily/Weekly missionها از داده واقعی Controller استفاده می‌کنند.
- Claim تکراری مسدود و دکمه دریافت‌شده واقعاً غیرفعال می‌شود.

### فروشگاه

- ساختار Featured Product، Product Card، Owned/Equipped و خرید Persisted حفظ شد.
- هدر سراسری و پالت جدید به صفحه اعمال شد.
- Skinهای انتخاب‌شده همچنان به Rendering واقعی مسابقه منتقل می‌شوند.

### رتبه‌بندی

- به Route مستقل منتقل شد.
- داده فعلی بازیکن از League Score واقعی خوانده می‌شود.
- ردیف‌های دیگر صریحاً «هسته هوش مصنوعی» هستند و کاربر آنلاین ساختگی نمایش داده نمی‌شود.
- Podium و ردیف کاربر فعلی حفظ و با پالت جدید هماهنگ شدند.

### تنظیمات

- صفحه کامل Settings به تب پایدار Bottom Navigation تبدیل شد.
- کنترل‌های اختصاصی برای Music، SFX، Vibration، Effects Quality و Frame Rate ساخته شد.
- حجم Music و SFX Persist می‌شود و در AudioManager اعمال می‌گردد.
- اطلاعات Offline Storage و نسخه برنامه شفاف نمایش داده می‌شود.

### مسابقه Landscape

- موتور فیزیک، کنترل راکت، Bot، شرط ده‌گل، Abilityها و سیستم صدا دست‌نخورده باقی ماندند.
- رنگ‌های HUD و Result با پالت Cyan/Magenta جدید هماهنگ شدند.
- Result Panel برای Training، برد و باخت وضعیت واقعی جداگانه دارد.
- نتیجه تمرین به هیچ آمار رقابتی ثبت نمی‌شود.

## کامپوننت‌ها و زیرساخت‌های افزوده یا اصلاح‌شده

- `PulseColors`, `PulseSpacing`, `PulseDurations`, `PulseTypography`
- `ModeSelectionScreen`
- `_GlobalPlayerHeader`, `_HeaderCurrency`
- `_DailyRewardPanel`, `_RewardChestPainter`, `_RewardChip`
- `_CyberVolumeSlider`, `_VolumeSliderPainter`
- `_StandaloneRankingScreen`
- Disabled State و Activation Debounce در `NeonPressable`
- `GameMode` و `GameConfig.training()`

## بهینه‌سازی عملکرد و Asset

- عناصر Decorator صفحه Mode Selection داخل `RepaintBoundary` قرار گرفتند.
- UI مسابقه از Progress Updateهای تمرین جدا شد.
- Route Transition بازی روی Fade کوتاه ۱۷۰ ms باقی ماند.
- Fixed-step physics با ۱۲۰ Hz و سقف iteration حفظ شد.
- موسیقی Loop از 2,822,444 بایت WAV به 228,432 بایت OGG تبدیل شد.
- هیچ Screenshot مرجع به‌عنوان UI Runtime استفاده نشده است.

## محدودیت‌های باقی‌مانده

- Online Backend در پروژه وجود ندارد؛ بنابراین Online Mode عمداً نمایش داده نمی‌شود.
- Font فارسی اختصاصی قابل‌توزیع در فایل مبنا وجود نداشت و فایل Font جدیدی به بسته اضافه نشده است؛ UI از Sans-serif سیستم استفاده می‌کند.
- تأیید تصویری Runtime، Frame Timing واقعی، Memory Profile و نصب APK به محیط Flutter/Android یا دستگاه واقعی نیاز دارد و در این محیط محلی اجرا نشده است.
