import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Multi-layer chamfered surface used by every hub, settings and overlay panel.
class PulsePanel extends StatelessWidget {
  const PulsePanel({
    required this.colors,
    required this.child,
    this.cut = 18,
    this.padding = EdgeInsets.zero,
    this.pressed = false,
    this.intensity = 1,
    super.key,
  });

  final List<Color> colors;
  final Widget child;
  final double cut;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final double intensity;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: PulsePanelPainter(
          colors: colors,
          cut: cut,
          pressed: pressed,
          intensity: intensity,
        ),
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

class PulsePanelPainter extends CustomPainter {
  const PulsePanelPainter({
    required this.colors,
    required this.cut,
    required this.pressed,
    required this.intensity,
  });

  final List<Color> colors;
  final double cut;
  final bool pressed;
  final double intensity;

  Path _shape(Size size, double inset) {
    final double chamfer = math.max(4.0, cut - inset * .45);
    final double left = inset;
    final double top = inset;
    final double right = size.width - inset;
    final double bottom = size.height - inset;
    return Path()
      ..moveTo(left + chamfer, top)
      ..lineTo(right - chamfer, top)
      ..lineTo(right, top + chamfer)
      ..lineTo(right, bottom - chamfer)
      ..lineTo(right - chamfer, bottom)
      ..lineTo(left + chamfer, bottom)
      ..lineTo(left, bottom - chamfer)
      ..lineTo(left, top + chamfer)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final Rect rect = Offset.zero & size;
    final Path outer = _shape(size, 2.2);
    final Path bevel = _shape(size, 5.3);
    final Path inner = _shape(size, 8.0);
    final Color left = colors.first;
    final Color right = colors.length > 1 ? colors.last : colors.first;
    final double press = pressed ? .68 : 1;
    final double lift = pressed ? 2.0 : 5.0;

    canvas.save();
    canvas.translate(0, lift);
    canvas.drawPath(outer, Paint()..color = const Color(0xFF01040A));
    canvas.drawPath(
      bevel,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..color = const Color(0xFF020610),
    );
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            const Color(0xFF1B2A3D),
            Color.lerp(const Color(0xFF0B1422), left, .055 * intensity)!,
            const Color(0xFF080D17),
            Color.lerp(const Color(0xFF070B14), right, .065 * intensity)!,
          ],
          stops: const <double>[0, .32, .72, 1],
        ).createShader(rect),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height * .48),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withValues(alpha: pressed ? .025 : .105),
            Colors.transparent,
          ],
        ).createShader(rect),
    );
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            left.withValues(alpha: .065 * intensity * press),
            Colors.transparent,
            right.withValues(alpha: .065 * intensity * press),
          ],
        ).createShader(rect),
    );
    final Paint texture = Paint()
      ..color = Colors.white.withValues(alpha: .012)
      ..strokeWidth = .55;
    for (double y = 14; y < size.height; y += 12) {
      canvas.drawLine(Offset(10, y), Offset(size.width - 10, y), texture);
    }
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.75
        ..shader = LinearGradient(
          colors: <Color>[
            left.withValues(alpha: .84 * press),
            const Color(0xFF6D7895),
            right.withValues(alpha: .84 * press),
          ],
          stops: const <double>[0, .5, 1],
        ).createShader(rect),
    );
    canvas.drawPath(
      bevel,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .8
        ..color = const Color(0x557B8AA8),
    );

    final Paint rail = Paint()
      ..strokeWidth = 2.1
      ..strokeCap = StrokeCap.round;
    rail.color = left.withValues(alpha: .78 * press);
    canvas.drawLine(
      const Offset(13, 5),
      Offset(math.min(54.0, size.width * .25), 5),
      rail,
    );
    canvas.drawLine(
      const Offset(5, 13),
      Offset(5, math.min(39.0, size.height * .44)),
      rail,
    );
    rail.color = right.withValues(alpha: .72 * press);
    canvas.drawLine(
      Offset(size.width - 13, size.height - 5),
      Offset(size.width - math.min(54.0, size.width * .25), size.height - 5),
      rail,
    );
    canvas.drawLine(
      Offset(size.width - 5, size.height - 13),
      Offset(size.width - 5, size.height - math.min(39.0, size.height * .44)),
      rail,
    );

    canvas.drawLine(
      Offset(cut + 7, size.height - 3.2),
      Offset(size.width - cut - 7, size.height - 3.2),
      Paint()
        ..strokeWidth = 1.2
        ..color = const Color(0xAA02050C),
    );
  }

  @override
  bool shouldRepaint(covariant PulsePanelPainter oldDelegate) {
    return oldDelegate.pressed != pressed ||
        oldDelegate.intensity != intensity ||
        oldDelegate.colors != colors ||
        oldDelegate.cut != cut;
  }
}
