import 'package:flutter/material.dart';

/// Centralized production design system for every PULSE ARENA surface.
abstract final class PulseColors {
  static const Color voidBlack = Color(0xFF01030A);
  static const Color background = Color(0xFF030711);
  static const Color deepNavy = Color(0xFF070D1B);
  static const Color panelTop = Color(0xFF0D1830);
  static const Color panelBottom = Color(0xFF07101F);
  static const Color panelInset = Color(0xFF050A14);
  static const Color elevated = Color(0xFF091327);
  static const Color cyan = Color(0xFF14DFFF);
  static const Color blue = Color(0xFF007DFF);
  static const Color violet = Color(0xFF7D4DFF);
  static const Color rose = Color(0xFFFF2DBD);
  static const Color magentaDeep = Color(0xFF9B36FF);
  static const Color gold = Color(0xFFFFC94A);
  static const Color success = Color(0xFF35E58A);
  static const Color danger = Color(0xFFFF4D79);
  static const Color textPrimary = Color(0xFFF3F7FF);
  static const Color textSecondary = Color(0xFF9CA9C4);
  static const Color textMuted = Color(0xFF65738E);
  static const Color disabled = Color(0xFF46516A);
  static const Color divider = Color(0xFF1B2A40);
}

abstract final class PulseSpacing {
  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
}

abstract final class PulseDurations {
  static const Duration press = Duration(milliseconds: 95);
  static const Duration micro = Duration(milliseconds: 180);
  static const Duration page = Duration(milliseconds: 240);
  static const Duration dialog = Duration(milliseconds: 220);
  static const Duration reward = Duration(milliseconds: 560);
}

abstract final class PulseTypography {
  static const String family = 'sans-serif';

  static const TextStyle display = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 30,
    fontWeight: FontWeight.w900,
    height: 1.12,
  );

  static const TextStyle title = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 21,
    fontWeight: FontWeight.w900,
    height: 1.18,
  );

  static const TextStyle section = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 15,
    fontWeight: FontWeight.w900,
    height: 1.25,
  );

  static const TextStyle body = TextStyle(
    fontFamily: family,
    color: PulseColors.textSecondary,
    fontSize: 12,
    fontWeight: FontWeight.w600,
    height: 1.55,
  );

  static const TextStyle label = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 12,
    fontWeight: FontWeight.w800,
    height: 1.25,
  );
}

ThemeData buildPulseArenaTheme() {
  final ColorScheme scheme = ColorScheme.fromSeed(
    seedColor: PulseColors.cyan,
    brightness: Brightness.dark,
    surface: PulseColors.deepNavy,
    error: PulseColors.danger,
  );
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    fontFamily: PulseTypography.family,
    scaffoldBackgroundColor: PulseColors.voidBlack,
    colorScheme: scheme,
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    hoverColor: Colors.transparent,
    focusColor: PulseColors.cyan.withValues(alpha: .12),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: PulseColors.cyan,
      selectionColor: PulseColors.cyan.withValues(alpha: .24),
      selectionHandleColor: PulseColors.cyan,
    ),
  );
}
