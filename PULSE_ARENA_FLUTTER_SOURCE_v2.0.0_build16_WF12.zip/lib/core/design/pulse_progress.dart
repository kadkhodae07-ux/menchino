import 'dart:math' as math;

import 'package:flutter/material.dart';

class PulseProgress extends StatelessWidget {
  const PulseProgress({
    required this.value,
    required this.label,
    required this.colors,
    this.compact = false,
    super.key,
  });

  final double value;
  final String label;
  final List<Color> colors;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: RepaintBoundary(
            child: SizedBox(
              height: compact ? 5 : 7,
              child: CustomPaint(
                painter: PulseProgressPainter(value: value, colors: colors),
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          textDirection: TextDirection.rtl,
          style: TextStyle(
            color: const Color(0xFFEAF7FF),
            fontSize: compact ? 9 : 10.5,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

class PulseProgressPainter extends CustomPainter {
  const PulseProgressPainter({required this.value, required this.colors});

  final double value;
  final List<Color> colors;

  @override
  void paint(Canvas canvas, Size size) {
    final RRect track = RRect.fromRectAndRadius(
      Offset.zero & size,
      Radius.circular(size.height),
    );
    canvas.drawRRect(track, Paint()..color = const Color(0xFF142238));
    final double width = size.width * value.clamp(0.0, 1.0).toDouble();
    if (width <= 0) return;
    final RRect fill = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, width, size.height),
      Radius.circular(size.height),
    );
    final Rect shaderRect = Rect.fromLTWH(
      0,
      0,
      math.max(width, 1.0),
      size.height,
    );
    canvas.drawRRect(
      fill,
      Paint()..shader = LinearGradient(colors: colors).createShader(shaderRect),
    );
    canvas.drawLine(
      const Offset(3, 1),
      Offset(math.max(3.0, width - 3), 1),
      Paint()
        ..strokeWidth = 1
        ..strokeCap = StrokeCap.round
        ..color = Colors.white.withValues(alpha: .34),
    );
  }

  @override
  bool shouldRepaint(covariant PulseProgressPainter oldDelegate) {
    return oldDelegate.value != value || oldDelegate.colors != colors;
  }
}
