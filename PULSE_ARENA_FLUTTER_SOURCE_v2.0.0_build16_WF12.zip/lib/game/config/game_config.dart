enum BotDifficulty { trainee, tactical, champion }

enum GameMode { offline, training }

extension GameModeLabel on GameMode {
  String get title => switch (this) {
        GameMode.offline => 'نبرد آفلاین',
        GameMode.training => 'تمرین آزاد',
      };

  String get subtitle => switch (this) {
        GameMode.offline => 'مسابقه کامل با ثبت آمار و پاداش',
        GameMode.training => 'تمرین سریع بدون تغییر آمار رقابتی',
      };
}

extension BotDifficultyLabel on BotDifficulty {
  String get title {
    switch (this) {
      case BotDifficulty.trainee:
        return 'تمرینی';
      case BotDifficulty.tactical:
        return 'تاکتیکی';
      case BotDifficulty.champion:
        return 'قهرمان';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.trainee:
        return 'واکنش آرام و خطای بیشتر';
      case BotDifficulty.tactical:
        return 'متعادل و مناسب مسابقه اصلی';
      case BotDifficulty.champion:
        return 'سریع، دقیق و کم‌اشتباه';
    }
  }
}

class GameConfig {
  const GameConfig({
    this.mode = GameMode.offline,
    this.trackProgress = true,
    this.difficulty = BotDifficulty.tactical,
    this.targetScore = 10,
    this.ballBaseSpeed = 540,
    this.ballMaximumSpeed = 980,
    this.ballSpeedIncreasePerSecond = 2.6,
    this.playerPaddleSpeed = 5200,
    this.playerPaddleAcceleration = 85000,
    this.playerResponse = 52,
    this.botPaddleSpeed = 1080,
    this.botPaddleAcceleration = 14800,
    this.botReactionDelay = 0.105,
    this.botErrorChance = 0.22,
    this.botBaseAimError = 62,
    this.countdownDuration = 2.7,
    this.pointServeDelay = 0.62,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.56,
    this.boostMultiplier = 1.30,
    this.shieldUses = 2,
    this.boostUses = 2,
    this.pulseUses = 2,
  });

  factory GameConfig.forDifficulty(BotDifficulty difficulty) {
    switch (difficulty) {
      case BotDifficulty.trainee:
        return const GameConfig(
          difficulty: BotDifficulty.trainee,
          botPaddleSpeed: 820,
          botPaddleAcceleration: 9800,
          botReactionDelay: 0.155,
          botErrorChance: 0.34,
          botBaseAimError: 88,
          ballBaseSpeed: 500,
          ballMaximumSpeed: 900,
        );
      case BotDifficulty.tactical:
        return const GameConfig();
      case BotDifficulty.champion:
        return const GameConfig(
          difficulty: BotDifficulty.champion,
          botPaddleSpeed: 1320,
          botPaddleAcceleration: 18600,
          botReactionDelay: 0.068,
          botErrorChance: 0.12,
          botBaseAimError: 38,
          ballBaseSpeed: 570,
          ballMaximumSpeed: 1040,
        );
    }
  }

  factory GameConfig.training() {
    return const GameConfig(
      mode: GameMode.training,
      trackProgress: false,
      difficulty: BotDifficulty.trainee,
      targetScore: 5,
      ballBaseSpeed: 470,
      ballMaximumSpeed: 820,
      botPaddleSpeed: 760,
      botPaddleAcceleration: 9200,
      botReactionDelay: 0.18,
      botErrorChance: 0.38,
      botBaseAimError: 92,
      shieldUses: 99,
      boostUses: 99,
      pulseUses: 99,
    );
  }

  final GameMode mode;
  final bool trackProgress;
  final BotDifficulty difficulty;
  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double playerPaddleSpeed;
  final double playerPaddleAcceleration;
  final double playerResponse;
  final double botPaddleSpeed;
  final double botPaddleAcceleration;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double pointServeDelay;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
