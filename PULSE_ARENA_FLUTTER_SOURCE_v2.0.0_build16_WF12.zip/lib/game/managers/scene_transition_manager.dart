import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/orientation_manager.dart';
import '../../screens/game_screen.dart';
import '../../screens/mode_selection_screen.dart';
import '../config/game_config.dart';

class SceneTransitionManager {
  const SceneTransitionManager._();

  static Future<void> openModeSelection(BuildContext context) async {
    await Navigator.of(context).push(_portraitRoute(const ModeSelectionScreen()));
  }

  static Future<void> openGame(
    BuildContext context, {
    GameConfig config = const GameConfig(),
  }) async {
    final NavigatorState navigator = Navigator.of(context);
    unawaited(OrientationManager.showGame());
    await navigator.push(_gameRoute(GameScreen(config: config)));
    unawaited(OrientationManager.showHome());
  }

  static Future<void> openHome(BuildContext context) async {
    final NavigatorState navigator = Navigator.of(context);
    await OrientationManager.showHome();
    navigator.popUntil((Route<dynamic> route) => route.isFirst);
  }

  @Deprecated('Use openHome instead.')
  static Future<void> openStart(BuildContext context) => openHome(context);

  static PageRouteBuilder<void> _portraitRoute(Widget page) {
    return PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 240),
      reverseTransitionDuration: const Duration(milliseconds: 190),
      pageBuilder: (_, Animation<double> animation, __) {
        final Animation<double> curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
        );
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(.025, 0),
              end: Offset.zero,
            ).animate(curved),
            child: page,
          ),
        );
      },
    );
  }

  static PageRouteBuilder<void> _gameRoute(Widget page) {
    return PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 170),
      reverseTransitionDuration: const Duration(milliseconds: 150),
      pageBuilder: (_, Animation<double> animation, __) => FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
        child: page,
      ),
    );
  }
}
