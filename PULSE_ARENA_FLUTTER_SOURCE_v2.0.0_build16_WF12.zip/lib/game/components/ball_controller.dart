import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, RadialGradient;

import '../config/game_config.dart';
import '../managers/audio_manager.dart';
import 'bot_paddle_controller.dart';
import 'impact_particle.dart';
import 'player_paddle_controller.dart';

class BallController extends PositionComponent {
  BallController({
    required this.config,
    required this.onPlayerScored,
    required this.onBotScored,
    required this.isShieldActive,
    required this.consumeBoost,
    required this.isBoostArmed,
    required this.matchElapsedSeconds,
    this.primaryColor = const Color(0xFFB765FF),
    this.secondaryColor = const Color(0xFF45239F),
    this.trailColor = const Color(0xFF6BE8FF),
    this.effectQuality = 2,
    void Function({required bool player, required bool perfect})? onPaddleHit,
  })  : onPaddleHit = onPaddleHit ?? _ignorePaddleHit,
        super(priority: 20, anchor: Anchor.center) {
    _outerGlowPaint.color = primaryColor.withValues(alpha: .08);
    _innerGlowPaint.color = primaryColor.withValues(alpha: .18);
    _ringPaint.color = primaryColor.withValues(alpha: .72);
    _pinkArcPaint.color = secondaryColor.withValues(alpha: .86);
    _cyanArcPaint.color = trailColor.withValues(alpha: .86);
  }

  static void _ignorePaddleHit({required bool player, required bool perfect}) {}

  final GameConfig config;
  final VoidCallback onPlayerScored;
  final VoidCallback onBotScored;
  final bool Function() isShieldActive;
  final VoidCallback consumeBoost;
  final bool Function() isBoostArmed;
  final double Function() matchElapsedSeconds;
  final void Function({required bool player, required bool perfect}) onPaddleHit;
  final Color primaryColor;
  final Color secondaryColor;
  final Color trailColor;
  final int effectQuality;

  late PlayerPaddleController player;
  late BotPaddleController bot;
  final math.Random _random = math.Random(7331);

  Rect arena = Rect.zero;
  Vector2 velocity = Vector2.zero();
  bool active = false;
  bool hidden = false;
  bool reducedEffects = false;
  double radius = 16;
  double visualTime = 0;

  double _currentSpeed = 0;
  double _orbitalSpin = 0;
  double _curveSpin = 0;
  double _energy = 0;
  double _physicsAccumulator = 0;
  double _trailAccumulator = 0;
  int _serveDirection = 1;
  int _particleSeed = 100;
  double _lastImpactAt = -1;
  final List<_TrailPoint> _trail = <_TrailPoint>[];

  final Paint _trailPaint = Paint()..strokeCap = StrokeCap.round;
  final Paint _outerGlowPaint = Paint()..color = const Color(0x14593CFF);
  final Paint _innerGlowPaint = Paint()..color = const Color(0x305B43FF);
  final Paint _ringPaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.55
    ..color = const Color(0xA88FEFFF);
  final Paint _pinkArcPaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.9
    ..strokeCap = StrokeCap.round
    ..color = const Color(0xD8FF5BC2);
  final Paint _cyanArcPaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.9
    ..strokeCap = StrokeCap.round
    ..color = const Color(0xD855E7FF);
  final Paint _orbPaint = Paint();
  final Paint _highlightPaint = Paint()..color = const Color(0xEFFFFFFF);

  static const double _physicsStep = 1 / 120;
  static const double _trailStep = 1 / 48;
  static const double _maxTrailAge = 0.12;

  void attachPaddles(PlayerPaddleController playerPaddle, BotPaddleController botPaddle) {
    player = playerPaddle;
    bot = botPaddle;
  }

  void layout(Rect value) {
    final bool firstLayout = arena.isEmpty;
    final bool wasActive = active;
    final bool wasHidden = hidden;
    final double xRatio = firstLayout
        ? 0.5
        : ((position.x - arena.left) / arena.width).clamp(0.0, 1.0).toDouble();
    final double yRatio = firstLayout
        ? 0.5
        : ((position.y - arena.top) / arena.height).clamp(0.0, 1.0).toDouble();

    arena = value;
    radius = (value.height * 0.027).clamp(10.5, 16.0).toDouble();
    size = Vector2.all(radius * 2);
    final Offset localCenter = Offset(radius, radius);
    _orbPaint.shader = RadialGradient(
      center: const Alignment(-0.30, -0.32),
      colors: <Color>[
        const Color(0xFFFFFFFF),
        Color.lerp(const Color(0xFFF4ECFF), primaryColor, .18)!,
        primaryColor,
        secondaryColor,
      ],
      stops: const <double>[0, 0.27, 0.70, 1],
    ).createShader(Rect.fromCircle(center: localCenter, radius: radius));

    if (firstLayout) {
      resetToCenter();
      return;
    }

    position = Vector2(value.left + value.width * xRatio, value.top + value.height * yRatio);
    position.x = position.x.clamp(value.left + radius, value.right - radius).toDouble();
    position.y = position.y.clamp(value.top + radius, value.bottom - radius).toDouble();
    active = wasActive;
    hidden = wasHidden;
    _trail.clear();
  }

  void resetToCenter({int? serveDirection}) {
    if (arena.isEmpty) return;
    if (serveDirection != null) _serveDirection = serveDirection;
    position = Vector2(arena.center.dx, arena.center.dy);
    _trail.clear();
    _physicsAccumulator = 0;
    _trailAccumulator = 0;
    active = false;
    hidden = false;
    _energy = 0;
    _curveSpin = 0;
    _currentSpeed = math.min(
      config.ballMaximumSpeed,
      config.ballBaseSpeed + matchElapsedSeconds() * config.ballSpeedIncreasePerSecond,
    );

    final double verticalMagnitude = 0.12 + _random.nextDouble() * 0.18;
    final double verticalAngle = verticalMagnitude * (_random.nextBool() ? 1 : -1);
    velocity = Vector2(
      _serveDirection * math.cos(verticalAngle),
      math.sin(verticalAngle),
    )..scale(_currentSpeed);
  }

  void launch() {
    if (arena.isEmpty) return;
    hidden = false;
    if (velocity.length < 1) {
      velocity = Vector2(_serveDirection.toDouble(), 0.12)..normalize()..scale(_currentSpeed);
    }
    active = true;
    _energy = 1;
    _physicsAccumulator = 0;
  }

  void stop({bool hide = false}) {
    active = false;
    hidden = hide;
    velocity = Vector2.zero();
    _trail.clear();
    _physicsAccumulator = 0;
    _trailAccumulator = 0;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double frameDt = dt.clamp(0.0, 0.05).toDouble();
    visualTime += frameDt;
    _orbitalSpin += frameDt * (active ? 6.0 : 1.4);
    _energy = math.max(0.14, _energy - frameDt * 0.62);

    for (final _TrailPoint point in _trail) {
      point.age += frameDt;
    }
    _trail.removeWhere((_TrailPoint point) => point.age > _maxTrailAge);

    if (!active || arena.isEmpty) return;

    final double timedMinimum = math.min(
      config.ballMaximumSpeed,
      config.ballBaseSpeed + matchElapsedSeconds() * config.ballSpeedIncreasePerSecond,
    );
    _currentSpeed = math.max(
      timedMinimum,
      math.min(config.ballMaximumSpeed, _currentSpeed + config.ballSpeedIncreasePerSecond * frameDt),
    );

    _physicsAccumulator += frameDt;
    int iterations = 0;
    while (_physicsAccumulator >= _physicsStep && active && iterations < 6) {
      _simulate(_physicsStep);
      _physicsAccumulator -= _physicsStep;
      iterations++;
    }
    if (iterations == 6) _physicsAccumulator = 0;
  }

  void _simulate(double dt) {
    _curveSpin *= math.exp(-2.3 * dt);
    velocity.y += _curveSpin * 22 * dt;
    _normalizeVelocityToCurrentSpeed();

    final Vector2 previous = position.clone();
    position += velocity * dt;

    _handleWalls();
    _handlePaddles(previous);
    _handleShield(previous);
    _handleScore();
    _sampleTrail(previous, dt);
  }

  void _sampleTrail(Vector2 previous, double dt) {
    if (!active) return;
    _trailAccumulator += dt;
    while (_trailAccumulator >= _trailStep) {
      _trailAccumulator -= _trailStep;
      final double t = dt <= 0 ? 1 : (1 - _trailAccumulator / dt).clamp(0.0, 1.0).toDouble();
      final Vector2 sample = previous + (position - previous) * t;
      _trail.insert(0, _TrailPoint(sample));
      final int trailLimit = reducedEffects ? 4 : (effectQuality == 1 ? 6 : 8);
      if (_trail.length > trailLimit) _trail.removeLast();
    }
  }

  void _handleWalls() {
    if (position.y - radius < arena.top && velocity.y < 0) {
      final double penetration = arena.top - (position.y - radius);
      position.y = arena.top + radius + penetration;
      velocity.y = velocity.y.abs();
      _curveSpin = -_curveSpin * 0.45;
      _energy = 0.9;
      _impact(const Color(0xFF7D8EFF));
      AudioManager.instance.playWall();
    } else if (position.y + radius > arena.bottom && velocity.y > 0) {
      final double penetration = position.y + radius - arena.bottom;
      position.y = arena.bottom - radius - penetration;
      velocity.y = -velocity.y.abs();
      _curveSpin = -_curveSpin * 0.45;
      _energy = 0.9;
      _impact(const Color(0xFF7D8EFF));
      AudioManager.instance.playWall();
    }
  }

  void _handlePaddles(Vector2 previous) {
    if (velocity.x < 0) {
      final double contactX = player.rect.right + radius;
      final bool crossedFace = previous.x >= contactX && position.x <= contactX;
      if (crossedFace) {
        final double denominator = previous.x - position.x;
        final double t = denominator.abs() < 0.0001
            ? 1
            : ((previous.x - contactX) / denominator).clamp(0.0, 1.0).toDouble();
        final double impactY = previous.y + (position.y - previous.y) * t;
        if (impactY >= player.rect.top - radius && impactY <= player.rect.bottom + radius) {
          position
            ..x = contactX
            ..y = impactY;
          _bounceFromPaddle(
            player.rect,
            direction: 1,
            isPlayer: true,
            paddleVelocity: player.verticalVelocity,
            paddleMaxSpeed: config.playerPaddleSpeed,
          );
        }
      }
    } else if (velocity.x > 0) {
      final double contactX = bot.rect.left - radius;
      final bool crossedFace = previous.x <= contactX && position.x >= contactX;
      if (crossedFace) {
        final double denominator = position.x - previous.x;
        final double t = denominator.abs() < 0.0001
            ? 1
            : ((contactX - previous.x) / denominator).clamp(0.0, 1.0).toDouble();
        final double impactY = previous.y + (position.y - previous.y) * t;
        if (impactY >= bot.rect.top - radius && impactY <= bot.rect.bottom + radius) {
          position
            ..x = contactX
            ..y = impactY;
          _bounceFromPaddle(
            bot.rect,
            direction: -1,
            isPlayer: false,
            paddleVelocity: bot.verticalVelocity,
            paddleMaxSpeed: config.botPaddleSpeed,
          );
        }
      }
    }
  }

  void _bounceFromPaddle(
    Rect paddle, {
    required int direction,
    required bool isPlayer,
    required double paddleVelocity,
    required double paddleMaxSpeed,
  }) {
    final double relative = ((position.y - paddle.center.dy) / (paddle.height / 2))
        .clamp(-1.0, 1.0)
        .toDouble();
    final double motionEnglish = (paddleVelocity / math.max(1, paddleMaxSpeed))
        .clamp(-1.0, 1.0)
        .toDouble();
    final double aim = (relative * 0.88 + motionEnglish * 0.24).clamp(-1.0, 1.0).toDouble();
    final bool perfect = isPlayer && relative.abs() <= 0.18 && motionEnglish.abs() < 0.78;

    double angle = aim * (math.pi * 0.325);
    if (angle.abs() < 0.055) {
      angle = 0.055 * (velocity.y < 0 ? -1 : 1);
    }

    double speed = math.min(config.ballMaximumSpeed, _currentSpeed + (perfect ? 34 : 19));
    if (isPlayer && isBoostArmed()) {
      speed = math.min(config.ballMaximumSpeed, speed * config.boostMultiplier);
      consumeBoost();
    }
    _currentSpeed = speed;
    velocity = Vector2(direction * math.cos(angle), math.sin(angle))..scale(speed);
    _curveSpin = motionEnglish * 4.8 + relative * 1.5;
    _energy = perfect ? 1.35 : 1;

    if (isPlayer) {
      player.registerHit(perfect: perfect);
    } else {
      bot.registerHit();
    }
    onPaddleHit(player: isPlayer, perfect: perfect);
    _impact(
      perfect
          ? const Color(0xFFFFFFFF)
          : (isPlayer ? trailColor : const Color(0xFFD96F9D)),
    );
    if (perfect) {
      AudioManager.instance.playPerfect();
      AudioManager.instance.importantImpact();
    } else {
      AudioManager.instance.playPaddle();
      AudioManager.instance.lightImpact();
    }
  }

  void _handleShield(Vector2 previous) {
    if (!isShieldActive() || velocity.x >= 0) return;
    final double shieldX = player.position.x - 27;
    final bool crossed = previous.x - radius >= shieldX && position.x - radius <= shieldX;
    if (!crossed) return;

    position.x = shieldX + radius;
    velocity.x = velocity.x.abs();
    _currentSpeed = math.min(config.ballMaximumSpeed, _currentSpeed + 25);
    _normalizeVelocityToCurrentSpeed();
    _energy = 1.15;
    _impact(const Color(0xFF6CF3FF));
    AudioManager.instance.playPower();
    AudioManager.instance.importantImpact();
  }

  void _handleScore() {
    if (position.x < arena.left - radius * 1.35) {
      active = false;
      hidden = true;
      _serveDirection = 1;
      _trail.clear();
      onBotScored();
    } else if (position.x > arena.right + radius * 1.35) {
      active = false;
      hidden = true;
      _serveDirection = -1;
      _trail.clear();
      onPlayerScored();
    }
  }

  void _normalizeVelocityToCurrentSpeed() {
    final double length = velocity.length;
    if (length < 0.001) {
      velocity = Vector2(_serveDirection.toDouble(), 0.1)..normalize()..scale(_currentSpeed);
      return;
    }

    velocity = velocity / length * _currentSpeed;
    final double minimumHorizontal = _currentSpeed * 0.46;
    if (velocity.x.abs() < minimumHorizontal) {
      final double signX = velocity.x < 0 ? -1 : 1;
      final double signY = velocity.y < 0 ? -1 : 1;
      final double horizontal = minimumHorizontal * signX;
      final double vertical = math.sqrt(math.max(0, _currentSpeed * _currentSpeed - horizontal * horizontal)) * signY;
      velocity = Vector2(horizontal, vertical);
    }
  }

  void _impact(Color color) {
    if (reducedEffects) return;
    if (visualTime - _lastImpactAt < 0.035) return;
    _lastImpactAt = visualTime;
    parent?.add(
      ImpactParticle(
        origin: position.clone(),
        color: color,
        seed: _particleSeed++,
      ),
    );
  }

  @override
  void render(Canvas canvas) {
    if (hidden) return;
    final Offset center = Offset(radius, radius);

    if (_trail.length > 1) {
      for (int i = _trail.length - 1; i > 0; i--) {
        final _TrailPoint older = _trail[i];
        final _TrailPoint newer = _trail[i - 1];
        final double life =
            (1 - older.age / _maxTrailAge).clamp(0.0, 1.0).toDouble();
        _trailPaint
          ..strokeWidth = radius * (0.12 + life * 0.24)
          ..color = Color.lerp(
            trailColor.withValues(alpha: 0),
            trailColor.withValues(alpha: .65),
            life,
          )!;
        canvas.drawLine(
          Offset(
            center.dx + older.position.x - position.x,
            center.dy + older.position.y - position.y,
          ),
          Offset(
            center.dx + newer.position.x - position.x,
            center.dy + newer.position.y - position.y,
          ),
          _trailPaint,
        );
      }
    }

    canvas.drawCircle(center, radius * (1.72 + _energy * 0.10), _outerGlowPaint);
    canvas.drawCircle(center, radius * (1.40 + _energy * 0.08), _innerGlowPaint);
    canvas.drawCircle(center, radius * 1.15, _ringPaint);
    final Rect orbitRect = Rect.fromCircle(center: center, radius: radius * 1.34);
    canvas.drawArc(orbitRect, _orbitalSpin, math.pi * 0.78, false, _pinkArcPaint);
    canvas.drawArc(
      orbitRect,
      -_orbitalSpin * 0.76 + math.pi,
      math.pi * 0.50,
      false,
      _cyanArcPaint,
    );
    canvas.drawCircle(center, radius, _orbPaint);
    canvas.drawCircle(
      Offset(center.dx - radius * 0.26, center.dy - radius * 0.31),
      radius * 0.19,
      _highlightPaint,
    );
  }

}

class _TrailPoint {
  _TrailPoint(this.position);

  final Vector2 position;
  double age = 0;
}
