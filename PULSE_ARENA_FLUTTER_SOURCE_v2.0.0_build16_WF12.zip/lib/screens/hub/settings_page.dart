part of '../hub_screen.dart';

class _SettingsPage extends StatefulWidget {
  const _SettingsPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  Future<void> _showInfo(String title, String body) async {
    await showDialog<void>(
      context: context,
      barrierColor: const Color(0xD601030A),
      builder: (BuildContext dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 25),
          child: PulsePanel(
            colors: const <Color>[PulseColors.cyan, PulseColors.violet],
            cut: 23,
            padding: const EdgeInsets.all(18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: PulseTypography.title,
                ),
                const SizedBox(height: 12),
                Text(
                  body,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: PulseTypography.body,
                ),
                const SizedBox(height: 15),
                SizedBox(
                  width: double.infinity,
                  child: _GraphicButton(
                    label: 'متوجه شدم',
                    icon: Icons.check_rounded,
                    colors: const <Color>[PulseColors.cyan, PulseColors.violet],
                    onTap: () => Navigator.of(dialogContext).pop(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final PlayerProgressController progress = widget.progress;
    return _PageScaffold(
      title: 'تنظیمات',
      subtitle: 'کنترل صدا، عملکرد و تجربه نبرد',
      icon: Icons.settings_rounded,
      colors: const <Color>[PulseColors.cyan, PulseColors.rose],
      children: <Widget>[
        const _SectionTitle(
          title: 'سطح هوش مصنوعی',
          icon: Icons.smart_toy_rounded,
          color: PulseColors.cyan,
        ),
        const SizedBox(height: 10),
        for (final BotDifficulty value in BotDifficulty.values) ...<Widget>[
          _DifficultyTile(
            value: value,
            selected: value == progress.difficulty,
            onTap: () {
              progress.setDifficulty(value);
              widget.onMessage('سطح ربات روی ${value.title} تنظیم شد');
              setState(() {});
            },
          ),
          const SizedBox(height: 9),
        ],
        const SizedBox(height: 5),
        const _SectionTitle(
          title: 'صدا و بازخورد',
          icon: Icons.tune_rounded,
          color: PulseColors.rose,
        ),
        const SizedBox(height: 10),
        _VolumeSettingTile(
          icon: Icons.music_note_rounded,
          label: 'موسیقی محیطی',
          value: progress.musicVolume,
          enabled: progress.musicEnabled,
          color: PulseColors.violet,
          onToggle: () async {
            final bool enabled = !progress.musicEnabled;
            progress.setMusicEnabled(enabled);
            await AudioManager.instance.setMusicEnabled(enabled);
            if (mounted) setState(() {});
          },
          onChanged: (double value) {
            progress.setMusicVolume(value);
            unawaited(AudioManager.instance.setMusicVolume(value));
            setState(() {});
          },
        ),
        const SizedBox(height: 9),
        _VolumeSettingTile(
          icon: Icons.surround_sound_rounded,
          label: 'افکت‌های صوتی',
          value: progress.soundVolume,
          enabled: progress.soundEnabled,
          color: PulseColors.cyan,
          onToggle: () async {
            final bool enabled = !progress.soundEnabled;
            progress.setSoundEnabled(enabled);
            await AudioManager.instance.setSoundEnabled(enabled);
            if (mounted) setState(() {});
          },
          onChanged: (double value) {
            progress.setSoundVolume(value);
            unawaited(AudioManager.instance.setSoundVolume(value));
            setState(() {});
          },
        ),
        const SizedBox(height: 9),
        _SettingToggleTile(
          icon: Icons.vibration_rounded,
          label: 'بازخورد لرزشی',
          subtitle: 'لرزش کوتاه و کنترل‌شده برای لمس، برخورد و گل',
          enabled: progress.vibrationEnabled,
          color: PulseColors.rose,
          onTap: () {
            final bool enabled = !progress.vibrationEnabled;
            progress.setVibrationEnabled(enabled);
            AudioManager.instance.vibrationEnabled = enabled;
            setState(() {});
          },
        ),
        const SizedBox(height: 14),
        const _SectionTitle(
          title: 'عملکرد و تصویر',
          icon: Icons.speed_rounded,
          color: PulseColors.gold,
        ),
        const SizedBox(height: 10),
        PulsePanel(
          colors: const <Color>[PulseColors.gold, PulseColors.violet],
          cut: 20,
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              const Text(
                'کیفیت افکت‌ها',
                textDirection: TextDirection.rtl,
                style: PulseTypography.section,
              ),
              const SizedBox(height: 9),
              Row(
                children: <Widget>[
                  for (int i = 0; i < 3; i++) ...<Widget>[
                    Expanded(
                      child: _SegmentButton(
                        label: const <String>['اقتصادی', 'متعادل', 'کامل'][i],
                        selected: progress.effectsQuality == i,
                        color: i == 0
                            ? PulseColors.blue
                            : i == 1
                                ? PulseColors.cyan
                                : PulseColors.gold,
                        onTap: () {
                          progress.setEffectsQuality(i);
                          setState(() {});
                        },
                      ),
                    ),
                    if (i != 2) const SizedBox(width: 7),
                  ],
                ],
              ),
              const SizedBox(height: 14),
              const Text(
                'نرخ فریم هدف',
                textDirection: TextDirection.rtl,
                style: PulseTypography.section,
              ),
              const SizedBox(height: 9),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _SegmentButton(
                      label: '۶۰ FPS پایدار',
                      selected: progress.frameRate == 60,
                      color: PulseColors.cyan,
                      onTap: () {
                        progress.setFrameRate(60);
                        setState(() {});
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SegmentButton(
                      label: '۹۰ FPS سازگار',
                      selected: progress.frameRate == 90,
                      color: PulseColors.violet,
                      onTap: () {
                        progress.setFrameRate(90);
                        setState(() {});
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const PulsePanel(
          colors: <Color>[PulseColors.gold, PulseColors.rose],
          cut: 20,
          padding: EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              Icon(Icons.info_rounded, color: PulseColors.gold, size: 30),
              SizedBox(width: 11),
              Expanded(
                child: Text(
                  'قانون مسابقه: هر بازیکنی که زودتر ۱۰ گل دریافت کند، بازنده است.',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: PulseTypography.body,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            Expanded(
              child: _GraphicButton(
                label: 'راهنمای کنترل',
                icon: Icons.touch_app_rounded,
                colors: const <Color>[PulseColors.cyan, PulseColors.blue],
                onTap: () => _showInfo(
                  'راهنمای کنترل',
                  'انگشت را روی نیمه بازیکن قرار بده و عمودی حرکت بده. راکت موقعیت انگشت را مستقیم دنبال می‌کند. قدرت‌های سپر، سرعت و پالس از نوار پایین فعال می‌شوند و در مسابقه اصلی تعداد استفاده محدود دارند.',
                ),
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: _GraphicButton(
                label: 'حریم خصوصی',
                icon: Icons.privacy_tip_rounded,
                colors: const <Color>[PulseColors.violet, PulseColors.rose],
                onTap: () => _showInfo(
                  'حریم خصوصی',
                  'این نسخه آفلاین است. پیشرفت، تنظیمات، خریدهای محلی و نتایج مسابقه فقط در حافظه داخلی همین دستگاه ذخیره می‌شوند و به سرور ارسال نمی‌شوند.',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          'PULSE ARENA • 2.0.0+16',
          textDirection: TextDirection.ltr,
          style: TextStyle(
            color: PulseColors.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _VolumeSettingTile extends StatelessWidget {
  const _VolumeSettingTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.enabled,
    required this.color,
    required this.onToggle,
    required this.onChanged,
  });

  final IconData icon;
  final String label;
  final double value;
  final bool enabled;
  final Color color;
  final VoidCallback onToggle;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: <Color>[color, enabled ? PulseColors.rose : PulseColors.disabled],
      cut: 19,
      intensity: enabled ? 1 : .5,
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
      child: Row(
        children: <Widget>[
          _IconCore(icon: icon, color: enabled ? color : PulseColors.disabled, size: 45),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      '${(value * 100).round()}٪',
                      style: TextStyle(
                        color: enabled ? color : PulseColors.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      label,
                      textDirection: TextDirection.rtl,
                      style: PulseTypography.section,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _CyberVolumeSlider(
                  value: value,
                  enabled: enabled,
                  color: color,
                  onChanged: onChanged,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          NeonPressable(
            semanticLabel: enabled ? 'خاموش کردن $label' : 'روشن کردن $label',
            onTap: onToggle,
            builder: (_, bool pressed) => Transform.scale(
              scale: pressed ? .94 : 1,
              child: _CustomToggle(enabled: enabled, color: color),
            ),
          ),
        ],
      ),
    );
  }
}

class _CyberVolumeSlider extends StatelessWidget {
  const _CyberVolumeSlider({
    required this.value,
    required this.enabled,
    required this.color,
    required this.onChanged,
  });

  final double value;
  final bool enabled;
  final Color color;
  final ValueChanged<double> onChanged;

  void _update(Offset localPosition, double width) {
    if (!enabled || width <= 0) return;
    onChanged((localPosition.dx / width).clamp(0.0, 1.0).toDouble());
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return Semantics(
          label: 'میزان صدا',
          value: '${(value * 100).round()} درصد',
          slider: true,
          enabled: enabled,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (TapDownDetails details) => _update(details.localPosition, constraints.maxWidth),
            onHorizontalDragUpdate: (DragUpdateDetails details) => _update(details.localPosition, constraints.maxWidth),
            child: SizedBox(
              height: 28,
              child: CustomPaint(
                painter: _VolumeSliderPainter(
                  value: value,
                  enabled: enabled,
                  color: color,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _VolumeSliderPainter extends CustomPainter {
  const _VolumeSliderPainter({
    required this.value,
    required this.enabled,
    required this.color,
  });

  final double value;
  final bool enabled;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final double y = size.height / 2;
    final RRect track = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, y - 3, size.width, 6),
      const Radius.circular(3),
    );
    canvas.drawRRect(track, Paint()..color = const Color(0xFF101B2E));
    final double activeWidth = size.width * value;
    if (activeWidth > 0) {
      final RRect active = RRect.fromRectAndRadius(
        Rect.fromLTWH(0, y - 3, activeWidth, 6),
        const Radius.circular(3),
      );
      canvas.drawRRect(
        active,
        Paint()
          ..shader = LinearGradient(
            colors: <Color>[
              enabled ? PulseColors.cyan : PulseColors.disabled,
              enabled ? color : PulseColors.disabled,
            ],
          ).createShader(active.outerRect),
      );
    }
    final Offset thumb = Offset(activeWidth.clamp(8.0, size.width - 8.0).toDouble(), y);
    if (enabled) {
      canvas.drawCircle(
        thumb,
        10,
        Paint()
          ..color = color.withValues(alpha: .24)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
    }
    canvas.drawCircle(
      thumb,
      7,
      Paint()..color = enabled ? color : PulseColors.disabled,
    );
    canvas.drawCircle(
      thumb,
      3,
      Paint()..color = enabled ? Colors.white : PulseColors.textMuted,
    );
  }

  @override
  bool shouldRepaint(covariant _VolumeSliderPainter oldDelegate) {
    return oldDelegate.value != value ||
        oldDelegate.enabled != enabled ||
        oldDelegate.color != color;
  }
}
