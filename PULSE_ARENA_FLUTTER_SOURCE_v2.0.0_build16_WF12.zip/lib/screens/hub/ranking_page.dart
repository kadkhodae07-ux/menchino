part of '../hub_screen.dart';

class _StandaloneRankingScreen extends StatelessWidget {
  const _StandaloneRankingScreen({
    required this.progress,
    required this.onMessage,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PulseColors.voidBlack,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const RepaintBoundary(child: CustomPaint(painter: _HubBackgroundPainter())),
          SafeArea(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                  child: Row(
                    children: <Widget>[
                      _MiniIconButton(
                        icon: Icons.arrow_back_rounded,
                        color: PulseColors.cyan,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      const Expanded(
                        child: Text(
                          'جدول لیگ آفلاین',
                          textDirection: TextDirection.rtl,
                          textAlign: TextAlign.center,
                          style: PulseTypography.title,
                        ),
                      ),
                      const SizedBox(width: 46),
                    ],
                  ),
                ),
                Expanded(
                  child: _RankingPage(
                    progress: progress,
                    onMessage: onMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RankingPage extends StatelessWidget {
  const _RankingPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  List<_RankData> _localRanking() {
    const List<({String name, int score, Color color})> bots =
        <({String name, int score, Color color})>[
      (name: 'هسته قهرمان آلفا', score: 4820, color: PulseColors.gold),
      (name: 'ربات تاکتیکی سیگما', score: 4665, color: Color(0xFFC9D6EF)),
      (name: 'نگهبان نئون سه', score: 4510, color: Color(0xFFFF9A62)),
      (name: 'هسته سرعت وُلت', score: 4280, color: PulseColors.cyan),
      (name: 'ربات دفاعی اوربیت', score: 3990, color: PulseColors.violet),
      (name: 'نگهبان آرنا نوا', score: 3845, color: PulseColors.textMuted),
    ];
    final List<({String name, int score, Color color, bool current})> entries =
        <({String name, int score, Color color, bool current})>[
      for (final ({String name, int score, Color color}) bot in bots)
        (name: bot.name, score: bot.score, color: bot.color, current: false),
      (
        name: progress.playerName,
        score: progress.leagueScore,
        color: PulseColors.rose,
        current: true,
      ),
    ]..sort((a, b) => b.score.compareTo(a.score));
    return <_RankData>[
      for (int i = 0; i < entries.length; i++)
        _RankData(
          i + 1,
          entries[i].name,
          entries[i].score,
          entries[i].color,
          current: entries[i].current,
        ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final List<_RankData> players = _localRanking();
    final _RankData current = players.firstWhere((p) => p.current);
    final double leagueProgress = progress.leagueProgress;
    final int toNext = progress.pointsToNextLeague;

    return _PageScaffold(
      title: 'رتبه‌بندی آفلاین',
      subtitle: 'رقابت محلی با هسته‌های هوش مصنوعی؛ بدون شبیه‌سازی بازیکن آنلاین',
      icon: Icons.leaderboard_rounded,
      colors: const <Color>[PulseColors.gold, PulseColors.rose],
      children: <Widget>[
        PulsePanel(
          colors: const <Color>[PulseColors.gold, PulseColors.rose],
          cut: 24,
          padding: const EdgeInsets.all(15),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  const SizedBox(
                    width: 76,
                    height: 76,
                    child: CustomPaint(painter: _LeagueEmblemPainter()),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          'لیگ ${progress.leagueName} آفلاین',
                          textDirection: TextDirection.rtl,
                          style: const TextStyle(
                            color: PulseColors.textPrimary,
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          'رتبه فعلی: ${current.rank} • ${_groupDigits(progress.leagueScore)} امتیاز',
                          textDirection: TextDirection.rtl,
                          style: const TextStyle(
                            color: PulseColors.gold,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 10),
                        PulseProgress(
                          value: leagueProgress,
                          label: toNext == 0
                              ? 'بالاترین لیگ محلی'
                              : '$toNext امتیاز تا ${progress.nextLeagueName}',
                          colors: const <Color>[PulseColors.gold, PulseColors.rose],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _GraphicButton(
                label: 'جزئیات پاداش ارتقای لیگ',
                icon: Icons.card_giftcard_rounded,
                colors: const <Color>[PulseColors.gold, PulseColors.rose],
                onTap: () => onMessage(
                  progress.pointsToNextLeague == 0
                      ? 'شما به بالاترین لیگ محلی رسیده‌اید'
                      : 'پاداش ارتقا به لیگ ${progress.nextLeagueName}: ۳۰۰ پالس؛ پس از رسیدن خودکار ثبت می‌شود',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _Podium(players: players.take(3).toList(growable: false)),
        const SizedBox(height: 14),
        const _SectionTitle(
          title: 'جدول هسته‌های آفلاین',
          icon: Icons.format_list_numbered_rounded,
          color: PulseColors.gold,
        ),
        const SizedBox(height: 9),
        for (final _RankData player in players) ...<Widget>[
          _RankingRow(
            data: player,
            isCurrentUser: player.current,
            onTap: () => onMessage(
              player.current
                  ? 'این ردیف از نتایج واقعی ذخیره‌شده شما ساخته شده است'
                  : '${player.name} — هسته هوش مصنوعی با ${player.score} امتیاز',
            ),
          ),
          const SizedBox(height: 8),
        ],
        const PulsePanel(
          colors: <Color>[PulseColors.blue, PulseColors.violet],
          cut: 17,
          padding: EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              Icon(Icons.offline_bolt_rounded, color: PulseColors.cyan),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'این جدول آنلاین نیست. نام‌های دیگر متعلق به هسته‌های هوش مصنوعی بازی هستند، نه کاربران ساختگی.',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: PulseTypography.body,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
