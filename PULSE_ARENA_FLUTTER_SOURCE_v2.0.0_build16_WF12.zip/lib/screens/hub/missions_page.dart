part of '../hub_screen.dart';

class _MissionsPage extends StatefulWidget {
  const _MissionsPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  State<_MissionsPage> createState() => _MissionsPageState();
}

class _MissionsPageState extends State<_MissionsPage> {
  int _segment = 0;

  List<_MissionData> _missions() {
    final PlayerProgressController progress = widget.progress;
    if (_segment == 0) {
      return <_MissionData>[
        _MissionData(
          progress.missionClaimId('daily', 'matches'),
          'سه نبرد کامل',
          '۳ مسابقه انجام بده',
          progress.dailyMatchesProgress.clamp(0, 3).toInt(),
          3,
          120,
          Icons.sports_esports_rounded,
        ),
        _MissionData(
          progress.missionClaimId('daily', 'perfect'),
          'پالس دقیق',
          '۱۰ ضربه دقیق ثبت کن',
          progress.dailyPerfectHitsProgress.clamp(0, 10).toInt(),
          10,
          80,
          Icons.track_changes_rounded,
        ),
        _MissionData(
          progress.missionClaimId('daily', 'power'),
          'توان آرنا',
          '۲ قدرت ویژه استفاده کن',
          progress.dailyPowersProgress.clamp(0, 2).toInt(),
          2,
          60,
          Icons.shield_rounded,
        ),
      ];
    }
    return <_MissionData>[
      _MissionData(
        progress.missionClaimId('weekly', 'wins'),
        'قهرمان هفته',
        '۲۰ مسابقه را برنده شو',
        progress.weeklyWinsProgress.clamp(0, 20).toInt(),
        20,
        600,
        Icons.emoji_events_rounded,
      ),
      _MissionData(
        progress.missionClaimId('weekly', 'goals'),
        'نبرد طولانی',
        '۱۰۰ گل در مجموع ثبت کن',
        progress.weeklyGoalsProgress.clamp(0, 100).toInt(),
        100,
        450,
        Icons.timeline_rounded,
      ),
      _MissionData(
        progress.missionClaimId('weekly', 'powers'),
        'استاد تقویت',
        '۱۵ قدرت ویژه اجرا کن',
        progress.weeklyPowersProgress.clamp(0, 15).toInt(),
        15,
        350,
        Icons.bolt_rounded,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final List<_MissionData> missions = _missions();
    final int available = missions.where((m) {
      return m.current >= m.target &&
          !widget.progress.claimedMissions.contains(m.id);
    }).length;
    final int rewards = missions.fold<int>(0, (int total, _MissionData mission) {
      if (widget.progress.claimedMissions.contains(mission.id)) return total;
      return total + mission.reward;
    });

    return _PageScaffold(
      title: 'ماموریت‌ها',
      subtitle: 'پاداش‌های آفلاین متصل به عملکرد واقعی شما',
      icon: Icons.track_changes_rounded,
      colors: const <Color>[PulseColors.violet, PulseColors.rose],
      children: <Widget>[
        _DailyRewardPanel(
          progress: widget.progress,
          onClaim: () {
            final bool claimed = widget.progress.claimDailyReward();
            widget.onMessage(
              claimed
                  ? '۵۰ انرژی، ۱۰۰ پالس و ۲۰۰ XP دریافت شد'
                  : 'جایزه امروز قبلاً دریافت شده است',
            );
            setState(() {});
          },
        ),
        const SizedBox(height: 13),
        PulsePanel(
          colors: const <Color>[PulseColors.cyan, PulseColors.rose],
          cut: 22,
          padding: const EdgeInsets.fromLTRB(15, 13, 15, 15),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: _MetricPanel(
                      value: '$available',
                      label: 'آماده دریافت',
                      icon: Icons.bolt_rounded,
                      color: PulseColors.gold,
                      compact: true,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _MetricPanel(
                      value: _groupDigits(rewards),
                      label: 'پاداش باقی‌مانده',
                      icon: Icons.motion_photos_on_rounded,
                      color: PulseColors.rose,
                      compact: true,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _SegmentButton(
                      label: 'روزانه',
                      selected: _segment == 0,
                      color: PulseColors.cyan,
                      onTap: () => setState(() => _segment = 0),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _SegmentButton(
                      label: 'هفتگی',
                      selected: _segment == 1,
                      color: PulseColors.rose,
                      onTap: () => setState(() => _segment = 1),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 13),
        for (int i = 0; i < missions.length; i++) ...<Widget>[
          _MissionTile(
            data: missions[i],
            claimed: widget.progress.claimedMissions.contains(missions[i].id),
            onTap: () {
              final _MissionData mission = missions[i];
              if (mission.current < mission.target) {
                widget.onMessage('این ماموریت هنوز کامل نشده است');
                return;
              }
              final bool claimed = widget.progress.claimMission(
                mission.id,
                mission.reward,
              );
              widget.onMessage(
                claimed
                    ? '${mission.reward} پالس به حساب محلی اضافه شد'
                    : 'پاداش این ماموریت قبلاً دریافت شده است',
              );
              setState(() {});
            },
          ),
          if (i != missions.length - 1) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _DailyRewardPanel extends StatelessWidget {
  const _DailyRewardPanel({
    required this.progress,
    required this.onClaim,
  });

  final PlayerProgressController progress;
  final VoidCallback onClaim;

  @override
  Widget build(BuildContext context) {
    final bool available = progress.canClaimDailyReward;
    return PulsePanel(
      colors: const <Color>[PulseColors.cyan, PulseColors.rose],
      cut: 25,
      padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
      child: Row(
        children: <Widget>[
          const SizedBox(
            width: 96,
            height: 92,
            child: CustomPaint(painter: _RewardChestPainter()),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      progress.dailyRewardStreak > 0
                          ? 'روز ${progress.dailyRewardStreak + (available ? 1 : 0)}'
                          : 'روز اول',
                      style: const TextStyle(
                        color: PulseColors.gold,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'جایزه روزانه',
                      textDirection: TextDirection.rtl,
                      style: PulseTypography.title,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Wrap(
                  alignment: WrapAlignment.end,
                  spacing: 6,
                  runSpacing: 6,
                  children: <Widget>[
                    _RewardChip(icon: Icons.bolt_rounded, value: '۵۰', color: PulseColors.cyan),
                    _RewardChip(icon: Icons.motion_photos_on_rounded, value: '۱۰۰', color: PulseColors.rose),
                    _RewardChip(icon: Icons.auto_awesome_rounded, value: '۲۰۰ XP', color: PulseColors.violet),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: _GraphicButton(
                    label: available ? 'دریافت جایزه' : 'دریافت شده',
                    icon: available ? Icons.card_giftcard_rounded : Icons.check_circle_rounded,
                    colors: available
                        ? const <Color>[PulseColors.cyan, PulseColors.rose]
                        : const <Color>[PulseColors.disabled, PulseColors.textMuted],
                    onTap: available ? onClaim : null,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardChip extends StatelessWidget {
  const _RewardChip({required this.icon, required this.value, required this.color});

  final IconData icon;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: .42)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, color: color, size: 15),
          const SizedBox(width: 4),
          Text(
            value,
            textDirection: TextDirection.ltr,
            style: const TextStyle(
              color: PulseColors.textPrimary,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardChestPainter extends CustomPainter {
  const _RewardChestPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Offset center = size.center(Offset.zero);
    canvas.drawCircle(
      center + const Offset(0, 10),
      size.shortestSide * .45,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            PulseColors.violet.withValues(alpha: .28),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(
          center: center + const Offset(0, 10),
          radius: size.shortestSide * .45,
        )),
    );
    final RRect body = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width * .13, size.height * .38, size.width * .74, size.height * .44),
      const Radius.circular(10),
    );
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF273D67), Color(0xFF080D1A)],
        ).createShader(rect),
    );
    canvas.drawRRect(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const LinearGradient(
          colors: <Color>[PulseColors.cyan, PulseColors.rose],
        ).createShader(rect),
    );
    final Path lid = Path()
      ..moveTo(size.width * .19, size.height * .39)
      ..lineTo(size.width * .25, size.height * .22)
      ..lineTo(size.width * .75, size.height * .22)
      ..lineTo(size.width * .81, size.height * .39)
      ..close();
    canvas.drawPath(
      lid,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF213A63), Color(0xFF0A1224)],
        ).createShader(rect),
    );
    canvas.drawPath(
      lid,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = PulseColors.violet,
    );
    final Path lock = Path()
      ..moveTo(size.width * .43, size.height * .43)
      ..lineTo(size.width * .57, size.height * .43)
      ..lineTo(size.width * .61, size.height * .58)
      ..lineTo(size.width * .50, size.height * .68)
      ..lineTo(size.width * .39, size.height * .58)
      ..close();
    canvas.drawPath(lock, Paint()..color = PulseColors.cyan);
    canvas.drawCircle(center + Offset(0, size.height * .04), 3.2, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant _RewardChestPainter oldDelegate) => false;
}
