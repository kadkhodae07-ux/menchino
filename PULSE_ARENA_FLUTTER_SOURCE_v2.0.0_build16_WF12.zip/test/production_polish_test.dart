import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Build 16 launch path removes intentional transition latency', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();
    final String transition = File(
      'lib/game/managers/scene_transition_manager.dart',
    ).readAsStringSync();

    expect(hub, isNot(contains('Duration(milliseconds: 100)')));
    expect(hub, contains('_ambient.stop(canceled: false)'));
    expect(hub, contains('_ambient.repeat()'));
    expect(hub, contains('setState(() => _leaving = false)'));
    expect(transition, contains('unawaited(OrientationManager.showGame())'));
    expect(transition, contains('await navigator.push('));
    expect(transition, contains('navigator.popUntil('));
    expect(transition, contains('Duration(milliseconds: 170)'));
    expect(transition, isNot(contains('Duration(milliseconds: 440)')));
  });

  test('Home preview caches rendering and panels retain depth', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();
    final String panel =
        File('lib/core/design/pulse_panel.dart').readAsStringSync();

    expect(hub, contains('static Picture? _staticPicture'));
    expect(hub, contains('Picture _buildStatic(Size size)'));
    expect(panel, contains('final double lift = pressed ? 2.0 : 5.0'));
    expect(panel, contains('final Path bevel'));
    expect(hub, contains('class _HubBackgroundPainter'));
  });

  test('adaptive performance limits are production tuned', () {
    final String ball = File(
      'lib/game/components/ball_controller.dart',
    ).readAsStringSync();
    final String game = File(
      'lib/game/pulse_arena_game.dart',
    ).readAsStringSync();

    expect(ball, contains('iterations < 6'));
    expect(ball, contains('trailLimit = reducedEffects ? 4 : (effectQuality == 1 ? 6 : 8)'));
    expect(game, contains('_slowFrameDebt < 18'));
    expect(game, contains('_uiAccumulator >= 0.25'));
    expect(game, contains('PlayerProgressController.instance.effectsQuality'));
  });

  test('player state and Android refresh preference persist locally', () {
    final String controller = File(
      'lib/player/player_progress_controller.dart',
    ).readAsStringSync();
    final String store = File(
      'lib/core/persistence/platform_state_store.dart',
    ).readAsStringSync();
    final String activity = File(
      'android/app/src/main/kotlin/com/manyshah/pulsearena/MainActivity.kt',
    ).readAsStringSync();

    expect(controller, contains('claimMission'));
    expect(controller, contains('purchaseItem'));
    expect(controller, contains('recordMatch'));
    expect(store, contains('setPreferredFrameRate'));
    expect(activity, contains('getSharedPreferences'));
    expect(activity, contains('preferredDisplayModeId'));
  });
}
