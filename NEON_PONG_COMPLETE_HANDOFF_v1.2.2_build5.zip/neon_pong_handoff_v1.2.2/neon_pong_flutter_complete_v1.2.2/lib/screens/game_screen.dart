import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../data/save_data.dart';
import '../game/game_engine.dart';
import '../game/pong_painter.dart';
import '../services/audio_feedback.dart';
import '../utils/fa_digits.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.mode, this.difficulty = 1});

  final GameMode mode;
  final int difficulty;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  late final GameEngine _engine;
  late final Ticker _ticker;
  final FocusNode _focusNode = FocusNode();
  final Map<int, bool> _pointerSides = <int, bool>{};
  Duration? _lastElapsed;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    _engine = GameEngine(save: SaveData.instance, onEvent: _handleEvent);
    _ticker = createTicker(_tick)..start();
    _enterGameMode();
    WidgetsBinding.instance.addPostFrameCallback((_) => _focusNode.requestFocus());
  }

  Future<void> _enterGameMode() async {
    await SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _engine.dispose();
    _focusNode.dispose();
    SystemChrome.setPreferredOrientations(<DeviceOrientation>[
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _tick(Duration elapsed) {
    if (_lastElapsed == null) {
      _lastElapsed = elapsed;
      return;
    }
    final double dt = (elapsed - _lastElapsed!).inMicroseconds / 1000000;
    _lastElapsed = elapsed;
    _engine.update(dt);
  }

  void _handleEvent(GameEvent event) {
    final AudioFeedbackService audio = AudioFeedbackService.instance;
    switch (event) {
      case GameEvent.launch:
        audio.play(FeedbackEvent.launch);
        break;
      case GameEvent.paddleHit:
        audio.play(FeedbackEvent.paddle);
        break;
      case GameEvent.wallHit:
        audio.play(FeedbackEvent.wall);
        break;
      case GameEvent.playerPoint:
        audio.play(FeedbackEvent.score);
        break;
      case GameEvent.opponentPoint:
        audio.play(FeedbackEvent.losePoint);
        break;
      case GameEvent.pickup:
        audio.play(FeedbackEvent.pickup);
        break;
      case GameEvent.shield:
        audio.play(FeedbackEvent.shield);
        break;
      case GameEvent.win:
        audio.play(FeedbackEvent.win);
        break;
      case GameEvent.lose:
        audio.play(FeedbackEvent.lose);
        break;
    }
  }

  void _handlePointer(PointerEvent event) {
    final bool left = _pointerSides[event.pointer] ?? (event.localPosition.dx < _engine.viewport.width / 2);
    _pointerSides[event.pointer] = left;
    if (widget.mode == GameMode.friend) {
      if (left) {
        _engine.movePlayer(event.localPosition.dy);
      } else {
        _engine.moveOpponent(event.localPosition.dy);
      }
    } else {
      _engine.movePlayer(event.localPosition.dy);
    }
  }

  void _key(KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) return;
    const double step = 45;
    switch (event.logicalKey) {
      case LogicalKeyboardKey.keyW:
        _engine.nudgePlayer(-step);
        break;
      case LogicalKeyboardKey.keyS:
        _engine.nudgePlayer(step);
        break;
      case LogicalKeyboardKey.arrowUp:
        if (widget.mode == GameMode.friend) {
          _engine.nudgeOpponent(-step);
        } else {
          _engine.nudgePlayer(-step);
        }
        break;
      case LogicalKeyboardKey.arrowDown:
        if (widget.mode == GameMode.friend) {
          _engine.nudgeOpponent(step);
        } else {
          _engine.nudgePlayer(step);
        }
        break;
      case LogicalKeyboardKey.keyP:
      case LogicalKeyboardKey.escape:
        _engine.togglePause();
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_engine.state == GameState.over) return true;
        if (_engine.state == GameState.play || _engine.state == GameState.serve) {
          _engine.togglePause();
        }
        return false;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF05060F),
        body: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            _engine.setSize(constraints.maxWidth, constraints.maxHeight);
            if (!_started && constraints.maxWidth > 0 && constraints.maxHeight > 0) {
              _started = true;
              WidgetsBinding.instance.addPostFrameCallback((_) => _engine.startMatch(gameMode: widget.mode, diff: widget.difficulty));
            }
            return KeyboardListener(
              focusNode: _focusNode,
              onKeyEvent: _key,
              child: Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: _handlePointer,
                onPointerMove: _handlePointer,
                onPointerUp: (PointerUpEvent event) => _pointerSides.remove(event.pointer),
                onPointerCancel: (PointerCancelEvent event) => _pointerSides.remove(event.pointer),
                child: AnimatedBuilder(
                  animation: _engine,
                  builder: (BuildContext context, Widget? child) {
                    return Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        CustomPaint(painter: PongPainter(_engine, SaveData.instance)),
                        Positioned(top: 12, right: 12, child: _roundButton(icon: _engine.state == GameState.pause ? Icons.play_arrow_rounded : Icons.pause_rounded, onTap: _engine.togglePause)),
                        Positioned(top: 12, left: 12, child: _roundButton(icon: SaveData.instance.muted ? Icons.volume_off_rounded : Icons.volume_up_rounded, onTap: () => SaveData.instance.setMuted(!SaveData.instance.muted))),
                        _playerHudStrip(),
                        if (_engine.activeEffects.isNotEmpty || _engine.shieldActive) _effectChips(),
                        if (_engine.state == GameState.pause) _pauseOverlay(),
                        if (_engine.state == GameState.over) _gameOverOverlay(),
                      ],
                    );
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _roundButton({required IconData icon, required VoidCallback onTap}) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Colors.white.withOpacity(0.08),
            const Color(0xFF0A0E20).withOpacity(0.92),
          ],
        ),
        border: Border.all(color: Colors.white.withOpacity(0.16)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.32), blurRadius: 20, offset: const Offset(0, 10)),
          BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.10), blurRadius: 16),
        ],
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(icon, color: Colors.white),
        style: IconButton.styleFrom(
          backgroundColor: Colors.transparent,
          side: BorderSide.none,
          padding: const EdgeInsets.all(12),
        ),
      ),
    );
  }

  Widget _playerHudStrip() {
    return Positioned(
      top: 16,
      left: 74,
      right: 74,
      child: IgnorePointer(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            _playerChip(
              emoji: SaveData.instance.avatarEmoji,
              name: widget.mode == GameMode.friend ? 'بازیکن ۱' : 'تو',
              accent: const Color(0xFF00E5FF),
              score: _engine.scorePlayer,
              alignEnd: false,
            ),
            _playerChip(
              emoji: widget.mode == GameMode.bot ? '🤖' : '🎮',
              name: widget.mode == GameMode.bot ? 'ربات' : 'بازیکن ۲',
              accent: const Color(0xFFFF2FD6),
              score: _engine.scoreOpponent,
              alignEnd: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _playerChip({
    required String emoji,
    required String name,
    required Color accent,
    required int score,
    required bool alignEnd,
  }) {
    final Alignment begin = alignEnd ? Alignment.topRight : Alignment.topLeft;
    final Alignment end = alignEnd ? Alignment.bottomLeft : Alignment.bottomRight;
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 154),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: begin,
            end: end,
            colors: <Color>[
              accent.withOpacity(0.24),
              const Color(0xDD0A0F20),
              Colors.black.withOpacity(0.45),
            ],
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accent.withOpacity(0.35)),
          boxShadow: <BoxShadow>[
            BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 8)),
            BoxShadow(color: accent.withOpacity(0.14), blurRadius: 16),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (alignEnd) ...<Widget>[
              _scoreBubble(score, accent),
              const SizedBox(width: 8),
            ],
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[Colors.white.withOpacity(0.12), accent.withOpacity(0.18)],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.10)),
              ),
              child: Center(child: Text(emoji, style: const TextStyle(fontSize: 19))),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.2, fontWeight: FontWeight.w800, color: Colors.white)),
                  const SizedBox(height: 3),
                  Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: <Color>[accent, accent.withOpacity(0.20)]),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ],
              ),
            ),
            if (!alignEnd) ...<Widget>[
              const SizedBox(width: 8),
              _scoreBubble(score, accent),
            ],
          ],
        ),
      ),
    );
  }

  Widget _scoreBubble(int value, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.28)),
      ),
      child: Text(
        faNumber(value),
        style: TextStyle(
          color: accent == const Color(0xFFFF2FD6) ? const Color(0xFFFFB8EC) : const Color(0xFF8FF4FF),
          fontWeight: FontWeight.w900,
          fontSize: 12.5,
        ),
      ),
    );
  }

  Widget _effectChips() {
    return Positioned(
      top: 72,
      left: 12,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ..._engine.activeEffects.map((ActiveEffect effect) {
            final FieldPowerUp data = effect.descriptor;
            return Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                    data.color.withOpacity(0.18),
                    const Color(0xE10A0E20),
                    Colors.black.withOpacity(0.56),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: data.color.withOpacity(0.52)),
                boxShadow: <BoxShadow>[
                  BoxShadow(color: Colors.black.withOpacity(0.26), blurRadius: 14, offset: const Offset(0, 8)),
                  BoxShadow(color: data.color.withOpacity(0.12), blurRadius: 14),
                ],
              ),
              child: Text(
                '${data.emoji} ${data.name} (${faNumber(effect.remaining.ceil())}s)',
                style: const TextStyle(fontSize: 11.8, fontWeight: FontWeight.w800),
              ),
            );
          }),
          if (_engine.shieldActive)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[
                    const Color(0xFFB388FF).withOpacity(0.18),
                    const Color(0xE10A0E20),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFB388FF).withOpacity(0.58)),
                boxShadow: <BoxShadow>[
                  BoxShadow(color: Colors.black.withOpacity(0.26), blurRadius: 14, offset: const Offset(0, 8)),
                  BoxShadow(color: const Color(0xFFB388FF).withOpacity(0.14), blurRadius: 14),
                ],
              ),
              child: const Text('🛡️ سپر فعال', style: TextStyle(fontSize: 11.8, fontWeight: FontWeight.w800)),
            ),
        ],
      ),
    );
  }

  Widget _pauseOverlay() {
    return _overlay(
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        const Text('⏸️ توقف', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
        const SizedBox(height: 22),
        FilledButton.icon(
          onPressed: _engine.togglePause,
          icon: const Icon(Icons.play_arrow_rounded),
          label: const Text('ادامه بازی'),
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00E5FF), foregroundColor: Colors.black),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.home_rounded), label: const Text('خروج به خانه')),
      ]),
    );
  }

  Widget _gameOverOverlay() {
    final MatchResult? result = _engine.result;
    final bool won = result?.won ?? false;
    final String title = widget.mode == GameMode.bot
        ? (won ? '🏆 برنده شدی!' : '🤖 ربات برنده شد!')
        : (won ? '🏆 بازیکن ۱ برنده شد!' : '🎉 بازیکن ۲ برنده شد!');
    return _overlay(
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w900,
            color: won || widget.mode == GameMode.friend ? const Color(0xFF4DFFB0) : const Color(0xFFFF5577),
          ),
        ),
        const SizedBox(height: 8),
        Text('نتیجه: ${faNumber(_engine.scorePlayer)} — ${faNumber(_engine.scoreOpponent)}', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 15)),
        const SizedBox(height: 14),
        if (result != null)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              _reward('🪙 +${faNumber(result.reward.coins)}', const Color(0xFFFFE259)),
              const SizedBox(width: 8),
              _reward('⭐ +${faNumber(result.reward.xp)} تجربه', const Color(0xFF8FF4FF)),
            ],
          ),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: () => _engine.startMatch(gameMode: widget.mode, diff: widget.difficulty),
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('بازی دوباره'),
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00E5FF), foregroundColor: Colors.black),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.home_rounded), label: const Text('بازگشت به خانه')),
      ]),
    );
  }

  Widget _reward(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: <Color>[color.withOpacity(0.14), Colors.white.withOpacity(0.04)]),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
    );
  }

  Widget _overlay({required Widget child}) {
    return Container(
      color: const Color(0xC0040612),
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 430),
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[Color(0xFF141A3A), Color(0xFF0D1023), Color(0xFF0A0C1E)],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
            boxShadow: <BoxShadow>[
              BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.15), blurRadius: 50),
              BoxShadow(color: Colors.black.withOpacity(0.28), blurRadius: 30, offset: const Offset(0, 14)),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}
