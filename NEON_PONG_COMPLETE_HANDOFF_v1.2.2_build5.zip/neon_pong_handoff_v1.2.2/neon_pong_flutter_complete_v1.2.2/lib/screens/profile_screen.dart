import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../services/audio_feedback.dart';
import '../utils/fa_digits.dart';
import '../widgets/pressable_surface.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.onOpenShop});

  final VoidCallback onOpenShop;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 130),
            children: <Widget>[
              Row(children: <Widget>[
                const Expanded(child: Text('👤 پروفایل', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
                _coin(save.coins),
              ]),
              const SizedBox(height: 14),
              _profileHeader(context, save),
              const SizedBox(height: 12),
              _stats(save),
              const SizedBox(height: 12),
              _equipment(save),
              const SizedBox(height: 12),
              _avatars(save),
              const SizedBox(height: 12),
              _history(save),
            ],
          );
        },
      ),
    );
  }

  Widget _coin(int coins) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 7),
      decoration: BoxDecoration(color: const Color(0xFFFFD54F).withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFFFD54F).withOpacity(0.5))),
      child: Text('🪙 ${faNumber(coins)}', style: const TextStyle(color: Color(0xFFFFE259), fontWeight: FontWeight.w900)),
    );
  }

  Widget _profileHeader(BuildContext context, SaveData save) {
    return _card(
      child: Column(
        children: <Widget>[
          Container(
            width: 94,
            height: 94,
            decoration: BoxDecoration(
              color: const Color(0xFF00E5FF).withOpacity(0.08),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.5), width: 3),
              boxShadow: <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.35), blurRadius: 30)],
            ),
            child: Center(child: Text(save.avatarEmoji, style: const TextStyle(fontSize: 52))),
          ),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            Text(save.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(width: 8),
            IconButton(onPressed: () => _editName(context, save), icon: const Icon(Icons.edit_rounded, size: 18), style: IconButton.styleFrom(backgroundColor: Colors.white.withOpacity(0.08), minimumSize: const Size(32, 32), padding: EdgeInsets.zero)),
          ]),
          const SizedBox(height: 12),
          Row(children: <Widget>[
            Text('سطح ${faNumber(save.level)}', style: const TextStyle(fontSize: 12.5, color: Color(0xFF9FB2D8))),
            const SizedBox(width: 10),
            Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: save.levelProgress / 150, minHeight: 9, backgroundColor: Colors.white.withOpacity(0.08), valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF00E5FF))))),
            const SizedBox(width: 10),
            Text('${faNumber(save.levelProgress)} / ۱۵۰ ⭐', style: const TextStyle(fontSize: 12.5, color: Color(0xFF9FB2D8))),
          ]),
        ],
      ),
    );
  }

  Widget _stats(SaveData save) {
    final List<(String, String, String)> values = <(String, String, String)>[
      ('🎮', faNumber(save.matches), 'بازی'),
      ('🏆', faNumber(save.wins), 'برد'),
      ('💔', faNumber(save.losses), 'باخت'),
      ('📈', '${faNumber((save.winRate * 100).round())}٪', 'نرخ برد'),
      ('🎖️', faNumber(save.points), 'امتیاز لیگ'),
      ('🪙', faNumber(save.coins), 'سکه'),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: values.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: 1.05),
      itemBuilder: (BuildContext context, int index) {
        final (String, String, String) data = values[index];
        return Container(
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[const Color(0xFF182041), const Color(0xFF0D1225)]), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.10)), boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.22), blurRadius: 10, offset: const Offset(0, 6))]),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
            Text(data.$1, style: const TextStyle(fontSize: 21)),
            Text(data.$2, style: const TextStyle(fontSize: 18, color: Color(0xFF8FF4FF), fontWeight: FontWeight.w900)),
            Text(data.$3, style: const TextStyle(fontSize: 11, color: Color(0xFF8FA3C8))),
          ]),
        );
      },
    );
  }

  Widget _equipment(SaveData save) {
    const List<(ItemCategory, String)> rows = <(ItemCategory, String)>[
      (ItemCategory.paddle, '🏓 راکت'),
      (ItemCategory.ball, '⚪ توپ'),
      (ItemCategory.trail, '💫 دنباله'),
      (ItemCategory.theme, '🌌 زمین'),
      (ItemCategory.boom, '💥 افکت گل'),
    ];
    return _card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        const Text('🎨 تجهیزات من', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        ...rows.map(((ItemCategory, String) row) {
          final ShopItem item = save.selectedItem(row.$1);
          return Container(
            padding: const EdgeInsets.symmetric(vertical: 9),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06)))),
            child: Row(children: <Widget>[
              Expanded(child: Text(row.$2, style: const TextStyle(color: Color(0xFF9FB2D8)))),
              Text(item.name, style: const TextStyle(color: Color(0xFF8FF4FF), fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              TextButton(onPressed: onOpenShop, child: const Text('تغییر')),
            ]),
          );
        }),
      ]),
    );
  }

  Widget _avatars(SaveData save) {
    final List<ShopItem> avatars = shopItems.where((ShopItem item) => item.category == ItemCategory.avatar && save.owned.contains(item.id)).toList();
    return _card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        const Text('😀 آواتارهای من', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: avatars.map((ShopItem item) {
            final bool selected = save.selected['avatar'] == item.id;
            return PressableSurface(
              onTap: () async {
                await save.select(item);
                AudioFeedbackService.instance.play(FeedbackEvent.select);
              },
              playTapSound: false,
              borderRadius: BorderRadius.circular(16),
              pressedScale: 0.92,
              child: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: selected ? LinearGradient(colors: <Color>[const Color(0xFF38FFB0).withOpacity(0.22), const Color(0xFF0D1225)]) : const LinearGradient(colors: <Color>[Color(0xFF161C34), Color(0xFF0D1225)]),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: selected ? const Color(0xFF38FFB0) : Colors.white.withOpacity(0.2), width: 2),
                  boxShadow: selected ? <BoxShadow>[BoxShadow(color: const Color(0xFF38FFB0).withOpacity(0.4), blurRadius: 16)] : <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.20), blurRadius: 10, offset: const Offset(0, 6))],
                ),
                child: Center(child: Text(item.emoji ?? '😀', style: const TextStyle(fontSize: 27))),
              ),
            );
          }).toList(),
        ),
      ]),
    );
  }

  Widget _history(SaveData save) {
    return _card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        const Text('🕹️ تاریخچه بازی‌ها', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        if (save.history.isEmpty)
          const Text('هنوز بازی نکردی! 🎮', style: TextStyle(color: Color(0xFF8FA3C8), fontSize: 13))
        else
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: save.history.reversed.map((MatchHistoryEntry entry) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: (entry.won ? const Color(0xFF38FFB0) : const Color(0xFFFF5577)).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: (entry.won ? const Color(0xFF38FFB0) : const Color(0xFFFF5577)).withOpacity(0.45)),
                ),
                child: Text('${entry.mode == 'bot' ? '🤖' : '👥'} ${faNumber(entry.playerScore)}–${faNumber(entry.opponentScore)} ${entry.won ? '✓' : '✗'}', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, color: entry.won ? const Color(0xFF7DFFC4) : const Color(0xFFFF8BA4))),
              );
            }).toList(),
          ),
      ]),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF1A2145), Color(0xFF10162E), Color(0xFF090C1A)]),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.20)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.28), blurRadius: 16, offset: const Offset(0, 10)),
          BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.06), blurRadius: 22, offset: const Offset(0, 8)),
        ],
      ),
      child: child,
    );
  }

  Future<void> _editName(BuildContext context, SaveData save) async {
    final TextEditingController controller = TextEditingController(text: save.name);
    final String? value = await showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        backgroundColor: const Color(0xFF141A3A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: const Color(0xFF00E5FF).withOpacity(0.3))),
        title: const Text('✏️ ویرایش نام'),
        content: TextField(controller: controller, maxLength: 12, autofocus: true, decoration: const InputDecoration(hintText: 'نام خود را وارد کنید')),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('ذخیره')),
        ],
      ),
    );
    controller.dispose();
    if (value != null) await save.updateName(value);
  }
}
