import 'package:flutter/material.dart';

import '../data/rank_data.dart';
import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../game/game_engine.dart';
import '../services/audio_feedback.dart';
import '../utils/fa_digits.dart';
import '../widgets/pressable_surface.dart';
import 'friend_screen.dart';
import 'game_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.onOpenShop,
    required this.onOpenRank,
    required this.onOpenProfile,
  });

  final VoidCallback onOpenShop;
  final VoidCallback onOpenRank;
  final VoidCallback onOpenProfile;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return AnimatedBuilder(
      animation: save,
      builder: (BuildContext context, Widget? child) {
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 128),
            children: <Widget>[
              _header(save),
              const SizedBox(height: 14),
              _stats(save),
              const SizedBox(height: 12),
              _hero(context),
              const SizedBox(height: 12),
              _challenge(save),
              const SizedBox(height: 12),
              _daily(context, save),
              const SizedBox(height: 12),
              _records(save),
              const SizedBox(height: 12),
              _feature(save),
            ],
          ),
        );
      },
    );
  }

  Widget _header(SaveData save) {
    return Row(
      children: <Widget>[
        InkWell(
          onTap: onOpenProfile,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[
                  const Color(0xFF00E5FF).withOpacity(0.18),
                  const Color(0xFF7A2BFF).withOpacity(0.18),
                ],
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.50), width: 1.8),
              boxShadow: <BoxShadow>[
                BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.18), blurRadius: 18, offset: const Offset(0, 8)),
              ],
            ),
            child: Center(child: Text(save.avatarEmoji, style: const TextStyle(fontSize: 28))),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text('خوش اومدی 👋', style: TextStyle(color: Color(0xFF8FA3C8), fontSize: 11.5)),
              Text(save.name, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
        _pill('🪙 ${faNumber(save.coins)}', const Color(0xFFFFE259), const Color(0xFFFFD54F)),
        const SizedBox(width: 7),
        _pill('⭐ سطح ${faNumber(save.level)}', const Color(0xFF8FF4FF), const Color(0xFF00E5FF)),
      ],
    );
  }

  Widget _pill(String text, Color foreground, Color border) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[border.withOpacity(0.18), border.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: border.withOpacity(0.45)),
        boxShadow: <BoxShadow>[BoxShadow(color: border.withOpacity(0.10), blurRadius: 14, offset: const Offset(0, 6))],
      ),
      child: Text(text, style: TextStyle(color: foreground, fontWeight: FontWeight.w900, fontSize: 12.2)),
    );
  }

  Widget _stats(SaveData save) {
    final int rank = 1 + rankBots.where((RankBot bot) => bot.points > save.points).length;
    return Row(
      children: <Widget>[
        _stat('🎮', faNumber(save.matches), 'بازی', onOpenProfile, const Color(0xFF00E5FF)),
        const SizedBox(width: 8),
        _stat('🏆', faNumber(save.wins), 'برد', onOpenProfile, const Color(0xFF38FFB0)),
        const SizedBox(width: 8),
        _stat('🎖️', faNumber(rank), 'رتبه', onOpenRank, const Color(0xFFFF2FD6)),
        const SizedBox(width: 8),
        _stat('🎯', '${faNumber(save.owned.length)}/${faNumber(shopItems.length)}', 'آیتم', onOpenShop, const Color(0xFFFFD54F)),
      ],
    );
  }

  Widget _stat(String icon, String value, String label, VoidCallback onTap, Color accent) {
    return Expanded(
      child: PressableSurface(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[accent.withOpacity(0.18), const Color(0xFF0E1228)],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: accent.withOpacity(0.34)),
            boxShadow: <BoxShadow>[
              BoxShadow(color: Colors.black.withOpacity(0.28), blurRadius: 13, offset: const Offset(0, 8)),
              BoxShadow(color: accent.withOpacity(0.10), blurRadius: 20, offset: const Offset(0, 10)),
              const BoxShadow(color: Color(0x20FFFFFF), blurRadius: 2, offset: Offset(0, -1)),
            ],
          ),
          child: Column(
            children: <Widget>[
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[Colors.white.withOpacity(0.13), accent.withOpacity(0.08)],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white.withOpacity(0.07)),
                ),
                child: Center(child: Text(icon, style: const TextStyle(fontSize: 16.5))),
              ),
              const SizedBox(height: 8),
              Text(
                value,
                style: TextStyle(
                  color: accent == const Color(0xFFFFD54F) ? const Color(0xFFFFF1A8) : accent.withOpacity(0.98),
                  fontSize: 14.5,
                  fontWeight: FontWeight.w900,
                ),
                maxLines: 1,
              ),
              Text(label, style: const TextStyle(color: Color(0xFF8FA3C8), fontSize: 10.2, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hero(BuildContext context) {
    return _card(
      child: Column(
        children: <Widget>[
          const Text(
            'آماده‌ای برای مسابقه؟ ⚡',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, shadows: <Shadow>[Shadow(color: Color(0xFF00E5FF), blurRadius: 22)]),
          ),
          const SizedBox(height: 8),
          const Text('پاورآپ‌های بیشتر، زمین‌های جذاب‌تر و رقابت تندتر منتظرته.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF9FB2D8), fontSize: 12.5)),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 58,
            child: FilledButton(
              onPressed: () => _showDifficulty(context),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF00E5FF),
                foregroundColor: const Color(0xFF031018),
                elevation: 10,
                shadowColor: const Color(0xFF00E5FF).withOpacity(0.35),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(19)),
              ),
              child: const Text('🚀 بازی با ربات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const FriendScreen())),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFFFB8EC),
                backgroundColor: const Color(0xFFFF2FD6).withOpacity(0.08),
                side: BorderSide(color: const Color(0xFFFF2FD6).withOpacity(0.55)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
              ),
              child: const Text('👥 دو نفره با دوست', style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: const <Widget>[
              Expanded(child: _MiniHint(icon: '💥', title: 'افکت‌های تازه', subtitle: 'پاورآپ‌های بزرگ‌تر')),
              SizedBox(width: 8),
              Expanded(child: _MiniHint(icon: '🛍️', title: 'فروشگاه کامل‌تر', subtitle: 'آیتم‌های بیشتر')),
              SizedBox(width: 8),
              Expanded(child: _MiniHint(icon: '⚙️', title: 'کنترل بهتر', subtitle: 'بازخورد سریع')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _challenge(SaveData save) {
    const int target = 5;
    final double progress = (save.winsToday / target).clamp(0, 1).toDouble();
    return _card(
      border: const Color(0xFFFF2FD6),
      gradient: <Color>[const Color(0xFFFF2FD6).withOpacity(0.14), const Color(0xFF7A2BFF).withOpacity(0.20), const Color(0xFF0A0C1E)],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('🔥 چالش روزانه: ۵ برد', style: TextStyle(color: Color(0xFFFFB8EC), fontSize: 15.5, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('امروز ${faNumber(save.winsToday)} از ${faNumber(target)} برد انجام دادی!', style: const TextStyle(fontSize: 13)),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(value: progress, minHeight: 10, backgroundColor: Colors.white.withOpacity(0.08), valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFF2FD6))),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              const Text('🎯 پیشرفت', style: TextStyle(color: Color(0xFFFFB8EC), fontSize: 11.5)),
              Text(save.winsToday >= target ? '🏆 تکمیل شد!' : '${faNumber(target - save.winsToday)} مونده', style: const TextStyle(color: Color(0xFFFFB8EC), fontSize: 11.5)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _daily(BuildContext context, SaveData save) {
    final bool canClaim = save.canClaimDaily();
    return _card(
      child: Row(
        children: <Widget>[
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: <Color>[const Color(0xFFFFD54F).withOpacity(0.22), Colors.white.withOpacity(0.03)]),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFFFD54F).withOpacity(0.30)),
            ),
            child: Center(child: Text(canClaim ? '🎁' : '✅', style: const TextStyle(fontSize: 27))),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(canClaim ? 'جایزه روزانه' : 'جایزه امروزت رو گرفتی!', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
                Text(canClaim ? 'امروز ۱۰۰ سکه رایگان بگیر!' : 'فردا دوباره سر بزن 🌙', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 12.5)),
              ],
            ),
          ),
          if (canClaim)
            FilledButton(
              onPressed: () async {
                final bool claimed = await save.claimDaily();
                if (claimed) AudioFeedbackService.instance.play(FeedbackEvent.claim);
                if (context.mounted && claimed) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('🎉 ۱۰۰ سکه گرفتی!')));
                }
              },
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFD54F), foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)),
              child: const Text('دریافت', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
        ],
      ),
    );
  }

  Widget _records(SaveData save) {
    return _card(
      border: const Color(0xFF38FFB0),
      gradient: <Color>[const Color(0xFF38FFB0).withOpacity(0.10), const Color(0xFF00E5FF).withOpacity(0.14), const Color(0xFF0A0C1E)],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('📊 رکوردهای شخصی', style: TextStyle(color: Color(0xFF7DFFC4), fontSize: 14.5, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Row(children: <Widget>[
            Expanded(child: _record('🔥 بهترین Streak', '${faNumber(save.bestStreak)} برد', const Color(0xFF38FFB0))),
            const SizedBox(width: 8),
            Expanded(child: _record('🎯 نرخ برد', '${faNumber((save.winRate * 100).round())}٪', const Color(0xFF00E5FF))),
          ]),
          const SizedBox(height: 8),
          Row(children: <Widget>[
            Expanded(child: _record('✨ Power-Ups', faNumber(save.totalPowerups), const Color(0xFFFFD54F))),
            const SizedBox(width: 8),
            Expanded(child: _record('🏆 امتیاز لیگ', faNumber(save.points), const Color(0xFFFF2FD6))),
          ]),
        ],
      ),
    );
  }

  Widget _record(String label, String value, Color accent) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[accent.withOpacity(0.16), Colors.white.withOpacity(0.03)]),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accent.withOpacity(0.25)),
        boxShadow: <BoxShadow>[BoxShadow(color: accent.withOpacity(0.06), blurRadius: 14, offset: const Offset(0, 7))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Text(label, style: const TextStyle(color: Color(0xFFB8D6E8), fontSize: 11.5)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(color: accent == const Color(0xFFFFD54F) ? const Color(0xFFFFF1A8) : accent, fontSize: 14.5, fontWeight: FontWeight.w900)),
      ]),
    );
  }

  Widget _feature(SaveData save) {
    final List<ShopItem> unowned = shopItems.where((ShopItem item) => !save.owned.contains(item.id)).toList()..sort((ShopItem a, ShopItem b) => b.price.compareTo(a.price));
    final ShopItem? feature = unowned.isEmpty ? null : unowned.first;
    return _card(
      child: Row(
        children: <Widget>[
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: <Color>[const Color(0xFFFF6CC7).withOpacity(0.22), const Color(0xFF7A2BFF).withOpacity(0.18)]),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFFF2FD6).withOpacity(0.22)),
            ),
            child: Center(child: Text(feature == null ? '🌟' : '🔥', style: const TextStyle(fontSize: 28))),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Text(feature == null ? 'همه آیتم‌ها مال توئه!' : 'پیشنهاد ویژه فروشگاه', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
              Text(feature == null ? 'کلکسیونت کامل شد 🎉' : '${categoryNames[feature.category]} • ${feature.name} • ${faNumber(feature.price)} سکه', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 12)),
            ]),
          ),
          OutlinedButton(onPressed: onOpenShop, child: const Text('مشاهده')),
        ],
      ),
    );
  }

  Widget _card({required Widget child, Color? border, List<Color>? gradient}) {
    final Color glowColor = border ?? const Color(0xFF00E5FF);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: gradient ?? const <Color>[Color(0xFF1A2145), Color(0xFF10162E), Color(0xFF090C1A)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: glowColor.withOpacity(0.28)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 12)),
          BoxShadow(color: glowColor.withOpacity(0.08), blurRadius: 28, offset: const Offset(0, 10)),
        ],
      ),
      child: child,
    );
  }

  Future<void> _showDifficulty(BuildContext context) async {
    final int? difficulty = await showDialog<int>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        backgroundColor: const Color(0xFF141A3A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: const Color(0xFF00E5FF).withOpacity(0.3))),
        title: const Text('🤖 سطح ربات را انتخاب کن', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _difficultyButton(context, 0, '🌱 آسان', 'برای گرم کردن'),
            _difficultyButton(context, 1, '⚡ متوسط', 'یه چالش معمولی'),
            _difficultyButton(context, 2, '🔥 سخت', 'فقط حرفه‌ای‌ها'),
            _difficultyButton(context, 3, '💀 غیرممکن', 'شبیه‌ساز دیوار!'),
          ],
        ),
      ),
    );
    if (difficulty != null && context.mounted) {
      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => GameScreen(mode: GameMode.bot, difficulty: difficulty)));
    }
  }

  Widget _difficultyButton(BuildContext context, int value, String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SizedBox(
        width: double.infinity,
        child: OutlinedButton(
          onPressed: () => Navigator.pop(context, value),
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), side: BorderSide(color: Colors.white.withOpacity(0.2)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: <Widget>[Text(title), Text(subtitle, style: const TextStyle(color: Color(0xFF8FA3C8), fontSize: 12))]),
        ),
      ),
    );
  }
}

class _MiniHint extends StatelessWidget {
  const _MiniHint({required this.icon, required this.title, required this.subtitle});

  final String icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        children: <Widget>[
          Text(icon, style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 5),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.2, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.2, color: Color(0xFF8FA3C8))),
        ],
      ),
    );
  }
}
