import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import '../services/audio_feedback.dart';
import '../utils/fa_digits.dart';
import '../widgets/pressable_surface.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  ItemCategory _category = ItemCategory.paddle;

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return SafeArea(
      child: AnimatedBuilder(
        animation: save,
        builder: (BuildContext context, Widget? child) {
          final List<ShopItem> items = shopItems.where((ShopItem item) => item.category == _category).toList();
          return CustomScrollView(
            slivers: <Widget>[
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: <Widget>[
                      const Expanded(child: Text('🛍️ فروشگاه', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
                      _coin(save.coins),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
                sliver: SliverToBoxAdapter(
                  child: _shopBanner(items.length),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(0, 14, 0, 8),
                sliver: SliverToBoxAdapter(
                  child: SizedBox(
                    height: 54,
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, int index) {
                        final ItemCategory category = ItemCategory.values[index];
                        final bool selected = category == _category;
                        return _categoryChip(category, selected);
                      },
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemCount: ItemCategory.values.length,
                    ),
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 130),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 205,
                    mainAxisExtent: 230,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) => _itemCard(context, save, items[index]),
                    childCount: items.length,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _shopBanner(int itemCount) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            const Color(0xFF00E5FF).withOpacity(0.18),
            const Color(0xFF7A2BFF).withOpacity(0.18),
            const Color(0xFF0A0E20),
          ],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.24)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.28), blurRadius: 16, offset: const Offset(0, 12)),
          BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.08), blurRadius: 20),
        ],
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Center(child: Text('✨', style: TextStyle(fontSize: 28))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('آیتم‌های بیشتر و حرفه‌ای‌تر', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('${faNumber(itemCount)} آیتم در این دسته • ظاهر آرنا را کاملاً شخصی‌سازی کن.', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 12.2)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _categoryChip(ItemCategory category, bool selected) {
    final Color accent = _categoryAccent(category);
    return PressableSurface(
      onTap: () {
        setState(() => _category = category);
        AudioFeedbackService.instance.play(FeedbackEvent.select);
      },
      playTapSound: false,
      pressedScale: 0.94,
      borderRadius: BorderRadius.circular(18),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: selected
              ? LinearGradient(colors: <Color>[accent.withOpacity(0.30), accent.withOpacity(0.11)])
              : const LinearGradient(colors: <Color>[Color(0xFF151C38), Color(0xFF0B1023)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: selected ? accent.withOpacity(0.58) : Colors.white.withOpacity(0.09)),
          boxShadow: <BoxShadow>[
            BoxShadow(color: Colors.black.withOpacity(0.22), blurRadius: 10, offset: const Offset(0, 6)),
            if (selected) BoxShadow(color: accent.withOpacity(0.20), blurRadius: 18, offset: const Offset(0, 8)),
          ],
        ),
        child: Center(
          child: Text(
            categoryNames[category]!,
            style: TextStyle(color: selected ? Colors.white : const Color(0xFFB8C6E8), fontSize: 12.6, fontWeight: FontWeight.w800),
          ),
        ),
      ),
    );
  }

  Widget _coin(int coins) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: <Color>[const Color(0xFFFFD54F).withOpacity(0.18), const Color(0xFF0F1221)]),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFFFD54F).withOpacity(0.50)),
      ),
      child: Text('🪙 ${faNumber(coins)}', style: const TextStyle(color: Color(0xFFFFE259), fontWeight: FontWeight.w900)),
    );
  }

  Widget _itemCard(BuildContext context, SaveData save, ShopItem item) {
    final bool owned = save.owned.contains(item.id);
    final bool selected = save.selected[categoryKeys[item.category]] == item.id;
    final String tier = _tierLabel(item.price);
    final Color accent = _tierColor(item.price);

    return PressableSurface(
      enabled: true,
      haptic: owned && !selected,
      onTap: owned && !selected
          ? () async {
              await save.select(item);
              AudioFeedbackService.instance.play(FeedbackEvent.select);
            }
          : null,
      playTapSound: false,
      borderRadius: BorderRadius.circular(22),
      child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[
                selected ? accent.withOpacity(0.22) : Colors.white.withOpacity(0.06),
                const Color(0xFF0C1023),
              ],
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: selected ? accent.withOpacity(0.65) : Colors.white.withOpacity(0.10), width: selected ? 1.6 : 1),
            boxShadow: <BoxShadow>[
              BoxShadow(color: Colors.black.withOpacity(0.30), blurRadius: 16, offset: const Offset(0, 10)),
              if (selected || !owned) BoxShadow(color: accent.withOpacity(selected ? 0.20 : 0.10), blurRadius: 18, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: accent.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: accent.withOpacity(0.30)),
                      ),
                      child: Text(tier, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent == const Color(0xFFFFD54F) ? const Color(0xFFFFF1A8) : accent, fontSize: 10.8, fontWeight: FontWeight.w900)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (selected)
                    const Icon(Icons.check_circle_rounded, color: Color(0xFF38FFB0), size: 20)
                  else if (owned)
                    const Icon(Icons.inventory_2_rounded, color: Color(0xFF8FF4FF), size: 20),
                ],
              ),
              const SizedBox(height: 10),
              Expanded(
                child: Center(
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.03),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: Center(child: _preview(item)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(item.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14.5)),
              const SizedBox(height: 2),
              Text(_subtitle(item.category), style: const TextStyle(color: Color(0xFF8FA3C8), fontSize: 11.2)),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 38,
                child: selected
                    ? FilledButton(
                        onPressed: null,
                        style: FilledButton.styleFrom(disabledBackgroundColor: const Color(0xFF38FFB0).withOpacity(0.18), disabledForegroundColor: const Color(0xFF9EFFD4)),
                        child: const Text('✓ انتخاب شد', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                      )
                    : owned
                        ? OutlinedButton(
                            onPressed: () async {
                              await save.select(item);
                              AudioFeedbackService.instance.play(FeedbackEvent.select);
                            },
                            style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF8FF4FF), side: BorderSide(color: const Color(0xFF00E5FF).withOpacity(0.50))),
                            child: const Text('انتخاب', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                          )
                        : FilledButton(
                            onPressed: save.coins >= item.price
                                ? () async {
                                    final bool purchased = await save.buy(item);
                                    AudioFeedbackService.instance.play(purchased ? FeedbackEvent.buy : FeedbackEvent.error);
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(purchased ? '🎉 «${item.name}» خریداری شد!' : '😅 سکه کافی نیست')));
                                    }
                                  }
                                : () {
                                    AudioFeedbackService.instance.play(FeedbackEvent.error);
                                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('😅 سکه کافی نیست! بازی کن و سکه جمع کن')));
                                  },
                            style: FilledButton.styleFrom(
                              backgroundColor: save.coins >= item.price ? accent : Colors.white.withOpacity(0.08),
                              foregroundColor: save.coins >= item.price && accent != const Color(0xFF00E5FF) ? Colors.black : Colors.white,
                            ),
                            child: Text('🪙 ${faNumber(item.price)}', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                          ),
              ),
            ],
          ),
        ),
    );
  }

  String _subtitle(ItemCategory category) {
    switch (category) {
      case ItemCategory.paddle:
        return 'ظاهر راکت داخل میدان';
      case ItemCategory.ball:
        return 'توپ ویژه مسابقه';
      case ItemCategory.trail:
        return 'رد نوری پشت توپ';
      case ItemCategory.theme:
        return 'تم کامل زمین بازی';
      case ItemCategory.avatar:
        return 'آواتار پروفایل';
      case ItemCategory.boom:
        return 'افکت انفجار گل';
    }
  }

  String _tierLabel(int price) {
    if (price == 0) return 'رایگان';
    if (price <= 250) return 'معمولی';
    if (price <= 600) return 'کمیاب';
    if (price <= 900) return 'اپیک';
    return 'افسانه‌ای';
  }

  Color _tierColor(int price) {
    if (price == 0) return const Color(0xFF00E5FF);
    if (price <= 250) return const Color(0xFF38FFB0);
    if (price <= 600) return const Color(0xFF00E5FF);
    if (price <= 900) return const Color(0xFFFF2FD6);
    return const Color(0xFFFFD54F);
  }

  Color _categoryAccent(ItemCategory category) {
    switch (category) {
      case ItemCategory.paddle:
        return const Color(0xFF00E5FF);
      case ItemCategory.ball:
        return const Color(0xFFFFD54F);
      case ItemCategory.trail:
        return const Color(0xFF38FFB0);
      case ItemCategory.theme:
        return const Color(0xFF7A2BFF);
      case ItemCategory.avatar:
        return const Color(0xFFFF2FD6);
      case ItemCategory.boom:
        return const Color(0xFFFF8A65);
    }
  }

  Widget _preview(ShopItem item) {
    switch (item.category) {
      case ItemCategory.paddle:
        return Container(
          width: 24,
          height: 82,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: item.rainbow
                ? const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[Colors.red, Colors.orange, Colors.yellow, Colors.green, Colors.blue, Colors.purple])
                : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[item.color1!, Colors.white, item.color2!]),
            boxShadow: <BoxShadow>[BoxShadow(color: (item.color1 ?? const Color(0xFFFF00FF)).withOpacity(0.55), blurRadius: 16)],
          ),
        );
      case ItemCategory.ball:
        final List<Color> colors = item.rainbow
            ? const <Color>[Colors.white, Color(0xFFFF00FF), Color(0xFF00FFFF)]
            : <Color>[item.color1!, item.color2!, item.color3!];
        return Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(center: const Alignment(-0.3, -0.3), colors: colors),
            boxShadow: <BoxShadow>[BoxShadow(color: colors[1].withOpacity(0.5), blurRadius: 18)],
          ),
        );
      case ItemCategory.trail:
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(width: 22, height: 22, decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white)),
            const SizedBox(height: 9),
            Container(
              width: 94,
              height: 12,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: item.color1 == null ? null : LinearGradient(colors: <Color>[item.color1!.withOpacity(0.0), item.color1!]),
                color: item.color1 == null ? const Color(0xFF30354A) : null,
              ),
            ),
          ],
        );
      case ItemCategory.theme:
        return Container(
          width: 94,
          height: 66,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: item.background!)),
          child: Stack(children: <Widget>[
            Positioned(top: 10, left: 16, child: _dot(item.starColor!)),
            Positioned(top: 22, right: 18, child: _dot(item.starColor!)),
            Positioned(bottom: 11, left: 18, right: 18, child: Container(height: 2, color: item.courtColor ?? Colors.white24)),
            Positioned(left: 46, top: 8, bottom: 8, child: Container(width: 2, color: item.courtColor ?? Colors.white24)),
            Positioned(bottom: 12, left: 45, child: _dot(item.accentColor!, size: 5)),
          ]),
        );
      case ItemCategory.avatar:
        return Text(item.emoji!, style: const TextStyle(fontSize: 50));
      case ItemCategory.boom:
        return Wrap(
          alignment: WrapAlignment.center,
          spacing: 6,
          runSpacing: 6,
          children: item.boomColors
              .map((Color color) => Container(width: 16, height: 16, decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: <BoxShadow>[BoxShadow(color: color, blurRadius: 10)])))
              .toList(),
        );
    }
  }

  Widget _dot(Color color, {double size = 4}) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}
