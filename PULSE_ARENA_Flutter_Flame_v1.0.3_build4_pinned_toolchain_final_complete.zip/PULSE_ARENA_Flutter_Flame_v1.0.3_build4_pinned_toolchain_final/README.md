# PULSE ARENA – Flutter + Flame Demo

دموی آفلاین و قابل‌بازی فونگ آینده‌نگر برای Android، ساخته‌شده با Flutter و Flame.

## نسخه

- Flutter app: `1.0.2+3`
- Hotfix: اصلاح Importهای گرافیکی سازگار با Flutter Stable و رفع ۱۳ خطای `flutter analyze` در Build 39

## امکانات

- صفحه شروع گرافیکی و Transition نرم
- مسابقه آفلاین تا امتیاز ۷ مقابل ربات متوسط
- کنترل لمسی نرم با Drag
- توپ انرژی با Glow، Trail و ذرات برخورد
- ربات با پیش‌بینی مسیر، تأخیر واکنش، محدودیت سرعت و خطای عمدی
- قدرت‌های سپر، شتاب و پالس
- شمارش معکوس ۳، ۲، ۱ بعد از هر امتیاز
- Pause، ادامه، شروع مجدد و بازگشت
- نتیجه برد/باخت و بازی دوباره
- صدا و لرزش قابل خاموش‌کردن از منوی Pause
- Android Landscape و Safe Area
- Flavorهای بازار و مایکت در پروژه؛ Workflow نهایی فقط یک APK بازار می‌سازد

## Workflow نهایی

فایل `.github/workflows/build-pulse-arena.yml`:

- جدیدترین ZIP سورس موجود در مخزن را خودکار تشخیص می‌دهد.
- `flutter pub get` و `flutter analyze` را اجرا می‌کند.
- تست‌ها را فقط در صورت وجود فایل تست اجرا می‌کند.
- فقط یک APK Release با Flavor بازار می‌سازد.
- در صورت شکست، لاگ کامل را به‌صورت Artifact تحویل می‌دهد.
- نام APK را از نسخه داخل `pubspec.yaml` تولید می‌کند.

## امضای Release

برای امضای فروشگاهی Secrets زیر را در GitHub تعریف کنید:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

اگر هیچ Secret امضایی تعریف نشده باشد، تنظیم fallback خود پروژه استفاده می‌شود که برای تست مناسب است، نه انتشار نهایی فروشگاه.

## Build 43 final toolchain lock

The final workflow is pinned to Flutter 3.44.8, Java 17, AGP 8.7.3,
Kotlin 2.1.0, and Gradle 8.9. It intentionally does not synchronize Android
plugin versions from future Flutter stable templates. This prevents a future
Flutter release from silently upgrading the extracted project to AGP 9+.

Workflow behavior:
- Detects the latest valid source ZIP in the repository.
- Builds one Bazaar release APK.
- Uploads exactly one successful Artifact: `PULSE-ARENA-APK`.
- Uploads complete diagnostic logs on failure.
