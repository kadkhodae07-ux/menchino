# یادداشت Workflow WF13 — PULSE ARENA

نسخه برنامه همچنان `2.0.0+16` است و هیچ تغییری در شناسه بسته، منطق مسابقه، UI، دارایی‌های صوتی یا تنظیمات فروشگاه ایجاد نشده است.

## علت Failure 79

WF12 سورس را با موفقیت شناسایی و استخراج کرد. تنظیمات Flutter، Java، Gradle و Android نیز تأیید شدند. توقف در مرحله `flutter analyze` بود؛ دو هشدار `unused_element_parameter` و یک مورد `prefer_const_constructors` باعث Exit Code غیرصفر شدند و Workflow پیش از تست و Build APK متوقف شد.

## اصلاحات WF13

- حذف پارامتر `key` بلااستفاده از ویجت خصوصی رتبه‌بندی.
- استفاده صریح از مقدار `tall: false` در یک فراخوانی دکمه، بدون تغییر ظاهر فعلی.
- تبدیل پنل ثابت توضیح حالت آفلاین به ساختار `const`.
- اجرای Analyzer با `--no-fatal-warnings --no-fatal-infos`؛ خطاهای واقعی همچنان Workflow را متوقف می‌کنند و هشدارها در `analyze.log` ثبت می‌شوند.
- حفظ شناسایی امن سورس ZIP یا پروژه استخراج‌شده از WF12.

## خروجی

Workflow دو APK Release برای flavorهای `bazaar` و `myket` تولید می‌کند. در نبود Secrets امضای Release، fallback امضای Debug طبق رفتار قبلی استفاده می‌شود.
