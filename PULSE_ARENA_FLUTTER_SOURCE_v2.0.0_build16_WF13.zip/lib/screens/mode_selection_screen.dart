import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/design/pulse_panel.dart';
import '../core/design/pulse_progress.dart';
import '../core/design/pulse_tokens.dart';
import '../game/config/game_config.dart';
import '../game/managers/scene_transition_manager.dart';
import '../player/player_progress_controller.dart';
import '../widgets/neon_pressable.dart';

class ModeSelectionScreen extends StatelessWidget {
  const ModeSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final PlayerProgressController progress = PlayerProgressController.instance;
    return Scaffold(
      backgroundColor: PulseColors.voidBlack,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const RepaintBoundary(child: CustomPaint(painter: _ModeBackgroundPainter())),
          SafeArea(
            child: LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final double horizontal = constraints.maxWidth < 380 ? 12 : 18;
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.fromLTRB(horizontal, 10, horizontal, 22),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: constraints.maxHeight - 32),
                    child: Column(
                      children: <Widget>[
                        _ModePlayerHeader(progress: progress),
                        const SizedBox(height: 24),
                        Row(
                          children: <Widget>[
                            SizedBox(
                              width: 48,
                              height: 48,
                              child: NeonPressable(
                                semanticLabel: 'بازگشت به خانه',
                                onTap: () => Navigator.of(context).pop(),
                                builder: (_, bool pressed) => PulsePanel(
                                  colors: const <Color>[PulseColors.cyan, PulseColors.violet],
                                  cut: 13,
                                  pressed: pressed,
                                  child: const Icon(
                                    Icons.arrow_back_rounded,
                                    color: PulseColors.textPrimary,
                                    size: 25,
                                  ),
                                ),
                              ),
                            ),
                            const Expanded(
                              child: Column(
                                children: <Widget>[
                                  Text(
                                    'انتخاب حالت بازی',
                                    textDirection: TextDirection.rtl,
                                    textAlign: TextAlign.center,
                                    style: PulseTypography.display,
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    'حالت مناسب نبرد را انتخاب کن',
                                    textDirection: TextDirection.rtl,
                                    textAlign: TextAlign.center,
                                    style: PulseTypography.body,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 48),
                          ],
                        ),
                        const SizedBox(height: 24),
                        _ModeCard(
                          title: 'بازی آفلاین',
                          subtitle: 'نبرد کامل برابر هوش مصنوعی با ثبت آمار، XP، پالس و امتیاز لیگ',
                          badge: 'حالت اصلی',
                          colors: const <Color>[PulseColors.cyan, PulseColors.rose],
                          painter: const _BotModePainter(),
                          onTap: () async {
                            if (!context.mounted) return;
                            await SceneTransitionManager.openGame(
                              context,
                              config: GameConfig.forDifficulty(progress.difficulty),
                            );
                          },
                        ),
                        const SizedBox(height: 16),
                        _ModeCard(
                          title: 'تمرین آزاد',
                          subtitle: 'تمرین کنترل راکت و قدرت‌ها در مسابقه کوتاه؛ بدون تغییر آمار رقابتی',
                          badge: 'بدون ثبت نتیجه',
                          colors: const <Color>[PulseColors.violet, PulseColors.rose],
                          painter: const _TrainingModePainter(),
                          onTap: () async {
                            if (!context.mounted) return;
                            await SceneTransitionManager.openGame(
                              context,
                              config: GameConfig.training(),
                            );
                          },
                        ),
                        const SizedBox(height: 16),
                        const PulsePanel(
                          colors: <Color>[PulseColors.blue, PulseColors.violet],
                          cut: 16,
                          intensity: .62,
                          padding: EdgeInsets.symmetric(horizontal: 13, vertical: 11),
                          child: Row(
                            children: <Widget>[
                              Icon(Icons.offline_bolt_rounded, color: PulseColors.cyan, size: 24),
                              SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'نسخه فعلی کاملاً آفلاین است؛ حالت آنلاین تا زمان وجود زیرساخت واقعی نمایش داده نمی‌شود.',
                                  textDirection: TextDirection.rtl,
                                  textAlign: TextAlign.right,
                                  style: PulseTypography.body,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ModePlayerHeader extends StatelessWidget {
  const _ModePlayerHeader({required this.progress});

  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: const <Color>[PulseColors.cyan, PulseColors.rose],
      cut: 21,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Row(
        children: <Widget>[
          const SizedBox(
            width: 60,
            height: 60,
            child: CustomPaint(painter: _PilotAvatarPainter()),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Flexible(
                      child: Text(
                        progress.playerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textDirection: TextDirection.rtl,
                        style: PulseTypography.section,
                      ),
                    ),
                    const SizedBox(width: 7),
                    PulsePanel(
                      colors: const <Color>[PulseColors.cyan, PulseColors.violet],
                      cut: 6,
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                      child: Text(
                        '${progress.level}',
                        style: const TextStyle(
                          color: PulseColors.textPrimary,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 7),
                PulseProgress(
                  value: progress.levelProgress,
                  label: '${progress.levelXp} / ${progress.nextLevelXp} XP',
                  colors: const <Color>[PulseColors.cyan, PulseColors.blue],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Column(
            children: <Widget>[
              _CompactCurrency(
                icon: Icons.bolt_rounded,
                value: progress.energy,
                color: PulseColors.cyan,
              ),
              const SizedBox(height: 7),
              _CompactCurrency(
                icon: Icons.motion_photos_on_rounded,
                value: progress.pulse,
                color: PulseColors.rose,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CompactCurrency extends StatelessWidget {
  const _CompactCurrency({required this.icon, required this.value, required this.color});

  final IconData icon;
  final int value;
  final Color color;

  String get formatted => value.toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'),
        (_) => '٬',
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 82),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: PulseColors.panelInset.withValues(alpha: .86),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: .42)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, color: color, size: 17),
          const SizedBox(width: 5),
          Text(
            formatted,
            style: const TextStyle(
              color: PulseColors.textPrimary,
              fontSize: 11,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.colors,
    required this.painter,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final String badge;
  final List<Color> colors;
  final CustomPainter painter;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 206,
      child: NeonPressable(
        semanticLabel: title,
        onTap: onTap,
        builder: (_, bool pressed) {
          return PulsePanel(
            colors: colors,
            cut: 28,
            pressed: pressed,
            intensity: 1,
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
            child: Row(
              children: <Widget>[
                Expanded(
                  flex: 5,
                  child: RepaintBoundary(child: CustomPaint(painter: painter)),
                ),
                const SizedBox(width: 16),
                Expanded(
                  flex: 7,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: colors.last.withValues(alpha: .12),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: colors.last.withValues(alpha: .45)),
                        ),
                        child: Text(
                          badge,
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: colors.last,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        title,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        style: const TextStyle(
                          color: PulseColors.textPrimary,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        subtitle,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        style: PulseTypography.body,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          const Text(
                            'ورود به آرنا',
                            textDirection: TextDirection.rtl,
                            style: PulseTypography.label,
                          ),
                          const SizedBox(width: 6),
                          Icon(Icons.chevron_left_rounded, color: colors.last, size: 25),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _ModeBackgroundPainter extends CustomPainter {
  const _ModeBackgroundPainter();

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-.15, -.55),
          radius: 1.3,
          colors: <Color>[Color(0xFF0B1730), PulseColors.voidBlack],
        ).createShader(Offset.zero & size),
    );
    final Paint grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .55
      ..color = PulseColors.cyan.withValues(alpha: .045);
    const double r = 20;
    final double h = math.sqrt(3) * r;
    for (double y = -h; y < size.height + h; y += h) {
      for (double x = -r; x < size.width + r; x += r * 3) {
        _drawHex(canvas, Offset(x, y), r, grid);
        _drawHex(canvas, Offset(x + r * 1.5, y + h / 2), r, grid);
      }
    }
    canvas.drawCircle(
      Offset(size.width * .12, size.height * .35),
      size.width * .42,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            PulseColors.cyan.withValues(alpha: .09),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(
          center: Offset(size.width * .12, size.height * .35),
          radius: size.width * .42,
        )),
    );
    canvas.drawCircle(
      Offset(size.width * .9, size.height * .65),
      size.width * .5,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            PulseColors.rose.withValues(alpha: .075),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(
          center: Offset(size.width * .9, size.height * .65),
          radius: size.width * .5,
        )),
    );
  }

  void _drawHex(Canvas canvas, Offset center, double radius, Paint paint) {
    final Path path = Path();
    for (int i = 0; i < 6; i++) {
      final double angle = math.pi / 3 * i;
      final Offset point = center + Offset(math.cos(angle), math.sin(angle)) * radius;
      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _ModeBackgroundPainter oldDelegate) => false;
}

class _BotModePainter extends CustomPainter {
  const _BotModePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    final double radius = math.min(size.width, size.height) * .34;
    canvas.drawCircle(
      center,
      radius * 1.38,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            PulseColors.cyan.withValues(alpha: .24),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(center: center, radius: radius * 1.38)),
    );
    final RRect head = RRect.fromRectAndRadius(
      Rect.fromCenter(center: center, width: radius * 1.58, height: radius * 1.18),
      Radius.circular(radius * .27),
    );
    canvas.drawRRect(
      head,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF18355C), Color(0xFF071020)],
        ).createShader(head.outerRect),
    );
    canvas.drawRRect(
      head,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.3
        ..shader = const LinearGradient(
          colors: <Color>[PulseColors.cyan, PulseColors.rose],
        ).createShader(head.outerRect),
    );
    final Rect face = Rect.fromCenter(
      center: center,
      width: radius * 1.12,
      height: radius * .62,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(face, Radius.circular(radius * .2)),
      Paint()..color = const Color(0xFF020A15),
    );
    for (final double dx in <double>[-.28, .28]) {
      final Offset eye = center + Offset(radius * dx, 0);
      canvas.drawCircle(
        eye,
        radius * .105,
        Paint()
          ..color = dx < 0 ? PulseColors.cyan : PulseColors.rose
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
      canvas.drawCircle(eye, radius * .055, Paint()..color = Colors.white);
    }
    canvas.drawLine(
      center + Offset(-radius * .33, radius * .32),
      center + Offset(radius * .33, radius * .32),
      Paint()
        ..color = PulseColors.violet
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      center - Offset(0, radius * .6),
      center - Offset(0, radius * .88),
      Paint()
        ..color = PulseColors.cyan
        ..strokeWidth = 2.2,
    );
    canvas.drawCircle(
      center - Offset(0, radius * .94),
      radius * .08,
      Paint()..color = PulseColors.rose,
    );
  }

  @override
  bool shouldRepaint(covariant _BotModePainter oldDelegate) => false;
}

class _TrainingModePainter extends CustomPainter {
  const _TrainingModePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    final double radius = math.min(size.width, size.height) * .38;
    for (int i = 0; i < 4; i++) {
      final double r = radius * (1 - i * .21);
      canvas.drawCircle(
        center,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.1
          ..color = Color.lerp(PulseColors.cyan, PulseColors.rose, i / 3)!
              .withValues(alpha: .75),
      );
    }
    canvas.drawCircle(
      center,
      radius * .12,
      Paint()
        ..color = PulseColors.rose
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    final Offset start = center + Offset(-radius * .72, radius * .65);
    final Offset end = center + Offset(radius * .18, -radius * .18);
    canvas.drawLine(
      start,
      end,
      Paint()
        ..color = PulseColors.textPrimary
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      start,
      end,
      Paint()
        ..color = PulseColors.violet
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round,
    );
    final Path arrow = Path()
      ..moveTo(end.dx, end.dy)
      ..lineTo(end.dx - 5, end.dy - 23)
      ..lineTo(end.dx + 18, end.dy - 10)
      ..close();
    canvas.drawPath(arrow, Paint()..color = PulseColors.rose);
    canvas.drawCircle(
      center,
      radius * 1.25,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .8
        ..color = PulseColors.violet.withValues(alpha: .22),
    );
  }

  @override
  bool shouldRepaint(covariant _TrainingModePainter oldDelegate) => false;
}

class _PilotAvatarPainter extends CustomPainter {
  const _PilotAvatarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    final Rect rect = Offset.zero & size;
    canvas.drawCircle(
      center,
      size.shortestSide * .47,
      Paint()
        ..shader = const SweepGradient(
          colors: <Color>[PulseColors.cyan, PulseColors.violet, PulseColors.rose, PulseColors.cyan],
        ).createShader(rect),
    );
    canvas.drawCircle(center, size.shortestSide * .42, Paint()..color = PulseColors.panelInset);
    final Path helmet = Path()
      ..moveTo(size.width * .25, size.height * .68)
      ..quadraticBezierTo(size.width * .20, size.height * .28, size.width * .50, size.height * .19)
      ..quadraticBezierTo(size.width * .80, size.height * .28, size.width * .75, size.height * .68)
      ..quadraticBezierTo(size.width * .50, size.height * .86, size.width * .25, size.height * .68)
      ..close();
    canvas.drawPath(
      helmet,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF293861), Color(0xFF080B18)],
        ).createShader(rect),
    );
    final Path visor = Path()
      ..moveTo(size.width * .31, size.height * .42)
      ..quadraticBezierTo(size.width * .50, size.height * .30, size.width * .69, size.height * .42)
      ..lineTo(size.width * .64, size.height * .55)
      ..quadraticBezierTo(size.width * .50, size.height * .60, size.width * .36, size.height * .55)
      ..close();
    canvas.drawPath(visor, Paint()..color = const Color(0xFF02030A));
    canvas.drawLine(
      Offset(size.width * .34, size.height * .47),
      Offset(size.width * .66, size.height * .43),
      Paint()
        ..shader = const LinearGradient(colors: <Color>[PulseColors.cyan, PulseColors.rose])
            .createShader(rect)
        ..strokeWidth = 2.4
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant _PilotAvatarPainter oldDelegate) => false;
}
