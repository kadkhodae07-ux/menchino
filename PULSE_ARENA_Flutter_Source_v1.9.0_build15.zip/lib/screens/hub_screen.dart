import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show Picture, PictureRecorder;

import 'package:flutter/material.dart';

import '../core/design/pulse_panel.dart';
import '../core/design/pulse_progress.dart';
import '../core/design/pulse_tokens.dart';
import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../player/player_progress_controller.dart';
import '../widgets/neon_pressable.dart';

part 'hub/profile_page.dart';
part 'hub/missions_page.dart';
part 'hub/ranking_page.dart';
part 'hub/shop_page.dart';
part 'hub/settings_page.dart';

String _groupDigits(int value) {
  return value.toString().replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (_) => '٬',
  );
}

class HubScreen extends StatefulWidget {
  const HubScreen({super.key});

  @override
  State<HubScreen> createState() => _HubScreenState();
}

class _HubScreenState extends State<HubScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _ambient;
  int _tabIndex = 2;
  final PlayerProgressController _progress = PlayerProgressController.instance;
  BotDifficulty _difficulty = BotDifficulty.tactical;
  bool _leaving = false;
  OverlayEntry? _toastEntry;

  @override
  void initState() {
    super.initState();
    _difficulty = _progress.difficulty;
    WidgetsBinding.instance.addObserver(this);
    _progress.addListener(_handleProgressChanged);
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
    unawaited(AudioManager.instance.startBgm());
  }

  void _handleProgressChanged() {
    if (!mounted) return;
    setState(() => _difficulty = _progress.difficulty);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _progress.refreshMissionCycles();
    }
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      unawaited(_progress.flush());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(_progress.flush());
    _progress.removeListener(_handleProgressChanged);
    _toastEntry?.remove();
    _ambient.dispose();
    super.dispose();
  }

  Future<void> _startGame() async {
    if (_leaving) return;
    _ambient.stop(canceled: false);
    setState(() => _leaving = true);
    unawaited(AudioManager.instance.importantImpact());
    try {
      await SceneTransitionManager.openGame(
        context,
        config: GameConfig.forDifficulty(_difficulty),
      );
    } finally {
      if (!mounted) return;
      _ambient.repeat();
      setState(() => _leaving = false);
    }
  }

  void _showToast(String message) {
    _toastEntry?.remove();
    final OverlayState overlay = Overlay.of(context);
    final OverlayEntry entry = OverlayEntry(
      builder: (BuildContext context) {
        return Positioned(
          left: 42,
          right: 42,
          bottom: MediaQuery.paddingOf(context).bottom + 106,
          child: IgnorePointer(
            child: Material(
              color: Colors.transparent,
              child: PulsePanel(
                colors: const <Color>[
                  Color(0xFF57D7D2),
                  Color(0xFFD96F9D),
                ],
                cut: 15,
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 12,
                ),
                child: Text(
                  message,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
    _toastEntry = entry;
    overlay.insert(entry);
    Future<void>.delayed(const Duration(milliseconds: 1250), () {
      if (_toastEntry == entry) {
        entry.remove();
        _toastEntry = null;
      }
    });
  }

  Future<void> _editProfile() async {
    final TextEditingController controller = TextEditingController(
      text: _progress.playerName,
    );
    final String? value = await showDialog<String>(
      context: context,
      barrierColor: const Color(0xCC01030A),
      builder: (BuildContext dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 28),
          child: PulsePanel(
            colors: const <Color>[PulseColors.cyan, PulseColors.violet],
            cut: 22,
            padding: const EdgeInsets.all(18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Text(
                  'ویرایش نام فرمانده',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: PulseTypography.title,
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: controller,
                  autofocus: true,
                  maxLength: 24,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: PulseColors.textPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                  decoration: InputDecoration(
                    counterStyle: const TextStyle(color: PulseColors.textMuted),
                    hintText: 'نام بازیکن',
                    hintTextDirection: TextDirection.rtl,
                    filled: true,
                    fillColor: PulseColors.panelInset,
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: PulseColors.divider),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(
                        color: PulseColors.cyan,
                        width: 1.5,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _GraphicButton(
                        label: 'انصراف',
                        icon: Icons.close_rounded,
                        colors: const <Color>[
                          PulseColors.textMuted,
                          PulseColors.violet,
                        ],
                        onTap: () => Navigator.of(dialogContext).pop(),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _GraphicButton(
                        label: 'ذخیره',
                        icon: Icons.check_rounded,
                        colors: const <Color>[
                          PulseColors.cyan,
                          PulseColors.blue,
                        ],
                        onTap: () => Navigator.of(dialogContext).pop(
                          controller.text,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    controller.dispose();
    if (value == null) return;
    final String before = _progress.playerName;
    _progress.updateName(value);
    _showToast(
      before == _progress.playerName
          ? 'نام باید بین ۲ تا ۲۴ نویسه باشد'
          : 'نام فرمانده ذخیره شد',
    );
  }

  Future<void> _openSettings() async {
    final BotDifficulty? value = await Navigator.of(context).push<BotDifficulty>(
      PageRouteBuilder<BotDifficulty>(
        transitionDuration: const Duration(milliseconds: 300),
        reverseTransitionDuration: const Duration(milliseconds: 220),
        pageBuilder: (_, Animation<double> animation, __) {
          return FadeTransition(
            opacity: CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
            ),
            child: _SettingsScreen(initialDifficulty: _difficulty),
          );
        },
      ),
    );
    if (value != null && mounted) {
      _progress.setDifficulty(value);
      setState(() => _difficulty = value);
    }
  }

  Widget _pageForIndex(int index) {
    switch (index) {
      case 0:
        return _ProfilePage(
          key: const ValueKey<String>('profile'),
          progress: _progress,
          onEditProfile: _editProfile,
          onMessage: _showToast,
        );
      case 1:
        return _MissionsPage(
          key: const ValueKey<String>('missions'),
          progress: _progress,
          onMessage: _showToast,
        );
      case 3:
        return _RankingPage(
          key: const ValueKey<String>('ranking'),
          progress: _progress,
          onMessage: _showToast,
        );
      case 4:
        return _ShopPage(
          key: const ValueKey<String>('shop'),
          progress: _progress,
          onMessage: _showToast,
        );
      case 2:
      default:
        return _HomePage(
          key: const ValueKey<String>('home'),
          ambient: _ambient,
          progress: _progress,
          onStart: _startGame,
          onOffline: _startGame,
          onSettings: _openSettings,
          onProfile: () => setState(() => _tabIndex = 0),
          onEnergy: () => _showToast('انرژی فعلی: ${_groupDigits(_progress.energy)}'),
          onCredit: () => _showToast('پالس فعلی: ${_groupDigits(_progress.pulse)}'),
          onRanking: () => setState(() => _tabIndex = 3),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_leaving,
      child: Scaffold(
        backgroundColor: PulseColors.voidBlack,
        body: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            const RepaintBoundary(
              child: CustomPaint(painter: _HubBackgroundPainter()),
            ),
            TickerMode(
              enabled: !_leaving,
              child: SafeArea(
                child: Column(
                  children: <Widget>[
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 180),
                        switchInCurve: Curves.easeOutCubic,
                        switchOutCurve: Curves.easeInCubic,
                        transitionBuilder: (Widget child, Animation<double> a) {
                          return FadeTransition(
                            opacity: a,
                            child: ScaleTransition(
                              scale: Tween<double>(begin: .992, end: 1).animate(a),
                              child: child,
                            ),
                          );
                        },
                        child: _pageForIndex(_tabIndex),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(10, 2, 10, 7),
                      child: _BottomNavigation(
                        activeIndex: _tabIndex,
                        onTap: (int index) {
                          if (_tabIndex == index) return;
                          setState(() => _tabIndex = index);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomePage extends StatelessWidget {
  const _HomePage({
    required this.ambient,
    required this.progress,
    required this.onStart,
    required this.onOffline,
    required this.onSettings,
    required this.onProfile,
    required this.onEnergy,
    required this.onCredit,
    required this.onRanking,
    super.key,
  });

  final Animation<double> ambient;
  final PlayerProgressController progress;
  final VoidCallback onStart;
  final VoidCallback onOffline;
  final VoidCallback onSettings;
  final VoidCallback onProfile;
  final VoidCallback onEnergy;
  final VoidCallback onCredit;
  final VoidCallback onRanking;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double scale = constraints.maxWidth / 430;
        final double logicalHeight = constraints.maxHeight / scale;
        return Align(
          alignment: Alignment.topCenter,
          child: FittedBox(
            fit: BoxFit.fitWidth,
            alignment: Alignment.topCenter,
            child: SizedBox(
              width: 430,
              height: logicalHeight,
              child: _HomeStage(
                height: logicalHeight,
                ambient: ambient,
                progress: progress,
                onStart: onStart,
                onOffline: onOffline,
                onSettings: onSettings,
                onProfile: onProfile,
                onEnergy: onEnergy,
                onCredit: onCredit,
                onRanking: onRanking,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _HomeStage extends StatelessWidget {
  const _HomeStage({
    required this.height,
    required this.ambient,
    required this.progress,
    required this.onStart,
    required this.onOffline,
    required this.onSettings,
    required this.onProfile,
    required this.onEnergy,
    required this.onCredit,
    required this.onRanking,
  });

  final double height;
  final Animation<double> ambient;
  final PlayerProgressController progress;
  final VoidCallback onStart;
  final VoidCallback onOffline;
  final VoidCallback onSettings;
  final VoidCallback onProfile;
  final VoidCallback onEnergy;
  final VoidCallback onCredit;
  final VoidCallback onRanking;

  @override
  Widget build(BuildContext context) {
    final double arenaHeight = (height * .37).clamp(270.0, 335.0).toDouble();
    return Padding(
      padding: const EdgeInsets.fromLTRB(11, 8, 11, 6),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          SizedBox(
            height: 69,
            child: Row(
              children: <Widget>[
                SizedBox(
                  width: 194,
                  child: _ProfileCard(progress: progress, onTap: onProfile),
                ),
                const SizedBox(width: 4),
                SizedBox(
                  width: 101,
                  child: _ResourceCard(
                    color: const Color(0xFFE8B84A),
                    value: _groupDigits(progress.energy),
                    icon: Icons.bolt_rounded,
                    onTap: onEnergy,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: _ResourceCard(
                    color: const Color(0xFFD96F9D),
                    value: _groupDigits(progress.pulse),
                    icon: Icons.motion_photos_on_rounded,
                    onTap: onCredit,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 76, child: _GameTitle()),
          SizedBox(
            height: arenaHeight,
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Positioned.fill(
                  bottom: 17,
                  child: RepaintBoundary(
                    child: AnimatedBuilder(
                      animation: ambient,
                      builder: (_, __) {
                        return CustomPaint(
                          painter: _ArenaPreviewPainter(progress: ambient.value),
                        );
                      },
                    ),
                  ),
                ),
                const Positioned(
                  left: 115,
                  right: 115,
                  bottom: 0,
                  height: 42,
                  child: _PowerStrip(),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 336,
            height: 74,
            child: _PrimaryButton(onTap: onStart),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                width: 160,
                height: 58,
                child: _SecondaryButton(
                  label: 'بازی آفلاین',
                  icon: Icons.gps_fixed_rounded,
                  color: const Color(0xFF57D7D2),
                  onTap: onOffline,
                ),
              ),
              const SizedBox(width: 16),
              SizedBox(
                width: 160,
                height: 58,
                child: _SecondaryButton(
                  label: 'تنظیمات',
                  icon: Icons.settings_rounded,
                  color: const Color(0xFFD96F9D),
                  onTap: onSettings,
                ),
              ),
            ],
          ),
          SizedBox(
            width: 336,
            height: 44,
            child: _SeasonRibbon(progress: progress, onTap: onRanking),
          ),
        ],
      ),
    );
  }
}

class _SeasonRibbon extends StatelessWidget {
  const _SeasonRibbon({required this.progress, required this.onTap});

  final PlayerProgressController progress;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'مشاهده رتبه‌بندی آفلاین',
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: const <Color>[PulseColors.gold, PulseColors.rose],
          cut: 13,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 13),
          child: Row(
            children: <Widget>[
              const Icon(Icons.leaderboard_rounded, color: PulseColors.gold, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'لیگ ${progress.leagueName} آفلاین • رتبه ${progress.offlineRank}',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: PulseColors.textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const Icon(Icons.chevron_left_rounded, color: PulseColors.rose, size: 22),
            ],
          ),
        );
      },
    );
  }
}

class _PageScaffold extends StatelessWidget {
  const _PageScaffold({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.children,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 16),
      child: Column(
        children: <Widget>[
          _PageHeader(
            title: title,
            subtitle: subtitle,
            icon: icon,
            colors: colors,
          ),
          const SizedBox(height: 14),
          ...children,
        ],
      ),
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation({required this.activeIndex, required this.onTap});

  final int activeIndex;
  final ValueChanged<int> onTap;

  static const List<_NavData> _items = <_NavData>[
    _NavData(Icons.person_outline_rounded, 'پروفایل'),
    _NavData(Icons.track_changes_rounded, 'ماموریت‌ها', badge: true),
    _NavData(Icons.home_rounded, 'خانه'),
    _NavData(Icons.leaderboard_rounded, 'رتبه‌بندی'),
    _NavData(Icons.shopping_cart_outlined, 'فروشگاه'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: Stack(
        clipBehavior: Clip.none,
        children: <Widget>[
          Positioned.fill(
            top: 12,
            child: PulsePanel(
              colors: const <Color>[Color(0xFF57D7D2), Color(0xFFD96F9D)],
              cut: 18,
              padding: const EdgeInsets.fromLTRB(5, 9, 5, 5),
              child: Row(
                children: <Widget>[
                  for (int i = 0; i < _items.length; i++)
                    Expanded(
                      child: i == 2
                          ? const SizedBox.shrink()
                          : _NavItem(
                              index: i,
                              data: _items[i],
                              active: activeIndex == i,
                              onTap: onTap,
                            ),
                    ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: Center(
              child: _HomeNavItem(
                active: activeIndex == 2,
                onTap: () => onTap(2),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.index,
    required this.data,
    required this.active,
    required this.onTap,
  });

  final int index;
  final _NavData data;
  final bool active;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = active
        ? (index < 2 ? const Color(0xFF62DDD7) : const Color(0xFFE07AA4))
        : const Color(0xFF7F8BAE);
    return NeonPressable(
      semanticLabel: data.label,
      pressedScale: .90,
      onTap: () => onTap(index),
      builder: (_, bool pressed) {
        return CustomPaint(
          painter: _NavCellPainter(
            color: color,
            active: active,
            pressed: pressed,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  Icon(
                    data.icon,
                    color: color,
                    size: 25,
                    shadows: active
                        ? <Shadow>[Shadow(color: color, blurRadius: 12)]
                        : null,
                  ),
                  if (data.badge)
                    const Positioned(
                      right: -5,
                      top: -3,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Color(0xFFD46D8E),
                          shape: BoxShape.circle,
                          boxShadow: <BoxShadow>[
                            BoxShadow(color: Color(0xAAFF3C96), blurRadius: 7),
                          ],
                        ),
                        child: SizedBox(width: 7, height: 7),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                data.label,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                style: TextStyle(
                  color: color,
                  fontSize: 9.5,
                  fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HomeNavItem extends StatelessWidget {
  const _HomeNavItem({required this.active, required this.onTap});

  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 78,
      height: 78,
      child: NeonPressable(
        semanticLabel: 'خانه',
        pressedScale: .90,
        onTap: onTap,
        builder: (_, bool pressed) {
          return CustomPaint(
            painter: _HomeNavPainter(active: active, pressed: pressed),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  Icons.home_rounded,
                  size: 32,
                  color: active ? Colors.white : const Color(0xFF99A5C5),
                  shadows: active
                      ? const <Shadow>[
                          Shadow(color: Color(0xFF5ADBD5), blurRadius: 14),
                          Shadow(color: Color(0xFFD96F9D), blurRadius: 18),
                        ]
                      : null,
                ),
                const SizedBox(height: 2),
                Text(
                  'خانه',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: active ? Colors.white : const Color(0xFF99A5C5),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _PageHeader extends StatelessWidget {
  const _PageHeader({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: colors,
      cut: 22,
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
      child: Row(
        children: <Widget>[
          _IconCore(icon: icon, color: colors.first, size: 50),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: Color(0xFF96A5BE),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileCard extends StatelessWidget {
  const _ProfileCard({required this.progress, required this.onTap});

  final PlayerProgressController progress;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final int percent = (progress.levelProgress * 100).round();
    return NeonPressable(
      semanticLabel: 'پروفایل بازیکن',
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: const <Color>[PulseColors.cyan, PulseColors.blue],
          cut: 15,
          pressed: pressed,
          padding: const EdgeInsets.fromLTRB(9, 7, 10, 7),
          child: Row(
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  const SizedBox(
                    width: 55,
                    height: 55,
                    child: CustomPaint(painter: _AvatarPainter()),
                  ),
                  Positioned(
                    right: -2,
                    bottom: -2,
                    child: _LevelBadge(level: '${progress.level}'),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      progress.playerName,
                      textDirection: TextDirection.rtl,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: PulseColors.textPrimary,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      'سطح ${progress.level}',
                      textDirection: TextDirection.rtl,
                      style: const TextStyle(
                        color: PulseColors.cyan,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    PulseProgress(
                      value: progress.levelProgress,
                      label: '$percent٪',
                      colors: const <Color>[PulseColors.cyan, PulseColors.blue],
                      compact: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ResourceCard extends StatelessWidget {
  const _ResourceCard({
    required this.color,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  final Color color;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: value,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: <Color>[color, color.withValues(alpha: .65)],
          cut: 14,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
          child: Row(
            children: <Widget>[
              _IconCore(icon: icon, color: color, size: 28),
              const SizedBox(width: 5),
              Expanded(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    value,
                    maxLines: 1,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
              Icon(Icons.add_rounded, color: color, size: 17),
            ],
          ),
        );
      },
    );
  }
}

class _GameTitle extends StatelessWidget {
  const _GameTitle();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ShaderMask(
          shaderCallback: (Rect rect) {
            return const LinearGradient(
              colors: <Color>[
                Color(0xFF47E8FF),
                Color(0xFFEAFDFF),
                Color(0xFFA98FD1),
                Color(0xFFD96F9D),
              ],
              stops: <double>[0, .39, .62, 1],
            ).createShader(rect);
          },
          child: const Text(
            'PULSE ARENA',
            maxLines: 1,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 42,
              letterSpacing: 1.4,
              fontWeight: FontWeight.w900,
              shadows: <Shadow>[
                Shadow(color: Color(0xAA2DE7FF), blurRadius: 18),
                Shadow(color: Color(0x88FF47B8), blurRadius: 22),
              ],
            ),
          ),
        ),
        const SizedBox(height: 1),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _LightLine(color: Color(0xFF5ADBD5)),
            SizedBox(width: 12),
            Text(
              'نبرد پالس‌ها',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                color: Colors.white,
                fontSize: 19,
                fontWeight: FontWeight.w900,
                shadows: <Shadow>[
                  Shadow(color: Color(0xAA3CE6FF), blurRadius: 11),
                  Shadow(color: Color(0xAAFF4ABB), blurRadius: 12),
                ],
              ),
            ),
            SizedBox(width: 12),
            _LightLine(color: Color(0xFFD96F9D), reverse: true),
          ],
        ),
      ],
    );
  }
}

class _LightLine extends StatelessWidget {
  const _LightLine({required this.color, this.reverse = false});

  final Color color;
  final bool reverse;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 61,
      height: 2,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: reverse
              ? <Color>[color, Colors.transparent]
              : <Color>[Colors.transparent, color],
        ),
        boxShadow: <BoxShadow>[BoxShadow(color: color, blurRadius: 6)],
      ),
    );
  }
}

class _PowerStrip extends StatelessWidget {
  const _PowerStrip();

  @override
  Widget build(BuildContext context) {
    return const PulsePanel(
      colors: <Color>[Color(0xFF57D7D2), Color(0xFFD96F9D)],
      cut: 11,
      padding: EdgeInsets.symmetric(horizontal: 11),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _PowerItem(Icons.shield_rounded, 'x2', Color(0xFF41E6FF)),
          _PowerDivider(),
          _PowerItem(Icons.bolt_rounded, 'x1', Color(0xFFE8B84A)),
          _PowerDivider(),
          _PowerItem(Icons.graphic_eq_rounded, 'x2', Color(0xFFE28AAF)),
        ],
      ),
    );
  }
}

class _PowerItem extends StatelessWidget {
  const _PowerItem(this.icon, this.value, this.color);

  final IconData icon;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(
          value,
          style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900),
        ),
      ],
    );
  }
}

class _PowerDivider extends StatelessWidget {
  const _PowerDivider();

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 21, color: const Color(0x554D5C78));
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'شروع بازی',
      pressedScale: .95,
      onTap: onTap,
      builder: (_, bool pressed) {
        return CustomPaint(
          painter: _ActionButtonPainter(
            pressed: pressed,
            cyan: const Color(0xFF2BE4FF),
            magenta: const Color(0xFFD96F9D),
            strong: true,
          ),
          child: const Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(Icons.keyboard_double_arrow_right_rounded, color: Color(0x8838E7FF), size: 28),
                SizedBox(width: 17),
                Text(
                  'شروع بازی',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 31,
                    fontWeight: FontWeight.w900,
                    shadows: <Shadow>[
                      Shadow(color: Color(0xCCFFFFFF), blurRadius: 8),
                      Shadow(color: Color(0xAA8B5CFF), blurRadius: 16),
                    ],
                  ),
                ),
                SizedBox(width: 17),
                Icon(Icons.keyboard_double_arrow_left_rounded, color: Color(0x88FF45B9), size: 28),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  const _SecondaryButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: <Color>[color, color.withValues(alpha: .7)],
          cut: 15,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 11),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: color, size: 27),
              const SizedBox(width: 9),
              Flexible(
                child: Text(
                  label,
                  textDirection: TextDirection.rtl,
                  maxLines: 1,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _GraphicButton extends StatelessWidget {
  const _GraphicButton({
    required this.label,
    required this.icon,
    required this.colors,
    required this.onTap,
    this.tall = false,
  });

  final String label;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback onTap;
  final bool tall;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: tall ? 62 : 46,
      child: NeonPressable(
        semanticLabel: label,
        onTap: onTap,
        builder: (_, bool pressed) {
          return PulsePanel(
            colors: colors,
            cut: tall ? 18 : 13,
            pressed: pressed,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, color: colors.first, size: tall ? 26 : 21),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    label,
                    textDirection: TextDirection.rtl,
                    maxLines: 1,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: tall ? 18 : 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _SegmentButton extends StatelessWidget {
  const _SegmentButton({
    required this.label,
    required this.selected,
    required this.color,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 45,
      child: NeonPressable(
        semanticLabel: label,
        onTap: onTap,
        builder: (_, bool pressed) {
          return PulsePanel(
            colors: <Color>[
              color,
              selected ? color : const Color(0xFF4A5874),
            ],
            cut: 12,
            pressed: pressed,
            intensity: selected ? 1 : .48,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Center(
              child: Text(
                label,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                style: TextStyle(
                  color: selected ? Colors.white : const Color(0xFFA2AEC2),
                  fontSize: 12.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _MetricPanel extends StatelessWidget {
  const _MetricPanel({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
    this.compact = false,
  });

  final String value;
  final String label;
  final IconData icon;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final Widget content = PulsePanel(
      colors: <Color>[color, color.withValues(alpha: .55)],
      cut: 15,
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 10 : 8,
        vertical: compact ? 9 : 11,
      ),
      child: compact
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, color: color, size: 23),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(value, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                    Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9DABC1), fontSize: 10, fontWeight: FontWeight.w700)),
                  ],
                ),
              ],
            )
          : Column(
              children: <Widget>[
                Icon(icon, color: color, size: 27),
                const SizedBox(height: 5),
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9DABC1), fontSize: 10.5, fontWeight: FontWeight.w700)),
              ],
            ),
    );
    return compact ? Expanded(child: content) : content;
  }
}

class _CurrencyPanel extends StatelessWidget {
  const _CurrencyPanel({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });

  final String value;
  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: <Color>[color, color.withValues(alpha: .55)],
      cut: 18,
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      child: Row(
        children: <Widget>[
          _IconCore(icon: icon, color: color, size: 40),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9FAEC4), fontSize: 11, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          Icon(Icons.add_circle_outline_rounded, color: color, size: 22),
        ],
      ),
    );
  }
}

class _AchievementTile extends StatelessWidget {
  const _AchievementTile({
    required this.title,
    required this.subtitle,
    required this.progress,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final double progress;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: title,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: <Color>[color, color.withValues(alpha: .55)],
          cut: 18,
          pressed: pressed,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              _IconCore(icon: icon, color: color, size: 50),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(title, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 2),
                    Text(subtitle, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF97A6BD), fontSize: 10.5, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    PulseProgress(
                      value: progress,
                      label: '${(progress * 100).round()}٪',
                      colors: <Color>[color, color.withValues(alpha: .65)],
                      compact: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MissionTile extends StatelessWidget {
  const _MissionTile({
    required this.data,
    required this.claimed,
    required this.onTap,
  });

  final _MissionData data;
  final bool claimed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool completed = data.current >= data.target;
    final Color color = completed ? const Color(0xFFE8B84A) : const Color(0xFF42E7FF);
    return PulsePanel(
      colors: <Color>[color, const Color(0xFFD96F9D)],
      cut: 19,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: <Widget>[
          _IconCore(icon: data.icon, color: color, size: 55),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(data.title, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                Text(data.subtitle, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9AA9C0), fontSize: 10.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                PulseProgress(
                  value: data.current / data.target,
                  label: '${data.current}/${data.target}',
                  colors: <Color>[color, const Color(0xFFD96F9D)],
                  compact: true,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 78,
            child: _GraphicButton(
              label: claimed ? 'دریافت شد' : '${data.reward}',
              icon: claimed ? Icons.check_rounded : Icons.card_giftcard_rounded,
              colors: <Color>[color, const Color(0xFFD96F9D)],
              onTap: onTap,
            ),
          ),
        ],
      ),
    );
  }
}

class _RankingRow extends StatelessWidget {
  const _RankingRow({
    required this.data,
    required this.isCurrentUser,
    required this.onTap,
  });

  final _RankData data;
  final bool isCurrentUser;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: data.name,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: isCurrentUser
              ? const <Color>[Color(0xFF57D7D2), Color(0xFFD96F9D)]
              : <Color>[data.color, data.color.withValues(alpha: .45)],
          cut: 16,
          intensity: isCurrentUser ? 1 : .55,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          child: Row(
            children: <Widget>[
              SizedBox(
                width: 35,
                child: Text(
                  '${data.rank}',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: data.color, fontSize: 18, fontWeight: FontWeight.w900),
                ),
              ),
              const SizedBox(width: 8),
              _IconCore(icon: Icons.person_rounded, color: data.color, size: 38),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  data.name,
                  maxLines: 1,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(color: isCurrentUser ? Colors.white : const Color(0xFFD5DCEC), fontSize: 14, fontWeight: FontWeight.w900),
                ),
              ),
              Text(
                '${data.score}',
                style: TextStyle(color: data.color, fontSize: 14, fontWeight: FontWeight.w900),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Podium extends StatelessWidget {
  const _Podium({required this.players});

  final List<_RankData> players;

  @override
  Widget build(BuildContext context) {
    if (players.length < 3) return const SizedBox.shrink();
    final _RankData first = players[0];
    final _RankData second = players[1];
    final _RankData third = players[2];
    return SizedBox(
      height: 175,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: <Widget>[
          Positioned(
            left: 8,
            bottom: 0,
            width: 112,
            height: 119,
            child: _PodiumPlayer(
              rank: second.rank,
              name: second.name,
              score: _groupDigits(second.score),
              color: second.color,
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Center(
              child: SizedBox(
                width: 126,
                height: 164,
                child: _PodiumPlayer(
                  rank: first.rank,
                  name: first.name,
                  score: _groupDigits(first.score),
                  color: first.color,
                ),
              ),
            ),
          ),
          Positioned(
            right: 8,
            bottom: 0,
            width: 112,
            height: 106,
            child: _PodiumPlayer(
              rank: third.rank,
              name: third.name,
              score: _groupDigits(third.score),
              color: third.color,
            ),
          ),
        ],
      ),
    );
  }
}

class _PodiumPlayer extends StatelessWidget {
  const _PodiumPlayer({
    required this.rank,
    required this.name,
    required this.score,
    required this.color,
  });

  final int rank;
  final String name;
  final String score;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: <Color>[color, color.withValues(alpha: .55)],
      cut: 17,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(
            rank == 1 ? Icons.emoji_events_rounded : Icons.military_tech_rounded,
            color: color,
            size: rank == 1 ? 40 : 31,
            shadows: <Shadow>[Shadow(color: color, blurRadius: 14)],
          ),
          Text('#$rank', style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(name, maxLines: 1, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(height: 2),
          Text(score, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _ShopItem extends StatelessWidget {
  const _ShopItem({
    required this.data,
    required this.owned,
    required this.equipped,
    required this.onTap,
    required this.onBuy,
  });

  final _ShopItemData data;
  final bool owned;
  final bool equipped;
  final VoidCallback onTap;
  final VoidCallback onBuy;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: data.title,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: <Color>[
            data.color,
            equipped ? PulseColors.cyan : data.color.withValues(alpha: .42),
          ],
          cut: data.rarity == 'افسانه‌ای' ? 24 : 18,
          intensity: equipped ? 1 : .62,
          pressed: pressed,
          padding: const EdgeInsets.all(9),
          child: Column(
            children: <Widget>[
              Align(
                alignment: Alignment.centerRight,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: data.color.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: data.color.withValues(alpha: .45)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    child: Text(
                      data.rarity,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: data.color,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: SizedBox(
                    width: 74,
                    height: 74,
                    child: CustomPaint(
                      painter: _ShopIconPainter(color: data.color, icon: data.icon),
                    ),
                  ),
                ),
              ),
              Text(
                data.title,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: PulseColors.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 6),
              SizedBox(
                width: double.infinity,
                child: _GraphicButton(
                  label: equipped
                      ? 'تجهیز شده'
                      : owned
                          ? 'تجهیز'
                          : data.price == 0
                              ? 'رایگان'
                              : _groupDigits(data.price),
                  icon: equipped
                      ? Icons.check_circle_rounded
                      : owned
                          ? Icons.inventory_2_rounded
                          : Icons.motion_photos_on_rounded,
                  colors: <Color>[data.color, PulseColors.rose],
                  onTap: onBuy,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _DifficultyTile extends StatelessWidget {
  const _DifficultyTile({
    required this.value,
    required this.selected,
    required this.onTap,
  });

  final BotDifficulty value;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = selected ? const Color(0xFF5ADBD5) : const Color(0xFF687897);
    return NeonPressable(
      semanticLabel: value.title,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: <Color>[color, selected ? const Color(0xFFD96F9D) : color.withValues(alpha: .45)],
          cut: 18,
          intensity: selected ? 1 : .5,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
          child: Row(
            children: <Widget>[
              _IconCore(
                icon: selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                color: color,
                size: 43,
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(value.title, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    Text(value.description, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF98A7BD), fontSize: 10.5, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SettingToggleTile extends StatelessWidget {
  const _SettingToggleTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.enabled,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final String subtitle;
  final bool enabled;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) {
        return PulsePanel(
          colors: <Color>[color, enabled ? const Color(0xFFD96F9D) : color.withValues(alpha: .4)],
          cut: 18,
          intensity: enabled ? 1 : .5,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
          child: Row(
            children: <Widget>[
              _IconCore(icon: icon, color: color, size: 45),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    Text(subtitle, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF96A5BB), fontSize: 10.5, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              _CustomToggle(enabled: enabled, color: color),
            ],
          ),
        );
      },
    );
  }
}

class _CustomToggle extends StatelessWidget {
  const _CustomToggle({required this.enabled, required this.color});

  final bool enabled;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 170),
      width: 50,
      height: 28,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: enabled ? color : const Color(0xFF56637E), width: 1.2),
        gradient: LinearGradient(
          colors: enabled
              ? <Color>[color.withValues(alpha: .42), const Color(0x55382558)]
              : const <Color>[Color(0xFF101827), Color(0xFF080D18)],
        ),
        boxShadow: enabled ? <BoxShadow>[BoxShadow(color: color.withValues(alpha: .45), blurRadius: 10)] : null,
      ),
      child: AnimatedAlign(
        duration: const Duration(milliseconds: 170),
        curve: Curves.easeOutCubic,
        alignment: enabled ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: enabled ? color : const Color(0xFF71809C),
            boxShadow: enabled ? <BoxShadow>[BoxShadow(color: color, blurRadius: 8)] : null,
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.icon, required this.color});

  final String title;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        Expanded(
          child: Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: <Color>[Colors.transparent, color.withValues(alpha: .75)]),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          textDirection: TextDirection.rtl,
          style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900),
        ),
        const SizedBox(width: 7),
        Icon(icon, color: color, size: 23, shadows: <Shadow>[Shadow(color: color, blurRadius: 10)]),
      ],
    );
  }
}

class _IconCore extends StatelessWidget {
  const _IconCore({required this.icon, required this.color, required this.size});

  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _IconCorePainter(color: color),
        child: Icon(icon, color: color, size: size * .5),
      ),
    );
  }
}

class _LevelBadge extends StatelessWidget {
  const _LevelBadge({required this.level});

  final String level;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: const <Color>[Color(0xFF57D7D2), Color(0xFF755BFF)],
      cut: 6,
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
      child: Text(
        level,
        style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _MiniIconButton extends StatelessWidget {
  const _MiniIconButton({required this.icon, required this.color, required this.onTap});

  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 46,
      height: 46,
      child: NeonPressable(
        semanticLabel: 'بازگشت',
        onTap: onTap,
        builder: (_, bool pressed) {
          return PulsePanel(
            colors: <Color>[color, color.withValues(alpha: .55)],
            cut: 12,
            pressed: pressed,
            child: Icon(icon, color: color, size: 25),
          );
        },
      ),
    );
  }
}

class _ActionButtonPainter extends CustomPainter {
  const _ActionButtonPainter({
    required this.pressed,
    required this.cyan,
    required this.magenta,
    required this.strong,
  });

  final bool pressed;
  final Color cyan;
  final Color magenta;
  final bool strong;

  Path _path(Size size, double inset) {
    final double cut = 19 - inset * .35;
    return Path()
      ..moveTo(inset + cut, inset)
      ..lineTo(size.width - inset - cut, inset)
      ..lineTo(size.width - inset, inset + cut)
      ..lineTo(size.width - inset, size.height - inset - cut)
      ..lineTo(size.width - inset - cut, size.height - inset)
      ..lineTo(inset + cut, size.height - inset)
      ..lineTo(inset, size.height - inset - cut)
      ..lineTo(inset, inset + cut)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Path path = _path(size, 2);
    final Path inner = _path(size, 7);
    final double press = pressed ? .72 : 1;
    final double lift = pressed ? 2 : 6;

    canvas.save();
    canvas.translate(0, lift);
    canvas.drawPath(path, Paint()..color = const Color(0xFF01040B));
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strong ? 3.5 : 2.5
        ..color = const Color(0xFF020712),
    );
    canvas.restore();

    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color.lerp(const Color(0xFF10283A), cyan, .14)!,
            const Color(0xFF17213A),
            Color.lerp(const Color(0xFF271322), magenta, .14)!,
          ],
        ).createShader(rect),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strong ? 2.5 : 1.8
        ..shader = LinearGradient(
          colors: <Color>[
            cyan.withValues(alpha: .9 * press),
            const Color(0xFFC7D5E7),
            magenta.withValues(alpha: .9 * press),
          ],
        ).createShader(rect),
    );
    canvas.drawPath(
      inner,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .8
        ..color = const Color(0x667C8EAA),
    );
    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height * .46),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withValues(alpha: pressed ? .025 : .13),
            Colors.transparent,
          ],
        ).createShader(rect),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ActionButtonPainter oldDelegate) {
    return oldDelegate.pressed != pressed ||
        oldDelegate.cyan != cyan ||
        oldDelegate.magenta != magenta ||
        oldDelegate.strong != strong;
  }
}

class _HubBackgroundPainter extends CustomPainter {
  const _HubBackgroundPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFF030711),
            Color(0xFF091321),
            Color(0xFF060A14),
            Color(0xFF0D0A15),
          ],
          stops: <double>[0, .38, .72, 1],
        ).createShader(rect),
    );

    final Offset leftCore = Offset(-size.width * .10, size.height * .34);
    canvas.drawCircle(
      leftCore,
      size.width * .74,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Color(0x2457D7D2), Color(0x0857D7D2), Colors.transparent],
          stops: <double>[0, .42, 1],
        ).createShader(Rect.fromCircle(center: leftCore, radius: size.width * .74)),
    );
    final Offset rightCore = Offset(size.width * 1.08, size.height * .46);
    canvas.drawCircle(
      rightCore,
      size.width * .76,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Color(0x20D96F9D), Color(0x07D96F9D), Colors.transparent],
          stops: <double>[0, .44, 1],
        ).createShader(Rect.fromCircle(center: rightCore, radius: size.width * .76)),
    );

    final Paint perspective = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .7
      ..color = const Color(0x163E5872);
    final double horizon = size.height * .59;
    for (int i = -8; i <= 8; i++) {
      final double x = size.width * .5 + i * size.width * .14;
      canvas.drawLine(Offset(size.width * .5, horizon), Offset(x, size.height), perspective);
    }
    for (int i = 0; i < 10; i++) {
      final double t = i / 10;
      final double eased = t * t;
      final double y = horizon + (size.height - horizon) * eased;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), perspective);
    }

    final Paint panelLines = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = const Color(0x124F6A84);
    for (int i = 0; i < 5; i++) {
      final double y = size.height * (.12 + i * .16);
      final Path line = Path()
        ..moveTo(0, y)
        ..lineTo(size.width * .10, y)
        ..lineTo(size.width * .14, y - 8)
        ..lineTo(size.width * .28, y - 8);
      canvas.drawPath(line, panelLines);
      final Path mirror = Path()
        ..moveTo(size.width, y + 11)
        ..lineTo(size.width * .90, y + 11)
        ..lineTo(size.width * .86, y + 3)
        ..lineTo(size.width * .72, y + 3);
      canvas.drawPath(mirror, panelLines);
    }

    final math.Random random = math.Random(8142);
    final Paint star = Paint();
    for (int i = 0; i < 52; i++) {
      final Offset p = Offset(random.nextDouble() * size.width, random.nextDouble() * size.height * .70);
      star.color = i % 9 == 0 ? const Color(0x668EDFD9) : const Color(0x2EC5D2DE);
      canvas.drawCircle(p, i % 9 == 0 ? 1.05 : .55, star);
    }

    canvas.drawRect(
      rect,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 1.02,
          colors: <Color>[Colors.transparent, Color(0x4A00030A)],
          stops: <double>[.50, 1],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ArenaPreviewPainter extends CustomPainter {
  const _ArenaPreviewPainter({required this.progress});

  final double progress;
  static Picture? _staticPicture;
  static Size? _staticSize;

  @override
  void paint(Canvas canvas, Size size) {
    if (_staticPicture == null || _staticSize != size) {
      _staticPicture?.dispose();
      _staticPicture = _buildStatic(size);
      _staticSize = size;
    }
    canvas.drawPicture(_staticPicture!);

    final Offset center = Offset(size.width / 2, size.height / 2);
    final double t = progress * math.pi * 2;
    final double ballX = center.dx + math.sin(t) * size.width * .24;
    final double ballY = center.dy + math.sin(t * 1.7) * size.height * .09;
    final Offset ball = Offset(ballX, ballY);
    final Offset leftPaddle = Offset(36, center.dy + math.sin(t * 1.3) * size.height * .16);
    final Offset rightPaddle = Offset(size.width - 36, center.dy - math.sin(t * 1.1) * size.height * .16);

    _drawPaddle(canvas, leftPaddle, const Color(0xFF5ADBD5), size.height * .28);
    _drawPaddle(canvas, rightPaddle, const Color(0xFFD96F9D), size.height * .28);

    final Paint trail = Paint()
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    trail.shader = const LinearGradient(
      colors: <Color>[Color(0xB05ADBD5), Colors.transparent],
    ).createShader(Rect.fromPoints(leftPaddle, ball));
    canvas.drawLine(Offset(leftPaddle.dx + 9, leftPaddle.dy), ball, trail);
    trail.shader = const LinearGradient(
      colors: <Color>[Colors.transparent, Color(0xB0D96F9D)],
    ).createShader(Rect.fromPoints(ball, rightPaddle));
    canvas.drawLine(ball, Offset(rightPaddle.dx - 9, rightPaddle.dy), trail);

    for (int i = 0; i < 3; i++) {
      final double radius = 25 + i * 13 + math.sin(t + i) * 1.6;
      canvas.drawCircle(
        ball,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 1.8 : .8
          ..color = <Color>[
            const Color(0xB05ADBD5),
            const Color(0x807C78C8),
            const Color(0x80D96F9D),
          ][i],
      );
    }
    canvas.drawCircle(
      ball,
      14,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Colors.white, Color(0xFFB58BDD), Color(0xFF47356F)],
        ).createShader(Rect.fromCircle(center: ball, radius: 14)),
    );
    canvas.drawCircle(ball, 19, Paint()..color = const Color(0x285A69B8));
  }

  Picture _buildStatic(Size size) {
    final PictureRecorder recorder = PictureRecorder();
    final Canvas canvas = Canvas(recorder);
    final Rect rect = Offset.zero & size;
    const double cut = 27;
    final Path frame = Path()
      ..moveTo(cut, 2)
      ..lineTo(size.width - cut, 2)
      ..lineTo(size.width - 2, cut)
      ..lineTo(size.width - 2, size.height - cut)
      ..lineTo(size.width - cut, size.height - 2)
      ..lineTo(cut, size.height - 2)
      ..lineTo(2, size.height - cut)
      ..lineTo(2, cut)
      ..close();

    canvas.save();
    canvas.translate(0, 6);
    canvas.drawPath(frame, Paint()..color = const Color(0xFF01040A));
    canvas.restore();
    canvas.drawPath(
      frame,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF0C1D2A), Color(0xFF101426), Color(0xFF21111D)],
        ).createShader(rect),
    );
    canvas.save();
    canvas.clipPath(frame);
    _paintGrid(canvas, size);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x125ADBD5), Colors.transparent, Color(0x12D96F9D)],
        ).createShader(rect),
    );
    canvas.restore();
    canvas.drawPath(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF5ADBD5), Color(0xFF7275B9), Color(0xFFD96F9D)],
        ).createShader(rect),
    );
    final Offset center = Offset(size.width / 2, size.height / 2);
    final Paint divider = Paint()
      ..color = const Color(0x454E5A8D)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(center.dx, 20), Offset(center.dx, size.height - 20), divider);
    for (double y = 27; y < size.height - 20; y += 22) {
      canvas.drawCircle(Offset(center.dx, y), 1.6, Paint()..color = const Color(0x7A8173C6));
    }
    return recorder.endRecording();
  }

  void _paintGrid(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .55
      ..color = const Color(0x1B50647A);
    const double spacing = 30;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  void _drawPaddle(Canvas canvas, Offset center, Color color, double height) {
    final RRect base = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(center.dx, center.dy + 4), width: 15, height: height),
      const Radius.circular(8),
    );
    canvas.drawRRect(base, Paint()..color = const Color(0xFF02050B));
    final RRect paddle = RRect.fromRectAndRadius(
      Rect.fromCenter(center: center, width: 13, height: height),
      const Radius.circular(8),
    );
    canvas.drawRRect(paddle, Paint()..color = color);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: center, width: 4, height: height - 12),
        const Radius.circular(3),
      ),
      Paint()..color = Colors.white.withValues(alpha: .72),
    );
  }

  @override
  bool shouldRepaint(covariant _ArenaPreviewPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}

class _AvatarPainter extends CustomPainter {
  const _AvatarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = size.shortestSide / 2 - 3;
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFF06101C));
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const SweepGradient(colors: <Color>[Color(0xFF57D7D2), Color(0xFFD96F9D), Color(0xFF7C5FFF), Color(0xFF57D7D2)]).createShader(Rect.fromCircle(center: c, radius: r)),
    );
    final Path helmet = Path()
      ..moveTo(c.dx - r * .62, c.dy - r * .12)
      ..quadraticBezierTo(c.dx - r * .48, c.dy - r * .72, c.dx, c.dy - r * .76)
      ..quadraticBezierTo(c.dx + r * .48, c.dy - r * .72, c.dx + r * .62, c.dy - r * .12)
      ..lineTo(c.dx + r * .46, c.dy + r * .56)
      ..quadraticBezierTo(c.dx, c.dy + r * .76, c.dx - r * .46, c.dy + r * .56)
      ..close();
    canvas.drawPath(
      helmet,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF9C6EB1), Color(0xFF5A206F), Color(0xFF0C1426), Color(0xFF2CE4FF)],
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );
    final RRect visor = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(c.dx, c.dy - r * .05), width: r * 1.18, height: r * .52),
      Radius.circular(r * .24),
    );
    canvas.drawRRect(visor, Paint()..color = const Color(0xFF02050C));
    canvas.drawRRect(
      visor,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF57D7D2), Color(0xFFD96F9D)]).createShader(visor.outerRect),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _IconCorePainter extends CustomPainter {
  const _IconCorePainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = size.shortestSide / 2 - 2;
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFF07101D));
    canvas.drawCircle(c, r, Paint()..color = color.withValues(alpha: .16)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
    canvas.drawCircle(c, r - 1, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.4..color = color);
    canvas.drawCircle(c, r - 5, Paint()..style = PaintingStyle.stroke..strokeWidth = .6..color = color.withValues(alpha: .45));
  }

  @override
  bool shouldRepaint(covariant _IconCorePainter oldDelegate) => oldDelegate.color != color;
}

class _HomeNavPainter extends CustomPainter {
  const _HomeNavPainter({required this.active, required this.pressed});

  final bool active;
  final bool pressed;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Path hex = Path()
      ..moveTo(size.width * .28, 2)
      ..lineTo(size.width * .72, 2)
      ..lineTo(size.width - 2, size.height * .28)
      ..lineTo(size.width - 2, size.height * .72)
      ..lineTo(size.width * .72, size.height - 2)
      ..lineTo(size.width * .28, size.height - 2)
      ..lineTo(2, size.height * .72)
      ..lineTo(2, size.height * .28)
      ..close();
    final double glow = pressed ? .45 : 1;
    canvas.drawPath(
      hex,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 13
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF57D7D2), Color(0xFFD96F9D)]).createShader(rect)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 10 * glow),
    );
    canvas.drawPath(
      hex,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: active
              ? const <Color>[Color(0xFF0D4D6A), Color(0xFF251957), Color(0xFF51133D)]
              : const <Color>[Color(0xFF14213A), Color(0xFF0A0F1D)],
        ).createShader(rect),
    );
    canvas.drawPath(
      hex,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF57D7D2), Colors.white, Color(0xFFD96F9D)]).createShader(rect),
    );
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 24, Paint()..color = const Color(0x2235E7FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
  }

  @override
  bool shouldRepaint(covariant _HomeNavPainter oldDelegate) {
    return oldDelegate.active != active || oldDelegate.pressed != pressed;
  }
}

class _NavCellPainter extends CustomPainter {
  const _NavCellPainter({required this.color, required this.active, required this.pressed});

  final Color color;
  final bool active;
  final bool pressed;

  @override
  void paint(Canvas canvas, Size size) {
    if (!active) return;
    final Rect rect = Offset.zero & size;
    final RRect r = RRect.fromRectAndRadius(rect.deflate(3), const Radius.circular(13));
    canvas.drawRRect(
      r,
      Paint()
        ..shader = LinearGradient(colors: <Color>[color.withValues(alpha: .14), color.withValues(alpha: .03)]).createShader(rect),
    );
    canvas.drawLine(
      Offset(size.width * .28, size.height - 4),
      Offset(size.width * .72, size.height - 4),
      Paint()
        ..color = color
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
  }

  @override
  bool shouldRepaint(covariant _NavCellPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.active != active || oldDelegate.pressed != pressed;
  }
}

class _LeagueEmblemPainter extends CustomPainter {
  const _LeagueEmblemPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Offset c = Offset(size.width / 2, size.height / 2);
    final Path diamond = Path()
      ..moveTo(c.dx, 3)
      ..lineTo(size.width - 5, c.dy)
      ..lineTo(c.dx, size.height - 3)
      ..lineTo(5, c.dy)
      ..close();
    canvas.drawPath(diamond, Paint()..shader = const LinearGradient(colors: <Color>[Color(0xFFFFD64D), Color(0xFF9C63FF), Color(0xFFD96F9D)]).createShader(rect));
    canvas.drawPath(diamond, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = Colors.white.withValues(alpha: .7));
    canvas.drawPath(diamond, Paint()..style = PaintingStyle.stroke..strokeWidth = 11..color = const Color(0x55FFB832)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawCircle(c, 18, Paint()..color = const Color(0xFF080C17));
    canvas.drawCircle(c, 17, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFFFFD64D));
    final TextPainter tp = TextPainter(
      text: const TextSpan(text: 'P', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FeaturedItemPainter extends CustomPainter {
  const _FeaturedItemPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(c, size.width * .39, Paint()..color = const Color(0x223DE7FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13));
    for (int i = 0; i < 3; i++) {
      canvas.drawCircle(
        c,
        31 + i * 9,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 2 : 1
          ..shader = const SweepGradient(colors: <Color>[Color(0xFF57D7D2), Color(0xFF9367FF), Color(0xFFD96F9D), Color(0xFF57D7D2)]).createShader(Rect.fromCircle(center: c, radius: 50)),
      );
    }
    final RRect left = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx - 19, c.dy), width: 9, height: 62), const Radius.circular(5));
    final RRect right = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx + 19, c.dy), width: 9, height: 62), const Radius.circular(5));
    canvas.drawRRect(left, Paint()..color = const Color(0xFF57D7D2));
    canvas.drawRRect(right, Paint()..color = const Color(0xFFD96F9D));
    canvas.drawCircle(c, 12, Paint()..shader = const RadialGradient(colors: <Color>[Colors.white, Color(0xFF9A83C7), Color(0xFF42127E)]).createShader(Rect.fromCircle(center: c, radius: 12)));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ShopIconPainter extends CustomPainter {
  const _ShopIconPainter({required this.color, required this.icon});

  final Color color;
  final IconData icon;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(c, size.width * .38, Paint()..color = color.withValues(alpha: .18)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawCircle(c, size.width * .34, Paint()..color = const Color(0xFF07101D));
    canvas.drawCircle(c, size.width * .34, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = color);
    final TextPainter painter = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(icon.codePoint),
        style: TextStyle(
          fontFamily: icon.fontFamily,
          package: icon.fontPackage,
          color: color,
          fontSize: size.width * .43,
          shadows: <Shadow>[Shadow(color: color, blurRadius: 10)],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(canvas, c - Offset(painter.width / 2, painter.height / 2));
  }

  @override
  bool shouldRepaint(covariant _ShopIconPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.icon != icon;
  }
}

class _NavData {
  const _NavData(this.icon, this.label, {this.badge = false});

  final IconData icon;
  final String label;
  final bool badge;
}

class _MissionData {
  const _MissionData(
    this.id,
    this.title,
    this.subtitle,
    this.current,
    this.target,
    this.reward,
    this.icon,
  );

  final String id;
  final String title;
  final String subtitle;
  final int current;
  final int target;
  final int reward;
  final IconData icon;
}

class _RankData {
  const _RankData(
    this.rank,
    this.name,
    this.score,
    this.color, {
    this.current = false,
  });

  final int rank;
  final String name;
  final int score;
  final Color color;
  final bool current;
}

class _ShopItemData {
  const _ShopItemData(
    this.id,
    this.category,
    this.title,
    this.price,
    this.color,
    this.icon,
    this.rarity,
  );

  final String id;
  final String category;
  final String title;
  final int price;
  final Color color;
  final IconData icon;
  final String rarity;
}
