part of '../hub_screen.dart';

class _RankingPage extends StatelessWidget {
  const _RankingPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  List<_RankData> _localRanking() {
    final List<({String name, int score, Color color, bool current})> entries =
        <({String name, int score, Color color, bool current})>[
      (name: 'NOVA-X', score: 4820, color: PulseColors.gold, current: false),
      (name: 'PulseQueen', score: 4665, color: const Color(0xFFC9D6EF), current: false),
      (name: 'ShadowArc', score: 4510, color: const Color(0xFFFF9A62), current: false),
      (name: 'NeonWolf', score: 4280, color: PulseColors.cyan, current: false),
      (name: progress.playerName, score: progress.leagueScore, color: PulseColors.rose, current: true),
      (name: 'VoltMaster', score: 3990, color: PulseColors.violet, current: false),
      (name: 'ArenaGhost', score: 3845, color: PulseColors.textMuted, current: false),
    ]..sort((a, b) => b.score.compareTo(a.score));
    return <_RankData>[
      for (int i = 0; i < entries.length; i++)
        _RankData(
          i + 1,
          entries[i].name,
          entries[i].score,
          entries[i].color,
          current: entries[i].current,
        ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final List<_RankData> players = _localRanking();
    final _RankData current = players.firstWhere((p) => p.current);
    final double leagueProgress = progress.leagueProgress;
    final int toNext = progress.pointsToNextLeague;

    return _PageScaffold(
      title: 'رتبه‌بندی آفلاین',
      subtitle: 'جدول محلی مبتنی بر نتایج ذخیره‌شده دستگاه',
      icon: Icons.leaderboard_rounded,
      colors: const <Color>[PulseColors.gold, PulseColors.rose],
      children: <Widget>[
        PulsePanel(
          colors: const <Color>[PulseColors.gold, PulseColors.rose],
          cut: 24,
          padding: const EdgeInsets.all(15),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  const SizedBox(
                    width: 76,
                    height: 76,
                    child: CustomPaint(painter: _LeagueEmblemPainter()),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          'لیگ ${progress.leagueName} آفلاین',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: PulseColors.textPrimary,
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          'رتبه فعلی: ${current.rank} • ${_groupDigits(progress.leagueScore)} امتیاز',
                          textDirection: TextDirection.rtl,
                          style: const TextStyle(
                            color: PulseColors.gold,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 10),
                        PulseProgress(
                          value: leagueProgress,
                          label: toNext == 0
                              ? 'بالاترین لیگ محلی'
                              : '$toNext امتیاز تا ${progress.nextLeagueName}',
                          colors: const <Color>[PulseColors.gold, PulseColors.rose],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _GraphicButton(
                label: 'جزئیات پاداش فصل محلی',
                icon: Icons.card_giftcard_rounded,
                colors: const <Color>[PulseColors.gold, PulseColors.rose],
                onTap: () => onMessage(
                  progress.pointsToNextLeague == 0
                      ? 'شما به بالاترین لیگ محلی رسیده‌اید'
                      : 'پاداش ارتقا به لیگ ${progress.nextLeagueName}: ۳۰۰ پالس؛ پس از رسیدن خودکار ثبت می‌شود',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _Podium(players: players.take(3).toList(growable: false)),
        const SizedBox(height: 14),
        const _SectionTitle(
          title: 'رقبای محلی',
          icon: Icons.format_list_numbered_rounded,
          color: PulseColors.gold,
        ),
        const SizedBox(height: 9),
        for (final _RankData player in players) ...<Widget>[
          _RankingRow(
            data: player,
            isCurrentUser: player.current,
            onTap: () => onMessage(
              player.current
                  ? 'این ردیف از نتایج واقعی ذخیره‌شده شما ساخته شده است'
                  : '${player.name} — رقیب آفلاین با ${player.score} امتیاز',
            ),
          ),
          const SizedBox(height: 8),
        ],
        const PulsePanel(
          colors: <Color>[PulseColors.blue, PulseColors.violet],
          cut: 17,
          padding: EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              Icon(Icons.offline_bolt_rounded, color: PulseColors.cyan),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'این جدول آنلاین نیست و هیچ بازیکن زنده یا اتصال سرور را شبیه‌سازی نمی‌کند.',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: PulseTypography.body,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
