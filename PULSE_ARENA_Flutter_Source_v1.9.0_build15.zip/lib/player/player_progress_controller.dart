import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../core/persistence/platform_state_store.dart';
import '../game/config/game_config.dart';

class PlayerProgressController extends ChangeNotifier {
  PlayerProgressController._();

  static final PlayerProgressController instance = PlayerProgressController._();

  String playerName = 'فرمانده پالس';
  int level = 1;
  int levelXp = 0;
  int energy = 1200;
  int pulse = 450;
  int wins = 0;
  int losses = 0;
  int goals = 0;
  int matches = 0;
  int perfectHits = 0;
  int powersUsed = 0;
  int leagueScore = 0;
  BotDifficulty difficulty = BotDifficulty.tactical;
  bool soundEnabled = true;
  bool musicEnabled = true;
  bool vibrationEnabled = true;
  int effectsQuality = 2;
  int frameRate = 60;
  String dailyMissionCycle = '';
  String weeklyMissionCycle = '';
  int dailyMatchesBaseline = 0;
  int dailyPerfectHitsBaseline = 0;
  int dailyPowersBaseline = 0;
  int weeklyWinsBaseline = 0;
  int weeklyGoalsBaseline = 0;
  int weeklyPowersBaseline = 0;
  int highestRewardedLeague = 0;
  final Set<String> claimedMissions = <String>{};
  final Set<String> purchasedItems = <String>{
    'paddle:nova',
    'ball:plasma',
    'effect:pulse_trail',
  };
  final List<Map<String, Object>> recentMatches = <Map<String, Object>>[];
  final Map<String, String> selectedItems = <String, String>{
    'paddle': 'paddle:nova',
    'ball': 'ball:plasma',
    'effect': 'effect:pulse_trail',
  };

  Timer? _saveDebounce;
  bool _loaded = false;

  bool get loaded => _loaded;
  static const List<int> offlineOpponentScores = <int>[
    4820,
    4665,
    4510,
    4280,
    3990,
    3845,
  ];

  int get totalGames => wins + losses;
  double get winRate => totalGames == 0 ? 0 : wins / totalGames;
  int get nextLevelXp => 1000 + (level - 1) * 80;
  double get levelProgress =>
      (levelXp / nextLevelXp).clamp(0.0, 1.0).toDouble();
  int get offlineRank =>
      1 + offlineOpponentScores.where((int score) => score > leagueScore).length;

  String get leagueName {
    if (leagueScore >= 5000) return 'لجند';
    if (leagueScore >= 4000) return 'الماس';
    if (leagueScore >= 3000) return 'پلاتینیوم';
    if (leagueScore >= 2000) return 'طلایی';
    if (leagueScore >= 1000) return 'نقره‌ای';
    return 'برنز';
  }

  String get nextLeagueName {
    if (leagueScore >= 5000) return 'حداکثر لیگ';
    if (leagueScore >= 4000) return 'لجند';
    if (leagueScore >= 3000) return 'الماس';
    if (leagueScore >= 2000) return 'پلاتینیوم';
    if (leagueScore >= 1000) return 'طلایی';
    return 'نقره‌ای';
  }

  int get currentLeagueFloor =>
      (leagueScore ~/ 1000).clamp(0, 5).toInt() * 1000;
  int get nextLeagueThreshold =>
      leagueScore >= 5000 ? 5000 : currentLeagueFloor + 1000;
  int get pointsToNextLeague =>
      leagueScore >= 5000 ? 0 : nextLeagueThreshold - leagueScore;
  double get leagueProgress {
    if (leagueScore >= 5000) return 1;
    return ((leagueScore - currentLeagueFloor) / 1000)
        .clamp(0.0, 1.0)
        .toDouble();
  }

  int get dailyMatchesProgress =>
      (matches - dailyMatchesBaseline).clamp(0, 9999999).toInt();
  int get dailyPerfectHitsProgress =>
      (perfectHits - dailyPerfectHitsBaseline).clamp(0, 9999999).toInt();
  int get dailyPowersProgress =>
      (powersUsed - dailyPowersBaseline).clamp(0, 9999999).toInt();
  int get weeklyWinsProgress =>
      (wins - weeklyWinsBaseline).clamp(0, 9999999).toInt();
  int get weeklyGoalsProgress =>
      (goals - weeklyGoalsBaseline).clamp(0, 9999999).toInt();
  int get weeklyPowersProgress =>
      (powersUsed - weeklyPowersBaseline).clamp(0, 9999999).toInt();

  String missionClaimId(String period, String missionId) {
    final String cycle =
        period == 'daily' ? dailyMissionCycle : weeklyMissionCycle;
    return '$period:$cycle:$missionId';
  }

  Future<void> load() async {
    if (_loaded) return;
    final String? raw = await PlatformStateStore.load();
    if (raw != null && raw.isNotEmpty) {
      try {
        final Object? decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) _apply(decoded);
      } on FormatException {
        // Corrupt local state falls back to safe production defaults.
      }
    }
    refreshMissionCycles(persist: false);
    _loaded = true;
    notifyListeners();
    unawaited(_persist());
  }

  void _apply(Map<String, dynamic> map) {
    playerName = _string(map['playerName'], playerName);
    level = _boundedInt(map['level'], level, 1, 100);
    levelXp = _boundedInt(map['levelXp'], levelXp, 0, 1000000);
    energy = _boundedInt(map['energy'], energy, 0, 9999999);
    pulse = _boundedInt(map['pulse'], pulse, 0, 9999999);
    wins = _boundedInt(map['wins'], wins, 0, 9999999);
    losses = _boundedInt(map['losses'], losses, 0, 9999999);
    goals = _boundedInt(map['goals'], goals, 0, 99999999);
    matches = _boundedInt(map['matches'], matches, 0, 99999999);
    perfectHits = _boundedInt(map['perfectHits'], perfectHits, 0, 99999999);
    powersUsed = _boundedInt(map['powersUsed'], powersUsed, 0, 99999999);
    leagueScore = _boundedInt(map['leagueScore'], leagueScore, 0, 9999999);
    difficulty = BotDifficulty.values[
      _boundedInt(
        map['difficulty'],
        difficulty.index,
        0,
        BotDifficulty.values.length - 1,
      ),
    ];
    soundEnabled = _boolean(map['soundEnabled'], soundEnabled);
    musicEnabled = _boolean(map['musicEnabled'], musicEnabled);
    vibrationEnabled = _boolean(map['vibrationEnabled'], vibrationEnabled);
    effectsQuality = _boundedInt(map['effectsQuality'], effectsQuality, 0, 2);
    frameRate = _integer(map['frameRate'], frameRate) >= 90 ? 90 : 60;
    dailyMissionCycle =
        _stringAllowEmpty(map['dailyMissionCycle'], dailyMissionCycle);
    weeklyMissionCycle =
        _stringAllowEmpty(map['weeklyMissionCycle'], weeklyMissionCycle);
    dailyMatchesBaseline =
        _boundedInt(map['dailyMatchesBaseline'], matches, 0, 99999999);
    dailyPerfectHitsBaseline = _boundedInt(
      map['dailyPerfectHitsBaseline'],
      perfectHits,
      0,
      99999999,
    );
    dailyPowersBaseline =
        _boundedInt(map['dailyPowersBaseline'], powersUsed, 0, 99999999);
    weeklyWinsBaseline =
        _boundedInt(map['weeklyWinsBaseline'], wins, 0, 99999999);
    weeklyGoalsBaseline =
        _boundedInt(map['weeklyGoalsBaseline'], goals, 0, 99999999);
    weeklyPowersBaseline =
        _boundedInt(map['weeklyPowersBaseline'], powersUsed, 0, 99999999);
    highestRewardedLeague = _boundedInt(
      map['highestRewardedLeague'],
      leagueScore ~/ 1000,
      0,
      9999,
    );

    final Object? claimed = map['claimedMissions'];
    if (claimed is List) {
      claimedMissions
        ..clear()
        ..addAll(claimed.whereType<String>());
    }
    final Object? purchased = map['purchasedItems'];
    if (purchased is List) {
      purchasedItems
        ..clear()
        ..addAll(purchased.whereType<String>());
    }
    purchasedItems.addAll(<String>{
      'paddle:nova',
      'ball:plasma',
      'effect:pulse_trail',
    });

    final Object? selected = map['selectedItems'];
    if (selected is Map) {
      for (final MapEntry<Object?, Object?> entry in selected.entries) {
        final Object? key = entry.key;
        final Object? value = entry.value;
        if (key is String && value is String) selectedItems[key] = value;
      }
    }

    const Map<String, String> starterLoadout = <String, String>{
      'paddle': 'paddle:nova',
      'ball': 'ball:plasma',
      'effect': 'effect:pulse_trail',
    };
    for (final MapEntry<String, String> entry in starterLoadout.entries) {
      final String? selectedId = selectedItems[entry.key];
      if (selectedId == null || !purchasedItems.contains(selectedId)) {
        selectedItems[entry.key] = entry.value;
      }
    }

    final Object? recent = map['recentMatches'];
    if (recent is List) {
      recentMatches.clear();
      for (final Object? item in recent.take(6)) {
        if (item is! Map) continue;
        recentMatches.add(<String, Object>{
          'won': _boolean(item['won'], false),
          'playerScore': _boundedInt(item['playerScore'], 0, 0, 99),
          'botScore': _boundedInt(item['botScore'], 0, 0, 99),
          'playedAt': _boundedInt(item['playedAt'], 0, 0, 9999999999999),
        });
      }
    }
  }

  int _integer(Object? value, int fallback) =>
      value is num ? value.toInt() : fallback;
  int _boundedInt(Object? value, int fallback, int minimum, int maximum) {
    return _integer(value, fallback).clamp(minimum, maximum).toInt();
  }
  bool _boolean(Object? value, bool fallback) =>
      value is bool ? value : fallback;
  String _stringAllowEmpty(Object? value, String fallback) =>
      value is String ? value : fallback;
  String _string(Object? value, String fallback) {
    if (value is! String) return fallback;
    final String clean = value.trim();
    if (clean.isEmpty) return fallback;
    return clean.substring(0, clean.length > 24 ? 24 : clean.length);
  }

  Map<String, Object> toJson() => <String, Object>{
        'schema': 3,
        'playerName': playerName,
        'level': level,
        'levelXp': levelXp,
        'energy': energy,
        'pulse': pulse,
        'wins': wins,
        'losses': losses,
        'goals': goals,
        'matches': matches,
        'perfectHits': perfectHits,
        'powersUsed': powersUsed,
        'leagueScore': leagueScore,
        'difficulty': difficulty.index,
        'soundEnabled': soundEnabled,
        'musicEnabled': musicEnabled,
        'vibrationEnabled': vibrationEnabled,
        'effectsQuality': effectsQuality,
        'frameRate': frameRate,
        'dailyMissionCycle': dailyMissionCycle,
        'weeklyMissionCycle': weeklyMissionCycle,
        'dailyMatchesBaseline': dailyMatchesBaseline,
        'dailyPerfectHitsBaseline': dailyPerfectHitsBaseline,
        'dailyPowersBaseline': dailyPowersBaseline,
        'weeklyWinsBaseline': weeklyWinsBaseline,
        'weeklyGoalsBaseline': weeklyGoalsBaseline,
        'weeklyPowersBaseline': weeklyPowersBaseline,
        'highestRewardedLeague': highestRewardedLeague,
        'claimedMissions':
            (claimedMissions.toList(growable: false)..sort()),
        'purchasedItems':
            (purchasedItems.toList(growable: false)..sort()),
        'selectedItems': selectedItems,
        'recentMatches': recentMatches,
      };

  void updateName(String value) {
    final String clean = value.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (clean.length < 2 || clean.length > 24 || clean == playerName) return;
    playerName = clean;
    _changed();
  }

  void refreshMissionCycles({bool persist = true}) {
    final DateTime now = DateTime.now();
    final String dayKey = _dateKey(now);
    final DateTime weekStart = DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: now.weekday - DateTime.monday));
    final String weekKey = _dateKey(weekStart);
    bool changed = false;

    if (dailyMissionCycle != dayKey) {
      dailyMissionCycle = dayKey;
      dailyMatchesBaseline = matches;
      dailyPerfectHitsBaseline = perfectHits;
      dailyPowersBaseline = powersUsed;
      claimedMissions.removeWhere((String id) => id.startsWith('daily:'));
      changed = true;
    }
    if (weeklyMissionCycle != weekKey) {
      weeklyMissionCycle = weekKey;
      weeklyWinsBaseline = wins;
      weeklyGoalsBaseline = goals;
      weeklyPowersBaseline = powersUsed;
      claimedMissions.removeWhere((String id) => id.startsWith('weekly:'));
      changed = true;
    }
    if (!changed) return;
    notifyListeners();
    if (persist) unawaited(flush());
  }

  String _dateKey(DateTime value) {
    final String month = value.month.toString().padLeft(2, '0');
    final String day = value.day.toString().padLeft(2, '0');
    return '${value.year}-$month-$day';
  }

  void setDifficulty(BotDifficulty value) {
    if (difficulty == value) return;
    difficulty = value;
    _changed();
  }

  void setSoundEnabled(bool value) {
    if (soundEnabled == value) return;
    soundEnabled = value;
    _changed();
  }

  void setMusicEnabled(bool value) {
    if (musicEnabled == value) return;
    musicEnabled = value;
    _changed();
  }

  void setVibrationEnabled(bool value) {
    if (vibrationEnabled == value) return;
    vibrationEnabled = value;
    _changed();
  }

  void setEffectsQuality(int value) {
    final int normalized = value.clamp(0, 2).toInt();
    if (effectsQuality == normalized) return;
    effectsQuality = normalized;
    _changed();
  }

  void setFrameRate(int value) {
    final int normalized = value >= 90 ? 90 : 60;
    if (frameRate == normalized) return;
    frameRate = normalized;
    unawaited(PlatformStateStore.setPreferredFrameRate(normalized));
    _changed();
  }

  bool claimMission(String id, int reward) {
    if (!claimedMissions.add(id)) return false;
    pulse += reward;
    _changed();
    return true;
  }

  bool purchaseItem(String id, String category, int price) {
    if (purchasedItems.contains(id)) {
      selectedItems[category] = id;
      _changed();
      return true;
    }
    if (pulse < price) return false;
    pulse -= price;
    purchasedItems.add(id);
    selectedItems[category] = id;
    _changed();
    return true;
  }

  bool purchaseBundle(Map<String, String> loadout, int price) {
    final bool alreadyOwned = loadout.values.every(purchasedItems.contains);
    if (!alreadyOwned && pulse < price) return false;
    if (!alreadyOwned) pulse -= price;
    purchasedItems.addAll(loadout.values);
    selectedItems.addAll(loadout);
    _changed();
    return true;
  }

  void selectItem(String id, String category) {
    if (!purchasedItems.contains(id) || selectedItems[category] == id) return;
    selectedItems[category] = id;
    _changed();
  }

  void recordMatch({
    required bool won,
    required int playerScore,
    required int botScore,
    required int matchPerfectHits,
    required int matchPowersUsed,
  }) {
    refreshMissionCycles(persist: false);
    assert(botScore >= 0);
    recentMatches.insert(0, <String, Object>{
      'won': won,
      'playerScore': playerScore,
      'botScore': botScore,
      'playedAt': DateTime.now().millisecondsSinceEpoch,
    });
    if (recentMatches.length > 6) recentMatches.removeLast();
    matches += 1;
    goals += playerScore;
    perfectHits += matchPerfectHits;
    powersUsed += matchPowersUsed;
    if (won) {
      wins += 1;
      pulse += 120;
      leagueScore += 42;
      levelXp += 180;
    } else {
      losses += 1;
      pulse += 45;
      leagueScore = (leagueScore - 18).clamp(0, 9999999).toInt();
      levelXp += 70;
    }
    _awardLeagueMilestones();
    while (levelXp >= nextLevelXp && level < 100) {
      levelXp -= nextLevelXp;
      level += 1;
      pulse += 150;
    }
    _changed(immediate: true);
  }

  void _awardLeagueMilestones() {
    final int reachedTier = (leagueScore ~/ 1000).clamp(0, 9999).toInt();
    if (reachedTier <= highestRewardedLeague) return;
    pulse += (reachedTier - highestRewardedLeague) * 300;
    highestRewardedLeague = reachedTier;
  }

  void _changed({bool immediate = false}) {
    notifyListeners();
    _saveDebounce?.cancel();
    if (immediate) {
      unawaited(_persist());
      return;
    }
    _saveDebounce = Timer(const Duration(milliseconds: 280), () {
      unawaited(_persist());
    });
  }

  Future<void> flush() {
    _saveDebounce?.cancel();
    return _persist();
  }

  Future<void> _persist() => PlatformStateStore.save(jsonEncode(toJson()));
}
