# ZARBU / ضربو

نسخه: `1.5.0+8` — Final Candidate
Package: `mk.kadkhodai.zarbu`

این بسته، نسخه نهایی آفلاین بازی به‌همراه زیرساخت واقعی پرداخت بازار و مایکت است. هسته مسابقه، اقتصاد، لیگ ضربو، پروفایل، فروشگاه داخلی، مأموریت‌ها، صندوق‌ها، تورنمنت، صدا و ذخیره‌سازی از مسیرهای مرکزی مشترک استفاده می‌کنند تا تغییرات فروشگاه روی منطق بازی اثر جانبی نداشته باشد.

## خروجی‌های Workflow V11

Workflow فعال:
`.github/workflows/ZARBU_BUILD_LATEST_ZIP_AUTO_FIXED_V11_SHELL_GUARD_JVM17_STORE_ISOLATION.yml`

Workflow همیشه یک APK آفلاین می‌سازد:
- `ZARBU-offline-release.apk`

اگر Secret واقعی بازار تنظیم شده باشد، خروجی زیر نیز ساخته می‌شود:
- `ZARBU-bazaar-release.apk`

اگر Secret واقعی مایکت تنظیم شده باشد، خروجی زیر نیز ساخته می‌شود:
- `ZARBU-myket-release.apk`

نسخه آفلاین هیچ ورودی خرید نقدی فعال ندارد. تب «سکه و جم» فقط در Build فروشگاهی که RSA واقعی از تنظیمات Build دریافت کرده باشد نمایش داده می‌شود.

## محصولات مصرفی فروشگاه

این ۶ شناسه باید دقیقاً در پنل فروشگاه مربوطه ایجاد شوند:
- `zarbu_coin_1000`
- `zarbu_coin_5000`
- `zarbu_coin_12000`
- `zarbu_gem_50`
- `zarbu_gem_150`
- `zarbu_bundle_6000_100`

قیمت پولی داخل سورس ثابت نشده است؛ قیمت از خود Bazaar/Myket خوانده می‌شود.

## حفاظت خرید

- خرید فقط بعد از پاسخ معتبر SDK همان مارکت ثبت می‌شود.
- SKU، Package Name و Payload کنترل می‌شوند.
- Purchase Token برای جلوگیری از دوباره‌پرداخت‌شدن یک خرید در Save نگهداری می‌شود.
- Grant ارز بازی قبل از Consume ثبت می‌شود و Consume ناموفق در صف Recovery قرار می‌گیرد.
- Reload/Crash بین Grant و Consume باعث دو برابر شدن اعتبار نمی‌شود.

## Release Gate

قبل از Build، `tool/release_gate.py` موارد زیر را کنترل می‌کند:
- Version و Package ID
- وجود Keystore
- دارایی‌های اجباری و ۱۰ آواتار
- نبودن Chat/Fake Payment/Debug runtime/Placeholder
- ساختار Settlement مرکزی و Anti-duplicate
- وابستگی‌های رسمی پرداخت
- Java 21 و تنظیمات Android موردنیاز مایکت
- JitPack موردنیاز Poolakey
- Workflow V11 و Store build guards

بعد از آن Workflow به‌ترتیب `flutter analyze`، `flutter test` و Release Build را اجرا می‌کند.

برای جزئیات نهایی به فایل‌های زیر مراجعه شود:
- `FINAL_RELEASE_CANDIDATE_v1.5.0_build8.md`
- `QA_MATRIX_v1.5.0_build8.md`
- `STORE_BILLING_REQUIREMENTS.md`
- `PREDELIVERY_VERIFICATION_v1.5.0_build8.md`

- Build hotfix: Poolakey Gradle compatibility is aligned automatically with the pinned Flutter Android toolchain.
- Image assets: transparent WebP, optimized to max 512 px while preserving UI aspect ratios.


## Store Isolation
Workflow V11 برای جلوگیری از Duplicate Class، هر APK را با dependency graph مستقل می‌سازد: Offline بدون SDK پرداخت، Bazaar فقط Poolakey و Myket فقط myket_iap.
