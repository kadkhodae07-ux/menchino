# ZARBU v1.5.0+8 — Bazaar / Myket Billing

Package: `mk.kadkhodai.zarbu`

## معماری

پرداخت به‌صورت Adapter مستقل در `lib/core/store/` پیاده‌سازی شده است. نسخه آفلاین بدون RSA ساخته می‌شود و هیچ تب خرید نقدی فعال ندارد. نسخه‌های فروشگاهی، RSA را فقط در زمان Build از `--dart-define=ZARBU_STORE_RSA=...` دریافت می‌کنند.

## وابستگی‌ها

- Bazaar: `flutter_poolakey: ^2.2.0+1.0.0`
- Myket: `myket_iap: ^1.1.11`

`tool/prepare_store_variant.py` قبل از هر Build فقط SDK همان مارکت را وارد dependency graph می‌کند. نسخه Bazaar فقط Poolakey، نسخه Myket فقط myket_iap و نسخه Offline بدون SDK پرداخت ساخته می‌شود. سپس `tool/prepare_android.py` تنظیمات Android/Signing و سازگاری Gradle مربوط به همان Variant را اعمال می‌کند.

## SKUهای canonical

همه محصولات Consumable هستند و باید دقیقاً با این شناسه‌ها در پنل هر مارکت ایجاد شوند:

| SKU | اعتبار داخل بازی |
|---|---|
| `zarbu_coin_1000` | 1,000 سکه |
| `zarbu_coin_5000` | 5,000 سکه |
| `zarbu_coin_12000` | 12,000 سکه |
| `zarbu_gem_50` | 50 جم |
| `zarbu_gem_150` | 150 جم |
| `zarbu_bundle_6000_100` | 6,000 سکه + 100 جم |

قیمت ریالی/تومانی در سورس تعریف نشده و از خود فروشگاه دریافت می‌شود.

## GitHub Secrets

برای تولید APK بازار:
`ZARBU_BAZAAR_RSA_KEY`

برای تولید APK مایکت:
`ZARBU_MYKET_RSA_KEY`

اگر Secret یک مارکت خالی باشد، Workflow همان Variant را Skip می‌کند ولی APK آفلاین همچنان ساخته می‌شود.

## ترتیب امن Purchase

1. اتصال SDK مارکت با RSA همان Build.
2. دریافت قیمت و Product detail از فروشگاه.
3. Launch purchase با Payload یونیک.
4. اعتبارسنجی SKU، Payload و Package Name.
5. ثبت Purchase Token در Ledger محلی و Grant یک‌باره ارز بازی.
6. Consume خرید.
7. اگر Consume شکست خورد، خرید در `pendingStoreConsumes` باقی می‌ماند و در اتصال بعدی Recovery می‌شود.
8. Token پردازش‌شده هرگز دوباره Grant نمی‌شود.

## کارهای بیرونی لازم قبل از انتشار فروشگاهی

- ساخت ۶ SKU بالا در پنل Bazaar.
- ساخت ۶ SKU بالا در پنل Myket.
- تعیین قیمت واقعی در هر پنل.
- دریافت RSA/Public Key مربوط به همین Package از هر مارکت.
- ثبت RSAها در GitHub Secrets بالا.
- Build با Workflow V11 Store Isolation.
- تست Purchase/Consume/Re-purchase با حساب تست و اپ مارکت روی دستگاه واقعی.

تا قبل از انجام این مراحل بیرونی، APK آفلاین کامل است ولی Variant فروشگاهی قابل تایید تراکنش واقعی نیست.


## جداسازی SDKهای پرداخت
Poolakey و Myket IAP هر دو کلاس `com.android.vending.billing.IInAppBillingService` را داخل AAR خود دارند. قرارگرفتن هم‌زمان آن‌ها در یک APK باعث `checkReleaseDuplicateClasses` می‌شود. Workflow V11 این دو SDK را در هیچ Variantی هم‌زمان لینک نمی‌کند.
