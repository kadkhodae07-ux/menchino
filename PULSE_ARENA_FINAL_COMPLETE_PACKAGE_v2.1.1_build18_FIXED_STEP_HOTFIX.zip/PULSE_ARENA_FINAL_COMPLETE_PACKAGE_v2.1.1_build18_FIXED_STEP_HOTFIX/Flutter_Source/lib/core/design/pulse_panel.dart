import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A raised, asymmetric game surface with controlled accents and real depth.
///
/// Unlike the old full-neon frame, this painter uses a dark extrusion, soft
/// shadow, restrained edge lighting and intentionally different corner cuts.
class PulsePanel extends StatelessWidget {
  const PulsePanel({
    required this.colors,
    required this.child,
    this.cut = 18,
    this.padding = EdgeInsets.zero,
    this.pressed = false,
    this.intensity = 1,
    super.key,
  });

  final List<Color> colors;
  final Widget child;
  final double cut;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final double intensity;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: PulsePanelPainter(
          colors: colors,
          cut: cut,
          pressed: pressed,
          intensity: intensity,
        ),
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

class PulsePanelPainter extends CustomPainter {
  const PulsePanelPainter({
    required this.colors,
    required this.cut,
    required this.pressed,
    required this.intensity,
  });

  final List<Color> colors;
  final double cut;
  final bool pressed;
  final double intensity;

  Path _shape(Size size, double inset) {
    final double c = math.max(5.0, cut - inset * .42);
    final double l = inset;
    final double t = inset;
    final double r = size.width - inset;
    final double b = size.height - inset;

    // Deliberately asymmetric silhouette: short upper-left shoulder, layered
    // upper-right notch, and a deeper lower-left cut.
    return Path()
      ..moveTo(l + c * .72, t)
      ..lineTo(r - c * 1.28, t)
      ..lineTo(r - c * .62, t + c * .34)
      ..lineTo(r, t + c)
      ..lineTo(r, b - c * .62)
      ..lineTo(r - c * .76, b)
      ..lineTo(l + c * 1.14, b)
      ..lineTo(l, b - c * 1.02)
      ..lineTo(l, t + c * .54)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final Rect rect = Offset.zero & size;
    final Path outer = _shape(size, 2.0);
    final Path bevel = _shape(size, 5.0);
    final Path inner = _shape(size, 7.6);
    final Color primary = colors.first;
    final Color secondary = colors.length > 1 ? colors.last : colors.first;
    final double state = pressed ? .62 : 1.0;
    final double lift = pressed ? 1.5 : 5.0;
    final double accent = intensity.clamp(0.0, 1.25).toDouble();

    canvas.drawShadow(
      outer.shift(Offset(0, lift)),
      const Color(0xE0000000),
      pressed ? 3 : 9,
      false,
    );

    // Mechanical extrusion under the panel: this creates visible separation
    // from the background instead of relying on a bright outline.
    canvas.save();
    canvas.translate(0, lift);
    canvas.drawPath(outer, Paint()..color = const Color(0xFF010409));
    canvas.drawPath(
      bevel,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.1
        ..color = const Color(0xFF111B27),
    );
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFF182635),
            Color(0xFF0D1824),
            Color(0xFF08111B),
            Color(0xFF0A121D),
          ],
          stops: <double>[0, .30, .72, 1],
        ).createShader(rect),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withValues(alpha: pressed ? .018 : .075),
            Colors.transparent,
            const Color(0x55000000),
          ],
          stops: const <double>[0, .42, 1],
        ).createShader(rect),
    );
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            primary.withValues(alpha: .030 * accent * state),
            Colors.transparent,
            Colors.transparent,
            secondary.withValues(alpha: .022 * accent * state),
          ],
          stops: const <double>[0, .28, .74, 1],
        ).createShader(rect),
    );
    canvas.restore();

    // Neutral body outline. Accents no longer surround the whole box.
    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.35
        ..color = const Color(0xFF3B4A5B).withValues(alpha: .90 * state),
    );
    canvas.drawPath(
      bevel,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .75
        ..color = const Color(0xFF6C7C8D).withValues(alpha: .28 * state),
    );

    // Small functional accent rails create hierarchy without visual noise.
    final Paint rail = Paint()
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;
    rail.color = primary.withValues(alpha: .60 * accent * state);
    canvas.drawLine(
      Offset(cut * .70, 4.4),
      Offset(math.min(size.width * .23, cut * .70 + 42), 4.4),
      rail,
    );
    canvas.drawLine(
      const Offset(4.4, 15),
      Offset(4.4, math.min(size.height * .35, 34)),
      rail,
    );

    rail.color = secondary.withValues(alpha: .42 * accent * state);
    canvas.drawLine(
      Offset(size.width - cut * .76, size.height - 4.4),
      Offset(math.max(size.width * .77, size.width - cut * .76 - 38), size.height - 4.4),
      rail,
    );

    // A dark lower seam reinforces the raised construction.
    canvas.drawLine(
      Offset(cut + 8, size.height - 2.8),
      Offset(size.width - cut - 8, size.height - 2.8),
      Paint()
        ..strokeWidth = 1.0
        ..color = const Color(0xD9000205),
    );
  }

  @override
  bool shouldRepaint(covariant PulsePanelPainter oldDelegate) {
    return oldDelegate.pressed != pressed ||
        oldDelegate.intensity != intensity ||
        oldDelegate.colors != colors ||
        oldDelegate.cut != cut;
  }
}
