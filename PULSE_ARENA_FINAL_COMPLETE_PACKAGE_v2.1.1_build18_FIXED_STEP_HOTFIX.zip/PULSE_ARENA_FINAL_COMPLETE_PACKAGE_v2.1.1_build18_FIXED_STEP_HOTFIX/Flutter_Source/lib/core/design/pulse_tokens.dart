import 'package:flutter/material.dart';

/// Production design tokens for the calmer, depth-first PULSE ARENA interface.
///
/// Accent colors are intentionally restrained. Cyan is the primary action
/// color, rose is reserved for active/critical states, and gold is used only
/// for rewards and competitive rank.
abstract final class PulseColors {
  static const Color voidBlack = Color(0xFF02050A);
  static const Color background = Color(0xFF050A12);
  static const Color deepNavy = Color(0xFF08111D);
  static const Color panelTop = Color(0xFF111D2B);
  static const Color panelBottom = Color(0xFF09121E);
  static const Color panelInset = Color(0xFF060C14);
  static const Color elevated = Color(0xFF0D1825);

  static const Color cyan = Color(0xFF45C7D8);
  static const Color blue = Color(0xFF3D83C9);
  static const Color violet = Color(0xFF756FA8);
  static const Color rose = Color(0xFFC15C8E);
  static const Color magentaDeep = Color(0xFF80587F);
  static const Color gold = Color(0xFFD6AE58);
  static const Color success = Color(0xFF62C991);
  static const Color danger = Color(0xFFD66B78);

  static const Color textPrimary = Color(0xFFF2F5F8);
  static const Color textSecondary = Color(0xFFA9B4C2);
  static const Color textMuted = Color(0xFF718093);
  static const Color disabled = Color(0xFF4D5A6B);
  static const Color divider = Color(0xFF263445);
  static const Color hairline = Color(0xFF33465A);
}

abstract final class PulseSpacing {
  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 22;
  static const double xl = 28;
}

abstract final class PulseDurations {
  static const Duration press = Duration(milliseconds: 85);
  static const Duration micro = Duration(milliseconds: 165);
  static const Duration page = Duration(milliseconds: 220);
  static const Duration dialog = Duration(milliseconds: 210);
  static const Duration reward = Duration(milliseconds: 520);
}

abstract final class PulseTypography {
  static const String family = 'sans-serif';

  static const TextStyle display = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 27,
    fontWeight: FontWeight.w900,
    height: 1.14,
  );

  static const TextStyle title = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 19,
    fontWeight: FontWeight.w900,
    height: 1.2,
  );

  static const TextStyle section = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 14.5,
    fontWeight: FontWeight.w900,
    height: 1.28,
  );

  static const TextStyle body = TextStyle(
    fontFamily: family,
    color: PulseColors.textSecondary,
    fontSize: 11.5,
    fontWeight: FontWeight.w600,
    height: 1.5,
  );

  static const TextStyle label = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 11.5,
    fontWeight: FontWeight.w800,
    height: 1.25,
  );
}

ThemeData buildPulseArenaTheme() {
  final ColorScheme scheme = ColorScheme.fromSeed(
    seedColor: PulseColors.cyan,
    brightness: Brightness.dark,
    surface: PulseColors.deepNavy,
    error: PulseColors.danger,
  );
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    fontFamily: PulseTypography.family,
    scaffoldBackgroundColor: PulseColors.voidBlack,
    colorScheme: scheme,
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    hoverColor: Colors.transparent,
    focusColor: PulseColors.cyan.withValues(alpha: .10),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: PulseColors.cyan,
      selectionColor: PulseColors.cyan.withValues(alpha: .20),
      selectionHandleColor: PulseColors.cyan,
    ),
  );
}
