enum BotDifficulty { trainee, tactical, champion }

enum GameMode { offline, training }

extension GameModeLabel on GameMode {
  String get title => switch (this) {
        GameMode.offline => 'نبرد آفلاین',
        GameMode.training => 'تمرین آزاد',
      };

  String get subtitle => switch (this) {
        GameMode.offline => 'مسابقه کامل با ثبت آمار و پاداش',
        GameMode.training => 'تمرین سریع بدون تغییر آمار رقابتی',
      };
}

extension BotDifficultyLabel on BotDifficulty {
  String get title {
    switch (this) {
      case BotDifficulty.trainee:
        return 'تمرینی';
      case BotDifficulty.tactical:
        return 'تاکتیکی';
      case BotDifficulty.champion:
        return 'قهرمان';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.trainee:
        return 'کند، خطاپذیر و مناسب یادگیری';
      case BotDifficulty.tactical:
        return 'متعادل، طبیعی و مناسب مسابقه اصلی';
      case BotDifficulty.champion:
        return 'سخت و واکنش‌گرا، اما قابل شکست';
    }
  }
}

class GameConfig {
  const GameConfig({
    this.mode = GameMode.offline,
    this.trackProgress = true,
    this.difficulty = BotDifficulty.tactical,
    this.targetScore = 10,
    this.ballBaseSpeed = 430,
    this.ballMaximumSpeed = 790,
    this.ballSpeedIncreasePerSecond = 1.6,
    this.serveSpeedFactor = .72,
    this.serveRampDuration = 1.15,
    this.playerPaddleSpeed = 6200,
    this.playerPaddleAcceleration = 96000,
    this.playerResponse = 58,
    this.botPaddleSpeed = 760,
    this.botPaddleAcceleration = 7200,
    this.botReactionDelay = 0.19,
    this.botErrorChance = 0.34,
    this.botBaseAimError = 88,
    this.countdownDuration = 3.2,
    this.pointServeDelay = 0.90,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.56,
    this.boostMultiplier = 1.26,
    this.shieldUses = 2,
    this.boostUses = 2,
    this.pulseUses = 2,
  });

  factory GameConfig.forDifficulty(BotDifficulty difficulty) {
    switch (difficulty) {
      case BotDifficulty.trainee:
        return const GameConfig(
          difficulty: BotDifficulty.trainee,
          botPaddleSpeed: 590,
          botPaddleAcceleration: 5200,
          botReactionDelay: 0.29,
          botErrorChance: 0.50,
          botBaseAimError: 132,
          ballBaseSpeed: 390,
          ballMaximumSpeed: 680,
          ballSpeedIncreasePerSecond: 1.25,
          serveSpeedFactor: .68,
        );
      case BotDifficulty.tactical:
        return const GameConfig();
      case BotDifficulty.champion:
        return const GameConfig(
          difficulty: BotDifficulty.champion,
          botPaddleSpeed: 910,
          botPaddleAcceleration: 9800,
          botReactionDelay: 0.135,
          botErrorChance: 0.23,
          botBaseAimError: 64,
          ballBaseSpeed: 460,
          ballMaximumSpeed: 850,
          ballSpeedIncreasePerSecond: 1.85,
          serveSpeedFactor: .74,
        );
    }
  }

  factory GameConfig.training() {
    return const GameConfig(
      mode: GameMode.training,
      trackProgress: false,
      difficulty: BotDifficulty.trainee,
      targetScore: 5,
      ballBaseSpeed: 375,
      ballMaximumSpeed: 650,
      ballSpeedIncreasePerSecond: 1.1,
      serveSpeedFactor: .66,
      botPaddleSpeed: 545,
      botPaddleAcceleration: 4800,
      botReactionDelay: 0.32,
      botErrorChance: 0.54,
      botBaseAimError: 142,
      shieldUses: 99,
      boostUses: 99,
      pulseUses: 99,
    );
  }

  final GameMode mode;
  final bool trackProgress;
  final BotDifficulty difficulty;
  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double serveSpeedFactor;
  final double serveRampDuration;
  final double playerPaddleSpeed;
  final double playerPaddleAcceleration;
  final double playerResponse;
  final double botPaddleSpeed;
  final double botPaddleAcceleration;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double pointServeDelay;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
