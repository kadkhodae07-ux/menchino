import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

String _hubLibrary() {
  final StringBuffer source = StringBuffer(
    File('lib/screens/hub_screen.dart').readAsStringSync(),
  );
  for (final FileSystemEntity entity in Directory('lib/screens/hub')
      .listSync()
      .where((FileSystemEntity entity) => entity.path.endsWith('.dart'))) {
    source.write((entity as File).readAsStringSync());
  }
  return source.toString();
}

void main() {
  test('complete game hub includes every production page', () {
    final String hub = _hubLibrary();
    final String app = File('lib/app/pulse_arena_app.dart').readAsStringSync();

    expect(app, contains('HubScreen'));
    expect(hub, contains('class HubScreen'));
    expect(hub, contains('class _ProfilePage'));
    expect(hub, contains('class _MissionsPage'));
    expect(hub, contains('class _RankingPage'));
    expect(hub, contains('class _ShopPage'));
    expect(hub, contains('class _SettingsPage'));
    expect(hub, contains('رتبه‌بندی آفلاین'));
    expect(hub, contains('فروشگاه آرنا'));
    expect(hub, contains('پروفایل فرمانده'));
    expect(hub, contains('ماموریت‌ها'));
  });

  test('compact navigation has five equal persistent destinations', () {
    final String hub = _hubLibrary();

    expect(hub, contains('height: 66'));
    expect(hub, contains('intensity: .34'));
    expect(hub, contains("_NavData(Icons.person_outline_rounded, 'پروفایل')"));
    expect(hub, contains("_NavData(Icons.track_changes_rounded, 'ماموریت‌ها'"));
    expect(hub, contains("_NavData(Icons.shopping_cart_outlined, 'فروشگاه')"));
    expect(hub, contains("_NavData(Icons.settings_outlined, 'تنظیمات')"));
    expect(hub, contains("_NavData(Icons.home_rounded, 'خانه')"));
  });

  test('all main surfaces use modular multi-layer graphical panels', () {
    final String hub = _hubLibrary();
    final String panel =
        File('lib/core/design/pulse_panel.dart').readAsStringSync();

    expect(hub, contains('PulsePanel('));
    expect(panel, contains('class PulsePanelPainter'));
    expect(panel, contains('final double lift = pressed ? 1.5 : 5.0'));
    expect(panel, contains('canvas.translate(0, lift)'));
    expect(panel, contains('canvas.drawShadow'));
    expect(panel, contains('Deliberately asymmetric silhouette'));
    expect(panel, contains('final Path inner'));
    expect(hub, contains('static Picture? _staticPicture'));
    expect(hub, contains('class _ActionButtonPainter'));
    expect(hub, isNot(contains('ElevatedButton(')));
    expect(RegExp(r'(^|[^A-Za-z0-9_])Card\(').hasMatch(hub), isFalse);
  });

  test('home layout expands arena and anchors actions near bottom', () {
    final String hub = _hubLibrary();

    expect(hub, contains('MainAxisAlignment.spaceBetween'));
    expect(hub, contains('final double arenaHeight = (height * .37)'));
    expect(hub, contains('class _SeasonRibbon'));
    expect(hub, contains('PULSE ARENA'));
    expect(hub, contains('شروع بازی'));
  });
}
