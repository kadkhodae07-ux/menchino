import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('restrained arena design tokens match the production identity', () {
    final String tokens = File('lib/core/design/pulse_tokens.dart').readAsStringSync();
    expect(tokens, contains('Color(0xFF050A12)'));
    expect(tokens, contains('Color(0xFF45C7D8)'));
    expect(tokens, contains('Color(0xFFC15C8E)'));
    expect(tokens, contains('Color(0xFF756FA8)'));
    expect(tokens, contains('Color(0xFFD6AE58)'));
    expect(tokens, contains('class PulseSpacing'));
    expect(tokens, contains('class PulseDurations'));
  });

  test('portrait navigation has five persistent production destinations', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();
    expect(hub, contains("_NavData(Icons.person_outline_rounded, 'پروفایل')"));
    expect(hub, contains("_NavData(Icons.track_changes_rounded, 'ماموریت‌ها'"));
    expect(hub, contains("_NavData(Icons.home_rounded, 'خانه')"));
    expect(hub, contains("_NavData(Icons.shopping_cart_outlined, 'فروشگاه')"));
    expect(hub, contains("_NavData(Icons.settings_outlined, 'تنظیمات')"));
    expect(hub, contains('class _GlobalPlayerHeader'));
  });

  test('daily reward, audio volume, and disabled interaction states are real', () {
    final String missions = File('lib/screens/hub/missions_page.dart').readAsStringSync();
    final String settings = File('lib/screens/hub/settings_page.dart').readAsStringSync();
    final String pressable = File('lib/widgets/neon_pressable.dart').readAsStringSync();
    final String audio = File('lib/game/managers/audio_manager.dart').readAsStringSync();

    expect(missions, contains('claimDailyReward'));
    expect(missions, contains('onTap: available ? onClaim : null'));
    expect(settings, contains('class _CyberVolumeSlider'));
    expect(
      RegExp(r'(^|[^A-Za-z0-9_])Slider\(').hasMatch(settings),
      isFalse,
    );
    expect(pressable, contains('final VoidCallback? onTap'));
    expect(pressable, contains('enabled: widget.enabled'));
    expect(audio, contains('soundVolume'));
    expect(audio, contains('musicVolume'));
  });

  test('result rewards are based on the same persisted match economy', () {
    final String screen = File('lib/screens/game_screen.dart').readAsStringSync();
    final String state = File('lib/player/player_progress_controller.dart').readAsStringSync();
    expect(screen, contains('+۱۲۰ پالس'));
    expect(screen, contains('+۴۵ پالس'));
    expect(screen, contains('تمرین آزاد؛ آمار رقابتی و موجودی تغییری نکرد'));
    expect(state, contains('pulse += 120'));
    expect(state, contains('pulse += 45'));
    expect(state, contains('leagueScore += 42'));
  });
}
