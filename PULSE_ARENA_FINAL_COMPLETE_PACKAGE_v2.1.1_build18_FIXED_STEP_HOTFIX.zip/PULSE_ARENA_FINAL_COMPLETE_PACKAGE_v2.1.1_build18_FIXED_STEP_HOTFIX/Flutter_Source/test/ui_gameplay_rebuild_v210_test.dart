import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';

void main() {
  test('serve starts controlled and ramps to match speed', () {
    const GameConfig config = GameConfig();
    expect(config.serveSpeedFactor, lessThan(0.8));
    expect(config.serveRampDuration, greaterThanOrEqualTo(1.0));
    expect(config.ballBaseSpeed, lessThan(500));
    expect(config.ballMaximumSpeed, lessThan(900));
  });

  test('all bot levels remain distinct without a losing catch-up boost', () {
    final GameConfig trainee = GameConfig.forDifficulty(BotDifficulty.trainee);
    final GameConfig tactical = GameConfig.forDifficulty(BotDifficulty.tactical);
    final GameConfig champion = GameConfig.forDifficulty(BotDifficulty.champion);
    final String bot = File('lib/game/components/bot_paddle_controller.dart').readAsStringSync();

    expect(trainee.botReactionDelay, greaterThan(tactical.botReactionDelay));
    expect(tactical.botReactionDelay, greaterThan(champion.botReactionDelay));
    expect(trainee.botErrorChance, greaterThan(tactical.botErrorChance));
    expect(tactical.botErrorChance, greaterThan(champion.botErrorChance));
    expect(bot, contains('final double rubberBand = lead >= 3 ? .86 : 1.0'));
    expect(bot, isNot(contains('lead <= -3 ? 1.08')));
  });

  test('interface uses restrained accents and raised asymmetric panels', () {
    final String tokens = File('lib/core/design/pulse_tokens.dart').readAsStringSync();
    final String panel = File('lib/core/design/pulse_panel.dart').readAsStringSync();
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();

    expect(tokens, contains('Cyan is the primary action'));
    expect(panel, contains('canvas.drawShadow'));
    expect(panel, contains('Deliberately asymmetric silhouette'));
    expect(hub, contains('height: 66'));
    expect(hub, contains('intensity: .34'));
  });
}
