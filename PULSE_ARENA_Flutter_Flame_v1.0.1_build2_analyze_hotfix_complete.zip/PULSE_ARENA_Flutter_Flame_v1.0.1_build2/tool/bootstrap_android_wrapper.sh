#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -x android/gradlew && -f android/gradle/wrapper/gradle-wrapper.jar ]]; then
  echo "Android Gradle wrapper already exists."
  exit 0
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
flutter create --platforms=android --android-language kotlin --project-name pulse_arena "$TMP_DIR/wrapper_seed"
cp "$TMP_DIR/wrapper_seed/android/gradlew" android/gradlew
cp "$TMP_DIR/wrapper_seed/android/gradlew.bat" android/gradlew.bat
mkdir -p android/gradle/wrapper
cp "$TMP_DIR/wrapper_seed/android/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
cp "$TMP_DIR/wrapper_seed/android/gradle/wrapper/gradle-wrapper.properties" android/gradle/wrapper/gradle-wrapper.properties
chmod +x android/gradlew
echo "Android Gradle wrapper generated from the installed Flutter SDK."
