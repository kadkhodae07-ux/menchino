import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../game/models/game_view_state.dart';
import '../game/pulse_arena_game.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final PulseArenaGame game;

  @override
  void initState() {
    super.initState();
    game = PulseArenaGame();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) game.pauseMatch();
      },
      child: Scaffold(
        body: SafeArea(
          child: ValueListenableBuilder<GameViewState>(
            valueListenable: game.viewState,
            builder: (BuildContext context, GameViewState state, Widget? child) {
              return Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onPanStart: (DragStartDetails d) => game.handleTouch(d.localPosition.dy),
                    onPanUpdate: (DragUpdateDetails d) => game.handleTouch(d.localPosition.dy),
                    onTapDown: (TapDownDetails d) => game.handleTouch(d.localPosition.dy),
                    child: GameWidget<PulseArenaGame>(game: game),
                  ),
                  _Hud(state: state, onPause: game.pauseMatch),
                  _PowerBar(state: state, onActivate: game.activatePower),
                  if (state.phase == MatchPhase.countdown) _Countdown(value: state.countdown),
                  if (state.phase == MatchPhase.paused)
                    _PausePanel(
                      state: state,
                      onResume: game.resumeMatch,
                      onRestart: game.restartMatch,
                      onHome: () => SceneTransitionManager.openStart(context),
                      onToggleSound: game.toggleSound,
                      onToggleVibration: game.toggleVibration,
                    ),
                  if (state.phase == MatchPhase.finished)
                    _EndPanel(
                      state: state,
                      onReplay: game.restartMatch,
                      onHome: () => SceneTransitionManager.openStart(context),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({required this.state, required this.onPause});
  final GameViewState state;
  final VoidCallback onPause;

  String get _time {
    final int total = state.elapsedSeconds.floor();
    final int minutes = total ~/ 60;
    final int seconds = total % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 28,
      right: 28,
      top: 10,
      child: IgnorePointer(
        ignoring: false,
        child: Row(
          children: <Widget>[
            _Score(label: 'شما', score: state.playerScore, color: const Color(0xFF37DEFF)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 9),
              decoration: BoxDecoration(
                color: const Color(0xCC0B1022),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0x556F75A4)),
              ),
              child: Text(_time, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 2)),
            ),
            const SizedBox(width: 16),
            GestureDetector(
              onTap: () {
                AudioManager.instance.playButton();
                onPause();
              },
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  color: const Color(0xCC151A31),
                  border: Border.all(color: const Color(0x886B77A5)),
                ),
                child: const Icon(Icons.pause_rounded, color: Colors.white, size: 30),
              ),
            ),
            const Spacer(),
            _Score(label: 'ربات', score: state.botScore, color: const Color(0xFFFF51B2)),
          ],
        ),
      ),
    );
  }
}

class _Score extends StatelessWidget {
  const _Score({required this.label, required this.score, required this.color});
  final String label;
  final int score;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Text(label, textDirection: TextDirection.rtl, style: TextStyle(color: color.withValues(alpha: 0.8), fontWeight: FontWeight.w700)),
        const SizedBox(width: 10),
        Text(
          '$score',
          style: TextStyle(
            fontSize: 36,
            height: 1,
            fontWeight: FontWeight.w900,
            color: color,
            shadows: <Shadow>[Shadow(color: color, blurRadius: 18)],
          ),
        ),
      ],
    );
  }
}

class _PowerBar extends StatelessWidget {
  const _PowerBar({required this.state, required this.onActivate});
  final GameViewState state;
  final bool Function(PowerType type) onActivate;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 0,
      right: 0,
      bottom: 12,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          _PowerButton(
            title: 'سپر',
            icon: Icons.shield_rounded,
            count: state.shieldUses,
            active: state.shieldActive,
            color: const Color(0xFF22CFFF),
            enabled: state.phase == MatchPhase.playing && state.shieldUses > 0 && !state.shieldActive,
            onTap: () => onActivate(PowerType.shield),
          ),
          const SizedBox(width: 18),
          _PowerButton(
            title: 'شتاب',
            icon: Icons.bolt_rounded,
            count: state.boostUses,
            active: state.boostArmed,
            color: const Color(0xFFFF9B35),
            enabled: state.phase == MatchPhase.playing && state.boostUses > 0 && !state.boostArmed,
            onTap: () => onActivate(PowerType.boost),
          ),
          const SizedBox(width: 18),
          _PowerButton(
            title: 'پالس',
            icon: Icons.graphic_eq_rounded,
            count: state.pulseUses,
            active: state.pulseActive,
            color: const Color(0xFFAE5CFF),
            enabled: state.phase == MatchPhase.playing && state.pulseUses > 0 && !state.pulseActive,
            onTap: () => onActivate(PowerType.pulse),
          ),
        ],
      ),
    );
  }
}

class _PowerButton extends StatefulWidget {
  const _PowerButton({
    required this.title,
    required this.icon,
    required this.count,
    required this.active,
    required this.color,
    required this.enabled,
    required this.onTap,
  });
  final String title;
  final IconData icon;
  final int count;
  final bool active;
  final Color color;
  final bool enabled;
  final VoidCallback onTap;

  @override
  State<_PowerButton> createState() => _PowerButtonState();
}

class _PowerButtonState extends State<_PowerButton> {
  bool pressed = false;

  @override
  Widget build(BuildContext context) {
    final double opacity = widget.enabled || widget.active ? 1 : 0.38;
    return GestureDetector(
      onTapDown: widget.enabled ? (_) => setState(() => pressed = true) : null,
      onTapCancel: widget.enabled ? () => setState(() => pressed = false) : null,
      onTapUp: widget.enabled
          ? (_) {
              setState(() => pressed = false);
              widget.onTap();
            }
          : null,
      child: AnimatedScale(
        scale: pressed ? 0.92 : 1,
        duration: const Duration(milliseconds: 90),
        child: AnimatedOpacity(
          opacity: opacity,
          duration: const Duration(milliseconds: 180),
          child: Container(
            width: 128,
            height: 66,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: const Color(0xE0101428),
              border: Border.all(color: widget.active ? Colors.white : widget.color, width: widget.active ? 2.5 : 1.5),
              boxShadow: <BoxShadow>[BoxShadow(color: widget.color.withValues(alpha: widget.active ? 0.65 : 0.28), blurRadius: 20)],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(widget.icon, color: widget.color, size: 30),
                const SizedBox(width: 8),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(widget.title, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                    Text('×${widget.count}', style: TextStyle(fontSize: 12, color: widget.color, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Countdown extends StatelessWidget {
  const _Countdown({required this.value});
  final int value;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 240),
        transitionBuilder: (Widget child, Animation<double> animation) => ScaleTransition(scale: animation, child: FadeTransition(opacity: animation, child: child)),
        child: Text(
          '$value',
          key: ValueKey<int>(value),
          style: const TextStyle(
            fontSize: 110,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            shadows: <Shadow>[Shadow(color: Color(0xFF764DFF), blurRadius: 34)],
          ),
        ),
      ),
    );
  }
}

class _PausePanel extends StatelessWidget {
  const _PausePanel({
    required this.state,
    required this.onResume,
    required this.onRestart,
    required this.onHome,
    required this.onToggleSound,
    required this.onToggleVibration,
  });
  final GameViewState state;
  final VoidCallback onResume;
  final VoidCallback onRestart;
  final VoidCallback onHome;
  final VoidCallback onToggleSound;
  final VoidCallback onToggleVibration;

  @override
  Widget build(BuildContext context) {
    return _OverlayPanel(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const Text('توقف بازی', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 20),
          _MenuButton(text: 'ادامه بازی', icon: Icons.play_arrow_rounded, onTap: onResume),
          _MenuButton(text: 'شروع مجدد', icon: Icons.refresh_rounded, onTap: onRestart),
          _MenuButton(text: 'بازگشت به شروع', icon: Icons.home_rounded, onTap: onHome),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              _ToggleButton(
                icon: state.soundEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                enabled: state.soundEnabled,
                onTap: onToggleSound,
              ),
              const SizedBox(width: 14),
              _ToggleButton(
                icon: state.vibrationEnabled ? Icons.vibration_rounded : Icons.mobile_off_rounded,
                enabled: state.vibrationEnabled,
                onTap: onToggleVibration,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EndPanel extends StatelessWidget {
  const _EndPanel({required this.state, required this.onReplay, required this.onHome});
  final GameViewState state;
  final VoidCallback onReplay;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    final bool won = state.winner == MatchWinner.player;
    final Color color = won ? const Color(0xFF39E2FF) : const Color(0xFFFF4FAE);
    return _OverlayPanel(
      glow: color,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(won ? Icons.emoji_events_rounded : Icons.sports_esports_rounded, size: 54, color: color),
          const SizedBox(height: 8),
          Text(
            won ? 'پیروز شدی!' : 'ربات برنده شد',
            textDirection: TextDirection.rtl,
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: color, shadows: <Shadow>[Shadow(color: color, blurRadius: 20)]),
          ),
          const SizedBox(height: 12),
          Text('${state.playerScore}  —  ${state.botScore}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 6)),
          const SizedBox(height: 22),
          _MenuButton(text: 'بازی دوباره', icon: Icons.replay_rounded, onTap: onReplay),
          _MenuButton(text: 'بازگشت به شروع', icon: Icons.home_rounded, onTap: onHome),
        ],
      ),
    );
  }
}

class _OverlayPanel extends StatelessWidget {
  const _OverlayPanel({required this.child, this.glow = const Color(0xFF704BFF)});
  final Widget child;
  final Color glow;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xB8000208),
      child: Center(
        child: Container(
          width: 390,
          padding: const EdgeInsets.fromLTRB(28, 24, 28, 24),
          decoration: BoxDecoration(
            color: const Color(0xF20C1020),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: glow.withValues(alpha: 0.75), width: 1.5),
            boxShadow: <BoxShadow>[BoxShadow(color: glow.withValues(alpha: 0.35), blurRadius: 40)],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({required this.text, required this.icon, required this.onTap});
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: SizedBox(
        width: 280,
        height: 50,
        child: FilledButton.icon(
          onPressed: () {
            AudioManager.instance.playButton();
            onTap();
          },
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF18213C),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0x665DE3FF))),
          ),
          icon: Icon(icon),
          label: Text(text, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ),
    );
  }
}

class _ToggleButton extends StatelessWidget {
  const _ToggleButton({required this.icon, required this.enabled, required this.onTap});
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return IconButton.filledTonal(
      onPressed: onTap,
      icon: Icon(icon, color: enabled ? const Color(0xFF46DFFF) : const Color(0xFF8B91A8)),
      style: IconButton.styleFrom(backgroundColor: const Color(0xFF171C30)),
    );
  }
}
