import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

class ImpactParticle extends PositionComponent {
  ImpactParticle({required Vector2 origin, required Color color, required this.seed})
      : _color = color,
        super(position: origin.clone(), priority: 30);

  final Color _color;
  final int seed;
  late final List<_Spark> _sparks;
  double _life = 0.34;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final math.Random random = math.Random(seed);
    _sparks = List<_Spark>.generate(10, (int index) {
      final double angle = random.nextDouble() * math.pi * 2;
      final double speed = 80.0 + random.nextDouble() * 170.0;
      return _Spark(
        velocity: Vector2(math.cos(angle) * speed, math.sin(angle) * speed),
        radius: 1.5 + random.nextDouble() * 2.4,
      );
    });
  }

  @override
  void update(double dt) {
    super.update(dt);
    _life -= dt;
    for (final _Spark spark in _sparks) {
      spark.offset += spark.velocity * dt;
      spark.velocity *= 0.92;
    }
    if (_life <= 0) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final double opacity = (_life / 0.34).clamp(0.0, 1.0).toDouble();
    for (final _Spark spark in _sparks) {
      canvas.drawCircle(
        Offset(spark.offset.x, spark.offset.y),
        spark.radius,
        Paint()
          ..color = _color.withValues(alpha: opacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
    }
  }
}

class _Spark {
  _Spark({required this.velocity, required this.radius});
  Vector2 offset = Vector2.zero();
  Vector2 velocity;
  final double radius;
}
