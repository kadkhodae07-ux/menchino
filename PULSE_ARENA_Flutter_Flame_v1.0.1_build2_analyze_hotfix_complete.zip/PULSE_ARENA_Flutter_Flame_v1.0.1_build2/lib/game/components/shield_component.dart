import 'dart:ui';

import 'package:flame/components.dart';

import 'player_paddle_controller.dart';

class ShieldComponent extends PositionComponent {
  ShieldComponent({required this.player, required this.isActive, super.priority = 5});

  final PlayerPaddleController player;
  final bool Function() isActive;
  Rect arena = Rect.zero;

  void layout(Rect value) {
    arena = value;
    size = Vector2(value.width, value.height);
  }

  double get collisionX => player.position.x - 25;

  @override
  void render(Canvas canvas) {
    if (!isActive() || arena.isEmpty) return;
    final double localX = collisionX - arena.left;
    final Rect bar = Rect.fromLTWH(localX - 5, 4, 10, arena.height - 8);
    canvas.save();
    canvas.translate(arena.left, arena.top);
    canvas.drawRRect(
      RRect.fromRectAndRadius(bar, const Radius.circular(7)),
      Paint()
        ..color = const Color(0xAA44E7FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(bar, const Radius.circular(7)),
      Paint()..color = const Color(0xDDEBFDFF),
    );
    canvas.restore();
  }
}
