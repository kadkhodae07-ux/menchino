import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

import '../config/game_config.dart';
import 'ball_controller.dart';

class BotPaddleController extends PositionComponent {
  BotPaddleController({
    required this.config,
    required this.ball,
    required this.playerScore,
    required this.isPulseActive,
  });

  final GameConfig config;
  final BallController ball;
  final int Function() playerScore;
  final bool Function() isPulseActive;
  final math.Random _random = math.Random(9721);

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  double _reactionTimer = 0;
  bool movementEnabled = true;

  void layout(Rect arena) {
    movementBounds = arena;
    size = Vector2(math.max(34.0, arena.width * 0.025), math.max(118.0, arena.height * 0.25));
    position = Vector2(arena.right - 34 - size.x, arena.center.dy - size.y / 2);
    targetY = position.y;
  }

  void resetToCenter() {
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    _reactionTimer = 0;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!movementEnabled || movementBounds.isEmpty) return;

    _reactionTimer -= dt;
    if (_reactionTimer <= 0) {
      final int score = playerScore();
      final double difficulty = (score / 7).clamp(0.0, 1.0).toDouble();
      _reactionTimer = math.max(0.10, config.botReactionDelay - difficulty * 0.045);
      _chooseTarget(difficulty);
    }

    final double pulseFactor = isPulseActive() ? config.pulseSlowFactor : 1.0;
    final double difficultySpeed = 1.0 + playerScore().clamp(0, 7).toInt() * 0.025;
    final double maxStep = config.botPaddleSpeed * pulseFactor * difficultySpeed * dt;
    final double delta = targetY - position.y;
    position.y += delta.clamp(-maxStep, maxStep).toDouble();
    position.y = position.y.clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  void _chooseTarget(double difficulty) {
    final bool ballThreatening = ball.velocity.x > 0 && ball.position.x > movementBounds.center.dx;
    if (!ballThreatening || !ball.active) {
      targetY = movementBounds.center.dy - size.y / 2;
      return;
    }

    final double travelX = position.x - ball.position.x;
    final double travelTime = travelX / math.max(1.0, ball.velocity.x);
    double predictedY = ball.position.y + ball.velocity.y * travelTime;
    predictedY = _reflectY(predictedY, movementBounds.top, movementBounds.bottom);

    double error = config.botBaseAimError * (1 - difficulty * 0.38);
    if (_random.nextDouble() < config.botErrorChance * (1 - difficulty * 0.28)) {
      error *= 2.2;
    }
    predictedY += (_random.nextDouble() * 2 - 1) * error;
    targetY = (predictedY - size.y / 2).clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  double _reflectY(double y, double top, double bottom) {
    final double height = bottom - top;
    if (height <= 0) return top;
    double local = (y - top) % (height * 2);
    if (local < 0) local += height * 2;
    if (local > height) local = height * 2 - local;
    return top + local;
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final Rect r = Offset.zero & Size(size.x, size.y);
    final RRect body = RRect.fromRectAndRadius(r, Radius.circular(size.x * 0.46));
    canvas.drawRRect(
      body.inflate(7),
      Paint()
        ..color = const Color(0xCCFF3EAD)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13),
    );
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF7E1B72), Color(0xFFFF3FA9), Color(0xFFFFC4EA)],
        ).createShader(r),
    );
    canvas.drawRRect(
      body.deflate(5),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xBFFFFFFF),
    );
    canvas.drawCircle(Offset(size.x * 0.44, size.y * 0.5), size.x * 0.16, Paint()..color = const Color(0xE6FFFFFF));
  }
}
