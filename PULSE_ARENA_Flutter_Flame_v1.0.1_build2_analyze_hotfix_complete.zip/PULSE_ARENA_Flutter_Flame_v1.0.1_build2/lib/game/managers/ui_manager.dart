import 'package:flutter/foundation.dart';

import '../models/game_view_state.dart';

class UIManager {
  UIManager(GameViewState initialState) : state = ValueNotifier<GameViewState>(initialState);

  final ValueNotifier<GameViewState> state;

  void update(GameViewState value) {
    state.value = value;
  }

  void dispose() {
    state.dispose();
  }
}
