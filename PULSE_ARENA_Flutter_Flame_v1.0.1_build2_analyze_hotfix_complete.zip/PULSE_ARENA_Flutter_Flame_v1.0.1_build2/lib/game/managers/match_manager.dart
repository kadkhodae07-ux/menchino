import '../config/game_config.dart';
import '../models/game_view_state.dart';

class MatchManager {
  MatchManager(this.config);

  final GameConfig config;
  MatchPhase phase = MatchPhase.countdown;
  MatchWinner? winner;
  double elapsedSeconds = 0;
  double countdownRemaining = 3;

  bool get isPlaying => phase == MatchPhase.playing;
  bool get isCountdown => phase == MatchPhase.countdown;
  bool get isFinished => phase == MatchPhase.finished;

  void startCountdown() {
    phase = MatchPhase.countdown;
    countdownRemaining = config.countdownDuration;
  }

  bool update(double dt) {
    if (phase == MatchPhase.countdown) {
      countdownRemaining -= dt;
      if (countdownRemaining <= 0) {
        countdownRemaining = 0;
        phase = MatchPhase.playing;
        return true;
      }
    } else if (phase == MatchPhase.playing) {
      elapsedSeconds += dt;
    }
    return false;
  }

  int get countdownLabel => countdownRemaining.ceil().clamp(1, 3).toInt();

  void pause() {
    if (phase == MatchPhase.playing || phase == MatchPhase.countdown) {
      phase = MatchPhase.paused;
    }
  }

  void resume({required bool wasCountdown}) {
    phase = wasCountdown ? MatchPhase.countdown : MatchPhase.playing;
  }

  void finish(MatchWinner matchWinner) {
    winner = matchWinner;
    phase = MatchPhase.finished;
  }

  void reset() {
    phase = MatchPhase.countdown;
    winner = null;
    elapsedSeconds = 0;
    countdownRemaining = config.countdownDuration;
  }
}
