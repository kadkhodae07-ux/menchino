import '../config/game_config.dart';
import '../models/game_view_state.dart';

class PowerUpManager {
  PowerUpManager(this.config)
      : shieldUses = config.shieldUses,
        boostUses = config.boostUses,
        pulseUses = config.pulseUses;

  final GameConfig config;
  int shieldUses;
  int boostUses;
  int pulseUses;

  double shieldRemaining = 0;
  double pulseRemaining = 0;
  bool boostArmed = false;

  bool get shieldActive => shieldRemaining > 0;
  bool get pulseActive => pulseRemaining > 0;

  bool activate(PowerType type) {
    switch (type) {
      case PowerType.shield:
        if (shieldUses <= 0 || shieldActive) return false;
        shieldUses -= 1;
        shieldRemaining = config.shieldDuration;
        return true;
      case PowerType.boost:
        if (boostUses <= 0 || boostArmed) return false;
        boostUses -= 1;
        boostArmed = true;
        return true;
      case PowerType.pulse:
        if (pulseUses <= 0 || pulseActive) return false;
        pulseUses -= 1;
        pulseRemaining = config.pulseDuration;
        return true;
    }
  }

  void consumeBoost() {
    boostArmed = false;
  }

  void update(double dt) {
    if (shieldRemaining > 0) {
      shieldRemaining = (shieldRemaining - dt).clamp(0.0, config.shieldDuration).toDouble();
    }
    if (pulseRemaining > 0) {
      pulseRemaining = (pulseRemaining - dt).clamp(0.0, config.pulseDuration).toDouble();
    }
  }

  void reset() {
    shieldUses = config.shieldUses;
    boostUses = config.boostUses;
    pulseUses = config.pulseUses;
    shieldRemaining = 0;
    pulseRemaining = 0;
    boostArmed = false;
  }
}
