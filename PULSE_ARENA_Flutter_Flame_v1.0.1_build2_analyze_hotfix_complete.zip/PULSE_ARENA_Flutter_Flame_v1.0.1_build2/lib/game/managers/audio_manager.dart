import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/services.dart';

class AudioManager {
  AudioManager._();

  static final AudioManager instance = AudioManager._();

  bool soundEnabled = true;
  bool vibrationEnabled = true;

  static const List<String> _sounds = <String>[
    'button.wav',
    'paddle.wav',
    'wall.wav',
    'score.wav',
    'power.wav',
    'win.wav',
    'lose.wav',
  ];

  Future<void> preload() async {
    try {
      await FlameAudio.audioCache.loadAll(_sounds);
    } catch (_) {
      // Audio failure must never block the game.
    }
  }

  Future<void> playButton() => _play('button.wav', volume: 0.42);
  Future<void> playPaddle() => _play('paddle.wav', volume: 0.45);
  Future<void> playWall() => _play('wall.wav', volume: 0.30);
  Future<void> playScore() => _play('score.wav', volume: 0.60);
  Future<void> playPower() => _play('power.wav', volume: 0.55);
  Future<void> playWin() => _play('win.wav', volume: 0.65);
  Future<void> playLose() => _play('lose.wav', volume: 0.65);

  Future<void> _play(String fileName, {double volume = 1}) async {
    if (!soundEnabled) return;
    try {
      await FlameAudio.play(fileName, volume: volume);
    } catch (_) {
      // Keep gameplay functional even when a device audio backend fails.
    }
  }

  Future<void> lightImpact() async {
    if (vibrationEnabled) {
      await HapticFeedback.lightImpact();
    }
  }

  Future<void> importantImpact() async {
    if (vibrationEnabled) {
      await HapticFeedback.mediumImpact();
    }
  }
}
