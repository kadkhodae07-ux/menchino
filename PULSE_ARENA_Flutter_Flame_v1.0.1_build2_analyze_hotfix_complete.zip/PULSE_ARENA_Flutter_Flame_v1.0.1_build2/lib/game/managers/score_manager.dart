import '../config/game_config.dart';
import '../models/game_view_state.dart';

class ScoreManager {
  ScoreManager(this.config);

  final GameConfig config;
  int playerScore = 0;
  int botScore = 0;

  MatchWinner? addPlayerPoint() {
    playerScore += 1;
    return playerScore >= config.targetScore ? MatchWinner.player : null;
  }

  MatchWinner? addBotPoint() {
    botScore += 1;
    return botScore >= config.targetScore ? MatchWinner.bot : null;
  }

  void reset() {
    playerScore = 0;
    botScore = 0;
  }
}
