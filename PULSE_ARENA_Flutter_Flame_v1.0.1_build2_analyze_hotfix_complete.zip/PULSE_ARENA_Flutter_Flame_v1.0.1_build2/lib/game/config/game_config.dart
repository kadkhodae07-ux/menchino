class GameConfig {
  const GameConfig({
    this.targetScore = 7,
    this.ballBaseSpeed = 560,
    this.ballMaximumSpeed = 980,
    this.ballSpeedIncreasePerSecond = 4.5,
    this.playerPaddleSpeed = 1450,
    this.botPaddleSpeed = 660,
    this.botReactionDelay = 0.18,
    this.botErrorChance = 0.14,
    this.botBaseAimError = 58,
    this.countdownDuration = 3,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.52,
    this.boostMultiplier = 1.28,
    this.shieldUses = 2,
    this.boostUses = 1,
    this.pulseUses = 2,
  });

  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double playerPaddleSpeed;
  final double botPaddleSpeed;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
