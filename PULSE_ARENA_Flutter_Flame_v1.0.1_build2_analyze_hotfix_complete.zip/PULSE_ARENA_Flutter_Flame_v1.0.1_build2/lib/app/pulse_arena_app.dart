import 'package:flutter/material.dart';

import '../screens/start_screen.dart';

class PulseArenaApp extends StatelessWidget {
  const PulseArenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PULSE ARENA',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050713),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF39D9FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const StartScreen(),
    );
  }
}
