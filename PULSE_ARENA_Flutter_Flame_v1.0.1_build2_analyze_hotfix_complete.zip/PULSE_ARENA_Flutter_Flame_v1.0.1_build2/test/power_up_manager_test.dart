import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';
import 'package:pulse_arena/game/managers/power_up_manager.dart';
import 'package:pulse_arena/game/models/game_view_state.dart';

void main() {
  test('shield usage decrements and expires', () {
    final PowerUpManager powers = PowerUpManager(const GameConfig(shieldDuration: 2));
    expect(powers.activate(PowerType.shield), isTrue);
    expect(powers.shieldUses, 1);
    expect(powers.shieldActive, isTrue);
    powers.update(2.1);
    expect(powers.shieldActive, isFalse);
  });

  test('boost remains armed until consumed', () {
    final PowerUpManager powers = PowerUpManager(const GameConfig());
    expect(powers.activate(PowerType.boost), isTrue);
    expect(powers.boostArmed, isTrue);
    powers.consumeBoost();
    expect(powers.boostArmed, isFalse);
  });
}
