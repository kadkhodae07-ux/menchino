import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';
import 'package:pulse_arena/game/managers/score_manager.dart';
import 'package:pulse_arena/game/models/game_view_state.dart';

void main() {
  test('player wins exactly at target score', () {
    final ScoreManager score = ScoreManager(const GameConfig(targetScore: 3));
    expect(score.addPlayerPoint(), isNull);
    expect(score.addPlayerPoint(), isNull);
    expect(score.addPlayerPoint(), MatchWinner.player);
    expect(score.playerScore, 3);
  });

  test('reset clears both scores', () {
    final ScoreManager score = ScoreManager(const GameConfig());
    score.addPlayerPoint();
    score.addBotPoint();
    score.reset();
    expect(score.playerScore, 0);
    expect(score.botScore, 0);
  });
}
