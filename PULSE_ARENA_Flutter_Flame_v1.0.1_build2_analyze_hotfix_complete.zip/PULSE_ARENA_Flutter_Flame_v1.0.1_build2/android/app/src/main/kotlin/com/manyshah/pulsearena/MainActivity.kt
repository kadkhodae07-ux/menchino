package com.manyshah.pulsearena

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
