# ZARBU v1.5.0+8 — Pre-delivery Verification

## نتیجه بررسی محلی قابل انجام در محیط فعلی

- Release Gate: **PASS**
- Workflow V9 YAML parse: **PASS**
- نسخه Workflow داخل سورس و فایل مستقل: **Byte-identical / PASS**
- Python syntax (`prepare_android.py`, `release_gate.py`): **PASS**
- شبیه‌سازی `prepare_android.py` روی Flutter Android Kotlin template: **PASS**
- Package target: `mk.kadkhodai.zarbu`
- ۱۰ Avatar WebP با Alpha: **PASS via Release Gate**
- Keystore نسبت به v1.4.0+7: **Byte-identical / PASS**
- `key.properties` نسبت به v1.4.0+7: **Byte-identical / PASS**
- Engine / GameScreen / Balance / Data / League / Rank / AvatarBadge نسبت به v1.4.0+7: **Byte-identical / Regression lock PASS**
- Runtime cleanup (Chat/Fake payment/Debug/TODO/FIXME/Placeholder/«به‌زودی»): **PASS**
- RSA hardcoded heuristic: **PASS**
- Workflow variants (Offline/Bazaar/Myket): **PASS**
- Store ledger targeted tests برای هر دو mode بازار/مایکت: **در Workflow V9 اجباری شده**
- Canonical store grant: **Guard + test اضافه شده**؛ UI نمی‌تواند مقدار سکه/جم SKU را جعل کند.

## کنترل‌های اجباری GitHub Actions V7

1. Release Gate
2. Java 21 setup
3. Flutter setup
4. `flutter pub get`
5. Android identity/signing/store prerequisites
6. `flutter analyze`
7. کل `flutter test`
8. Store Ledger test با `ZARBU_STORE=bazaar`
9. Store Ledger test با `ZARBU_STORE=myket`
10. Offline Release APK
11. Bazaar Release APK در صورت وجود Secret واقعی
12. Myket Release APK در صورت وجود Secret واقعی
13. Package-ID inspection برای همه APKها
14. Signature verification برای همه APKها
15. APK size gate <= 90 MiB
16. SHA-256 output
17. Diagnostics artifact در صورت Failure

## محدودیت واقعی محیط فعلی

Flutter SDK در محیط تحویل محلی نصب نیست؛ بنابراین `flutter analyze`، `flutter test` و `flutter build apk` در این محیط به‌صورت صوری PASS اعلام نشده‌اند. Workflow V9 آن‌ها را قبل از تحویل APK اجباری می‌کند.

## مواردی که فقط پس از تولید APK قابل تایید هستند

- نصب/اجرای واقعی روی Android
- Performance/Jank/Crash روی دستگاه
- Lifecycle و Orientation روی OEM واقعی
- Update install و Save migration روی APK قبلی
- Checkout/Consume/Re-purchase واقعی Bazaar/Myket با حساب تست

این تفکیک عمدی است: ساختار سورس و CI بررسی شده‌اند، اما تستی که به Flutter SDK، APK، مارکت یا دستگاه نیاز دارد جعل نشده است.

- Store Isolation: **PASS** — هیچ Variantی هم‌زمان Poolakey و Myket IAP را لینک نمی‌کند.
