import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'rewards_screen.dart';

class MissionsScreen extends StatelessWidget {
  final bool embedded;
  final VoidCallback? onBack;

  const MissionsScreen({super.key, this.embedded = false, this.onBack});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final completed = missions.where((mission) {
      final progress = state.missionProgress[mission.key] ?? 0;
      return progress >= mission.target;
    }).length;

    final content = SafeArea(
      top: true,
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GamePageHeader(
              title: 'ماموریت‌ها',
              subtitle: 'پیشرفت واقعی از مسابقه‌ها و فعالیت داخل بازی',
              onBack: onBack,
              actions: [
                Chip3D(text: '${state.coins}'),
                const SizedBox(width: 5),
                Chip3D(text: '${state.gems}', gem: true),
              ],
            ),
            const SizedBox(height: 14),
            NeonPanel(
              borderColor: theme.gold,
              child: Row(
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      color: theme.gold.withOpacity(.10),
                      border: Border.all(color: theme.gold.withOpacity(.24)),
                    ),
                    child: Center(child: AppIcons.icon('mission', size: 28, color: theme.gold)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('$completed از ${missions.length} ماموریت کامل', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 16)),
                        const SizedBox(height: 7),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(99),
                          child: LinearProgressIndicator(
                            minHeight: 9,
                            value: missions.isEmpty ? 0.0 : completed / missions.length,
                            color: theme.gold,
                            backgroundColor: theme.gold.withOpacity(.12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  NeonButton(
                    label: 'صندوق‌ها',
                    icon: 'chest',
                    small: true,
                    color: theme.gold,
                    onTap: () => Navigator.push(context, zarbuRoute(const RewardsScreen())),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            for (final mission in missions) ...[
              _MissionCard(mission: mission),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
    if (embedded) return content;
    return Scaffold(backgroundColor: theme.bg, body: content);
  }
}

class _MissionCard extends StatelessWidget {
  final Mission mission;

  const _MissionCard({required this.mission});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final progress = state.missionProgress[mission.key] ?? 0;
    final clamped = min(progress, mission.target);
    final done = progress >= mission.target;
    final claimed = state.claimed[mission.id] == true;
    final ratio = mission.target <= 0 ? 0.0 : (clamped / mission.target).clamp(0.0, 1.0).toDouble();

    return NeonPanel(
      borderColor: claimed ? theme.accent : done ? theme.gold : theme.primary,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: (done ? theme.gold : theme.primary).withOpacity(.09),
                  border: Border.all(color: (done ? theme.gold : theme.primary).withOpacity(.23)),
                ),
                child: Center(child: AppIcons.icon(claimed ? 'check' : 'mission', size: 24, color: claimed ? theme.accent : done ? theme.gold : theme.primary)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      mission.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 15, height: 1.4),
                    ),
                    const SizedBox(height: 5),
                    Text(_rewardText(mission), style: TextStyle(color: theme.dim, fontSize: 12, height: 1.5)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (claimed)
                StatBadge('دریافت شد', color: theme.accent)
              else
                NeonButton(
                  label: done ? 'دریافت' : '$clamped/${mission.target}',
                  icon: done ? 'gift' : 'lock',
                  small: true,
                  color: done ? theme.gold : theme.dim,
                  onTap: done ? () => _claim(context, state, mission) : null,
                ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              minHeight: 10,
              value: ratio,
              color: claimed ? theme.accent : done ? theme.gold : theme.primary,
              backgroundColor: theme.primary.withOpacity(.10),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _claim(BuildContext context, AppState state, Mission mission) async {
    final success = await state.claimMission(mission);
    if (context.mounted && success) showNeonMessage(context, 'جایزه ماموریت دریافت شد.');
  }

  String _rewardText(Mission mission) {
    final parts = <String>[];
    if (mission.reward['coins'] is int) parts.add('+${mission.reward['coins']} سکه');
    if (mission.reward['gems'] is int) parts.add('+${mission.reward['gems']} الماس');
    if (mission.reward['chest'] is String) {
      final tier = mission.reward['chest'] == 'bronze' ? 'برنزی' : mission.reward['chest'] == 'silver' ? 'نقره‌ای' : 'طلایی';
      parts.add('صندوق $tier');
    }
    return parts.join('  •  ');
  }
}
