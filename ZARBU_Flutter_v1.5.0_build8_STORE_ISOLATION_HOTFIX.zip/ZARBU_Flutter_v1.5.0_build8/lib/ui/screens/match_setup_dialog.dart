import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class MatchSetupDialog extends StatefulWidget {
  const MatchSetupDialog({super.key});

  @override
  State<MatchSetupDialog> createState() => _MatchSetupDialogState();
}

class _MatchSetupDialogState extends State<MatchSetupDialog> {
  late String mode;
  late String difficulty;
  late String orientation;
  late int entry;

  @override
  void initState() {
    super.initState();
    final setup = context.read<AppState>().matchSetup;
    mode = setup['mode'] as String? ?? 'quick';
    difficulty = setup['difficulty'] as String? ?? 'medium';
    orientation = setup['orientation'] as String? ?? 'portrait';
    entry = setup['entry'] as int? ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final prize = (entry * 2 * .75).floor();

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 470),
        child: NeonPanel(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    AppIcons.icon('play', size: 26, color: theme.accent),
                    const SizedBox(width: 10),
                    Expanded(child: Text('تنظیم مسابقه', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 21))),
                  ],
                ),
                const SizedBox(height: 16),
                _label(theme, 'حالت بازی'),
                const SizedBox(height: 8),
                _OptionWrap(
                  value: mode,
                  options: const {
                    'quick': 'سریع',
                    'challenge': 'چالش',
                    'practice': 'تمرین',
                    'local': 'دوستانه',
                  },
                  color: theme.primary,
                  onChanged: (value) => setState(() {
                    mode = value;
                    if (mode == 'practice' || mode == 'local') entry = 0;
                  }),
                ),
                const SizedBox(height: 15),
                _label(theme, 'سختی حریف'),
                const SizedBox(height: 8),
                _OptionWrap(
                  value: difficulty,
                  options: const {'easy': 'آسان', 'medium': 'متوسط', 'hard': 'سخت', 'pro': 'حرفه‌ای'},
                  color: theme.secondary,
                  enabled: mode != 'local',
                  onChanged: (value) => setState(() => difficulty = value),
                ),
                const SizedBox(height: 15),
                _label(theme, 'جهت صفحه'),
                const SizedBox(height: 8),
                _OptionWrap(
                  value: orientation,
                  options: const {'portrait': 'عمودی', 'landscape': 'افقی'},
                  color: theme.accent,
                  onChanged: (value) => setState(() => orientation = value),
                ),
                const SizedBox(height: 15),
                _label(theme, 'ورودی مسابقه'),
                const SizedBox(height: 8),
                _EntryRow(
                  value: mode == 'practice' || mode == 'local' ? 0 : entry,
                  enabled: mode != 'practice' && mode != 'local',
                  color: theme.gold,
                  onChanged: (value) => setState(() => entry = value),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: theme.bg.withOpacity(.28),
                    border: Border.all(color: theme.dim.withOpacity(.10)),
                  ),
                  child: Row(
                    children: [
                      AppIcons.icon('coin', size: 18, color: theme.gold),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          entry > 0 && mode != 'practice' && mode != 'local'
                              ? 'جایزه برنده از ورودی: $prize سکه'
                              : 'ورودی آزاد؛ بدون ریسک سکه.',
                          style: TextStyle(color: theme.dim, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: NeonButton(label: 'انصراف', small: true, expand: true, onTap: () => Navigator.pop(context))),
                    const SizedBox(width: 10),
                    Expanded(
                      child: NeonButton(
                        label: 'شروع',
                        icon: 'play',
                        small: true,
                        expand: true,
                        color: theme.accent,
                        onTap: () {
                          final finalEntry = mode == 'practice' || mode == 'local' ? 0 : entry;
                          if (finalEntry > state.coins) {
                            showNeonMessage(context, 'سکه کافی برای ورودی مسابقه نداری.');
                            return;
                          }
                          Navigator.pop(context, {
                            'mode': mode,
                            'difficulty': mode == 'challenge' ? 'hard' : difficulty,
                            'orientation': orientation,
                            'entry': finalEntry,
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(dynamic theme, String text) => Text(text, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 13));
}

class _OptionWrap extends StatelessWidget {
  final String value;
  final Map<String, String> options;
  final Color color;
  final bool enabled;
  final ValueChanged<String> onChanged;

  const _OptionWrap({required this.value, required this.options, required this.color, this.enabled = true, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: options.entries.map((entry) {
        final active = value == entry.key;
        return GestureDetector(
          onTap: enabled ? () => onChanged(entry.key) : null,
          child: AnimatedOpacity(
            duration: const Duration(milliseconds: 120),
            opacity: enabled ? 1 : .42,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 140),
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: active ? color.withOpacity(.14) : theme.bg.withOpacity(.26),
                border: Border.all(color: active ? color.withOpacity(.48) : theme.dim.withOpacity(.10)),
              ),
              child: Text(entry.value, style: TextStyle(color: active ? theme.text : theme.dim, fontWeight: FontWeight.w900, fontSize: 12)),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _EntryRow extends StatelessWidget {
  final int value;
  final bool enabled;
  final Color color;
  final ValueChanged<int> onChanged;

  const _EntryRow({required this.value, required this.enabled, required this.color, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return Row(
      children: [
        for (final item in const [0, 20, 50, 100]) ...[
          Expanded(
            child: GestureDetector(
              onTap: enabled ? () => onChanged(item) : null,
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 120),
                opacity: enabled || item == 0 ? 1 : .40,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 140),
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: value == item ? color.withOpacity(.13) : theme.bg.withOpacity(.25),
                    border: Border.all(color: value == item ? color.withOpacity(.45) : theme.dim.withOpacity(.09)),
                  ),
                  child: Text(item == 0 ? 'آزاد' : '$item', textAlign: TextAlign.center, style: TextStyle(color: value == item ? theme.text : theme.dim, fontWeight: FontWeight.w900, fontSize: 11)),
                ),
              ),
            ),
          ),
          if (item != 100) const SizedBox(width: 7),
        ],
      ],
    );
  }
}
