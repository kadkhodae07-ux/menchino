import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'game_screen.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  final TextEditingController _controller = TextEditingController();
  bool _launchingMatch = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        top: true,
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: GamePageHeader(title: 'بازیکنان محلی', subtitle: 'بازی دونفره روی همین دستگاه'),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
              child: NeonPanel(
                borderColor: theme.accent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        AppIcons.icon('friends', size: 26, color: theme.accent),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('بازی دونفره روی همین دستگاه', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                              const SizedBox(height: 3),
                              Text('برای بازی دونفره نام بازیکن دوم را ذخیره کن.', style: TextStyle(color: theme.dim, fontSize: 11, height: 1.5)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _controller,
                            style: TextStyle(color: theme.text),
                            textInputAction: TextInputAction.done,
                            decoration: InputDecoration(
                              hintText: 'نام بازیکن دوم...',
                              hintStyle: TextStyle(color: theme.dim),
                              filled: true,
                              fillColor: theme.bg.withOpacity(.28),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                            ),
                            onSubmitted: (_) => _add(state),
                          ),
                        ),
                        const SizedBox(width: 8),
                        NeonButton(label: 'افزودن', icon: 'check', small: true, color: theme.accent, onTap: () => _add(state)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: state.friends.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(28),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AppIcons.icon('friends', size: 46, color: theme.dim),
                            const SizedBox(height: 12),
                            Text('بازیکنی ذخیره نشده', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 17)),
                            const SizedBox(height: 5),
                            Text('یک نام اضافه کن تا برای مسابقه محلی روی همین دستگاه در دسترس باشد.', textAlign: TextAlign.center, style: TextStyle(color: theme.dim, height: 1.6, fontSize: 12)),
                          ],
                        ),
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 2, 16, 22),
                      itemCount: state.friends.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, index) {
                        final friend = state.friends[index];
                        return NeonPanel(
                          child: Row(
                            children: [
                              Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: theme.secondary.withOpacity(.10),
                                  border: Border.all(color: theme.secondary.withOpacity(.22)),
                                ),
                                child: Center(child: AppIcons.icon('profile', size: 21, color: theme.secondary)),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('${friend['name']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                                    Text('بازیکن ذخیره‌شده روی دستگاه', style: TextStyle(color: theme.dim, fontSize: 11)),
                                  ],
                                ),
                              ),
                              NeonButton(label: 'بازی', icon: 'play', small: true, color: theme.accent, onTap: _launchingMatch ? null : () => _play(state, friend)),
                              const SizedBox(width: 7),
                              IconButton(
                                tooltip: 'حذف بازیکن',
                                onPressed: () => state.removeFriend('${friend['id']}'),
                                icon: AppIcons.icon('close', size: 18, color: theme.danger),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _add(AppState state) async {
    final name = _controller.text.trim();
    if (name.length < 2) {
      showNeonMessage(context, 'نام بازیکن خیلی کوتاه است.');
      return;
    }
    final added = await state.addFriend(name);
    if (!mounted) return;
    if (!added) {
      showNeonMessage(context, 'این نام قبلاً ذخیره شده یا معتبر نیست.');
      return;
    }
    _controller.clear();
    showNeonMessage(context, '$name اضافه شد.');
  }

  Future<void> _play(AppState state, Map<String, dynamic> friend) async {
    if (_launchingMatch || !mounted) return;
    setState(() => _launchingMatch = true);
    try {
      await state.updateMatchSetup({'mode': 'local', 'entry': 0});
      if (!mounted) return;
      await Navigator.push(context, zarbuRoute(GameScreen.local('${friend['name']}')));
    } finally {
      if (mounted) setState(() => _launchingMatch = false);
    }
  }
}
