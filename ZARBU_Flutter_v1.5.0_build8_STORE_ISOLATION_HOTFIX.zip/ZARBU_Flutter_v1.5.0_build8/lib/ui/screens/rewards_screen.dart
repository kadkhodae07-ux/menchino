import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class RewardsScreen extends StatefulWidget {
  const RewardsScreen({super.key});

  @override
  State<RewardsScreen> createState() => _RewardsScreenState();
}

class _RewardsScreenState extends State<RewardsScreen> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        top: true,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const GamePageHeader(title: 'صندوق‌ها و جوایز', subtitle: 'پاداش مأموریت‌ها و تورنمنت‌ها'),
              const SizedBox(height: 14),
              NeonPanel(
                borderColor: theme.gold,
                child: Row(
                  children: [
                    AppIcons.icon('chest', size: 34, color: theme.gold),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('صندوق‌های مسابقه', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 17)),
                          const SizedBox(height: 4),
                          Text('صندوق‌ها را از ماموریت‌ها و تورنمنت‌ها بگیر و اینجا باز کن.', style: TextStyle(color: theme.dim, height: 1.6, fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              for (final tier in const ['bronze', 'silver', 'gold']) ...[
                _ChestCard(
                  tier: tier,
                  count: state.chests[tier] ?? 0,
                  busy: _busy,
                  onOpen: () => _openChest(state, tier),
                ),
                const SizedBox(height: 12),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openChest(AppState state, String tier) async {
    if (_busy || (state.chests[tier] ?? 0) <= 0) return;
    setState(() => _busy = true);
    final result = await state.openChest(tier);
    if (!mounted) return;
    setState(() => _busy = false);
    if (result == null) return;
    final rewards = result.labels();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 390),
          child: NeonPanel(
            borderColor: _chestColor(tier),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppIcons.icon('chest', size: 46, color: _chestColor(tier)),
                const SizedBox(height: 10),
                Text('صندوق باز شد', style: TextStyle(color: state.theme.text, fontWeight: FontWeight.w900, fontSize: 22)),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.center,
                  children: rewards.map((reward) => StatBadge(reward, color: _chestColor(tier))).toList(),
                ),
                const SizedBox(height: 16),
                NeonButton(label: 'بستن', small: true, expand: true, onTap: () => Navigator.pop(dialogContext)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _chestColor(String tier) => switch (tier) {
        'silver' => const Color(0xFFC7D2E5),
        'gold' => const Color(0xFFFFD66A),
        _ => const Color(0xFFC98055),
      };
}

class _ChestCard extends StatelessWidget {
  final String tier;
  final int count;
  final bool busy;
  final VoidCallback onOpen;

  const _ChestCard({
    required this.tier,
    required this.count,
    required this.busy,
    required this.onOpen,
  });

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final color = switch (tier) {
      'silver' => const Color(0xFFC7D2E5),
      'gold' => const Color(0xFFFFD66A),
      _ => const Color(0xFFC98055),
    };
    final name = switch (tier) {
      'silver' => 'صندوق نقره‌ای',
      'gold' => 'صندوق طلایی',
      _ => 'صندوق برنزی',
    };
    final hint = switch (tier) {
      'silver' => 'سکه و الماس بیشتر + شانس آیتم حماسی',
      'gold' => 'بالاترین پاداش + شانس آیتم افسانه‌ای',
      _ => 'پاداش پایه + شانس آیتم کمیاب',
    };

    return NeonPanel(
      borderColor: color,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(21),
              color: color.withOpacity(.09),
              border: Border.all(color: color.withOpacity(.24)),
              boxShadow: [BoxShadow(color: color.withOpacity(.12), blurRadius: 18)],
            ),
            child: Center(child: AppIcons.icon('chest', size: 32, color: color)),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 4),
                Text(hint, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim, height: 1.5, fontSize: 12)),
                const SizedBox(height: 7),
                StatBadge('موجودی: $count', color: color),
              ],
            ),
          ),
          const SizedBox(width: 10),
          NeonButton(
            label: 'باز کردن',
            icon: 'gift',
            small: true,
            color: color,
            onTap: !busy && count > 0 ? onOpen : null,
          ),
        ],
      ),
    );
  }
}
