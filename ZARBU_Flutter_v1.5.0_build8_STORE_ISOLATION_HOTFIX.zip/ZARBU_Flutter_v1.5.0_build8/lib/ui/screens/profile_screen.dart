import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/state/app_state.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';
import 'shop_screen.dart';

class ProfileScreen extends StatefulWidget {
  final bool embedded;
  final VoidCallback? onBack;

  const ProfileScreen({super.key, this.embedded = false, this.onBack});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final TextEditingController _nameController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: context.read<AppState>().name);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final matches = state.stats['matches'] ?? 0;
    final wins = state.stats['wins'] ?? 0;
    final winRate = matches > 0 ? (wins * 100 / matches).round() : 0;

    final content = SafeArea(
      top: true,
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 22),
        child: Column(
          children: [
            GamePageHeader(
              title: 'پروفایل',
              subtitle: 'آمار، تجهیزات و هویت بازیکن',
              onBack: widget.onBack,
              actions: [
                Chip3D(text: '${state.coins}'),
                const SizedBox(width: 5),
                Chip3D(text: '${state.gems}', gem: true),
              ],
            ),
            const SizedBox(height: 14),
            NeonPanel(
              child: Column(
                children: [
                  Row(
                    children: [
                      AvatarBadge(index: state.avatar),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: _nameController,
                          maxLength: 16,
                          style: TextStyle(color: theme.text, fontWeight: FontWeight.w800),
                          decoration: InputDecoration(
                            counterText: '',
                            hintText: 'نام بازیکن',
                            hintStyle: TextStyle(color: theme.dim),
                            filled: true,
                            fillColor: theme.primary.withOpacity(.06),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: theme.primary.withOpacity(.28))),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: theme.primary)),
                          ),
                          onSubmitted: (_) => _saveName(state),
                        ),
                      ),
                      const SizedBox(width: 8),
                      NeonButton(label: 'ذخیره', small: true, color: theme.accent, onTap: () => _saveName(state)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: List.generate(avatars.length, (index) {
                      final ownedAvatar = state.ownsAvatar(index);
                      return AvatarBadge(
                        index: index,
                        selected: state.avatar == index,
                        locked: !ownedAvatar,
                        onTap: () async {
                          if (ownedAvatar) {
                            await state.setAvatar(index);
                            return;
                          }
                          if (!mounted) return;
                          showNeonMessage(context, 'این آواتار پولی است. برای خرید به فروشگاه برو.');
                        },
                      );
                    }),
                  ),
                  const SizedBox(height: 12),
                  Text('سطح ${state.level} • ${state.xp}/${state.xpToNext} XP', style: TextStyle(color: theme.dim)),
                  const SizedBox(height: 7),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      minHeight: 9,
                      value: (state.xp / state.xpToNext).clamp(0.0, 1.0).toDouble(),
                      color: theme.primary,
                      backgroundColor: theme.primary.withOpacity(.14),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            NeonPanel(
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  StatBadge('مسابقه: $matches'),
                  StatBadge('برد: $wins'),
                  StatBadge('باخت: ${state.stats['losses'] ?? 0}'),
                  StatBadge('درصد برد: $winRate٪'),
                  StatBadge('بهترین رالی: ${state.stats['bestRally'] ?? 0}'),
                  StatBadge('پاورآپ‌ها: ${state.stats['powerCollected'] ?? 0}'),
                  StatBadge('لیگ ضربو: ${state.leaguePoints} LP'),
                  StatBadge('فصل: ${state.season}'),
                ],
              ),
            ),
            const SizedBox(height: 12),
            NeonPanel(
              child: Column(
                children: [
                  _equipmentRow(theme, 'راکت', state.racket.name),
                  _equipmentRow(theme, 'توپ', state.ball.name),
                  _equipmentRow(theme, 'زمین', state.arena.name, last: true),
                  const SizedBox(height: 12),
                  NeonButton(
                    label: 'مشاهده تجهیزات فروشگاه',
                    icon: 'shop',
                    color: theme.secondary,
                    expand: true,
                    onTap: () => Navigator.push(context, zarbuRoute(const ShopScreen())),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
    if (widget.embedded) return content;
    return Scaffold(backgroundColor: theme.bg, body: content);
  }

  Future<void> _saveName(AppState state) async {
    final clean = _nameController.text.trim().replaceAll(RegExp(r'[<>{}]'), '');
    if (clean.length < 2 || clean.length > 16) {
      showNeonMessage(context, 'نام باید بین ۲ تا ۱۶ کاراکتر باشد.');
      return;
    }
    await state.updateName(clean);
    if (mounted) showNeonMessage(context, 'نام ذخیره شد.');
  }

  Widget _equipmentRow(dynamic theme, String label, String value, {bool last = false}) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(border: last ? null : Border(bottom: BorderSide(color: theme.dim.withOpacity(.12)))),
        child: Row(children: [Text(label, style: TextStyle(color: theme.dim)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.left, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)))]),
      );
}
