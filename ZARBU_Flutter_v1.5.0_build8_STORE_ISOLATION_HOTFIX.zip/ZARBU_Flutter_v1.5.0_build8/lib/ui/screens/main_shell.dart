import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'lobby_screen.dart';
import 'missions_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'shop_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 2;
  bool _exitDialogOpen = false;

  void _selectTab(int index) {
    if (index < 0 || index > 4) return;
    setState(() => _index = index);
  }

  void _backToHome() => _selectTab(2);

  Future<void> _handleBack() async {
    if (_index != 2) {
      _backToHome();
      return;
    }
    if (_exitDialogOpen || !mounted) return;
    _exitDialogOpen = true;
    final exit = await showNeonConfirm(
      context,
      title: 'خروج از ضربو',
      message: 'می‌خوای از بازی خارج بشی؟',
      confirmLabel: 'خروج',
      cancelLabel: 'ماندن',
      danger: true,
    );
    _exitDialogOpen = false;
    if (exit) {
      await SystemNavigator.pop();
    }
  }

  static const _tabs = [
    ('shop', 'فروشگاه'),
    ('mission', 'ماموریت'),
    ('home', 'خانه'),
    ('rank', 'رتبه‌بندی'),
    ('profile', 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        if (!didPop) _handleBack();
      },
      child: Scaffold(
        backgroundColor: theme.bg,
        body: IndexedStack(
          index: _index,
          children: [
            ShopScreen(embedded: true, onBack: _backToHome),
            MissionsScreen(embedded: true, onBack: _backToHome),
            LobbyScreen(onTabSelected: _selectTab),
            RankScreen(embedded: true, onBack: _backToHome),
            ProfileScreen(embedded: true, onBack: _backToHome),
          ],
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          minimum: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: NeonPanel(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
            child: SizedBox(
              height: 60,
              child: Row(
                children: List.generate(_tabs.length, (index) {
                  final active = index == _index;
                  final home = index == 2;
                  final color = active ? theme.primary : theme.dim;
                  return Expanded(
                    child: _BottomNavItem(
                      icon: _tabs[index].$1,
                      label: _tabs[index].$2,
                      active: active,
                      home: home,
                      color: color,
                      onTap: () => _selectTab(index),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}


class _BottomNavItem extends StatefulWidget {
  final String icon;
  final String label;
  final bool active;
  final bool home;
  final Color color;
  final VoidCallback onTap;

  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.active,
    required this.home,
    required this.color,
    required this.onTap,
  });

  @override
  State<_BottomNavItem> createState() => _BottomNavItemState();
}

class _BottomNavItemState extends State<_BottomNavItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    return Semantics(
      button: true,
      selected: widget.active,
      label: widget.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _pressed = true),
        onTapCancel: () => setState(() => _pressed = false),
        onTapUp: (_) {
          setState(() => _pressed = false);
          state.audio.play('tap');
          if (state.haptics) HapticFeedback.selectionClick();
          widget.onTap();
        },
        child: AnimatedScale(
          duration: const Duration(milliseconds: 90),
          scale: _pressed ? .94 : 1,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            transform: Matrix4.translationValues(0, _pressed ? 3 : (widget.home && widget.active ? -2 : 0), 0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: widget.home ? 38 : 34,
                  height: widget.home ? 38 : 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.active ? theme.primary.withOpacity(.13) : Colors.transparent,
                    border: Border.all(color: widget.active ? theme.primary.withOpacity(.30) : Colors.transparent),
                    boxShadow: widget.active && !_pressed
                        ? [BoxShadow(color: theme.primary.withOpacity(.12), blurRadius: 12, offset: const Offset(0, 5))]
                        : null,
                  ),
                  child: Center(child: AppIcons.icon(widget.icon, size: widget.home ? 20 : 18, color: widget.color)),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: widget.active ? theme.text : theme.dim.withOpacity(.68),
                    fontSize: 8.5,
                    fontWeight: widget.active ? FontWeight.w900 : FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
