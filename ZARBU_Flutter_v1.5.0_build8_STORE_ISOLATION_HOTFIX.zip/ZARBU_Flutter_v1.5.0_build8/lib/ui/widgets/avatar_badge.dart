import 'package:flutter/material.dart';

import '../../core/data.dart';

class AvatarBadge extends StatelessWidget {
  final int index;
  final double size;
  final bool selected;
  final bool locked;
  final VoidCallback? onTap;

  const AvatarBadge({
    super.key,
    required this.index,
    this.size = 52,
    this.selected = false,
    this.locked = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final spec = avatars[index.clamp(0, avatars.length - 1).toInt()];
    final badge = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: spec.background.withOpacity(.88),
        border: Border.all(
          color: selected ? Colors.white.withOpacity(.94) : Colors.white.withOpacity(.16),
          width: selected ? 2 : 1,
        ),
        boxShadow: selected ? [BoxShadow(color: spec.accent.withOpacity(.24), blurRadius: 16)] : null,
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Padding(
            padding: EdgeInsets.all(size * .05),
            child: ClipOval(
              child: Container(
                color: spec.background.withOpacity(.32),
                child: Image.asset(
                  spec.assetPath,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Icon(
                    Icons.person,
                    color: Colors.white.withOpacity(.9),
                    size: size * .52,
                  ),
                ),
              ),
            ),
          ),
          if (locked)
            Positioned.fill(
              child: Container(color: Colors.black.withOpacity(.38)),
            ),
          if (locked)
            Align(
              alignment: Alignment.topRight,
              child: Container(
                margin: EdgeInsets.all(size * .08),
                width: size * .28,
                height: size * .28,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.72),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(.2)),
                ),
                child: Icon(Icons.lock_rounded, size: size * .16, color: Colors.white.withOpacity(.94)),
              ),
            ),
        ],
      ),
    );
    if (onTap == null) return badge;
    return GestureDetector(onTap: onTap, child: badge);
  }
}
