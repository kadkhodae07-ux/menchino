import 'dart:math';

import 'data.dart';

class MatchSummary {
  final String token;
  final String mode;
  final String difficulty;
  final bool won;
  final int bottomScore;
  final int topScore;
  final int longestRally;
  final int playerGold;
  final double coinBonus;
  final int entry;
  final int tournamentRound;

  const MatchSummary({
    required this.token,
    required this.mode,
    required this.difficulty,
    required this.won,
    required this.bottomScore,
    required this.topScore,
    required this.longestRally,
    required this.playerGold,
    required this.coinBonus,
    required this.entry,
    this.tournamentRound = 0,
  });

  bool get isPersistent => const {'quick', 'challenge', 'tournament'}.contains(mode);
}

enum MatchSettlementKind {
  local,
  practice,
  standard,
  tournamentAdvance,
  tournamentChampion,
  tournamentEliminated,
  duplicate,
}

class MatchSettlement {
  final MatchSettlementKind kind;
  final int xp;
  final int coins;
  final int baseCoins;
  final int entryPrize;
  final int leagueDelta;
  final String? chestTier;
  final int? nextRound;

  const MatchSettlement({
    required this.kind,
    this.xp = 0,
    this.coins = 0,
    this.baseCoins = 0,
    this.entryPrize = 0,
    this.leagueDelta = 0,
    this.chestTier,
    this.nextRound,
  });

  static const duplicate = MatchSettlement(kind: MatchSettlementKind.duplicate);
  static const local = MatchSettlement(kind: MatchSettlementKind.local);
  static const practice = MatchSettlement(kind: MatchSettlementKind.practice);
}

class EconomyBalance {
  static const int startingCoins = 300;
  static const int startingGems = 5;
  static const int winLeaguePoints = 18;
  static const int lossLeaguePoints = -8;
  static const int duplicateItemCoins = 40;

  static bool isRankedMode(String mode) => mode == 'quick' || mode == 'challenge';
  static bool isCompetitiveMode(String mode) => const {'quick', 'challenge', 'tournament'}.contains(mode);

  static MatchSettlement standardMatch(MatchSummary summary) {
    if (!isRankedMode(summary.mode)) {
      return summary.mode == 'practice' ? MatchSettlement.practice : MatchSettlement.local;
    }

    final difficultyBonus = const {'easy': 5, 'medium': 10, 'hard': 18, 'pro': 28}[summary.difficulty] ?? 10;
    final modeBonus = summary.mode == 'challenge' ? 16 : difficultyBonus;
    final scoreDifference = max(0, summary.bottomScore - summary.topScore).toInt();
    final rallyBonus = summary.longestRally ~/ 3;

    var xp = 18 + modeBonus + scoreDifference * 2 + rallyBonus;
    var baseCoins = 8 + modeBonus ~/ 2 + max(0, summary.playerGold).toInt();
    if (summary.won) {
      xp += 26;
      baseCoins += 14;
    }
    if (summary.mode == 'challenge' && summary.won) baseCoins += 20;

    baseCoins = (baseCoins * (1 + summary.coinBonus.clamp(0.0, .75))).floor();
    final entryPrize = summary.won ? (max(0, summary.entry) * 2 * .75).floor() : 0;
    final totalCoins = baseCoins + entryPrize;

    return MatchSettlement(
      kind: MatchSettlementKind.standard,
      xp: xp,
      coins: totalCoins,
      baseCoins: baseCoins,
      entryPrize: entryPrize,
      leagueDelta: summary.won ? winLeaguePoints : lossLeaguePoints,
    );
  }

  static MatchSettlement tournamentMatch(MatchSummary summary, Tournament tournament) {
    final round = summary.tournamentRound.clamp(1, tournament.rounds).toInt();
    if (summary.won && round < tournament.rounds) {
      return MatchSettlement(
        kind: MatchSettlementKind.tournamentAdvance,
        xp: 35,
        nextRound: round + 1,
      );
    }
    if (summary.won) {
      final chestTier = switch (tournament.id) {
        'weekly' => 'gold',
        'daily' => 'silver',
        _ => 'bronze',
      };
      return MatchSettlement(
        kind: MatchSettlementKind.tournamentChampion,
        xp: 90,
        coins: tournament.prize,
        chestTier: chestTier,
      );
    }
    return const MatchSettlement(
      kind: MatchSettlementKind.tournamentEliminated,
      xp: 10,
    );
  }
}

class ChestOpenResult {
  final int coins;
  final int gems;
  final String? itemName;
  final bool duplicateItem;

  const ChestOpenResult({
    required this.coins,
    required this.gems,
    this.itemName,
    this.duplicateItem = false,
  });

  List<String> labels() {
    final result = <String>['+$coins سکه'];
    if (gems > 0) result.add('+$gems الماس');
    if (itemName != null) {
      result.add(duplicateItem ? 'آیتم تکراری: +${EconomyBalance.duplicateItemCoins} سکه' : 'آیتم جدید: $itemName');
    }
    return result;
  }
}
