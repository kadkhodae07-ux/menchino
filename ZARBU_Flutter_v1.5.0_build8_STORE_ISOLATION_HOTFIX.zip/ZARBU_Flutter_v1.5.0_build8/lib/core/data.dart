import 'package:flutter/material.dart';

class Item {
  final String id;
  final String type;
  final String name;
  final String rarity;
  final String icon;
  final String desc;
  final int price;
  final Map<String, double> stats;
  final Color? color;
  final Color? trailColor;

  const Item(
    this.id,
    this.type,
    this.name,
    this.rarity,
    this.icon,
    this.desc,
    this.price, [
    this.stats = const {},
    this.color,
    this.trailColor,
  ]);
}

class Catalog {
  static const rackets = [
    Item('r_default', 'racket', 'راکت کلاسیک', 'common', 'racket', 'راکت متعادل برای شروع.', 0),
    Item('r_long', 'racket', 'راکت بلند', 'rare', 'racketLong', 'سطح دفاعی بزرگ‌تر برای کنترل بیشتر.', 250, {'widthMult': 1.28, 'spinMult': .9, 'moveSpeedMult': .94}),
    Item('r_spin', 'racket', 'راکت اسپین', 'epic', 'racketSpin', 'زاویه‌ها و اسپین‌های قوی‌تر.', 420, {'widthMult': .92, 'spinMult': 1.75}),
    Item('r_turbo', 'racket', 'راکت توربو', 'legendary', 'racketTurbo', 'هر ضربه توپ را سریع‌تر می‌کند.', 650, {'widthMult': .96, 'spinMult': 1.1, 'hitSpeed': 35}),
    Item('r_phantom', 'racket', 'راکت فانتوم', 'epic', 'racket', 'کوچک‌تر، اما بسیار سریع.', 540, {'widthMult': .82, 'spinMult': 1.05, 'moveSpeedMult': 1.35}),
    Item('r_guardian', 'racket', 'راکت محافظ', 'rare', 'shield', 'در ابتدای هر مسابقه یک سپر داری.', 380, {'widthMult': 1.02, 'spinMult': .95, 'moveSpeedMult': .98, 'startShield': 1}),
    Item('r_magnet', 'racket', 'راکت مگنت', 'legendary', 'power', 'توپ‌های نزدیک را کمی به سمت راکت می‌کشد.', 760, {'widthMult': .96, 'magnet': .8}),
    Item('r_echo', 'racket', 'راکت اکو', 'epic', 'restart', 'شانس کُند شدن توپ بعد از ضربه تو.', 600, {'widthMult': .98, 'spinMult': 1.15, 'echoSlow': .18}),
    Item('r_blade', 'racket', 'راکت بلید', 'rare', 'racketTurbo', 'باریک و سریع برای ضربه‌های تهاجمی.', 460, {'widthMult': .88, 'moveSpeedMult': 1.22, 'hitSpeed': 16}),
    Item('r_royal', 'racket', 'راکت رویال', 'legendary', 'crown', 'کنترل بالا با سطح دفاعی گسترده.', 920, {'widthMult': 1.18, 'spinMult': 1.25, 'moveSpeedMult': 1.02}),
    Item('r_flux', 'racket', 'راکت فلوکس', 'epic', 'power', 'حرکت نرم با اسپین دقیق‌تر.', 690, {'widthMult': .96, 'spinMult': 1.48, 'moveSpeedMult': 1.18}),
    Item('r_iron', 'racket', 'راکت آیرون', 'rare', 'shield', 'پایدار و مناسب مسابقه‌های طولانی.', 510, {'widthMult': 1.10, 'spinMult': .96, 'moveSpeedMult': .93}),
  ];

  static const balls = [
    Item('b_default', 'ball', 'توپ نئونی', 'common', 'ball', 'توپ استاندارد مسابقه.', 0, {}, Color(0xFFE8F2FF), Color(0xFF2DE2FF)),
    Item('b_comet', 'ball', 'توپ دنباله‌دار', 'rare', 'ball', 'سریع‌تر با رد درخشان‌تر.', 220, {'speedMult': 1.08, 'radiusMult': .95, 'powerRate': 1.15}, Color(0xFF8DF6FF), Color(0xFF2DE2FF)),
    Item('b_heavy', 'ball', 'توپ سنگین', 'rare', 'ball', 'کنترل آسان‌تر و رشد سرعت کمتر.', 260, {'speedMult': .92, 'radiusMult': 1.18, 'powerRate': .9, 'speedIncrementMult': .85, 'minVerticalBonus': .08}, Color(0xFFFFD28D), Color(0xFFFF9D5C)),
    Item('b_plasma', 'ball', 'توپ پلاسما', 'legendary', 'ball', 'سرعت بالا و پاورآپ بیشتر.', 700, {'speedMult': 1.16, 'radiusMult': .9, 'powerRate': 1.35, 'speedIncrementMult': 1.1}, Color(0xFFFF7AD9), Color(0xFFFF3B8D)),
    Item('b_ghost', 'ball', 'توپ شبح', 'epic', 'ball', 'حرکت تو برای حریف سخت‌تر خوانده می‌شود.', 580, {'speedMult': 1.03, 'radiusMult': .98, 'aiErrorBonus': 26}, Color(0xFFC9D7F0), Color(0xFF8A5CFF)),
    Item('b_gold', 'ball', 'توپ طلایی', 'epic', 'coin', 'سکه بیشتر در پایان مسابقه.', 620, {'coinBonus': .25}, Color(0xFFFFD54D), Color(0xFFFFD54D)),
    Item('b_moon', 'ball', 'توپ ماه', 'rare', 'ball', 'سرعت توپ آرام‌تر رشد می‌کند.', 340, {'speedMult': .98, 'radiusMult': 1.05, 'speedIncrementMult': .65, 'minVerticalBonus': .04}, Color(0xFFBFD9FF), Color(0xFF7DE3FF)),
    Item('b_rubber', 'ball', 'توپ لاستیکی', 'legendary', 'ball', 'مسیر کمی خمیده و غیرقابل پیش‌بینی.', 760, {'speedMult': 1.02, 'powerRate': 1.1, 'curve': 22}, Color(0xFF7DFFB2), Color(0xFF00FFC6)),
    Item('b_ice', 'ball', 'توپ یخی', 'rare', 'ball', 'کمی آرام‌تر و دقیق‌تر برای کنترل بهتر.', 390, {'speedMult': .95, 'radiusMult': 1.04, 'minVerticalBonus': .06}, Color(0xFFBEEBFF), Color(0xFF78D9FF)),
    Item('b_solar', 'ball', 'توپ خورشیدی', 'epic', 'ball', 'سرعت رشد بیشتر با رد گرم و روشن.', 650, {'speedMult': 1.08, 'speedIncrementMult': 1.22}, Color(0xFFFFC45E), Color(0xFFFF7B45)),
    Item('b_nebula', 'ball', 'توپ نبولا', 'legendary', 'ball', 'پاورآپ بیشتر و مسیر سریع‌تر.', 900, {'speedMult': 1.12, 'powerRate': 1.30, 'radiusMult': .94}, Color(0xFFC49BFF), Color(0xFF8A5CFF)),
    Item('b_core', 'ball', 'توپ کور', 'epic', 'ball', 'اندازه کوچک و سرعت بالا برای حرفه‌ای‌ها.', 720, {'speedMult': 1.14, 'radiusMult': .82, 'speedIncrementMult': 1.15}, Color(0xFFFF788B), Color(0xFFFF3B8D)),
  ];

  static const arenas = [
    Item('a_default', 'arena', 'آرنای سایبر', 'common', 'arena', 'زمین استاندارد ZARBU.', 0),
    Item('a_speed', 'arena', 'آرنای توربو', 'epic', 'fast', 'سرعت پایه بالاتر برای حرفه‌ای‌ها.', 520, {'baseSpeedMult': 1.12, 'maxSpeedMult': 1.1, 'powerRate': .9}),
    Item('a_control', 'arena', 'آرنای کنترل', 'rare', 'shield', 'سرعت محدودتر برای تمرکز روی کنترل.', 320, {'baseSpeedMult': .94, 'maxSpeedMult': .95, 'powerRate': 1.1}),
    Item('a_void', 'arena', 'آرنای ووید', 'legendary', 'power', 'پاورآپ بیشتر و سرعت زیاد.', 800, {'baseSpeedMult': 1.06, 'maxSpeedMult': 1.12, 'powerRate': 1.45}),
    Item('a_narrow', 'arena', 'آرنای باریک', 'epic', 'shrink', 'دیواره‌های نزدیک‌تر؛ مسابقه فشرده‌تر.', 560, {'baseSpeedMult': 1.02, 'maxSpeedMult': 1.05, 'sideInset': 36}),
    Item('a_fortune', 'arena', 'آرنای ثروت', 'epic', 'coin', 'سکه بیشتر در پایان مسابقه.', 640, {'coinBonus': .2}),
    Item('a_time', 'arena', 'آرنای زمان', 'legendary', 'timer', 'پاورآپ‌ها مدت بیشتری فعال می‌مانند.', 780, {'maxSpeedMult': .98, 'powerRate': 1.15, 'powerDurationMult': 1.4}),
    Item('a_mirror', 'arena', 'آرنای آینه', 'rare', 'arena', 'حرکت هوش مصنوعی کمی کندتر می‌شود.', 420, {'aiSpeedMult': .88}),
    Item('a_frost', 'arena', 'آرنای فراست', 'rare', 'arena', 'زمین آرام‌تر برای کنترل و رالی‌های طولانی.', 470, {'baseSpeedMult': .92, 'maxSpeedMult': .94}),
    Item('a_blaze', 'arena', 'آرنای بلیز', 'epic', 'fast', 'زمین تهاجمی با سرعت پایه بالاتر.', 690, {'baseSpeedMult': 1.10, 'maxSpeedMult': 1.08}),
    Item('a_orbit', 'arena', 'آرنای اوربیت', 'legendary', 'power', 'پاورآپ‌های بیشتر و مدت اثر طولانی‌تر.', 980, {'powerRate': 1.35, 'powerDurationMult': 1.25}),
    Item('a_elite', 'arena', 'آرنای الیت', 'legendary', 'crown', 'زمین رقابتی با سرعت و پاداش بیشتر.', 1100, {'baseSpeedMult': 1.06, 'maxSpeedMult': 1.12, 'coinBonus': .12}),
  ];

  static final List<Item> all = [...rackets, ...balls, ...arenas];

  static Item? findById(String? id) {
    if (id == null) return null;
    for (final item in all) {
      if (item.id == id) return item;
    }
    return null;
  }

  static Item byId(String? id) => findById(id) ?? rackets.first;

  static List<Item> of(String tab) {
    switch (tab) {
      case 'rackets': return rackets;
      case 'balls': return balls;
      case 'arenas': return arenas;
      default: return rackets;
    }
  }
}

class Tournament {
  final String id;
  final String name;
  final String icon;
  final String desc;
  final String difficulty;
  final int entry;
  final int prize;
  final int rounds;

  const Tournament(this.id, this.name, this.icon, this.desc, this.difficulty, this.entry, this.prize, this.rounds);
}

const tournaments = [
  Tournament('neon', 'جام نئونی', 'power', 'دو مسابقه کوتاه برای شروع.', 'medium', 20, 90, 2),
  Tournament('daily', 'جام روزانه', 'rank', 'سه مسابقه متوالی با حریف‌های سخت.', 'hard', 50, 250, 3),
  Tournament('weekly', 'جام قهرمانی', 'crown', 'چهار مسابقه حرفه‌ای برای قهرمانان.', 'pro', 100, 600, 4),
];

class Mission {
  final String id;
  final String title;
  final String key;
  final int target;
  final Map<String, dynamic> reward;

  const Mission(this.id, this.title, this.key, this.target, this.reward);
}

const missions = [
  Mission('play3', '۳ مسابقه انجام بده', 'play', 3, {'coins': 50}),
  Mission('win2', '۲ مسابقه ببر', 'win', 2, {'chest': 'bronze'}),
  Mission('rally10', 'یک رالی ۱۰ ضربه‌ای بساز', 'rally10', 1, {'coins': 80}),
  Mission('power3', '۳ پاورآپ جمع کن', 'power', 3, {'gems': 2}),
  Mission('hardWin', 'یک برد روی سخت', 'hardWin', 1, {'chest': 'silver'}),
  Mission('chestOpen', 'یک صندوق باز کن', 'chest', 1, {'coins': 60}),
];

const rarityColor = {
  'common': Color(0xFFB7C8E8),
  'rare': Color(0xFF2DE2FF),
  'epic': Color(0xFFB491FF),
  'legendary': Color(0xFFFFD54D),
};

const rarityLabel = {
  'common': 'معمولی',
  'rare': 'کمیاب',
  'epic': 'حماسی',
  'legendary': 'افسانه‌ای',
};

class AvatarSpec {
  final String name;
  final String gender;
  final String assetPath;
  final Color background;
  final Color accent;
  final int price;

  const AvatarSpec({
    required this.name,
    required this.gender,
    required this.assetPath,
    required this.background,
    required this.accent,
    this.price = 0,
  });

  bool get isPremium => price > 0;
}

const avatars = [
  AvatarSpec(
    name: 'آواتار پسر',
    gender: 'پسر',
    assetPath: 'assets/images/avatars/01_default_male.webp',
    background: Color(0xFF16334D),
    accent: Color(0xFF2DE2FF),
  ),
  AvatarSpec(
    name: 'آواتار دختر',
    gender: 'دختر',
    assetPath: 'assets/images/avatars/02_default_female.webp',
    background: Color(0xFF3A2244),
    accent: Color(0xFFFF76C8),
  ),
  AvatarSpec(
    name: 'نئون کلاسیک',
    gender: 'پسر',
    assetPath: 'assets/images/avatars/03_premium_male.webp',
    background: Color(0xFF243260),
    accent: Color(0xFF7AA8FF),
    price: 350,
  ),
  AvatarSpec(
    name: 'نئون صورتی',
    gender: 'دختر',
    assetPath: 'assets/images/avatars/04_premium_female.webp',
    background: Color(0xFF5A2957),
    accent: Color(0xFFFF76C8),
    price: 350,
  ),
  AvatarSpec(
    name: 'ویزور آبی',
    gender: 'پسر',
    assetPath: 'assets/images/avatars/05_premium_male_visor.webp',
    background: Color(0xFF17384F),
    accent: Color(0xFF2DE2FF),
    price: 420,
  ),
  AvatarSpec(
    name: 'فرمانده نئون',
    gender: 'دختر',
    assetPath: 'assets/images/avatars/06_premium_female_commander.webp',
    background: Color(0xFF4B2D1F),
    accent: Color(0xFFFFC45E),
    price: 420,
  ),
  AvatarSpec(
    name: 'ماسک سایبر',
    gender: 'پسر',
    assetPath: 'assets/images/avatars/07_premium_male_masked.webp',
    background: Color(0xFF2D2B44),
    accent: Color(0xFFB491FF),
    price: 480,
  ),
  AvatarSpec(
    name: 'گیمر نئون',
    gender: 'دختر',
    assetPath: 'assets/images/avatars/08_premium_female_gamer.webp',
    background: Color(0xFF234B48),
    accent: Color(0xFF58E0C1),
    price: 480,
  ),
  AvatarSpec(
    name: 'دوال نئون',
    gender: 'پسر',
    assetPath: 'assets/images/avatars/09_premium_male_dual_neon.webp',
    background: Color(0xFF3B244C),
    accent: Color(0xFF8A72FF),
    price: 560,
  ),
  AvatarSpec(
    name: 'آرمر نئون',
    gender: 'دختر',
    assetPath: 'assets/images/avatars/10_premium_female_armor.webp',
    background: Color(0xFF5C2737),
    accent: Color(0xFFFF8A5C),
    price: 560,
  ),
];
