// The concrete store backend is selected by tool/prepare_store_variant.py.
// Source archives default to the offline backend so a plain build never links
// Bazaar and Myket billing SDKs into the same Android application.
export 'store_billing_backend.dart';
