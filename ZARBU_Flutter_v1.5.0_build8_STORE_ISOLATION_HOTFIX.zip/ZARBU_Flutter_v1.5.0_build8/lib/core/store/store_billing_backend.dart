import 'store_product.dart';

class StoreBillingService {
  bool get ready => false;

  Future<bool> initialize() async => false;

  Future<Map<String, String>> loadPrices() async {
    throw const StoreBillingException('پرداخت در نسخه آفلاین فعال نیست.');
  }

  Future<StoreReceipt> purchase(StoreProduct product) async {
    throw const StoreBillingException('پرداخت در نسخه آفلاین فعال نیست.');
  }

  Future<bool> consume(StoreReceipt receipt) async => false;

  Future<bool> recoverConsume({required String store, required String sku, required String token}) async => false;

  Future<void> dispose() async {}
}
