class StoreProduct {
  final String id;
  final String title;
  final String sku;
  final int coins;
  final int gems;

  const StoreProduct({
    required this.id,
    required this.title,
    required this.sku,
    this.coins = 0,
    this.gems = 0,
  });

  bool get isValid => id.isNotEmpty && sku.isNotEmpty && (coins > 0 || gems > 0);
}

class StoreReceipt {
  final String store;
  final String token;
  final String sku;
  final String payload;
  final Object? nativePurchase;

  const StoreReceipt({
    required this.store,
    required this.token,
    required this.sku,
    required this.payload,
    this.nativePurchase,
  });
}

class StoreBillingException implements Exception {
  final String message;
  const StoreBillingException(this.message);

  @override
  String toString() => message;
}
