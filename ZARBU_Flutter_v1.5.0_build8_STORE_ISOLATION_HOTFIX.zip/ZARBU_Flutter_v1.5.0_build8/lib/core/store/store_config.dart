import 'store_product.dart';

enum ZarbuStore { offline, bazaar, myket }

class StoreConfig {
  static const String _storeValue = String.fromEnvironment('ZARBU_STORE', defaultValue: 'offline');
  static const String rsaKey = String.fromEnvironment('ZARBU_STORE_RSA');

  // Canonical SKUs. Create the same IDs in both Bazaar and Myket panels.
  static const String coin1000Sku = 'zarbu_coin_1000';
  static const String coin5000Sku = 'zarbu_coin_5000';
  static const String coin12000Sku = 'zarbu_coin_12000';
  static const String gem50Sku = 'zarbu_gem_50';
  static const String gem150Sku = 'zarbu_gem_150';
  static const String bundleSku = 'zarbu_bundle_6000_100';

  static ZarbuStore get activeStore => switch (_storeValue.trim().toLowerCase()) {
        'bazaar' => ZarbuStore.bazaar,
        'myket' => ZarbuStore.myket,
        _ => ZarbuStore.offline,
      };

  static bool get isStoreBuild => activeStore != ZarbuStore.offline;
  static bool get isConfigured => isStoreBuild && rsaKey.trim().isNotEmpty && products.every((item) => item.isValid);

  static String get storeLabel => switch (activeStore) {
        ZarbuStore.bazaar => 'بازار',
        ZarbuStore.myket => 'مایکت',
        ZarbuStore.offline => 'آفلاین',
      };

  static const List<StoreProduct> products = [
    StoreProduct(id: 'coin1000', title: '۱٬۰۰۰ سکه', sku: coin1000Sku, coins: 1000),
    StoreProduct(id: 'coin5000', title: '۵٬۰۰۰ سکه', sku: coin5000Sku, coins: 5000),
    StoreProduct(id: 'coin12000', title: '۱۲٬۰۰۰ سکه', sku: coin12000Sku, coins: 12000),
    StoreProduct(id: 'gem50', title: '۵۰ جم', sku: gem50Sku, gems: 50),
    StoreProduct(id: 'gem150', title: '۱۵۰ جم', sku: gem150Sku, gems: 150),
    StoreProduct(id: 'bundle', title: '۶٬۰۰۰ سکه + ۱۰۰ جم', sku: bundleSku, coins: 6000, gems: 100),
  ];

  static StoreProduct? productBySku(String sku) {
    for (final product in products) {
      if (product.sku == sku) return product;
    }
    return null;
  }
}
