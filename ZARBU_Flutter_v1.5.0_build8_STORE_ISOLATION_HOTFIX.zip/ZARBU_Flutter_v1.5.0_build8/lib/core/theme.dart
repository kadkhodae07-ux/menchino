import 'package:flutter/material.dart';

class GameTheme {
  final String id;
  final String label;
  final Brightness brightness;
  final Color bg;
  final Color panel;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color danger;
  final Color gold;
  final Color text;
  final Color dim;
  final Color canvasBg;
  final Color grid;
  final Color center;
  final Color top;
  final Color bottom;
  final Color ball;
  final Color trail;

  const GameTheme({
    required this.id,
    required this.label,
    required this.brightness,
    required this.bg,
    required this.panel,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.danger,
    required this.gold,
    required this.text,
    required this.dim,
    required this.canvasBg,
    required this.grid,
    required this.center,
    required this.top,
    required this.bottom,
    required this.ball,
    required this.trail,
  });
}

class Themes {
  static const dark = GameTheme(
    id: 'dark',
    label: 'نئون شب',
    brightness: Brightness.dark,
    bg: Color(0xFF050913),
    panel: Color(0xF0121B2D),
    primary: Color(0xFF42C8ED),
    secondary: Color(0xFF8576E9),
    accent: Color(0xFF2ED7AE),
    danger: Color(0xFFE9578D),
    gold: Color(0xFFE7C55D),
    text: Color(0xFFF4F8FD),
    dim: Color(0xFFA5B2CB),
    canvasBg: Color(0xFF030711),
    grid: Color(0x1339C8E8),
    center: Color(0xFF43CBEA),
    top: Color(0xFF8B7AEA),
    bottom: Color(0xFF2FD7AF),
    ball: Color(0xFFF4F9FD),
    trail: Color(0xFF4BC8E9),
  );

  static const light = GameTheme(
    id: 'light',
    label: 'کریستال',
    brightness: Brightness.light,
    bg: Color(0xFFF4F7FB),
    panel: Color(0xF7FFFFFF),
    primary: Color(0xFF315F9F),
    secondary: Color(0xFF6754A8),
    accent: Color(0xFF247C6B),
    danger: Color(0xFFB63C68),
    gold: Color(0xFFA97421),
    text: Color(0xFF111B2B),
    dim: Color(0xFF526078),
    canvasBg: Color(0xFFEAF0F7),
    grid: Color(0x18315F9F),
    center: Color(0xFF3769A7),
    top: Color(0xFF6B57AE),
    bottom: Color(0xFF287F6D),
    ball: Color(0xFF142033),
    trail: Color(0xFF3E6FAE),
  );

  static const girly = GameTheme(
    id: 'girly',
    label: 'بلوسوم',
    brightness: Brightness.dark,
    bg: Color(0xFF160A14),
    panel: Color(0xF02A1428),
    primary: Color(0xFFE57CAD),
    secondary: Color(0xFFB483D5),
    accent: Color(0xFFF1B2CE),
    danger: Color(0xFFE0507D),
    gold: Color(0xFFE6C467),
    text: Color(0xFFFFF5FA),
    dim: Color(0xFFD0A5BC),
    canvasBg: Color(0xFF12080F),
    grid: Color(0x14E57CAD),
    center: Color(0xFFE98AB6),
    top: Color(0xFFBB8ADD),
    bottom: Color(0xFFEDAECA),
    ball: Color(0xFFFFF5FA),
    trail: Color(0xFFE981AF),
  );

  static const boyish = GameTheme(
    id: 'boyish',
    label: 'سایبر اسپرت',
    brightness: Brightness.dark,
    bg: Color(0xFF071015),
    panel: Color(0xF00D1B24),
    primary: Color(0xFF3CA9D5),
    secondary: Color(0xFF34B982),
    accent: Color(0xFFA0CF4F),
    danger: Color(0xFFD97649),
    gold: Color(0xFFDAB64D),
    text: Color(0xFFF0F9FC),
    dim: Color(0xFF93AAB4),
    canvasBg: Color(0xFF041014),
    grid: Color(0x133CA9D5),
    center: Color(0xFF42B1D9),
    top: Color(0xFF38BE86),
    bottom: Color(0xFFA2D151),
    ball: Color(0xFFF1FAFC),
    trail: Color(0xFF41ADD4),
  );

  static const child = GameTheme(
    id: 'child',
    label: 'فان پاپ',
    brightness: Brightness.light,
    bg: Color(0xFFFFF7EA),
    panel: Color(0xF8FFFDF8),
    primary: Color(0xFFD96F3B),
    secondary: Color(0xFF675FC0),
    accent: Color(0xFF318F7D),
    danger: Color(0xFFC94E6C),
    gold: Color(0xFFC99327),
    text: Color(0xFF302641),
    dim: Color(0xFF655A78),
    canvasBg: Color(0xFFFFF0DD),
    grid: Color(0x16D96F3B),
    center: Color(0xFFDA7742),
    top: Color(0xFF6B62C4),
    bottom: Color(0xFF359480),
    ball: Color(0xFF332844),
    trail: Color(0xFFD97640),
  );

  static const all = [dark, light, girly, boyish, child];

  static GameTheme byId(String? id) =>
      all.firstWhere((theme) => theme.id == id, orElse: () => dark);
}
