import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const _key = 'zarbu_flutter_v1';
  static const _legacyKey = 'phong_flutter_v1';
  SharedPreferences? _prefs;
  Future<void> _writeTail = Future<void>.value();

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final prefs = _prefs!;
    if (prefs.getString(_key) == null) {
      final legacy = prefs.getString(_legacyKey);
      if (legacy != null) {
        await prefs.setString(_key, legacy);
      }
    }
  }

  Map<String, dynamic>? load() {
    final raw = _prefs?.getString(_key) ?? _prefs?.getString(_legacyKey);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> save(Map<String, dynamic> data) {
    final prefs = _prefs;
    if (prefs == null) {
      return Future<void>.error(StateError('StorageService.init() must be called first.'));
    }
    final payload = jsonEncode(data);
    final operation = _writeTail.then((_) async {
      final success = await prefs.setString(_key, payload);
      if (!success) throw StateError('Could not persist ZARBU state.');
    });
    // Keep the queue usable after an individual write failure while returning
    // the original operation to the caller so the error is still observable.
    _writeTail = operation.then<void>((_) {}, onError: (Object _, StackTrace __) {});
    return operation;
  }

  Future<void> reset() async {
    final prefs = _prefs;
    if (prefs == null) throw StateError('StorageService.init() must be called first.');
    try {
      await _writeTail;
    } catch (_) {
      // A previous failed write must not prevent an explicit reset.
    }
    await prefs.remove(_key);
    await prefs.remove(_legacyKey);
  }
}
