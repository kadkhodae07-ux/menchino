import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../balance.dart';
import '../data.dart';
import '../services/audio_service.dart';
import '../services/storage_service.dart';
import '../store/store_billing_service.dart';
import '../store/store_config.dart';
import '../store/store_product.dart';
import '../theme.dart';

class AppState extends ChangeNotifier {
  final StorageService storage = StorageService();
  final AudioService audio = AudioService();
  final StoreBillingService billing = StoreBillingService();
  String name = 'بازیکن';
  int avatar = 0;
  String themeId = 'dark';
  int level = 1;
  int xp = 0;
  int coins = EconomyBalance.startingCoins;
  int gems = EconomyBalance.startingGems;
  Map<String, String> selected = {
    'racket': 'r_default',
    'ball': 'b_default',
    'arena': 'a_default',
  };
  List<String> owned = ['r_default', 'b_default', 'a_default'];
  List<int> ownedAvatars = [0, 1];
  Map<String, int> chests = {'bronze': 1, 'silver': 0, 'gold': 0};
  Map<String, int> missionProgress = {
    'play': 0,
    'win': 0,
    'rally10': 0,
    'power': 0,
    'hardWin': 0,
    'chest': 0,
  };
  Map<String, bool> claimed = {};
  String missionDay = _dayNow();
  Map<String, int> stats = {
    'matches': 0,
    'wins': 0,
    'losses': 0,
    'bestRally': 0,
    'streak': 0,
    'bestStreak': 0,
    'powerCollected': 0,
  };
  int leaguePoints = 0;
  String season = _seasonNow();
  Map<String, dynamic> tournament = {'activeId': null, 'round': 0};
  List<Map<String, dynamic>> friends = [];
  List<String> settledMatchTokens = [];
  List<String> processedStorePurchaseTokens = [];
  List<Map<String, dynamic>> pendingStoreConsumes = [];
  Map<String, dynamic> matchSetup = {
    'mode': 'quick',
    'difficulty': 'medium',
    'orientation': 'portrait',
    'entry': 0,
  };
  double sensitivity = 1;
  String quality = 'medium';
  bool trail = true;
  bool sound = true;
  double sfxVolume = .8;
  bool haptics = true;

  GameTheme get theme => Themes.byId(themeId);
  int get xpToNext => 100 + (level - 1) * 70;
  Item get racket => Catalog.byId(selected['racket']);
  Item get ball => Catalog.byId(selected['ball']);
  Item get arena => Catalog.byId(selected['arena']);

  static String _seasonNow() {
    final date = DateTime.now();
    return '${date.year}-${date.month.toString().padLeft(2, '0')}';
  }

  static String _dayNow() {
    final date = DateTime.now();
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  Future<void> bootstrap() async {
    await storage.init();
    try {
      await audio.init();
    } catch (_) {
      // Audio is optional; a device-specific audio failure must not block the game.
      audio.enabled = false;
    }
    final data = storage.load();
    if (data != null) _from(data);
    final seasonChanged = _ensureSeason();
    final missionDayChanged = _ensureMissionDay();
    _sanitizeState();
    _syncServices();
    if (seasonChanged || missionDayChanged || data == null) await _persist();
    notifyListeners();
  }

  int _int(dynamic value, int fallback) => value is num ? value.toInt() : fallback;
  double _double(dynamic value, double fallback) => value is num ? value.toDouble() : fallback;
  bool _bool(dynamic value, bool fallback) => value is bool ? value : fallback;
  String _string(dynamic value, String fallback) => value is String ? value : fallback;

  Map<String, int> _intMap(dynamic value, Map<String, int> fallback) {
    if (value is! Map) return Map<String, int>.from(fallback);
    final result = Map<String, int>.from(fallback);
    value.forEach((key, item) {
      if (key is String && item is num) result[key] = item.toInt();
    });
    return result;
  }

  void _from(Map<String, dynamic> data) {
    name = _string(data['name'], name);
    avatar = _int(data['avatar'], avatar).clamp(0, avatars.length - 1).toInt();
    themeId = _string(data['theme'], themeId);
    level = max(1, _int(data['level'], level)).toInt();
    xp = max(0, _int(data['xp'], xp)).toInt();
    coins = max(0, _int(data['coins'], coins)).toInt();
    gems = max(0, _int(data['gems'], gems)).toInt();

    if (data['selected'] is Map) {
      selected = Map<String, String>.from(selected);
      (data['selected'] as Map).forEach((key, value) {
        if (key is String && value is String) selected[key] = value;
      });
    }
    if (data['owned'] is List) {
      owned = (data['owned'] as List).whereType<String>().toSet().toList();
    }
    for (final id in const ['r_default', 'b_default', 'a_default']) {
      if (!owned.contains(id)) owned.add(id);
    }

    ownedAvatars = [0, 1];
    if (data['ownedAvatars'] is List) {
      ownedAvatars = (data['ownedAvatars'] as List)
          .whereType<num>()
          .map((value) => value.toInt())
          .where((value) => value >= 0 && value < avatars.length)
          .toSet()
          .toList()
        ..sort();
    }
    for (final id in const [0, 1]) {
      if (!ownedAvatars.contains(id)) ownedAvatars.add(id);
    }
    ownedAvatars = ownedAvatars.where((value) => value >= 0 && value < avatars.length).toSet().toList()..sort();
    if (!ownedAvatars.contains(avatar)) avatar = 0;

    chests = _intMap(data['chests'], chests);
    missionProgress = _intMap(data['missionProgress'], missionProgress);
    stats = _intMap(data['stats'], stats);
    claimed = {};
    if (data['claimed'] is Map) {
      (data['claimed'] as Map).forEach((key, value) {
        if (key is String && value is bool) claimed[key] = value;
      });
    }
    missionDay = data['missionDay'] is String ? data['missionDay'] as String : '';

    leaguePoints = max(0, _int(data['leaguePoints'], leaguePoints)).toInt();
    season = _string(data['season'], season);
    tournament = data['tournament'] is Map
        ? Map<String, dynamic>.from(data['tournament'] as Map)
        : {'activeId': null, 'round': 0};
    friends = _listOfMaps(data['friends']);
    settledMatchTokens = data['settledMatchTokens'] is List
        ? (data['settledMatchTokens'] as List).whereType<String>().where((token) => token.isNotEmpty).toSet().toList()
        : <String>[];
    processedStorePurchaseTokens = data['processedStorePurchaseTokens'] is List
        ? (data['processedStorePurchaseTokens'] as List).whereType<String>().where((token) => token.trim().isNotEmpty).toSet().toList()
        : <String>[];
    pendingStoreConsumes = _listOfMaps(data['pendingStoreConsumes']);
    if (data['matchSetup'] is Map) {
      matchSetup = {...matchSetup, ...Map<String, dynamic>.from(data['matchSetup'] as Map)};
    }
    sensitivity = _double(data['sensitivity'], sensitivity).clamp(.6, 2.0).toDouble();
    quality = _string(data['quality'], quality);
    if (!const ['low', 'medium', 'high'].contains(quality)) quality = 'medium';
    trail = _bool(data['trail'], trail);
    sound = _bool(data['sound'], sound);
    sfxVolume = _double(data['sfxVolume'], sfxVolume).clamp(0.0, 1.0).toDouble();
    haptics = _bool(data['haptics'], haptics);
  }

  List<Map<String, dynamic>> _listOfMaps(dynamic value) {
    if (value is! List) return [];
    return value.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
  }

  Map<String, dynamic> _to() => {
        'name': name,
        'avatar': avatar,
        'theme': themeId,
        'level': level,
        'xp': xp,
        'coins': coins,
        'gems': gems,
        'selected': selected,
        'owned': owned,
        'ownedAvatars': ownedAvatars,
        'chests': chests,
        'missionProgress': missionProgress,
        'claimed': claimed,
        'missionDay': missionDay,
        'stats': stats,
        'leaguePoints': leaguePoints,
        'season': season,
        'tournament': tournament,
        'friends': friends,
        'settledMatchTokens': settledMatchTokens,
        'processedStorePurchaseTokens': processedStorePurchaseTokens,
        'pendingStoreConsumes': pendingStoreConsumes,
        'matchSetup': matchSetup,
        'sensitivity': sensitivity,
        'quality': quality,
        'trail': trail,
        'sound': sound,
        'sfxVolume': sfxVolume,
        'haptics': haptics,
      };

  Future<void> _persist() => storage.save(_to());

  Future<void> save({bool notify = true}) async {
    _sanitizeState();
    _syncServices();
    await _persist();
    if (notify) notifyListeners();
  }

  void _syncServices() {
    audio.enabled = sound;
    audio.sfxVolume = sfxVolume.clamp(0.0, 1.0).toDouble();
  }

  bool _ensureSeason() {
    if (season == _seasonNow()) return false;
    season = _seasonNow();
    leaguePoints = 0;
    return true;
  }

  bool _ensureMissionDay() {
    final today = _dayNow();
    if (missionDay == today) return false;
    missionDay = today;
    missionProgress = {
      'play': 0,
      'win': 0,
      'rally10': 0,
      'power': 0,
      'hardWin': 0,
      'chest': 0,
    };
    claimed = {};
    return true;
  }

  void _sanitizeState() {
    final cleanName = name.trim().replaceAll(RegExp(r'[<>{}]'), '');
    name = cleanName.length >= 2 && cleanName.length <= 16 ? cleanName : 'بازیکن';
    themeId = Themes.byId(themeId).id;

    final validCatalogIds = Catalog.all.map((item) => item.id).toSet();
    owned = owned.where(validCatalogIds.contains).toSet().toList();
    for (final id in const ['r_default', 'b_default', 'a_default']) {
      if (!owned.contains(id)) owned.add(id);
    }

    const defaults = {'racket': 'r_default', 'ball': 'b_default', 'arena': 'a_default'};
    for (final entry in defaults.entries) {
      final item = Catalog.findById(selected[entry.key]);
      if (item == null || item.type != entry.key || !owned.contains(item.id)) {
        selected[entry.key] = entry.value;
      }
    }

    ownedAvatars = ownedAvatars.where((value) => value >= 0 && value < avatars.length).toSet().toList()..sort();
    for (final id in const [0, 1]) {
      if (!ownedAvatars.contains(id)) ownedAvatars.add(id);
    }
    ownedAvatars.sort();
    if (!ownedAvatars.contains(avatar)) avatar = 0;

    chests = {
      'bronze': max(0, chests['bronze'] ?? 0).toInt(),
      'silver': max(0, chests['silver'] ?? 0).toInt(),
      'gold': max(0, chests['gold'] ?? 0).toInt(),
    };

    final cleanMissionProgress = <String, int>{};
    for (final mission in missions) {
      cleanMissionProgress[mission.key] = max(0, missionProgress[mission.key] ?? 0).toInt();
    }
    missionProgress = cleanMissionProgress;
    claimed.removeWhere((id, value) => !missions.any((mission) => mission.id == id) || !value);

    final statDefaults = <String, int>{
      'matches': 0,
      'wins': 0,
      'losses': 0,
      'bestRally': 0,
      'streak': 0,
      'bestStreak': 0,
      'powerCollected': 0,
    };
    for (final key in statDefaults.keys) {
      stats[key] = max(0, stats[key] ?? 0).toInt();
    }

    level = max(1, level).toInt();
    xp = max(0, xp).toInt();
    while (xp >= xpToNext) {
      xp -= xpToNext;
      level++;
    }
    coins = coins.clamp(0, 999999999).toInt();
    gems = gems.clamp(0, 999999999).toInt();
    leaguePoints = max(0, leaguePoints).toInt();

    final activeId = tournament['activeId'];
    Tournament? activeTournament;
    if (activeId is String) {
      for (final item in tournaments) {
        if (item.id == activeId) {
          activeTournament = item;
          break;
        }
      }
    }
    if (activeTournament == null) {
      tournament = {'activeId': null, 'round': 0};
    } else {
      final round = _int(tournament['round'], 1).clamp(1, activeTournament.rounds).toInt();
      tournament = {'activeId': activeTournament.id, 'round': round};
    }

    final mode = matchSetup['mode'] is String ? matchSetup['mode'] as String : 'quick';
    final difficulty = matchSetup['difficulty'] is String ? matchSetup['difficulty'] as String : 'medium';
    final orientation = matchSetup['orientation'] is String ? matchSetup['orientation'] as String : 'portrait';
    final entry = matchSetup['entry'] is num ? (matchSetup['entry'] as num).toInt() : 0;
    matchSetup = {
      'mode': const ['quick', 'challenge', 'practice', 'local'].contains(mode) ? mode : 'quick',
      'difficulty': const ['easy', 'medium', 'hard', 'pro'].contains(difficulty) ? difficulty : 'medium',
      'orientation': const ['portrait', 'landscape'].contains(orientation) ? orientation : 'portrait',
      'entry': const [0, 20, 50, 100].contains(entry) ? entry : 0,
    };
    if (matchSetup['mode'] == 'practice' || matchSetup['mode'] == 'local') matchSetup['entry'] = 0;

    final cleanFriends = <Map<String, dynamic>>[];
    final seenNames = <String>{};
    for (final friend in friends) {
      final rawId = '${friend['id'] ?? ''}'.trim();
      if (rawId == 'f1' || rawId == 'f2') continue;
      final name = '${friend['name'] ?? ''}'.trim().replaceAll(RegExp(r'[<>{}]'), '');
      if (name.length < 2 || name.length > 16) continue;
      final normalized = name.toLowerCase();
      if (!seenNames.add(normalized)) continue;
      cleanFriends.add({'id': rawId.isEmpty ? 'local_${cleanFriends.length + 1}' : rawId, 'name': name, 'local': true});
      if (cleanFriends.length >= 20) break;
    }
    friends = cleanFriends;
    settledMatchTokens = settledMatchTokens.where((token) => token.isNotEmpty).toSet().toList();
    if (settledMatchTokens.length > 16) {
      settledMatchTokens = settledMatchTokens.sublist(settledMatchTokens.length - 16);
    }

    processedStorePurchaseTokens = processedStorePurchaseTokens.where((token) => token.trim().isNotEmpty).toSet().toList();
    if (processedStorePurchaseTokens.length > 128) {
      processedStorePurchaseTokens = processedStorePurchaseTokens.sublist(processedStorePurchaseTokens.length - 128);
    }
    final cleanPendingConsumes = <Map<String, dynamic>>[];
    final pendingTokens = <String>{};
    for (final item in pendingStoreConsumes) {
      final token = '${item['token'] ?? ''}'.trim();
      final sku = '${item['sku'] ?? ''}'.trim();
      final store = '${item['store'] ?? ''}'.trim();
      if (token.isEmpty || sku.isEmpty || !const {'bazaar', 'myket'}.contains(store) || !pendingTokens.add(token)) continue;
      if (StoreConfig.productBySku(sku) == null) continue;
      cleanPendingConsumes.add({'token': token, 'sku': sku, 'store': store});
      if (cleanPendingConsumes.length >= 32) break;
    }
    pendingStoreConsumes = cleanPendingConsumes;
    sfxVolume = sfxVolume.clamp(0.0, 1.0).toDouble();
  }

  void addCoins(int amount) => coins = (coins + amount).clamp(0, 999999999).toInt();
  void addGems(int amount) => gems = (gems + amount).clamp(0, 999999999).toInt();

  bool spendCoins(int amount) {
    if (amount <= 0) return true;
    if (coins < amount) return false;
    coins -= amount;
    return true;
  }

  void addChest(String tier, [int amount = 1]) {
    if (!const ['bronze', 'silver', 'gold'].contains(tier) || amount <= 0) return;
    chests[tier] = (chests[tier] ?? 0) + amount;
  }

  void changeLeaguePoints(int delta) {
    _ensureSeason();
    leaguePoints = max(0, leaguePoints + delta).toInt();
  }

  void addXp(int amount) {
    xp += max(0, amount).toInt();
    while (xp >= xpToNext) {
      xp -= xpToNext;
      level++;
    }
  }

  void incMission(String key, [int amount = 1]) {
    _ensureMissionDay();
    if (!missionProgress.containsKey(key) || amount <= 0) return;
    missionProgress[key] = (missionProgress[key] ?? 0) + amount;
  }

  bool _claimMatchToken(String token) {
    final clean = token.trim();
    if (clean.isEmpty || settledMatchTokens.contains(clean)) return false;
    settledMatchTokens.add(clean);
    if (settledMatchTokens.length > 16) settledMatchTokens.removeAt(0);
    return true;
  }

  void _recordCompetitiveResult(MatchSummary summary) {
    stats['matches'] = (stats['matches'] ?? 0) + 1;
    if (summary.won) {
      stats['wins'] = (stats['wins'] ?? 0) + 1;
      stats['streak'] = (stats['streak'] ?? 0) + 1;
      stats['bestStreak'] = max(stats['bestStreak'] ?? 0, stats['streak'] ?? 0).toInt();
    } else {
      stats['losses'] = (stats['losses'] ?? 0) + 1;
      stats['streak'] = 0;
    }
    stats['bestRally'] = max(stats['bestRally'] ?? 0, summary.longestRally).toInt();
    incMission('play');
    if (summary.won) incMission('win');
    if (summary.longestRally >= 10) incMission('rally10');
    if ((summary.difficulty == 'hard' || summary.difficulty == 'pro') && summary.won) incMission('hardWin');
  }

  Future<MatchSettlement> settleMatch(MatchSummary summary, {Tournament? tournamentItem}) async {
    if (summary.mode == 'local') return MatchSettlement.local;
    if (summary.mode == 'practice') return MatchSettlement.practice;
    if (!EconomyBalance.isCompetitiveMode(summary.mode)) return MatchSettlement.practice;
    if (summary.mode == 'tournament' &&
        (tournamentItem == null || !tournaments.any((item) => item.id == tournamentItem.id))) {
      return MatchSettlement.duplicate;
    }
    if (!_claimMatchToken(summary.token)) return MatchSettlement.duplicate;

    _recordCompetitiveResult(summary);
    late final MatchSettlement settlement;
    if (summary.mode == 'tournament') {
      settlement = EconomyBalance.tournamentMatch(summary, tournamentItem!);
      addXp(settlement.xp);
      if (settlement.coins > 0) addCoins(settlement.coins);
      if (settlement.chestTier != null) addChest(settlement.chestTier!);
      if (settlement.kind == MatchSettlementKind.tournamentAdvance) {
        tournament = {'activeId': tournamentItem.id, 'round': settlement.nextRound ?? 1};
      } else if (settlement.kind == MatchSettlementKind.tournamentChampion ||
          settlement.kind == MatchSettlementKind.tournamentEliminated) {
        tournament = {'activeId': null, 'round': 0};
      }
    } else {
      settlement = EconomyBalance.standardMatch(summary);
      addXp(settlement.xp);
      addCoins(settlement.coins);
      changeLeaguePoints(settlement.leagueDelta);
    }
    await save();
    return settlement;
  }

  bool _openingChest = false;

  Future<ChestOpenResult?> openChest(String tier, {Random? random}) async {
    if (_openingChest || !const {'bronze', 'silver', 'gold'}.contains(tier) || (chests[tier] ?? 0) <= 0) return null;
    _openingChest = true;
    try {
      final rng = random ?? Random.secure();
      chests[tier] = (chests[tier] ?? 0) - 1;
      final ranges = switch (tier) {
        'silver' => (80, 160, 1, 3, .25, const ['rare', 'epic']),
        'gold' => (150, 300, 3, 6, .45, const ['epic', 'legendary']),
        _ => (30, 80, 0, 1, .10, const ['common', 'rare']),
      };
      var coinsWon = ranges.$1 + rng.nextInt(ranges.$2 - ranges.$1 + 1);
      final gemsWon = ranges.$3 == 0
          ? (rng.nextDouble() < .25 ? 1 : 0)
          : ranges.$3 + rng.nextInt(ranges.$4 - ranges.$3 + 1);
      addCoins(coinsWon);
      addGems(gemsWon);

      String? itemName;
      var duplicate = false;
      if (rng.nextDouble() < ranges.$5) {
        final pool = Catalog.all.where((item) => item.price > 0 && ranges.$6.contains(item.rarity)).toList();
        if (pool.isNotEmpty) {
          final item = pool[rng.nextInt(pool.length)];
          itemName = item.name;
          if (owned.contains(item.id)) {
            duplicate = true;
            addCoins(EconomyBalance.duplicateItemCoins);
          } else {
            owned.add(item.id);
          }
        }
      }
      incMission('chest');
      await audio.play('coin');
      await save();
      return ChestOpenResult(coins: coinsWon, gems: gemsWon, itemName: itemName, duplicateItem: duplicate);
    } finally {
      _openingChest = false;
    }
  }


  Future<bool> applyStorePurchase(StoreProduct product, StoreReceipt receipt) async {
    if (!StoreConfig.isConfigured) return false;
    final canonical = StoreConfig.productBySku(receipt.sku);
    if (canonical == null || canonical.id != product.id || canonical.sku != product.sku) return false;

    final token = receipt.token.trim();
    final expectedPayloadPrefix = 'zarbu:${canonical.id}:';
    if (token.isEmpty || receipt.store != StoreConfig.activeStore.name || !receipt.payload.startsWith(expectedPayloadPrefix)) return false;

    final alreadyProcessed = processedStorePurchaseTokens.contains(token);
    if (!alreadyProcessed) {
      processedStorePurchaseTokens.add(token);
      addCoins(canonical.coins);
      addGems(canonical.gems);
      await audio.play('coin');
    }

    if (!pendingStoreConsumes.any((item) => item['token'] == token)) {
      pendingStoreConsumes.add({'token': token, 'sku': canonical.sku, 'store': receipt.store});
    }
    await save();
    return !alreadyProcessed;
  }

  Future<void> markStorePurchaseConsumed(String token) async {
    final before = pendingStoreConsumes.length;
    pendingStoreConsumes.removeWhere((item) => item['token'] == token);
    if (pendingStoreConsumes.length != before) await save();
  }

  Future<int> recoverPendingStoreConsumes() async {
    if (!StoreConfig.isConfigured || pendingStoreConsumes.isEmpty) return 0;
    if (!billing.ready && !await billing.initialize()) return 0;
    var recovered = 0;
    for (final item in List<Map<String, dynamic>>.from(pendingStoreConsumes)) {
      final token = '${item['token'] ?? ''}';
      final sku = '${item['sku'] ?? ''}';
      final store = '${item['store'] ?? ''}';
      final consumed = await billing.recoverConsume(store: store, sku: sku, token: token);
      if (consumed) {
        pendingStoreConsumes.removeWhere((entry) => entry['token'] == token);
        recovered++;
      }
    }
    if (recovered > 0) await save();
    return recovered;
  }

  Future<bool> buy(Item item) async {
    final catalogItem = Catalog.findById(item.id);
    if (catalogItem == null || owned.contains(catalogItem.id) || !spendCoins(catalogItem.price)) return false;
    owned.add(catalogItem.id);
    await audio.play('coin');
    await save();
    return true;
  }

  Future<void> equip(Item item) async {
    final catalogItem = Catalog.findById(item.id);
    if (catalogItem == null || !owned.contains(catalogItem.id) || !const ['racket', 'ball', 'arena'].contains(catalogItem.type)) return;
    selected[catalogItem.type] = catalogItem.id;
    await save();
  }

  bool ownsAvatar(int value) => ownedAvatars.contains(value.clamp(0, avatars.length - 1).toInt());

  Future<bool> buyAvatar(int value) async {
    final index = value.clamp(0, avatars.length - 1).toInt();
    final spec = avatars[index];
    if (!ownsAvatar(index)) {
      if (spec.isPremium && !spendCoins(spec.price)) return false;
      ownedAvatars.add(index);
      ownedAvatars = ownedAvatars.toSet().toList()..sort();
      if (spec.isPremium) await audio.play('coin');
    }
    avatar = index;
    await save();
    return true;
  }

  Future<void> updateName(String value) async {
    final clean = value.trim().replaceAll(RegExp(r'[<>{}]'), '');
    if (clean.length < 2 || clean.length > 16) return;
    name = clean;
    await save();
  }

  Future<void> setAvatar(int value) async {
    final index = value.clamp(0, avatars.length - 1).toInt();
    if (!ownsAvatar(index)) return;
    avatar = index;
    await save();
  }

  Future<void> setTheme(String value) async {
    themeId = Themes.byId(value).id;
    await save();
  }

  Future<void> setSetting({double? sensitivityValue, String? qualityValue, bool? trailValue, bool? soundValue, double? sfxVolumeValue, bool? hapticsValue}) async {
    if (sensitivityValue != null) sensitivity = sensitivityValue.clamp(.6, 2.0).toDouble();
    if (qualityValue != null && const ['low', 'medium', 'high'].contains(qualityValue)) quality = qualityValue;
    if (trailValue != null) trail = trailValue;
    if (soundValue != null) sound = soundValue;
    if (sfxVolumeValue != null) sfxVolume = sfxVolumeValue.clamp(0.0, 1.0).toDouble();
    if (hapticsValue != null) haptics = hapticsValue;
    await save();
  }

  Future<void> updateMatchSetup(Map<String, dynamic> setup) async {
    matchSetup = {...matchSetup, ...setup};
    _sanitizeState();
    await save();
  }

  Future<bool> registerTournament(Tournament item) async {
    if (tournament['activeId'] != null) return false;
    if (!tournaments.any((entry) => entry.id == item.id)) return false;
    if (!spendCoins(item.entry)) return false;
    tournament = {'activeId': item.id, 'round': 1};
    await save();
    return true;
  }

  Future<void> abandonTournament() async {
    tournament = {'activeId': null, 'round': 0};
    await save();
  }

  Future<bool> claimMission(Mission mission) async {
    _ensureMissionDay();
    if (!missions.any((item) => item.id == mission.id)) return false;
    if (claimed[mission.id] == true || (missionProgress[mission.key] ?? 0) < mission.target) return false;
    claimed[mission.id] = true;
    final rewardCoins = mission.reward['coins'];
    final rewardGems = mission.reward['gems'];
    final rewardChest = mission.reward['chest'];
    if (rewardCoins is int) addCoins(rewardCoins);
    if (rewardGems is int) addGems(rewardGems);
    if (rewardChest is String) addChest(rewardChest);
    await audio.play('coin');
    await save();
    return true;
  }

  Future<bool> addFriend(String value) async {
    final clean = value.trim().replaceAll(RegExp(r'[<>{}]'), '');
    if (clean.length < 2 || clean.length > 16 || friends.length >= 20) return false;
    if (friends.any((friend) => '${friend['name']}'.trim().toLowerCase() == clean.toLowerCase())) return false;
    friends.add({
      'id': 'local_${DateTime.now().microsecondsSinceEpoch}',
      'name': clean,
      'local': true,
    });
    await save();
    return true;
  }

  Future<void> removeFriend(String friendId) async {
    friends.removeWhere((friend) => '${friend['id']}' == friendId);
    await save();
  }

  Future<void> resetData() async {
    await storage.reset();
    name = 'بازیکن';
    avatar = 0;
    themeId = 'dark';
    level = 1;
    xp = 0;
    coins = EconomyBalance.startingCoins;
    gems = EconomyBalance.startingGems;
    selected = {'racket': 'r_default', 'ball': 'b_default', 'arena': 'a_default'};
    owned = ['r_default', 'b_default', 'a_default'];
    ownedAvatars = [0, 1];
    chests = {'bronze': 1, 'silver': 0, 'gold': 0};
    missionProgress = {'play': 0, 'win': 0, 'rally10': 0, 'power': 0, 'hardWin': 0, 'chest': 0};
    claimed = {};
    missionDay = _dayNow();
    stats = {'matches': 0, 'wins': 0, 'losses': 0, 'bestRally': 0, 'streak': 0, 'bestStreak': 0, 'powerCollected': 0};
    leaguePoints = 0;
    season = _seasonNow();
    tournament = {'activeId': null, 'round': 0};
    friends = [];
    settledMatchTokens = [];
    processedStorePurchaseTokens = [];
    pendingStoreConsumes = [];
    matchSetup = {'mode': 'quick', 'difficulty': 'medium', 'orientation': 'portrait', 'entry': 0};
    sensitivity = 1;
    quality = 'medium';
    trail = true;
    sound = true;
    sfxVolume = .8;
    haptics = true;
    await save();
  }

  @override
  void dispose() {
    unawaited(billing.dispose());
    super.dispose();
  }
}

