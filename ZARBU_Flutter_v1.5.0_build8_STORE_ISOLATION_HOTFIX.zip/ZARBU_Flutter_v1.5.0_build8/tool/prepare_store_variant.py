#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

DEPENDENCIES = {
    'offline': None,
    'bazaar': 'flutter_poolakey: ^2.2.0+1.0.0',
    'myket': 'myket_iap: ^1.1.11',
}

if len(sys.argv) != 3:
    raise SystemExit('usage: prepare_store_variant.py <project-root> <offline|bazaar|myket>')

root = Path(sys.argv[1]).resolve()
store = sys.argv[2].strip().lower()
if store not in DEPENDENCIES:
    raise SystemExit(f'unsupported store variant: {store}')

pubspec_path = root / 'pubspec.yaml'
backend_path = root / 'lib/core/store/store_billing_backend.dart'
template_path = root / f'tool/store_variants/{store}_backend.dart.txt'

if not pubspec_path.is_file() or not template_path.is_file():
    raise SystemExit('store variant prerequisites are missing')

pubspec = pubspec_path.read_text(encoding='utf-8')
# Never allow both native billing SDKs in a single Flutter dependency graph.
pubspec = re.sub(r'(?m)^\s{2}(?:flutter_poolakey|myket_iap):[^\n]*\n?', '', pubspec)
dependency = DEPENDENCIES[store]
if dependency:
    marker = '  path_provider: ^2.1.3\n'
    if marker not in pubspec:
        raise SystemExit('cannot locate dependency insertion marker in pubspec.yaml')
    pubspec = pubspec.replace(marker, marker + f'  {dependency}\n', 1)

pubspec_path.write_text(pubspec, encoding='utf-8')
backend_path.write_text(template_path.read_text(encoding='utf-8'), encoding='utf-8')

active = [name for name in ('flutter_poolakey', 'myket_iap') if re.search(rf'(?m)^\s{{2}}{name}:', pubspec)]
expected = [] if store == 'offline' else (['flutter_poolakey'] if store == 'bazaar' else ['myket_iap'])
if active != expected:
    raise SystemExit(f'invalid dependency isolation for {store}: {active}')

print(f'Prepared ZARBU store variant: {store}')
print(f'Native billing dependencies: {active or ["none"]}')
