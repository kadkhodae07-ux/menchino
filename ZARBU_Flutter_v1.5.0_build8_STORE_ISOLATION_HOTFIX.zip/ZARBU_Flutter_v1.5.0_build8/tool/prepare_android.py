#!/usr/bin/env python3
from pathlib import Path
import json
import re
import shutil
import sys
from urllib.parse import unquote, urlparse

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
android = root / 'android'
app = android / 'app'
release = root / 'release'
package_id = 'mk.kadkhodai.zarbu'

if not android.exists() or not app.exists():
    raise SystemExit('Android project is missing.')
if not (release / 'bazikhone_release_key.jks').is_file():
    raise SystemExit('Release keystore is missing.')
if not (release / 'key.properties').is_file():
    raise SystemExit('Release key.properties is missing.')

shutil.copy2(release / 'bazikhone_release_key.jks', android / 'bazikhone_release_key.jks')
props = (release / 'key.properties').read_text(encoding='utf-8')
props = re.sub(r'(?m)^storeFile=.*$', 'storeFile=../bazikhone_release_key.jks', props)
(android / 'key.properties').write_text(props, encoding='utf-8')

kts = app / 'build.gradle.kts'
groovy = app / 'build.gradle'

if kts.exists():
    text = kts.read_text(encoding='utf-8')
    text = re.sub(r'namespace\s*=\s*"[^"]+"', f'namespace = "{package_id}"', text)
    text = re.sub(r'applicationId\s*=\s*"[^"]+"', f'applicationId = "{package_id}"', text)
    text = text.replace('JavaVersion.VERSION_11', 'JavaVersion.VERSION_21')
    text = text.replace('JavaVersion.VERSION_17', 'JavaVersion.VERSION_21')

    required_imports = [
        'import java.io.FileInputStream',
        'import java.util.Properties',
    ]
    for required_import in reversed(required_imports):
        if required_import not in text:
            text = required_import + '\n' + text

    canonical_props_block = '''val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    FileInputStream(keystorePropertiesFile).use { stream ->
        keystoreProperties.load(stream)
    }
}

'''

    if 'val keystoreProperties = Properties()' not in text:
        legacy_props_pattern = re.compile(
            r'val\s+keystoreProperties\s*=\s*(?:java\.util\.)?Properties\(\)\s*\n'
            r'val\s+keystorePropertiesFile\s*=\s*rootProject\.file\("key\.properties"\)\s*\n'
            r'if\s*\(keystorePropertiesFile\.exists\(\)\)\s*\{\s*\n'
            r'\s*keystorePropertiesFile\.inputStream\(\)\.use\s*\{\s*keystoreProperties\.load\(it\)\s*\}\s*\n'
            r'\}\s*\n\s*'
        )
        text, replaced = legacy_props_pattern.subn(canonical_props_block, text, count=1)
        if replaced == 0:
            text = text.replace('android {', canonical_props_block + 'android {', 1)

    if 'jvmToolchain(21)' not in text:
        text = text.replace('android {', 'kotlin {\n    jvmToolchain(21)\n}\n\nandroid {', 1)

    if 'marketApplicationId' not in text:
        placeholders = (
            '            manifestPlaceholders["marketApplicationId"] = "ir.mservices.market"\n'
            '            manifestPlaceholders["marketBindAddress"] = "ir.mservices.market.InAppBillingService.BIND"\n'
            '            manifestPlaceholders["marketPermission"] = "ir.mservices.market.BILLING"'
        )
        text, count = re.subn(r'(defaultConfig\s*\{)', r'\1\n' + placeholders, text, count=1)
        if count == 0:
            raise SystemExit('Could not add Myket manifest placeholders to Kotlin build file.')

    if 'create("release")' not in text:
        signing = '''    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }

'''
        text = text.replace('    buildTypes {', signing + '    buildTypes {', 1)

    text = re.sub(
        r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
        'signingConfig = signingConfigs.getByName("release")',
        text,
    )
    if 'signingConfig = signingConfigs.getByName("release")' not in text:
        text, count = re.subn(
            r'(buildTypes\s*\{\s*(?:getByName\("release"\)|release)\s*\{)',
            r'\1\n            signingConfig = signingConfigs.getByName("release")',
            text,
            count=1,
        )
        if count == 0:
            raise SystemExit('Could not bind release build type to release signing config.')
    kts.write_text(text, encoding='utf-8')

elif groovy.exists():
    text = groovy.read_text(encoding='utf-8')
    text = re.sub(r'namespace\s+["\'][^"\']+["\']', f'namespace "{package_id}"', text)
    text = re.sub(r'applicationId\s+["\'][^"\']+["\']', f'applicationId "{package_id}"', text)
    text = text.replace('JavaVersion.VERSION_11', 'JavaVersion.VERSION_21')
    text = text.replace('JavaVersion.VERSION_17', 'JavaVersion.VERSION_21')

    if 'keystoreProperties = new Properties()' not in text:
        prefix = '''def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

'''
        text = prefix + text

    if 'jvmToolchain(21)' not in text:
        text = text.replace('android {', 'kotlin {\n    jvmToolchain(21)\n}\n\nandroid {', 1)

    if 'marketApplicationId' not in text:
        placeholders = '''            manifestPlaceholders += [
                    marketApplicationId: "ir.mservices.market",
                    marketBindAddress: "ir.mservices.market.InAppBillingService.BIND",
                    marketPermission: "ir.mservices.market.BILLING"
            ]'''
        text, count = re.subn(r'(defaultConfig\s*\{)', r'\1\n' + placeholders, text, count=1)
        if count == 0:
            raise SystemExit('Could not add Myket manifest placeholders to Groovy build file.')

    if 'signingConfigs {' not in text:
        signing = '''    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }

'''
        text = text.replace('    buildTypes {', signing + '    buildTypes {', 1)

    text = re.sub(r'signingConfig\s+signingConfigs\.debug', 'signingConfig signingConfigs.release', text)
    if 'signingConfig signingConfigs.release' not in text:
        text, count = re.subn(
            r'(buildTypes\s*\{\s*release\s*\{)',
            r'\1\n            signingConfig signingConfigs.release',
            text,
            count=1,
        )
        if count == 0:
            raise SystemExit('Could not bind release build type to release signing config.')
    groovy.write_text(text, encoding='utf-8')
else:
    raise SystemExit('android/app/build.gradle(.kts) is missing.')

# Bazaar Poolakey needs JitPack while Flutter-generated repositories stay intact.
root_kts = android / 'build.gradle.kts'
root_groovy = android / 'build.gradle'
settings_kts = android / 'settings.gradle.kts'
settings_groovy = android / 'settings.gradle'

def add_jitpack_to_settings(path: Path, *, kotlin: bool) -> bool:
    if not path.exists():
        return False
    text = path.read_text(encoding='utf-8')
    if 'dependencyResolutionManagement' not in text:
        return False
    if 'https://jitpack.io' in text:
        return True
    anchor = text.find('dependencyResolutionManagement')
    repo_pos = text.find('repositories {', anchor)
    if repo_pos < 0:
        return False
    insert_pos = repo_pos + len('repositories {')
    line = '\n        maven { url = uri("https://jitpack.io") }' if kotlin else "\n        maven { url 'https://jitpack.io' }"
    text = text[:insert_pos] + line + text[insert_pos:]
    path.write_text(text, encoding='utf-8')
    return True

used_settings_repo = add_jitpack_to_settings(settings_kts, kotlin=True) or add_jitpack_to_settings(settings_groovy, kotlin=False)
if not used_settings_repo:
    if root_kts.exists():
        root_text = root_kts.read_text(encoding='utf-8')
        if 'https://jitpack.io' not in root_text:
            root_text += '\nallprojects {\n    repositories {\n        maven { url = uri("https://jitpack.io") }\n    }\n}\n'
        root_kts.write_text(root_text, encoding='utf-8')
    elif root_groovy.exists():
        root_text = root_groovy.read_text(encoding='utf-8')
        if 'https://jitpack.io' not in root_text:
            root_text += "\nallprojects {\n    repositories {\n        maven { url 'https://jitpack.io' }\n    }\n}\n"
        root_groovy.write_text(root_text, encoding='utf-8')
    else:
        raise SystemExit('android/build.gradle(.kts) is missing.')

# flutter_poolakey 2.2.0+1.0.0 still ships an Android build script with
# jcenter() and old AGP/Kotlin classpaths. Align its isolated pub-cache copy
# with the versions generated by this pinned Flutter SDK. This does not change
# ZARBU runtime/payment logic; it only makes the third-party Android build file
# compatible with the current Gradle toolchain used by CI.
def resolve_package_root(package_name: str) -> Path | None:
    package_config = root / '.dart_tool' / 'package_config.json'
    if not package_config.is_file():
        raise SystemExit('Dart package_config.json is missing; run flutter pub get first.')
    data = json.loads(package_config.read_text(encoding='utf-8'))
    for item in data.get('packages', []):
        if item.get('name') != package_name:
            continue
        raw_uri = item.get('rootUri', '')
        parsed = urlparse(raw_uri)
        if parsed.scheme == 'file':
            return Path(unquote(parsed.path)).resolve()
        return (package_config.parent / unquote(raw_uri)).resolve()
    return None

settings_text = ''
for candidate in (settings_kts, settings_groovy):
    if candidate.exists():
        settings_text += candidate.read_text(encoding='utf-8') + '\n'

agp_patterns = (
    r'id\("com\.android\.application"\)\s+version\s+"([^"]+)"',
    r'id\s+["\']com\.android\.application["\']\s+version\s+["\']([^"\']+)["\']',
)
kotlin_patterns = (
    r'id\("org\.jetbrains\.kotlin\.android"\)\s+version\s+"([^"]+)"',
    r'id\s+["\']org\.jetbrains\.kotlin\.android["\']\s+version\s+["\']([^"\']+)["\']',
)

def first_match(patterns: tuple[str, ...], text: str, label: str) -> str:
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1)
    raise SystemExit(f'Could not determine generated {label} version.')

agp_version = first_match(agp_patterns, settings_text, 'AGP')
kotlin_version = first_match(kotlin_patterns, settings_text, 'Kotlin')
poolakey_root = resolve_package_root('flutter_poolakey')
if poolakey_root is not None:
    poolakey_gradle = poolakey_root / 'android' / 'build.gradle'
    if not poolakey_gradle.is_file():
        raise SystemExit('flutter_poolakey Android build.gradle is missing.')
    poolakey_text = poolakey_gradle.read_text(encoding='utf-8')
    poolakey_text = poolakey_text.replace('jcenter()', 'mavenCentral()')
    poolakey_text = re.sub(
        r'ext\.kotlin_version\s*=\s*["\'][^"\']+["\']',
        f'ext.kotlin_version = "{kotlin_version}"',
        poolakey_text,
    )
    poolakey_text = re.sub(
        r'classpath\s+["\']com\.android\.tools\.build:gradle:[^"\']+["\']',
        f'classpath "com.android.tools.build:gradle:{agp_version}"',
        poolakey_text,
    )
    poolakey_gradle.write_text(poolakey_text, encoding='utf-8')
    if 'jcenter()' in poolakey_text:
        raise SystemExit('flutter_poolakey compatibility patch failed: jcenter() remains.')
    if f'com.android.tools.build:gradle:{agp_version}' not in poolakey_text:
        raise SystemExit('flutter_poolakey compatibility patch failed: AGP version was not aligned.')
    if f'ext.kotlin_version = "{kotlin_version}"' not in poolakey_text:
        raise SystemExit('flutter_poolakey compatibility patch failed: Kotlin version was not aligned.')
    print(f'Poolakey build compatibility patched: AGP {agp_version}, Kotlin {kotlin_version}, jcenter -> mavenCentral.')
else:
    print('Poolakey build compatibility patch: not required for this isolated store variant.')

manifest = app / 'src' / 'main' / 'AndroidManifest.xml'
if manifest.exists():
    manifest_text = manifest.read_text(encoding='utf-8')
    manifest_text = re.sub(r'android:label="[^"]*"', 'android:label="ZARBU"', manifest_text, count=1)
    manifest.write_text(manifest_text, encoding='utf-8')

joined = ''
for candidate in (kts, groovy):
    if candidate.exists():
        joined += candidate.read_text(encoding='utf-8')
if package_id not in joined:
    raise SystemExit('Package ID verification failed.')
if 'release' not in joined or 'keystoreProperties' not in joined:
    raise SystemExit('Release signing configuration verification failed.')
if 'marketApplicationId' not in joined or 'jvmToolchain(21)' not in joined:
    raise SystemExit('Myket billing Android configuration verification failed.')

repository_joined = ''
for candidate in (root_kts, root_groovy, settings_kts, settings_groovy):
    if candidate.exists():
        repository_joined += candidate.read_text(encoding='utf-8')
if 'https://jitpack.io' not in repository_joined:
    raise SystemExit('Bazaar Poolakey JitPack repository verification failed.')

print('Android identity, release signing, and store billing prerequisites prepared.')
