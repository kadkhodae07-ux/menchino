#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required." >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

flutter create --platforms=android --org mk.kadkhodai --project-name zarbu "$TMP/zarbu"
rm -rf "$TMP/zarbu/lib" "$TMP/zarbu/test"
cp -R "$ROOT/lib" "$TMP/zarbu/lib"
cp -R "$ROOT/test" "$TMP/zarbu/test"
cp "$ROOT/pubspec.yaml" "$TMP/zarbu/pubspec.yaml"
cp "$ROOT/analysis_options.yaml" "$TMP/zarbu/analysis_options.yaml"
rm -rf "$ROOT/android"
cp -R "$TMP/zarbu/android" "$ROOT/android"
cp "$TMP/zarbu/.metadata" "$ROOT/.metadata"
cp "$TMP/zarbu/.gitignore" "$ROOT/.gitignore"
python3 "$ROOT/tool/prepare_android.py" "$ROOT"

echo "Android platform files generated in $ROOT/android"
