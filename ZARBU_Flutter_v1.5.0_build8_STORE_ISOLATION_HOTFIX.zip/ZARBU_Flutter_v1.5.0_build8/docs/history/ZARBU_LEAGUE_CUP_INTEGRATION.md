# ZARBU League Cup integration

- Official ZARBU League cup asset added at `assets/images/zarbu_league_cup.png`.
- Original transparent PNG bytes preserved without recompression.
- Registered in `pubspec.yaml`.
- Ranking/league hero trophy replaced with the official ZARBU League cup.
- Existing generic rank icon remains as the runtime fallback if the asset cannot load.
- Workflow is unchanged for this asset-only integration.
