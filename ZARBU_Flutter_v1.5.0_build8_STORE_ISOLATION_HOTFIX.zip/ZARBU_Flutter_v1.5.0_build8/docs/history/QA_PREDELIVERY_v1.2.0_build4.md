# QA PRE-DELIVERY — ZARBU v1.2.0+4

## Checked before packaging
- Version: 1.2.0+4
- Package ID source contract: mk.kadkhodai.zarbu
- Release keystore and key.properties present.
- Workflow hash unchanged from the previously supplied RUN135-fixed workflow.
- Workflow YAML parses successfully.
- Workflow contains flutter analyze, flutter test, release APK build, package-id verification and APK signature verification.
- 10 avatar PNG files present and referenced as Flutter assets.
- All avatar files have an alpha channel and transparent pixels.
- No runtime reference to the old CustomPainter/test avatar implementation remains.
- Dart source lightweight structural scan: balanced delimiters, strings and comments across all Dart files.
- Added tests for catalog/avatar/tournament invariants, economy guardrails, XP/league rules and game target-score rules.

## Environment limitation
The current execution container does not include a Flutter/Dart SDK, so `flutter analyze`, `flutter test`, and an actual local APK compile could not be executed here. The unchanged GitHub Actions workflow performs all three before it accepts the release artifact.
