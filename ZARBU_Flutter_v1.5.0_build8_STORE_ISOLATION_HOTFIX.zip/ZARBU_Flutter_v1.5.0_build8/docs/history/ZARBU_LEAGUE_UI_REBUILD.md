# ZARBU LEAGUE + UI REBUILD

- Brand: ZARBU / ضربو
- Package ID: mk.kadkhodai.zarbu
- Single league only: لیگ ضربو
- Official ZARBU cup used
- Professional Top 3 podium and unified leaderboard
- League data model separated for future API
- Three-layer nested frames removed from shared UI
- Volumetric press depth retained
- Lobby cards press with audio/haptics
- Gameplay engine unchanged
- Fixed release keystore reference bundled from user package
