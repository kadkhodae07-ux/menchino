# ZARBU v1.4.0+7 — QA Matrix

این ماتریس تفاوت بین کنترل‌های قابل اجرای آفلاین در محیط فعلی و Gateهایی که در GitHub Actions با Flutter SDK اجرا می‌شوند را مشخص می‌کند.

| حوزه | کنترل | وضعیت/محل اجرا |
|---|---|---|
| Source integrity | Release Gate اختصاصی | PASS در بررسی محلی؛ دوباره در Workflow اجرا می‌شود |
| Dart structure | بررسی Lexical delimiter/string | PASS در بررسی محلی |
| Workflow | YAML parse | PASS در بررسی محلی |
| Package | `mk.kadkhodai.zarbu` | Release Gate + Workflow Verify |
| Signing | Keystore موجود + APK signature | فایل موجود؛ امضای APK در Workflow Verify می‌شود |
| Assets | 10 Avatar PNG با Alpha | Release Gate |
| League cup | Asset موجود و ثبت‌شده در pubspec | Release Gate |
| Demo cleanup | Chat/Fake payment/Placeholder runtime ممنوع | Release Gate |
| Match settlement | یک مسیر مرکزی + Match Token | Unit tests + Release Gate |
| Practice/Local farming | Reward پایدار صفر | Unit tests |
| Paid entry | Win/Loss/Retry/Refund-before-start | Unit tests + Gameplay flow |
| Tournament | Advance/Champion/Elimination | Unit tests |
| League | یک لیگ + Gender mapping | Unit tests |
| Physics health | NaN/Stall/overspeed recovery | Unit tests |
| Pause | Elapsed هنگام Pause جلو نرود | Unit tests |
| Restart | Token جدید | Unit tests |
| Economy | deterministic reward cases | Unit tests |
| Storage | migration + serialized writes | Source gate / CI testable |
| Audio | lazy init + non-blocking failures | Source gate + Flutter tests |
| Analyze | `flutter analyze` | GitHub Actions V6 |
| Tests | `flutter test --reporter expanded` | GitHub Actions V6 |
| Release APK | `flutter build apk --release` | GitHub Actions V6 |
| APK size | <= 85 MiB sanity threshold | GitHub Actions V6 |
| Install/Upgrade | Clean install + update روی نسخه قبلی | نیازمند APK ساخته‌شده و تست دستگاه واقعی |
| Store IAP | Bazaar/Myket real purchase | نیازمند RSA/Public key + SKU واقعی پنل؛ در RC1 مخفی است |

## سناریوهای دستگاه واقعی بعد از اولین APK موفق RC1

1. Clean install و ورود به تمام صفحات.
2. Quick در Easy/Medium/Hard حداقل یک برد و یک باخت.
3. Challenge برد/باخت و کنترل LP/XP/Coin.
4. Pause حداقل 30 ثانیه، Background/Foreground، سپس Resume.
5. خروج وسط Quick و کنترل ثبت دقیق یک باخت.
6. Rematch سه بار متوالی و کنترل عدم Duplicate reward.
7. Local دو نفره و Practice؛ موجودی/XP/LP نباید تغییر کند.
8. Tournament از ثبت‌نام تا قهرمانی/حذف.
9. خرید چند Item و Avatar، بستن Force Stop و بازکردن مجدد.
10. بازکردن صندوق و Claim مأموریت؛ Force Stop و بررسی عدم Rollback.
11. Portrait و Landscape با حداقل یک مسابقه کامل در هر حالت.
12. تست صدا 0%، میانی، 100% و Mute؛ Haptic روشن/خاموش.
13. Upgrade از Build قبلی با Save موجود؛ سطح/موجودی/مالکیت باید حفظ شود.
