# ZARBU Offline Release Candidate 1

نسخه: `1.4.0+7`
Package ID: `mk.kadkhodai.zarbu`
وضعیت: Offline RC1 — هسته آنلاین/Matchmaking در این نسخه فعال نیست.

## هدف این نسخه

این نسخه به‌جای Patchهای جداگانه، مسیرهای مشترک بازی را یکپارچه می‌کند تا اقتصاد، نتیجه مسابقه، ذخیره‌سازی، مأموریت‌ها، لیگ و فروشگاه از منبع حقیقت واحد استفاده کنند.

## 1) QA و پایداری مسابقه

- Pause/Resume به Ticker واقعی متصل شده تا زمان مخفی هنگام Pause/Background وارد Physics نشود.
- برگشت از Background بازی را خودکار Pause می‌کند و ادامه فقط با اقدام بازیکن انجام می‌شود.
- Rematch یک Match Token جدید می‌گیرد و نتیجه قبلی دوباره قابل ثبت نیست.
- خروج از مسابقه رقابتی یک‌بار به‌عنوان باخت ثبت می‌شود؛ خروج Practice/Local نتیجه اقتصادی ندارد.
- Restart در حالت رقابتی حذف شده تا Reset برای دورزدن نتیجه/ورودی قابل سوءاستفاده نباشد.
- ورودی مسابقه پولی در Retry دوباره محاسبه می‌شود و قبل از شروع واقعی، در صورت خروج اولیه Refund می‌شود.
- Engine برای Ball State غیرعددی، سرعت بسیار کم یا سرعت خارج از سقف Recover/Clamp دارد.
- منطق عادی برخورد، امتیازدهی، زاویه راکت و فیزیک اصلی بازطراحی نشده است.

## 2) پاک‌سازی Demo/Test/Placeholder

- Chat نمایشی و Persistence مربوط به آن حذف شده است.
- مسیرهای Runtime با TODO/FIXME/Placeholder/«به‌زودی» توسط Release Gate ممنوع شده‌اند.
- خرید نقدی نمایشی از فروشگاه حذف شده؛ چیزی که کار نمی‌کند به کاربر نمایش داده نمی‌شود.
- داده‌های دوستان تستی قدیمی هنگام Load پاک می‌شوند.

## 3) لیگ ضربو

- فقط یک لیگ: «لیگ ضربو».
- نگاشت جنسیت نام‌های Rival با Avatarهای دختر/پسر اصلاح و با Test قفل شده است.
- LP از مسیر مرکزی نتیجه مسابقه تغییر می‌کند و منفی نمی‌شود.
- Season و Ranking محلی حفظ می‌شوند.
- کاپ اختصاصی ZARBU در Asset و Release Gate کنترل می‌شود.

## 4) اقتصاد و پیشرفت

- Match Reward در `EconomyBalance` مرکزی شده است.
- Practice و Local هیچ Reward/XP/LP پایدار تولید نمی‌کنند.
- Quick/Challenge مسیر رقابتی و League Point دارند.
- Tournament پاداش Advance/Champion/Elimination مشخص دارد.
- Coin bonus سقف دارد تا ترکیب تجهیزات اقتصاد را نشکند.
- خرید تجهیزات قیمت واقعی Catalog را دوباره Resolve می‌کند و به Object ورودی UI اعتماد نمی‌کند.
- صندوق فقط Item پولی را Drop می‌کند؛ Duplicate به Compensation سکه تبدیل می‌شود.
- Mission/XP/Level و Save بعد از تغییرات از AppState مرکزی عبور می‌کنند.

## 5) فروشگاه

- تجهیزات و Avatarها با مالکیت پایدار و خرید واقعی با سکه داخلی بازی فعال‌اند.
- تب پرداخت نقدی نمایشی حذف شده است.
- فعال‌سازی Bazaar/Myket به ورودی‌های واقعی پنل انتشار نیاز دارد؛ جزئیات در `STORE_BILLING_REQUIREMENTS.md` آمده است.

## 6) صدا و حس بازی

- AudioPlayerها Lazy ساخته می‌شوند تا Test و Bootstrap به Platform Channel زودهنگام وابسته نباشند.
- Pool صوتی برای افکت‌های کوتاه استفاده می‌شود.
- Fail شدن Audio نباید Bootstrap بازی را متوقف کند.
- Mute و Volume افکت‌ها ذخیره می‌شوند.
- Hapticهای Gameplay و UI از Setting کاربر تبعیت می‌کنند.

## 7) Release Hardening

- Saveهای همزمان Serialize شده‌اند تا Write قدیمی روی Write جدید Overwrite نشود.
- Migration از کلید Save قدیمی `phong_flutter_v1` به `zarbu_flutter_v1` وجود دارد.
- Runtime debug state/painter حذف شده است.
- Workflow V6 پیش از Analyze/Test/Build، Release Gate اختصاصی پروژه را اجرا می‌کند.
- Workflow Package ID و APK Signature را Verify می‌کند.
- APK Size sanity gate برای جلوگیری از ورود ناخواسته Cache/Media بزرگ اضافه شده است.
- Release Keystore ثابت پروژه حفظ شده است.

## محدودیت صریح RC1

Online Matchmaking/Backend در این نسخه وجود ندارد. همچنین پرداخت نقدی Bazaar/Myket تا زمانی که RSA/Public Key و SKUهای واقعی همین برنامه از پنل‌ها ارائه نشوند فعال نمی‌شود؛ UI جعلی نیز نمایش داده نمی‌شود.
