# ZARBU v1.4.0+7 — Pre-delivery Verification

## کنترل‌های اجراشده در محیط فعلی

- Release Gate اختصاصی پروژه: **PASS**
- Workflow V6 YAML parse: **PASS**
- Workflow داخلی سورس و Workflow خارجی بسته: **قابل Parse**
- Dart lexical structure scan روی تمام فایل‌های Dart: **PASS**
- Python helper scripts syntax: **PASS**
- Runtime forbidden markers (Chat/Fake payment/TODO/FIXME/Placeholder/«به‌زودی»): **PASS**
- Runtime debug state/painter: **حذف شده**
- Package ID contract: `mk.kadkhodai.zarbu`
- Release keystore: **موجود**
- Avatar PNG count: **10**
- Avatar alpha capability: **PASS**
- League cup asset: **موجود**
- Source workflow count: **1** (V6)
- Economy representative simulations: **PASS**
- Source ZIP cache/build pollution guard: **فعال**

## کنترل‌های تعریف‌شده برای GitHub Actions V6

این موارد به Flutter SDK/Android toolchain نیاز دارند و در محیط فعلی محلی اجرا نشده‌اند؛ Workflow قبل از تولید APK آن‌ها را اجباری اجرا می‌کند:

1. `flutter pub get`
2. `flutter analyze`
3. `flutter test --reporter expanded`
4. `flutter build apk --release`
5. Verify Package ID
6. Verify APK Signature
7. APK size sanity gate
8. Upload APK یا Diagnostics کامل در Failure

## تست‌های Flutter موجود در سورس

- `balance_test.dart`
- `data_test.dart`
- `engine_rules_test.dart`
- `league_test.dart`
- `settlement_state_test.dart`
- `state_rules_test.dart`
- `storage_service_test.dart`

## نکته پرداخت مارکت

پرداخت نقدی نمایشی در RC1 وجود ندارد. فعال‌سازی واقعی Bazaar/Myket به داده‌های واقعی پنل همان برنامه نیاز دارد و باید در فاز Billing با تست واقعی Store انجام شود. قرارداد لازم در `STORE_BILLING_REQUIREMENTS.md` ثبت شده است.
