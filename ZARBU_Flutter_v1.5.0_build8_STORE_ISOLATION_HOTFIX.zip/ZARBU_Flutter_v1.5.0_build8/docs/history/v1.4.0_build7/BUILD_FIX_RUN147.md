# ZARBU Run 147 Build Fix

- Root cause: `dart:math max()` caused `baseCoins` to be inferred as `num` in the centralized economy settlement.
- Fix: explicitly normalize the player-gold term to `int` before the arithmetic chain.
- Also removed one analyzer-only redundant non-null assertion with no behavior change.
- No UI, game physics, league rules, store rules, save schema, package ID, signing key, or workflow behavior was changed.
- Release version remains 1.4.0+7 because Run 147 did not produce a releasable APK.
