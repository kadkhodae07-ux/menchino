# تاریخچه تغییرات ZARBU

این پوشه فقط برای نگهداری گزارش‌های نسخه‌ها و Fixهای قدیمی است. هیچ فایل این پوشه در Runtime یا Build منطق بازی استفاده نمی‌شود.

برای وضعیت Release فعلی به فایل‌های ریشه پروژه مراجعه شود:
- `README_FA.md`
- `OFFLINE_RELEASE_CANDIDATE_v1.4.0_build7.md`
- `QA_MATRIX_v1.4.0_build7.md`
- `PREDELIVERY_VERIFICATION_v1.4.0_build7.md`
