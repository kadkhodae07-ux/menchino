# ZARBU v1.2.0+4 — First Five Completion Stages

Implemented without redesigning the existing game UI:

1. Game modes
- Quick, Challenge, Practice, Local 2-player, and Tournament flows retained and hardened.
- Local friendly matches no longer grant coins, XP, league points, or mission farming progress.
- Match entry spending uses a guarded transaction and retry re-checks balance.

2. Economy and rewards
- Guarded coin spending prevents negative/over-spend transactions.
- Daily missions reset by local calendar day and claims are transactional.
- Chest inventory is sanitized and persisted.
- Tournament champions now receive Bronze/Silver/Gold chests by tournament tier.
- Duplicate/empty chest item reward pool has a safe coin fallback.

3. Zarbu League
- Single Zarbu League remains the only league.
- League points stay limited to competitive Quick/Challenge results.
- Monthly season reset remains intact.

4. Profile and progression
- XP/level and saved statistics are normalized on load.
- Invalid/corrupted saved values are clamped or repaired safely.
- Avatar ownership and selected avatar remain persistent.

5. Shop
- Equipment and avatar ownership are persisted and validated.
- Invalid selected/owned catalog IDs are cleaned on load.
- Purchases use guarded coin spending.
- Real Bazaar/Myket currency billing remains intentionally deferred; the existing display-only currency packs are unchanged.

UI redesign: none.
Core paddle/ball physics rules: unchanged.
