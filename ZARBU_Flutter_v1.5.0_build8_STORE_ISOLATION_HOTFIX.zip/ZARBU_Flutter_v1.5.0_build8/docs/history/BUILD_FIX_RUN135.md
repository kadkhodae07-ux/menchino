# ZARBU build fix — run 135

- Root cause: `android/app/build.gradle.kts` used `java.util.Properties()` after the Android plugin was applied. Under AGP 9 / Gradle 9, `java` is also a DSL symbol and the script failed to resolve `java.util`.
- Fix: `prepare_android.py` now injects explicit `java.io.FileInputStream` and `java.util.Properties` imports and uses a canonical typed keystore-loading block.
- Flutter is pinned to 3.44.9 in Workflow V5 for reproducible Android template generation.
- Package ID remains `mk.kadkhodai.zarbu`; release keystore remains unchanged.
- App version: `1.1.0+3`.
