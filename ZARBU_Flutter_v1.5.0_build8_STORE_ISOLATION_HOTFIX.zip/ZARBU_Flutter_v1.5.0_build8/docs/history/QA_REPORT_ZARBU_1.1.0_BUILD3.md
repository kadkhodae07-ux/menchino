# ZARBU v1.1.0+3 — QA REPORT

| Check | Result |
|---|---|
| Package ID | PASS — `mk.kadkhodai.zarbu` |
| Release keystore payload | PASS — unchanged from build2/reference |
| League tests from run 135 | PASS — 5/5 |
| Flutter analyze from run 135 | PASS for build gate — info/warnings only |
| Run 135 root cause | FIXED — Kotlin DSL `java.util.Properties()` resolution |
| Kotlin DSL signing injection | PASS — explicit `Properties` + `FileInputStream` imports |
| Workflow reproducibility | PASS — Flutter pinned to 3.44.9 |
| Workflow syntax/static checks | PASS |
| Full Android build in this environment | NOT RUN — Flutter SDK unavailable locally; GitHub Actions performs Analyze/Test/Build/Package/Signature verification |
