# ZARBU v1.5.0+8 — QA Matrix

| حوزه | کنترل | محل اجرا | وضعیت پیش از تحویل سورس |
|---|---|---|---|
| ساختار Release | Release Gate | Local static + GitHub | آماده |
| Python tooling | py_compile | Local/CI | آماده |
| Workflow | YAML parse | Local | آماده |
| Flutter Analyze | `flutter analyze` | GitHub Actions V7 | اجباری در CI |
| Unit/logic tests | `flutter test` | GitHub Actions V7 | اجباری در CI |
| Offline APK | Release build | GitHub Actions V7 | اجباری در CI |
| Bazaar APK | Release build با RSA واقعی | GitHub Actions V7 | شرطی |
| Myket APK | Release build با RSA واقعی | GitHub Actions V7 | شرطی |
| Package ID | APK inspection | GitHub Actions V7 | اجباری |
| Signature | apksigner/jarsigner | GitHub Actions V7 | اجباری |
| APK size | <= 90 MiB | GitHub Actions V7 | اجباری |
| Save migration | automated state tests | Flutter test | پوشش داده شده |
| Duplicate settlement | automated tests | Flutter test | پوشش داده شده |
| Store SKU config | automated test | Flutter test | پوشش داده شده |
| Purchase double-grant | token ledger + canonical grant tests | Flutter test در حالت Bazaar/Myket | پوشش داده شده در CI |
| Avatar assets | WebP/alpha/count | Release Gate | اجباری |
| Pause/Resume | real device | دستگاه واقعی | بعد از APK |
| Background/Foreground | real device | دستگاه واقعی | بعد از APK |
| Portrait/Landscape | real device | دستگاه واقعی | بعد از APK |
| Rematch/Exit | real device | دستگاه واقعی | بعد از APK |
| Easy/Medium/Hard | real device | دستگاه واقعی | بعد از APK |
| Powerups/FX/Haptic/Audio | real device | دستگاه واقعی | بعد از APK |
| Store checkout | test account + installed market | دستگاه واقعی | نیازمند تنظیم پنل |
| Consume/rebuy | test account + installed market | دستگاه واقعی | نیازمند تنظیم پنل |

## سناریوی QA دستگاه پس از Build سبز

1. Clean install و اجرای اولیه.
2. بازی Quick در هر سه Difficulty و ثبت یک برد/باخت.
3. Challenge و Tournament تا پایان.
4. Practice حداقل ۵ دقیقه و تایید عدم تغییر لیگ/پاداش رقابتی.
5. Local دو نفره و تایید عدم فارم Economy.
6. Pause/Resume، رفتن Background و برگشت.
7. Rematch چندباره و خروج وسط مسابقه.
8. Portrait و Landscape.
9. خرید و Equip هر نوع Item و بستن/بازکردن اپ.
10. صندوق، مأموریت، XP و League persistence.
11. Store build: قیمت‌گیری، Purchase، Grant، Consume و Re-purchase.
12. قطع اینترنت بین Grant و Consume و تایید Recovery بدون Double Grant.
13. نصب Update روی نسخه قبلی و کنترل حفظ Save.

هیچ موردی که نیازمند APK و دستگاه واقعی است در این سند به‌عنوان «انجام‌شده» علامت‌گذاری نشده است؛ CI و تست فیزیکی دو Gate مستقل هستند.
