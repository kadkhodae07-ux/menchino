# ZARBU Asset Optimization Report

- Format: transparent WebP
- Quality: 92
- Maximum dimension: 512 px
- Aspect ratio: preserved
- Flutter layout and game logic: unchanged

| Asset | Before PNG | After WebP | Output size |
|---|---:|---:|---|
| `assets/images/avatars/01_default_male.webp` | 1,568,158 B | 60,132 B | 512×512 (RGBA) |
| `assets/images/avatars/02_default_female.webp` | 891,149 B | 83,542 B | 512×512 (RGBA) |
| `assets/images/avatars/03_premium_male.webp` | 2,043,472 B | 103,416 B | 512×512 (RGBA) |
| `assets/images/avatars/04_premium_female.webp` | 1,971,783 B | 114,676 B | 512×512 (RGBA) |
| `assets/images/avatars/05_premium_male_visor.webp` | 1,945,915 B | 94,638 B | 512×512 (RGBA) |
| `assets/images/avatars/06_premium_female_commander.webp` | 1,965,047 B | 89,572 B | 512×512 (RGBA) |
| `assets/images/avatars/07_premium_male_masked.webp` | 284,583 B | 72,420 B | 418×430 (RGBA) |
| `assets/images/avatars/08_premium_female_gamer.webp` | 2,234,716 B | 130,758 B | 512×512 (RGBA) |
| `assets/images/avatars/09_premium_male_dual_neon.webp` | 1,924,279 B | 109,400 B | 512×512 (RGBA) |
| `assets/images/avatars/10_premium_female_armor.webp` | 2,013,010 B | 98,082 B | 512×512 (RGBA) |
| `assets/images/zarbu_league_cup.webp` | 2,316,651 B | 50,606 B | 410×512 (RGBA) |

- Total before: **19,158,763 bytes (18.27 MiB)**
- Total after: **1,007,242 bytes (0.96 MiB)**
- Reduction: **94.74%**
