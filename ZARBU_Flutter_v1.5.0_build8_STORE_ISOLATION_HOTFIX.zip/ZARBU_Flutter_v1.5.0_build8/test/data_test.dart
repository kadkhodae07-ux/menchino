import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/data.dart';
import 'package:zarbu/core/theme.dart';

void main() {
  test('catalog identifiers are unique', () {
    final ids = Catalog.all.map((item) => item.id).toList();
    expect(ids.toSet().length, ids.length);
  });

  test('default equipment exists', () {
    expect(Catalog.byId('r_default').type, 'racket');
    expect(Catalog.byId('b_default').type, 'ball');
    expect(Catalog.byId('a_default').type, 'arena');
  });

  test('all themes have unique identifiers', () {
    expect(Themes.all.map((theme) => theme.id).toSet().length, Themes.all.length);
  });

  test('avatar catalog contains two defaults and eight premium avatars', () {
    expect(avatars.length, 10);
    expect(avatars.take(2).every((avatar) => !avatar.isPremium), isTrue);
    expect(avatars.skip(2).every((avatar) => avatar.isPremium), isTrue);
    expect(avatars.map((avatar) => avatar.assetPath).toSet().length, avatars.length);
  });

  test('tournament definitions are valid and unique', () {
    expect(tournaments.map((item) => item.id).toSet().length, tournaments.length);
    for (final item in tournaments) {
      expect(item.entry, greaterThanOrEqualTo(0));
      expect(item.prize, greaterThan(item.entry));
      expect(item.rounds, greaterThan(0));
    }
  });
}
