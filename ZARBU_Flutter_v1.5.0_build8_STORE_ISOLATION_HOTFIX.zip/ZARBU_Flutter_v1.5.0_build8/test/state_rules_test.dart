import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/balance.dart';
import 'package:zarbu/core/state/app_state.dart';

void main() {
  test('coin spending never overspends', () {
    final state = AppState();
    expect(state.coins, EconomyBalance.startingCoins);
    expect(state.spendCoins(100), isTrue);
    expect(state.coins, EconomyBalance.startingCoins - 100);
    expect(state.spendCoins(999999), isFalse);
    expect(state.coins, EconomyBalance.startingCoins - 100);
  });

  test('default avatar ownership contains only free defaults initially', () {
    final state = AppState();
    expect(state.ownedAvatars, containsAll(<int>[0, 1]));
    expect(state.ownsAvatar(0), isTrue);
    expect(state.ownsAvatar(1), isTrue);
    expect(state.ownsAvatar(2), isFalse);
  });

  test('xp progression carries overflow into next level', () {
    final state = AppState();
    state.addXp(120);
    expect(state.level, 2);
    expect(state.xp, 20);
  });

  test('league points cannot become negative', () {
    final state = AppState();
    state.changeLeaguePoints(-50);
    expect(state.leaguePoints, 0);
    state.changeLeaguePoints(EconomyBalance.winLeaguePoints);
    expect(state.leaguePoints, EconomyBalance.winLeaguePoints);
  });

  test('sound volume has a safe production default', () {
    final state = AppState();
    expect(state.sfxVolume, inInclusiveRange(0.0, 1.0));
    expect(state.sound, isTrue);
  });
}
