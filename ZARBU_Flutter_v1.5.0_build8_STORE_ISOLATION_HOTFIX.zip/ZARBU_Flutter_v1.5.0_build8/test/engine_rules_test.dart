import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/state/app_state.dart';
import 'package:zarbu/game/engine.dart';

void main() {
  Engine makeEngine(
    String mode, {
    bool twoPlayer = false,
    String orientation = 'portrait',
    String difficulty = 'medium',
  }) =>
      Engine(
        state: AppState(),
        mode: mode,
        difficulty: difficulty,
        orientation: orientation,
        entry: 0,
        twoPlayer: twoPlayer,
      );

  test('quick mode uses seven-point target', () {
    expect(makeEngine('quick').targetScore, 7);
  });

  test('challenge and tournament use five-point target', () {
    expect(makeEngine('challenge').targetScore, 5);
    expect(makeEngine('tournament').targetScore, 5);
  });

  test('local mode is configured as two-player when requested', () {
    expect(makeEngine('local', twoPlayer: true).twoPlayer, isTrue);
  });

  test('portrait and landscape resize keep paddle axes valid', () {
    final portrait = makeEngine('quick');
    portrait.resize(420, 860);
    expect(portrait.bottom.width, greaterThan(portrait.bottom.height));
    expect(portrait.top.width, greaterThan(portrait.top.height));

    final landscape = makeEngine('quick', orientation: 'landscape');
    landscape.resize(860, 420);
    expect(landscape.bottom.height, greaterThan(landscape.bottom.width));
    expect(landscape.top.height, greaterThan(landscape.top.width));
  });

  test('every restart gets a new settlement token', () {
    final engine = makeEngine('quick');
    engine.resize(420, 860);
    engine.start();
    final first = engine.matchToken;
    engine.restart();
    expect(first, isNotEmpty);
    expect(engine.matchToken, isNot(first));
  });

  test('paused game does not advance simulation time', () {
    final engine = makeEngine('quick');
    engine.resize(420, 860);
    engine.start();
    engine.phase = 'playing';
    engine.setPaused(true);
    final before = engine.elapsed;
    engine.update(1 / 60);
    expect(engine.elapsed, before);
  });

  test('stalled ball is healed without changing normal scoring rules', () {
    final engine = makeEngine('quick');
    engine.resize(420, 860);
    engine.start();
    engine.phase = 'playing';
    engine.ball.vx = 0;
    engine.ball.vy = 0;
    engine.update(1 / 60);
    expect(engine.hypot, greaterThanOrEqualTo(120));
  });

  test('non-finite ball state is recovered safely', () {
    final engine = makeEngine('quick');
    engine.resize(420, 860);
    engine.start();
    engine.phase = 'playing';
    engine.ball.x = double.nan;
    engine.update(1 / 60);
    expect(engine.ball.x.isFinite, isTrue);
    expect(engine.ball.y.isFinite, isTrue);
    expect(engine.hypot.isFinite, isTrue);
  });
}
