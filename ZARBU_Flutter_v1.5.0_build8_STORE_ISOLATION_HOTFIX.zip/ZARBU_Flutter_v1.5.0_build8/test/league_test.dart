import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/league.dart';

void main() {
  test('ZARBU uses one league identity', () {
    final snapshot = buildLocalZarbuLeague(
      userName: 'بازیکن',
      userAvatar: 0,
      userPoints: 100,
    );
    expect(snapshot.leagueName, 'لیگ ضربو');
  });

  test('leaderboard is sorted by league points', () {
    final snapshot = buildLocalZarbuLeague(
      userName: 'بازیکن',
      userAvatar: 0,
      userPoints: 3000,
    );
    expect(snapshot.players.first.isCurrentUser, isTrue);
    for (var i = 1; i < snapshot.players.length; i++) {
      expect(snapshot.players[i - 1].points >= snapshot.players[i].points, isTrue);
    }
  });

  test('offline league rival names use matching avatar gender', () {
    final snapshot = buildLocalZarbuLeague(
      userName: 'بازیکن',
      userAvatar: 0,
      userPoints: 100,
    );
    const femaleNames = {'رها', 'آوا', 'هلیا', 'نیلا'};
    const maleNames = {'آرین', 'کیان', 'سام', 'رادین'};
    for (final player in snapshot.players.where((item) => !item.isCurrentUser)) {
      if (femaleNames.contains(player.name)) expect(player.avatar.isOdd, isTrue, reason: player.name);
      if (maleNames.contains(player.name)) expect(player.avatar.isEven, isTrue, reason: player.name);
    }
  });
}
