import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/balance.dart';
import 'package:zarbu/core/data.dart';

MatchSummary summary({
  String mode = 'quick',
  String difficulty = 'medium',
  bool won = true,
  int bottomScore = 7,
  int topScore = 4,
  int rally = 9,
  int gold = 0,
  double coinBonus = 0,
  int entry = 0,
  int round = 1,
}) =>
    MatchSummary(
      token: 'test-token',
      mode: mode,
      difficulty: difficulty,
      won: won,
      bottomScore: bottomScore,
      topScore: topScore,
      longestRally: rally,
      playerGold: gold,
      coinBonus: coinBonus,
      entry: entry,
      tournamentRound: round,
    );

void main() {
  test('practice and local modes never generate persistent standard rewards', () {
    expect(EconomyBalance.standardMatch(summary(mode: 'practice')).kind, MatchSettlementKind.practice);
    expect(EconomyBalance.standardMatch(summary(mode: 'local')).kind, MatchSettlementKind.local);
  });

  test('ranked win rewards and league delta are deterministic', () {
    final result = EconomyBalance.standardMatch(summary());
    expect(result.kind, MatchSettlementKind.standard);
    expect(result.xp, 63);
    expect(result.baseCoins, 27);
    expect(result.coins, 27);
    expect(result.leagueDelta, EconomyBalance.winLeaguePoints);
  });

  test('paid entry has a controlled win return and full loss risk', () {
    final win = EconomyBalance.standardMatch(summary(entry: 100));
    final loss = EconomyBalance.standardMatch(summary(won: false, bottomScore: 4, topScore: 7, entry: 100));
    expect(win.entryPrize, 150);
    expect(loss.entryPrize, 0);
    expect(loss.leagueDelta, EconomyBalance.lossLeaguePoints);
  });

  test('coin bonus is capped to prevent runaway stacked equipment rewards', () {
    final capped = EconomyBalance.standardMatch(summary(coinBonus: 99));
    final maxExpected = EconomyBalance.standardMatch(summary(coinBonus: .75));
    expect(capped.baseCoins, maxExpected.baseCoins);
  });

  test('tournament progression, champion reward and elimination are deterministic', () {
    final tournament = tournaments.first;
    final advance = EconomyBalance.tournamentMatch(summary(mode: 'tournament', round: 1), tournament);
    final champion = EconomyBalance.tournamentMatch(summary(mode: 'tournament', round: tournament.rounds), tournament);
    final eliminated = EconomyBalance.tournamentMatch(
      summary(mode: 'tournament', won: false, bottomScore: 2, topScore: 5, round: 1),
      tournament,
    );

    expect(advance.kind, MatchSettlementKind.tournamentAdvance);
    expect(advance.nextRound, 2);
    expect(champion.kind, MatchSettlementKind.tournamentChampion);
    expect(champion.coins, tournament.prize);
    expect(champion.chestTier, 'bronze');
    expect(eliminated.kind, MatchSettlementKind.tournamentEliminated);
  });
}
