import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zarbu/core/balance.dart';
import 'package:zarbu/core/data.dart';
import 'package:zarbu/core/state/app_state.dart';

MatchSummary _summary({
  required String token,
  String mode = 'quick',
  bool won = true,
  int bottomScore = 7,
  int topScore = 4,
  int round = 1,
}) =>
    MatchSummary(
      token: token,
      mode: mode,
      difficulty: 'medium',
      won: won,
      bottomScore: bottomScore,
      topScore: topScore,
      longestRally: 9,
      playerGold: 0,
      coinBonus: 0,
      entry: 0,
      tournamentRound: round,
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<AppState> stateForTest() async {
    SharedPreferences.setMockInitialValues({});
    final state = AppState();
    await state.storage.init();
    return state;
  }

  test('the same competitive match token settles exactly once', () async {
    final state = await stateForTest();
    final first = await state.settleMatch(_summary(token: 'match-1'));
    final afterFirstCoins = state.coins;
    final afterFirstXp = state.xp;
    final afterFirstLp = state.leaguePoints;
    final afterFirstMatches = state.stats['matches'];

    final duplicate = await state.settleMatch(_summary(token: 'match-1'));

    expect(first.kind, MatchSettlementKind.standard);
    expect(duplicate.kind, MatchSettlementKind.duplicate);
    expect(state.coins, afterFirstCoins);
    expect(state.xp, afterFirstXp);
    expect(state.leaguePoints, afterFirstLp);
    expect(state.stats['matches'], afterFirstMatches);
  });

  test('practice never mutates persistent progression', () async {
    final state = await stateForTest();
    final before = (state.coins, state.xp, state.leaguePoints, state.stats['matches']);

    final result = await state.settleMatch(_summary(token: 'practice-1', mode: 'practice'));
    final after = (state.coins, state.xp, state.leaguePoints, state.stats['matches']);

    expect(result.kind, MatchSettlementKind.practice);
    expect(after, before);
  });

  test('catalog price cannot be bypassed by a forged Item object', () async {
    final state = await stateForTest();
    final target = Catalog.rackets.firstWhere((item) => item.price > 0);
    state.coins = target.price + 50;
    final forged = Item(
      target.id,
      target.type,
      target.name,
      target.rarity,
      target.icon,
      target.desc,
      0,
    );

    final bought = await state.buy(forged);

    expect(bought, isTrue);
    expect(state.coins, 50);
    expect(state.owned, contains(target.id));
  });

  test('tournament final settles once and clears active tournament', () async {
    final state = await stateForTest();
    final tournament = tournaments.first;
    state.tournament = {'activeId': tournament.id, 'round': tournament.rounds};

    final result = await state.settleMatch(
      _summary(token: 't-final', mode: 'tournament', bottomScore: 5, topScore: 2, round: tournament.rounds),
      tournamentItem: tournament,
    );

    expect(result.kind, MatchSettlementKind.tournamentChampion);
    expect(state.tournament['activeId'], isNull);
    expect(state.chests[result.chestTier], greaterThanOrEqualTo(1));
  });
}
