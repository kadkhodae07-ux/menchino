import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zarbu/core/state/app_state.dart';
import 'package:zarbu/core/store/store_config.dart';
import 'package:zarbu/core/store/store_product.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<AppState> stateForTest() async {
    SharedPreferences.setMockInitialValues({});
    final state = AppState();
    await state.storage.init();
    return state;
  }

  test('configured store receipt grants exactly once and queues consume', () async {
    if (!StoreConfig.isConfigured) {
      expect(StoreConfig.activeStore, ZarbuStore.offline);
      return;
    }

    final state = await stateForTest();
    final product = StoreConfig.products.first;
    final beforeCoins = state.coins;
    final receipt = StoreReceipt(
      store: StoreConfig.activeStore.name,
      token: 'purchase-token-1',
      sku: product.sku,
      payload: 'zarbu:${product.id}:test',
    );

    final first = await state.applyStorePurchase(product, receipt);
    final afterFirstCoins = state.coins;
    final duplicate = await state.applyStorePurchase(product, receipt);

    expect(first, isTrue);
    expect(afterFirstCoins, beforeCoins + product.coins);
    expect(duplicate, isFalse);
    expect(state.coins, afterFirstCoins);
    expect(state.processedStorePurchaseTokens.where((token) => token == receipt.token).length, 1);
    expect(state.pendingStoreConsumes.where((item) => item['token'] == receipt.token).length, 1);

    await state.markStorePurchaseConsumed(receipt.token);
    expect(state.pendingStoreConsumes.where((item) => item['token'] == receipt.token), isEmpty);
  });

  test('mismatched sku or store never grants currency', () async {
    if (!StoreConfig.isConfigured) return;

    final state = await stateForTest();
    final product = StoreConfig.products.first;
    final before = (state.coins, state.gems);

    final wrongSku = StoreReceipt(
      store: StoreConfig.activeStore.name,
      token: 'wrong-sku-token',
      sku: 'not-${product.sku}',
      payload: 'test',
    );
    final wrongStore = StoreReceipt(
      store: StoreConfig.activeStore == ZarbuStore.bazaar ? 'myket' : 'bazaar',
      token: 'wrong-store-token',
      sku: product.sku,
      payload: 'test',
    );

    expect(await state.applyStorePurchase(product, wrongSku), isFalse);
    expect(await state.applyStorePurchase(product, wrongStore), isFalse);
    expect((state.coins, state.gems), before);
  });
  test('forged pack values cannot bypass canonical store grant', () async {
    if (!StoreConfig.isConfigured) return;

    final state = await stateForTest();
    final canonical = StoreConfig.products.first;
    final forged = StoreProduct(
      id: canonical.id,
      title: canonical.title,
      sku: canonical.sku,
      coins: canonical.coins + 999999,
      gems: canonical.gems + 999999,
    );
    final before = (state.coins, state.gems);
    final receipt = StoreReceipt(
      store: StoreConfig.activeStore.name,
      token: 'forged-value-token',
      sku: canonical.sku,
      payload: 'zarbu:${canonical.id}:forged-test',
    );

    expect(await state.applyStorePurchase(forged, receipt), isTrue);
    expect(state.coins, before.$1 + canonical.coins);
    expect(state.gems, before.$2 + canonical.gems);
  });

}
