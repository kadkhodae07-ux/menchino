import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/store/store_config.dart';

void main() {
  test('store catalog uses six unique canonical consumable SKUs', () {
    expect(StoreConfig.products.length, 6);
    final skus = StoreConfig.products.map((item) => item.sku).toSet();
    expect(skus.length, StoreConfig.products.length);
    expect(StoreConfig.products.every((item) => item.isValid), isTrue);
  });

  test('normal test build remains offline unless a store is explicitly selected', () {
    expect(StoreConfig.activeStore, ZarbuStore.offline);
    expect(StoreConfig.isConfigured, isFalse);
  });

  test('all store packs grant a positive amount exactly once by definition', () {
    for (final product in StoreConfig.products) {
      expect(product.coins + product.gems, greaterThan(0));
      expect(product.id.trim(), isNotEmpty);
      expect(product.sku.startsWith('zarbu_'), isTrue);
    }
  });
}
