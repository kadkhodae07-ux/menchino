import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zarbu/core/services/storage_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('legacy PHONG save migrates to the ZARBU key', () async {
    SharedPreferences.setMockInitialValues({
      'phong_flutter_v1': jsonEncode({'coins': 123, 'name': 'قدیمی'}),
    });
    final storage = StorageService();
    await storage.init();

    expect(storage.load()?['coins'], 123);
    expect(storage.load()?['name'], 'قدیمی');
  });

  test('queued writes preserve call order', () async {
    SharedPreferences.setMockInitialValues({});
    final storage = StorageService();
    await storage.init();

    final first = storage.save({'value': 1});
    final second = storage.save({'value': 2});
    await Future.wait([first, second]);

    expect(storage.load()?['value'], 2);
  });

  test('reset removes current and legacy saves', () async {
    SharedPreferences.setMockInitialValues({
      'phong_flutter_v1': jsonEncode({'value': 1}),
    });
    final storage = StorageService();
    await storage.init();
    await storage.save({'value': 2});
    await storage.reset();

    expect(storage.load(), isNull);
  });
}
