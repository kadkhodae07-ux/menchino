# ZARBU v1.5.0+8 — Final Candidate

## هدف نسخه

این نسخه، مبنای فریز هسته آفلاین ZARBU است. قابلیت آنلاین هنوز وارد این شاخه نشده است. پرداخت واقعی Bazaar/Myket به شکل Adapter مستقل به فروشگاه داخلی متصل شده تا هسته بازی برای اضافه‌کردن پرداخت بازنویسی نشود.

## بخش‌های نهایی‌شده

- مسابقه سریع، چالش، تمرین، دونفره محلی و تورنمنت
- Settlement مرکزی مسابقه و جلوگیری از ثبت دوباره نتیجه/پاداش
- اقتصاد مرکزی سکه/جم/XP/ورودی/پاداش
- مأموریت روزانه و صندوق‌ها
- لیگ اختصاصی ضربو و Reset فصل
- پروفایل، Level، XP و آمار
- فروشگاه راکت، توپ، آرنا و آواتار
- ۱۰ آواتار اختصاصی نئونی
- صدا، Haptic، Volume و ذخیره تنظیمات
- Save migration/sanitization و صف‌بندی Writeها
- پرداخت مصرفی Bazaar/Myket با Recovery و Exactly-once local grant
- Release Gate و Workflow نهایی چندخروجی

## جداسازی آفلاین و فروشگاهی

Build آفلاین با `ZARBU_STORE=offline` ساخته می‌شود و تب خرید نقدی را نشان نمی‌دهد. Build بازار یا مایکت فقط زمانی ساخته می‌شود که کلید واقعی همان مارکت در GitHub Actions Secret قرار گرفته باشد. هیچ RSA آزمایشی یا متعلق به اپ دیگر داخل سورس قرار ندارد.

## اصول Regression Control

- Engine و Settlement بازی از Billing مستقل‌اند.
- قیمت و مالکیت تجهیزات از Catalog مرکزی اعتبارسنجی می‌شود.
- اعتبار خرید نقدی فقط با SKU canonical قابل Grant است.
- Token مصرف‌شده دوباره Grant نمی‌شود.
- Save هم‌زمان به ترتیب نوشته می‌شود.
- Practice و Local برای فارم Economy/League استفاده نمی‌شوند.

## وضعیت Release

این بسته از نظر ساختار سورس و CI یک Final Candidate است. تایید APK نهایی منوط به پاس‌شدن GitHub Actions V7 و QA روی دستگاه واقعی برای APK تولیدشده است. تست واقعی Checkout بازار/مایکت نیز فقط با RSA، محصولات ثبت‌شده و حساب تست مارکت قابل انجام است.

- Build hotfix: Poolakey Gradle compatibility is aligned automatically with the pinned Flutter Android toolchain.
- Image assets: transparent WebP, optimized to max 512 px while preserving UI aspect ratios.

- Store isolation hotfix: Offline/Bazaar/Myket are built with mutually exclusive native billing dependencies to prevent duplicate billing classes.
