# PULSE ARENA — Build 14 Production Release Candidate

Version: `1.8.0+14`  
Workflow: `WF9`

Build 14 upgrades the entire game presentation and the transition/gameplay performance path.

## Main improvements

- New production-grade shared panel and button rendering with real depth and restrained highlights.
- Softer teal/rose/navy palette designed for longer play sessions.
- New professional arena-command background instead of the repetitive demo grid.
- Cached animated arena preview on Home.
- Faster Home-to-match transition with no artificial 100 ms delay and a 170 ms route transition.
- Earlier sustained-performance protection, lighter ball trail, fewer particles, and lower HUD rebuild frequency.
- All existing pages and game logic remain available.

## Build output

WF9 selects the newest valid Flutter source ZIP, validates release invariants, installs Flutter `3.41.8` and Java `17`, runs analysis and tests, then creates separate Bazaar and Myket release APKs. Failure logs are uploaded automatically.

See `BUILD14_PRODUCTION_POLISH_REPORT.txt` for the complete technical change list.
