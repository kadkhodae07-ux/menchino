import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/components/ball_controller.dart';
import 'package:pulse_arena/game/components/bot_paddle_controller.dart';
import 'package:pulse_arena/game/components/player_paddle_controller.dart';
import 'package:pulse_arena/game/config/game_config.dart';

void main() {
  BallController makeBall(GameConfig config) {
    return BallController(
      config: config,
      onPlayerScored: () {},
      onBotScored: () {},
      isShieldActive: () => false,
      consumeBoost: () {},
      isBoostArmed: () => false,
      matchElapsedSeconds: () => 0,
    );
  }

  test('resize preserves an active ball and its normalized position', () {
    const GameConfig config = GameConfig();
    final BallController ball = makeBall(config);

    ball.layout(const Rect.fromLTWH(10, 20, 800, 320));
    ball.position = Vector2(610, 100);
    ball.launch();

    ball.layout(const Rect.fromLTWH(20, 30, 1000, 400));

    expect(ball.active, isTrue);
    expect(ball.position.x, closeTo(770, 0.01));
    expect(ball.position.y, closeTo(130, 0.01));
  });

  test('launched ball advances on the next update frame', () {
    const GameConfig config = GameConfig(ballBaseSpeed: 600);
    final BallController ball = makeBall(config);
    final PlayerPaddleController player = PlayerPaddleController(moveSpeed: config.playerPaddleSpeed);
    final BotPaddleController bot = BotPaddleController(
      config: config,
      ball: ball,
      playerScore: () => 0,
      isPulseActive: () => false,
    );
    const Rect arena = Rect.fromLTWH(20, 20, 900, 360);
    player.layout(arena);
    bot.layout(arena);
    ball.attachPaddles(player, bot);
    ball.layout(arena);
    ball.resetToCenter(serveDirection: 1);
    final double before = ball.position.x;

    ball.launch();
    ball.update(0.05);

    expect(ball.active, isTrue);
    expect(ball.position.x, greaterThan(before));
    expect(ball.velocity.length, greaterThanOrEqualTo(config.ballBaseSpeed));
  });
}
