import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Build 14 launch path removes intentional transition latency', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();
    final String transition = File(
      'lib/game/managers/scene_transition_manager.dart',
    ).readAsStringSync();

    expect(hub, isNot(contains('Duration(milliseconds: 100)')));
    expect(hub, contains('_ambient.stop(canceled: false)'));
    expect(transition, contains('unawaited(OrientationManager.showGame())'));
    expect(transition, contains('Duration(milliseconds: 170)'));
    expect(transition, isNot(contains('Duration(milliseconds: 440)')));
  });

  test('Home preview caches static rendering and panels retain depth', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();

    expect(hub, contains('static Picture? _staticPicture'));
    expect(hub, contains('Picture _buildStatic(Size size)'));
    expect(hub, contains('final double lift = pressed ? 2.0 : 5.0'));
    expect(hub, contains('lowerEdge'));
    expect(hub, contains('class _HubBackgroundPainter'));
  });

  test('adaptive performance limits are production tuned', () {
    final String ball = File(
      'lib/game/components/ball_controller.dart',
    ).readAsStringSync();
    final String game = File(
      'lib/game/pulse_arena_game.dart',
    ).readAsStringSync();

    expect(ball, contains('iterations < 6'));
    expect(ball, contains('trailLimit = reducedEffects ? 4 : 8'));
    expect(game, contains('_slowFrameDebt < 18'));
    expect(game, contains('_uiAccumulator >= 0.25'));
  });
}
