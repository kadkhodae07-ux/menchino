#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

readonly GRADLE_VERSION="8.9"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

flutter create \
  --platforms=android \
  --android-language kotlin \
  --project-name pulse_arena \
  "$TMP_DIR/wrapper_seed"

SEED_ANDROID="$TMP_DIR/wrapper_seed/android"
mkdir -p android/gradle/wrapper
cp "$SEED_ANDROID/gradlew" android/gradlew
cp "$SEED_ANDROID/gradlew.bat" android/gradlew.bat
cp "$SEED_ANDROID/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
chmod +x android/gradlew

cat > android/gradle/wrapper/gradle-wrapper.properties <<PROPS
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-all.zip
PROPS

./android/gradlew --version
