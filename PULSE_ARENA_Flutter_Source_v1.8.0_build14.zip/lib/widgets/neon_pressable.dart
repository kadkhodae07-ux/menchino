import 'dart:async';

import 'package:flutter/material.dart';

import '../game/managers/audio_manager.dart';

class NeonPressable extends StatefulWidget {
  const NeonPressable({
    required this.builder,
    required this.onTap,
    super.key,
    this.pressedScale = 0.96,
    this.playSound = true,
    this.hapticFeedback = true,
    this.semanticLabel,
  });

  final Widget Function(BuildContext context, bool pressed) builder;
  final VoidCallback onTap;
  final double pressedScale;
  final bool playSound;
  final bool hapticFeedback;
  final String? semanticLabel;

  @override
  State<NeonPressable> createState() => _NeonPressableState();
}

class _NeonPressableState extends State<NeonPressable> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (_pressed == value || !mounted) return;
    setState(() => _pressed = value);
  }

  void _activate() {
    _setPressed(false);
    if (widget.playSound) {
      unawaited(AudioManager.instance.playButton());
    }
    if (widget.hapticFeedback) {
      unawaited(AudioManager.instance.lightImpact());
    }
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: widget.semanticLabel,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => _setPressed(true),
        onTapUp: (_) => _setPressed(false),
        onTapCancel: () => _setPressed(false),
        onTap: _activate,
        child: AnimatedScale(
          scale: _pressed ? widget.pressedScale : 1,
          duration: const Duration(milliseconds: 92),
          curve: Curves.easeOutCubic,
          child: widget.builder(context, _pressed),
        ),
      ),
    );
  }
}
