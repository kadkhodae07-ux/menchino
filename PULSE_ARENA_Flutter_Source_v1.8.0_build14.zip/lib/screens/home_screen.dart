import 'hub_screen.dart';

/// Compatibility entry point retained for older imports.
/// The complete production lobby now lives in [HubScreen].
class HomeScreen extends HubScreen {
  const HomeScreen({super.key});
}
