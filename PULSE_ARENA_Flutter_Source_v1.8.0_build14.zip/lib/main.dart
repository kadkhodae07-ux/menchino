import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/material.dart';

import 'app/pulse_arena_app.dart';
import 'core/orientation_manager.dart';
import 'game/managers/audio_manager.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await OrientationManager.showHome();

  FlameAudio.bgm.initialize();
  await AudioManager.instance.preload();

  runApp(const PulseArenaApp());
}
