import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient, RadialGradient;

class ArenaComponent extends PositionComponent {
  ArenaComponent({super.priority = -100});

  Rect arenaRect = Rect.zero;
  Rect playRect = Rect.zero;
  final List<Offset> _stars = <Offset>[];
  final math.Random _random = math.Random(4137);

  Picture? _staticPicture;
  Path _playClipPath = Path();
  Path _victoryBorderPath = Path();
  final Paint _scanPaint = Paint()..color = const Color(0x0C4FE7FF);
  final Paint _centerLinePaint = Paint()..strokeWidth = 1.35;
  final Paint _centerHaloPaint = Paint()..color = const Color(0x245F65FF);
  final Paint _centerCorePaint = Paint()..color = const Color(0xB8B8D7FF);
  final Paint _servePaint = Paint()..style = PaintingStyle.stroke;
  double _time = 0;
  double _goalFlash = 0;
  double _servePulse = 0;
  double _hitFlash = 0;
  double _rallyEnergy = 0;
  double _victoryGlow = 0;
  bool reducedEffects = false;
  bool _playerGoal = true;
  bool _playerHit = true;
  bool _perfectHit = false;

  void layout(Vector2 gameSize) {
    final double horizontal = (gameSize.x * 0.014).clamp(10.0, 20.0).toDouble();
    final double vertical = (gameSize.y * 0.020).clamp(6.0, 12.0).toDouble();
    arenaRect = Rect.fromLTRB(horizontal, vertical, gameSize.x - horizontal, gameSize.y - vertical);
    playRect = arenaRect.deflate((gameSize.y * 0.014).clamp(5.0, 9.0).toDouble());
    size = gameSize;
    final double playCut =
        (playRect.height * 0.036).clamp(11.0, 19.0).toDouble();
    _playClipPath = _chamferedRect(playRect, playCut);
    _victoryBorderPath = _chamferedRect(
      playRect.deflate(2),
      (playRect.height * 0.042).clamp(12.0, 22.0).toDouble(),
    );

    if (_stars.isEmpty) {
      for (int i = 0; i < 34; i++) {
        _stars.add(Offset(_random.nextDouble(), _random.nextDouble()));
      }
    }
    _buildStaticPicture();
  }

  void triggerGoal({required bool playerScored}) {
    _playerGoal = playerScored;
    _goalFlash = 1;
  }

  void triggerVictory() {
    _victoryGlow = 1;
  }

  void triggerServe() {
    _servePulse = 1;
  }

  void triggerHit({required bool playerHit, required bool perfect}) {
    _playerHit = playerHit;
    _perfectHit = perfect;
    _hitFlash = perfect ? 1.15 : 0.70;
  }

  void setRally(int rally) {
    final double target = (rally / 14).clamp(0.0, 1.0).toDouble();
    _rallyEnergy += (target - _rallyEnergy) * 0.12;
  }

  void resetEffects() {
    _goalFlash = 0;
    _servePulse = 0;
    _hitFlash = 0;
    _rallyEnergy = 0;
    _victoryGlow = 0;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double safeDt = dt.clamp(0.0, 0.05).toDouble();
    _time += safeDt;
    _goalFlash = math.max(0.0, _goalFlash - safeDt * 1.9);
    _servePulse = math.max(0.0, _servePulse - safeDt * 1.7);
    _hitFlash = math.max(0.0, _hitFlash - safeDt * 4.2);
    _rallyEnergy = math.max(0.0, _rallyEnergy - safeDt * 0.015);
  }

  void _buildStaticPicture() {
    if (size.x <= 0 || size.y <= 0 || arenaRect.isEmpty) return;
    final PictureRecorder recorder = PictureRecorder();
    final Canvas canvas = Canvas(recorder);
    final Rect full = Offset.zero & Size(size.x, size.y);

    canvas.drawRect(
      full,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF01040A), Color(0xFF071225), Color(0xFF160817)],
        ).createShader(full),
    );
    canvas.drawRect(
      full,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.72, -0.05),
          radius: 1.05,
          colors: <Color>[Color(0x3024CFFF), Color(0x0024CFFF)],
        ).createShader(full),
    );
    canvas.drawRect(
      full,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(0.78, 0.18),
          radius: 1.08,
          colors: <Color>[Color(0x2AFF3EAD), Color(0x00FF3EAD)],
        ).createShader(full),
    );

    final Paint starPaint = Paint()..color = const Color(0x759DEBFF);
    for (int i = 0; i < _stars.length; i++) {
      final Offset star = _stars[i];
      canvas.drawCircle(
        Offset(star.dx * size.x, star.dy * size.y),
        i % 8 == 0 ? 1.15 : 0.65,
        starPaint,
      );
    }

    final double outerCut = (arenaRect.height * 0.050).clamp(15.0, 26.0).toDouble();
    final double innerCut = (playRect.height * 0.036).clamp(11.0, 19.0).toDouble();
    final Path outer = _chamferedRect(arenaRect, outerCut);
    final Path inner = _chamferedRect(playRect, innerCut);

    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF073A52), Color(0xFF12192B), Color(0xFF4A1439)],
        ).createShader(arenaRect),
    );
    canvas.drawPath(
      inner,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 1.12,
          colors: <Color>[Color(0xFF111D32), Color(0xFF07101D), Color(0xFF02050B)],
        ).createShader(playRect),
    );

    canvas.save();
    canvas.clipPath(inner);
    _drawStaticFloor(canvas, playRect);
    _drawGoalZones(canvas, playRect);
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..color = const Color(0xFF617590),
    );
    canvas.drawLine(
      playRect.topLeft,
      playRect.bottomLeft,
      Paint()
        ..color = const Color(0x5538DFFF)
        ..strokeWidth = 9,
    );
    canvas.drawLine(
      playRect.topLeft,
      playRect.bottomLeft,
      Paint()
        ..color = const Color(0xFF55D4D0)
        ..strokeWidth = 2.7,
    );
    canvas.drawLine(
      playRect.topRight,
      playRect.bottomRight,
      Paint()
        ..color = const Color(0x55FF47AD)
        ..strokeWidth = 9,
    );
    canvas.drawLine(
      playRect.topRight,
      playRect.bottomRight,
      Paint()
        ..color = const Color(0xFFD96F9D)
        ..strokeWidth = 2.7,
    );

    _drawCornerAccents(canvas, arenaRect);
    _staticPicture?.dispose();
    _staticPicture = recorder.endRecording();
  }

  void _drawStaticFloor(Canvas canvas, Rect rect) {
    final Paint horizontal = Paint()
      ..strokeWidth = 0.75
      ..color = const Color(0x245D87C7);
    for (int i = 1; i < 9; i++) {
      final double y = rect.top + rect.height * i / 9;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), horizontal);
    }

    final Paint vertical = Paint()
      ..strokeWidth = 0.55
      ..color = const Color(0x1742CFFF);
    for (int i = 1; i < 15; i++) {
      final double x = rect.left + rect.width * i / 15;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), vertical);
    }

    final Rect vignette = rect.inflate(2);
    canvas.drawRect(
      vignette,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 0.94,
          colors: <Color>[Color(0x00000000), Color(0x5C000000)],
        ).createShader(vignette),
    );
  }

  void _drawGoalZones(Canvas canvas, Rect rect) {
    final double width = rect.width * 0.078;
    final Rect left = Rect.fromLTWH(rect.left, rect.top, width, rect.height);
    final Rect right = Rect.fromLTWH(rect.right - width, rect.top, width, rect.height);
    canvas.drawRect(
      left,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0x532DDEFF), Color(0x002DDEFF)],
        ).createShader(left),
    );
    canvas.drawRect(
      right,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
          colors: <Color>[Color(0x53FF42AD), Color(0x00FF42AD)],
        ).createShader(right),
    );
  }

  void _drawCornerAccents(Canvas canvas, Rect rect) {
    final double length = math.min(rect.width, rect.height) * 0.055;
    final Paint cyan = Paint()
      ..color = const Color(0xB638DFFF)
      ..strokeWidth = 2;
    final Paint pink = Paint()
      ..color = const Color(0xB6FF47AD)
      ..strokeWidth = 2;

    canvas.drawLine(rect.topLeft + const Offset(11, 0), rect.topLeft + Offset(11 + length, 0), cyan);
    canvas.drawLine(rect.bottomLeft + const Offset(11, 0), rect.bottomLeft + Offset(11 + length, 0), cyan);
    canvas.drawLine(rect.topRight - const Offset(11, 0), rect.topRight - Offset(11 + length, 0), pink);
    canvas.drawLine(rect.bottomRight - const Offset(11, 0), rect.bottomRight - Offset(11 + length, 0), pink);
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    if (_staticPicture != null) canvas.drawPicture(_staticPicture!);
    if (playRect.isEmpty) return;

    canvas.save();
    canvas.clipPath(_playClipPath);
    if (!reducedEffects) _drawMovingScan(canvas, playRect);
    _drawCenterGate(canvas, playRect);
    _drawServePulse(canvas, playRect);
    if (!reducedEffects) _drawHitFlash(canvas, playRect);
    _drawGoalFlash(canvas, playRect);
    _drawVictoryGlow(canvas, playRect);
    canvas.restore();
  }

  void _drawMovingScan(Canvas canvas, Rect rect) {
    final double scanX = rect.left + ((_time * 76) % (rect.width + 48)) - 24;
    canvas.drawRect(
      Rect.fromLTWH(scanX, rect.top, 22, rect.height),
      _scanPaint,
    );
  }

  void _drawCenterGate(Canvas canvas, Rect rect) {
    final double x = rect.center.dx;
    final double dash = (rect.height * 0.060).clamp(15.0, 24.0).toDouble();
    _centerLinePaint.color = const Color(0xFF7E84FF)
        .withValues(alpha: 0.36 + _rallyEnergy * 0.24);
    for (double y = rect.top + 10; y < rect.bottom; y += dash * 1.95) {
      canvas.drawLine(
        Offset(x, y),
        Offset(x, math.min(y + dash, rect.bottom - 8)),
        _centerLinePaint,
      );
    }

    final double pulse = 0.5 + 0.5 * math.sin(_time * 2.0);
    final Rect core = Rect.fromCenter(
      center: rect.center,
      width: 5.5 + pulse * 1.5,
      height: rect.height * (0.16 + _rallyEnergy * 0.03),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(core.inflate(2.5), const Radius.circular(6)),
      _centerHaloPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(core, const Radius.circular(5)),
      _centerCorePaint,
    );
  }

  void _drawServePulse(Canvas canvas, Rect rect) {
    if (_servePulse <= 0) return;
    final double progress = 1 - _servePulse;
    final double radius = rect.height * (0.035 + progress * 0.34);
    _servePaint
      ..strokeWidth = 3.0 * _servePulse + 0.7
      ..color = const Color(0xFFC9F4F0)
          .withValues(alpha: _servePulse * 0.62);
    canvas.drawCircle(rect.center, radius, _servePaint);
  }

  void _drawHitFlash(Canvas canvas, Rect rect) {
    if (_hitFlash <= 0) return;
    final Color color = _playerHit ? const Color(0xFF5ADBD5) : const Color(0xFFD96F9D);
    final Alignment begin = _playerHit ? Alignment.centerLeft : Alignment.centerRight;
    final Alignment end = _playerHit ? Alignment.centerRight : Alignment.centerLeft;
    final Rect half = Rect.fromLTWH(
      _playerHit ? rect.left : rect.center.dx,
      rect.top,
      rect.width / 2,
      rect.height,
    );
    canvas.drawRect(
      half,
      Paint()
        ..shader = LinearGradient(
          begin: begin,
          end: end,
          colors: <Color>[
            color.withValues(alpha: _hitFlash * 0.17),
            color.withValues(alpha: 0),
          ],
        ).createShader(half),
    );
    if (_perfectHit) {
      final double alpha = _hitFlash.clamp(0.0, 1.0).toDouble();
      canvas.drawCircle(
        Offset(_playerHit ? rect.left : rect.right, rect.center.dy),
        rect.height * (0.17 + (1 - alpha) * 0.18),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.7
          ..color = const Color(0xFFFFFFFF).withValues(alpha: alpha * 0.72),
      );
    }
  }

  void _drawGoalFlash(Canvas canvas, Rect rect) {
    if (_goalFlash <= 0) return;
    final bool right = _playerGoal;
    final Rect zone = Rect.fromLTWH(right ? rect.center.dx : rect.left, rect.top, rect.width / 2, rect.height);
    final Color color = right ? const Color(0xFF5ADBD5) : const Color(0xFFD96F9D);
    canvas.drawRect(
      zone,
      Paint()
        ..shader = LinearGradient(
          begin: right ? Alignment.centerLeft : Alignment.centerRight,
          end: right ? Alignment.centerRight : Alignment.centerLeft,
          colors: <Color>[
            color.withValues(alpha: 0),
            color.withValues(alpha: _goalFlash * 0.34),
          ],
        ).createShader(zone),
    );
  }

  void _drawVictoryGlow(Canvas canvas, Rect rect) {
    if (_victoryGlow <= 0) return;
    final double pulse = 0.72 + 0.28 * math.sin(_time * 5.2);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.55, 0),
          radius: 1.08,
          colors: <Color>[
            Color.fromRGBO(48, 224, 255, 0.17 * pulse),
            Color.fromRGBO(65, 92, 255, 0.08 * pulse),
            const Color(0x00000000),
          ],
        ).createShader(rect),
    );
    canvas.drawPath(
      _victoryBorderPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2 + pulse * 1.4
        ..color = const Color(0xFF73E0DB).withValues(alpha: 0.55 + pulse * 0.25),
    );
    for (int i = 0; i < 9; i++) {
      final double phase = (_time * 0.38 + i / 9) % 1;
      final double x = rect.left + rect.width * phase;
      final double y = rect.top + rect.height * (0.12 + ((i * 37) % 76) / 100);
      canvas.drawCircle(
        Offset(x, y),
        1.2 + (i % 3) * 0.7,
        Paint()..color = const Color(0xFFC9F4F0).withValues(alpha: (1 - phase) * 0.7),
      );
    }
  }

  @override
  void onRemove() {
    _staticPicture?.dispose();
    _staticPicture = null;
    super.onRemove();
  }

  Path _chamferedRect(Rect rect, double cut) {
    return Path()
      ..moveTo(rect.left + cut, rect.top)
      ..lineTo(rect.right - cut, rect.top)
      ..lineTo(rect.right, rect.top + cut)
      ..lineTo(rect.right, rect.bottom - cut)
      ..lineTo(rect.right - cut, rect.bottom)
      ..lineTo(rect.left + cut, rect.bottom)
      ..lineTo(rect.left, rect.bottom - cut)
      ..lineTo(rect.left, rect.top + cut)
      ..close();
  }
}
