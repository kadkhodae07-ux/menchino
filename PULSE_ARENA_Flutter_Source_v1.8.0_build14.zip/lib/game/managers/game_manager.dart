import '../config/game_config.dart';
import '../models/game_view_state.dart';
import 'match_manager.dart';
import 'match_stats_manager.dart';
import 'power_up_manager.dart';
import 'score_manager.dart';

class GameManager {
  GameManager(this.config)
      : match = MatchManager(config),
        score = ScoreManager(config),
        powers = PowerUpManager(config),
        stats = MatchStatsManager();

  final GameConfig config;
  final MatchManager match;
  final ScoreManager score;
  final PowerUpManager powers;
  final MatchStatsManager stats;

  MatchWinner? lastPointWinner;
  MatchWinner? nextServer;
  String eventText = '';

  void reset() {
    match.reset();
    score.reset();
    powers.reset();
    stats.reset();
    lastPointWinner = null;
    nextServer = null;
    eventText = '';
  }

  void registerPoint({required MatchWinner pointWinner, required MatchWinner server}) {
    lastPointWinner = pointWinner;
    nextServer = server;
    eventText = pointWinner == MatchWinner.player ? 'گل برای شما' : 'گل برای نوا';
    stats.endRally();
  }

  GameViewState makeViewState({
    required bool soundEnabled,
    required bool vibrationEnabled,
    required bool showControlHint,
  }) {
    return GameViewState(
      playerScore: score.playerScore,
      botScore: score.botScore,
      elapsedSeconds: match.elapsedSeconds,
      countdown: match.countdownLabel,
      countdownRemaining: match.countdownRemaining,
      countdownTotal: match.countdownTotal,
      openingSequence: match.openingSequence,
      phase: match.phase,
      winner: match.winner,
      difficulty: config.difficulty,
      targetScore: config.targetScore,
      shieldUses: powers.shieldUses,
      boostUses: powers.boostUses,
      pulseUses: powers.pulseUses,
      shieldActive: powers.shieldActive,
      boostArmed: powers.boostArmed,
      pulseActive: powers.pulseActive,
      shieldProgress: config.shieldDuration <= 0 ? 0 : powers.shieldRemaining / config.shieldDuration,
      pulseProgress: config.pulseDuration <= 0 ? 0 : powers.pulseRemaining / config.pulseDuration,
      soundEnabled: soundEnabled,
      vibrationEnabled: vibrationEnabled,
      currentRally: stats.currentRally,
      longestRally: stats.longestRally,
      playerHits: stats.playerHits,
      botHits: stats.botHits,
      perfectHits: stats.perfectHits,
      powersUsed: stats.powersUsed,
      lastPointWinner: lastPointWinner,
      nextServer: nextServer,
      eventText: eventText,
      showControlHint: showControlHint,
    );
  }
}
