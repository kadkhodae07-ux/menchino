import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/orientation_manager.dart';
import '../../screens/game_screen.dart';
import '../../screens/home_screen.dart';
import '../config/game_config.dart';

class SceneTransitionManager {
  const SceneTransitionManager._();

  static Future<void> openGame(BuildContext context, {GameConfig config = const GameConfig()}) async {
    final NavigatorState navigator = Navigator.of(context);
    unawaited(OrientationManager.showGame());
    await navigator.pushReplacement(_fadeRoute(GameScreen(config: config)));
  }

  static Future<void> openHome(BuildContext context) async {
    final NavigatorState navigator = Navigator.of(context);
    unawaited(OrientationManager.showHome());
    await navigator.pushReplacement(_fadeRoute(const HomeScreen()));
  }

  @Deprecated('Use openHome instead.')
  static Future<void> openStart(BuildContext context) => openHome(context);

  static PageRouteBuilder<void> _fadeRoute(Widget page) {
    return PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 170),
      reverseTransitionDuration: const Duration(milliseconds: 150),
      pageBuilder: (_, Animation<double> animation, __) => FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
        child: page,
      ),
    );
  }
}
