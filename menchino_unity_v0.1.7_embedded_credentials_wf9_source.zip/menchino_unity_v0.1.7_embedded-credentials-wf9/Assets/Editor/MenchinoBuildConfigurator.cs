#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Menchino.Editor
{
    [InitializeOnLoad]
    public static class MenchinoBuildConfigurator
    {
        public const string VersionName = "0.1.7";
        public const int VersionCode = 7;

        static MenchinoBuildConfigurator()
        {
            EditorApplication.delayCall += Apply;
        }

        [MenuItem("Menchino/Apply Android Configuration")]
        public static void Apply()
        {
            PlayerSettings.companyName = "Menchino Studio";
            PlayerSettings.productName = "منچینو";
            PlayerSettings.bundleVersion = VersionName;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.menchino.game");
            PlayerSettings.Android.bundleVersionCode = VersionCode;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.useCustomKeystore = false;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetIl2CppCompilerConfiguration(BuildTargetGroup.Android, Il2CppCompilerConfiguration.Release);
            PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Medium);
            EditorUserBuildSettings.buildAppBundle = false;

            Texture2D icon = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Art/AppIcon/menchino_icon_512.png");
            if (icon != null)
            {
                PlayerSettings.SetIconsForTargetGroup(BuildTargetGroup.Android, new[] { icon });
            }

            EnsureUrp();
            AssetDatabase.SaveAssets();
        }

        private static void EnsureUrp()
        {
            const string pipelinePath = "Assets/Settings/MenchinoURP.asset";
            const string rendererPath = "Assets/Settings/MenchinoRenderer.asset";
            UniversalRenderPipelineAsset pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(pipelinePath);
            if (pipeline == null)
            {
                UniversalRendererData renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(rendererPath);
                if (renderer == null)
                {
                    renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
                    AssetDatabase.CreateAsset(renderer, rendererPath);
                }

                MethodInfo create = typeof(UniversalRenderPipelineAsset).GetMethod(
                    "Create",
                    BindingFlags.Public | BindingFlags.Static,
                    null,
                    new[] { typeof(UniversalRendererData) },
                    null);

                pipeline = create != null
                    ? create.Invoke(null, new object[] { renderer }) as UniversalRenderPipelineAsset
                    : ScriptableObject.CreateInstance<UniversalRenderPipelineAsset>();

                AssetDatabase.CreateAsset(pipeline, pipelinePath);
                AssetDatabase.SaveAssets();
            }

            GraphicsSettings.renderPipelineAsset = pipeline;
            QualitySettings.renderPipeline = pipeline;
        }
    }

    public static class AndroidBuilder
    {
        private static readonly string[] Scenes =
        {
            "Assets/Scenes/Boot.unity",
            "Assets/Scenes/Home.unity",
            "Assets/Scenes/ModeSelect.unity",
            "Assets/Scenes/SnakesSetup.unity",
            "Assets/Scenes/SnakesGameplay.unity",
            "Assets/Scenes/Result.unity",
            "Assets/Scenes/DailyReward.unity",
            "Assets/Scenes/Missions.unity",
            "Assets/Scenes/Shop.unity",
            "Assets/Scenes/Profile.unity",
            "Assets/Scenes/Settings.unity"
        };

        private const string OutputDirectory = "Builds/Android";
        private const string SummaryLog = "Builds/Logs/menchino-build-summary.log";

        [MenuItem("Menchino/Build Two Android APKs")]
        public static void BuildFromMenu()
        {
            Build();
        }

        // GitHub Actions entry point. Produces exactly two real APK builds.
        public static void Build()
        {
            MenchinoBuildConfigurator.Apply();
            PrepareOutputDirectories();

            try
            {
                BuildVariant(
                    "Menchino-arm64-v8a.apk",
                    AndroidArchitecture.ARM64,
                    "ARM64-only");

                BuildVariant(
                    "Menchino-universal.apk",
                    AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64,
                    "ARMv7+ARM64 universal");

                string[] apks = Directory.GetFiles(OutputDirectory, "*.apk", SearchOption.TopDirectoryOnly);
                if (apks.Length != 2)
                {
                    throw new InvalidOperationException(
                        $"Expected exactly two APK files, but found {apks.Length} in {OutputDirectory}.");
                }

                AppendSummary("SUCCESS: exactly two APK files were produced.");
                Debug.Log("Menchino dual APK build completed successfully.");
            }
            catch (Exception exception)
            {
                AppendSummary("FAILURE: " + exception);
                Debug.LogException(exception);
                throw;
            }
            finally
            {
                PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
                AssetDatabase.SaveAssets();
            }
        }

        private static void PrepareOutputDirectories()
        {
            if (Directory.Exists(OutputDirectory))
            {
                Directory.Delete(OutputDirectory, true);
            }

            Directory.CreateDirectory(OutputDirectory);
            Directory.CreateDirectory(Path.GetDirectoryName(SummaryLog) ?? "Builds/Logs");
            File.WriteAllText(
                SummaryLog,
                $"Menchino Android build started at {DateTime.UtcNow:O}{Environment.NewLine}" +
                $"Version: {MenchinoBuildConfigurator.VersionName} ({MenchinoBuildConfigurator.VersionCode}){Environment.NewLine}");
        }

        private static void BuildVariant(
            string fileName,
            AndroidArchitecture architectures,
            string label)
        {
            string output = Path.Combine(OutputDirectory, fileName);
            PlayerSettings.Android.targetArchitectures = architectures;
            AssetDatabase.SaveAssets();

            AppendSummary($"START: {label} -> {output}");

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = Scenes,
                locationPathName = output,
                target = BuildTarget.Android,
                options = BuildOptions.CleanBuildCache
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            BuildSummary summary = report.summary;
            AppendSummary(
                $"RESULT: {label}; result={summary.result}; errors={summary.totalErrors}; " +
                $"warnings={summary.totalWarnings}; bytes={summary.totalSize}; duration={summary.totalTime}");

            if (summary.result != BuildResult.Succeeded)
            {
                throw new InvalidOperationException(
                    $"Android build failed for {label}: result={summary.result}, errors={summary.totalErrors}.");
            }

            if (!File.Exists(output) || new FileInfo(output).Length <= 0)
            {
                throw new InvalidOperationException($"APK output is missing or empty: {output}");
            }

            Debug.Log($"Menchino APK built: {output} ({summary.totalSize} bytes)");
        }

        private static void AppendSummary(string message)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SummaryLog) ?? "Builds/Logs");
            File.AppendAllText(SummaryLog, $"[{DateTime.UtcNow:O}] {message}{Environment.NewLine}");
        }
    }
}
#endif
