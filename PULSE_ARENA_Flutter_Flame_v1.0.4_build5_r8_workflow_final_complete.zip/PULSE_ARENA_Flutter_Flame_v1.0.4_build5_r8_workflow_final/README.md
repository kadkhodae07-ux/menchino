# PULSE ARENA – Flutter + Flame Demo

دموی آفلاین و قابل‌بازی فونگ آینده‌نگر برای Android، ساخته‌شده با Flutter و Flame.

## نسخه

- Flutter app: `1.0.4+5`
- Build 45 hotfix: رفع شکست R8 ناشی از کلاس‌های اختیاری Google Play Core
- Workflow: ساخت یک APK از جدیدترین ZIP معتبر و تحویل لاگ کامل در صورت خطا
- وابستگی‌های Flame و Flame Audio برای جلوگیری از تغییرات ناخواسته قفل شده‌اند

## امکانات

- صفحه شروع گرافیکی و Transition نرم
- مسابقه آفلاین تا امتیاز ۷ مقابل ربات متوسط
- کنترل لمسی نرم با Drag
- توپ انرژی با Glow، Trail و ذرات برخورد
- ربات با پیش‌بینی مسیر، تأخیر واکنش، محدودیت سرعت و خطای عمدی
- قدرت‌های سپر، شتاب و پالس
- شمارش معکوس ۳، ۲، ۱ بعد از هر امتیاز
- Pause، ادامه، شروع مجدد و بازگشت
- نتیجه برد/باخت و بازی دوباره
- صدا و لرزش قابل خاموش‌کردن از منوی Pause
- Android Landscape و Safe Area

## تنظیم Android Release

برای پایداری Build فروشگاهی این دمو، `minify` و `shrinkResources` غیرفعال هستند. این پروژه از Deferred Components یا Google Play Dynamic Features استفاده نمی‌کند؛ فعال‌بودن R8 در Build 45 باعث ارجاع اجباری به کلاس‌های اختیاری Play Core و شکست Build شده بود.

## Workflow نهایی

فایل `.github/workflows/build-pulse-arena.yml`:

- جدیدترین ZIP معتبر پروژه Flutter را براساس آخرین Commit تشخیص می‌دهد.
- ZIPهای لاگ، Keystore، تصاویر و فایل‌های نامرتبط را انتخاب نمی‌کند.
- Flutter، Java، Gradle، Analyze و Test را اجرا می‌کند.
- فقط یک APK Release با Flavor بازار می‌سازد.
- قبل از تحویل APK موفق، Artifactهای قدیمی را حذف می‌کند.
- در صورت شکست، Build را با حالت Verbose تکرار و همه لاگ‌ها را تحویل می‌دهد.

## امضای Release

برای امضای فروشگاهی Secrets زیر را در GitHub تعریف کنید:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

اگر Secrets امضا تعریف نشده باشند، APK با Debug Keystore ساخته می‌شود و فقط برای تست مناسب است.
