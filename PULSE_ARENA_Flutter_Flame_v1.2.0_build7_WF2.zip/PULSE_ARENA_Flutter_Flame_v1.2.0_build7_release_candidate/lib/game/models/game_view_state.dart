import '../config/game_config.dart';

enum MatchPhase { countdown, playing, paused, finished }

enum MatchWinner { player, bot }

enum PowerType { shield, boost, pulse }

class GameViewState {
  const GameViewState({
    this.playerScore = 0,
    this.botScore = 0,
    this.elapsedSeconds = 0,
    this.countdown = 3,
    this.countdownRemaining = 3,
    this.countdownTotal = 3,
    this.openingSequence = true,
    this.phase = MatchPhase.countdown,
    this.winner,
    this.difficulty = BotDifficulty.tactical,
    this.targetScore = 7,
    this.shieldUses = 2,
    this.boostUses = 2,
    this.pulseUses = 2,
    this.shieldActive = false,
    this.boostArmed = false,
    this.pulseActive = false,
    this.shieldProgress = 0,
    this.pulseProgress = 0,
    this.soundEnabled = true,
    this.vibrationEnabled = true,
    this.currentRally = 0,
    this.longestRally = 0,
    this.playerHits = 0,
    this.botHits = 0,
    this.perfectHits = 0,
    this.powersUsed = 0,
    this.lastPointWinner,
    this.nextServer,
    this.eventText = '',
    this.showControlHint = true,
  });

  final int playerScore;
  final int botScore;
  final double elapsedSeconds;
  final int countdown;
  final double countdownRemaining;
  final double countdownTotal;
  final bool openingSequence;
  final MatchPhase phase;
  final MatchWinner? winner;
  final BotDifficulty difficulty;
  final int targetScore;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
  final bool shieldActive;
  final bool boostArmed;
  final bool pulseActive;
  final double shieldProgress;
  final double pulseProgress;
  final bool soundEnabled;
  final bool vibrationEnabled;
  final int currentRally;
  final int longestRally;
  final int playerHits;
  final int botHits;
  final int perfectHits;
  final int powersUsed;
  final MatchWinner? lastPointWinner;
  final MatchWinner? nextServer;
  final String eventText;
  final bool showControlHint;

  double get perfectRate => playerHits <= 0 ? 0 : perfectHits / playerHits;

  GameViewState copyWith({
    int? playerScore,
    int? botScore,
    double? elapsedSeconds,
    int? countdown,
    double? countdownRemaining,
    double? countdownTotal,
    bool? openingSequence,
    MatchPhase? phase,
    MatchWinner? winner,
    bool clearWinner = false,
    BotDifficulty? difficulty,
    int? targetScore,
    int? shieldUses,
    int? boostUses,
    int? pulseUses,
    bool? shieldActive,
    bool? boostArmed,
    bool? pulseActive,
    double? shieldProgress,
    double? pulseProgress,
    bool? soundEnabled,
    bool? vibrationEnabled,
    int? currentRally,
    int? longestRally,
    int? playerHits,
    int? botHits,
    int? perfectHits,
    int? powersUsed,
    MatchWinner? lastPointWinner,
    bool clearLastPointWinner = false,
    MatchWinner? nextServer,
    bool clearNextServer = false,
    String? eventText,
    bool? showControlHint,
  }) {
    return GameViewState(
      playerScore: playerScore ?? this.playerScore,
      botScore: botScore ?? this.botScore,
      elapsedSeconds: elapsedSeconds ?? this.elapsedSeconds,
      countdown: countdown ?? this.countdown,
      countdownRemaining: countdownRemaining ?? this.countdownRemaining,
      countdownTotal: countdownTotal ?? this.countdownTotal,
      openingSequence: openingSequence ?? this.openingSequence,
      phase: phase ?? this.phase,
      winner: clearWinner ? null : (winner ?? this.winner),
      difficulty: difficulty ?? this.difficulty,
      targetScore: targetScore ?? this.targetScore,
      shieldUses: shieldUses ?? this.shieldUses,
      boostUses: boostUses ?? this.boostUses,
      pulseUses: pulseUses ?? this.pulseUses,
      shieldActive: shieldActive ?? this.shieldActive,
      boostArmed: boostArmed ?? this.boostArmed,
      pulseActive: pulseActive ?? this.pulseActive,
      shieldProgress: shieldProgress ?? this.shieldProgress,
      pulseProgress: pulseProgress ?? this.pulseProgress,
      soundEnabled: soundEnabled ?? this.soundEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      currentRally: currentRally ?? this.currentRally,
      longestRally: longestRally ?? this.longestRally,
      playerHits: playerHits ?? this.playerHits,
      botHits: botHits ?? this.botHits,
      perfectHits: perfectHits ?? this.perfectHits,
      powersUsed: powersUsed ?? this.powersUsed,
      lastPointWinner: clearLastPointWinner ? null : (lastPointWinner ?? this.lastPointWinner),
      nextServer: clearNextServer ? null : (nextServer ?? this.nextServer),
      eventText: eventText ?? this.eventText,
      showControlHint: showControlHint ?? this.showControlHint,
    );
  }
}
