enum BotDifficulty { trainee, tactical, champion }

extension BotDifficultyLabel on BotDifficulty {
  String get title {
    switch (this) {
      case BotDifficulty.trainee:
        return 'تمرینی';
      case BotDifficulty.tactical:
        return 'تاکتیکی';
      case BotDifficulty.champion:
        return 'قهرمان';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.trainee:
        return 'واکنش آرام و خطای بیشتر';
      case BotDifficulty.tactical:
        return 'متعادل و مناسب مسابقه اصلی';
      case BotDifficulty.champion:
        return 'سریع، دقیق و کم‌اشتباه';
    }
  }
}

class GameConfig {
  const GameConfig({
    this.difficulty = BotDifficulty.tactical,
    this.targetScore = 7,
    this.ballBaseSpeed = 510,
    this.ballMaximumSpeed = 940,
    this.ballSpeedIncreasePerSecond = 3.4,
    this.playerPaddleSpeed = 1320,
    this.playerResponse = 14,
    this.botPaddleSpeed = 590,
    this.botReactionDelay = 0.205,
    this.botErrorChance = 0.24,
    this.botBaseAimError = 68,
    this.countdownDuration = 3.0,
    this.pointServeDelay = 0.68,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.56,
    this.boostMultiplier = 1.32,
    this.shieldUses = 2,
    this.boostUses = 2,
    this.pulseUses = 2,
  });

  factory GameConfig.forDifficulty(BotDifficulty difficulty) {
    switch (difficulty) {
      case BotDifficulty.trainee:
        return const GameConfig(
          difficulty: BotDifficulty.trainee,
          botPaddleSpeed: 500,
          botReactionDelay: 0.265,
          botErrorChance: 0.34,
          botBaseAimError: 92,
          ballBaseSpeed: 470,
          ballMaximumSpeed: 860,
        );
      case BotDifficulty.tactical:
        return const GameConfig();
      case BotDifficulty.champion:
        return const GameConfig(
          difficulty: BotDifficulty.champion,
          botPaddleSpeed: 690,
          botReactionDelay: 0.145,
          botErrorChance: 0.13,
          botBaseAimError: 42,
          ballBaseSpeed: 550,
          ballMaximumSpeed: 1010,
        );
    }
  }

  final BotDifficulty difficulty;
  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double playerPaddleSpeed;
  final double playerResponse;
  final double botPaddleSpeed;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double pointServeDelay;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
