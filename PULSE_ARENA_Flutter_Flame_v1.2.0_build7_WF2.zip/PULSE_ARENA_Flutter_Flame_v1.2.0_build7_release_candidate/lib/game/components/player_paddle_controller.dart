import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

class PlayerPaddleController extends PositionComponent {
  PlayerPaddleController({required this.moveSpeed, this.response = 14});

  final double moveSpeed;
  final double response;
  Rect movementBounds = Rect.zero;
  double targetY = 0;
  bool movementEnabled = true;
  double _motionEnergy = 0;
  double _hitEnergy = 0;

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) / movementBounds.height).clamp(0.0, 1.0).toDouble();
    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.026).clamp(25.0, 39.0).toDouble(),
      (arena.height * 0.29).clamp(88.0, 146.0).toDouble(),
    );
    position.x = arena.left + (arena.width * 0.031).clamp(22.0, 40.0).toDouble();
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
  }

  void setTargetFromTouch(double touchY) {
    if (movementBounds.isEmpty) return;
    targetY = (touchY - size.y / 2).clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    _motionEnergy = 0;
  }

  void registerHit({required bool perfect}) {
    _hitEnergy = perfect ? 1.45 : 1;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _hitEnergy = math.max(0, _hitEnergy - dt * 4.8);
    if (!movementEnabled || movementBounds.isEmpty) return;

    final double delta = targetY - position.y;
    final double easedStep = delta * (1 - math.exp(-response * dt));
    final double maxStep = moveSpeed * dt;
    final double step = easedStep.clamp(-maxStep, maxStep).toDouble();
    position.y += step;
    _motionEnergy += (math.min(1.0, step.abs() / math.max(1.0, maxStep)) - _motionEnergy) * math.min(1, dt * 12);
    position.y = position.y.clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final Rect bounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * 0.34;
    final Path body = Path()
      ..moveTo(cut, 0)
      ..lineTo(size.x - cut * 0.25, 0)
      ..lineTo(size.x, cut)
      ..lineTo(size.x, size.y - cut)
      ..lineTo(size.x - cut * 0.25, size.y)
      ..lineTo(cut, size.y)
      ..lineTo(0, size.y - cut * 0.7)
      ..lineTo(0, cut * 0.7)
      ..close();

    for (int i = 3; i >= 1; i--) {
      canvas.save();
      canvas.translate(-i * (3.5 + _motionEnergy * 2.5), 0);
      canvas.drawPath(body, Paint()..color = const Color(0xFF26DFFF).withValues(alpha: 0.045 + _motionEnergy * 0.08));
      canvas.restore();
    }

    canvas.drawPath(
      body,
      Paint()
        ..color = const Color(0xFF1DDFFF).withValues(alpha: 0.52 + _hitEnergy * 0.22)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 12 + _hitEnergy * 7),
    );
    canvas.drawPath(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF064F7C), Color(0xFF24DFFF), Color(0xFFE8FEFF)],
        ).createShader(bounds),
    );
    canvas.drawPath(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xEFFFFFFF),
    );

    final Rect spine = Rect.fromLTWH(size.x * 0.25, size.y * 0.12, size.x * 0.22, size.y * 0.76);
    canvas.drawRRect(
      RRect.fromRectAndRadius(spine, Radius.circular(size.x * 0.12)),
      Paint()..color = const Color(0xDDF4FFFF),
    );
    canvas.drawCircle(
      Offset(size.x * 0.66, size.y * 0.5),
      size.x * (0.2 + _hitEnergy * 0.035),
      Paint()
        ..color = const Color(0xFFFFFFFF)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2 + _hitEnergy * 5),
    );

    for (final double y in <double>[0.16, 0.84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(size.x * 0.58, size.y * y), width: size.x * 0.54, height: size.x * 0.16),
          Radius.circular(size.x * 0.08),
        ),
        Paint()..color = const Color(0xAA07375D),
      );
    }
  }
}
