import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient, RadialGradient;

class ArenaComponent extends PositionComponent {
  ArenaComponent({super.priority = -100});

  Rect arenaRect = Rect.zero;
  Rect playRect = Rect.zero;
  final List<Offset> _stars = <Offset>[];
  final math.Random _random = math.Random(4137);
  double _time = 0;
  double _goalFlash = 0;
  double _servePulse = 0;
  double _hitFlash = 0;
  double _rallyEnergy = 0;
  bool _playerGoal = true;
  bool _playerHit = true;
  bool _perfectHit = false;

  void layout(Vector2 gameSize) {
    final double horizontal = (gameSize.x * 0.017).clamp(13.0, 23.0).toDouble();
    final double vertical = (gameSize.y * 0.025).clamp(8.0, 15.0).toDouble();
    arenaRect = Rect.fromLTRB(horizontal, vertical, gameSize.x - horizontal, gameSize.y - vertical);
    playRect = arenaRect.deflate((gameSize.y * 0.016).clamp(6.0, 10.0).toDouble());
    size = gameSize;

    if (_stars.isEmpty) {
      for (int i = 0; i < 48; i++) {
        _stars.add(Offset(_random.nextDouble(), _random.nextDouble()));
      }
    }
  }

  void triggerGoal({required bool playerScored}) {
    _playerGoal = playerScored;
    _goalFlash = 1;
  }

  void triggerServe() {
    _servePulse = 1;
  }

  void triggerHit({required bool playerHit, required bool perfect}) {
    _playerHit = playerHit;
    _perfectHit = perfect;
    _hitFlash = perfect ? 1.25 : 0.72;
  }

  void setRally(int rally) {
    final double target = (rally / 12).clamp(0.0, 1.0).toDouble();
    _rallyEnergy += (target - _rallyEnergy) * 0.12;
  }

  void resetEffects() {
    _goalFlash = 0;
    _servePulse = 0;
    _hitFlash = 0;
    _rallyEnergy = 0;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    _goalFlash = math.max(0.0, _goalFlash - dt * 1.75);
    _servePulse = math.max(0.0, _servePulse - dt * 1.55);
    _hitFlash = math.max(0.0, _hitFlash - dt * 3.8);
    _rallyEnergy = math.max(0.0, _rallyEnergy - dt * 0.018);
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final Rect full = Offset.zero & Size(size.x, size.y);
    canvas.drawRect(
      full,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF02050C), Color(0xFF061124), Color(0xFF150817)],
        ).createShader(full),
    );

    _drawAmbient(canvas, full);
    _drawStars(canvas);
    if (arenaRect.isEmpty) return;

    final double outerCut = (arenaRect.height * 0.052).clamp(16.0, 27.0).toDouble();
    final double innerCut = (playRect.height * 0.038).clamp(12.0, 20.0).toDouble();
    final Path outer = _chamferedRect(arenaRect, outerCut);
    final Path inner = _chamferedRect(playRect, innerCut);

    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF073A52), Color(0xFF121A2D), Color(0xFF4A1439)],
        ).createShader(arenaRect),
    );
    canvas.drawPath(
      inner,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 1.15,
          colors: <Color>[Color(0xFF111D32), Color(0xFF07101D), Color(0xFF03060D)],
        ).createShader(playRect),
    );

    canvas.save();
    canvas.clipPath(inner);
    _drawFloor(canvas, playRect);
    _drawGoalZones(canvas, playRect);
    _drawCenterGate(canvas, playRect);
    _drawServePulse(canvas, playRect);
    _drawHitFlash(canvas, playRect);
    _drawGoalFlash(canvas, playRect);
    canvas.restore();

    _drawFrame(canvas, outer, playRect);
  }

  void _drawAmbient(Canvas canvas, Rect full) {
    final double drift = math.sin(_time * 0.38) * full.width * 0.028;
    canvas.drawCircle(
      Offset(full.width * 0.18 + drift, full.height * 0.42),
      full.height * 0.62,
      Paint()
        ..color = const Color(0x2624CFFF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 72),
    );
    canvas.drawCircle(
      Offset(full.width * 0.84 - drift, full.height * 0.58),
      full.height * 0.58,
      Paint()
        ..color = const Color(0x26FF3EAD)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 76),
    );
  }

  void _drawStars(Canvas canvas) {
    for (int i = 0; i < _stars.length; i++) {
      final Offset star = _stars[i];
      final double twinkle = 0.18 + 0.36 * (0.5 + 0.5 * math.sin(_time * (0.55 + i % 4 * 0.12) + i));
      canvas.drawCircle(
        Offset(star.dx * size.x, star.dy * size.y),
        i % 9 == 0 ? 1.25 : 0.7,
        Paint()..color = const Color(0xFFB6EEFF).withValues(alpha: twinkle),
      );
    }
  }

  void _drawFloor(Canvas canvas, Rect rect) {
    final double energy = 0.16 + _rallyEnergy * 0.34;
    final Paint horizontal = Paint()
      ..strokeWidth = 0.8
      ..color = const Color(0xFF5D87C7).withValues(alpha: energy);
    for (int i = 1; i < 8; i++) {
      final double t = i / 8;
      final double y = rect.top + rect.height * t;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), horizontal);
    }

    final Paint diagonal = Paint()
      ..strokeWidth = 0.75
      ..color = const Color(0xFF42CFFF).withValues(alpha: 0.075 + _rallyEnergy * 0.09);
    final double shift = (_time * 34) % 70;
    for (double x = rect.left - rect.height; x < rect.right + rect.height; x += 70) {
      canvas.drawLine(Offset(x + shift, rect.bottom), Offset(x + rect.height * 0.44 + shift, rect.top), diagonal);
    }

    final Rect vignette = rect.inflate(2);
    canvas.drawRect(
      vignette,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 0.92,
          colors: <Color>[Color(0x00000000), Color(0x52000000)],
        ).createShader(vignette),
    );
  }

  void _drawCenterGate(Canvas canvas, Rect rect) {
    final double x = rect.center.dx;
    final double dash = (rect.height * 0.055).clamp(14.0, 23.0).toDouble();
    final Paint centerLine = Paint()
      ..color = const Color(0xFF7E84FF).withValues(alpha: 0.46 + _rallyEnergy * 0.22)
      ..strokeWidth = 1.7
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
    for (double y = rect.top + 10; y < rect.bottom; y += dash * 1.72) {
      canvas.drawLine(Offset(x, y), Offset(x, math.min(y + dash, rect.bottom - 8)), centerLine);
    }

    final double coreHeight = rect.height * 0.19;
    final Rect core = Rect.fromCenter(center: rect.center, width: 8, height: coreHeight);
    canvas.drawRRect(
      RRect.fromRectAndRadius(core, const Radius.circular(5)),
      Paint()
        ..color = const Color(0x555F65FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(core.deflate(2), const Radius.circular(4)),
      Paint()..color = const Color(0xB8B8D7FF),
    );
  }

  void _drawGoalZones(Canvas canvas, Rect rect) {
    final double width = rect.width * 0.072;
    final Rect left = Rect.fromLTWH(rect.left, rect.top, width, rect.height);
    final Rect right = Rect.fromLTWH(rect.right - width, rect.top, width, rect.height);
    canvas.drawRect(
      left,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0x4D2DDEFF), Color(0x002DDEFF)],
        ).createShader(left),
    );
    canvas.drawRect(
      right,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
          colors: <Color>[Color(0x4DFF42AD), Color(0x00FF42AD)],
        ).createShader(right),
    );
  }

  void _drawServePulse(Canvas canvas, Rect rect) {
    if (_servePulse <= 0) return;
    final double progress = 1 - _servePulse;
    final double radius = rect.height * (0.035 + progress * 0.34);
    canvas.drawCircle(
      rect.center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.5 * _servePulse + 0.8
        ..color = const Color(0xFFB9F8FF).withValues(alpha: _servePulse * 0.66),
    );
  }

  void _drawHitFlash(Canvas canvas, Rect rect) {
    if (_hitFlash <= 0) return;
    final Color color = _playerHit ? const Color(0xFF40E5FF) : const Color(0xFFFF4DAF);
    final double x = _playerHit ? rect.left : rect.right;
    final Alignment begin = _playerHit ? Alignment.centerLeft : Alignment.centerRight;
    final Alignment end = _playerHit ? Alignment.centerRight : Alignment.centerLeft;
    final Rect half = Rect.fromLTWH(_playerHit ? rect.left : rect.center.dx, rect.top, rect.width / 2, rect.height);
    canvas.drawRect(
      half,
      Paint()
        ..shader = LinearGradient(
          begin: begin,
          end: end,
          colors: <Color>[color.withValues(alpha: _hitFlash * 0.18), color.withValues(alpha: 0)],
        ).createShader(half),
    );
    if (_perfectHit) {
      canvas.drawCircle(
        Offset(x, rect.center.dy),
        rect.height * (0.18 + (1 - _hitFlash.clamp(0.0, 1.0).toDouble()) * 0.18),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = const Color(0xFFFFFFFF).withValues(alpha: _hitFlash.clamp(0.0, 1.0).toDouble() * 0.72),
      );
    }
  }

  void _drawGoalFlash(Canvas canvas, Rect rect) {
    if (_goalFlash <= 0) return;
    final bool right = _playerGoal;
    final Rect zone = Rect.fromLTWH(right ? rect.center.dx : rect.left, rect.top, rect.width / 2, rect.height);
    final Color color = right ? const Color(0xFF4AE5FF) : const Color(0xFFFF4DAF);
    canvas.drawRect(
      zone,
      Paint()
        ..shader = LinearGradient(
          begin: right ? Alignment.centerLeft : Alignment.centerRight,
          end: right ? Alignment.centerRight : Alignment.centerLeft,
          colors: <Color>[color.withValues(alpha: 0), color.withValues(alpha: _goalFlash * 0.34)],
        ).createShader(zone),
    );
  }

  void _drawFrame(Canvas canvas, Path outer, Rect rect) {
    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..color = const Color(0xFF5D718F),
    );
    canvas.drawLine(
      rect.topLeft,
      rect.bottomLeft,
      Paint()
        ..color = const Color(0xFF38DFFF)
        ..strokeWidth = 3.5
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
    canvas.drawLine(
      rect.topRight,
      rect.bottomRight,
      Paint()
        ..color = const Color(0xFFFF47AD)
        ..strokeWidth = 3.5
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
  }

  Path _chamferedRect(Rect rect, double cut) {
    return Path()
      ..moveTo(rect.left + cut, rect.top)
      ..lineTo(rect.right - cut, rect.top)
      ..lineTo(rect.right, rect.top + cut)
      ..lineTo(rect.right, rect.bottom - cut)
      ..lineTo(rect.right - cut, rect.bottom)
      ..lineTo(rect.left + cut, rect.bottom)
      ..lineTo(rect.left, rect.bottom - cut)
      ..lineTo(rect.left, rect.top + cut)
      ..close();
  }
}
