import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

import '../config/game_config.dart';
import 'ball_controller.dart';

class BotPaddleController extends PositionComponent {
  BotPaddleController({
    required this.config,
    required this.ball,
    required this.playerScore,
    required this.isPulseActive,
    int Function()? botScore,
  }) : botScore = botScore ?? _zeroScore;

  static int _zeroScore() => 0;

  final GameConfig config;
  final BallController ball;
  final int Function() playerScore;
  final int Function() botScore;
  final bool Function() isPulseActive;
  final math.Random _random = math.Random(9721);

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  double _reactionTimer = 0;
  double _motionEnergy = 0;
  double _hitEnergy = 0;
  bool movementEnabled = true;

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) / movementBounds.height).clamp(0.0, 1.0).toDouble();
    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.026).clamp(25.0, 39.0).toDouble(),
      (arena.height * 0.29).clamp(88.0, 146.0).toDouble(),
    );
    position.x = arena.right - (arena.width * 0.031).clamp(22.0, 40.0).toDouble() - size.x;
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    _reactionTimer = 0;
    _motionEnergy = 0;
  }

  void registerHit() {
    _hitEnergy = 1;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _hitEnergy = math.max(0, _hitEnergy - dt * 4.8);
    if (!movementEnabled || movementBounds.isEmpty) return;

    final int lead = botScore() - playerScore();
    final double rubberBand = lead >= 2 ? 0.82 : (lead <= -2 ? 1.08 : 1.0);
    _reactionTimer -= dt;
    if (_reactionTimer <= 0) {
      _reactionTimer = config.botReactionDelay * (lead >= 2 ? 1.18 : 1.0) * (0.92 + _random.nextDouble() * 0.18);
      _chooseTarget(lead);
    }

    final double pulseFactor = isPulseActive() ? config.pulseSlowFactor : 1.0;
    final double maxStep = config.botPaddleSpeed * pulseFactor * rubberBand * dt;
    final double delta = targetY - position.y;
    final double easedStep = delta * (1 - math.exp(-10.5 * dt));
    final double step = easedStep.clamp(-maxStep, maxStep).toDouble();
    position.y += step;
    _motionEnergy += (math.min(1.0, step.abs() / math.max(1.0, maxStep)) - _motionEnergy) * math.min(1, dt * 10);
    position.y = position.y.clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  void _chooseTarget(int lead) {
    final bool ballThreatening = ball.velocity.x > 0 && ball.position.x > movementBounds.center.dx * 0.92;
    if (!ballThreatening || !ball.active) {
      final double idleOffset = math.sin(ball.position.x * 0.015) * movementBounds.height * 0.05;
      targetY = (movementBounds.center.dy - size.y / 2 + idleOffset)
          .clamp(movementBounds.top, movementBounds.bottom - size.y)
          .toDouble();
      return;
    }

    final double travelX = position.x - ball.position.x;
    final double travelTime = travelX / math.max(1.0, ball.velocity.x);
    double predictedY = ball.position.y + ball.velocity.y * travelTime;
    predictedY = _reflectY(predictedY, movementBounds.top, movementBounds.bottom);

    double error = config.botBaseAimError;
    if (lead >= 2) error *= 1.45;
    if (lead <= -2) error *= 0.82;
    if (_random.nextDouble() < config.botErrorChance * (lead >= 2 ? 1.35 : 1.0)) {
      error *= 1.9;
    }
    predictedY += (_random.nextDouble() * 2 - 1) * error;
    targetY = (predictedY - size.y / 2).clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  double _reflectY(double y, double top, double bottom) {
    final double height = bottom - top;
    if (height <= 0) return top;
    double local = (y - top) % (height * 2);
    if (local < 0) local += height * 2;
    if (local > height) local = height * 2 - local;
    return top + local;
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final Rect bounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * 0.34;
    final Path body = Path()
      ..moveTo(cut * 0.25, 0)
      ..lineTo(size.x - cut, 0)
      ..lineTo(size.x, cut * 0.7)
      ..lineTo(size.x, size.y - cut * 0.7)
      ..lineTo(size.x - cut, size.y)
      ..lineTo(cut * 0.25, size.y)
      ..lineTo(0, size.y - cut)
      ..lineTo(0, cut)
      ..close();

    for (int i = 3; i >= 1; i--) {
      canvas.save();
      canvas.translate(i * (3.5 + _motionEnergy * 2.5), 0);
      canvas.drawPath(body, Paint()..color = const Color(0xFFFF42AD).withValues(alpha: 0.045 + _motionEnergy * 0.08));
      canvas.restore();
    }

    canvas.drawPath(
      body,
      Paint()
        ..color = const Color(0xFFFF3FAB).withValues(alpha: 0.52 + _hitEnergy * 0.22)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 12 + _hitEnergy * 7),
    );
    canvas.drawPath(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFFFFE7F5), Color(0xFFFF43AD), Color(0xFF6F175F)],
        ).createShader(bounds),
    );
    canvas.drawPath(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xEFFFFFFF),
    );

    final Rect spine = Rect.fromLTWH(size.x * 0.53, size.y * 0.12, size.x * 0.22, size.y * 0.76);
    canvas.drawRRect(
      RRect.fromRectAndRadius(spine, Radius.circular(size.x * 0.12)),
      Paint()..color = const Color(0xDDFEEDF7),
    );
    canvas.drawCircle(
      Offset(size.x * 0.34, size.y * 0.5),
      size.x * (0.2 + _hitEnergy * 0.035),
      Paint()
        ..color = const Color(0xFFFFFFFF)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2 + _hitEnergy * 5),
    );

    for (final double y in <double>[0.16, 0.84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(size.x * 0.42, size.y * y), width: size.x * 0.54, height: size.x * 0.16),
          Radius.circular(size.x * 0.08),
        ),
        Paint()..color = const Color(0xAA5A164E),
      );
    }
  }
}
