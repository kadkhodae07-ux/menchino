import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';

class StartScreen extends StatefulWidget {
  const StartScreen({super.key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  BotDifficulty _difficulty = BotDifficulty.tactical;
  bool _pressed = false;
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
    AudioManager.instance.startBgm();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    if (_leaving) return;
    setState(() {
      _pressed = true;
      _leaving = true;
    });
    await AudioManager.instance.playButton();
    await AudioManager.instance.importantImpact();
    await Future<void>.delayed(const Duration(milliseconds: 140));
    if (!mounted) return;
    await SceneTransitionManager.openGame(context, config: GameConfig.forDifficulty(_difficulty));
  }

  Future<void> _toggleSound() async {
    await AudioManager.instance.setSoundEnabled(!AudioManager.instance.soundEnabled);
    if (mounted) setState(() {});
  }

  void _toggleVibration() {
    AudioManager.instance.vibrationEnabled = !AudioManager.instance.vibrationEnabled;
    AudioManager.instance.lightImpact();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 360),
          child: LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
              final bool compact = constraints.maxHeight < 390 || constraints.maxWidth < 760;
              return Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (_, __) => CustomPaint(painter: _StartBackgroundPainter(progress: _controller.value)),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: compact ? 18 : 34, vertical: compact ? 10 : 20),
                    child: Row(
                      children: <Widget>[
                        Expanded(flex: 11, child: _BrandPanel(progress: _controller.value, compact: compact)),
                        SizedBox(width: compact ? 14 : 28),
                        Expanded(
                          flex: 9,
                          child: _BattlePanel(
                            compact: compact,
                            difficulty: _difficulty,
                            pressed: _pressed,
                            onDifficulty: (BotDifficulty value) {
                              AudioManager.instance.playButton();
                              AudioManager.instance.lightImpact();
                              setState(() => _difficulty = value);
                            },
                            onStart: _start,
                            onPressChanged: (bool value) => setState(() => _pressed = value),
                            soundEnabled: AudioManager.instance.soundEnabled,
                            vibrationEnabled: AudioManager.instance.vibrationEnabled,
                            onToggleSound: _toggleSound,
                            onToggleVibration: _toggleVibration,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _BrandPanel extends StatelessWidget {
  const _BrandPanel({required this.progress, required this.compact});
  final double progress;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Container(
              width: compact ? 38 : 48,
              height: compact ? 38 : 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFF82EDFF), width: 1.5),
                gradient: const RadialGradient(colors: <Color>[Color(0xFFFFFFFF), Color(0xFF8155FF), Color(0xFF15214B)]),
                boxShadow: const <BoxShadow>[BoxShadow(color: Color(0xAA6C52FF), blurRadius: 22)],
              ),
              child: Icon(Icons.bolt_rounded, color: const Color(0xFF07101F), size: compact ? 25 : 31),
            ),
            SizedBox(width: compact ? 10 : 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'PULSE ARENA',
                  style: TextStyle(
                    fontSize: compact ? 26 : 38,
                    fontWeight: FontWeight.w900,
                    letterSpacing: compact ? 3.5 : 5.5,
                    color: const Color(0xFFF3FDFF),
                    shadows: const <Shadow>[Shadow(color: Color(0xFF38DFFF), blurRadius: 18)],
                  ),
                ),
                Text(
                  'نبرد پالس‌ها',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(fontSize: compact ? 12 : 15, fontWeight: FontWeight.w800, color: const Color(0xFFAEC8E8)),
                ),
              ],
            ),
          ],
        ),
        SizedBox(height: compact ? 8 : 14),
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0x6B07101D),
              borderRadius: BorderRadius.circular(compact ? 22 : 29),
              border: Border.all(color: const Color(0x4459DFFF)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(compact ? 22 : 29),
              child: CustomPaint(painter: _ArenaPreviewPainter(progress: progress)),
            ),
          ),
        ),
        SizedBox(height: compact ? 8 : 12),
        const Row(
          children: <Widget>[
            _FeatureChip(icon: Icons.touch_app_rounded, label: 'کنترل مستقیم'),
            SizedBox(width: 8),
            _FeatureChip(icon: Icons.auto_awesome_rounded, label: 'سه قدرت ویژه'),
            SizedBox(width: 8),
            _FeatureChip(icon: Icons.smart_toy_rounded, label: 'ربات تطبیقی'),
          ],
        ),
      ],
    );
  }
}

class _BattlePanel extends StatelessWidget {
  const _BattlePanel({
    required this.compact,
    required this.difficulty,
    required this.pressed,
    required this.onDifficulty,
    required this.onStart,
    required this.onPressChanged,
    required this.soundEnabled,
    required this.vibrationEnabled,
    required this.onToggleSound,
    required this.onToggleVibration,
  });

  final bool compact;
  final BotDifficulty difficulty;
  final bool pressed;
  final ValueChanged<BotDifficulty> onDifficulty;
  final VoidCallback onStart;
  final ValueChanged<bool> onPressChanged;
  final bool soundEnabled;
  final bool vibrationEnabled;
  final VoidCallback onToggleSound;
  final VoidCallback onToggleVibration;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(compact ? 22 : 30),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: EdgeInsets.all(compact ? 13 : 20),
          decoration: BoxDecoration(
            color: const Color(0xD6070D19),
            borderRadius: BorderRadius.circular(compact ? 22 : 30),
            border: Border.all(color: const Color(0x995C75A2), width: 1.2),
            boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x553A5BFF), blurRadius: 36)],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    width: compact ? 39 : 48,
                    height: compact ? 39 : 48,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: const Color(0x22FF4DAF),
                      border: Border.all(color: const Color(0xAAFF4DAF)),
                    ),
                    child: Icon(Icons.smart_toy_rounded, color: const Color(0xFFFF72BE), size: compact ? 24 : 29),
                  ),
                  SizedBox(width: compact ? 9 : 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text('نبرد آفلاین', textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 18 : 23, fontWeight: FontWeight.w900)),
                        Text('حریف: نوا، هوش تاکتیکی آرنا', textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 9.5 : 11, color: const Color(0xFFAABBD7))),
                      ],
                    ),
                  ),
                  const _StatusDot(),
                ],
              ),
              SizedBox(height: compact ? 9 : 15),
              Text('سطح حریف', textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 10 : 12, color: const Color(0xFFB8C7E2), fontWeight: FontWeight.w800)),
              SizedBox(height: compact ? 5 : 8),
              Row(
                children: BotDifficulty.values.map((BotDifficulty value) {
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      child: _DifficultyButton(
                        value: value,
                        selected: difficulty == value,
                        compact: compact,
                        onTap: () => onDifficulty(value),
                      ),
                    ),
                  );
                }).toList(),
              ),
              SizedBox(height: compact ? 8 : 13),
              Container(
                padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 13, vertical: compact ? 7 : 10),
                decoration: BoxDecoration(
                  color: const Color(0x99101829),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0x3D7EDFFF)),
                ),
                child: Row(
                  children: <Widget>[
                    const _MatchRule(icon: Icons.flag_rounded, value: '۷', label: 'امتیاز'),
                    _RuleDivider(compact: compact),
                    const _MatchRule(icon: Icons.shield_rounded, value: '۳', label: 'قدرت'),
                    _RuleDivider(compact: compact),
                    const _MatchRule(icon: Icons.wifi_off_rounded, value: 'آفلاین', label: 'حالت'),
                  ],
                ),
              ),
              const Spacer(),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _SettingButton(
                      icon: soundEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                      label: 'صدا',
                      enabled: soundEnabled,
                      onTap: onToggleSound,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SettingButton(
                      icon: vibrationEnabled ? Icons.vibration_rounded : Icons.mobile_off_rounded,
                      label: 'لرزش',
                      enabled: vibrationEnabled,
                      onTap: onToggleVibration,
                    ),
                  ),
                ],
              ),
              SizedBox(height: compact ? 7 : 11),
              GestureDetector(
                onTapDown: (_) => onPressChanged(true),
                onTapCancel: () => onPressChanged(false),
                onTapUp: (_) => onStart(),
                child: AnimatedScale(
                  scale: pressed ? 0.965 : 1,
                  duration: const Duration(milliseconds: 90),
                  child: Container(
                    height: compact ? 49 : 59,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: const LinearGradient(colors: <Color>[Color(0xFF077EA5), Color(0xFF4D46C8), Color(0xFFB7257A)]),
                      border: Border.all(color: const Color(0xFFBDF7FF), width: 1.5),
                      boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x882EDFFF), blurRadius: 23), BoxShadow(color: Color(0x66FF3EAC), blurRadius: 30)],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('ورود به آرنا', textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 17 : 20, fontWeight: FontWeight.w900)),
                        const SizedBox(width: 9),
                        Icon(Icons.arrow_back_rounded, size: compact ? 21 : 25),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DifficultyButton extends StatelessWidget {
  const _DifficultyButton({required this.value, required this.selected, required this.compact, required this.onTap});
  final BotDifficulty value;
  final bool selected;
  final bool compact;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = switch (value) {
      BotDifficulty.trainee => const Color(0xFF57E3A6),
      BotDifficulty.tactical => const Color(0xFF54DFFF),
      BotDifficulty.champion => const Color(0xFFFF5CAB),
    };
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          height: compact ? 43 : 55,
          padding: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
            color: color.withValues(alpha: selected ? 0.18 : 0.055),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: selected ? 0.95 : 0.25), width: selected ? 1.4 : 1),
            boxShadow: selected ? <BoxShadow>[BoxShadow(color: color.withValues(alpha: 0.2), blurRadius: 14)] : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(value.title, textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 10 : 12, color: selected ? Colors.white : const Color(0xFFB4BED2), fontWeight: FontWeight.w900)),
              if (!compact) Text(value == BotDifficulty.tactical ? 'متعادل' : (value == BotDifficulty.trainee ? 'آسان' : 'سخت'), textDirection: TextDirection.rtl, style: TextStyle(fontSize: 8, color: color)),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureChip extends StatelessWidget {
  const _FeatureChip({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        height: 30,
        padding: const EdgeInsets.symmetric(horizontal: 7),
        decoration: BoxDecoration(color: const Color(0x7D0A1322), borderRadius: BorderRadius.circular(11), border: Border.all(color: const Color(0x3057DFFF))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, size: 14, color: const Color(0xFF67E6FF)),
            const SizedBox(width: 5),
            Flexible(child: Text(label, textDirection: TextDirection.rtl, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Color(0xFFC4D4E9)))),
          ],
        ),
      ),
    );
  }
}

class _MatchRule extends StatelessWidget {
  const _MatchRule({required this.icon, required this.value, required this.label});
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(icon, size: 16, color: const Color(0xFF70E6FF)),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(value, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
              Text(label, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 8, color: Color(0xFF8FA2C0))),
            ],
          ),
        ],
      ),
    );
  }
}

class _RuleDivider extends StatelessWidget {
  const _RuleDivider({required this.compact});
  final bool compact;

  @override
  Widget build(BuildContext context) => Container(width: 1, height: compact ? 24 : 30, color: const Color(0x345C7295));
}

class _SettingButton extends StatelessWidget {
  const _SettingButton({required this.icon, required this.label, required this.enabled, required this.onTap});
  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = enabled ? const Color(0xFF62E4FF) : const Color(0xFF7E8799);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(13),
        child: Container(
          height: 36,
          decoration: BoxDecoration(color: const Color(0x9B111A2C), borderRadius: BorderRadius.circular(13), border: Border.all(color: color.withValues(alpha: 0.35))),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[Icon(icon, size: 18, color: color), const SizedBox(width: 6), Text(label, textDirection: TextDirection.rtl, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w800))]),
        ),
      ),
    );
  }
}

class _StatusDot extends StatelessWidget {
  const _StatusDot();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(color: const Color(0x174FE3A3), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0x664FE3A3))),
      child: const Row(children: <Widget>[Icon(Icons.circle, size: 7, color: Color(0xFF55E3A6)), SizedBox(width: 4), Text('آماده', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 8.5, fontWeight: FontWeight.w800, color: Color(0xFF8CF0C4)))]),
    );
  }
}

class _StartBackgroundPainter extends CustomPainter {
  const _StartBackgroundPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const RadialGradient(center: Alignment.center, radius: 1.05, colors: <Color>[Color(0xFF111A34), Color(0xFF060A14), Color(0xFF020309)]).createShader(rect),
    );
    final double drift = math.sin(progress * math.pi * 2) * size.width * 0.03;
    canvas.drawCircle(Offset(size.width * 0.18 + drift, size.height * 0.44), size.height * 0.72, Paint()..color = const Color(0x2926CFFF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80));
    canvas.drawCircle(Offset(size.width * 0.82 - drift, size.height * 0.6), size.height * 0.65, Paint()..color = const Color(0x24FF3EAD)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80));

    final Paint line = Paint()..color = const Color(0x102FD9FF)..strokeWidth = 0.8;
    final double offset = progress * 48;
    for (double x = -size.height; x < size.width + size.height; x += 54) {
      canvas.drawLine(Offset(x + offset, size.height), Offset(x + size.height * 0.55 + offset, 0), line);
    }
  }

  @override
  bool shouldRepaint(covariant _StartBackgroundPainter oldDelegate) => oldDelegate.progress != progress;
}

class _ArenaPreviewPainter extends CustomPainter {
  const _ArenaPreviewPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF07182B), Color(0xFF090B18), Color(0xFF281025)]).createShader(rect));
    final Rect arena = rect.deflate(size.height * 0.08);
    final RRect frame = RRect.fromRectAndRadius(arena, Radius.circular(size.height * 0.06));
    canvas.drawRRect(frame, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0x885E7194));
    canvas.drawLine(arena.topLeft, arena.bottomLeft, Paint()..strokeWidth = 4..color = const Color(0xFF32DDFF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
    canvas.drawLine(arena.topRight, arena.bottomRight, Paint()..strokeWidth = 4..color = const Color(0xFFFF46AE)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));

    for (int i = 1; i < 7; i++) {
      final double y = arena.top + arena.height * i / 7;
      canvas.drawLine(Offset(arena.left, y), Offset(arena.right, y), Paint()..strokeWidth = 0.7..color = const Color(0x205985B0));
    }
    for (double y = arena.top + 8; y < arena.bottom; y += 16) {
      canvas.drawLine(Offset(arena.center.dx, y), Offset(arena.center.dx, math.min(y + 8, arena.bottom)), Paint()..strokeWidth = 1.3..color = const Color(0x667B82FF));
    }

    final double ballT = Curves.easeInOut.transform((math.sin(progress * math.pi * 2) + 1) / 2);
    final Offset ball = Offset(lerpDouble(arena.left + arena.width * 0.18, arena.right - arena.width * 0.18, ballT)!, arena.center.dy + math.sin(progress * math.pi * 4) * arena.height * 0.17);
    final Rect left = Rect.fromCenter(center: Offset(arena.left + arena.width * 0.08, arena.center.dy + math.sin(progress * math.pi * 2) * arena.height * 0.13), width: 13, height: arena.height * 0.38);
    final Rect right = Rect.fromCenter(center: Offset(arena.right - arena.width * 0.08, arena.center.dy - math.sin(progress * math.pi * 2) * arena.height * 0.13), width: 13, height: arena.height * 0.38);
    _drawPaddle(canvas, left, const Color(0xFF32DDFF));
    _drawPaddle(canvas, right, const Color(0xFFFF46AE));
    canvas.drawCircle(ball, 19, Paint()..color = const Color(0x775839FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15));
    canvas.drawCircle(ball, 8, Paint()..shader = const RadialGradient(colors: <Color>[Color(0xFFFFFFFF), Color(0xFFC98CFF), Color(0xFF6B35D8)]).createShader(Rect.fromCircle(center: ball, radius: 8)));
  }

  void _drawPaddle(Canvas canvas, Rect rect, Color color) {
    final RRect body = RRect.fromRectAndRadius(rect, const Radius.circular(7));
    canvas.drawRRect(body.inflate(5), Paint()..color = color.withValues(alpha: 0.4)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9));
    canvas.drawRRect(body, Paint()..color = color);
    canvas.drawRRect(body.deflate(3), Paint()..style = PaintingStyle.stroke..strokeWidth = 1.3..color = const Color(0xDDFFFFFF));
  }

  @override
  bool shouldRepaint(covariant _ArenaPreviewPainter oldDelegate) => oldDelegate.progress != progress;
}
