# Modular Prefabs

پس از اولین Import پروژه در Unity، ابزار `MenchinoPrefabGenerator` Prefabهای پایه UI و Gameplay را در این پوشه تولید می‌کند. بازتولید دستی از مسیر `Menchino > Regenerate Modular Prefabs` انجام می‌شود.
