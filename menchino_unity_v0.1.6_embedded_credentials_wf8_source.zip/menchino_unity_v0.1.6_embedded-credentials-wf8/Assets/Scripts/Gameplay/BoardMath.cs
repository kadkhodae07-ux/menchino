using UnityEngine;

namespace Menchino.Gameplay
{
    public static class BoardMath
    {
        public const int Size = 10;
        public const float CellSize = 0.86f;

        public static Vector2Int NumberToGrid(int cell)
        {
            cell = Mathf.Clamp(cell, 1, 100);
            int zero = cell - 1;
            int row = zero / Size;
            int index = zero % Size;
            int col = row % 2 == 0 ? index : Size - 1 - index;
            return new Vector2Int(col, row);
        }

        public static int GridToNumber(int col, int row)
        {
            col = Mathf.Clamp(col, 0, Size - 1);
            row = Mathf.Clamp(row, 0, Size - 1);
            int index = row % 2 == 0 ? col : Size - 1 - col;
            return row * Size + index + 1;
        }

        public static Vector3 NumberToWorld(int cell, float y = 0.22f)
        {
            if (cell <= 0) return new Vector3(-4.75f, y, -4.7f);
            Vector2Int grid = NumberToGrid(cell);
            float origin = -((Size - 1) * CellSize) * .5f;
            return new Vector3(origin + grid.x * CellSize, y, origin + grid.y * CellSize);
        }

        public static Vector3 PieceOffset(int slot, int count)
        {
            if (count <= 1) return Vector3.zero;
            float radius = count >= 4 ? .23f : .19f;
            float angle = Mathf.PI * 2f * slot / count + Mathf.PI * .25f;
            return new Vector3(Mathf.Cos(angle) * radius, 0f, Mathf.Sin(angle) * radius);
        }
    }
}
