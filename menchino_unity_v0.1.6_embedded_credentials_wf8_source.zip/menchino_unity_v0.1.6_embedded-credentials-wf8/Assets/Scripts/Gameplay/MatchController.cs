using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Menchino.Data;
using Menchino.Services;
using UnityEngine;

namespace Menchino.Gameplay
{
    public sealed class MatchController : MonoBehaviour
    {
        public event Action<TurnPhase> PhaseChanged;
        public event Action<PlayerMatchState> TurnStarted;
        public event Action<int> DiceRolled;
        public event Action<int, int> PieceStepped;
        public event Action<int, int, int, bool> SpecialMoveStarted;
        public event Action<int, int> PieceResetByCollision;
        public event Action<string> Notice;
        public event Action<float> TurnTimerChanged;
        public event Action<MatchResultData> MatchFinished;

        public MatchStateData State { get; private set; }
        public TurnPhase Phase { get; private set; } = TurnPhase.Init;
        public BoardLayoutData Board { get; private set; }
        public PlayerMatchState CurrentPlayer => State.players[State.currentTurnIndex];

        private GameServices _services;
        private System.Random _random;
        private bool _rollRequested;
        private float _turnTime;
        private int _finishCounter;
        private Coroutine _activeRoutine;
        private TurnPhase _phaseBeforePause = TurnPhase.AwaitDiceInput;

        public void InitializeNew(PendingMatchSettings pending, GameServices services)
        {
            _services = services;
            Board = BoardConfigLoader.Load();
            State = new MatchStateData
            {
                matchId = Guid.NewGuid().ToString("N"),
                gameMode = pending.gameMode,
                currentTurnIndex = 0,
                turnRemainingTime = pending.rules.turnTimeSeconds,
                rules = pending.rules.Clone(),
                boardId = pending.themeId,
                startedUtcTicks = DateTime.UtcNow.Ticks,
                updatedUtcTicks = DateTime.UtcNow.Ticks
            };

            int count = Mathf.Clamp(pending.playerCount, 2, 4);
            for (int i = 0; i < count; i++)
            {
                var setup = pending.players[i];
                State.players.Add(new PlayerMatchState
                {
                    playerId = i == 0 ? services.Save.Data.profile.playerId : $"player-{i}",
                    displayName = setup.displayName,
                    playerKind = setup.playerKind,
                    aiDifficulty = setup.aiDifficulty,
                    pieceColor = setup.pieceColor,
                    avatarIndex = setup.avatarIndex,
                    currentCell = pending.rules.startAtZero ? 0 : 1,
                    turnIndex = i
                });
            }

            _random = new System.Random(State.matchId.GetHashCode());
            _services.Save.SetUnfinishedMatch(State);
            BeginTurnAfter(.35f);
        }

        public void InitializeFromSave(MatchStateData saved, GameServices services)
        {
            _services = services;
            Board = BoardConfigLoader.Load();
            State = saved;
            State.isFinished = false;
            _finishCounter = State.players.Count(x => x.hasFinished);
            _random = new System.Random((State.matchId ?? "restored").GetHashCode() ^ State.diceHistory.Count);
            BeginTurnAfter(.35f);
        }

        private void Update()
        {
            if (State == null || Phase != TurnPhase.AwaitDiceInput) return;
            _turnTime = Mathf.Max(0f, _turnTime - Time.deltaTime);
            State.turnRemainingTime = _turnTime;
            TurnTimerChanged?.Invoke(_turnTime);
            if (_turnTime <= 0f) RequestRoll();
        }

        public bool RequestRoll()
        {
            if (Phase != TurnPhase.AwaitDiceInput || _rollRequested || State == null || State.isFinished) return false;
            _rollRequested = true;
            _activeRoutine = StartCoroutine(RunTurn());
            return true;
        }

        public void Pause(bool paused)
        {
            if (State == null || State.isFinished) return;
            if (paused)
            {
                if (Phase == TurnPhase.Paused) return;
                _phaseBeforePause = Phase;
                SetPhase(TurnPhase.Paused);
                Time.timeScale = 0f;
            }
            else
            {
                Time.timeScale = 1f;
                SetPhase(_phaseBeforePause);
            }
        }

        private void BeginTurnAfter(float delay)
        {
            _activeRoutine = StartCoroutine(BeginTurnRoutine(delay));
        }

        private IEnumerator BeginTurnRoutine(float delay)
        {
            SetPhase(TurnPhase.TurnStart);
            yield return new WaitForSeconds(delay);
            _rollRequested = false;
            _turnTime = Mathf.Max(8, State.rules.turnTimeSeconds);
            State.turnRemainingTime = _turnTime;
            TurnStarted?.Invoke(CurrentPlayer);
            Notice?.Invoke(CurrentPlayer.playerKind == PlayerKind.Human ? "نوبت شماست" : $"نوبت {CurrentPlayer.displayName}");
            SetPhase(TurnPhase.AwaitDiceInput);

            if (CurrentPlayer.playerKind == PlayerKind.Bot)
            {
                float wait = CurrentPlayer.aiDifficulty == AiDifficulty.Easy ? UnityEngine.Random.Range(1.1f, 2f) :
                             CurrentPlayer.aiDifficulty == AiDifficulty.Medium ? UnityEngine.Random.Range(.75f, 1.55f) :
                             UnityEngine.Random.Range(.55f, 1.25f);
                yield return new WaitForSeconds(wait);
                RequestRoll();
            }
        }

        private IEnumerator RunTurn()
        {
            var player = CurrentPlayer;
            SetPhase(TurnPhase.DiceRolling);
            int roll = _random.Next(1, 7);
            State.diceHistory.Add(roll);
            player.diceRollCount++;
            _services.Save.Data.profile.totalDiceRolls++;
            if (roll == 6) _services.Missions.Record(MissionType.RollSixes);
            DiceRolled?.Invoke(roll);
            _services.Audio.Play("dice");
            yield return new WaitForSeconds(.88f);

            if (roll == 6) player.consecutiveSixes++;
            else player.consecutiveSixes = 0;

            if (State.rules.maxConsecutiveSixes > 0 && player.consecutiveSixes >= State.rules.maxConsecutiveSixes)
            {
                Notice?.Invoke("سه تاس ۶ متوالی؛ نوبت سوخت!");
                player.consecutiveSixes = 0;
                yield return new WaitForSeconds(.7f);
                EndTurn(false);
                yield break;
            }

            MovePlan plan = RuleEngine.Plan(player.currentCell, roll, State.rules, Board);
            if (!plan.canMove)
            {
                Notice?.Invoke(player.currentCell >= 94 ? "برای رسیدن به ۱۰۰ عدد دقیق لازم است" : "حرکتی انجام نشد");
                yield return new WaitForSeconds(.7f);
                EndTurn(roll == 6 && State.rules.extraTurnOnSix);
                yield break;
            }

            SetPhase(TurnPhase.PieceMoving);
            int step = plan.from;
            while (step != plan.landing)
            {
                step += plan.landing > step ? 1 : -1;
                player.currentCell = step;
                PieceStepped?.Invoke(player.turnIndex, step);
                _services.Audio.Play("step");
                yield return new WaitForSeconds(.145f);
            }

            if (plan.usedLadder || plan.hitSnake)
            {
                SetPhase(TurnPhase.ResolvingSpecial);
                SpecialMoveStarted?.Invoke(player.turnIndex, plan.landing, plan.finalCell, plan.usedLadder);
                if (plan.usedLadder)
                {
                    player.usedLaddersCount++;
                    _services.Save.Data.profile.totalLadders++;
                    _services.Missions.Record(MissionType.UseLadders);
                    Notice?.Invoke("صعود از نردبان!");
                    _services.Audio.Play("ladder");
                }
                else
                {
                    player.hitSnakesCount++;
                    _services.Save.Data.profile.totalSnakes++;
                    Notice?.Invoke("سقوط با مار!");
                    _services.Audio.Play("snake");
                }
                yield return new WaitForSeconds(.82f);
                player.currentCell = plan.finalCell;
            }

            if (State.rules.collisionEnabled && player.currentCell > 0 && player.currentCell < 100)
            {
                foreach (var other in State.players)
                {
                    if (other.turnIndex == player.turnIndex || other.currentCell != player.currentCell || other.hasFinished) continue;
                    other.currentCell = 0;
                    PieceResetByCollision?.Invoke(other.turnIndex, 0);
                    Notice?.Invoke($"مهره {other.displayName} به شروع برگشت");
                }
            }

            if (player.currentCell == 100)
            {
                player.hasFinished = true;
                player.finishOrder = ++_finishCounter;
                _services.Missions.Record(MissionType.ReachHundred);
                CompleteMatch(player);
                yield break;
            }

            bool extra = roll == 6 && State.rules.extraTurnOnSix;
            if (extra) Notice?.Invoke("تاس ۶؛ یک نوبت اضافه!");
            yield return new WaitForSeconds(.35f);
            EndTurn(extra);
        }

        private void EndTurn(bool samePlayer)
        {
            SetPhase(TurnPhase.TurnEnd);
            if (!samePlayer)
            {
                CurrentPlayer.consecutiveSixes = 0;
                State.currentTurnIndex = NextActivePlayerIndex(State.currentTurnIndex);
            }
            State.updatedUtcTicks = DateTime.UtcNow.Ticks;
            _services.Save.SetUnfinishedMatch(State);
            BeginTurnAfter(samePlayer ? .45f : .62f);
        }

        private int NextActivePlayerIndex(int current)
        {
            for (int i = 1; i <= State.players.Count; i++)
            {
                int index = (current + i) % State.players.Count;
                if (!State.players[index].hasFinished) return index;
            }
            return current;
        }

        private void CompleteMatch(PlayerMatchState winner)
        {
            State.isFinished = true;
            SetPhase(TurnPhase.MatchFinished);
            _services.Save.ClearUnfinishedMatch();
            var profile = _services.Save.Data.profile;
            profile.totalGames++;
            _services.Missions.Record(MissionType.CompleteGames);
            bool localWon = winner.playerId == profile.playerId;
            if (localWon)
            {
                profile.totalWins++;
                _services.Missions.Record(MissionType.WinGames);
            }
            if (State.gameMode == GameMode.LocalMultiplayer || State.gameMode == GameMode.Offline)
                _services.Missions.Record(MissionType.LocalWithFriends);

            int duration = Mathf.Max(1, (int)TimeSpan.FromTicks(DateTime.UtcNow.Ticks - State.startedUtcTicks).TotalSeconds);
            profile.totalPlaySeconds += duration;
            int rewardCoins = localWon ? 250 : 90;
            int rewardXp = localWon ? 120 : 45;
            profile.experience += rewardXp;
            while (profile.experience >= profile.level * 500)
            {
                profile.experience -= profile.level * 500;
                profile.level++;
            }
            _services.Wallet.Grant(rewardCoins, 0);
            _services.Save.Save();

            var ranking = State.players
                .OrderByDescending(x => x.playerId == winner.playerId)
                .ThenByDescending(x => x.currentCell)
                .ThenBy(x => x.diceRollCount)
                .ToList();
            for (int i = 0; i < ranking.Count; i++) ranking[i].finishOrder = i + 1;
            var result = new MatchResultData
            {
                ranking = ranking,
                durationSeconds = duration,
                rewardCoins = rewardCoins,
                rewardExperience = rewardXp
            };
            _services.Audio.Play(localWon ? "win" : "reward");
            MatchFinished?.Invoke(result);
        }

        private void SetPhase(TurnPhase phase)
        {
            Phase = phase;
            PhaseChanged?.Invoke(phase);
        }
    }
}
