using Menchino.Data;
using UnityEngine;

namespace Menchino.Gameplay
{
    public readonly struct MovePlan
    {
        public readonly bool canMove;
        public readonly int from;
        public readonly int landing;
        public readonly int finalCell;
        public readonly bool usedLadder;
        public readonly bool hitSnake;
        public readonly bool bounced;

        public MovePlan(bool canMove, int from, int landing, int finalCell, bool usedLadder, bool hitSnake, bool bounced)
        {
            this.canMove = canMove;
            this.from = from;
            this.landing = landing;
            this.finalCell = finalCell;
            this.usedLadder = usedLadder;
            this.hitSnake = hitSnake;
            this.bounced = bounced;
        }
    }

    public static class RuleEngine
    {
        public static MovePlan Plan(int currentCell, int roll, RuleConfigData rules, BoardLayoutData board)
        {
            int target;
            bool bounced = false;

            if (currentCell <= 0 && rules.requiredEntryRoll > 0)
            {
                if (roll != rules.requiredEntryRoll)
                    return new MovePlan(false, currentCell, currentCell, currentCell, false, false, false);
                target = 1;
            }
            else target = currentCell + roll;
            if (target > 100)
            {
                if (rules.requireExact100 && !rules.allowBounceBack)
                    return new MovePlan(false, currentCell, currentCell, currentCell, false, false, false);

                if (rules.allowBounceBack)
                {
                    target = 100 - (target - 100);
                    bounced = true;
                }
                else target = 100;
            }

            target = Mathf.Clamp(target, 1, 100);
            int final = target;
            bool ladder = false;
            bool snake = false;

            foreach (var item in board.ladders)
            {
                if (item.from != target) continue;
                final = item.to;
                ladder = true;
                break;
            }

            if (!ladder)
            {
                foreach (var item in board.snakes)
                {
                    if (item.from != target) continue;
                    final = item.to;
                    snake = true;
                    break;
                }
            }

            return new MovePlan(true, currentCell, target, final, ladder, snake, bounced);
        }
    }
}
