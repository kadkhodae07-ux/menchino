using System;
using System.IO;
using Menchino.Data;
using UnityEngine;

namespace Menchino.Services
{
    public sealed class SaveRepository
    {
        private readonly string _path;
        public AppSaveData Data { get; private set; }

        public SaveRepository()
        {
            _path = Path.Combine(Application.persistentDataPath, "menchino_save_v1.json");
            Data = LoadInternal();
            Normalize();
        }

        private AppSaveData LoadInternal()
        {
            try
            {
                if (!File.Exists(_path)) return new AppSaveData();
                var json = File.ReadAllText(_path);
                return string.IsNullOrWhiteSpace(json) ? new AppSaveData() : JsonUtility.FromJson<AppSaveData>(json);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"Menchino save load failed: {ex.Message}");
                return new AppSaveData();
            }
        }

        private void Normalize()
        {
            Data ??= new AppSaveData();
            Data.profile ??= new PlayerProfileData();
            Data.settings ??= new SettingsData();
            Data.inventory ??= new InventoryData();
            Data.inventory.ownedThemes ??= new System.Collections.Generic.List<string>();
            Data.inventory.ownedPieces ??= new System.Collections.Generic.List<string>();
            Data.inventory.ownedDice ??= new System.Collections.Generic.List<string>();
            Data.inventory.ownedAvatars ??= new System.Collections.Generic.List<string>();
            Data.inventory.ownedFrames ??= new System.Collections.Generic.List<string>();
            Data.inventory.ownedEffects ??= new System.Collections.Generic.List<string>();
            if (!Data.inventory.ownedThemes.Contains("royal")) Data.inventory.ownedThemes.Add("royal");
            if (!Data.inventory.ownedPieces.Contains("classic")) Data.inventory.ownedPieces.Add("classic");
            if (!Data.inventory.ownedDice.Contains("ivory")) Data.inventory.ownedDice.Add("ivory");
            Data.dailyReward ??= new DailyRewardStateData();
            Data.missions ??= DefaultContent.CreateDailyMissions();
            if (Data.missions.Count == 0) Data.missions = DefaultContent.CreateDailyMissions();
            long now = DateTime.UtcNow.Ticks;
            if (Data.dailyReward.lastSeenUtcTicks == 0) Data.dailyReward.lastSeenUtcTicks = now;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_path) ?? Application.persistentDataPath);
                Data.dailyReward.lastSeenUtcTicks = Math.Max(Data.dailyReward.lastSeenUtcTicks, DateTime.UtcNow.Ticks);
                var temp = _path + ".tmp";
                File.WriteAllText(temp, JsonUtility.ToJson(Data, true));
                if (File.Exists(_path)) File.Delete(_path);
                File.Move(temp, _path);
            }
            catch (Exception ex)
            {
                Debug.LogError($"Menchino save failed: {ex}");
            }
        }

        public void SetUnfinishedMatch(MatchStateData match)
        {
            Data.unfinishedMatch = match;
            Save();
        }

        public void ClearUnfinishedMatch()
        {
            Data.unfinishedMatch = null;
            Save();
        }
    }
}
