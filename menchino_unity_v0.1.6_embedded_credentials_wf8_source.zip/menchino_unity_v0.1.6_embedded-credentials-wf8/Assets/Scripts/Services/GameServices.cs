using System;
using System.Collections.Generic;
using Menchino.Data;
using UnityEngine;

namespace Menchino.Services
{
    public sealed class GameServices
    {
        public SaveRepository Save { get; }
        public AudioService Audio { get; }
        public DailyRewardService DailyRewards { get; }
        public MissionService Missions { get; }
        public WalletService Wallet { get; }

        public GameServices(MonoBehaviour runner)
        {
            Save = new SaveRepository();
            Audio = new AudioService(runner, Save);
            Wallet = new WalletService(Save, Audio);
            DailyRewards = new DailyRewardService(Save, Wallet);
            Missions = new MissionService(Save, Wallet);
        }
    }

    public sealed class WalletService
    {
        private readonly SaveRepository _save;
        private readonly AudioService _audio;
        public event Action Changed;

        public WalletService(SaveRepository save, AudioService audio)
        {
            _save = save;
            _audio = audio;
        }

        public bool SpendCoins(int amount)
        {
            if (amount < 0 || _save.Data.profile.coins < amount) return false;
            _save.Data.profile.coins -= amount;
            _save.Save();
            Changed?.Invoke();
            return true;
        }

        public bool SpendGems(int amount)
        {
            if (amount < 0 || _save.Data.profile.gems < amount) return false;
            _save.Data.profile.gems -= amount;
            _save.Save();
            Changed?.Invoke();
            return true;
        }

        public void Grant(int coins, int gems)
        {
            _save.Data.profile.coins += Mathf.Max(0, coins);
            _save.Data.profile.gems += Mathf.Max(0, gems);
            _save.Save();
            _audio.Play("reward");
            Changed?.Invoke();
        }
    }

    public sealed class DailyRewardService
    {
        private readonly SaveRepository _save;
        private readonly WalletService _wallet;
        private static readonly int[] Coins = { 100, 150, 200, 300, 450, 650, 1000 };
        private static readonly int[] Gems = { 0, 0, 1, 1, 2, 2, 8 };

        public DailyRewardService(SaveRepository save, WalletService wallet)
        {
            _save = save;
            _wallet = wallet;
            EnsureCycle();
        }

        private void EnsureCycle()
        {
            var state = _save.Data.dailyReward;
            var now = DateTime.UtcNow;
            if (state.cycleStartUtcTicks == 0)
            {
                state.cycleStartUtcTicks = now.Date.Ticks;
                state.currentDayIndex = 0;
                state.claimedMask = 0;
                _save.Save();
                return;
            }

            var start = new DateTime(state.cycleStartUtcTicks, DateTimeKind.Utc).Date;
            int elapsed = Mathf.Max(0, (int)(now.Date - start).TotalDays);
            if (elapsed >= 7)
            {
                state.cycleStartUtcTicks = now.Date.Ticks;
                state.currentDayIndex = 0;
                state.claimedMask = 0;
                state.lastClaimUtcTicks = 0;
                _save.Save();
            }
            else
            {
                state.currentDayIndex = Mathf.Clamp(elapsed, 0, 6);
            }
        }

        public bool IsClockRollbackDetected()
        {
            return DateTime.UtcNow.Ticks + TimeSpan.FromMinutes(5).Ticks < _save.Data.dailyReward.lastSeenUtcTicks;
        }

        public bool CanClaim()
        {
            EnsureCycle();
            if (IsClockRollbackDetected()) return false;
            int day = _save.Data.dailyReward.currentDayIndex;
            return (_save.Data.dailyReward.claimedMask & (1 << day)) == 0;
        }

        public (int coins, int gems) GetReward(int day)
        {
            day = Mathf.Clamp(day, 0, 6);
            return (Coins[day], Gems[day]);
        }

        public bool Claim()
        {
            if (!CanClaim()) return false;
            var state = _save.Data.dailyReward;
            int day = state.currentDayIndex;
            state.claimedMask |= 1 << day;
            state.lastClaimUtcTicks = DateTime.UtcNow.Ticks;
            _wallet.Grant(Coins[day], Gems[day]);
            _save.Save();
            return true;
        }
    }

    public sealed class MissionService
    {
        private readonly SaveRepository _save;
        private readonly WalletService _wallet;
        public event Action Changed;

        public MissionService(SaveRepository save, WalletService wallet)
        {
            _save = save;
            _wallet = wallet;
            EnsureDailyCycle();
        }

        public IReadOnlyList<MissionStateData> Items
        {
            get
            {
                EnsureDailyCycle();
                return _save.Data.missions;
            }
        }

        private void EnsureDailyCycle()
        {
            DateTime today = DateTime.UtcNow.Date;
            if (_save.Data.missionCycleUtcTicks != 0)
            {
                DateTime savedDate = new DateTime(_save.Data.missionCycleUtcTicks, DateTimeKind.Utc).Date;
                if (savedDate == today) return;
            }
            _save.Data.missions = DefaultContent.CreateDailyMissions();
            _save.Data.missionCycleUtcTicks = today.Ticks;
            _save.Save();
            Changed?.Invoke();
        }

        public void Record(MissionType type, int amount = 1)
        {
            EnsureDailyCycle();
            bool changed = false;
            foreach (var mission in _save.Data.missions)
            {
                if (mission.type != type || mission.claimed) continue;
                int before = mission.progress;
                mission.progress = Mathf.Clamp(mission.progress + Mathf.Max(0, amount), 0, mission.target);
                changed |= mission.progress != before;
            }
            if (!changed) return;
            _save.Save();
            Changed?.Invoke();
        }

        public bool Claim(string missionId)
        {
            EnsureDailyCycle();
            var mission = _save.Data.missions.Find(x => x.missionId == missionId);
            if (mission == null || mission.claimed || mission.progress < mission.target) return false;
            mission.claimed = true;
            _wallet.Grant(mission.rewardCoins, mission.rewardGems);
            _save.Save();
            Changed?.Invoke();
            return true;
        }
    }
}
