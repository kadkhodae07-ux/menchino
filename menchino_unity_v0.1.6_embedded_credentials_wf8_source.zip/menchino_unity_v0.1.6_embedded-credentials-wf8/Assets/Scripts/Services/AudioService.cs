using System;
using System.Collections.Generic;
using Menchino.Data;
using UnityEngine;

namespace Menchino.Services
{
    public sealed class AudioService
    {
        private readonly SaveRepository _save;
        private readonly AudioSource _sfx;
        private readonly AudioSource _music;
        private readonly Dictionary<string, AudioClip> _clips = new Dictionary<string, AudioClip>();

        public AudioService(MonoBehaviour runner, SaveRepository save)
        {
            _save = save;
            _sfx = runner.gameObject.AddComponent<AudioSource>();
            _music = runner.gameObject.AddComponent<AudioSource>();
            _music.loop = true;
            _music.volume = .16f;
            _sfx.volume = .72f;
            BuildClips();
            ApplySettings();
            if (_save.Data.settings.music)
            {
                _music.clip = _clips["music"];
                _music.Play();
            }
        }

        public void ApplySettings()
        {
            _music.mute = !_save.Data.settings.music;
            _sfx.mute = !_save.Data.settings.soundEffects;
            if (!_music.mute && !_music.isPlaying)
            {
                _music.clip = _clips["music"];
                _music.Play();
            }
        }

        public void Play(string key)
        {
            if (!_save.Data.settings.soundEffects) return;
            if (_clips.TryGetValue(key, out var clip)) _sfx.PlayOneShot(clip);
        }

        private void BuildClips()
        {
            _clips["click"] = Tone("click", 520, .075f, .28f, Wave.Sine, 920);
            _clips["dice"] = Noise("dice", .42f, .22f, 8);
            _clips["step"] = Tone("step", 280, .08f, .18f, Wave.Triangle, 360);
            _clips["ladder"] = Sweep("ladder", 420, 1060, .55f, .24f);
            _clips["snake"] = Sweep("snake", 520, 110, .64f, .24f);
            _clips["reward"] = Chord("reward", new[] { 660f, 825f, 990f }, .42f, .22f);
            _clips["win"] = Chord("win", new[] { 523f, 659f, 784f, 1046f }, 1.1f, .24f);
            _clips["music"] = MusicLoop();
        }

        private enum Wave { Sine, Triangle }

        private static AudioClip Tone(string name, float frequency, float duration, float volume, Wave wave, float endFrequency = -1)
        {
            const int rate = 22050;
            int count = Mathf.CeilToInt(duration * rate);
            float[] data = new float[count];
            float phase = 0f;
            for (int i = 0; i < count; i++)
            {
                float t = i / (float)Mathf.Max(1, count - 1);
                float f = endFrequency > 0 ? Mathf.Lerp(frequency, endFrequency, t) : frequency;
                phase += 2f * Mathf.PI * f / rate;
                float sample = wave == Wave.Sine ? Mathf.Sin(phase) : 2f / Mathf.PI * Mathf.Asin(Mathf.Sin(phase));
                float env = Mathf.Sin(Mathf.PI * t);
                data[i] = sample * env * volume;
            }
            var clip = AudioClip.Create(name, count, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        private static AudioClip Sweep(string name, float from, float to, float duration, float volume)
            => Tone(name, from, duration, volume, Wave.Sine, to);

        private static AudioClip Chord(string name, float[] frequencies, float duration, float volume)
        {
            const int rate = 22050;
            int count = Mathf.CeilToInt(duration * rate);
            float[] data = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = i / (float)Mathf.Max(1, count - 1);
                float sample = 0f;
                foreach (float f in frequencies) sample += Mathf.Sin(2f * Mathf.PI * f * i / rate);
                float env = Mathf.Pow(Mathf.Sin(Mathf.PI * t), .55f);
                data[i] = sample / frequencies.Length * env * volume;
            }
            var clip = AudioClip.Create(name, count, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        private static AudioClip Noise(string name, float duration, float volume, int impacts)
        {
            const int rate = 22050;
            int count = Mathf.CeilToInt(duration * rate);
            float[] data = new float[count];
            var rng = new System.Random(2701);
            for (int i = 0; i < count; i++)
            {
                float t = i / (float)Mathf.Max(1, count - 1);
                float gate = Mathf.Pow(Mathf.Max(0f, Mathf.Sin(t * impacts * Mathf.PI)), 10f);
                data[i] = ((float)rng.NextDouble() * 2f - 1f) * gate * volume * (1f - t * .45f);
            }
            var clip = AudioClip.Create(name, count, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        private static AudioClip MusicLoop()
        {
            const int rate = 22050;
            const float duration = 8f;
            int count = Mathf.CeilToInt(duration * rate);
            float[] data = new float[count];
            float[] notes = { 261.63f, 329.63f, 392f, 329.63f, 293.66f, 369.99f, 440f, 369.99f };
            for (int i = 0; i < count; i++)
            {
                float sec = i / (float)rate;
                int beat = Mathf.FloorToInt(sec) % notes.Length;
                float local = sec - Mathf.Floor(sec);
                float env = Mathf.Sin(Mathf.PI * Mathf.Clamp01(local));
                float root = notes[beat];
                float sample = Mathf.Sin(2f * Mathf.PI * root * sec) * .45f;
                sample += Mathf.Sin(2f * Mathf.PI * root * 1.5f * sec) * .25f;
                sample += Mathf.Sin(2f * Mathf.PI * root * .5f * sec) * .2f;
                data[i] = sample * env * .16f;
            }
            var clip = AudioClip.Create("music", count, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
