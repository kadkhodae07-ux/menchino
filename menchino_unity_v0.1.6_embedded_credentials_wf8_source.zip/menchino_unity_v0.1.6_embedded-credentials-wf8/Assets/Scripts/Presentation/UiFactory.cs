using System;
using System.Collections;
using Menchino.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Menchino.Presentation
{
    public sealed class SafeAreaFitter : MonoBehaviour
    {
        private Rect _last;
        private RectTransform _rect;
        private void Awake() { _rect = transform as RectTransform; Apply(); }
        private void Update() { if (Screen.safeArea != _last) Apply(); }
        private void Apply()
        {
            _last = Screen.safeArea;
            if (_rect == null || Screen.width <= 0 || Screen.height <= 0) return;
            Vector2 min = _last.position;
            Vector2 max = _last.position + _last.size;
            min.x /= Screen.width; min.y /= Screen.height;
            max.x /= Screen.width; max.y /= Screen.height;
            _rect.anchorMin = min; _rect.anchorMax = max;
            _rect.offsetMin = Vector2.zero; _rect.offsetMax = Vector2.zero;
        }
    }

    public sealed class PressableButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        private Vector3 _baseScale;
        private Coroutine _routine;
        public bool pulse;

        private void Awake()
        {
            _baseScale = transform.localScale;
            if (pulse) _routine = StartCoroutine(Pulse());
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (_routine != null) StopCoroutine(_routine);
            transform.localScale = _baseScale * .94f;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            transform.localScale = _baseScale;
            if (pulse) _routine = StartCoroutine(Pulse());
        }

        public void OnPointerExit(PointerEventData eventData) => OnPointerUp(eventData);

        private IEnumerator Pulse()
        {
            float time = 0f;
            while (true)
            {
                time += Time.unscaledDeltaTime;
                float s = 1f + Mathf.Sin(time * 2.1f) * .018f;
                transform.localScale = _baseScale * s;
                yield return null;
            }
        }
    }

    public sealed class FloatingAnimation : MonoBehaviour
    {
        public float amount = 5f;
        public float speed = 1.4f;
        private Vector3 _start;
        private void Awake() => _start = transform.localPosition;
        private void Update() => transform.localPosition = _start + Vector3.up * (Mathf.Sin(Time.unscaledTime * speed) * amount);
    }

    public static class UiFactory
    {
        private static Font _font;
        public static Font Font
        {
            get
            {
                if (_font != null) return _font;
                try
                {
                    _font = Font.CreateDynamicFontFromOSFont(new[] { "Noto Naskh Arabic", "Noto Sans Arabic", "Roboto", "Droid Sans", "sans-serif", "Tahoma", "Arial" }, 64);
                }
                catch { _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); }
                if (_font == null) _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                return _font;
            }
        }

        public static Canvas CreateCanvas(string name = "UI")
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = go.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 20;
            var scaler = go.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = .55f;
            return canvas;
        }

        public static RectTransform CreateSafeRoot(Transform parent)
        {
            var go = new GameObject("SafeArea", typeof(RectTransform), typeof(SafeAreaFitter));
            var rt = go.GetComponent<RectTransform>();
            rt.SetParent(parent, false);
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
            return rt;
        }

        public static Image CreateImage(Transform parent, string name, Sprite sprite, Color? color = null)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            var image = go.GetComponent<Image>();
            image.transform.SetParent(parent, false);
            image.sprite = sprite;
            image.type = sprite != null && sprite.border.sqrMagnitude > 0 ? Image.Type.Sliced : Image.Type.Simple;
            image.color = color ?? Color.white;
            return image;
        }

        public static Text CreateText(Transform parent, string text, int size, Color color, TextAnchor anchor = TextAnchor.MiddleCenter, FontStyle style = FontStyle.Bold)
        {
            var go = new GameObject("Text", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text), typeof(Outline));
            go.transform.SetParent(parent, false);
            var uiText = go.GetComponent<Text>();
            uiText.font = Font;
            uiText.fontSize = size;
            uiText.fontStyle = style;
            uiText.alignment = anchor;
            uiText.horizontalOverflow = HorizontalWrapMode.Wrap;
            uiText.verticalOverflow = VerticalWrapMode.Truncate;
            uiText.resizeTextForBestFit = size >= 22;
            uiText.resizeTextMinSize = Mathf.Max(16, size / 2);
            uiText.resizeTextMaxSize = size;
            uiText.supportRichText = true;
            uiText.color = color;
            uiText.text = PersianText.Fix(text);
            var outline = go.GetComponent<Outline>();
            outline.effectColor = new Color(0.12f, 0.03f, 0.16f, .78f);
            outline.effectDistance = new Vector2(2f, -2f);
            return uiText;
        }

        public static Button CreateButton(Transform parent, string label, Sprite sprite, Action action, AudioService audio, int fontSize = 34, bool pulse = false)
        {
            var image = CreateImage(parent, "Button_" + label, sprite);
            var button = image.gameObject.AddComponent<Button>();
            button.targetGraphic = image;
            var colors = button.colors;
            colors.highlightedColor = new Color(1.08f, 1.08f, 1.08f, 1f);
            colors.pressedColor = new Color(.88f, .88f, .88f, 1f);
            colors.disabledColor = new Color(.45f, .45f, .45f, .72f);
            colors.fadeDuration = .08f;
            button.colors = colors;
            var press = image.gameObject.AddComponent<PressableButton>();
            press.pulse = pulse;
            var text = CreateText(image.transform, label, fontSize, ThemePalette.Cream);
            Stretch(text.rectTransform, new Vector2(24, 10), new Vector2(-24, -10));
            button.onClick.AddListener(() =>
            {
                audio?.Play("click");
                action?.Invoke();
            });
            return button;
        }

        public static Image CreatePanel(Transform parent, string name = "RoyalPanel", bool dark = false)
            => CreateImage(parent, name, dark ? ProceduralSpriteFactory.DarkPanel() : ProceduralSpriteFactory.RoyalPanel());

        public static Image CreateCoinIcon(Transform parent, float size = 64)
        {
            var icon = CreateImage(parent, "Coin", ProceduralSpriteFactory.Circle(ThemePalette.GoldLight, ThemePalette.GoldDark, Color.white));
            SetSize(icon.rectTransform, size, size);
            var t = CreateText(icon.transform, "$", Mathf.RoundToInt(size * .48f), ThemePalette.Cream);
            Stretch(t.rectTransform);
            return icon;
        }

        public static Image CreateGemIcon(Transform parent, float size = 64)
        {
            var icon = CreateImage(parent, "Gem", ProceduralSpriteFactory.Diamond(new Color(.92f,.38f,1f), new Color(.36f,.02f,.64f), ThemePalette.GoldLight));
            SetSize(icon.rectTransform, size, size);
            return icon;
        }

        public static RectTransform CreateCurrencyBar(Transform parent, bool gem, int value, Action onPlus, AudioService audio)
        {
            var panel = CreateImage(parent, gem ? "GemBar" : "CoinBar", ProceduralSpriteFactory.DarkPanel());
            SetSize(panel.rectTransform, 270, 76);
            var icon = gem ? CreateGemIcon(panel.transform, 58) : CreateCoinIcon(panel.transform, 58);
            Anchor(icon.rectTransform, new Vector2(0, .5f), new Vector2(0, .5f), new Vector2(36, 0));
            var amount = CreateText(panel.transform, value.ToString("N0"), 28, ThemePalette.Cream);
            amount.gameObject.name = "AmountText";
            amount.rectTransform.anchorMin = new Vector2(.2f, 0); amount.rectTransform.anchorMax = new Vector2(.78f, 1);
            amount.rectTransform.offsetMin = Vector2.zero; amount.rectTransform.offsetMax = Vector2.zero;
            var plus = CreateButton(panel.transform, "+", ProceduralSpriteFactory.GreenButton(96,96), onPlus, audio, 40);
            SetSize(plus.GetComponent<RectTransform>(), 60, 60);
            Anchor(plus.GetComponent<RectTransform>(), new Vector2(1,.5f), new Vector2(1,.5f), new Vector2(-34,0));
            return panel.rectTransform;
        }

        public static RectTransform CreateHeader(Transform parent, string title, Action back, AudioService audio)
        {
            var panel = CreatePanel(parent, "Header");
            panel.rectTransform.anchorMin = new Vector2(.1f, 1); panel.rectTransform.anchorMax = new Vector2(.9f, 1);
            panel.rectTransform.pivot = new Vector2(.5f, 1);
            panel.rectTransform.anchoredPosition = new Vector2(0, -18);
            panel.rectTransform.sizeDelta = new Vector2(0, 112);
            var text = CreateText(panel.transform, title, 48, ThemePalette.GoldLight);
            Stretch(text.rectTransform, new Vector2(120, 12), new Vector2(-120, -12));
            if (back != null)
            {
                var button = CreateButton(panel.transform, "←", ProceduralSpriteFactory.PurpleButton(96,96), back, audio, 40);
                SetSize(button.GetComponent<RectTransform>(), 76, 76);
                Anchor(button.GetComponent<RectTransform>(), new Vector2(0,.5f), new Vector2(0,.5f), new Vector2(48,0));
            }
            return panel.rectTransform;
        }

        public static void Stretch(RectTransform rt, Vector2? minOffset = null, Vector2? maxOffset = null)
        {
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = minOffset ?? Vector2.zero;
            rt.offsetMax = maxOffset ?? Vector2.zero;
        }

        public static void SetSize(RectTransform rt, float width, float height) => rt.sizeDelta = new Vector2(width, height);

        public static void Anchor(RectTransform rt, Vector2 min, Vector2 max, Vector2 pos)
        {
            rt.anchorMin = min; rt.anchorMax = max; rt.pivot = (min + max) * .5f;
            rt.anchoredPosition = pos;
        }

        public static void EnsureEventSystem()
        {
            var existing = UnityEngine.Object.FindObjectOfType<EventSystem>();
            if (existing != null)
            {
                UnityEngine.Object.DontDestroyOnLoad(existing.gameObject);
                return;
            }
            var eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            UnityEngine.Object.DontDestroyOnLoad(eventSystem);
        }
    }
}
