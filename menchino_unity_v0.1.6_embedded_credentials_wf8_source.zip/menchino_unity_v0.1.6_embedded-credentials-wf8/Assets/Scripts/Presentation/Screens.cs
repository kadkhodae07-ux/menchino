using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Menchino.Core;
using Menchino.Data;
using Menchino.Gameplay;
using Menchino.Services;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.Presentation
{
    public static class ScreenComposer
    {
        public static ScreenBase Create(string sceneName, MenchinoApp app)
        {
            var root = new GameObject("Screen_" + sceneName);
            ScreenBase screen;
            switch (sceneName)
            {
                case "Home": screen = root.AddComponent<HomeScreen>(); break;
                case "ModeSelect": screen = root.AddComponent<ModeSelectScreen>(); break;
                case "SnakesSetup": screen = root.AddComponent<SetupScreen>(); break;
                case "SnakesGameplay": screen = root.AddComponent<GameplayScreen>(); break;
                case "Result": screen = root.AddComponent<ResultScreen>(); break;
                case "DailyReward": screen = root.AddComponent<DailyRewardScreen>(); break;
                case "Missions": screen = root.AddComponent<MissionsScreen>(); break;
                case "Shop": screen = root.AddComponent<ShopScreen>(); break;
                case "Profile": screen = root.AddComponent<ProfileScreen>(); break;
                case "Settings": screen = root.AddComponent<SettingsScreen>(); break;
                default: screen = root.AddComponent<HomeScreen>(); break;
            }
            screen.Initialize(app);
            return screen;
        }
    }

    public abstract class ScreenBase : MonoBehaviour
    {
        protected MenchinoApp App;
        protected Canvas Canvas;
        protected RectTransform SafeRoot;
        protected RectTransform Content;

        public void Initialize(MenchinoApp app)
        {
            App = app;
            Build();
        }

        protected abstract void Build();

        protected void CreateBase(bool castles = true)
        {
            Canvas = UiFactory.CreateCanvas(name + "Canvas");
            Canvas.transform.SetParent(transform, false);
            var background = UiFactory.CreateImage(Canvas.transform, "FantasyBackground", ProceduralSpriteFactory.Background());
            UiFactory.Stretch(background.rectTransform);
            if (castles) CreateCastleSilhouette(background.transform);
            SafeRoot = UiFactory.CreateSafeRoot(Canvas.transform);
            Content = new GameObject("Content", typeof(RectTransform)).GetComponent<RectTransform>();
            Content.SetParent(SafeRoot, false);
            UiFactory.Stretch(Content);
            gameObject.AddComponent<ScreenEntranceAnimation>().target = Content;
        }

        protected void CreateCastleSilhouette(Transform parent)
        {
            var city = new GameObject("CastleCity", typeof(RectTransform)).GetComponent<RectTransform>();
            city.SetParent(parent, false);
            city.anchorMin = new Vector2(0, 0); city.anchorMax = new Vector2(1, .58f);
            city.offsetMin = city.offsetMax = Vector2.zero;
            Color towerColor = new Color(.07f, .035f, .15f, .72f);
            for (int i = 0; i < 9; i++)
            {
                float x = i / 8f;
                float h = 170 + (i * 97 % 230);
                var tower = UiFactory.CreateImage(city, "Tower", ProceduralSpriteFactory.DarkPanel(), towerColor);
                tower.rectTransform.anchorMin = tower.rectTransform.anchorMax = new Vector2(x, 0);
                tower.rectTransform.pivot = new Vector2(.5f, 0);
                tower.rectTransform.sizeDelta = new Vector2(105 + (i % 3) * 26, h);
                tower.rectTransform.anchoredPosition = Vector2.zero;
                var roof = UiFactory.CreateImage(tower.transform, "Roof", ProceduralSpriteFactory.Diamond(towerColor, towerColor, towerColor, 96), towerColor);
                roof.rectTransform.anchorMin = roof.rectTransform.anchorMax = new Vector2(.5f, 1);
                roof.rectTransform.sizeDelta = new Vector2(118, 118);
                roof.rectTransform.anchoredPosition = new Vector2(0, 16);
                for (int w = 0; w < 3; w++)
                {
                    var window = UiFactory.CreateImage(tower.transform, "Window", ProceduralSpriteFactory.Circle(ThemePalette.GoldLight, ThemePalette.GoldDark, ThemePalette.GoldLight, 48));
                    window.rectTransform.anchorMin = window.rectTransform.anchorMax = new Vector2(.5f, .28f + w * .22f);
                    window.rectTransform.sizeDelta = new Vector2(20, 31);
                    window.rectTransform.anchoredPosition = Vector2.zero;
                }
            }
        }

        protected RectTransform CreateLogo(Transform parent, float topY = -145f, float width = 570f)
        {
            var plate = UiFactory.CreatePanel(parent, "MenchinoLogo");
            plate.rectTransform.anchorMin = plate.rectTransform.anchorMax = new Vector2(.5f, 1f);
            plate.rectTransform.pivot = new Vector2(.5f, 1f);
            plate.rectTransform.anchoredPosition = new Vector2(0, topY);
            plate.rectTransform.sizeDelta = new Vector2(width, 190);
            var crown = UiFactory.CreateText(plate.transform, "♛", 62, ThemePalette.GoldLight);
            crown.rectTransform.anchorMin = new Vector2(.38f, .69f); crown.rectTransform.anchorMax = new Vector2(.62f, 1.08f);
            crown.rectTransform.offsetMin = crown.rectTransform.offsetMax = Vector2.zero;
            var title = UiFactory.CreateText(plate.transform, "منچینو", 82, ThemePalette.GoldLight);
            title.rectTransform.anchorMin = new Vector2(.05f, .05f); title.rectTransform.anchorMax = new Vector2(.95f, .82f);
            title.rectTransform.offsetMin = title.rectTransform.offsetMax = Vector2.zero;
            plate.gameObject.AddComponent<FloatingAnimation>().amount = 4f;
            return plate.rectTransform;
        }

        protected RectTransform CreateMiniBoard(Transform parent)
        {
            var frame = UiFactory.CreatePanel(parent, "MiniBoard", true);
            var grid = new GameObject("Grid", typeof(RectTransform), typeof(GridLayoutGroup)).GetComponent<RectTransform>();
            grid.SetParent(frame.transform, false);
            grid.anchorMin = new Vector2(.08f, .09f); grid.anchorMax = new Vector2(.92f, .91f);
            grid.offsetMin = grid.offsetMax = Vector2.zero;
            var layout = grid.GetComponent<GridLayoutGroup>();
            layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            layout.constraintCount = 8;
            layout.spacing = new Vector2(3, 3);
            layout.cellSize = new Vector2(57, 50);
            Color[] colors = { ThemePalette.Red, ThemePalette.Blue, ThemePalette.Green, ThemePalette.Gold, ThemePalette.PurpleLight, ThemePalette.Cream };
            for (int i = 0; i < 48; i++)
            {
                var tile = UiFactory.CreateImage(grid, "Tile", ProceduralSpriteFactory.PurpleButton(64, 64), colors[(i * 5) % colors.Length]);
                var n = UiFactory.CreateText(tile.transform, ((i + 1) * 2).ToString(), 17, ThemePalette.Ink);
                UiFactory.Stretch(n.rectTransform);
            }
            var snake = new GameObject("Snake", typeof(RectTransform)).GetComponent<RectTransform>();
            snake.SetParent(frame.transform, false);
            snake.anchorMin = new Vector2(.2f, .2f); snake.anchorMax = new Vector2(.8f, .8f);
            snake.offsetMin = snake.offsetMax = Vector2.zero;
            for (int i = 0; i < 8; i++)
            {
                var segment = UiFactory.CreateImage(snake, "SnakeSegment", ProceduralSpriteFactory.Circle(new Color(.4f, .95f, .25f), new Color(.08f, .42f, .08f), ThemePalette.GoldLight, 64));
                segment.rectTransform.anchorMin = segment.rectTransform.anchorMax = new Vector2(.16f + i * .09f, .72f - i * .07f + Mathf.Sin(i) * .08f);
                segment.rectTransform.sizeDelta = new Vector2(44 - i, 44 - i);
                segment.rectTransform.anchoredPosition = Vector2.zero;
            }
            for (int i = 0; i < 5; i++)
            {
                var rung = UiFactory.CreateImage(frame.transform, "LadderRung", ProceduralSpriteFactory.GoldButton(128, 32));
                rung.rectTransform.anchorMin = rung.rectTransform.anchorMax = new Vector2(.62f, .25f + i * .10f);
                rung.rectTransform.sizeDelta = new Vector2(120, 17);
                rung.rectTransform.rotation = Quaternion.Euler(0, 0, 22);
            }
            return frame.rectTransform;
        }

        protected Button BottomNavButton(Transform parent, string label, Action action, Sprite sprite = null)
        {
            return UiFactory.CreateButton(parent, label, sprite ?? ProceduralSpriteFactory.PurpleButton(), action, App.Services.Audio, 27);
        }

        protected static void SetRect(RectTransform rt, Vector2 min, Vector2 max, Vector2 minOffset, Vector2 maxOffset)
        {
            rt.anchorMin = min; rt.anchorMax = max; rt.offsetMin = minOffset; rt.offsetMax = maxOffset;
        }
    }

    public sealed class ScreenEntranceAnimation : MonoBehaviour
    {
        public RectTransform target;
        private IEnumerator Start()
        {
            if (target == null) yield break;
            target.localScale = Vector3.one * .96f;
            var group = target.gameObject.AddComponent<CanvasGroup>();
            group.alpha = 0;
            float time = 0;
            while (time < .28f)
            {
                time += Time.unscaledDeltaTime;
                float t = Mathf.Clamp01(time / .28f);
                group.alpha = t;
                target.localScale = Vector3.one * Mathf.Lerp(.96f, 1f, 1f - Mathf.Pow(1f - t, 3f));
                yield return null;
            }
            group.alpha = 1; target.localScale = Vector3.one;
        }
    }

    public sealed class HomeScreen : ScreenBase
    {
        private Text _coinText;
        private Text _gemText;

        protected override void Build()
        {
            CreateBase();
            var profile = App.Services.Save.Data.profile;

            var profileCard = UiFactory.CreatePanel(Content, "ProfileCard");
            SetRect(profileCard.rectTransform, new Vector2(.035f, .89f), new Vector2(.37f, .98f), Vector2.zero, Vector2.zero);
            var avatar = UiFactory.CreateImage(profileCard.transform, "Avatar", ProceduralSpriteFactory.Circle(ThemePalette.GoldLight, ThemePalette.PurpleDark, Color.white));
            SetRect(avatar.rectTransform, new Vector2(.02f, .07f), new Vector2(.30f, .93f), Vector2.zero, Vector2.zero);
            var face = UiFactory.CreateText(avatar.transform, "●‿●", 31, ThemePalette.Cream);
            UiFactory.Stretch(face.rectTransform);
            var name = UiFactory.CreateText(profileCard.transform, profile.displayName, 32, ThemePalette.Cream);
            SetRect(name.rectTransform, new Vector2(.30f, .48f), new Vector2(.94f, .92f), Vector2.zero, Vector2.zero);
            var level = UiFactory.CreateText(profileCard.transform, $"سطح {profile.level}  ★ {profile.stars}", 22, ThemePalette.GoldLight);
            SetRect(level.rectTransform, new Vector2(.30f, .06f), new Vector2(.94f, .50f), Vector2.zero, Vector2.zero);

            var coinBar = UiFactory.CreateCurrencyBar(Content, false, profile.coins, () => App.Navigate(ScreenId.Shop), App.Services.Audio);
            SetRect(coinBar, new Vector2(.69f, .935f), new Vector2(.965f, .98f), Vector2.zero, Vector2.zero);
            _coinText = coinBar.Find("AmountText")?.GetComponent<Text>();
            var gemBar = UiFactory.CreateCurrencyBar(Content, true, profile.gems, () => App.Navigate(ScreenId.Shop), App.Services.Audio);
            SetRect(gemBar, new Vector2(.69f, .88f), new Vector2(.965f, .925f), Vector2.zero, Vector2.zero);
            _gemText = gemBar.Find("AmountText")?.GetComponent<Text>();

            CreateLogo(Content, -105f, 565f);

            var hero = UiFactory.CreatePanel(Content, "SnakesHero");
            SetRect(hero.rectTransform, new Vector2(.055f, .42f), new Vector2(.945f, .76f), Vector2.zero, Vector2.zero);
            var title = UiFactory.CreateText(hero.transform, "مار و پله", 62, ThemePalette.GoldLight);
            SetRect(title.rectTransform, new Vector2(.05f, .72f), new Vector2(.95f, .97f), Vector2.zero, Vector2.zero);
            var preview = CreateMiniBoard(hero.transform);
            SetRect(preview, new Vector2(.08f, .16f), new Vector2(.92f, .72f), Vector2.zero, Vector2.zero);
            var tagline = UiFactory.CreateText(hero.transform, "هیجان، شانس و صعود تا قله!", 27, ThemePalette.Cream);
            SetRect(tagline.rectTransform, new Vector2(.08f, .01f), new Vector2(.92f, .18f), Vector2.zero, Vector2.zero);

            var start = UiFactory.CreateButton(Content, "شروع بازی", ProceduralSpriteFactory.GoldButton(), () => App.Navigate(ScreenId.ModeSelect), App.Services.Audio, 54, true);
            SetRect(start.GetComponent<RectTransform>(), new Vector2(.15f, .335f), new Vector2(.85f, .415f), Vector2.zero, Vector2.zero);

            if (App.Services.Save.Data.unfinishedMatch != null && !App.Services.Save.Data.unfinishedMatch.isFinished)
            {
                var resume = UiFactory.CreateButton(Content, "ادامه بازی نیمه‌تمام", ProceduralSpriteFactory.GreenButton(), () =>
                {
                    App.ResumeRequested = true;
                    App.Navigate(ScreenId.SnakesGameplay);
                }, App.Services.Audio, 27);
                SetRect(resume.GetComponent<RectTransform>(), new Vector2(.24f, .285f), new Vector2(.76f, .333f), Vector2.zero, Vector2.zero);
            }

            var daily = UiFactory.CreatePanel(Content, "DailyMini");
            SetRect(daily.rectTransform, new Vector2(.04f, .12f), new Vector2(.485f, .28f), Vector2.zero, Vector2.zero);
            var chest = UiFactory.CreateText(daily.transform, "▣", 68, ThemePalette.GoldLight);
            SetRect(chest.rectTransform, new Vector2(.03f, .22f), new Vector2(.27f, .86f), Vector2.zero, Vector2.zero);
            var dailyTitle = UiFactory.CreateText(daily.transform, "جایزه روزانه", 31, ThemePalette.GoldLight);
            SetRect(dailyTitle.rectTransform, new Vector2(.28f, .55f), new Vector2(.95f, .90f), Vector2.zero, Vector2.zero);
            var dailyText = UiFactory.CreateText(daily.transform, App.Services.DailyRewards.CanClaim() ? "جایزه آماده دریافت است" : "جایزه امروز دریافت شده", 20, ThemePalette.Cream, TextAnchor.MiddleCenter, FontStyle.Normal);
            SetRect(dailyText.rectTransform, new Vector2(.28f, .18f), new Vector2(.95f, .56f), Vector2.zero, Vector2.zero);
            var dailyButton = UiFactory.CreateButton(daily.transform, "مشاهده", ProceduralSpriteFactory.GreenButton(), () => App.Navigate(ScreenId.DailyReward), App.Services.Audio, 22);
            SetRect(dailyButton.GetComponent<RectTransform>(), new Vector2(.52f, -.05f), new Vector2(.93f, .24f), Vector2.zero, Vector2.zero);

            var missions = UiFactory.CreatePanel(Content, "MissionsMini");
            SetRect(missions.rectTransform, new Vector2(.515f, .12f), new Vector2(.96f, .28f), Vector2.zero, Vector2.zero);
            var missionTitle = UiFactory.CreateText(missions.transform, "مأموریت‌های امروز", 31, ThemePalette.GoldLight);
            SetRect(missionTitle.rectTransform, new Vector2(.07f, .59f), new Vector2(.93f, .91f), Vector2.zero, Vector2.zero);
            int completed = App.Services.Missions.Items.Count(x => x.progress >= x.target);
            var missionProgress = UiFactory.CreateText(missions.transform, $"{completed} از {App.Services.Missions.Items.Count} مأموریت کامل", 22, ThemePalette.Cream, TextAnchor.MiddleCenter, FontStyle.Normal);
            SetRect(missionProgress.rectTransform, new Vector2(.07f, .28f), new Vector2(.93f, .60f), Vector2.zero, Vector2.zero);
            var missionButton = UiFactory.CreateButton(missions.transform, "مشاهده همه", ProceduralSpriteFactory.BlueButton(), () => App.Navigate(ScreenId.Missions), App.Services.Audio, 22);
            SetRect(missionButton.GetComponent<RectTransform>(), new Vector2(.29f, -.05f), new Vector2(.72f, .24f), Vector2.zero, Vector2.zero);

            var bottom = UiFactory.CreatePanel(Content, "BottomBar");
            SetRect(bottom.rectTransform, new Vector2(.03f, .015f), new Vector2(.97f, .105f), Vector2.zero, Vector2.zero);
            var shop = BottomNavButton(bottom.transform, "فروشگاه", () => App.Navigate(ScreenId.Shop), ProceduralSpriteFactory.PurpleButton());
            SetRect(shop.GetComponent<RectTransform>(), new Vector2(.03f, .10f), new Vector2(.32f, .90f), Vector2.zero, Vector2.zero);
            var profileButton = BottomNavButton(bottom.transform, "پروفایل", () => App.Navigate(ScreenId.Profile), ProceduralSpriteFactory.GreenButton());
            SetRect(profileButton.GetComponent<RectTransform>(), new Vector2(.355f, .10f), new Vector2(.645f, .90f), Vector2.zero, Vector2.zero);
            var settings = BottomNavButton(bottom.transform, "تنظیمات", () => App.Navigate(ScreenId.Settings), ProceduralSpriteFactory.PurpleButton());
            SetRect(settings.GetComponent<RectTransform>(), new Vector2(.68f, .10f), new Vector2(.97f, .90f), Vector2.zero, Vector2.zero);

            App.Services.Wallet.Changed += UpdateWallet;
        }

        private void OnDestroy() { if (App?.Services?.Wallet != null) App.Services.Wallet.Changed -= UpdateWallet; }
        private void UpdateWallet()
        {
            if (_coinText != null) _coinText.text = App.Services.Save.Data.profile.coins.ToString("N0");
            if (_gemText != null) _gemText.text = App.Services.Save.Data.profile.gems.ToString("N0");
        }
    }

    public sealed class ModeSelectScreen : ScreenBase
    {
        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "انتخاب حالت بازی", () => App.Navigate(ScreenId.Home), App.Services.Audio);
            CreateLogo(Content, -150f, 460f);
            CreateModeCard(new Vector2(.05f, .49f), new Vector2(.49f, .76f), "آفلاین", "بدون اینترنت؛ ۲ تا ۴ بازیکن", ThemePalette.Blue, GameMode.Offline, "⚄");
            CreateModeCard(new Vector2(.51f, .49f), new Vector2(.95f, .76f), "بازی با ربات", "سه سطح هوش مصنوعی منصفانه", ThemePalette.Green, GameMode.VsBots, "◎");
            CreateModeCard(new Vector2(.05f, .20f), new Vector2(.49f, .47f), "چندنفره روی یک دستگاه", "بازی خانوادگی و دوستانه", ThemePalette.PurpleLight, GameMode.LocalMultiplayer, "●●");
            CreateModeCard(new Vector2(.51f, .20f), new Vector2(.95f, .47f), "آنلاین", "رقابت واقعی در نسخه آینده", ThemePalette.BlueDark, GameMode.OnlineLocked, "◇");
            var hint = UiFactory.CreatePanel(Content, "ModeHint", true);
            SetRect(hint.rectTransform, new Vector2(.12f, .08f), new Vector2(.88f, .17f), Vector2.zero, Vector2.zero);
            var text = UiFactory.CreateText(hint.transform, "حالت انتخاب‌شده با نور طلایی مشخص می‌شود", 25, ThemePalette.Cream);
            UiFactory.Stretch(text.rectTransform, new Vector2(20, 12), new Vector2(-20, -12));
        }

        private void CreateModeCard(Vector2 min, Vector2 max, string title, string description, Color accent, GameMode mode, string symbol)
        {
            var card = UiFactory.CreatePanel(Content, "Mode_" + mode);
            SetRect(card.rectTransform, min, max, Vector2.zero, Vector2.zero);
            var art = UiFactory.CreateImage(card.transform, "Art", ProceduralSpriteFactory.Circle(Color.Lerp(accent, Color.white, .35f), Color.Lerp(accent, Color.black, .25f), ThemePalette.GoldLight));
            SetRect(art.rectTransform, new Vector2(.22f, .46f), new Vector2(.78f, .94f), Vector2.zero, Vector2.zero);
            var icon = UiFactory.CreateText(art.transform, symbol, 66, ThemePalette.Cream);
            UiFactory.Stretch(icon.rectTransform);
            var titleText = UiFactory.CreateText(card.transform, title, 38, ThemePalette.GoldLight);
            SetRect(titleText.rectTransform, new Vector2(.06f, .25f), new Vector2(.94f, .49f), Vector2.zero, Vector2.zero);
            var desc = UiFactory.CreateText(card.transform, description, 22, ThemePalette.Cream, TextAnchor.MiddleCenter, FontStyle.Normal);
            SetRect(desc.rectTransform, new Vector2(.07f, .05f), new Vector2(.93f, .27f), Vector2.zero, Vector2.zero);
            var button = card.gameObject.AddComponent<Button>();
            button.targetGraphic = card;
            button.onClick.AddListener(() =>
            {
                App.Services.Audio.Play("click");
                if (mode == GameMode.OnlineLocked)
                {
                    App.ShowPopup("آنلاین", "زیرساخت این حالت در معماری پروژه آماده است و در نسخه آنلاین فعال می‌شود.", "باشه", null);
                    return;
                }
                App.PendingMatch = DefaultContent.CreatePendingSettings(mode, App.Services.Save.Data.profile);
                App.Navigate(ScreenId.SnakesSetup);
            });
            card.gameObject.AddComponent<PressableButton>();
        }
    }

    public sealed class SetupScreen : ScreenBase
    {
        private RectTransform _body;
        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "آماده‌سازی مار و پله", () => App.Navigate(ScreenId.ModeSelect), App.Services.Audio);
            BuildBody();
        }

        private void BuildBody()
        {
            if (_body != null) Destroy(_body.gameObject);
            _body = new GameObject("SetupBody", typeof(RectTransform)).GetComponent<RectTransform>();
            _body.SetParent(Content, false); UiFactory.Stretch(_body);
            var pending = App.PendingMatch ?? DefaultContent.CreatePendingSettings(GameMode.VsBots, App.Services.Save.Data.profile);
            EnsurePlayers(pending);

            var preview = CreateMiniBoard(_body);
            SetRect(preview, new Vector2(.17f, .67f), new Vector2(.83f, .89f), Vector2.zero, Vector2.zero);

            var countPanel = UiFactory.CreatePanel(_body, "PlayerCount");
            SetRect(countPanel.rectTransform, new Vector2(.07f, .59f), new Vector2(.93f, .66f), Vector2.zero, Vector2.zero);
            var countLabel = UiFactory.CreateText(countPanel.transform, "تعداد بازیکنان", 29, ThemePalette.GoldLight);
            SetRect(countLabel.rectTransform, new Vector2(.64f, .12f), new Vector2(.96f, .88f), Vector2.zero, Vector2.zero);
            for (int count = 2; count <= 4; count++)
            {
                int captured = count;
                var sprite = pending.playerCount == count ? ProceduralSpriteFactory.GoldButton() : ProceduralSpriteFactory.PurpleButton();
                var btn = UiFactory.CreateButton(countPanel.transform, $"{count} نفره", sprite, () => { pending.playerCount = captured; BuildBody(); }, App.Services.Audio, 26);
                float x = .04f + (count - 2) * .20f;
                SetRect(btn.GetComponent<RectTransform>(), new Vector2(x, .14f), new Vector2(x + .18f, .86f), Vector2.zero, Vector2.zero);
            }

            for (int i = 0; i < 4; i++)
            {
                float col = i % 2; float row = i / 2;
                Vector2 min = new Vector2(.055f + col * .475f, .42f - row * .17f);
                Vector2 max = new Vector2(.475f + col * .475f, .58f - row * .17f);
                CreatePlayerCard(_body, i, min, max, pending);
            }

            var difficulty = UiFactory.CreatePanel(_body, "Difficulty");
            SetRect(difficulty.rectTransform, new Vector2(.06f, .18f), new Vector2(.94f, .245f), Vector2.zero, Vector2.zero);
            var diffTitle = UiFactory.CreateText(difficulty.transform, "سطح ربات‌ها", 27, ThemePalette.GoldLight);
            SetRect(diffTitle.rectTransform, new Vector2(.71f, .10f), new Vector2(.96f, .90f), Vector2.zero, Vector2.zero);
            AiDifficulty[] levels = { AiDifficulty.Easy, AiDifficulty.Medium, AiDifficulty.Hard };
            string[] names = { "آسان", "متوسط", "سخت" };
            for (int i = 0; i < levels.Length; i++)
            {
                var level = levels[i];
                var sprite = pending.botDifficulty == level ? ProceduralSpriteFactory.GoldButton() : ProceduralSpriteFactory.PurpleButton();
                var button = UiFactory.CreateButton(difficulty.transform, names[i], sprite, () =>
                {
                    pending.botDifficulty = level;
                    foreach (var p in pending.players) if (p.playerKind == PlayerKind.Bot) p.aiDifficulty = level;
                    BuildBody();
                }, App.Services.Audio, 24);
                float x = .05f + i * .215f;
                SetRect(button.GetComponent<RectTransform>(), new Vector2(x, .12f), new Vector2(x + .19f, .88f), Vector2.zero, Vector2.zero);
            }

            var rules = UiFactory.CreatePanel(_body, "Rules", true);
            SetRect(rules.rectTransform, new Vector2(.055f, .06f), new Vector2(.65f, .175f), Vector2.zero, Vector2.zero);
            CreateRuleToggle(rules.transform, "ورود دقیق به ۱۰۰", pending.rules.requireExact100, .68f, value => { pending.rules.requireExact100 = value; BuildBody(); });
            CreateRuleToggle(rules.transform, "نوبت اضافه با ۶", pending.rules.extraTurnOnSix, .36f, value => { pending.rules.extraTurnOnSix = value; BuildBody(); });
            CreateRuleToggle(rules.transform, "برخورد مهره‌ها", pending.rules.collisionEnabled, .04f, value => { pending.rules.collisionEnabled = value; BuildBody(); });

            var theme = UiFactory.CreatePanel(_body, "Theme");
            SetRect(theme.rectTransform, new Vector2(.67f, .06f), new Vector2(.945f, .175f), Vector2.zero, Vector2.zero);
            var themeTitle = UiFactory.CreateText(theme.transform, "تم و قوانین", 24, ThemePalette.GoldLight);
            SetRect(themeTitle.rectTransform, new Vector2(.07f, .73f), new Vector2(.93f, .96f), Vector2.zero, Vector2.zero);
            var themeButton = UiFactory.CreateButton(theme.transform, pending.themeId == "royal" ? "تم پادشاهی" : "تم شب جادویی", pending.themeId == "royal" ? ProceduralSpriteFactory.GreenButton() : ProceduralSpriteFactory.BlueButton(), () => { pending.themeId = pending.themeId == "royal" ? "night" : "royal"; BuildBody(); }, App.Services.Audio, 18);
            SetRect(themeButton.GetComponent<RectTransform>(), new Vector2(.08f, .39f), new Vector2(.92f, .72f), Vector2.zero, Vector2.zero);
            var advanced = UiFactory.CreateButton(theme.transform, AdvancedRuleLabel(pending.rules), ProceduralSpriteFactory.PurpleButton(), () => { CycleAdvancedRules(pending.rules); BuildBody(); }, App.Services.Audio, 16);
            SetRect(advanced.GetComponent<RectTransform>(), new Vector2(.08f, .06f), new Vector2(.92f, .37f), Vector2.zero, Vector2.zero);

            var start = UiFactory.CreateButton(_body, "شروع مار و پله", ProceduralSpriteFactory.GoldButton(), () =>
            {
                App.Services.Save.ClearUnfinishedMatch();
                App.ResumeRequested = false;
                App.Navigate(ScreenId.SnakesGameplay);
            }, App.Services.Audio, 48, true);
            SetRect(start.GetComponent<RectTransform>(), new Vector2(.18f, .005f), new Vector2(.82f, .058f), Vector2.zero, Vector2.zero);
        }

        private static void EnsurePlayers(PendingMatchSettings pending)
        {
            while (pending.players.Count < 4)
            {
                int i = pending.players.Count;
                pending.players.Add(new PlayerSetupData { displayName = DefaultContent.PersianPlayerNames[i], pieceColor = (PieceColor)i, avatarIndex = i, playerKind = i == 0 ? PlayerKind.Human : PlayerKind.Bot, aiDifficulty = pending.botDifficulty });
            }
            if (pending.gameMode == GameMode.LocalMultiplayer || pending.gameMode == GameMode.Offline)
                for (int i = 0; i < pending.players.Count; i++) pending.players[i].playerKind = PlayerKind.Human;
            else pending.players[0].playerKind = PlayerKind.Human;
        }

        private void CreatePlayerCard(Transform parent, int index, Vector2 min, Vector2 max, PendingMatchSettings pending)
        {
            bool enabled = index < pending.playerCount;
            var card = UiFactory.CreatePanel(parent, "PlayerCard_" + index);
            SetRect(card.rectTransform, min, max, Vector2.zero, Vector2.zero);
            card.color = enabled ? Color.white : new Color(.35f, .35f, .35f, .68f);
            var player = pending.players[index];
            Color pieceColor = ThemePalette.PieceColor((int)player.pieceColor);
            var avatar = UiFactory.CreateImage(card.transform, "Avatar", ProceduralSpriteFactory.Circle(Color.Lerp(pieceColor, Color.white, .35f), ThemePalette.PurpleDark, ThemePalette.GoldLight));
            SetRect(avatar.rectTransform, new Vector2(.04f, .18f), new Vector2(.31f, .88f), Vector2.zero, Vector2.zero);
            string[] faces = { "●‿●", "●ᴗ●", "◕‿◕", "•ᴗ•", "◉‿◉", "●◡●", "◕ᴗ◕", "•‿•" };
            var face = UiFactory.CreateText(avatar.transform, faces[Mathf.Abs(player.avatarIndex) % faces.Length], 22, ThemePalette.Cream);
            UiFactory.Stretch(face.rectTransform);
            var avatarButton = avatar.gameObject.AddComponent<Button>();
            avatarButton.targetGraphic = avatar;
            avatarButton.interactable = enabled;
            avatarButton.onClick.AddListener(() => { App.Services.Audio.Play("click"); player.avatarIndex = (player.avatarIndex + 1) % faces.Length; BuildBody(); });
            avatar.gameObject.AddComponent<PressableButton>();

            var name = UiFactory.CreateText(card.transform, enabled ? player.displayName : "غیرفعال", 27, ThemePalette.Cream);
            SetRect(name.rectTransform, new Vector2(.31f, .50f), new Vector2(.81f, .91f), Vector2.zero, Vector2.zero);
            if (enabled)
            {
                var nameButton = name.gameObject.AddComponent<Button>();
                nameButton.targetGraphic = name;
                nameButton.onClick.AddListener(() =>
                {
                    App.Services.Audio.Play("click");
                    string[] names = { "آریا", "سارا", "کیان", "نیلوفر", "پارسا", "هانا", "مهسا", "سام" };
                    int current = Array.IndexOf(names, player.displayName);
                    player.displayName = names[(current + 1 + names.Length) % names.Length];
                    BuildBody();
                });
            }

            string difficultyName = player.aiDifficulty == AiDifficulty.Easy ? "آسان" : player.aiDifficulty == AiDifficulty.Hard ? "سخت" : "متوسط";
            string typeText = player.playerKind == PlayerKind.Human ? (index == 0 ? "شما" : "بازیکن واقعی") : $"ربات • {difficultyName}";
            var type = UiFactory.CreateButton(card.transform, typeText, player.playerKind == PlayerKind.Human ? ProceduralSpriteFactory.GreenButton() : ProceduralSpriteFactory.PurpleButton(), () =>
            {
                if (!enabled || index == 0 || pending.gameMode != GameMode.VsBots) return;
                if (player.playerKind == PlayerKind.Human)
                {
                    player.playerKind = PlayerKind.Bot;
                    player.aiDifficulty = AiDifficulty.Easy;
                }
                else if (player.aiDifficulty == AiDifficulty.Easy) player.aiDifficulty = AiDifficulty.Medium;
                else if (player.aiDifficulty == AiDifficulty.Medium) player.aiDifficulty = AiDifficulty.Hard;
                else player.playerKind = PlayerKind.Human;
                BuildBody();
            }, App.Services.Audio, 18);
            SetRect(type.GetComponent<RectTransform>(), new Vector2(.36f, .10f), new Vector2(.91f, .48f), Vector2.zero, Vector2.zero);

            var colorDot = UiFactory.CreateImage(card.transform, "Color", ProceduralSpriteFactory.Circle(Color.Lerp(pieceColor, Color.white, .2f), pieceColor, ThemePalette.GoldLight));
            SetRect(colorDot.rectTransform, new Vector2(.82f, .66f), new Vector2(.96f, .94f), Vector2.zero, Vector2.zero);
            var colorButton = colorDot.gameObject.AddComponent<Button>();
            colorButton.targetGraphic = colorDot;
            colorButton.interactable = enabled;
            colorButton.onClick.AddListener(() => { App.Services.Audio.Play("click"); CyclePlayerColor(pending, index); BuildBody(); });
            colorDot.gameObject.AddComponent<PressableButton>();
        }



        private static string AdvancedRuleLabel(RuleConfigData rules)
        {
            if (rules.requiredEntryRoll == 6) return "ورود با ۶ • ۳۰ث";
            if (rules.allowBounceBack) return "حرکت برگشتی • ۳۰ث";
            if (rules.maxConsecutiveSixes == 0) return "۶ نامحدود • ۴۵ث";
            return "استاندارد • ۳۰ث";
        }

        private static void CycleAdvancedRules(RuleConfigData rules)
        {
            if (!rules.allowBounceBack && rules.requiredEntryRoll == 0 && rules.maxConsecutiveSixes == 3)
            {
                rules.requireExact100 = false;
                rules.allowBounceBack = true;
                rules.requiredEntryRoll = 0;
                rules.maxConsecutiveSixes = 3;
                rules.turnTimeSeconds = 30;
                rules.startAtZero = true;
                return;
            }
            if (rules.allowBounceBack)
            {
                rules.requireExact100 = true;
                rules.allowBounceBack = false;
                rules.requiredEntryRoll = 6;
                rules.maxConsecutiveSixes = 3;
                rules.turnTimeSeconds = 30;
                rules.startAtZero = true;
                return;
            }
            if (rules.requiredEntryRoll == 6)
            {
                rules.requireExact100 = true;
                rules.allowBounceBack = false;
                rules.requiredEntryRoll = 0;
                rules.maxConsecutiveSixes = 0;
                rules.turnTimeSeconds = 45;
                rules.startAtZero = false;
                return;
            }
            rules.requireExact100 = true;
            rules.allowBounceBack = false;
            rules.requiredEntryRoll = 0;
            rules.maxConsecutiveSixes = 3;
            rules.turnTimeSeconds = 30;
            rules.startAtZero = true;
        }

        private static void CyclePlayerColor(PendingMatchSettings pending, int playerIndex)
        {
            var player = pending.players[playerIndex];
            PieceColor oldColor = player.pieceColor;
            PieceColor nextColor = (PieceColor)(((int)oldColor + 1) % 4);
            for (int i = 0; i < pending.players.Count; i++)
            {
                if (i == playerIndex || pending.players[i].pieceColor != nextColor) continue;
                pending.players[i].pieceColor = oldColor;
                break;
            }
            player.pieceColor = nextColor;
        }

        private void CreateRuleToggle(Transform parent, string label, bool value, float y, Action<bool> changed)
        {
            var text = UiFactory.CreateText(parent, label, 22, ThemePalette.Cream, TextAnchor.MiddleRight);
            SetRect(text.rectTransform, new Vector2(.30f, y), new Vector2(.95f, y + .28f), Vector2.zero, Vector2.zero);
            var button = UiFactory.CreateButton(parent, value ? "روشن" : "خاموش", value ? ProceduralSpriteFactory.GreenButton() : ProceduralSpriteFactory.RedButton(), () => changed(!value), App.Services.Audio, 18);
            SetRect(button.GetComponent<RectTransform>(), new Vector2(.04f, y + .03f), new Vector2(.29f, y + .25f), Vector2.zero, Vector2.zero);
        }
    }

    public sealed class GameplayScreen : ScreenBase
    {
        private MatchController _match;
        private Button _rollButton;
        private Text _turnText;
        private Text _timerText;
        private readonly List<Text> _cellTexts = new List<Text>();
        private readonly List<Image> _playerCards = new List<Image>();

        protected override void Build()
        {
            Canvas = UiFactory.CreateCanvas("GameplayCanvas");
            Canvas.transform.SetParent(transform, false);
            SafeRoot = UiFactory.CreateSafeRoot(Canvas.transform);
            Content = new GameObject("GameplayHUD", typeof(RectTransform)).GetComponent<RectTransform>();
            Content.SetParent(SafeRoot, false); UiFactory.Stretch(Content);

            _match = gameObject.AddComponent<MatchController>();
            if (App.ResumeRequested && App.Services.Save.Data.unfinishedMatch != null)
                _match.InitializeFromSave(App.Services.Save.Data.unfinishedMatch, App.Services);
            else
                _match.InitializeNew(App.PendingMatch ?? DefaultContent.CreatePendingSettings(GameMode.VsBots, App.Services.Save.Data.profile), App.Services);
            App.ResumeRequested = false;

            var world = new GameObject("World", typeof(GameplayWorldView)).GetComponent<GameplayWorldView>();
            world.transform.SetParent(transform, false);
            world.Build(_match);

            BuildHud();
            Subscribe();
        }

        private void BuildHud()
        {
            var top = UiFactory.CreatePanel(Content, "PlayersTop", true);
            SetRect(top.rectTransform, new Vector2(.02f, .835f), new Vector2(.98f, .985f), Vector2.zero, Vector2.zero);
            for (int i = 0; i < _match.State.players.Count; i++)
            {
                float w = 1f / _match.State.players.Count;
                var p = _match.State.players[i];
                var card = UiFactory.CreatePanel(top.transform, "Player_" + i);
                SetRect(card.rectTransform, new Vector2(i * w + .005f, .08f), new Vector2((i + 1) * w - .005f, .92f), Vector2.zero, Vector2.zero);
                var avatar = UiFactory.CreateImage(card.transform, "Avatar", ProceduralSpriteFactory.Circle(Color.Lerp(ThemePalette.PieceColor((int)p.pieceColor), Color.white, .3f), ThemePalette.PurpleDark, ThemePalette.GoldLight));
                SetRect(avatar.rectTransform, new Vector2(.03f, .22f), new Vector2(.35f, .86f), Vector2.zero, Vector2.zero);
                var name = UiFactory.CreateText(card.transform, p.displayName, 21, ThemePalette.Cream);
                SetRect(name.rectTransform, new Vector2(.35f, .52f), new Vector2(.95f, .91f), Vector2.zero, Vector2.zero);
                var cell = UiFactory.CreateText(card.transform, "خانه ۰", 18, ThemePalette.GoldLight);
                SetRect(cell.rectTransform, new Vector2(.35f, .12f), new Vector2(.95f, .55f), Vector2.zero, Vector2.zero);
                _cellTexts.Add(cell); _playerCards.Add(card);
            }

            var turnPanel = UiFactory.CreatePanel(Content, "TurnBanner");
            SetRect(turnPanel.rectTransform, new Vector2(.25f, .775f), new Vector2(.75f, .83f), Vector2.zero, Vector2.zero);
            _turnText = UiFactory.CreateText(turnPanel.transform, "آماده شروع", 30, ThemePalette.GoldLight);
            SetRect(_turnText.rectTransform, new Vector2(.05f, .05f), new Vector2(.78f, .95f), Vector2.zero, Vector2.zero);
            _timerText = UiFactory.CreateText(turnPanel.transform, "۳۰", 27, ThemePalette.Cream);
            SetRect(_timerText.rectTransform, new Vector2(.78f, .05f), new Vector2(.96f, .95f), Vector2.zero, Vector2.zero);

            _rollButton = UiFactory.CreateButton(Content, "تاس بریز", ProceduralSpriteFactory.GreenButton(), () => _match.RequestRoll(), App.Services.Audio, 47, true);
            SetRect(_rollButton.GetComponent<RectTransform>(), new Vector2(.62f, .055f), new Vector2(.96f, .145f), Vector2.zero, Vector2.zero);

            var pause = UiFactory.CreateButton(Content, "توقف", ProceduralSpriteFactory.PurpleButton(), Pause, App.Services.Audio, 24);
            SetRect(pause.GetComponent<RectTransform>(), new Vector2(.035f, .055f), new Vector2(.205f, .13f), Vector2.zero, Vector2.zero);
            var surrender = UiFactory.CreateButton(Content, "تسلیم", ProceduralSpriteFactory.RedButton(), Surrender, App.Services.Audio, 24);
            SetRect(surrender.GetComponent<RectTransform>(), new Vector2(.215f, .055f), new Vector2(.385f, .13f), Vector2.zero, Vector2.zero);
            var emoji = UiFactory.CreateButton(Content, "ایموجی", ProceduralSpriteFactory.GoldButton(), () => App.ShowPopup("پیام آماده", "آفرین!  |  چه شانسی!  |  بازی عالی بود!", "بستن", null), App.Services.Audio, 23);
            SetRect(emoji.GetComponent<RectTransform>(), new Vector2(.395f, .055f), new Vector2(.565f, .13f), Vector2.zero, Vector2.zero);
            var rules = UiFactory.CreateButton(Content, "قوانین", ProceduralSpriteFactory.BlueButton(), () => App.ShowPopup("قوانین بازی", "با تاس حرکت کن؛ نردبان تو را بالا می‌برد، مار تو را پایین می‌آورد و برای برد باید دقیقاً به خانه ۱۰۰ برسی.", "باشه", null), App.Services.Audio, 23);
            SetRect(rules.GetComponent<RectTransform>(), new Vector2(.035f, .005f), new Vector2(.205f, .05f), Vector2.zero, Vector2.zero);
        }

        private void Subscribe()
        {
            _match.TurnStarted += OnTurnStarted;
            _match.PhaseChanged += OnPhaseChanged;
            _match.PieceStepped += OnPieceStepped;
            _match.SpecialMoveStarted += OnSpecialMove;
            _match.PieceResetByCollision += OnPieceReset;
            _match.Notice += OnNotice;
            _match.TurnTimerChanged += OnTimer;
            _match.MatchFinished += OnFinished;
        }

        private void OnDestroy()
        {
            if (_match == null) return;
            _match.TurnStarted -= OnTurnStarted;
            _match.PhaseChanged -= OnPhaseChanged;
            _match.PieceStepped -= OnPieceStepped;
            _match.SpecialMoveStarted -= OnSpecialMove;
            _match.PieceResetByCollision -= OnPieceReset;
            _match.Notice -= OnNotice;
            _match.TurnTimerChanged -= OnTimer;
            _match.MatchFinished -= OnFinished;
        }

        private void OnTurnStarted(PlayerMatchState player)
        {
            _turnText.text = PersianText.Fix(player.playerKind == PlayerKind.Human ? "نوبت شماست" : $"نوبت {player.displayName}");
            for (int i = 0; i < _playerCards.Count; i++) _playerCards[i].color = i == player.turnIndex ? new Color(1.22f, 1.12f, .8f, 1f) : Color.white;
        }

        private void OnPhaseChanged(TurnPhase phase)
        {
            if (_rollButton == null) return;
            bool human = _match.CurrentPlayer.playerKind == PlayerKind.Human;
            _rollButton.interactable = phase == TurnPhase.AwaitDiceInput && human;
        }

        private void OnPieceStepped(int index, int cell)
        {
            if (index >= 0 && index < _cellTexts.Count) _cellTexts[index].text = PersianText.Fix($"خانه {cell}");
        }

        private void OnSpecialMove(int index, int from, int to, bool ladder) => StartCoroutine(UpdateCellAfter(index, to, .82f));
        private void OnPieceReset(int index, int cell) { if (index >= 0 && index < _cellTexts.Count) _cellTexts[index].text = PersianText.Fix("خانه ۰"); }
        private IEnumerator UpdateCellAfter(int index, int cell, float delay) { yield return new WaitForSeconds(delay); OnPieceStepped(index, cell); }
        private void OnNotice(string message) { if (_turnText != null) _turnText.text = PersianText.Fix(message); }
        private void OnTimer(float seconds) { if (_timerText != null) _timerText.text = Mathf.CeilToInt(seconds).ToString(); }

        private void OnFinished(MatchResultData result)
        {
            App.LastResult = result;
            StartCoroutine(GoResult());
        }

        private IEnumerator GoResult() { yield return new WaitForSecondsRealtime(1.15f); App.Navigate(ScreenId.Result); }

        private void Pause()
        {
            if (_match.Phase != TurnPhase.AwaitDiceInput)
            {
                App.ShowPopup("کمی صبر کنید", "پس از پایان حرکت مهره می‌توانی بازی را متوقف کنی.", "باشه", null);
                return;
            }
            _match.Pause(true);
            App.ShowPopup("توقف بازی", "بازی متوقف شده است. ادامه می‌دهی یا به خانه برمی‌گردی؟", "ادامه", () => _match.Pause(false), "خروج", () => { Time.timeScale = 1; App.Navigate(ScreenId.Home); });
        }

        private void Surrender()
        {
            if (_match.Phase != TurnPhase.AwaitDiceInput)
            {
                App.ShowPopup("کمی صبر کنید", "تسلیم پس از پایان حرکت فعلی در دسترس است.", "باشه", null);
                return;
            }
            _match.Pause(true);
            App.ShowPopup("تسلیم؟", "با تسلیم، مسابقه نیمه‌تمام حذف می‌شود.", "بله", () => { App.Services.Save.ClearUnfinishedMatch(); Time.timeScale = 1; App.Navigate(ScreenId.Home); }, "خیر", () => _match.Pause(false));
        }
    }

    public sealed class ResultScreen : ScreenBase
    {
        protected override void Build()
        {
            CreateBase();
            gameObject.AddComponent<ConfettiEmitter>().parent = Canvas.transform as RectTransform;
            CreateLogo(Content, -70f, 570f);
            var title = UiFactory.CreatePanel(Content, "VictoryTitle");
            SetRect(title.rectTransform, new Vector2(.12f, .75f), new Vector2(.88f, .84f), Vector2.zero, Vector2.zero);
            var titleText = UiFactory.CreateText(title.transform, "پیروزی شکوهمند!", 55, ThemePalette.GoldLight);
            UiFactory.Stretch(titleText.rectTransform);
            var result = App.LastResult;
            if (result == null || result.ranking.Count == 0)
            {
                App.ShowPopup("نتیجه", "اطلاعات نتیجه در دسترس نیست.", "بازگشت", () => App.Navigate(ScreenId.Home));
                return;
            }

            var podium = UiFactory.CreatePanel(Content, "Podium", true);
            SetRect(podium.rectTransform, new Vector2(.05f, .35f), new Vector2(.95f, .74f), Vector2.zero, Vector2.zero);
            float[] heights = { .82f, .66f, .57f, .50f };
            float[] xs = { .39f, .09f, .61f, .80f };
            for (int i = 0; i < result.ranking.Count; i++)
            {
                var p = result.ranking[i];
                float width = i == 0 ? .22f : .18f;
                var slot = UiFactory.CreatePanel(podium.transform, "Rank_" + (i + 1));
                SetRect(slot.rectTransform, new Vector2(xs[i], .08f), new Vector2(Mathf.Min(.98f, xs[i] + width), heights[i]), Vector2.zero, Vector2.zero);
                var avatar = UiFactory.CreateImage(slot.transform, "Avatar", ProceduralSpriteFactory.Circle(Color.Lerp(ThemePalette.PieceColor((int)p.pieceColor), Color.white, .3f), ThemePalette.PurpleDark, i == 0 ? Color.white : ThemePalette.GoldLight));
                SetRect(avatar.rectTransform, new Vector2(.14f, .45f), new Vector2(.86f, .94f), Vector2.zero, Vector2.zero);
                var rank = UiFactory.CreateText(avatar.transform, (i + 1).ToString(), 40, ThemePalette.GoldLight);
                UiFactory.Stretch(rank.rectTransform);
                var name = UiFactory.CreateText(slot.transform, p.displayName, 27, ThemePalette.Cream);
                SetRect(name.rectTransform, new Vector2(.04f, .22f), new Vector2(.96f, .48f), Vector2.zero, Vector2.zero);
                var stats = UiFactory.CreateText(slot.transform, $"{p.diceRollCount} تاس", 20, ThemePalette.GoldLight);
                SetRect(stats.rectTransform, new Vector2(.04f, .04f), new Vector2(.96f, .24f), Vector2.zero, Vector2.zero);
            }

            var statsPanel = UiFactory.CreatePanel(Content, "ResultStats");
            SetRect(statsPanel.rectTransform, new Vector2(.075f, .20f), new Vector2(.925f, .34f), Vector2.zero, Vector2.zero);
            var winner = result.ranking[0];
            string statsText = $"مدت بازی: {result.durationSeconds / 60:00}:{result.durationSeconds % 60:00}     تعداد تاس: {winner.diceRollCount}\nنردبان‌ها: {winner.usedLaddersCount}     سقوط با مار: {winner.hitSnakesCount}\nجایزه: {result.rewardCoins} سکه + {result.rewardExperience} تجربه";
            var text = UiFactory.CreateText(statsPanel.transform, statsText, 26, ThemePalette.Cream);
            UiFactory.Stretch(text.rectTransform, new Vector2(35, 18), new Vector2(-35, -18));

            var replay = UiFactory.CreateButton(Content, "بازی مجدد", ProceduralSpriteFactory.GreenButton(), () => { App.ResumeRequested = false; App.Navigate(ScreenId.SnakesGameplay); }, App.Services.Audio, 39, true);
            SetRect(replay.GetComponent<RectTransform>(), new Vector2(.52f, .08f), new Vector2(.95f, .17f), Vector2.zero, Vector2.zero);
            var home = UiFactory.CreateButton(Content, "بازگشت به خانه", ProceduralSpriteFactory.BlueButton(), () => App.Navigate(ScreenId.Home), App.Services.Audio, 36);
            SetRect(home.GetComponent<RectTransform>(), new Vector2(.05f, .08f), new Vector2(.48f, .17f), Vector2.zero, Vector2.zero);
            var share = UiFactory.CreateButton(Content, "اشتراک‌گذاری نتیجه", ProceduralSpriteFactory.PurpleButton(), Share, App.Services.Audio, 28);
            SetRect(share.GetComponent<RectTransform>(), new Vector2(.25f, .015f), new Vector2(.75f, .07f), Vector2.zero, Vector2.zero);
        }

        private void Share()
        {
            var result = App.LastResult;
            string text = result == null ? "منچینو" : $"در منچینو، {result.ranking[0].displayName} برنده شد! زمان بازی: {result.durationSeconds / 60}:{result.durationSeconds % 60:00}";
            bool native = NativeShareService.ShareText("نتیجه منچینو", text);
            if (!native) App.ShowPopup("اشتراک‌گذاری", "متن نتیجه در کلیپ‌بورد کپی شد و آماده اشتراک‌گذاری است.", "باشه", null);
        }
    }

    public sealed class ConfettiEmitter : MonoBehaviour
    {
        public RectTransform parent;
        private IEnumerator Start()
        {
            yield return null;
            if (parent == null) yield break;
            Color[] colors = { ThemePalette.Gold, ThemePalette.Red, ThemePalette.Green, ThemePalette.Blue, ThemePalette.PurpleLight };
            for (int i = 0; i < 46; i++)
            {
                var piece = UiFactory.CreateImage(parent, "Confetti", ProceduralSpriteFactory.GoldButton(32, 32), colors[i % colors.Length]);
                piece.rectTransform.anchorMin = piece.rectTransform.anchorMax = new Vector2(UnityEngine.Random.value, 1.05f);
                piece.rectTransform.sizeDelta = new Vector2(UnityEngine.Random.Range(8, 19), UnityEngine.Random.Range(18, 35));
                piece.rectTransform.anchoredPosition = Vector2.zero;
                piece.gameObject.AddComponent<ConfettiFall>().speed = UnityEngine.Random.Range(170f, 380f);
            }
        }
    }

    public sealed class ConfettiFall : MonoBehaviour
    {
        public float speed;
        private float _spin;
        private void Start() { _spin = UnityEngine.Random.Range(-180f, 180f); }
        private void Update()
        {
            transform.Rotate(0, 0, _spin * Time.unscaledDeltaTime);
            transform.localPosition += Vector3.down * speed * Time.unscaledDeltaTime;
            if (transform.localPosition.y < -2100f) Destroy(gameObject);
        }
    }

    public sealed class DailyRewardScreen : ScreenBase
    {
        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "جایزه روزانه", () => App.Navigate(ScreenId.Home), App.Services.Audio);
            var chest = UiFactory.CreatePanel(Content, "DailyChest");
            SetRect(chest.rectTransform, new Vector2(.18f, .63f), new Vector2(.82f, .86f), Vector2.zero, Vector2.zero);
            var icon = UiFactory.CreateText(chest.transform, "▣", 125, ThemePalette.GoldLight);
            SetRect(icon.rectTransform, new Vector2(.25f, .25f), new Vector2(.75f, .92f), Vector2.zero, Vector2.zero);
            var text = UiFactory.CreateText(chest.transform, "هر روز بازی کن و جایزه بگیر!", 31, ThemePalette.Cream);
            SetRect(text.rectTransform, new Vector2(.05f, .03f), new Vector2(.95f, .29f), Vector2.zero, Vector2.zero);

            for (int i = 0; i < 7; i++)
            {
                int row = i < 4 ? 0 : 1;
                int col = row == 0 ? i : i - 4;
                float count = row == 0 ? 4f : 3f;
                float width = .85f / count;
                float start = row == 0 ? .075f : .17f;
                var node = UiFactory.CreatePanel(Content, "Day_" + i, true);
                float y0 = row == 0 ? .39f : .20f;
                SetRect(node.rectTransform, new Vector2(start + col * width, y0), new Vector2(start + (col + 1) * width - .012f, y0 + .16f), Vector2.zero, Vector2.zero);
                bool claimed = (App.Services.Save.Data.dailyReward.claimedMask & (1 << i)) != 0;
                bool current = i == App.Services.Save.Data.dailyReward.currentDayIndex;
                node.color = claimed ? new Color(.65f, 1f, .65f, 1f) : current ? new Color(1.2f, 1.05f, .65f, 1f) : new Color(.65f, .65f, .72f, .9f);
                var day = UiFactory.CreateText(node.transform, $"روز {i + 1}", 24, ThemePalette.GoldLight);
                SetRect(day.rectTransform, new Vector2(.04f, .65f), new Vector2(.96f, .94f), Vector2.zero, Vector2.zero);
                var reward = App.Services.DailyRewards.GetReward(i);
                var amount = UiFactory.CreateText(node.transform, i == 6 ? $"صندوق ویژه\n{reward.coins} سکه + {reward.gems} جم" : $"{reward.coins} سکه\n{reward.gems} جواهر", 20, ThemePalette.Cream);
                SetRect(amount.rectTransform, new Vector2(.04f, .10f), new Vector2(.96f, .66f), Vector2.zero, Vector2.zero);
                if (claimed)
                {
                    var check = UiFactory.CreateText(node.transform, "✓", 48, ThemePalette.Green);
                    SetRect(check.rectTransform, new Vector2(.65f, .56f), new Vector2(.96f, .95f), Vector2.zero, Vector2.zero);
                }
            }

            var stateText = App.Services.DailyRewards.IsClockRollbackDetected() ? "تغییر غیرعادی زمان دستگاه تشخیص داده شد" : App.Services.DailyRewards.CanClaim() ? "جایزه امروز آماده است" : "جایزه امروز قبلاً دریافت شده";
            var status = UiFactory.CreatePanel(Content, "Status", true);
            SetRect(status.rectTransform, new Vector2(.15f, .11f), new Vector2(.85f, .18f), Vector2.zero, Vector2.zero);
            var statusText = UiFactory.CreateText(status.transform, stateText, 25, ThemePalette.Cream);
            UiFactory.Stretch(statusText.rectTransform, new Vector2(20, 10), new Vector2(-20, -10));
            var claim = UiFactory.CreateButton(Content, "دریافت جایزه", App.Services.DailyRewards.CanClaim() ? ProceduralSpriteFactory.GreenButton() : ProceduralSpriteFactory.PurpleButton(), () =>
            {
                if (App.Services.DailyRewards.Claim()) { App.ShowPopup("جایزه دریافت شد", "سکه و جواهر به حساب شما افزوده شد.", "عالیه", () => App.Navigate(ScreenId.DailyReward)); }
                else App.ShowPopup("جایزه", "امکان دریافت دوباره جایزه امروز وجود ندارد.", "باشه", null);
            }, App.Services.Audio, 44, App.Services.DailyRewards.CanClaim());
            SetRect(claim.GetComponent<RectTransform>(), new Vector2(.20f, .025f), new Vector2(.80f, .10f), Vector2.zero, Vector2.zero);
        }
    }

    public sealed class MissionsScreen : ScreenBase
    {
        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "مأموریت‌های امروز", () => App.Navigate(ScreenId.Home), App.Services.Audio);
            var list = new GameObject("MissionList", typeof(RectTransform), typeof(VerticalLayoutGroup)).GetComponent<RectTransform>();
            list.SetParent(Content, false);
            SetRect(list, new Vector2(.055f, .10f), new Vector2(.945f, .85f), Vector2.zero, Vector2.zero);
            var layout = list.GetComponent<VerticalLayoutGroup>();
            layout.spacing = 22; layout.padding = new RectOffset(0, 0, 10, 10); layout.childControlHeight = false; layout.childForceExpandHeight = false;
            foreach (var mission in App.Services.Missions.Items) CreateMission(list, mission);
        }

        private void CreateMission(Transform parent, MissionStateData mission)
        {
            var panel = UiFactory.CreatePanel(parent, "Mission_" + mission.missionId);
            panel.rectTransform.sizeDelta = new Vector2(0, 265);
            var icon = UiFactory.CreateImage(panel.transform, "Icon", ProceduralSpriteFactory.Circle(ThemePalette.GoldLight, ThemePalette.PurpleDark, Color.white));
            SetRect(icon.rectTransform, new Vector2(.03f, .28f), new Vector2(.20f, .82f), Vector2.zero, Vector2.zero);
            var symbol = UiFactory.CreateText(icon.transform, mission.type == MissionType.RollSixes ? "⚄" : mission.type == MissionType.UseLadders ? "⇧" : "★", 44, ThemePalette.Cream);
            UiFactory.Stretch(symbol.rectTransform);
            var title = UiFactory.CreateText(panel.transform, mission.title, 31, ThemePalette.GoldLight, TextAnchor.MiddleRight);
            SetRect(title.rectTransform, new Vector2(.22f, .63f), new Vector2(.95f, .91f), Vector2.zero, Vector2.zero);
            var desc = UiFactory.CreateText(panel.transform, mission.description, 21, ThemePalette.Cream, TextAnchor.MiddleRight, FontStyle.Normal);
            SetRect(desc.rectTransform, new Vector2(.22f, .44f), new Vector2(.95f, .65f), Vector2.zero, Vector2.zero);
            var barBg = UiFactory.CreateImage(panel.transform, "ProgressBg", ProceduralSpriteFactory.DarkPanel());
            SetRect(barBg.rectTransform, new Vector2(.22f, .25f), new Vector2(.73f, .40f), Vector2.zero, Vector2.zero);
            var fill = UiFactory.CreateImage(barBg.transform, "Fill", ProceduralSpriteFactory.GreenButton());
            fill.rectTransform.anchorMin = new Vector2(0, 0); fill.rectTransform.anchorMax = new Vector2(Mathf.Clamp01(mission.progress / (float)Mathf.Max(1, mission.target)), 1);
            fill.rectTransform.offsetMin = fill.rectTransform.offsetMax = Vector2.zero;
            var progress = UiFactory.CreateText(barBg.transform, $"{mission.progress} / {mission.target}", 20, ThemePalette.Cream);
            UiFactory.Stretch(progress.rectTransform);
            var reward = UiFactory.CreateText(panel.transform, $"{mission.rewardCoins} سکه + {mission.rewardGems} جم", 21, ThemePalette.GoldLight);
            SetRect(reward.rectTransform, new Vector2(.22f, .05f), new Vector2(.73f, .23f), Vector2.zero, Vector2.zero);
            bool complete = mission.progress >= mission.target;
            var button = UiFactory.CreateButton(panel.transform, mission.claimed ? "دریافت شد" : complete ? "دریافت" : "در حال انجام", mission.claimed ? ProceduralSpriteFactory.PurpleButton() : complete ? ProceduralSpriteFactory.GreenButton() : ProceduralSpriteFactory.BlueButton(), () =>
            {
                if (App.Services.Missions.Claim(mission.missionId)) { App.ShowPopup("مأموریت کامل", "جایزه مأموریت به کیف پول افزوده شد.", "عالیه", () => App.Navigate(ScreenId.Missions)); }
            }, App.Services.Audio, 21);
            SetRect(button.GetComponent<RectTransform>(), new Vector2(.75f, .12f), new Vector2(.96f, .42f), Vector2.zero, Vector2.zero);
            button.interactable = complete && !mission.claimed;
        }
    }

    public sealed class ShopScreen : ScreenBase
    {
        private readonly struct Product
        {
            public readonly string id, title, description, type;
            public readonly int coins, gems;
            public Product(string id, string title, string description, string type, int coins, int gems) { this.id = id; this.title = title; this.description = description; this.type = type; this.coins = coins; this.gems = gems; }
        }

        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "فروشگاه", () => App.Navigate(ScreenId.Home), App.Services.Audio);
            var profile = App.Services.Save.Data.profile;
            var coin = UiFactory.CreateCurrencyBar(Content, false, profile.coins, StorePaymentInfo, App.Services.Audio);
            SetRect(coin, new Vector2(.05f, .79f), new Vector2(.36f, .84f), Vector2.zero, Vector2.zero);
            var gem = UiFactory.CreateCurrencyBar(Content, true, profile.gems, StorePaymentInfo, App.Services.Audio);
            SetRect(gem, new Vector2(.64f, .79f), new Vector2(.95f, .84f), Vector2.zero, Vector2.zero);

            Product[] products =
            {
                new Product("night","تم شب جادویی","پس‌زمینه عمیق و نور آبی","theme",800,0),
                new Product("gold_piece","مهره طلایی","پوسته براق سلطنتی","piece",1200,0),
                new Product("crystal_dice","تاس کریستالی","درخشش ویژه هنگام پرتاب","dice",0,12),
                new Product("avatar_royal","آواتار قهرمان","قاب و چهره اختصاصی","avatar",600,0),
                new Product("royal_frame","قاب پروفایل سلطنتی","لبه طلایی متحرک","frame",900,0),
                new Product("trail_star","افکت حرکت ستاره‌ای","رد نور هنگام حرکت مهره","effect",0,15)
            };

            for (int i = 0; i < products.Length; i++)
            {
                int col = i % 2; int row = i / 2;
                Vector2 min = new Vector2(.055f + col * .47f, .56f - row * .20f);
                Vector2 max = new Vector2(.475f + col * .47f, .75f - row * .20f);
                CreateProduct(products[i], min, max);
            }

            var special = UiFactory.CreatePanel(Content, "SpecialBundle");
            SetRect(special.rectTransform, new Vector2(.055f, .02f), new Vector2(.945f, .14f), Vector2.zero, Vector2.zero);
            var specialTitle = UiFactory.CreateText(special.transform, "بسته شاهانه: ۲۵۰٬۰۰۰ سکه + ۲٬۰۰۰ جواهر + ۵ تاس ویژه", 28, ThemePalette.GoldLight);
            SetRect(specialTitle.rectTransform, new Vector2(.05f, .48f), new Vector2(.95f, .92f), Vector2.zero, Vector2.zero);
            var specialButton = UiFactory.CreateButton(special.transform, "اتصال پرداخت فروشگاهی", ProceduralSpriteFactory.GreenButton(), StorePaymentInfo, App.Services.Audio, 25);
            SetRect(specialButton.GetComponent<RectTransform>(), new Vector2(.30f, .06f), new Vector2(.70f, .47f), Vector2.zero, Vector2.zero);
        }

        private void CreateProduct(Product product, Vector2 min, Vector2 max)
        {
            var card = UiFactory.CreatePanel(Content, "Product_" + product.id);
            SetRect(card.rectTransform, min, max, Vector2.zero, Vector2.zero);
            var visual = UiFactory.CreateImage(card.transform, "Visual", product.type == "dice" ? ProceduralSpriteFactory.Circle(ThemePalette.Cream, new Color(.65f,.72f,.85f), ThemePalette.GoldLight) : ProceduralSpriteFactory.Diamond(ThemePalette.PurpleLight, ThemePalette.PurpleDark, ThemePalette.GoldLight));
            SetRect(visual.rectTransform, new Vector2(.05f, .32f), new Vector2(.34f, .88f), Vector2.zero, Vector2.zero);
            var symbol = UiFactory.CreateText(visual.transform, product.type == "theme" ? "♜" : product.type == "piece" ? "♟" : product.type == "dice" ? "⚄" : "★", 44, ThemePalette.Cream);
            UiFactory.Stretch(symbol.rectTransform);
            var title = UiFactory.CreateText(card.transform, product.title, 27, ThemePalette.GoldLight);
            SetRect(title.rectTransform, new Vector2(.34f, .62f), new Vector2(.96f, .91f), Vector2.zero, Vector2.zero);
            var desc = UiFactory.CreateText(card.transform, product.description, 18, ThemePalette.Cream, TextAnchor.MiddleCenter, FontStyle.Normal);
            SetRect(desc.rectTransform, new Vector2(.34f, .38f), new Vector2(.96f, .64f), Vector2.zero, Vector2.zero);
            string price = product.coins > 0 ? $"{product.coins} سکه" : $"{product.gems} جواهر";
            var buy = UiFactory.CreateButton(card.transform, price, ProceduralSpriteFactory.GreenButton(), () => Buy(product), App.Services.Audio, 21);
            SetRect(buy.GetComponent<RectTransform>(), new Vector2(.36f, .08f), new Vector2(.94f, .36f), Vector2.zero, Vector2.zero);
        }

        private void Buy(Product p)
        {
            bool paid = p.coins > 0 ? App.Services.Wallet.SpendCoins(p.coins) : App.Services.Wallet.SpendGems(p.gems);
            if (!paid)
            {
                App.ShowPopup("موجودی ناکافی", "برای خرید این محصول سکه یا جواهر کافی نداری.", "فهمیدم", null);
                return;
            }
            var inv = App.Services.Save.Data.inventory;
            if (p.type == "theme" && !inv.ownedThemes.Contains(p.id)) inv.ownedThemes.Add(p.id);
            if (p.type == "piece" && !inv.ownedPieces.Contains(p.id)) inv.ownedPieces.Add(p.id);
            if (p.type == "dice" && !inv.ownedDice.Contains(p.id)) inv.ownedDice.Add(p.id);
            if (p.type == "avatar" && !inv.ownedAvatars.Contains(p.id)) inv.ownedAvatars.Add(p.id);
            if (p.type == "frame" && !inv.ownedFrames.Contains(p.id)) inv.ownedFrames.Add(p.id);
            if (p.type == "effect" && !inv.ownedEffects.Contains(p.id)) inv.ownedEffects.Add(p.id);
            App.Services.Save.Save();
            App.ShowPopup("خرید موفق", "محصول با موفقیت به مجموعه شما اضافه شد.", "باشه", () => App.Navigate(ScreenId.Shop));
        }

        private void StorePaymentInfo() => App.ShowPopup("پرداخت فروشگاهی", "ساختار خرید آماده اتصال به کافه‌بازار، مایکت یا گوگل‌پلی است. در این سورس پرداخت واقعی عمداً غیرفعال مانده است.", "باشه", null);
    }

    public sealed class ProfileScreen : ScreenBase
    {
        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "پروفایل", () => App.Navigate(ScreenId.Home), App.Services.Audio);
            var p = App.Services.Save.Data.profile;
            var hero = UiFactory.CreatePanel(Content, "ProfileHero");
            SetRect(hero.rectTransform, new Vector2(.055f, .61f), new Vector2(.945f, .84f), Vector2.zero, Vector2.zero);
            var avatar = UiFactory.CreateImage(hero.transform, "Avatar", ProceduralSpriteFactory.Circle(ThemePalette.GoldLight, ThemePalette.PurpleDark, Color.white));
            SetRect(avatar.rectTransform, new Vector2(.34f, .30f), new Vector2(.66f, .93f), Vector2.zero, Vector2.zero);
            var face = UiFactory.CreateText(avatar.transform, "●‿●", 48, ThemePalette.Cream); UiFactory.Stretch(face.rectTransform);
            var level = UiFactory.CreateText(avatar.transform, p.level.ToString(), 27, ThemePalette.GoldLight);
            SetRect(level.rectTransform, new Vector2(.37f, -.12f), new Vector2(.63f, .13f), Vector2.zero, Vector2.zero);
            var name = UiFactory.CreateText(hero.transform, p.displayName, 43, ThemePalette.GoldLight);
            SetRect(name.rectTransform, new Vector2(.15f, .05f), new Vector2(.85f, .32f), Vector2.zero, Vector2.zero);
            var edit = UiFactory.CreateButton(hero.transform, "ویرایش نام", ProceduralSpriteFactory.BlueButton(), EditName, App.Services.Audio, 20);
            SetRect(edit.GetComponent<RectTransform>(), new Vector2(.72f, .08f), new Vector2(.95f, .28f), Vector2.zero, Vector2.zero);

            var stats = UiFactory.CreatePanel(Content, "Stats", true);
            SetRect(stats.rectTransform, new Vector2(.055f, .46f), new Vector2(.945f, .60f), Vector2.zero, Vector2.zero);
            string[] labels = { "تعداد بازی", "برد", "زمان بازی", "تاس‌ها", "نردبان", "سقوط مار" };
            string[] values = { p.totalGames.ToString(), p.totalWins.ToString(), $"{p.totalPlaySeconds / 3600} ساعت", p.totalDiceRolls.ToString(), p.totalLadders.ToString(), p.totalSnakes.ToString() };
            for (int i = 0; i < labels.Length; i++)
            {
                float x0 = (i % 3) / 3f; float y0 = i < 3 ? .52f : .04f;
                var tile = UiFactory.CreatePanel(stats.transform, "Stat");
                SetRect(tile.rectTransform, new Vector2(x0 + .015f, y0), new Vector2(x0 + .318f, y0 + .43f), Vector2.zero, Vector2.zero);
                var val = UiFactory.CreateText(tile.transform, values[i], 27, ThemePalette.GoldLight); SetRect(val.rectTransform, new Vector2(.05f, .45f), new Vector2(.95f, .93f), Vector2.zero, Vector2.zero);
                var lab = UiFactory.CreateText(tile.transform, labels[i], 19, ThemePalette.Cream); SetRect(lab.rectTransform, new Vector2(.05f, .05f), new Vector2(.95f, .48f), Vector2.zero, Vector2.zero);
            }

            var achievements = UiFactory.CreatePanel(Content, "Achievements");
            SetRect(achievements.rectTransform, new Vector2(.055f, .30f), new Vector2(.945f, .45f), Vector2.zero, Vector2.zero);
            string[] badges = { "سلطان برد", "قهرمان جام", "استاد تاس", "استاد مار و پله", "دوست‌داشتنی" };
            for (int i = 0; i < badges.Length; i++)
            {
                var badge = UiFactory.CreateImage(achievements.transform, "Badge", ProceduralSpriteFactory.Diamond(Color.Lerp(ThemePalette.PieceColor(i % 4), Color.white, .22f), ThemePalette.PurpleDark, ThemePalette.GoldLight));
                float w = .19f;
                SetRect(badge.rectTransform, new Vector2(.025f + i * w, .29f), new Vector2(.17f + i * w, .91f), Vector2.zero, Vector2.zero);
                var star = UiFactory.CreateText(badge.transform, "★", 34, ThemePalette.GoldLight); UiFactory.Stretch(star.rectTransform);
                var label = UiFactory.CreateText(achievements.transform, badges[i], 16, ThemePalette.Cream);
                SetRect(label.rectTransform, new Vector2(.005f + i * w, .04f), new Vector2(.19f + i * w, .30f), Vector2.zero, Vector2.zero);
            }

            var friends = UiFactory.CreatePanel(Content, "Friends", true);
            SetRect(friends.rectTransform, new Vector2(.055f, .08f), new Vector2(.945f, .29f), Vector2.zero, Vector2.zero);
            var friendsTitle = UiFactory.CreateText(friends.transform, "دوستان نزدیک", 29, ThemePalette.GoldLight); SetRect(friendsTitle.rectTransform, new Vector2(.05f, .72f), new Vector2(.95f, .96f), Vector2.zero, Vector2.zero);
            for (int i = 0; i < 4; i++)
            {
                int index = i;
                var friend = UiFactory.CreatePanel(friends.transform, "Friend");
                float x = .025f + i * .235f;
                SetRect(friend.rectTransform, new Vector2(x, .08f), new Vector2(x + .215f, .70f), Vector2.zero, Vector2.zero);
                var av = UiFactory.CreateImage(friend.transform, "Avatar", ProceduralSpriteFactory.Circle(Color.Lerp(ThemePalette.PieceColor(i), Color.white, .3f), ThemePalette.PurpleDark, ThemePalette.GoldLight));
                SetRect(av.rectTransform, new Vector2(.25f, .43f), new Vector2(.75f, .93f), Vector2.zero, Vector2.zero);
                var fname = UiFactory.CreateText(friend.transform, DefaultContent.PersianPlayerNames[i], 18, ThemePalette.Cream); SetRect(fname.rectTransform, new Vector2(.05f, .22f), new Vector2(.95f, .45f), Vector2.zero, Vector2.zero);
                var gift = UiFactory.CreateButton(friend.transform, "هدیه ۵۰ سکه", ProceduralSpriteFactory.GreenButton(), () => SendGift(index), App.Services.Audio, 14);
                SetRect(gift.GetComponent<RectTransform>(), new Vector2(.08f, .02f), new Vector2(.92f, .23f), Vector2.zero, Vector2.zero);
            }

            var history = UiFactory.CreateButton(Content, "تاریخچه بازی و افتخارات", ProceduralSpriteFactory.PurpleButton(), () => App.ShowPopup("تاریخچه", App.LastResult == null ? "هنوز نتیجه‌ای در این نشست ثبت نشده است." : $"آخرین برنده: {App.LastResult.ranking[0].displayName}", "باشه", null), App.Services.Audio, 27);
            SetRect(history.GetComponent<RectTransform>(), new Vector2(.20f, .015f), new Vector2(.80f, .07f), Vector2.zero, Vector2.zero);
        }

        private void EditName()
        {
            var profile = App.Services.Save.Data.profile;
            string[] names = { "آریا", "کیان", "پارسا", "هانا", "سارا", "نیلوفر" };
            int index = Array.IndexOf(names, profile.displayName);
            profile.displayName = names[(index + 1 + names.Length) % names.Length];
            App.Services.Save.Save();
            App.ShowPopup("ویرایش پروفایل", $"نام جدید: {profile.displayName}", "تأیید", () => App.Navigate(ScreenId.Profile));
        }

        private void SendGift(int friendIndex)
        {
            if (!App.Services.Wallet.SpendCoins(50)) { App.ShowPopup("کمبود سکه", "برای ارسال هدیه ۵۰ سکه لازم است.", "باشه", null); return; }
            App.ShowPopup("هدیه ارسال شد", $"هدیه برای {DefaultContent.PersianPlayerNames[friendIndex]} ارسال شد.", "عالیه", () => App.Navigate(ScreenId.Profile));
        }
    }

    public sealed class SettingsScreen : ScreenBase
    {
        protected override void Build()
        {
            CreateBase();
            UiFactory.CreateHeader(Content, "تنظیمات", () => App.Navigate(ScreenId.Home), App.Services.Audio);
            var panel = UiFactory.CreatePanel(Content, "SettingsPanel");
            SetRect(panel.rectTransform, new Vector2(.08f, .25f), new Vector2(.92f, .82f), Vector2.zero, Vector2.zero);
            var settings = App.Services.Save.Data.settings;
            CreateToggle(panel.transform, "موسیقی", settings.music, .76f, v => { settings.music = v; SaveAndRefresh(); });
            CreateToggle(panel.transform, "جلوه‌های صوتی", settings.soundEffects, .58f, v => { settings.soundEffects = v; SaveAndRefresh(); });
            CreateToggle(panel.transform, "لرزش", settings.vibration, .40f, v => { settings.vibration = v; SaveAndRefresh(); });
            CreateToggle(panel.transform, "اعلان‌ها", settings.notifications, .22f, v => { settings.notifications = v; SaveAndRefresh(); });
            var qualityTitle = UiFactory.CreateText(panel.transform, "کیفیت گرافیک", 28, ThemePalette.GoldLight, TextAnchor.MiddleRight);
            SetRect(qualityTitle.rectTransform, new Vector2(.49f, .04f), new Vector2(.94f, .20f), Vector2.zero, Vector2.zero);
            string[] q = { "کم", "متوسط", "زیاد" };
            for (int i = 0; i < 3; i++)
            {
                int index = i;
                var b = UiFactory.CreateButton(panel.transform, q[i], settings.qualityLevel == i ? ProceduralSpriteFactory.GoldButton() : ProceduralSpriteFactory.PurpleButton(), () => { settings.qualityLevel = index; QualitySettings.SetQualityLevel(index, true); SaveAndRefresh(); }, App.Services.Audio, 21);
                float x = .05f + i * .145f;
                SetRect(b.GetComponent<RectTransform>(), new Vector2(x, .05f), new Vector2(x + .13f, .19f), Vector2.zero, Vector2.zero);
            }
            var info = UiFactory.CreatePanel(Content, "Info", true);
            SetRect(info.rectTransform, new Vector2(.16f, .10f), new Vector2(.84f, .21f), Vector2.zero, Vector2.zero);
            var text = UiFactory.CreateText(info.transform, "منچینو  نسخه ۰٫۱٫۰\nیونیتی ۲۰۲۲ • عمودی • آفلاین", 24, ThemePalette.Cream);
            UiFactory.Stretch(text.rectTransform, new Vector2(20, 10), new Vector2(-20, -10));
        }

        private void CreateToggle(Transform parent, string label, bool value, float y, Action<bool> changed)
        {
            var text = UiFactory.CreateText(parent, label, 31, ThemePalette.Cream, TextAnchor.MiddleRight);
            SetRect(text.rectTransform, new Vector2(.35f, y), new Vector2(.93f, y + .15f), Vector2.zero, Vector2.zero);
            var button = UiFactory.CreateButton(parent, value ? "روشن" : "خاموش", value ? ProceduralSpriteFactory.GreenButton() : ProceduralSpriteFactory.RedButton(), () => changed(!value), App.Services.Audio, 24);
            SetRect(button.GetComponent<RectTransform>(), new Vector2(.07f, y + .01f), new Vector2(.32f, y + .14f), Vector2.zero, Vector2.zero);
        }

        private void SaveAndRefresh()
        {
            App.Services.Save.Save();
            App.Services.Audio.ApplySettings();
            App.Navigate(ScreenId.Settings);
        }
    }
}
