using System.Collections.Generic;
using System.Text;

namespace Menchino.Presentation
{
    public static class PersianText
    {
        private readonly struct Forms
        {
            public readonly char Isolated, Final, Initial, Medial;
            public readonly bool JoinPrev, JoinNext;
            public Forms(char isolated, char final, char initial, char medial, bool joinPrev = true, bool joinNext = true)
            {
                Isolated = isolated; Final = final; Initial = initial; Medial = medial;
                JoinPrev = joinPrev; JoinNext = joinNext;
            }
        }

        private static readonly Dictionary<char, Forms> Map = new Dictionary<char, Forms>
        {
            ['ا']=new Forms('\uFE8D','\uFE8E','\uFE8D','\uFE8E',true,false),
            ['آ']=new Forms('\uFE81','\uFE82','\uFE81','\uFE82',true,false),
            ['أ']=new Forms('\uFE83','\uFE84','\uFE83','\uFE84',true,false),
            ['إ']=new Forms('\uFE87','\uFE88','\uFE87','\uFE88',true,false),
            ['ب']=new Forms('\uFE8F','\uFE90','\uFE91','\uFE92'),
            ['پ']=new Forms('\uFB56','\uFB57','\uFB58','\uFB59'),
            ['ت']=new Forms('\uFE95','\uFE96','\uFE97','\uFE98'),
            ['ث']=new Forms('\uFE99','\uFE9A','\uFE9B','\uFE9C'),
            ['ج']=new Forms('\uFE9D','\uFE9E','\uFE9F','\uFEA0'),
            ['چ']=new Forms('\uFB7A','\uFB7B','\uFB7C','\uFB7D'),
            ['ح']=new Forms('\uFEA1','\uFEA2','\uFEA3','\uFEA4'),
            ['خ']=new Forms('\uFEA5','\uFEA6','\uFEA7','\uFEA8'),
            ['د']=new Forms('\uFEA9','\uFEAA','\uFEA9','\uFEAA',true,false),
            ['ذ']=new Forms('\uFEAB','\uFEAC','\uFEAB','\uFEAC',true,false),
            ['ر']=new Forms('\uFEAD','\uFEAE','\uFEAD','\uFEAE',true,false),
            ['ز']=new Forms('\uFEAF','\uFEB0','\uFEAF','\uFEB0',true,false),
            ['ژ']=new Forms('\uFB8A','\uFB8B','\uFB8A','\uFB8B',true,false),
            ['س']=new Forms('\uFEB1','\uFEB2','\uFEB3','\uFEB4'),
            ['ش']=new Forms('\uFEB5','\uFEB6','\uFEB7','\uFEB8'),
            ['ص']=new Forms('\uFEB9','\uFEBA','\uFEBB','\uFEBC'),
            ['ض']=new Forms('\uFEBD','\uFEBE','\uFEBF','\uFEC0'),
            ['ط']=new Forms('\uFEC1','\uFEC2','\uFEC3','\uFEC4'),
            ['ظ']=new Forms('\uFEC5','\uFEC6','\uFEC7','\uFEC8'),
            ['ع']=new Forms('\uFEC9','\uFECA','\uFECB','\uFECC'),
            ['غ']=new Forms('\uFECD','\uFECE','\uFECF','\uFED0'),
            ['ف']=new Forms('\uFED1','\uFED2','\uFED3','\uFED4'),
            ['ق']=new Forms('\uFED5','\uFED6','\uFED7','\uFED8'),
            ['ک']=new Forms('\uFB8E','\uFB8F','\uFB90','\uFB91'),
            ['ك']=new Forms('\uFED9','\uFEDA','\uFEDB','\uFEDC'),
            ['گ']=new Forms('\uFB92','\uFB93','\uFB94','\uFB95'),
            ['ل']=new Forms('\uFEDD','\uFEDE','\uFEDF','\uFEE0'),
            ['م']=new Forms('\uFEE1','\uFEE2','\uFEE3','\uFEE4'),
            ['ن']=new Forms('\uFEE5','\uFEE6','\uFEE7','\uFEE8'),
            ['و']=new Forms('\uFEED','\uFEEE','\uFEED','\uFEEE',true,false),
            ['ؤ']=new Forms('\uFE85','\uFE86','\uFE85','\uFE86',true,false),
            ['ه']=new Forms('\uFEE9','\uFEEA','\uFEEB','\uFEEC'),
            ['ة']=new Forms('\uFE93','\uFE94','\uFE93','\uFE94',true,false),
            ['ی']=new Forms('\uFBFC','\uFBFD','\uFBFE','\uFBFF'),
            ['ي']=new Forms('\uFEF1','\uFEF2','\uFEF3','\uFEF4'),
            ['ئ']=new Forms('\uFE89','\uFE8A','\uFE8B','\uFE8C')
        };

        public static string Fix(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;
            string[] lines = input.Replace("\r", string.Empty).Split('\n');
            for (int i = 0; i < lines.Length; i++) lines[i] = FixLine(lines[i]);
            return string.Join("\n", lines);
        }

        private static string FixLine(string input)
        {
            var chars = input.ToCharArray();
            var shaped = new char[chars.Length];
            for (int i = 0; i < chars.Length; i++)
            {
                char c = chars[i];
                if (!Map.TryGetValue(c, out var f)) { shaped[i] = c; continue; }
                bool prev = FindPreviousJoin(chars, i, f);
                bool next = FindNextJoin(chars, i, f);
                shaped[i] = prev && next ? f.Medial : prev ? f.Final : next ? f.Initial : f.Isolated;
            }

            var reversed = new StringBuilder(shaped.Length);
            for (int i = shaped.Length - 1; i >= 0; i--) reversed.Append(shaped[i]);
            return RestoreLTRRuns(reversed.ToString());
        }

        private static bool FindPreviousJoin(char[] chars, int index, Forms current)
        {
            if (!current.JoinPrev) return false;
            int i = index - 1;
            while (i >= 0 && IsTransparent(chars[i])) i--;
            return i >= 0 && Map.TryGetValue(chars[i], out var prev) && prev.JoinNext;
        }

        private static bool FindNextJoin(char[] chars, int index, Forms current)
        {
            if (!current.JoinNext) return false;
            int i = index + 1;
            while (i < chars.Length && IsTransparent(chars[i])) i++;
            return i < chars.Length && Map.TryGetValue(chars[i], out var next) && next.JoinPrev;
        }

        private static bool IsTransparent(char c) => c >= '\u064B' && c <= '\u065F';

        private static string RestoreLTRRuns(string text)
        {
            var chars = text.ToCharArray();
            int i = 0;
            while (i < chars.Length)
            {
                if (!IsLtr(chars[i])) { i++; continue; }
                int start = i;
                while (i < chars.Length && IsLtr(chars[i])) i++;
                System.Array.Reverse(chars, start, i - start);
            }
            return new string(chars);
        }

        private static bool IsLtr(char c)
        {
            return (c >= '0' && c <= '9') || (c >= '\u06F0' && c <= '\u06F9') ||
                   (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '/' || c == ':' || c == '+' || c == '-';
        }
    }
}
