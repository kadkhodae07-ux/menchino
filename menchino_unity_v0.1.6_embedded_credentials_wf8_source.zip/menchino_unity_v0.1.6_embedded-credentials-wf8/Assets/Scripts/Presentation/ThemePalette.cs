using UnityEngine;

namespace Menchino.Presentation
{
    public static class ThemePalette
    {
        public static readonly Color PurpleDark = Hex("1B0837");
        public static readonly Color Purple = Hex("4B1679");
        public static readonly Color PurpleLight = Hex("7C31A8");
        public static readonly Color GoldDark = Hex("8D4E00");
        public static readonly Color Gold = Hex("FFB51D");
        public static readonly Color GoldLight = Hex("FFE081");
        public static readonly Color GreenDark = Hex("11680F");
        public static readonly Color Green = Hex("2DBA25");
        public static readonly Color RedDark = Hex("8A1111");
        public static readonly Color Red = Hex("E13227");
        public static readonly Color BlueDark = Hex("075497");
        public static readonly Color Blue = Hex("1A9DEB");
        public static readonly Color Cream = Hex("FFF3CF");
        public static readonly Color Ink = Hex("24142D");
        public static readonly Color SkyTop = Hex("0F79D6");
        public static readonly Color SkyBottom = Hex("0B153C");

        public static Color PieceColor(int index)
        {
            switch (index)
            {
                case 0: return Red;
                case 1: return Blue;
                case 2: return Green;
                default: return Gold;
            }
        }

        private static Color Hex(string hex)
        {
            ColorUtility.TryParseHtmlString("#" + hex, out var color);
            return color;
        }
    }
}
