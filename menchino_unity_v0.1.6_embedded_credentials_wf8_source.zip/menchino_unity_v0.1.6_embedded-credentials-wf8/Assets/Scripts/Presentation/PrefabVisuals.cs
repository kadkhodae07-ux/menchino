using Menchino.Data;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.Presentation
{
    [RequireComponent(typeof(RectTransform), typeof(CanvasRenderer), typeof(Image))]
    public sealed class RoyalPanelPrefabVisual : MonoBehaviour
    {
        public bool dark;
        private void Awake()
        {
            var image = GetComponent<Image>();
            image.sprite = dark ? ProceduralSpriteFactory.DarkPanel() : ProceduralSpriteFactory.RoyalPanel();
            image.type = Image.Type.Sliced;
        }
    }

    [RequireComponent(typeof(RectTransform), typeof(CanvasRenderer), typeof(Image))]
    [RequireComponent(typeof(Button), typeof(PressableButton))]
    public sealed class RoyalButtonPrefabVisual : MonoBehaviour
    {
        public string label = "دکمه";
        public int fontSize = 34;
        public bool primary;

        private void Awake()
        {
            var image = GetComponent<Image>();
            image.sprite = primary ? ProceduralSpriteFactory.GoldButton() : ProceduralSpriteFactory.PurpleButton();
            image.type = Image.Type.Sliced;
            var button = GetComponent<Button>();
            button.targetGraphic = image;
            if (transform.Find("Text") == null)
            {
                var text = UiFactory.CreateText(transform, label, fontSize, ThemePalette.Cream);
                text.gameObject.name = "Text";
                UiFactory.Stretch(text.rectTransform, new Vector2(24, 10), new Vector2(-24, -10));
            }
        }
    }

    public sealed class PawnPrefabVisual : MonoBehaviour
    {
        public PieceColor color = PieceColor.Red;
        private void Awake()
        {
            if (transform.childCount == 0) WorldFactory.CreatePawn(transform, color, 0);
        }
    }

    public sealed class DicePrefabVisual : MonoBehaviour
    {
        private void Awake()
        {
            if (transform.childCount == 0) WorldFactory.CreateDice(transform);
        }
    }

    public sealed class DicePlatformPrefabVisual : MonoBehaviour
    {
        private void Awake()
        {
            if (transform.childCount == 0) WorldFactory.CreateDicePlatform(transform);
        }
    }
}
