using System;
using System.Collections.Generic;
using UnityEngine;

namespace Menchino.Presentation
{
    public static class ProceduralSpriteFactory
    {
        private static readonly Dictionary<string, Sprite> Cache = new Dictionary<string, Sprite>();

        public static Sprite RoyalPanel(int width = 256, int height = 128)
            => RoundedGradient("royal_panel", width, height, 28, ThemePalette.PurpleLight, ThemePalette.PurpleDark, ThemePalette.GoldLight, 10, true);

        public static Sprite PurpleButton(int width = 256, int height = 96)
            => RoundedGradient("purple_button", width, height, 32, ThemePalette.PurpleLight, ThemePalette.PurpleDark, ThemePalette.Gold, 9, true);

        public static Sprite GoldButton(int width = 320, int height = 112)
            => RoundedGradient("gold_button", width, height, 38, ThemePalette.GoldLight, ThemePalette.GoldDark, Color.white, 8, true);

        public static Sprite GreenButton(int width = 256, int height = 96)
            => RoundedGradient("green_button", width, height, 32, new Color(0.36f,0.88f,0.2f), ThemePalette.GreenDark, ThemePalette.GoldLight, 8, true);

        public static Sprite RedButton(int width = 256, int height = 96)
            => RoundedGradient("red_button", width, height, 32, new Color(1f,0.28f,0.18f), ThemePalette.RedDark, ThemePalette.GoldLight, 8, true);

        public static Sprite BlueButton(int width = 256, int height = 96)
            => RoundedGradient("blue_button", width, height, 32, new Color(0.2f,0.67f,1f), ThemePalette.BlueDark, ThemePalette.GoldLight, 8, true);

        public static Sprite DarkPanel(int width = 256, int height = 128)
            => RoundedGradient("dark_panel", width, height, 26, new Color(0.18f,0.07f,0.28f), new Color(0.04f,0.01f,0.09f), ThemePalette.Gold, 6, false);

        public static Sprite Circle(Color top, Color bottom, Color border, int size = 128)
            => RoundedGradient($"circle_{ColorKey(top)}_{ColorKey(bottom)}_{ColorKey(border)}_{size}", size, size, size/2-1, top, bottom, border, Mathf.Max(4,size/16), true);

        public static Sprite Diamond(Color top, Color bottom, Color border, int size = 128)
        {
            string key = $"diamond_{ColorKey(top)}_{ColorKey(bottom)}_{ColorKey(border)}_{size}";
            if (Cache.TryGetValue(key, out var cached)) return cached;
            var tex = NewTexture(size, size);
            var pixels = new Color32[size * size];
            Vector2 center = new Vector2((size-1)*0.5f, (size-1)*0.5f);
            float radius = size * 0.46f;
            for (int y=0;y<size;y++)
            for (int x=0;x<size;x++)
            {
                float d = (Mathf.Abs(x-center.x)+Mathf.Abs(y-center.y))/radius;
                if (d > 1f) { pixels[y*size+x] = new Color32(0,0,0,0); continue; }
                float edge = Mathf.InverseLerp(1f,0.82f,d);
                float t = 1f-y/(float)(size-1);
                Color c = Color.Lerp(bottom,top,t);
                if (edge < 1f) c = Color.Lerp(border,c,edge);
                float shine = Mathf.Clamp01(1f - Vector2.Distance(new Vector2(x,y), center + new Vector2(-size*.14f,size*.16f))/(size*.35f));
                c = Color.Lerp(c,Color.white,shine*.28f);
                pixels[y*size+x] = c;
            }
            tex.SetPixels32(pixels); tex.Apply(false,true);
            return Cache[key] = MakeSprite(tex, size/3f);
        }

        public static Sprite Background(int width = 256, int height = 512)
        {
            string key = $"background_{width}_{height}";
            if (Cache.TryGetValue(key, out var cached)) return cached;
            var tex = NewTexture(width,height);
            var pixels = new Color32[width*height];
            var random = new System.Random(71027);
            for (int y=0;y<height;y++)
            for (int x=0;x<width;x++)
            {
                float t=y/(float)(height-1);
                Color c=Color.Lerp(ThemePalette.SkyBottom,ThemePalette.SkyTop,t);
                float radial=Mathf.Clamp01(1f-Vector2.Distance(new Vector2(x/(float)width,t),new Vector2(.5f,.65f))/.72f);
                c=Color.Lerp(c,new Color(.15f,.55f,1f),radial*.25f);
                float vignette=Mathf.Pow(Mathf.Abs(x/(float)(width-1)-.5f)*2f,1.7f);
                c*=1f-vignette*.24f;
                pixels[y*width+x]=c;
            }
            for(int i=0;i<180;i++)
            {
                int x=random.Next(2,width-2), y=random.Next(height/3,height-2);
                float a=(float)random.NextDouble()*.55f+.15f;
                pixels[y*width+x]=Color.Lerp(pixels[y*width+x],Color.white,a);
            }
            tex.SetPixels32(pixels);tex.Apply(false,true);
            return Cache[key]=MakeSprite(tex,32f);
        }

        public static Sprite RoundedGradient(string key, int width, int height, int radius, Color top, Color bottom, Color border, int borderSize, bool shine)
        {
            key += $"_{width}_{height}";
            if (Cache.TryGetValue(key, out var cached)) return cached;
            var tex=NewTexture(width,height);
            var pixels=new Color32[width*height];
            for(int y=0;y<height;y++)
            for(int x=0;x<width;x++)
            {
                float dist=RoundedDistance(x,y,width,height,radius);
                if(dist>0f){pixels[y*width+x]=new Color32(0,0,0,0);continue;}
                bool isBorder=RoundedDistance(x,y,width,height,Mathf.Max(1,radius-borderSize),borderSize)>0f;
                float t=y/(float)(height-1);
                Color c=Color.Lerp(bottom,top,t);
                if(isBorder)c=Color.Lerp(ThemePalette.GoldDark,border,Mathf.Clamp01(t+.15f));
                else
                {
                    float innerShadow=Mathf.Clamp01((borderSize*1.7f-Mathf.Min(Mathf.Min(x,width-1-x),Mathf.Min(y,height-1-y)))/(borderSize*1.7f));
                    c=Color.Lerp(c,Color.black,innerShadow*.2f);
                    if(shine)
                    {
                        float band=Mathf.Clamp01(1f-Mathf.Abs(t-.78f)/.11f);
                        c=Color.Lerp(c,Color.white,band*.16f);
                    }
                }
                pixels[y*width+x]=c;
            }
            tex.SetPixels32(pixels);tex.Apply(false,true);
            var sprite=MakeSprite(tex,32f,new Vector4(radius,radius,radius,radius));
            Cache[key]=sprite;
            return sprite;
        }

        private static float RoundedDistance(int x,int y,int width,int height,int radius,int inset=0)
        {
            float left=inset,right=width-1-inset,bottom=inset,top=height-1-inset;
            float cx=Mathf.Clamp(x,left+radius,right-radius);
            float cy=Mathf.Clamp(y,bottom+radius,top-radius);
            return Vector2.Distance(new Vector2(x,y),new Vector2(cx,cy))-radius;
        }

        private static Texture2D NewTexture(int width,int height)
        {
            var tex=new Texture2D(width,height,TextureFormat.RGBA32,false){filterMode=FilterMode.Bilinear,wrapMode=TextureWrapMode.Clamp};
            return tex;
        }

        private static Sprite MakeSprite(Texture2D tex,float pixelsPerUnit,Vector4 border=default)
        {
            return Sprite.Create(tex,new Rect(0,0,tex.width,tex.height),new Vector2(.5f,.5f),pixelsPerUnit,0,SpriteMeshType.FullRect,border);
        }

        private static string ColorKey(Color c) => $"{Mathf.RoundToInt(c.r*255):X2}{Mathf.RoundToInt(c.g*255):X2}{Mathf.RoundToInt(c.b*255):X2}";
    }
}
