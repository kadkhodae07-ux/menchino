using System.Collections.Generic;
using UnityEngine;

namespace Menchino.Data
{
    public static class BoardConfigLoader
    {
        public static BoardLayoutData Load(string boardId = "royal_default")
        {
            string resourceName = string.IsNullOrWhiteSpace(boardId) ? "royal_default" : boardId;
            var asset = Resources.Load<TextAsset>("Configs/board_" + resourceName);
            if (asset == null && resourceName != "royal_default")
                asset = Resources.Load<TextAsset>("Configs/board_royal_default");

            if (asset != null)
            {
                try
                {
                    var parsed = JsonUtility.FromJson<BoardLayoutData>(asset.text);
                    if (IsValid(parsed)) return parsed;
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning($"Menchino board config parse failed: {ex.Message}");
                }
            }
            return DefaultContent.CreateBoard();
        }

        public static bool IsValid(BoardLayoutData board)
        {
            if (board == null || board.ladders == null || board.snakes == null) return false;
            var occupied = new HashSet<int>();
            foreach (var ladder in board.ladders)
            {
                if (ladder == null || ladder.from < 1 || ladder.to > 100 || ladder.from >= ladder.to || !occupied.Add(ladder.from)) return false;
            }
            foreach (var snake in board.snakes)
            {
                if (snake == null || snake.to < 1 || snake.from > 100 || snake.from <= snake.to || !occupied.Add(snake.from)) return false;
            }
            return board.ladders.Count > 0 && board.snakes.Count > 0;
        }
    }
}
