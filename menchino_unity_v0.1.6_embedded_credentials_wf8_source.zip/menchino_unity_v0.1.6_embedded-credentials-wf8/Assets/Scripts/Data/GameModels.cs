using System;
using System.Collections.Generic;
using UnityEngine;

namespace Menchino.Data
{
    public enum ScreenId { Boot, Home, ModeSelect, SnakesSetup, SnakesGameplay, Result, DailyReward, Missions, Shop, Profile, Settings }
    public enum GameMode { Offline, VsBots, LocalMultiplayer, OnlineLocked }
    public enum PlayerKind { Human, Bot }
    public enum AiDifficulty { Easy, Medium, Hard }
    public enum PieceColor { Red, Blue, Green, Yellow }
    public enum TurnPhase { Init, TurnStart, AwaitDiceInput, DiceRolling, PieceMoving, ResolvingSpecial, TurnEnd, MatchFinished, Paused }
    public enum MissionType { CompleteGames, WinGames, UseLadders, RollSixes, ReachHundred, LocalWithFriends }

    [Serializable]
    public sealed class RuleConfigData
    {
        public bool requireExact100 = true;
        public bool allowBounceBack = false;
        public bool extraTurnOnSix = true;
        public int maxConsecutiveSixes = 3;
        public int turnTimeSeconds = 30;
        public bool collisionEnabled = false;
        public bool startAtZero = true;
        public int requiredEntryRoll = 0;

        public RuleConfigData Clone()
        {
            return JsonUtility.FromJson<RuleConfigData>(JsonUtility.ToJson(this));
        }
    }

    [Serializable]
    public sealed class BoardLinkData
    {
        public int from;
        public int to;
        public BoardLinkData() { }
        public BoardLinkData(int from, int to) { this.from = from; this.to = to; }
    }

    [Serializable]
    public sealed class BoardLayoutData
    {
        public string boardId = "royal_default";
        public List<BoardLinkData> ladders = new List<BoardLinkData>();
        public List<BoardLinkData> snakes = new List<BoardLinkData>();
    }

    [Serializable]
    public sealed class PlayerProfileData
    {
        public string playerId = "local-player";
        public string displayName = "آریا";
        public int avatarIndex;
        public int level = 1;
        public int experience;
        public int coins = 1500;
        public int gems = 30;
        public int cups;
        public int stars;
        public int totalGames;
        public int totalWins;
        public int totalDiceRolls;
        public int totalLadders;
        public int totalSnakes;
        public int totalPlaySeconds;
        public string selectedThemeId = "royal";
        public string selectedPieceSkinId = "classic";
        public string selectedDiceSkinId = "ivory";
    }

    [Serializable]
    public sealed class PlayerMatchState
    {
        public string playerId;
        public string displayName;
        public PlayerKind playerKind;
        public AiDifficulty aiDifficulty;
        public PieceColor pieceColor;
        public int avatarIndex;
        public int currentCell;
        public bool hasFinished;
        public int turnIndex;
        public int consecutiveSixes;
        public int usedLaddersCount;
        public int hitSnakesCount;
        public int diceRollCount;
        public int finishOrder;
    }

    [Serializable]
    public sealed class MatchStateData
    {
        public string matchId;
        public GameMode gameMode;
        public int currentTurnIndex;
        public float turnRemainingTime;
        public bool isFinished;
        public string boardId;
        public RuleConfigData rules = new RuleConfigData();
        public List<PlayerMatchState> players = new List<PlayerMatchState>();
        public List<int> diceHistory = new List<int>();
        public long startedUtcTicks;
        public long updatedUtcTicks;
    }

    [Serializable]
    public sealed class PendingMatchSettings
    {
        public GameMode gameMode = GameMode.VsBots;
        public int playerCount = 4;
        public AiDifficulty botDifficulty = AiDifficulty.Medium;
        public RuleConfigData rules = new RuleConfigData();
        public string themeId = "royal";
        public List<PlayerSetupData> players = new List<PlayerSetupData>();
    }

    [Serializable]
    public sealed class PlayerSetupData
    {
        public string displayName;
        public PlayerKind playerKind;
        public AiDifficulty aiDifficulty;
        public PieceColor pieceColor;
        public int avatarIndex;
    }

    [Serializable]
    public sealed class MissionStateData
    {
        public string missionId;
        public MissionType type;
        public string title;
        public string description;
        public int target;
        public int progress;
        public int rewardCoins;
        public int rewardGems;
        public bool claimed;
    }

    [Serializable]
    public sealed class DailyRewardStateData
    {
        public int currentDayIndex;
        public int claimedMask;
        public long cycleStartUtcTicks;
        public long lastClaimUtcTicks;
        public long lastSeenUtcTicks;
    }

    [Serializable]
    public sealed class SettingsData
    {
        public bool music = true;
        public bool soundEffects = true;
        public bool vibration = true;
        public bool notifications = true;
        public int qualityLevel = 2;
    }

    [Serializable]
    public sealed class InventoryData
    {
        public List<string> ownedThemes = new List<string> { "royal" };
        public List<string> ownedPieces = new List<string> { "classic" };
        public List<string> ownedDice = new List<string> { "ivory" };
        public List<string> ownedAvatars = new List<string> { "avatar_0", "avatar_1", "avatar_2", "avatar_3" };
        public List<string> ownedFrames = new List<string>();
        public List<string> ownedEffects = new List<string>();
    }

    [Serializable]
    public sealed class AppSaveData
    {
        public int schemaVersion = 1;
        public PlayerProfileData profile = new PlayerProfileData();
        public SettingsData settings = new SettingsData();
        public InventoryData inventory = new InventoryData();
        public DailyRewardStateData dailyReward = new DailyRewardStateData();
        public List<MissionStateData> missions = new List<MissionStateData>();
        public long missionCycleUtcTicks;
        public MatchStateData unfinishedMatch;
    }

    [Serializable]
    public sealed class MatchResultData
    {
        public List<PlayerMatchState> ranking = new List<PlayerMatchState>();
        public int durationSeconds;
        public int rewardCoins;
        public int rewardExperience;
    }

    public static class DefaultContent
    {
        public static readonly string[] PersianPlayerNames = { "آریا", "سارا", "کیان", "نیلوفر" };

        public static BoardLayoutData CreateBoard()
        {
            return new BoardLayoutData
            {
                boardId = "royal_default",
                ladders = new List<BoardLinkData>
                {
                    new BoardLinkData(2,38), new BoardLinkData(7,14), new BoardLinkData(8,31),
                    new BoardLinkData(15,26), new BoardLinkData(21,42), new BoardLinkData(28,84),
                    new BoardLinkData(36,44), new BoardLinkData(51,67), new BoardLinkData(71,91),
                    new BoardLinkData(78,98)
                },
                snakes = new List<BoardLinkData>
                {
                    new BoardLinkData(16,6), new BoardLinkData(46,25), new BoardLinkData(49,11),
                    new BoardLinkData(62,19), new BoardLinkData(64,60), new BoardLinkData(74,53),
                    new BoardLinkData(89,68), new BoardLinkData(92,88), new BoardLinkData(95,75),
                    new BoardLinkData(99,80)
                }
            };
        }

        public static List<MissionStateData> CreateDailyMissions()
        {
            return new List<MissionStateData>
            {
                new MissionStateData { missionId="play_2", type=MissionType.CompleteGames, title="۲ بازی کامل انجام بده", description="دو مسابقه را تا پایان ادامه بده", target=2, rewardCoins=300, rewardGems=2 },
                new MissionStateData { missionId="win_1", type=MissionType.WinGames, title="یک بار برنده شو", description="در یک مسابقه رتبه اول را بگیر", target=1, rewardCoins=500, rewardGems=3 },
                new MissionStateData { missionId="ladder_2", type=MissionType.UseLadders, title="از ۲ نردبان بالا برو", description="در مسابقه‌ها دو صعود ثبت کن", target=2, rewardCoins=250, rewardGems=1 },
                new MissionStateData { missionId="six_3", type=MissionType.RollSixes, title="۳ بار عدد ۶ بیاور", description="سه تاس شش در بازی‌ها ثبت کن", target=3, rewardCoins=350, rewardGems=2 }
            };
        }

        public static PendingMatchSettings CreatePendingSettings(GameMode mode, PlayerProfileData profile)
        {
            var result = new PendingMatchSettings { gameMode = mode, playerCount = 4 };
            for (int i = 0; i < 4; i++)
            {
                bool human = i == 0 || mode == GameMode.LocalMultiplayer || mode == GameMode.Offline;
                result.players.Add(new PlayerSetupData
                {
                    displayName = i == 0 ? profile.displayName : PersianPlayerNames[i],
                    playerKind = human ? PlayerKind.Human : PlayerKind.Bot,
                    aiDifficulty = AiDifficulty.Medium,
                    pieceColor = (PieceColor)i,
                    avatarIndex = i
                });
            }
            return result;
        }
    }
}
