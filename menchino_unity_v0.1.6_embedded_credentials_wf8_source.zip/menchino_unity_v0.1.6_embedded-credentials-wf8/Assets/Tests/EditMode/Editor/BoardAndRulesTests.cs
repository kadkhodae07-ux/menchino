#if UNITY_EDITOR
using Menchino.Data;
using Menchino.Gameplay;
using NUnit.Framework;

namespace Menchino.Tests
{
    public sealed class BoardAndRulesTests
    {
        [Test]
        public void ZigzagBoardMapping_IsCorrectAtRowBoundaries()
        {
            Assert.AreEqual(new UnityEngine.Vector2Int(0, 0), BoardMath.NumberToGrid(1));
            Assert.AreEqual(new UnityEngine.Vector2Int(9, 0), BoardMath.NumberToGrid(10));
            Assert.AreEqual(new UnityEngine.Vector2Int(9, 1), BoardMath.NumberToGrid(11));
            Assert.AreEqual(new UnityEngine.Vector2Int(0, 1), BoardMath.NumberToGrid(20));
            Assert.AreEqual(new UnityEngine.Vector2Int(0, 9), BoardMath.NumberToGrid(100));
        }

        [Test]
        public void EveryBoardCell_RoundTrips()
        {
            for (int cell = 1; cell <= 100; cell++)
            {
                var grid = BoardMath.NumberToGrid(cell);
                Assert.AreEqual(cell, BoardMath.GridToNumber(grid.x, grid.y));
            }
        }


        [Test]
        public void EntryRollSix_EntersOnCellOne()
        {
            var rules = new RuleConfigData { requiredEntryRoll = 6 };
            Assert.IsFalse(RuleEngine.Plan(0, 5, rules, DefaultContent.CreateBoard()).canMove);
            var plan = RuleEngine.Plan(0, 6, rules, DefaultContent.CreateBoard());
            Assert.IsTrue(plan.canMove);
            Assert.AreEqual(1, plan.finalCell);
        }

        [Test]
        public void ExactHundred_BlocksOvershoot()
        {
            var rules = new RuleConfigData { requireExact100 = true, allowBounceBack = false };
            var plan = RuleEngine.Plan(97, 5, rules, DefaultContent.CreateBoard());
            Assert.IsFalse(plan.canMove);
            Assert.AreEqual(97, plan.finalCell);
        }

        [Test]
        public void BounceBack_ReturnsFromHundred()
        {
            var rules = new RuleConfigData { requireExact100 = false, allowBounceBack = true };
            var plan = RuleEngine.Plan(97, 5, rules, DefaultContent.CreateBoard());
            Assert.IsTrue(plan.canMove);
            Assert.AreEqual(98, plan.finalCell);
        }

        [TestCase(2, 38, true)]
        [TestCase(28, 84, true)]
        [TestCase(16, 6, false)]
        [TestCase(99, 80, false)]
        public void SpecialLinks_ResolveToConfiguredDestination(int from, int to, bool ladder)
        {
            var rules = new RuleConfigData();
            var plan = RuleEngine.Plan(from - 1, 1, rules, DefaultContent.CreateBoard());
            Assert.AreEqual(to, plan.finalCell);
            Assert.AreEqual(ladder, plan.usedLadder);
            Assert.AreEqual(!ladder, plan.hitSnake);
        }


        [Test]
        public void ResourceBoardConfig_IsValidAndComplete()
        {
            var board = BoardConfigLoader.Load();
            Assert.IsTrue(BoardConfigLoader.IsValid(board));
            Assert.AreEqual(10, board.ladders.Count);
            Assert.AreEqual(10, board.snakes.Count);
        }

        [Test]
        public void DefaultBoard_HasTenSnakesAndTenLadders()
        {
            var board = DefaultContent.CreateBoard();
            Assert.AreEqual(10, board.ladders.Count);
            Assert.AreEqual(10, board.snakes.Count);
            foreach (var ladder in board.ladders) Assert.Greater(ladder.to, ladder.from);
            foreach (var snake in board.snakes) Assert.Less(snake.to, snake.from);
        }
    }
}
#endif
