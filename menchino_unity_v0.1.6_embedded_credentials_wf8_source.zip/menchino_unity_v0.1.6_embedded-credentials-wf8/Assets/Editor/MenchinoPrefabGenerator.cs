#if UNITY_EDITOR
using Menchino.Presentation;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.Editor
{
    [InitializeOnLoad]
    public static class MenchinoPrefabGenerator
    {
        static MenchinoPrefabGenerator()
        {
            EditorApplication.delayCall += GenerateIfMissing;
        }

        [MenuItem("Menchino/Regenerate Modular Prefabs")]
        public static void Generate()
        {
            EnsureFolder("Assets/Prefabs");
            EnsureFolder("Assets/Prefabs/UI");
            EnsureFolder("Assets/Prefabs/Gameplay");

            SaveUiPrefab("Assets/Prefabs/UI/PF_RoyalPanel.prefab", false);
            SaveUiPrefab("Assets/Prefabs/UI/PF_DarkPanel.prefab", true);
            SaveButtonPrefab("Assets/Prefabs/UI/PF_PrimaryButton.prefab", true);
            SaveButtonPrefab("Assets/Prefabs/UI/PF_SecondaryButton.prefab", false);
            SaveWorldPrefab<DicePrefabVisual>("Assets/Prefabs/Gameplay/PF_Dice3D.prefab");
            SaveWorldPrefab<DicePlatformPrefabVisual>("Assets/Prefabs/Gameplay/PF_DicePlatform.prefab");
            SaveWorldPrefab<PawnPrefabVisual>("Assets/Prefabs/Gameplay/PF_Pawn3D.prefab");
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private static void GenerateIfMissing()
        {
            if (AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/UI/PF_RoyalPanel.prefab") == null) Generate();
        }

        private static void SaveUiPrefab(string path, bool dark)
        {
            var go = new GameObject(System.IO.Path.GetFileNameWithoutExtension(path), typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(RoyalPanelPrefabVisual));
            go.GetComponent<RoyalPanelPrefabVisual>().dark = dark;
            PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }

        private static void SaveButtonPrefab(string path, bool primary)
        {
            var go = new GameObject(System.IO.Path.GetFileNameWithoutExtension(path), typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(PressableButton), typeof(RoyalButtonPrefabVisual));
            var visual = go.GetComponent<RoyalButtonPrefabVisual>();
            visual.primary = primary;
            visual.label = primary ? "ادامه" : "انتخاب";
            PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }

        private static void SaveWorldPrefab<T>(string path) where T : Component
        {
            var go = new GameObject(System.IO.Path.GetFileNameWithoutExtension(path), typeof(T));
            PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = System.IO.Path.GetDirectoryName(path)?.Replace('\\', '/');
            string name = System.IO.Path.GetFileName(path);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent ?? "Assets", name);
        }
    }
}
#endif
