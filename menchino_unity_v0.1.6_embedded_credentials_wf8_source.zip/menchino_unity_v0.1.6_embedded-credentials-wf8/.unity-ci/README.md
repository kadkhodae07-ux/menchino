# Unity CI files

- `Unity_lic.ulf`: embedded Unity Personal license.
- `unity_credentials.env`: embedded account credentials for this private repository.
- Workflow v5 loads and masks all values through `GITHUB_ENV`; it does not require Unity repository secrets.
- Do not publish this source ZIP or make the repository public.
