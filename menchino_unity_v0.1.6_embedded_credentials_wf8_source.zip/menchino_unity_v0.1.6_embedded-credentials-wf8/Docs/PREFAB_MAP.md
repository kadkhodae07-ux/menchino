# نقشه Prefab و اجزای مستقل

ابزار `MenchinoPrefabGenerator` پس از Import این Prefabها را می‌سازد:

## UI

- `PF_RoyalPanel`
- `PF_DarkPanel`
- `PF_PrimaryButton`
- `PF_SecondaryButton`

## Gameplay

- `PF_Dice3D`
- `PF_DicePlatform`
- `PF_Pawn3D`

صفحات اصلی نیز از Factoryهای مستقل `UiFactory`، `ProceduralSpriteFactory` و `WorldFactory` استفاده می‌کنند. هر پنل، دکمه، کارت، خانه تخته، مار، نردبان، مهره و تاس GameObject جداگانه دارد و قابل کنترل یا تعویض است. هیچ صفحه‌ای به‌صورت یک تصویر Full-screen ساخته نشده است.
