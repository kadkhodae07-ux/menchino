# معماری فنی منچینو

## جریان Sceneها

`Boot → Home → ModeSelect → SnakesSetup → SnakesGameplay → Result`

Sceneهای جانبی:

- DailyReward
- Missions
- Shop
- Profile
- Settings

## لایه‌ها

### Core

`MenchinoApp` تنها Composition Root پروژه است. سرویس‌ها را می‌سازد، Sceneها را هدایت می‌کند و Popup اختصاصی را مدیریت می‌کند.

### Data

تمام Match State، RuleConfig، BoardLayout، Player State، Daily Reward، Missions و Inventory در مدل‌های Serializable نگهداری می‌شوند.

### Gameplay

- `BoardMath`: تبدیل شماره خانه به مختصات زیگزاگی
- `RuleEngine`: محاسبه حرکت بدون وابستگی به UI
- `MatchController`: State Machine نوبت، تاس، حرکت، مار/نردبان، برد و ذخیره

### Presentation

- `UiFactory`: تولید کامپوننت‌های UI مستقل
- `ProceduralSpriteFactory`: ساخت قاب و دکمه چندلایه
- `WorldFactory`: تخته، مار، نردبان، مهره و تاس سه‌بعدی
- `GameplayWorldView`: اتصال Eventهای منطق به انیمیشن سه‌بعدی
- Screen Controllerها: صفحه اصلی، Setup، Gameplay، Result و صفحات جانبی

### Services

- `SaveRepository`: ذخیره Atomic و نسخه‌دار
- `WalletService`: سکه و جواهر
- `DailyRewardService`: چرخه هفت‌روزه و کنترل ساعت
- `MissionService`: پیشرفت و دریافت جایزه
- `AudioService`: موسیقی و افکت صوتی Runtime

## State Machine مسابقه

1. TurnStart
2. AwaitDiceInput
3. DiceRolling
4. PieceMoving
5. ResolvingSpecial
6. TurnEnd
7. MatchFinished
8. Paused

ورودی تاس فقط در `AwaitDiceInput` پذیرفته می‌شود؛ بنابراین لمس چندباره یا اجرای هم‌زمان حرکت ممکن نیست.

## سیاست داده

- مارها و نردبان‌ها در `DefaultContent.CreateBoard()` متمرکز هستند.
- قوانین در `RuleConfigData` متمرکز هستند.
- نتیجه فیزیک تاس تعیین‌کننده منطق نیست.
- Snapshot مسابقه پس از پایان هر نوبت ذخیره می‌شود.
