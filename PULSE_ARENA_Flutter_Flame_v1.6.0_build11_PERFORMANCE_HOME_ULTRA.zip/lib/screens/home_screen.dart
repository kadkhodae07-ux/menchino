import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../widgets/neon_pressable.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ambient;
  BotDifficulty _difficulty = BotDifficulty.tactical;
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
    unawaited(AudioManager.instance.startBgm());
  }

  @override
  void dispose() {
    _ambient.dispose();
    super.dispose();
  }

  Future<void> _startGame() async {
    if (_leaving) return;
    setState(() => _leaving = true);
    await AudioManager.instance.importantImpact();
    await Future<void>.delayed(const Duration(milliseconds: 110));
    if (!mounted) return;
    await SceneTransitionManager.openGame(
      context,
      config: GameConfig.forDifficulty(_difficulty),
    );
  }

  void _message(String text) {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 900),
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(28, 0, 28, 24),
          backgroundColor: const Color(0xF20A1020),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0x8838E7FF)),
          ),
          content: Text(
            text,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
      );
  }

  Future<void> _showSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: const Color(0xE0000208),
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setSheetState) {
            return SafeArea(
              minimum: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: _TechPanel(
                colors: const <Color>[Color(0xFF28E3FF), Color(0xFFFF42B5)],
                cut: 24,
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: 52,
                      height: 4,
                      decoration: BoxDecoration(
                        color: const Color(0xFF53617A),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    const SizedBox(height: 13),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.settings_rounded,
                            color: Color(0xFFFF63C5), size: 28),
                        SizedBox(width: 8),
                        Text(
                          'تنظیمات مسابقه',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 17),
                    const Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'سطح ربات',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          color: Color(0xFFBDCCE3),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: BotDifficulty.values.map((BotDifficulty value) {
                        final bool selected = value == _difficulty;
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 3),
                            child: NeonPressable(
                              semanticLabel: value.title,
                              onTap: () {
                                setState(() => _difficulty = value);
                                setSheetState(() {});
                              },
                              builder: (_, bool pressed) => AnimatedContainer(
                                duration: const Duration(milliseconds: 100),
                                height: 50,
                                decoration: BoxDecoration(
                                  color: selected
                                      ? const Color(0xFF0B6B8C)
                                      : const Color(0xFF0C1424),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: selected
                                        ? const Color(0xFF5DEBFF)
                                        : const Color(0x55536A8D),
                                  ),
                                  boxShadow: selected
                                      ? const <BoxShadow>[
                                          BoxShadow(
                                            color: Color(0x553DE4FF),
                                            blurRadius: 14,
                                          ),
                                        ]
                                      : null,
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  value.title,
                                  textDirection: TextDirection.rtl,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    color: selected
                                        ? Colors.white
                                        : const Color(0xFF94A4BE),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    _SettingsToggle(
                      icon: AudioManager.instance.soundEnabled
                          ? Icons.volume_up_rounded
                          : Icons.volume_off_rounded,
                      label: 'صدای بازی',
                      enabled: AudioManager.instance.soundEnabled,
                      onTap: () async {
                        await AudioManager.instance.setSoundEnabled(
                          !AudioManager.instance.soundEnabled,
                        );
                        if (mounted) setState(() {});
                        setSheetState(() {});
                      },
                    ),
                    const SizedBox(height: 8),
                    _SettingsToggle(
                      icon: AudioManager.instance.vibrationEnabled
                          ? Icons.vibration_rounded
                          : Icons.mobile_off_rounded,
                      label: 'بازخورد لرزشی',
                      enabled: AudioManager.instance.vibrationEnabled,
                      onTap: () {
                        AudioManager.instance.vibrationEnabled =
                            !AudioManager.instance.vibrationEnabled;
                        setState(() {});
                        setSheetState(() {});
                      },
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'هر بازیکنی که زودتر ۱۰ گل دریافت کند، بازنده است.',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        color: Color(0xFFAAB9D0),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_leaving,
      child: Scaffold(
        backgroundColor: const Color(0xFF01030A),
        body: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 280),
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              RepaintBoundary(
                child: CustomPaint(painter: const _HomeBackgroundPainter()),
              ),
              SafeArea(
                child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    final double scale = constraints.maxWidth / 430;
                    final double logicalHeight = constraints.maxHeight / scale;
                    return Align(
                      alignment: Alignment.topCenter,
                      child: FittedBox(
                        fit: BoxFit.fitWidth,
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          width: 430,
                          height: logicalHeight,
                          child: _HomeCanvas(
                            animation: _ambient,
                            onStart: _startGame,
                            onSettings: _showSettings,
                            onProfile: () => _message('شون رنجر — سطح ۱۸'),
                            onEnergy: () => _message('انرژی فعلی: ۲٬۴۵۰'),
                            onCredit: () => _message('اعتبار فعلی: ۸۶۰'),
                            onNav: (int index) {
                              const List<String> labels = <String>[
                                'خانه',
                                'پروفایل',
                                'ماموریت‌ها',
                                'فروشگاه',
                              ];
                              if (index != 0) _message(labels[index]);
                            },
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomeCanvas extends StatelessWidget {
  const _HomeCanvas({
    required this.animation,
    required this.onStart,
    required this.onSettings,
    required this.onProfile,
    required this.onEnergy,
    required this.onCredit,
    required this.onNav,
  });

  final Animation<double> animation;
  final VoidCallback onStart;
  final VoidCallback onSettings;
  final VoidCallback onProfile;
  final VoidCallback onEnergy;
  final VoidCallback onCredit;
  final ValueChanged<int> onNav;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: <Widget>[
        Positioned(
          left: 10,
          top: 10,
          width: 190,
          height: 68,
          child: _ProfileCard(onTap: onProfile),
        ),
        Positioned(
          left: 205,
          top: 12,
          width: 104,
          height: 56,
          child: _ResourceCard(
            color: const Color(0xFFFFC832),
            value: '2,450',
            icon: Icons.bolt_rounded,
            onTap: onEnergy,
          ),
        ),
        Positioned(
          right: 10,
          top: 12,
          width: 104,
          height: 56,
          child: _ResourceCard(
            color: const Color(0xFFFF48C1),
            value: '860',
            icon: Icons.motion_photos_on_rounded,
            onTap: onCredit,
          ),
        ),
        const Positioned(
          left: 0,
          right: 0,
          top: 92,
          child: _GameTitle(),
        ),
        Positioned(
          left: 20,
          top: 188,
          width: 390,
          height: 255,
          child: RepaintBoundary(
            child: AnimatedBuilder(
              animation: animation,
              builder: (_, __) => CustomPaint(
                painter: _ArenaPreviewPainter(progress: animation.value),
              ),
            ),
          ),
        ),
        const Positioned(
          left: 132,
          top: 425,
          width: 166,
          height: 39,
          child: _PowerStrip(),
        ),
        Positioned(
          left: 54,
          top: 468,
          width: 322,
          height: 72,
          child: _PrimaryButton(onTap: onStart),
        ),
        Positioned(
          left: 54,
          top: 554,
          width: 154,
          height: 55,
          child: _SecondaryButton(
            label: 'بازی آفلاین',
            icon: Icons.gps_fixed_rounded,
            color: const Color(0xFF37E5FF),
            onTap: onStart,
          ),
        ),
        Positioned(
          right: 54,
          top: 554,
          width: 154,
          height: 55,
          child: _SecondaryButton(
            label: 'تنظیمات',
            icon: Icons.settings_rounded,
            color: const Color(0xFFFF4DB8),
            onTap: onSettings,
          ),
        ),
        Positioned(
          left: 12,
          right: 12,
          bottom: 7,
          height: 78,
          child: _BottomNavigation(onTap: onNav),
        ),
      ],
    );
  }
}

class _ProfileCard extends StatelessWidget {
  const _ProfileCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'پروفایل بازیکن',
      onTap: onTap,
      builder: (_, bool pressed) => _TechPanel(
        colors: const <Color>[Color(0xFF36E7FF), Color(0xFF0877C8)],
        cut: 14,
        pressed: pressed,
        padding: const EdgeInsets.fromLTRB(10, 7, 9, 7),
        child: Row(
          children: <Widget>[
            Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                const SizedBox(
                  width: 55,
                  height: 55,
                  child: CustomPaint(painter: _AvatarPainter()),
                ),
                Positioned(
                  right: -2,
                  bottom: -2,
                  child: Container(
                    width: 20,
                    height: 20,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFF071525),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: const Color(0xFF39E7FF)),
                      boxShadow: const <BoxShadow>[
                        BoxShadow(color: Color(0x7739E7FF), blurRadius: 7),
                      ],
                    ),
                    child: const Text(
                      '18',
                      style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Text(
                    'شون رنجر',
                    textDirection: TextDirection.rtl,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'سطح 18',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 10.5,
                      color: Color(0xFF35DBFF),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Container(
                          height: 4,
                          decoration: BoxDecoration(
                            color: const Color(0xFF17263B),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: FractionallySizedBox(
                              widthFactor: .75,
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: <Color>[
                                      Color(0xFF29D7FF),
                                      Color(0xFF60F0FF),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(4),
                                  boxShadow: const <BoxShadow>[
                                    BoxShadow(
                                      color: Color(0xAA2BE0FF),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text(
                        '75%',
                        style: TextStyle(
                          fontSize: 9.5,
                          color: Color(0xFFEAFBFF),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResourceCard extends StatelessWidget {
  const _ResourceCard({
    required this.color,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  final Color color;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: value,
      onTap: onTap,
      builder: (_, bool pressed) => _TechPanel(
        colors: <Color>[color, color.withValues(alpha: .55)],
        cut: 13,
        pressed: pressed,
        padding: const EdgeInsets.fromLTRB(8, 6, 7, 6),
        child: Row(
          children: <Widget>[
            Container(
              width: 29,
              height: 29,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF080B15),
                border: Border.all(color: color.withValues(alpha: .85)),
                boxShadow: <BoxShadow>[
                  BoxShadow(color: color.withValues(alpha: .36), blurRadius: 12),
                ],
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 7),
            Expanded(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.center,
                child: Text(
                  value,
                  maxLines: 1,
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: .15,
                  ),
                ),
              ),
            ),
            Icon(Icons.add_rounded, size: 18, color: color),
          ],
        ),
      ),
    );
  }
}

class _GameTitle extends StatelessWidget {
  const _GameTitle();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ShaderMask(
          shaderCallback: (Rect rect) => const LinearGradient(
            colors: <Color>[
              Color(0xFF5DEBFF),
              Color(0xFFC8F8FF),
              Color(0xFFEF73FF),
              Color(0xFFFF5BBE),
            ],
            stops: <double>[0, .38, .62, 1],
          ).createShader(rect),
          child: const Text(
            'PULSE ARENA',
            textAlign: TextAlign.center,
            maxLines: 1,
            style: TextStyle(
              color: Colors.white,
              fontSize: 43,
              letterSpacing: 1.5,
              fontWeight: FontWeight.w900,
              shadows: <Shadow>[
                Shadow(color: Color(0xAA3DE7FF), blurRadius: 17),
                Shadow(color: Color(0x88FF43B8), blurRadius: 23),
              ],
            ),
          ),
        ),
        const SizedBox(height: 1),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 60,
              height: 2,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[Colors.transparent, Color(0xFF3DEAFF)],
                ),
              ),
            ),
            const SizedBox(width: 13),
            const Text(
              'نبرد پالس‌ها',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFFF8F5FF),
                shadows: <Shadow>[
                  Shadow(color: Color(0xAA4BEAFF), blurRadius: 12),
                  Shadow(color: Color(0xAAFF4CBE), blurRadius: 12),
                ],
              ),
            ),
            const SizedBox(width: 13),
            Container(
              width: 60,
              height: 2,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[Color(0xFFFF4BC0), Colors.transparent],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _PowerStrip extends StatelessWidget {
  const _PowerStrip();

  @override
  Widget build(BuildContext context) {
    return _TechPanel(
      colors: const <Color>[Color(0xFF2FE5FF), Color(0xFFFF49BC)],
      cut: 10,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _PowerItem(Icons.shield_rounded, 'x2', Color(0xFF41E6FF)),
          _PowerDivider(),
          _PowerItem(Icons.bolt_rounded, 'x1', Color(0xFFFFC832)),
          _PowerDivider(),
          _PowerItem(Icons.graphic_eq_rounded, 'x2', Color(0xFFFF53C4)),
        ],
      ),
    );
  }
}

class _PowerItem extends StatelessWidget {
  const _PowerItem(this.icon, this.value, this.color);
  final IconData icon;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(
          value,
          style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w900),
        ),
      ],
    );
  }
}

class _PowerDivider extends StatelessWidget {
  const _PowerDivider();

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 20, color: const Color(0x554C5B76));
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'شروع بازی',
      pressedScale: .955,
      onTap: onTap,
      builder: (_, bool pressed) => CustomPaint(
        painter: _ActionButtonPainter(
          pressed: pressed,
          cyan: const Color(0xFF2BE4FF),
          magenta: const Color(0xFFFF46BB),
          strong: true,
        ),
        child: const Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.keyboard_double_arrow_right_rounded,
                  color: Color(0x7738E7FF), size: 28),
              SizedBox(width: 18),
              Text(
                'شروع بازی',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 31,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  shadows: <Shadow>[
                    Shadow(color: Color(0xCCFFFFFF), blurRadius: 9),
                    Shadow(color: Color(0xAA8B5CFF), blurRadius: 16),
                  ],
                ),
              ),
              SizedBox(width: 18),
              Icon(Icons.keyboard_double_arrow_left_rounded,
                  color: Color(0x77FF45B9), size: 28),
            ],
          ),
        ),
      ),
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  const _SecondaryButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) => _TechPanel(
        colors: <Color>[color, color.withValues(alpha: .70)],
        cut: 13,
        pressed: pressed,
        padding: const EdgeInsets.symmetric(horizontal: 13),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, size: 27, color: color),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                label,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                style: const TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation({required this.onTap});
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return _TechPanel(
      colors: const <Color>[Color(0xFF36E5FF), Color(0xFFFF48BB)],
      cut: 15,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      child: Row(
        children: <Widget>[
          _NavItem(
            index: 0,
            icon: Icons.home_rounded,
            label: 'خانه',
            active: true,
            onTap: onTap,
          ),
          const _NavDivider(),
          _NavItem(
            index: 1,
            icon: Icons.person_outline_rounded,
            label: 'پروفایل',
            onTap: onTap,
          ),
          const _NavDivider(),
          _NavItem(
            index: 2,
            icon: Icons.track_changes_rounded,
            label: 'ماموریت‌ها',
            badge: true,
            onTap: onTap,
          ),
          const _NavDivider(),
          _NavItem(
            index: 3,
            icon: Icons.shopping_cart_outlined,
            label: 'فروشگاه',
            onTap: onTap,
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.index,
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.badge = false,
  });

  final int index;
  final IconData icon;
  final String label;
  final bool active;
  final bool badge;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = active ? const Color(0xFF57EBFF) : const Color(0xFF818CB7);
    return Expanded(
      child: NeonPressable(
        semanticLabel: label,
        onTap: () => onTap(index),
        pressedScale: .92,
        builder: (_, bool pressed) => AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: active ? const Color(0x241DCEFF) : Colors.transparent,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  Icon(
                    icon,
                    size: 27,
                    color: color,
                    shadows: active
                        ? const <Shadow>[
                            Shadow(color: Color(0xCC3DE7FF), blurRadius: 13),
                          ]
                        : null,
                  ),
                  if (badge)
                    const Positioned(
                      top: -2,
                      right: -5,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Color(0xFFFF3C96),
                          shape: BoxShape.circle,
                          boxShadow: <BoxShadow>[
                            BoxShadow(color: Color(0xAAFF3C96), blurRadius: 7),
                          ],
                        ),
                        child: SizedBox(width: 7, height: 7),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                label,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  color: color,
                  fontSize: 11.5,
                  fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                ),
              ),
              const SizedBox(height: 3),
              AnimatedContainer(
                duration: const Duration(milliseconds: 100),
                width: active ? 27 : 0,
                height: 2.5,
                decoration: BoxDecoration(
                  color: const Color(0xFF4CE9FF),
                  borderRadius: BorderRadius.circular(4),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(color: Color(0xCC35E7FF), blurRadius: 8),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavDivider extends StatelessWidget {
  const _NavDivider();

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 40, color: const Color(0x334E5C7B));
  }
}

class _SettingsToggle extends StatelessWidget {
  const _SettingsToggle({
    required this.icon,
    required this.label,
    required this.enabled,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) => AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        height: 53,
        padding: const EdgeInsets.symmetric(horizontal: 13),
        decoration: BoxDecoration(
          color: pressed ? const Color(0xFF101E31) : const Color(0xFF0B1424),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: enabled ? const Color(0x884CE7FF) : const Color(0x4454647E),
          ),
        ),
        child: Row(
          children: <Widget>[
            Icon(icon,
                color: enabled ? const Color(0xFF52E8FF) : const Color(0xFF78859D)),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                label,
                textDirection: TextDirection.rtl,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            Switch.adaptive(value: enabled, onChanged: (_) => onTap()),
          ],
        ),
      ),
    );
  }
}

class _TechPanel extends StatelessWidget {
  const _TechPanel({
    required this.colors,
    required this.child,
    this.cut = 18,
    this.padding = EdgeInsets.zero,
    this.pressed = false,
  });

  final List<Color> colors;
  final Widget child;
  final double cut;
  final EdgeInsetsGeometry padding;
  final bool pressed;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _TechPanelPainter(colors: colors, cut: cut, pressed: pressed),
      child: Padding(padding: padding, child: child),
    );
  }
}

class _TechPanelPainter extends CustomPainter {
  const _TechPanelPainter({
    required this.colors,
    required this.cut,
    required this.pressed,
  });

  final List<Color> colors;
  final double cut;
  final bool pressed;

  Path _path(Size size, double inset) {
    final double c = math.max(4.0, cut - inset * .45);
    final double l = inset;
    final double t = inset;
    final double r = size.width - inset;
    final double b = size.height - inset;
    return Path()
      ..moveTo(l + c, t)
      ..lineTo(r - c, t)
      ..lineTo(r, t + c)
      ..lineTo(r, b - c)
      ..lineTo(r - c, b)
      ..lineTo(l + c, b)
      ..lineTo(l, b - c)
      ..lineTo(l, t + c)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Path outer = _path(size, 1.5);
    final Path bevel = _path(size, 4.7);
    final Path inner = _path(size, 7.2);
    final Color left = colors.first;
    final Color right = colors.length > 1 ? colors.last : colors.first;
    final double pressure = pressed ? .70 : 1.0;

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 11 * pressure
        ..shader = LinearGradient(
          colors: <Color>[
            left.withValues(alpha: .30 * pressure),
            right.withValues(alpha: .30 * pressure),
          ],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
    );

    canvas.drawPath(
      outer,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            const Color(0xF5142238),
            Color.lerp(const Color(0xF20A1222), left, .035)!,
            Color.lerp(const Color(0xF2050914), right, .045)!,
          ],
          stops: const <double>[0, .52, 1],
        ).createShader(rect),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height * .48),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withValues(alpha: pressed ? .018 : .045),
            Colors.transparent,
          ],
        ).createShader(rect),
    );
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            left.withValues(alpha: .035),
            Colors.transparent,
            right.withValues(alpha: .035),
          ],
        ).createShader(rect),
    );
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.75
        ..shader = LinearGradient(
          colors: <Color>[left, const Color(0xFF7889BF), right],
          stops: const <double>[0, .50, 1],
        ).createShader(rect),
    );
    canvas.drawPath(
      bevel,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .85
        ..shader = LinearGradient(
          colors: <Color>[
            left.withValues(alpha: .55),
            const Color(0x224B5C7A),
            right.withValues(alpha: .55),
          ],
        ).createShader(rect),
    );
    canvas.drawPath(
      inner,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .45
        ..color = const Color(0x335E7196),
    );

    final Paint accent = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square
      ..strokeWidth = 2.1
      ..shader = LinearGradient(colors: <Color>[left, right]).createShader(rect);
    final double short = math.min(size.width * .21, 52);
    canvas.drawLine(Offset(cut + 7, 3.5), Offset(cut + 7 + short, 3.5), accent);
    canvas.drawLine(
      Offset(size.width - cut - 7 - short, size.height - 3.5),
      Offset(size.width - cut - 7, size.height - 3.5),
      accent,
    );

    final Paint notch = Paint()
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.square;
    notch.color = left.withValues(alpha: .72);
    canvas.drawLine(Offset(5, cut + 5), Offset(5, cut + 17), notch);
    canvas.drawLine(Offset(cut + 5, 5), Offset(cut + 17, 5), notch);
    notch.color = right.withValues(alpha: .72);
    canvas.drawLine(
      Offset(size.width - 5, size.height - cut - 17),
      Offset(size.width - 5, size.height - cut - 5),
      notch,
    );
    canvas.drawLine(
      Offset(size.width - cut - 17, size.height - 5),
      Offset(size.width - cut - 5, size.height - 5),
      notch,
    );
  }

  @override
  bool shouldRepaint(covariant _TechPanelPainter oldDelegate) {
    return oldDelegate.pressed != pressed ||
        oldDelegate.colors != colors ||
        oldDelegate.cut != cut;
  }
}

class _ActionButtonPainter extends CustomPainter {
  const _ActionButtonPainter({
    required this.pressed,
    required this.cyan,
    required this.magenta,
    required this.strong,
  });

  final bool pressed;
  final Color cyan;
  final Color magenta;
  final bool strong;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final double cut = 18;
    final Path path = Path()
      ..moveTo(cut, 1)
      ..lineTo(size.width - cut, 1)
      ..lineTo(size.width - 1, cut)
      ..lineTo(size.width - 1, size.height - cut)
      ..lineTo(size.width - cut, size.height - 1)
      ..lineTo(cut, size.height - 1)
      ..lineTo(1, size.height - cut)
      ..lineTo(1, cut)
      ..close();

    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = pressed ? 10 : 15
        ..shader = LinearGradient(
          colors: <Color>[cyan.withValues(alpha: .26), magenta.withValues(alpha: .26)],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          colors: <Color>[
            const Color(0xFF082B4E),
            pressed ? const Color(0xFF241546) : const Color(0xFF32165B),
            const Color(0xFF511441),
          ],
        ).createShader(rect),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = LinearGradient(colors: <Color>[cyan, magenta]).createShader(rect),
    );
    final Path inner = Path()
      ..moveTo(cut + 7, 8)
      ..lineTo(size.width - cut - 7, 8)
      ..lineTo(size.width - 8, cut + 4)
      ..lineTo(size.width - 8, size.height - cut - 4)
      ..lineTo(size.width - cut - 7, size.height - 8)
      ..lineTo(cut + 7, size.height - 8)
      ..lineTo(8, size.height - cut - 4)
      ..lineTo(8, cut + 4)
      ..close();
    canvas.drawPath(
      inner,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .75
        ..shader = LinearGradient(
          colors: <Color>[cyan.withValues(alpha: .5), magenta.withValues(alpha: .5)],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(covariant _ActionButtonPainter oldDelegate) =>
      oldDelegate.pressed != pressed;
}

class _AvatarPainter extends CustomPainter {
  const _AvatarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2);
    final Rect bounds = Offset.zero & size;
    canvas.drawCircle(
      center,
      size.width * .46,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..shader = const SweepGradient(
          colors: <Color>[
            Color(0xFF31EAFF),
            Color(0xFFFF4AC0),
            Color(0xFF31EAFF),
          ],
        ).createShader(bounds),
    );
    canvas.drawCircle(
      center,
      size.width * .39,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Color(0xFF3D0D5B), Color(0xFF070A16)],
        ).createShader(bounds),
    );
    final Path helmet = Path()
      ..moveTo(size.width * .25, size.height * .49)
      ..quadraticBezierTo(size.width * .27, size.height * .23, size.width * .5, size.height * .19)
      ..quadraticBezierTo(size.width * .73, size.height * .23, size.width * .75, size.height * .49)
      ..lineTo(size.width * .69, size.height * .72)
      ..quadraticBezierTo(size.width * .5, size.height * .82, size.width * .31, size.height * .72)
      ..close();
    canvas.drawPath(
      helmet,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFFFF55C6),
            Color(0xFF56208E),
            Color(0xFF17CBEF),
          ],
        ).createShader(bounds),
    );
    final Path visor = Path()
      ..moveTo(size.width * .30, size.height * .43)
      ..quadraticBezierTo(size.width * .5, size.height * .34, size.width * .70, size.height * .43)
      ..lineTo(size.width * .66, size.height * .58)
      ..quadraticBezierTo(size.width * .5, size.height * .63, size.width * .34, size.height * .58)
      ..close();
    canvas.drawPath(
      visor,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF061321), Color(0xFF111023), Color(0xFF04121F)],
        ).createShader(bounds),
    );
    canvas.drawPath(
      visor,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = const Color(0xFFC9FAFF),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ArenaPreviewPainter extends CustomPainter {
  _ArenaPreviewPainter({required this.progress});
  final double progress;

  Path _frame(Size size, double inset) {
    final double cut = 23 - inset * .4;
    return Path()
      ..moveTo(inset + cut, inset)
      ..lineTo(size.width - inset - cut, inset)
      ..lineTo(size.width - inset, inset + cut)
      ..lineTo(size.width - inset, size.height - inset - cut)
      ..lineTo(size.width - inset - cut, size.height - inset)
      ..lineTo(inset + cut, size.height - inset)
      ..lineTo(inset, size.height - inset - cut)
      ..lineTo(inset, inset + cut)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Path outer = _frame(size, 2);
    canvas.save();
    canvas.clipPath(outer);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF03182D), Color(0xFF08091A), Color(0xFF28051E)],
          stops: <double>[0, .5, 1],
        ).createShader(rect),
    );
    _drawHexGrid(canvas, size);
    _drawCenterAxis(canvas, size);
    _drawArenaEnergy(canvas, size);
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x5534E9FF), Color(0x335A68FF), Color(0x55FF47BD)],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
    );
    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF36E7FF), Color(0xFF7780FF), Color(0xFFFF46BD)],
        ).createShader(rect),
    );
    canvas.drawPath(
      _frame(size, 9),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .75
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x8839E9FF), Color(0x445D68FF), Color(0x88FF4BBE)],
        ).createShader(rect),
    );
    _drawFrameAccents(canvas, size);
  }

  void _drawHexGrid(Canvas canvas, Size size) {
    const double r = 17;
    final double h = math.sqrt(3) * r;
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .55
      ..color = const Color(0x243E7B9E);
    for (int row = -1; row < size.height / h + 2; row++) {
      for (int col = -1; col < size.width / (r * 1.5) + 2; col++) {
        final double cx = col * r * 1.5;
        final double cy = row * h + (col.isOdd ? h / 2 : 0);
        final Path hex = Path();
        for (int i = 0; i < 6; i++) {
          final double angle = math.pi / 3 * i;
          final Offset p = Offset(cx + r * math.cos(angle), cy + r * math.sin(angle));
          if (i == 0) {
            hex.moveTo(p.dx, p.dy);
          } else {
            hex.lineTo(p.dx, p.dy);
          }
        }
        hex.close();
        canvas.drawPath(hex, paint);
      }
    }
  }

  void _drawCenterAxis(Canvas canvas, Size size) {
    final double cx = size.width / 2;
    final Paint line = Paint()
      ..strokeWidth = 1
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[Colors.transparent, Color(0xFF704BFF), Colors.transparent],
      ).createShader(Rect.fromLTWH(cx - 1, 0, 2, size.height));
    canvas.drawLine(Offset(cx, 12), Offset(cx, size.height - 12), line);
    for (int i = 0; i < 9; i++) {
      final double y = 25 + i * (size.height - 50) / 8;
      canvas.drawCircle(
        Offset(cx, y),
        i == 4 ? 3.0 : 1.7,
        Paint()
          ..color = const Color(0xFF8A48FF).withValues(alpha: .45 + .4 * math.sin(progress * math.pi * 2 + i).abs())
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
      );
    }
  }

  void _drawArenaEnergy(Canvas canvas, Size size) {
    final double wave = math.sin(progress * math.pi * 2);
    final Offset center = Offset(size.width / 2, size.height / 2 + wave * 2);
    final double paddleHeight = 90;
    _drawPreviewPaddle(
      canvas,
      Rect.fromCenter(center: Offset(34, center.dy), width: 12, height: paddleHeight),
      const Color(0xFF31E7FF),
    );
    _drawPreviewPaddle(
      canvas,
      Rect.fromCenter(center: Offset(size.width - 34, center.dy), width: 12, height: paddleHeight),
      const Color(0xFFFF48BB),
    );

    final Offset leftSpark = Offset(79 + 10 * wave, center.dy - 12);
    final Offset rightSpark = Offset(size.width - 79 - 9 * wave, center.dy + 17);
    canvas.drawLine(
      leftSpark,
      center,
      Paint()
        ..strokeWidth = 1.2
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x0037E6FF), Color(0xFF37E6FF)],
        ).createShader(Rect.fromPoints(leftSpark, center)),
    );
    canvas.drawLine(
      center,
      rightSpark,
      Paint()
        ..strokeWidth = 1.2
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFFFF4ABC), Color(0x00FF4ABC)],
        ).createShader(Rect.fromPoints(center, rightSpark)),
    );

    for (int i = 0; i < 4; i++) {
      final double radius = 27 + i * 10 + wave * 1.5;
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 2 : .9
          ..shader = const SweepGradient(
            colors: <Color>[
              Color(0xFF31E8FF),
              Color(0xFF6F52FF),
              Color(0xFFFF47BE),
              Color(0xFF31E8FF),
            ],
          ).createShader(Rect.fromCircle(center: center, radius: radius)),
      );
    }
    canvas.drawCircle(
      center,
      20,
      Paint()
        ..color = const Color(0xFF7336FF).withValues(alpha: .55)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13),
    );
    canvas.drawCircle(
      center,
      13,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-.3, -.3),
          colors: <Color>[Colors.white, Color(0xFFB54AFF), Color(0xFF29126E)],
        ).createShader(Rect.fromCircle(center: center, radius: 13)),
    );

    final Paint spark = Paint()
      ..color = const Color(0xFF8AF4FF)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
    for (int i = 0; i < 10; i++) {
      final double a = progress * math.pi * 2 + i * .73;
      final double r = 43 + (i % 3) * 13;
      canvas.drawCircle(center + Offset(math.cos(a) * r, math.sin(a) * r), 1.1, spark);
    }
  }

  void _drawPreviewPaddle(Canvas canvas, Rect rect, Color color) {
    final RRect rrect = RRect.fromRectAndRadius(rect, const Radius.circular(9));
    canvas.drawRRect(
      rrect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 11
        ..color = color.withValues(alpha: .28)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );
    canvas.drawRRect(rrect, Paint()..color = color);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect.deflate(3.2), const Radius.circular(6)),
      Paint()..color = const Color(0xFFF4FFFF),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: rect.center, width: 2.3, height: rect.height * .55),
        const Radius.circular(2),
      ),
      Paint()..color = color.withValues(alpha: .75),
    );
  }

  void _drawFrameAccents(Canvas canvas, Size size) {
    const Color cyan = Color(0xFF34E8FF);
    const Color pink = Color(0xFFFF47BE);
    final Paint cp = Paint()..color = cyan;
    final Paint pp = Paint()..color = pink;
    canvas.drawRect(const Rect.fromLTWH(30, 0, 45, 3), cp);
    canvas.drawRect(Rect.fromLTWH(size.width - 75, 0, 45, 3), pp);
    canvas.drawRect(Rect.fromLTWH(0, 40, 3, 38), cp);
    canvas.drawRect(Rect.fromLTWH(size.width - 3, size.height - 78, 3, 38), pp);
  }

  @override
  bool shouldRepaint(covariant _ArenaPreviewPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _HomeBackgroundPainter extends CustomPainter {
  const _HomeBackgroundPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(0, -.15),
          radius: 1.15,
          colors: <Color>[
            Color(0xFF071326),
            Color(0xFF030612),
            Color(0xFF010208),
          ],
        ).createShader(rect),
    );
    canvas.drawCircle(
      Offset(-size.width * .06, size.height * .45),
      size.width * .52,
      Paint()
        ..color = const Color(0xFF006A9E).withValues(alpha: .16)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 70),
    );
    canvas.drawCircle(
      Offset(size.width * 1.05, size.height * .48),
      size.width * .52,
      Paint()
        ..color = const Color(0xFF8F005F).withValues(alpha: .14)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 70),
    );

    final Paint grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .55
      ..color = const Color(0x153C6C91);
    const double r = 23;
    final double h = math.sqrt(3) * r;
    for (int row = -1; row < size.height / h + 2; row++) {
      for (int col = -1; col < size.width / (r * 1.5) + 2; col++) {
        final double cx = col * r * 1.5;
        final double cy = row * h + (col.isOdd ? h / 2 : 0);
        final Path hex = Path();
        for (int i = 0; i < 6; i++) {
          final double angle = math.pi / 3 * i;
          final Offset p = Offset(cx + r * math.cos(angle), cy + r * math.sin(angle));
          if (i == 0) {
            hex.moveTo(p.dx, p.dy);
          } else {
            hex.lineTo(p.dx, p.dy);
          }
        }
        hex.close();
        canvas.drawPath(hex, grid);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
