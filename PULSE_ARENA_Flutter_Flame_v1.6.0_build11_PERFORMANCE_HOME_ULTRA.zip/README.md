# PULSE ARENA – Professional Home & Sustained Performance

Version: `1.6.0+11`

This package upgrades the coded Stage 2 home lobby and rewrites the gameplay input/performance path for sustained smooth play on Android devices.

## Home lobby

- The home screen is rendered from Flutter widgets and custom painters; the reference screenshot is not embedded as a background.
- The layout is top-aligned and width-responsive, preventing the large empty area that appeared on tall phones.
- Profile, resource capsules, title, animated arena preview, power inventory, primary/secondary actions, and bottom navigation use layered beveled neon frames rather than flat demo boxes.
- Every clickable item keeps the compressed press response with audio and restrained haptics.

## Gameplay performance

- The player paddle follows the finger position directly on pointer events instead of waiting for spring interpolation.
- Finger velocity is still measured and applied to the ball rebound angle.
- Swept collision physics runs at a bounded 120 Hz with a maximum of eight catch-up steps per rendered frame.
- Ball trail history is capped at ten samples and impact particle creation is rate-limited.
- Repeated wall/paddle audio and haptic calls are throttled to prevent player accumulation and device-side stalls.
- HUD synchronization is reduced to a stable cadence while score and important events still update immediately.
- Static arena rendering remains cached; recurring dynamic allocations were reduced.
- The 10-goal loss rule and real-player victory celebration remain active.

## Build

The included `.github/workflows/build-apk.yml` is WF6. It validates Build 11 safeguards, runs `flutter analyze` and tests, creates separate Bazaar/Myket release APKs, removes older PULSE ARENA artifacts, and uploads diagnostic logs on failure.
