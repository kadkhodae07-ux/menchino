# وضعیت تحویل 0.1.3

## انجام‌شده در سورس

- معماری ماژولار و Assembly Definition
- Scene Flow کامل فاز آفلاین
- Rule Engine و Board Mapping
- UI و World سه‌بعدی تولیدشونده از اجزای مستقل
- Save/Resume، Economy، Rewards، Missions، Profile، Shop و Settings
- تست‌های EditMode و Workflow Android
- لایسنس Unity تعبیه‌شده در `.unity-ci/Unity_lic.ulf` و بارگذاری امن آن در Workflow

## نیازمند اجرای بیرون از این محیط

- Import واقعی با Unity 2022.3.62f1
- رفع هر خطای احتمالی Package/Compiler که فقط Unity گزارش می‌کند
- اجرای EditMode و PlayMode Tests
- Build و نصب APK روی ARM64
- بررسی فارسی، Safe Area و Layout روی چند نسبت نمایش
- Profiler و کنترل 60 FPS روی دستگاه واقعی
- جایگزینی صوت و Artwork پایه با Assetهای تولیدی نهایی برای رسیدن به برابری کامل هنری با تصاویر مرجع
- امضای Release با keystore مالک پروژه
