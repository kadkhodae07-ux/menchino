# Unity CI credentials

This private project intentionally stores the Unity license and account credentials inside `.unity-ci/` for GitHub Actions activation. Keep the repository private and rotate the Unity account password after the build workflow is confirmed.
