import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('production hub is coded, graphical, and pressable', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();
    final String panel =
        File('lib/core/design/pulse_panel.dart').readAsStringSync();
    final String pressable =
        File('lib/widgets/neon_pressable.dart').readAsStringSync();

    expect(hub, contains('class HubScreen'));
    expect(hub, contains('_HomeStage'));
    expect(panel, contains('class PulsePanelPainter'));
    expect(hub, contains('_ArenaPreviewPainter'));
    expect(hub, contains('_ActionButtonPainter'));
    expect(hub, contains('BoxConstraints(maxWidth: 430)'));
    expect(hub, contains('SingleChildScrollView'));
    expect(hub, contains('Alignment.topCenter'));
    expect(hub, contains('PULSE ARENA'));
    expect(hub, contains('انتخاب حالت نبرد'));
    expect(hub, contains('شروع سریع'));
    expect(hub, contains('تنظیمات'));
    expect(hub, contains('ماموریت‌ها'));
    expect(hub, contains('رتبه‌بندی'));
    expect(pressable, contains('AnimatedScale'));
    expect(pressable, contains('pressedScale = 0.96'));
    expect(hub, contains('MaskFilter.blur'));
  });

  test('home and game use separate production orientations', () {
    final String orientation =
        File('lib/core/orientation_manager.dart').readAsStringSync();
    final String manifest =
        File('android/app/src/main/AndroidManifest.xml').readAsStringSync();

    expect(orientation, contains('DeviceOrientation.portraitUp'));
    expect(orientation, contains('DeviceOrientation.landscapeLeft'));
    expect(orientation, contains('DeviceOrientation.landscapeRight'));
    expect(manifest, contains('android:screenOrientation="unspecified"'));
  });

  test('real-player victory has a dedicated professional celebration', () {
    final String gameScreen =
        File('lib/screens/game_screen.dart').readAsStringSync();
    final String game =
        File('lib/game/pulse_arena_game.dart').readAsStringSync();
    final String arena =
        File('lib/game/components/arena_component.dart').readAsStringSync();

    expect(gameScreen, contains('_VictoryFxPainter'));
    expect(gameScreen, contains("'پیروزی'"));
    expect(game, contains('arenaComponent.triggerVictory()'));
    expect(arena, contains('void triggerVictory()'));
    expect(arena, contains('_drawVictoryGlow'));
  });
}
