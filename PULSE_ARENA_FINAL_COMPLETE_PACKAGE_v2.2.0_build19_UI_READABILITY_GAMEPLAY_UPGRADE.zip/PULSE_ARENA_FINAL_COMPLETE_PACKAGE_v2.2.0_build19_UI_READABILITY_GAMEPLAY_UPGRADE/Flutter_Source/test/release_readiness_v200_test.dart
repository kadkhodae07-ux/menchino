import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

String _read(String path) => File(path).readAsStringSync();

bool _usesConstructor(String source, String constructor) {
  final RegExp pattern = RegExp(
    '(^|[^A-Za-z0-9_])${RegExp.escape(constructor)}\\(',
    multiLine: true,
  );
  return pattern.hasMatch(source);
}

String _hubLibrary() {
  final StringBuffer source = StringBuffer(_read('lib/screens/hub_screen.dart'));
  for (final FileSystemEntity entity in Directory('lib/screens/hub')
      .listSync()
      .where((FileSystemEntity entity) => entity.path.endsWith('.dart'))) {
    source.write((entity as File).readAsStringSync());
  }
  return source.toString();
}

void main() {
  test('release identity and both Android store flavors are preserved', () {
    final String pubspec = _read('pubspec.yaml');
    final String gradle = _read('android/app/build.gradle.kts');

    expect(pubspec, contains('version: 2.2.0+19'));
    expect(gradle, contains('namespace = "com.manyshah.pulsearena"'));
    expect(gradle, contains('applicationId = "com.manyshah.pulsearena"'));
    expect(gradle, contains('create("bazaar")'));
    expect(gradle, contains('create("myket")'));
  });

  test('all production UI uses reusable graphical components', () {
    final String hub = _hubLibrary();
    final String gameScreen = _read('lib/screens/game_screen.dart');
    final String modeSelection = _read('lib/screens/mode_selection_screen.dart');
    final String productionUi = '$hub\n$gameScreen\n$modeSelection';
    final String panel = _read('lib/core/design/pulse_panel.dart');
    final String progress = _read('lib/core/design/pulse_progress.dart');

    expect(productionUi, contains('PulsePanel('));
    expect(productionUi, contains('PulseProgress('));
    expect(panel, contains('class PulsePanelPainter'));
    expect(progress, contains('class PulseProgressPainter'));
    for (final String control in <String>[
      'Card',
      'ElevatedButton',
      'FilledButton',
      'OutlinedButton',
      'TextButton',
      'IconButton',
      'LinearProgressIndicator',
      'CircularProgressIndicator',
      'Switch',
      'Slider',
      'InkWell',
    ]) {
      expect(
        _usesConstructor(productionUi, control),
        isFalse,
        reason: '$control(',
      );
    }
  });

  test('real mode selection never exposes a fake online mode', () {
    final String selection = _read('lib/screens/mode_selection_screen.dart');
    final String config = _read('lib/game/config/game_config.dart');
    final String gameScreen = _read('lib/screens/game_screen.dart');

    expect(selection, contains('نبرد آفلاین'));
    expect(selection, contains('تمرین آزاد'));
    expect(selection, contains('حالت آنلاین فقط پس از اتصال به زیرساخت واقعی اضافه می‌شود'));
    expect(config, contains('enum GameMode { offline, training }'));
    expect(config, contains('trackProgress: false'));
    expect(gameScreen, contains('if (!widget.config.trackProgress) return;'));
  });

  test('local progression, daily rewards, and settings are durable', () {
    final String hub = _hubLibrary();
    final String controller = _read('lib/player/player_progress_controller.dart');
    final String activity = _read(
      'android/app/src/main/kotlin/com/manyshah/pulsearena/MainActivity.kt',
    );

    expect(hub, contains('رتبه‌بندی آفلاین'));
    expect(hub, contains('هسته‌های هوش مصنوعی بازی هستند، نه کاربران ساختگی'));
    for (final String token in <String>[
      'dailyMissionCycle',
      'weeklyMissionCycle',
      'claimedMissions',
      'purchasedItems',
      'selectedItems',
      'recentMatches',
      'lastDailyRewardDate',
      'dailyRewardStreak',
      'soundVolume',
      'musicVolume',
    ]) {
      expect(controller, contains(token));
    }
    expect(hub, contains('آخرین نبردها'));
    expect(activity, contains('getSharedPreferences'));
  });

  test('selected loadout and effect quality reach real match rendering', () {
    final String game = _read('lib/game/pulse_arena_game.dart');
    final String paddle = _read('lib/game/components/player_paddle_controller.dart');
    final String ball = _read('lib/game/components/ball_controller.dart');

    expect(game, contains('_paddlePalette'));
    expect(game, contains('_ballPalette'));
    expect(game, contains('_effectPalette'));
    expect(
      game,
      contains(
        'final PlayerProgressController progress = PlayerProgressController.instance',
      ),
    );
    expect(game, contains("progress.selectedItems['paddle']"));
    expect(game, contains("progress.selectedItems['ball']"));
    expect(game, contains("progress.selectedItems['effect']"));
    expect(paddle, contains('accentColor'));
    expect(ball, contains('effectQuality'));
    expect(ball, contains('trailLimit'));
  });

  test('branding assets and launch screen are production-owned', () {
    expect(File('assets/branding/pulse_arena_icon_1024.png').existsSync(), isTrue);
    expect(File('assets/branding/pulse_arena_splash_mark.png').existsSync(), isTrue);
    expect(
      _read('android/app/src/main/res/drawable/launch_background.xml'),
      contains('@drawable/splash_mark'),
    );
  });
}
