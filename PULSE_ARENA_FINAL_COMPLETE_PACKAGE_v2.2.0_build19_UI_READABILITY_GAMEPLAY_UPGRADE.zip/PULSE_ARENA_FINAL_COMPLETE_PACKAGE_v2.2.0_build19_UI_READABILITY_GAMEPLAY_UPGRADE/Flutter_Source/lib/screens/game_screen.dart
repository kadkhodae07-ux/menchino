import 'dart:math' as math;

import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../core/design/pulse_panel.dart';
import '../core/design/pulse_tokens.dart';
import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../game/models/game_view_state.dart';
import '../game/pulse_arena_game.dart';
import '../player/player_progress_controller.dart';
import '../widgets/neon_pressable.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, this.config = const GameConfig()});

  final GameConfig config;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final PulseArenaGame game;
  bool _recordedResult = false;

  @override
  void initState() {
    super.initState();
    game = PulseArenaGame(config: widget.config);
    game.viewState.addListener(_handleGameState);
  }

  void _handleGameState() {
    final GameViewState state = game.viewState.value;
    if (state.phase != MatchPhase.finished) {
      if (state.playerScore == 0 && state.botScore == 0) {
        _recordedResult = false;
      }
      return;
    }
    if (_recordedResult || state.winner == null) return;
    _recordedResult = true;
    if (!widget.config.trackProgress) return;
    PlayerProgressController.instance.recordMatch(
      won: state.winner == MatchWinner.player,
      playerScore: state.playerScore,
      botScore: state.botScore,
      matchPerfectHits: state.perfectHits,
      matchPowersUsed: state.powersUsed,
    );
  }

  @override
  void dispose() {
    game.viewState.removeListener(_handleGameState);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Widget gameLayer = _GameInput(game: game);
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          game.pauseMatch();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF02040A),
        body: SafeArea(
          minimum: const EdgeInsets.all(2),
          child: ValueListenableBuilder<GameViewState>(
            valueListenable: game.viewState,
            child: gameLayer,
            builder: (BuildContext context, GameViewState state, Widget? child) {
              return LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) {
                  final bool compact = constraints.maxHeight < 390 || constraints.maxWidth < 760;
                  return Stack(
                    fit: StackFit.expand,
                    children: <Widget>[
                      child!,
                      _Hud(state: state, compact: compact, onPause: game.pauseMatch),
                      _PowerDock(state: state, compact: compact, onActivate: game.activatePower),
                      if (state.phase == MatchPhase.playing && state.eventText.isNotEmpty)
                        _EventToast(text: state.eventText, compact: compact),
                      if (state.phase == MatchPhase.playing && state.showControlHint)
                        _ControlHint(compact: compact),
                      if (state.phase == MatchPhase.countdown)
                        state.openingSequence
                            ? _MatchIntro(state: state, compact: compact)
                            : _PointTransition(state: state, compact: compact),
                      if (state.phase == MatchPhase.paused)
                        _PausePanel(
                          state: state,
                          onResume: game.resumeMatch,
                          onRestart: game.restartMatch,
                          onHome: () => SceneTransitionManager.openHome(context),
                          onToggleSound: game.toggleSound,
                          onToggleVibration: game.toggleVibration,
                        ),
                      if (state.phase == MatchPhase.finished)
                        _EndPanel(
                          state: state,
                          config: widget.config,
                          onReplay: game.restartMatch,
                          onHome: () => SceneTransitionManager.openHome(context),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}

class _GameInput extends StatelessWidget {
  const _GameInput({required this.game});
  final PulseArenaGame game;

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (PointerDownEvent event) => game.handleTouch(
        event.localPosition.dy,
        eventMicros: event.timeStamp.inMicroseconds,
      ),
      onPointerMove: (PointerMoveEvent event) => game.handleTouch(
        event.localPosition.dy,
        eventMicros: event.timeStamp.inMicroseconds,
      ),
      onPointerUp: (_) => game.endTouch(),
      onPointerCancel: (_) => game.endTouch(),
      child: RepaintBoundary(
        child: GameWidget<PulseArenaGame>(
          game: game,
          loadingBuilder: (_) => const ColoredBox(color: Color(0xFF030812)),
        ),
      ),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({required this.state, required this.compact, required this.onPause});
  final GameViewState state;
  final bool compact;
  final VoidCallback onPause;

  String get _time {
    final int total = state.elapsedSeconds.floor();
    final int minutes = total ~/ 60;
    final int seconds = total % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: compact ? 15 : 25,
      right: compact ? 15 : 25,
      top: compact ? 10 : 14,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: _FighterPlate(
                name: 'شما',
                subtitle: 'فرمانده پالس',
                score: state.playerScore,
                targetScore: state.targetScore,
                color: PulseColors.cyan,
                player: true,
                compact: compact,
              ),
            ),
          ),
          _CenterStatus(
            time: _time,
            rally: state.currentRally,
            targetScore: state.targetScore,
            compact: compact,
          ),
          Expanded(
            child: Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  _FighterPlate(
                    name: 'نوا',
                    subtitle: state.difficulty.title,
                    score: state.botScore,
                    targetScore: state.targetScore,
                    color: PulseColors.rose,
                    player: false,
                    compact: compact,
                  ),
                  SizedBox(width: compact ? 6 : 9),
                  _PauseButton(onTap: onPause, compact: compact),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FighterPlate extends StatelessWidget {
  const _FighterPlate({
    required this.name,
    required this.subtitle,
    required this.score,
    required this.targetScore,
    required this.color,
    required this.player,
    required this.compact,
  });

  final String name;
  final String subtitle;
  final int score;
  final int targetScore;
  final Color color;
  final bool player;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final Widget identity = Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        _PilotCore(color: color, player: player, size: compact ? 31 : 38),
        SizedBox(width: compact ? 7 : 10),
        if (!compact)
          Column(
            crossAxisAlignment: player ? CrossAxisAlignment.start : CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(name, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
              Text(subtitle, textDirection: TextDirection.rtl, style: TextStyle(color: color.withValues(alpha: 0.8), fontSize: 9, fontWeight: FontWeight.w700)),
            ],
          ),
      ],
    );

    return Container(
      height: compact ? 51 : 63,
      width: compact ? 128 : 210,
      padding: EdgeInsets.fromLTRB(compact ? 8 : 12, compact ? 4 : 5, compact ? 8 : 12, 5),
      decoration: BoxDecoration(
        color: const Color(0xEE08101F),
        borderRadius: BorderRadius.circular(compact ? 15 : 19),
        border: Border.all(color: color.withValues(alpha: 0.72), width: 1.15),
      ),
      child: Column(
        children: <Widget>[
          Expanded(
            child: Row(
              children: player
                  ? <Widget>[identity, const Spacer(), _ScoreNumber(value: score, color: color, compact: compact)]
                  : <Widget>[_ScoreNumber(value: score, color: color, compact: compact), const Spacer(), identity],
            ),
          ),
          Row(
            children: List<Widget>.generate(targetScore, (int index) {
              final bool filled = index < score;
              return Expanded(
                child: Container(
                  height: compact ? 2.6 : 3.2,
                  margin: EdgeInsetsDirectional.only(end: index == targetScore - 1 ? 0 : 2),
                  decoration: BoxDecoration(
                    color: filled ? color : const Color(0xFF202B40),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _PilotCore extends StatelessWidget {
  const _PilotCore({required this.color, required this.player, required this.size});
  final Color color;
  final bool player;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(center: const Alignment(-0.3, -0.35), colors: <Color>[Colors.white, color, color.withValues(alpha: 0.28)]),
        border: Border.all(color: Colors.white.withValues(alpha: 0.68), width: 1.4),
        boxShadow: <BoxShadow>[BoxShadow(color: color.withValues(alpha: 0.52), blurRadius: 12)],
      ),
      child: Icon(player ? Icons.person_rounded : Icons.smart_toy_rounded, size: size * 0.55, color: const Color(0xFF07101E)),
    );
  }
}

class _ScoreNumber extends StatelessWidget {
  const _ScoreNumber({required this.value, required this.color, required this.compact});
  final int value;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 220),
      transitionBuilder: (Widget child, Animation<double> animation) => ScaleTransition(scale: animation, child: FadeTransition(opacity: animation, child: child)),
      child: Text(
        '$value',
        key: ValueKey<int>(value),
        style: TextStyle(color: Colors.white, fontSize: compact ? 25 : 34, fontWeight: FontWeight.w900, height: 1, shadows: <Shadow>[Shadow(color: color, blurRadius: 15)]),
      ),
    );
  }
}

class _CenterStatus extends StatelessWidget {
  const _CenterStatus({required this.time, required this.rally, required this.targetScore, required this.compact});
  final String time;
  final int rally;
  final int targetScore;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: compact ? 43 : 54,
      margin: EdgeInsets.symmetric(horizontal: compact ? 7 : 14),
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 15),
      decoration: BoxDecoration(
        color: const Color(0xD40A1020),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0x777B7CFF), width: 1.1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(time, style: TextStyle(fontSize: compact ? 14 : 17, fontWeight: FontWeight.w900, letterSpacing: 1.7)),
              if (!compact) Text('هرکس $targetScore گل بخورد بازنده است', textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 8, color: Color(0xFFA8B5D8), fontWeight: FontWeight.w700)),
            ],
          ),
          if (rally >= 2) ...<Widget>[
            SizedBox(width: compact ? 7 : 10),
            Container(width: 1, height: compact ? 23 : 30, color: const Color(0x335E6E96)),
            SizedBox(width: compact ? 7 : 10),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text('$rally', style: TextStyle(fontSize: compact ? 14 : 17, color: const Color(0xFFFFD36A), fontWeight: FontWeight.w900)),
                if (!compact) const Text('رالی', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 8, color: Color(0xFFFFDFA0), fontWeight: FontWeight.w700)),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _PauseButton extends StatelessWidget {
  const _PauseButton({required this.onTap, required this.compact});
  final VoidCallback onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: compact ? 42 : 48,
      height: compact ? 42 : 48,
      child: NeonPressable(
        semanticLabel: 'توقف مسابقه',
        onTap: onTap,
        builder: (_, bool pressed) {
          return PulsePanel(
            colors: const <Color>[PulseColors.blue, PulseColors.violet],
            cut: 13,
            pressed: pressed,
            padding: EdgeInsets.zero,
            child: Center(
              child: Icon(
                Icons.pause_rounded,
                size: compact ? 22 : 26,
                color: PulseColors.textPrimary,
              ),
            ),
          );
        },
      ),
    );
  }
}

class _PowerDock extends StatelessWidget {
  const _PowerDock({required this.state, required this.compact, required this.onActivate});
  final GameViewState state;
  final bool compact;
  final bool Function(PowerType type) onActivate;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 0,
      right: 0,
      bottom: compact ? 9 : 13,
      child: Center(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 7 : 11, vertical: compact ? 5 : 7),
          decoration: BoxDecoration(
            color: const Color(0xEE080E1B),
            borderRadius: BorderRadius.circular(compact ? 18 : 23),
            border: Border.all(color: const Color(0x665E7197)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              _PowerButton(
                title: 'سپر',
                icon: Icons.shield_rounded,
                count: state.shieldUses,
                active: state.shieldActive,
                progress: state.shieldProgress,
                color: const Color(0xFF27DFFF),
                compact: compact,
                enabled: state.phase == MatchPhase.playing && state.shieldUses > 0 && !state.shieldActive,
                onTap: () => onActivate(PowerType.shield),
              ),
              _DockDivider(compact: compact),
              _PowerButton(
                title: 'شتاب',
                icon: Icons.bolt_rounded,
                count: state.boostUses,
                active: state.boostArmed,
                progress: state.boostArmed ? 1 : 0,
                color: const Color(0xFFFFB347),
                compact: compact,
                enabled: state.phase == MatchPhase.playing && state.boostUses > 0 && !state.boostArmed,
                onTap: () => onActivate(PowerType.boost),
              ),
              _DockDivider(compact: compact),
              _PowerButton(
                title: 'پالس',
                icon: Icons.graphic_eq_rounded,
                count: state.pulseUses,
                active: state.pulseActive,
                progress: state.pulseProgress,
                color: const Color(0xFFB66CFF),
                compact: compact,
                enabled: state.phase == MatchPhase.playing && state.pulseUses > 0 && !state.pulseActive,
                onTap: () => onActivate(PowerType.pulse),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DockDivider extends StatelessWidget {
  const _DockDivider({required this.compact});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: compact ? 30 : 39, margin: EdgeInsets.symmetric(horizontal: compact ? 3 : 6), color: const Color(0x335E6E96));
  }
}

class _PowerButton extends StatefulWidget {
  const _PowerButton({
    required this.title,
    required this.icon,
    required this.count,
    required this.active,
    required this.progress,
    required this.color,
    required this.compact,
    required this.enabled,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final int count;
  final bool active;
  final double progress;
  final Color color;
  final bool compact;
  final bool enabled;
  final VoidCallback onTap;

  @override
  State<_PowerButton> createState() => _PowerButtonState();
}

class _PowerButtonState extends State<_PowerButton> {
  bool pressed = false;

  @override
  Widget build(BuildContext context) {
    final double opacity = widget.enabled || widget.active ? 1 : 0.34;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.enabled ? (_) => setState(() => pressed = true) : null,
      onTapCancel: widget.enabled ? () => setState(() => pressed = false) : null,
      onTapUp: widget.enabled
          ? (_) {
              setState(() => pressed = false);
              widget.onTap();
            }
          : null,
      child: AnimatedScale(
        scale: pressed ? 0.92 : 1,
        duration: const Duration(milliseconds: 90),
        child: AnimatedOpacity(
          opacity: opacity,
          duration: const Duration(milliseconds: 160),
          child: SizedBox(
            width: widget.compact ? 77 : 108,
            height: widget.compact ? 39 : 49,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  width: widget.compact ? 31 : 37,
                  height: widget.compact ? 31 : 37,
                  child: Stack(
                    fit: StackFit.expand,
                    children: <Widget>[
                      if (widget.active)
                        RepaintBoundary(
                          child: CustomPaint(
                            painter: _PowerRingPainter(
                              progress: widget.progress,
                              color: widget.color,
                            ),
                          ),
                        ),
                      Container(
                        margin: EdgeInsets.all(widget.active ? 4 : 0),
                        decoration: BoxDecoration(shape: BoxShape.circle, color: widget.color.withValues(alpha: widget.active ? 0.28 : 0.12), border: Border.all(color: widget.color.withValues(alpha: 0.75))),
                        child: Icon(widget.icon, color: widget.color, size: widget.compact ? 17 : 21),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: widget.compact ? 5 : 7),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(widget.title, textDirection: TextDirection.rtl, style: TextStyle(fontSize: widget.compact ? 10 : 11.5, fontWeight: FontWeight.w900)),
                    Text(widget.active ? 'فعال' : '×${widget.count}', textDirection: TextDirection.rtl, style: TextStyle(fontSize: widget.compact ? 9 : 10, color: widget.color, fontWeight: FontWeight.w800)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PowerRingPainter extends CustomPainter {
  const _PowerRingPainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    final double radius = math.max(0.0, size.shortestSide / 2 - 1.5);
    final Rect arc = Rect.fromCircle(center: center, radius: radius);
    final Paint track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..color = color.withValues(alpha: .14);
    final Paint fill = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        colors: <Color>[color.withValues(alpha: .52), color],
        transform: const GradientRotation(-math.pi / 2),
      ).createShader(arc);
    canvas.drawCircle(center, radius, track);
    canvas.drawArc(
      arc,
      -math.pi / 2,
      math.pi * 2 * progress.clamp(0.0, 1.0).toDouble(),
      false,
      fill,
    );
  }

  @override
  bool shouldRepaint(covariant _PowerRingPainter oldDelegate) {
    return oldDelegate.progress != progress || oldDelegate.color != color;
  }
}

class _MatchIntro extends StatelessWidget {
  const _MatchIntro({required this.state, required this.compact});
  final GameViewState state;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final double progress = state.countdownTotal <= 0 ? 1 : (1 - state.countdownRemaining / state.countdownTotal).clamp(0.0, 1.0).toDouble();
    final bool ready = progress < 0.14;
    final String centerText = ready ? 'آماده' : '${state.countdown}';

    return IgnorePointer(
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          ColoredBox(color: Color.lerp(const Color(0xD601040B), const Color(0x6501040B), progress)!),
          CustomPaint(painter: _IntroEnergyPainter(progress: progress)),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    _IntroFighter(label: 'شما', caption: 'فرمانده پالس', color: PulseColors.cyan, player: true, compact: compact),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: compact ? 20 : 32),
                      child: Column(
                        children: <Widget>[
                          const Icon(Icons.bolt_rounded, color: Color(0xFFC7D2F0), size: 22),
                          Text('${state.targetScore} گل تا شکست', textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFFAEBBD4), fontSize: 9, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    _IntroFighter(label: 'نوا', caption: state.difficulty.title, color: PulseColors.rose, player: false, compact: compact),
                  ],
                ),
                SizedBox(height: compact ? 14 : 21),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 170),
                  transitionBuilder: (Widget child, Animation<double> animation) {
                    final Animation<double> scale = Tween<double>(begin: 1.45, end: 1).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutBack));
                    return FadeTransition(opacity: animation, child: ScaleTransition(scale: scale, child: child));
                  },
                  child: Text(
                    centerText,
                    key: ValueKey<String>(centerText),
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: ready ? (compact ? 26 : 34) : (compact ? 58 : 76),
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      shadows: const <Shadow>[Shadow(color: Color(0x8845C7D8), blurRadius: 10)],
                    ),
                  ),
                ),
                if (ready) ...<Widget>[
                  const SizedBox(height: 5),
                  Text('نبرد آفلاین • سطح ${state.difficulty.title}', textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 10, color: Color(0xFFB8C6DF), fontWeight: FontWeight.w700)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _IntroFighter extends StatelessWidget {
  const _IntroFighter({required this.label, required this.caption, required this.color, required this.player, required this.compact});
  final String label;
  final String caption;
  final Color color;
  final bool player;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: compact ? 96 : 128,
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 14, vertical: compact ? 8 : 11),
      decoration: BoxDecoration(color: const Color(0xD10A1020), borderRadius: BorderRadius.circular(18), border: Border.all(color: color.withValues(alpha: 0.42)), boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withValues(alpha: 0.45), blurRadius: 14, offset: const Offset(0, 5))]),
      child: Column(
        children: <Widget>[
          _PilotCore(color: color, player: player, size: compact ? 32 : 42),
          SizedBox(height: compact ? 5 : 7),
          Text(label, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
          if (!compact) Text(caption, textDirection: TextDirection.rtl, style: TextStyle(fontSize: 8.5, color: color, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _IntroEnergyPainter extends CustomPainter {
  const _IntroEnergyPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = size.center(Offset.zero);
    final double base = size.height * 0.18;
    for (int i = 0; i < 3; i++) {
      final double radius = base + i * size.height * 0.065;
      final double direction = i.isEven ? 1 : -1;
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: radius),
        progress * math.pi * 2.2 * direction + i,
        math.pi * (0.27 + i * 0.08),
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 2.8 : 1.4
          ..strokeCap = StrokeCap.round
          ..color = (i.isEven ? const Color(0xFF55C7D7) : PulseColors.rose).withValues(alpha: 0.35),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _IntroEnergyPainter oldDelegate) => oldDelegate.progress != progress;
}

class _PointTransition extends StatelessWidget {
  const _PointTransition({required this.state, required this.compact});
  final GameViewState state;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final double progress = state.countdownTotal <= 0 ? 1 : (1 - state.countdownRemaining / state.countdownTotal).clamp(0.0, 1.0).toDouble();
    final bool playerPoint = state.lastPointWinner == MatchWinner.player;
    final Color color = playerPoint ? const Color(0xFF55C7D7) : const Color(0xFFC96F93);
    final String serve = state.nextServer == MatchWinner.player ? 'سرویس شما' : 'سرویس نوا';
    return IgnorePointer(
      child: Center(
        child: Transform.scale(
          scale: 0.9 + math.sin(progress * math.pi) * 0.08,
          child: Opacity(
            opacity: math.sin(progress * math.pi).clamp(0.0, 1.0).toDouble(),
            child: Container(
              width: compact ? 210 : 260,
              padding: EdgeInsets.symmetric(horizontal: compact ? 16 : 20, vertical: compact ? 10 : 14),
              decoration: BoxDecoration(color: const Color(0xE10A1020), borderRadius: BorderRadius.circular(21), border: Border.all(color: color, width: 1.4), boxShadow: <BoxShadow>[BoxShadow(color: color.withValues(alpha: 0.34), blurRadius: 28)]),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(playerPoint ? Icons.add_circle_rounded : Icons.warning_amber_rounded, color: color, size: compact ? 25 : 31),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(state.eventText, textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 15 : 18, fontWeight: FontWeight.w900)),
                      Text(serve, textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 9 : 11, color: color, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _EventToast extends StatelessWidget {
  const _EventToast({required this.text, required this.compact});
  final String text;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: compact ? 59 : 79,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: Center(
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16, vertical: compact ? 5 : 7),
            decoration: BoxDecoration(color: const Color(0xC90A1020), borderRadius: BorderRadius.circular(13), border: Border.all(color: const Color(0x775DE5FF))),
            child: Text(text, textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 10 : 12, fontWeight: FontWeight.w800, color: const Color(0xFFEAFBFF))),
          ),
        ),
      ),
    );
  }
}

class _ControlHint extends StatelessWidget {
  const _ControlHint({required this.compact});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: compact ? 60 : 90,
      bottom: compact ? 58 : 75,
      child: IgnorePointer(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 9 : 12, vertical: compact ? 6 : 8),
          decoration: BoxDecoration(color: const Color(0xB50A1322), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0x6639E4FF))),
          child: Row(
            children: <Widget>[
              const Icon(Icons.swipe_vertical_rounded, color: Color(0xFF62E7FF), size: 20),
              const SizedBox(width: 7),
              Text('برای حرکت راکت، انگشت را بالا و پایین بکشید', textDirection: TextDirection.rtl, style: TextStyle(fontSize: compact ? 9 : 11, fontWeight: FontWeight.w700, color: const Color(0xFFD4EAF5))),
            ],
          ),
        ),
      ),
    );
  }
}

class _PausePanel extends StatelessWidget {
  const _PausePanel({required this.state, required this.onResume, required this.onRestart, required this.onHome, required this.onToggleSound, required this.onToggleVibration});
  final GameViewState state;
  final VoidCallback onResume;
  final VoidCallback onRestart;
  final VoidCallback onHome;
  final VoidCallback onToggleSound;
  final VoidCallback onToggleVibration;

  @override
  Widget build(BuildContext context) {
    return _OverlayPanel(
      glow: const Color(0xFF60D7D2),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const _PanelTitle(icon: Icons.pause_circle_filled_rounded, title: 'مسابقه متوقف شد', subtitle: 'پیشرفت فعلی حفظ شده است', color: Color(0xFF7DE0DB)),
          const SizedBox(height: 15),
          _MenuButton(text: 'ادامه مسابقه', icon: Icons.play_arrow_rounded, primary: true, onTap: onResume),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(child: _MenuButton(text: 'شروع مجدد', icon: Icons.refresh_rounded, onTap: onRestart, compact: true)),
              const SizedBox(width: 8),
              Expanded(child: _MenuButton(text: 'بازگشت به منو', icon: Icons.home_rounded, onTap: onHome, compact: true)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              _ToggleButton(icon: state.soundEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded, label: 'صدا', enabled: state.soundEnabled, onTap: onToggleSound),
              const SizedBox(width: 10),
              _ToggleButton(icon: state.vibrationEnabled ? Icons.vibration_rounded : Icons.mobile_off_rounded, label: 'لرزش', enabled: state.vibrationEnabled, onTap: onToggleVibration),
            ],
          ),
        ],
      ),
    );
  }
}

class _EndPanel extends StatefulWidget {
  const _EndPanel({
    required this.state,
    required this.config,
    required this.onReplay,
    required this.onHome,
  });

  final GameViewState state;
  final GameConfig config;
  final VoidCallback onReplay;
  final VoidCallback onHome;

  @override
  State<_EndPanel> createState() => _EndPanelState();
}

class _EndPanelState extends State<_EndPanel> with TickerProviderStateMixin {
  late final AnimationController _ambientController;
  late final AnimationController _entranceController;

  @override
  void initState() {
    super.initState();
    _ambientController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 560),
    );
    if (widget.state.winner == MatchWinner.player) {
      _ambientController.repeat();
      _entranceController.forward();
    } else {
      _ambientController.value = 0;
      _entranceController.value = 1;
    }
  }

  @override
  void dispose() {
    _ambientController.dispose();
    _entranceController.dispose();
    super.dispose();
  }

  String get _duration {
    final int total = widget.state.elapsedSeconds.floor();
    return '${(total ~/ 60).toString().padLeft(2, '0')}:${(total % 60).toString().padLeft(2, '0')}';
  }

  String get _advice {
    if (widget.state.winner == MatchWinner.player) {
      return 'کنترل دقیق راکت و زمان‌بندی قدرت‌ها، نتیجه نبرد را تعیین کرد.';
    }
    if (widget.state.perfectHits == 0) {
      return 'توپ را نزدیک مرکز راکت بزن تا زاویه برگشت قابل‌کنترل‌تر شود.';
    }
    if (widget.state.powersUsed == 0) {
      return 'در فشارهای طولانی از سپر و پالس استفاده کن.';
    }
    return 'در رالی‌های سریع، راکت را کمی زودتر در مسیر توپ قرار بده.';
  }

  Widget _rewardChip({required IconData icon, required String value, required Color color}) {
    return Expanded(
      child: Container(
        height: 34,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .09),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: .28)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: color, size: 17),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                value,
                textDirection: TextDirection.rtl,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: PulseColors.textPrimary,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _resultContent({required bool won, required Color color}) {
    final GameViewState state = widget.state;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withValues(alpha: .13),
                border: Border.all(color: color.withValues(alpha: .50)),
              ),
              child: Icon(
                won ? Icons.emoji_events_rounded : Icons.sports_esports_rounded,
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  won ? 'پیروزی' : 'پایان نبرد',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: PulseColors.textPrimary,
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  won ? 'نبرد آرنا با موفقیت تمام شد' : 'این بار نوا برنده شد',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: color,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: const Color(0xB908111B),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: color.withValues(alpha: .34)),
          ),
          child: Row(
            children: <Widget>[
              const Expanded(
                child: Text(
                  'فرمانده',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: PulseColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ),
              Text(
                '${state.playerScore}  —  ${state.botScore}',
                style: const TextStyle(
                  color: PulseColors.textPrimary,
                  fontSize: 23,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const Expanded(
                child: Text(
                  'نوا',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: PulseColors.textSecondary, fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: <Widget>[
            Expanded(child: _StatTile(icon: Icons.timer_outlined, value: _duration, label: 'زمان')),
            const SizedBox(width: 7),
            Expanded(child: _StatTile(icon: Icons.sync_alt_rounded, value: '${state.longestRally}', label: 'بهترین رالی')),
            const SizedBox(width: 7),
            Expanded(child: _StatTile(icon: Icons.gps_fixed_rounded, value: '${state.perfectHits}', label: 'ضربه دقیق')),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: color.withValues(alpha: .07),
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: color.withValues(alpha: .18)),
          ),
          child: Row(
            children: <Widget>[
              Icon(won ? Icons.military_tech_outlined : Icons.tips_and_updates_outlined, color: color, size: 19),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  '$_advice  •  قدرت مصرفی: ${state.powersUsed}',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: PulseColors.textSecondary,
                    fontSize: 9.8,
                    fontWeight: FontWeight.w500,
                    height: 1.35,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        if (widget.config.trackProgress)
          Row(
            children: <Widget>[
              _rewardChip(
                icon: Icons.motion_photos_on_rounded,
                value: won ? '+۱۲۰ پالس' : '+۴۵ پالس',
                color: PulseColors.rose,
              ),
              const SizedBox(width: 6),
              _rewardChip(
                icon: Icons.auto_awesome_rounded,
                value: won ? '+۱۸۰ XP' : '+۷۰ XP',
                color: PulseColors.cyan,
              ),
              const SizedBox(width: 6),
              _rewardChip(
                icon: Icons.workspace_premium_outlined,
                value: won ? '+۴۲ لیگ' : '۱۸- لیگ',
                color: PulseColors.gold,
              ),
            ],
          )
        else
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: PulseColors.cyan.withValues(alpha: .07),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Text(
              'تمرین آزاد؛ آمار رقابتی و موجودی تغییری نکرد',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(color: PulseColors.textSecondary, fontSize: 10.5, fontWeight: FontWeight.w600),
            ),
          ),
      ],
    );
  }

  Widget _actions() {
    return Row(
      children: <Widget>[
        Expanded(
          child: _MenuButton(
            text: widget.config.mode == GameMode.training ? 'تمرین دوباره' : 'مسابقه دوباره',
            icon: Icons.replay_rounded,
            primary: true,
            onTap: widget.onReplay,
            compact: true,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _MenuButton(
            text: 'بازگشت به منو',
            icon: Icons.home_rounded,
            onTap: widget.onHome,
            compact: true,
          ),
        ),
      ],
    );
  }

  Widget _panel({required bool won, required Color color, required Size screen}) {
    final double width = math.min(580.0, screen.width * .74);
    final double height = math.min(390.0, screen.height * .80);
    return SizedBox(
      width: width,
      height: height,
      child: PulsePanel(
        colors: <Color>[color, color],
        cut: 15,
        intensity: .42,
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
        child: Column(
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: _resultContent(won: won, color: color),
              ),
            ),
            const SizedBox(height: 8),
            _actions(),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool won = widget.state.winner == MatchWinner.player;
    final Color color = won ? PulseColors.cyan : PulseColors.rose;
    final Size screen = MediaQuery.sizeOf(context);

    return ColoredBox(
      color: const Color(0xE7000208),
      child: SafeArea(
        minimum: const EdgeInsets.fromLTRB(18, 22, 18, 14),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            if (won)
              IgnorePointer(
                child: AnimatedBuilder(
                  animation: _ambientController,
                  builder: (_, __) => CustomPaint(
                    painter: _VictoryFxPainter(progress: _ambientController.value),
                  ),
                ),
              ),
            Center(
              child: AnimatedBuilder(
                animation: _entranceController,
                builder: (_, Widget? child) {
                  final double entrance = Curves.easeOutCubic.transform(_entranceController.value);
                  return Opacity(
                    opacity: entrance,
                    child: Transform.scale(scale: .96 + entrance * .04, child: child),
                  );
                },
                child: _panel(won: won, color: color, screen: screen),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VictoryFxPainter extends CustomPainter {
  const _VictoryFxPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    final double phase = progress * math.pi * 2;
    final double maxRadius = math.max(size.width, size.height) * 0.72;

    final Paint halo = Paint()
      ..shader = RadialGradient(
        colors: <Color>[
          Color.fromRGBO(70, 230, 255, 0.20 + math.sin(phase) * 0.035),
          const Color(0x143E63FF),
          const Color(0x00000000),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: maxRadius));
    canvas.drawRect(Offset.zero & size, halo);

    final Paint rayPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (int i = 0; i < 18; i++) {
      final double angle = phase * 0.12 + i * math.pi * 2 / 18;
      final double inner = 100.0 + (i % 3) * 13;
      final double outer = maxRadius * (0.58 + (i % 4) * 0.07);
      rayPaint
        ..strokeWidth = i.isEven ? 1.4 : 0.8
        ..color = i.isEven ? const Color(0x553DE7FF) : const Color(0x334F5EFF);
      canvas.drawLine(
        center + Offset(math.cos(angle) * inner, math.sin(angle) * inner),
        center + Offset(math.cos(angle) * outer, math.sin(angle) * outer),
        rayPaint,
      );
    }

    for (int i = 0; i < 34; i++) {
      final double seed = i * 0.61803398875;
      final double orbit = (progress * (0.35 + (i % 5) * 0.035) + seed) % 1;
      final double angle = orbit * math.pi * 2;
      final double radius = 88 + (i * 41 % 260).toDouble();
      final Offset point = center + Offset(math.cos(angle) * radius, math.sin(angle) * radius * 0.52);
      final double alpha = 0.25 + 0.55 * math.sin((orbit + seed) * math.pi).abs();
      canvas.drawCircle(
        point,
        1.1 + (i % 4) * 0.55,
        Paint()..color = i.isEven
            ? const Color(0xFF8FF4FF).withValues(alpha: alpha)
            : const Color(0xFFA77BFF).withValues(alpha: alpha),
      );
    }

    final double sweepY = size.height * ((progress * 1.35) % 1);
    final Rect sweepRect = Rect.fromLTWH(0, sweepY - 45, size.width, 90);
    canvas.drawRect(
      sweepRect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0x00000000), Color(0x203BE7FF), Color(0x00000000)],
        ).createShader(sweepRect),
    );
  }

  @override
  bool shouldRepaint(covariant _VictoryFxPainter oldDelegate) => oldDelegate.progress != progress;
}

class _StatTile extends StatelessWidget {
  const _StatTile({required this.icon, required this.value, required this.label});
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
      decoration: BoxDecoration(color: const Color(0xB308101A), borderRadius: BorderRadius.circular(9), border: Border.all(color: const Color(0x44364657)), boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x66000000), blurRadius: 8, offset: Offset(0, 3))]),
      child: Column(
        children: <Widget>[
          Icon(icon, size: 15, color: PulseColors.cyan),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
          Text(label, textDirection: TextDirection.rtl, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 8, color: Color(0xFFA8B5CB), fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _PanelTitle extends StatelessWidget {
  const _PanelTitle({required this.icon, required this.title, required this.subtitle, required this.color});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(icon, size: 38, color: color, shadows: <Shadow>[Shadow(color: color, blurRadius: 18)]),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(title, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            Text(subtitle, textDirection: TextDirection.rtl, style: TextStyle(fontSize: 9.5, color: color, fontWeight: FontWeight.w700)),
          ],
        ),
      ],
    );
  }
}

class _OverlayPanel extends StatelessWidget {
  const _OverlayPanel({required this.child, this.glow = const Color(0xFF7166B8), this.wide = false});
  final Widget child;
  final Color glow;
  final bool wide;

  @override
  Widget build(BuildContext context) {
    final Size screen = MediaQuery.sizeOf(context);
    return ColoredBox(
      color: const Color(0xD3000208),
      child: Center(
        child: SizedBox(
          width: math.min(wide ? 470.0 : 390.0, screen.width * 0.70),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: screen.height * 0.84),
            child: PulsePanel(
              colors: <Color>[glow, PulseColors.violet],
              cut: 19,
              intensity: .52,
              padding: const EdgeInsets.fromLTRB(16, 11, 16, 11),
              child: SingleChildScrollView(child: child),
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({required this.text, required this.icon, required this.onTap, this.primary = false, this.compact = false});
  final String text;
  final IconData icon;
  final VoidCallback onTap;
  final bool primary;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final List<Color> colors = primary
        ? const <Color>[PulseColors.cyan, PulseColors.blue]
        : const <Color>[PulseColors.violet, PulseColors.rose];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: SizedBox(
        width: compact ? null : 285,
        height: compact ? 43 : 47,
        child: NeonPressable(
          semanticLabel: text,
          onTap: () {
            AudioManager.instance.playButton();
            onTap();
          },
          builder: (_, bool pressed) {
            return PulsePanel(
              colors: colors,
              cut: 13,
              pressed: pressed,
              intensity: primary ? 1 : .68,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(icon, size: compact ? 19 : 21, color: colors.first),
                  const SizedBox(width: 7),
                  Flexible(
                    child: Text(
                      text,
                      textDirection: TextDirection.rtl,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: PulseColors.textPrimary,
                        fontSize: compact ? 12 : 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ToggleButton extends StatelessWidget {
  const _ToggleButton({required this.icon, required this.label, required this.enabled, required this.onTap});
  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = enabled ? PulseColors.cyan : PulseColors.textMuted;
    return SizedBox(
      width: 110,
      height: 38,
      child: NeonPressable(
        semanticLabel: label,
        onTap: onTap,
        builder: (_, bool pressed) {
          return PulsePanel(
            colors: <Color>[color, PulseColors.violet],
            cut: 12,
            pressed: pressed,
            intensity: enabled ? .78 : .35,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, color: color, size: 19),
                const SizedBox(width: 6),
                Text(
                  label,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
