part of '../hub_screen.dart';

class _ShopPage extends StatefulWidget {
  const _ShopPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  State<_ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<_ShopPage> {
  int _category = 0;

  static const List<({String label, String key, Color color})> _categories =
      <({String label, String key, Color color})>[
    (label: 'راکت‌ها', key: 'paddle', color: PulseColors.cyan),
    (label: 'توپ‌ها', key: 'ball', color: PulseColors.rose),
    (label: 'افکت‌ها', key: 'effect', color: PulseColors.violet),
  ];

  List<_ShopItemData> _itemsForCategory() {
    if (_category == 0) {
      return const <_ShopItemData>[
        _ShopItemData('paddle:nova', 'paddle', 'راکت نوا', 0, PulseColors.cyan, Icons.view_stream_rounded, 'پایه'),
        _ShopItemData('paddle:phantom', 'paddle', 'راکت فانتوم', 820, PulseColors.rose, Icons.blur_linear_rounded, 'کمیاب'),
        _ShopItemData('paddle:titan', 'paddle', 'راکت تایتان', 1100, PulseColors.gold, Icons.vertical_align_center_rounded, 'حماسی'),
        _ShopItemData('paddle:crystal', 'paddle', 'راکت کریستال', 1350, PulseColors.violet, Icons.diamond_rounded, 'افسانه‌ای'),
      ];
    }
    if (_category == 1) {
      return const <_ShopItemData>[
        _ShopItemData('ball:plasma', 'ball', 'گوی پلاسما', 0, PulseColors.cyan, Icons.circle_rounded, 'پایه'),
        _ShopItemData('ball:solar', 'ball', 'گوی خورشیدی', 760, PulseColors.gold, Icons.wb_sunny_rounded, 'کمیاب'),
        _ShopItemData('ball:shadow', 'ball', 'گوی سایه', 940, PulseColors.violet, Icons.blur_circular_rounded, 'حماسی'),
        _ShopItemData('ball:quantum', 'ball', 'گوی کوانتوم', 1250, PulseColors.rose, Icons.motion_photos_on_rounded, 'افسانه‌ای'),
      ];
    }
    return const <_ShopItemData>[
      _ShopItemData('effect:pulse_trail', 'effect', 'رد پالس', 0, PulseColors.cyan, Icons.timeline_rounded, 'پایه'),
      _ShopItemData('effect:neon_burst', 'effect', 'انفجار نئون', 690, PulseColors.rose, Icons.auto_awesome_rounded, 'کمیاب'),
      _ShopItemData('effect:gold_wave', 'effect', 'موج طلایی', 880, PulseColors.gold, Icons.waves_rounded, 'حماسی'),
      _ShopItemData('effect:space_rift', 'effect', 'شکاف فضایی', 1180, PulseColors.violet, Icons.blur_on_rounded, 'افسانه‌ای'),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final List<_ShopItemData> items = _itemsForCategory();
    final bool bundleOwned = const <String>[
      'paddle:phantom',
      'ball:quantum',
      'effect:neon_burst',
    ].every(widget.progress.purchasedItems.contains);

    return _PageScaffold(
      title: 'فروشگاه آرنا',
      subtitle: 'آیتم‌ها را بخر، تجهیز کن و روی همین دستگاه نگه دار',
      icon: Icons.shopping_cart_rounded,
      colors: const <Color>[PulseColors.rose, PulseColors.rose],
      children: <Widget>[
        _ShopWalletStrip(progress: widget.progress),
        const SizedBox(height: 10),
        PulsePanel(
          colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
          cut: 15,
          intensity: .38,
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Row(
            children: <Widget>[
              const SizedBox(
                width: 64,
                height: 64,
                child: CustomPaint(painter: _FeaturedItemPainter()),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          'بسته نئون دوگانه',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: PulseColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(width: 7),
                        Icon(Icons.auto_awesome_rounded, color: PulseColors.cyan, size: 18),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      bundleOwned
                          ? 'خریداری شده؛ برای تجهیز آماده است'
                          : 'راکت فانتوم، گوی کوانتوم و افکت انفجار نئون',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        color: PulseColors.textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 40,
                      child: _GraphicButton(
                        label: bundleOwned ? 'تجهیز بسته' : '۱٬۶۵۰ پالس',
                        icon: bundleOwned ? Icons.check_circle_rounded : Icons.shopping_bag_outlined,
                        colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
                        onTap: () {
                          final bool success = widget.progress.purchaseBundle(
                            const <String, String>{
                              'paddle': 'paddle:phantom',
                              'ball': 'ball:quantum',
                              'effect': 'effect:neon_burst',
                            },
                            1650,
                          );
                          widget.onMessage(
                            success
                                ? 'بسته نئون دوگانه تجهیز و ذخیره شد'
                                : 'برای خرید این بسته پالس کافی نیست',
                          );
                          setState(() {});
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            for (int i = 0; i < _categories.length; i++) ...<Widget>[
              Expanded(
                child: _SegmentButton(
                  label: _categories[i].label,
                  selected: _category == i,
                  color: _categories[i].color,
                  onTap: () => setState(() => _category = i),
                ),
              ),
              if (i != _categories.length - 1) const SizedBox(width: 7),
            ],
          ],
        ),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.02,
          ),
          itemBuilder: (BuildContext context, int index) {
            final _ShopItemData item = items[index];
            final bool owned = widget.progress.purchasedItems.contains(item.id);
            final bool equipped = widget.progress.selectedItems[item.category] == item.id;
            return _ShopItem(
              data: item,
              owned: owned,
              equipped: equipped,
              onTap: () {
                if (owned) {
                  widget.progress.selectItem(item.id, item.category);
                  widget.onMessage('${item.title} تجهیز شد');
                  setState(() {});
                } else {
                  widget.onMessage('${item.title} — ${item.rarity} — ${item.price} پالس');
                }
              },
              onBuy: () {
                if (equipped) {
                  widget.onMessage('این آیتم هم‌اکنون تجهیز شده است');
                  return;
                }
                if (owned) {
                  widget.progress.selectItem(item.id, item.category);
                  widget.onMessage('${item.title} تجهیز شد');
                  setState(() {});
                  return;
                }
                final bool success = widget.progress.purchaseItem(
                  item.id,
                  item.category,
                  item.price,
                );
                widget.onMessage(
                  success
                      ? '${item.title} خریداری و تجهیز شد'
                      : 'موجودی پالس برای این خرید کافی نیست',
                );
                setState(() {});
              },
            );
          },
        ),
      ],
    );
  }
}

class _ShopWalletStrip extends StatelessWidget {
  const _ShopWalletStrip({required this.progress});

  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: PulseColors.elevatedSoft.withValues(alpha: .92),
        borderRadius: BorderRadius.circular(PulseRadii.control),
        border: Border.all(color: PulseColors.divider),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Icon(Icons.bolt_rounded, color: PulseColors.gold, size: 19),
                const SizedBox(width: 6),
                Text(
                  _groupDigits(progress.energy),
                  style: const TextStyle(color: PulseColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w800),
                ),
                const SizedBox(width: 5),
                const Text('انرژی', textDirection: TextDirection.rtl, style: TextStyle(color: PulseColors.textMuted, fontSize: 10.5)),
              ],
            ),
          ),
          Container(width: 1, height: 22, color: PulseColors.divider),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Icon(Icons.motion_photos_on_rounded, color: PulseColors.rose, size: 19),
                const SizedBox(width: 6),
                Text(
                  _groupDigits(progress.pulse),
                  style: const TextStyle(color: PulseColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w800),
                ),
                const SizedBox(width: 5),
                const Text('پالس', textDirection: TextDirection.rtl, style: TextStyle(color: PulseColors.textMuted, fontSize: 10.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
