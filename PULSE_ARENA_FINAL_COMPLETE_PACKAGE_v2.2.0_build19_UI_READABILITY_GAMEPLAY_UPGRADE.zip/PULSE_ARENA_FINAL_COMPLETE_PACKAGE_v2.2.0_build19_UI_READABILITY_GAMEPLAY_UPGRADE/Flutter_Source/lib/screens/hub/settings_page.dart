part of '../hub_screen.dart';

class _SettingsPage extends StatefulWidget {
  const _SettingsPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  Future<void> _showInfo(String title, String body) async {
    await showDialog<void>(
      context: context,
      barrierColor: const Color(0xD601030A),
      builder: (BuildContext dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 25),
          child: PulsePanel(
            colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
            cut: 16,
            intensity: .48,
            padding: const EdgeInsets.all(18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: PulseTypography.title,
                ),
                const SizedBox(height: 10),
                Text(
                  body,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: PulseTypography.body,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: _GraphicButton(
                    label: 'متوجه شدم',
                    icon: Icons.check_rounded,
                    colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
                    onTap: () => Navigator.of(dialogContext).pop(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final PlayerProgressController progress = widget.progress;
    return _PageScaffold(
      title: 'تنظیمات',
      subtitle: 'کنترل بازی، صدا و عملکرد دستگاه',
      icon: Icons.settings_rounded,
      colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
      children: <Widget>[
        const _SectionTitle(
          title: 'سطح هوش مصنوعی',
          icon: Icons.smart_toy_rounded,
          color: PulseColors.cyan,
        ),
        const SizedBox(height: 9),
        PulsePanel(
          colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
          cut: 12,
          intensity: .30,
          padding: const EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  for (int i = 0; i < BotDifficulty.values.length; i++) ...<Widget>[
                    Expanded(
                      child: _DifficultyChoice(
                        value: BotDifficulty.values[i],
                        selected: progress.difficulty == BotDifficulty.values[i],
                        onTap: () {
                          final BotDifficulty value = BotDifficulty.values[i];
                          progress.setDifficulty(value);
                          widget.onMessage('سطح ربات روی ${value.title} تنظیم شد');
                          setState(() {});
                        },
                      ),
                    ),
                    if (i != BotDifficulty.values.length - 1)
                      const SizedBox(width: 7),
                  ],
                ],
              ),
              const SizedBox(height: 9),
              Row(
                children: <Widget>[
                  const Icon(Icons.info_outline_rounded, color: PulseColors.textMuted, size: 18),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      progress.difficulty.description,
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        color: PulseColors.textSecondary,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const _SectionTitle(
          title: 'صدا و بازخورد',
          icon: Icons.tune_rounded,
          color: PulseColors.rose,
        ),
        const SizedBox(height: 9),
        _VolumeSettingTile(
          icon: Icons.music_note_rounded,
          label: 'موسیقی محیطی',
          value: progress.musicVolume,
          enabled: progress.musicEnabled,
          color: PulseColors.violet,
          onToggle: () async {
            final bool enabled = !progress.musicEnabled;
            progress.setMusicEnabled(enabled);
            await AudioManager.instance.setMusicEnabled(enabled);
            if (mounted) setState(() {});
          },
          onChanged: (double value) {
            progress.setMusicVolume(value);
            unawaited(AudioManager.instance.setMusicVolume(value));
            setState(() {});
          },
        ),
        const SizedBox(height: 8),
        _VolumeSettingTile(
          icon: Icons.surround_sound_rounded,
          label: 'افکت‌های صوتی',
          value: progress.soundVolume,
          enabled: progress.soundEnabled,
          color: PulseColors.cyan,
          onToggle: () async {
            final bool enabled = !progress.soundEnabled;
            progress.setSoundEnabled(enabled);
            await AudioManager.instance.setSoundEnabled(enabled);
            if (mounted) setState(() {});
          },
          onChanged: (double value) {
            progress.setSoundVolume(value);
            unawaited(AudioManager.instance.setSoundVolume(value));
            setState(() {});
          },
        ),
        const SizedBox(height: 8),
        _SettingToggleTile(
          icon: Icons.vibration_rounded,
          label: 'بازخورد لرزشی',
          subtitle: progress.vibrationEnabled ? 'روشن؛ لرزش کوتاه برای لمس و برخورد' : 'خاموش',
          enabled: progress.vibrationEnabled,
          color: PulseColors.rose,
          onTap: () {
            final bool enabled = !progress.vibrationEnabled;
            progress.setVibrationEnabled(enabled);
            AudioManager.instance.vibrationEnabled = enabled;
            setState(() {});
          },
        ),
        const SizedBox(height: 14),
        const _SectionTitle(
          title: 'عملکرد و تصویر',
          icon: Icons.speed_rounded,
          color: PulseColors.gold,
        ),
        const SizedBox(height: 9),
        PulsePanel(
          colors: const <Color>[PulseColors.gold, PulseColors.gold],
          cut: 13,
          intensity: .28,
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              const Text('کیفیت افکت‌ها', textDirection: TextDirection.rtl, style: PulseTypography.section),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  for (int i = 0; i < 3; i++) ...<Widget>[
                    Expanded(
                      child: _SegmentButton(
                        label: const <String>['اقتصادی', 'متعادل', 'کامل'][i],
                        selected: progress.effectsQuality == i,
                        color: i == 2 ? PulseColors.gold : PulseColors.cyan,
                        onTap: () {
                          progress.setEffectsQuality(i);
                          setState(() {});
                        },
                      ),
                    ),
                    if (i != 2) const SizedBox(width: 7),
                  ],
                ],
              ),
              const SizedBox(height: 12),
              const Text('نرخ فریم هدف', textDirection: TextDirection.rtl, style: PulseTypography.section),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _SegmentButton(
                      label: '۶۰ FPS پایدار',
                      selected: progress.frameRate == 60,
                      color: PulseColors.cyan,
                      onTap: () {
                        progress.setFrameRate(60);
                        setState(() {});
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SegmentButton(
                      label: '۹۰ FPS سازگار',
                      selected: progress.frameRate == 90,
                      color: PulseColors.cyan,
                      onTap: () {
                        progress.setFrameRate(90);
                        setState(() {});
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              const Text(
                'حالت ۹۰ فریم فقط روی نمایشگر و دستگاه سازگار اعمال می‌شود و مصرف باتری بیشتری دارد.',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.right,
                style: TextStyle(color: PulseColors.textMuted, fontSize: 10.5, height: 1.45),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const _SectionTitle(
          title: 'راهنما و اطلاعات',
          icon: Icons.info_outline_rounded,
          color: PulseColors.textMuted,
        ),
        const SizedBox(height: 9),
        PulsePanel(
          colors: const <Color>[PulseColors.textMuted, PulseColors.textMuted],
          cut: 11,
          intensity: .20,
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Column(
            children: <Widget>[
              const Row(
                children: <Widget>[
                  Icon(Icons.sports_score_rounded, color: PulseColors.gold, size: 22),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'قانون مسابقه: اولین بازیکنی که ۱۰ گل بزند، برنده است.',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                      style: PulseTypography.body,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 9),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _GraphicButton(
                      label: 'راهنمای کنترل',
                      icon: Icons.touch_app_rounded,
                      colors: const <Color>[PulseColors.cyan, PulseColors.cyan],
                      onTap: () => _showInfo(
                        'راهنمای کنترل',
                        'انگشت را روی نیمه بازیکن قرار بده و عمودی حرکت بده. راکت موقعیت انگشت را مستقیم دنبال می‌کند. قبل از سرویس شمارش معکوس نمایش داده می‌شود و کنترل از همان لحظه فعال است.',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _GraphicButton(
                      label: 'حریم خصوصی',
                      icon: Icons.privacy_tip_outlined,
                      colors: const <Color>[PulseColors.textMuted, PulseColors.textMuted],
                      onTap: () => _showInfo(
                        'حریم خصوصی',
                        'این نسخه آفلاین است. پیشرفت، تنظیمات، خریدهای محلی و نتایج مسابقه فقط در حافظه داخلی همین دستگاه ذخیره می‌شوند و به سرور ارسال نمی‌شوند.',
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'PULSE ARENA • 2.2.0+19',
          textDirection: TextDirection.ltr,
          style: TextStyle(
            color: PulseColors.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _DifficultyChoice extends StatelessWidget {
  const _DifficultyChoice({required this.value, required this.selected, required this.onTap});

  final BotDifficulty value;
  final bool selected;
  final VoidCallback onTap;

  IconData get icon => switch (value) {
        BotDifficulty.trainee => Icons.school_outlined,
        BotDifficulty.tactical => Icons.gps_fixed_rounded,
        BotDifficulty.champion => Icons.emoji_events_outlined,
      };

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: value.title,
      onTap: onTap,
      builder: (_, bool pressed) => AnimatedContainer(
        duration: PulseDurations.micro,
        height: 72,
        decoration: BoxDecoration(
          color: selected ? PulseColors.cyan.withValues(alpha: .11) : PulseColors.panelInset,
          borderRadius: BorderRadius.circular(PulseRadii.control),
          border: Border.all(
            color: selected ? PulseColors.cyan.withValues(alpha: .70) : PulseColors.divider,
            width: selected ? 1.35 : 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: selected ? PulseColors.cyan : PulseColors.textMuted, size: 23),
            const SizedBox(height: 5),
            Text(
              value.title,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                color: selected ? PulseColors.textPrimary : PulseColors.textSecondary,
                fontSize: 12,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VolumeSettingTile extends StatelessWidget {
  const _VolumeSettingTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.enabled,
    required this.color,
    required this.onToggle,
    required this.onChanged,
  });

  final IconData icon;
  final String label;
  final double value;
  final bool enabled;
  final Color color;
  final VoidCallback onToggle;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return PulsePanel(
      colors: <Color>[color, color],
      cut: 11,
      intensity: enabled ? .34 : .16,
      padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(icon, color: enabled ? color : PulseColors.disabled, size: 23),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: const TextStyle(color: PulseColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700),
                ),
              ),
              Text(
                enabled ? '${(value * 100).round()}٪' : 'خاموش',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  color: enabled ? color : PulseColors.textMuted,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 8),
              NeonPressable(
                semanticLabel: enabled ? 'خاموش کردن $label' : 'روشن کردن $label',
                onTap: onToggle,
                builder: (_, bool pressed) => _CustomToggle(enabled: enabled, color: color),
              ),
            ],
          ),
          const SizedBox(height: 5),
          _CyberVolumeSlider(
            value: value,
            enabled: enabled,
            color: color,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _CyberVolumeSlider extends StatelessWidget {
  const _CyberVolumeSlider({
    required this.value,
    required this.enabled,
    required this.color,
    required this.onChanged,
  });

  final double value;
  final bool enabled;
  final Color color;
  final ValueChanged<double> onChanged;

  void _update(Offset localPosition, double width) {
    if (!enabled || width <= 0) return;
    onChanged((localPosition.dx / width).clamp(0.0, 1.0).toDouble());
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return Semantics(
          label: 'میزان صدا',
          value: '${(value * 100).round()} درصد',
          slider: true,
          enabled: enabled,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (TapDownDetails details) => _update(details.localPosition, constraints.maxWidth),
            onHorizontalDragUpdate: (DragUpdateDetails details) => _update(details.localPosition, constraints.maxWidth),
            child: SizedBox(
              height: 25,
              child: CustomPaint(
                painter: _VolumeSliderPainter(value: value, enabled: enabled, color: color),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _VolumeSliderPainter extends CustomPainter {
  const _VolumeSliderPainter({required this.value, required this.enabled, required this.color});

  final double value;
  final bool enabled;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final double y = size.height / 2;
    final RRect track = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, y - 3, size.width, 6),
      const Radius.circular(3),
    );
    canvas.drawRRect(track, Paint()..color = const Color(0xFF152230));
    final double activeWidth = size.width * value;
    if (activeWidth > 0) {
      final RRect active = RRect.fromRectAndRadius(
        Rect.fromLTWH(0, y - 3, activeWidth, 6),
        const Radius.circular(3),
      );
      canvas.drawRRect(active, Paint()..color = enabled ? color : PulseColors.disabled);
    }
    final Offset thumb = Offset(activeWidth.clamp(7.0, size.width - 7.0).toDouble(), y);
    canvas.drawCircle(thumb, 7, Paint()..color = enabled ? PulseColors.textPrimary : PulseColors.disabled);
    canvas.drawCircle(thumb, 4, Paint()..color = enabled ? color : PulseColors.textMuted);
  }

  @override
  bool shouldRepaint(covariant _VolumeSliderPainter oldDelegate) {
    return oldDelegate.value != value || oldDelegate.enabled != enabled || oldDelegate.color != color;
  }
}
