part of '../hub_screen.dart';

class _ProfilePage extends StatelessWidget {
  const _ProfilePage({
    required this.progress,
    required this.onEditProfile,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final VoidCallback onEditProfile;
  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    final int levelPercent = (progress.levelProgress * 100).round();
    final int winPercent = (progress.winRate * 100).round();
    return _PageScaffold(
      title: 'پروفایل فرمانده',
      subtitle: 'هویت، آمار واقعی نبرد و افتخارات محلی',
      icon: Icons.person_rounded,
      colors: const <Color>[PulseColors.cyan, PulseColors.violet],
      children: <Widget>[
        PulsePanel(
          colors: const <Color>[PulseColors.cyan, PulseColors.rose],
          cut: 24,
          padding: const EdgeInsets.all(16),
          child: Row(
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  const SizedBox(
                    width: 92,
                    height: 92,
                    child: CustomPaint(painter: _AvatarPainter()),
                  ),
                  Positioned(
                    right: -3,
                    bottom: -3,
                    child: _LevelBadge(level: '${progress.level}'),
                  ),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      progress.playerName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textDirection: TextDirection.rtl,
                      style: const TextStyle(
                        color: PulseColors.textPrimary,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'فرمانده پالس • سطح ${progress.level}',
                      textDirection: TextDirection.rtl,
                      style: const TextStyle(
                        color: PulseColors.cyan,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 11),
                    PulseProgress(
                      value: progress.levelProgress,
                      label: '$levelPercent٪ تا سطح ${progress.level + 1}',
                      colors: const <Color>[
                        PulseColors.cyan,
                        PulseColors.violet,
                      ],
                    ),
                    const SizedBox(height: 9),
                    _GraphicButton(
                      label: 'ویرایش پروفایل',
                      icon: Icons.edit_rounded,
                      colors: const <Color>[
                        PulseColors.cyan,
                        PulseColors.violet,
                      ],
                      onTap: onEditProfile,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            Expanded(
              child: _MetricPanel(
                value: _groupDigits(progress.wins),
                label: 'پیروزی',
                icon: Icons.emoji_events_rounded,
                color: PulseColors.gold,
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: _MetricPanel(
                value: _groupDigits(progress.losses),
                label: 'شکست',
                icon: Icons.close_rounded,
                color: PulseColors.rose,
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: _MetricPanel(
                value: '$winPercent٪',
                label: 'نرخ برد',
                icon: Icons.auto_graph_rounded,
                color: PulseColors.cyan,
              ),
            ),
          ],
        ),
        const SizedBox(height: 9),
        Row(
          children: <Widget>[
            Expanded(
              child: _MetricPanel(
                value: _groupDigits(progress.matches),
                label: 'مسابقه',
                icon: Icons.sports_esports_rounded,
                color: PulseColors.blue,
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: _MetricPanel(
                value: _groupDigits(progress.goals),
                label: 'گل زده',
                icon: Icons.track_changes_rounded,
                color: PulseColors.violet,
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: _MetricPanel(
                value: '#${progress.offlineRank}',
                label: 'رتبه محلی',
                icon: Icons.leaderboard_rounded,
                color: PulseColors.gold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        PulsePanel(
          colors: const <Color>[PulseColors.gold, PulseColors.violet],
          cut: 20,
          padding: const EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              const SizedBox(
                width: 62,
                height: 62,
                child: CustomPaint(painter: _LeagueEmblemPainter()),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      'لیگ ${progress.leagueName} آفلاین',
                      textDirection: TextDirection.rtl,
                      style: PulseTypography.section,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${_groupDigits(progress.leagueScore)} امتیاز • رتبه ${progress.offlineRank}',
                      textDirection: TextDirection.rtl,
                      style: PulseTypography.body,
                    ),
                    const SizedBox(height: 8),
                    PulseProgress(
                      value: progress.leagueProgress,
                      label: progress.pointsToNextLeague == 0
                          ? 'بالاترین لیگ محلی'
                          : '${progress.pointsToNextLeague} امتیاز تا ${progress.nextLeagueName}',
                      colors: const <Color>[PulseColors.gold, PulseColors.violet],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        const _SectionTitle(
          title: 'افتخارات و رکوردها',
          icon: Icons.military_tech_rounded,
          color: PulseColors.gold,
        ),
        const SizedBox(height: 9),
        _AchievementTile(
          title: 'شکارچی پالس',
          subtitle: '۵۰ پیروزی در نبردهای آفلاین',
          progress: (progress.wins / 50).clamp(0.0, 1.0).toDouble(),
          icon: Icons.flash_on_rounded,
          color: PulseColors.gold,
          onTap: () => onMessage('${progress.wins} از ۵۰ پیروزی ثبت شده'),
        ),
        const SizedBox(height: 9),
        _AchievementTile(
          title: 'ضربه بی‌نقص',
          subtitle: '۳۰۰ ضربه دقیق در مجموع',
          progress: (progress.perfectHits / 300).clamp(0.0, 1.0).toDouble(),
          icon: Icons.gps_fixed_rounded,
          color: PulseColors.cyan,
          onTap: () => onMessage('${progress.perfectHits} از ۳۰۰ ضربه دقیق ثبت شده'),
        ),
        const SizedBox(height: 9),
        _AchievementTile(
          title: 'فرمانروای آرنا',
          subtitle: 'رسیدن به امتیاز ۵۰۰۰ لیگ محلی',
          progress: (progress.leagueScore / 5000).clamp(0.0, 1.0).toDouble(),
          icon: Icons.workspace_premium_rounded,
          color: PulseColors.rose,
          onTap: () => onMessage('${progress.leagueScore} از ۵۰۰۰ امتیاز ثبت شده'),
        ),
        const SizedBox(height: 10),
        const _SectionTitle(
          title: 'آخرین نبردها',
          icon: Icons.history_rounded,
          color: PulseColors.cyan,
        ),
        const SizedBox(height: 9),
        if (progress.recentMatches.isEmpty)
          const PulsePanel(
            colors: <Color>[PulseColors.blue, PulseColors.violet],
            cut: 17,
            padding: EdgeInsets.all(13),
            child: Row(
              children: <Widget>[
                Icon(Icons.sports_esports_rounded, color: PulseColors.cyan),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'هنوز نبردی ثبت نشده است. اولین مسابقه، تاریخچه واقعی شما را می‌سازد.',
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: PulseTypography.body,
                  ),
                ),
              ],
            ),
          )
        else
          for (int i = 0; i < progress.recentMatches.length; i++) ...<Widget>[
            _RecentMatchTile(data: progress.recentMatches[i]),
            if (i != progress.recentMatches.length - 1)
              const SizedBox(height: 8),
          ],
      ],
    );
  }
}


class _RecentMatchTile extends StatelessWidget {
  const _RecentMatchTile({required this.data});

  final Map<String, Object> data;

  @override
  Widget build(BuildContext context) {
    final bool won = data['won'] == true;
    final int playerScore = data['playerScore'] as int? ?? 0;
    final int botScore = data['botScore'] as int? ?? 0;
    final int playedAt = data['playedAt'] as int? ?? 0;
    final DateTime date = DateTime.fromMillisecondsSinceEpoch(playedAt);
    final String minute = date.minute.toString().padLeft(2, '0');
    final String time = playedAt == 0
        ? 'ثبت محلی'
        : '${date.year}/${date.month}/${date.day} • ${date.hour}:$minute';
    final Color color = won ? PulseColors.cyan : PulseColors.rose;

    return PulsePanel(
      colors: <Color>[color, PulseColors.violet],
      cut: 16,
      intensity: .62,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: <Widget>[
          _IconCore(
            icon: won ? Icons.emoji_events_rounded : Icons.replay_rounded,
            color: color,
            size: 40,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  won ? 'پیروزی در آرنا' : 'شکست در آرنا',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: color,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  time,
                  textDirection: TextDirection.rtl,
                  style: PulseTypography.body,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            '$playerScore — $botScore',
            textDirection: TextDirection.ltr,
            style: const TextStyle(
              color: PulseColors.textPrimary,
              fontSize: 19,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
