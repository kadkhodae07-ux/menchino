import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

import '../config/game_config.dart';
import 'ball_controller.dart';

class BotPaddleController extends PositionComponent {
  BotPaddleController({
    required this.config,
    required this.ball,
    required this.playerScore,
    required this.isPulseActive,
    int Function()? botScore,
  }) : botScore = botScore ?? _zeroScore;

  static int _zeroScore() => 0;

  final GameConfig config;
  final BallController ball;
  final int Function() playerScore;
  final int Function() botScore;
  final bool Function() isPulseActive;
  final math.Random _random = math.Random(9721);

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  double verticalVelocity = 0;
  bool movementEnabled = true;

  double _reactionTimer = 0;
  double _observedBallY = 0;
  double _observedVelocityY = 0;
  double _motionEnergy = 0;
  double _hitEnergy = 0;
  Path _bodyPath = Path();
  Rect _localBounds = Rect.zero;
  late Paint _bodyPaint;
  final Paint _ghostPaint = Paint();
  final Paint _glowPaint = Paint()..style = PaintingStyle.stroke;
  final Paint _outlinePaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.7
    ..color = const Color(0xEFFFFFFF);
  final Paint _whitePaint = Paint()..color = const Color(0xFFFFFFFF);
  final Paint _detailPaint = Paint()..color = const Color(0xB859124A);

  static const Color _magenta = Color(0xFFC15C8E);

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? .5
        : ((position.y + size.y / 2 - movementBounds.top) /
                movementBounds.height)
            .clamp(0.0, 1.0)
            .toDouble();

    movementBounds = arena;
    size = Vector2(
      (arena.width * .024).clamp(23.0, 35.0).toDouble(),
      (arena.height * .275).clamp(86.0, 138.0).toDouble(),
    );
    position.x = arena.right -
        (arena.width * .032).clamp(24.0, 42.0).toDouble() -
        size.x;
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
    _rebuildVisuals();
  }

  void _rebuildVisuals() {
    _localBounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * .32;
    _bodyPath = Path()
      ..moveTo(cut * .22, 0)
      ..lineTo(size.x - cut, 0)
      ..lineTo(size.x, cut * .65)
      ..lineTo(size.x, size.y - cut * .65)
      ..lineTo(size.x - cut, size.y)
      ..lineTo(cut * .22, size.y)
      ..lineTo(0, size.y - cut)
      ..lineTo(0, cut)
      ..close();
    _bodyPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: <Color>[
          Color(0xFFE8DCE3),
          Color(0xFFC15C8E),
          Color(0xFF4B273B),
        ],
      ).createShader(_localBounds);
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    verticalVelocity = 0;
    _reactionTimer = 0;
    _observedBallY = movementBounds.center.dy;
    _observedVelocityY = 0;
    _motionEnergy = 0;
  }

  void registerHit() {
    _hitEnergy = .95;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double frameDt = dt.clamp(1 / 300, 1 / 20).toDouble();
    _hitEnergy = math.max(0.0, _hitEnergy - frameDt * 6.0);
    if (!movementEnabled || movementBounds.isEmpty) return;

    final int lead = botScore() - playerScore();
    _reactionTimer -= frameDt;
    if (_reactionTimer <= 0) {
      final double leadDelay = lead >= 3 ? 1.16 : 1.0;
      _reactionTimer = config.botReactionDelay *
          leadDelay *
          (.92 + _random.nextDouble() * .24);
      _observedBallY = ball.position.y;
      _observedVelocityY = ball.velocity.y;
      _chooseTarget(lead);
    }

    final double pulseFactor =
        isPulseActive() ? config.pulseSlowFactor : 1.0;
    final double rubberBand = lead >= 3 ? .86 : 1.0;
    final double maxSpeed = config.botPaddleSpeed * pulseFactor * rubberBand;
    final double maxAcceleration =
        config.botPaddleAcceleration * pulseFactor * rubberBand;
    final double delta = targetY - position.y;
    final double distanceRatio =
        (delta.abs() / math.max(1.0, movementBounds.height * .32))
            .clamp(0.0, 1.0)
            .toDouble();
    final double desiredVelocity =
        (delta * (15.5 + distanceRatio * 8.5))
            .clamp(-maxSpeed, maxSpeed)
            .toDouble();
    final bool braking =
        verticalVelocity != 0 && delta != 0 && verticalVelocity.sign != delta.sign;
    final double maxVelocityChange =
        maxAcceleration * (braking ? 1.45 : 1.0) * frameDt;
    verticalVelocity += (desiredVelocity - verticalVelocity)
        .clamp(-maxVelocityChange, maxVelocityChange)
        .toDouble();
    position.y += verticalVelocity * frameDt;

    if (delta.abs() < .55 && verticalVelocity.abs() < 14) {
      position.y = targetY;
      verticalVelocity = 0;
    }

    final double minY = movementBounds.top;
    final double maxY = movementBounds.bottom - size.y;
    if (position.y <= minY) {
      position.y = minY;
      if (verticalVelocity < 0) verticalVelocity = 0;
    } else if (position.y >= maxY) {
      position.y = maxY;
      if (verticalVelocity > 0) verticalVelocity = 0;
    }

    final double targetEnergy =
        (verticalVelocity.abs() / math.max(1.0, maxSpeed))
            .clamp(0.0, 1.0)
            .toDouble();
    _motionEnergy +=
        (targetEnergy - _motionEnergy) * (1 - math.exp(-16 * frameDt));
  }

  void _chooseTarget(int lead) {
    final bool ballThreatening = ball.active && ball.velocity.x > 0;
    if (!ballThreatening) {
      final double idleOffset =
          math.sin(ball.visualTime * 1.18) * movementBounds.height * .028;
      targetY = (movementBounds.center.dy - size.y / 2 + idleOffset)
          .clamp(movementBounds.top, movementBounds.bottom - size.y)
          .toDouble();
      return;
    }

    final double interceptX = position.x - ball.radius;
    final double travelX = math.max(0.0, interceptX - ball.position.x);
    final double rawTravelTime = travelX / math.max(1.0, ball.velocity.x);
    final double lookAheadLimit = switch (config.difficulty) {
      BotDifficulty.trainee => .46,
      BotDifficulty.tactical => .62,
      BotDifficulty.champion => .78,
    };
    final double travelTime = math.min(rawTravelTime, lookAheadLimit);

    double predictedY = _observedBallY + _observedVelocityY * travelTime;
    predictedY = _reflectY(
      predictedY,
      movementBounds.top + ball.radius,
      movementBounds.bottom - ball.radius,
    );

    final double speedRatio =
        (ball.velocity.length / math.max(1.0, config.ballMaximumSpeed))
            .clamp(0.0, 1.0)
            .toDouble();
    double error = config.botBaseAimError * (1 + speedRatio * .48);
    if (lead >= 3) error *= 1.32;

    final double fastBallMistake = config.botErrorChance * (1 + speedRatio * .70);
    if (_random.nextDouble() < fastBallMistake) {
      error *= 1.55 + _random.nextDouble() * .55;
    }

    // A small delayed tracking drift prevents the bot from snapping to the
    // mathematically perfect intercept even on the champion level.
    predictedY += (_random.nextDouble() * 2 - 1) * error;
    final double centerBias = switch (config.difficulty) {
      BotDifficulty.trainee => .18,
      BotDifficulty.tactical => .10,
      BotDifficulty.champion => .05,
    };
    predictedY = predictedY * (1 - centerBias) + movementBounds.center.dy * centerBias;

    targetY = (predictedY - size.y / 2)
        .clamp(movementBounds.top, movementBounds.bottom - size.y)
        .toDouble();
  }

  double _reflectY(double y, double top, double bottom) {
    final double height = bottom - top;
    if (height <= 0) return top;
    double local = (y - top) % (height * 2);
    if (local < 0) local += height * 2;
    if (local > height) local = height * 2 - local;
    return top + local;
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final double ghostDistance = 2.3 + _motionEnergy * 6.0;
    for (int i = 2; i >= 1; i--) {
      canvas.save();
      canvas.translate(i * ghostDistance, 0);
      _ghostPaint.color = _magenta.withValues(
        alpha: .02 + _motionEnergy * (.05 / i),
      );
      canvas.drawPath(_bodyPath, _ghostPaint);
      canvas.restore();
    }

    _glowPaint
      ..strokeWidth = 6 + _hitEnergy * 2.6
      ..color = _magenta.withValues(alpha: .13 + _hitEnergy * .10);
    canvas.drawPath(_bodyPath, _glowPaint);
    canvas.drawPath(_bodyPath, _bodyPaint);
    canvas.drawPath(_bodyPath, _outlinePaint);

    final Rect energyChannel =
        Rect.fromLTWH(size.x * .58, size.y * .10, size.x * .22, size.y * .80);
    canvas.drawRRect(
      RRect.fromRectAndRadius(energyChannel, Radius.circular(size.x * .12)),
      _whitePaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(size.x * .34, size.y * .5),
          width: size.x * (.48 + _hitEnergy * .08),
          height: size.x * (.48 + _hitEnergy * .08),
        ),
        Radius.circular(size.x),
      ),
      _whitePaint,
    );

    for (final double y in <double>[.16, .84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(size.x * .42, size.y * y),
            width: size.x * .54,
            height: size.x * .14,
          ),
          Radius.circular(size.x * .07),
        ),
        _detailPaint,
      );
    }
  }
}
