# گزارش اعتبارسنجی PULSE ARENA 2.2.0+19

## کنترل‌های انجام‌شده

- نسخه `2.2.0+19`
- Package Name برابر `com.manyshah.pulsearena`
- وجود Flavorهای `bazaar` و `myket`
- قانون برد ۱۰ گل
- ساختار صفحات خانه، فروشگاه، تنظیمات، انتخاب حالت و نتیجه
- Bottom Padding منوی پایین
- Safe Area نتیجه و نام‌گذاری امتیاز
- timestep ثابت ۱۲۰ هرتز و سقف ۸ زیرگام
- پروفایل‌های مستقل سه سطح ربات
- توازن پرانتز، براکت و آکولاد فایل‌های Dart
- Parse تمام XMLهای Android
- آیکن ۱۰۲۴×۱۰۲۴ و Splash پروژه
- Parse فایل YAML مستقل WF16
- نبود عبارت WF15 در Workflow جدید
- نبود فایل Workflow داخل ساختار سورس

## Workflow

- نام: `PULSE_ARENA_BUILD_APK_WF16.yml`
- تعداد خطوط: `838`
- SHA-256: `f9b54ffe56f5c37ccae19240b625cb45cd6a856bcf83b1116df4ebe3e3a387c8`
- تست هدفمند حرکت ثابت ۱۲۰/۶۰/۳۰ FPS
- تست هدفمند UI/Gameplay نسخه 2.2
- سپس مجموعه کامل تست‌ها و Build دو APK

## محدودیت محیط محلی

Flutter SDK، Dart SDK، Android SDK، Emulator و دستگاه واقعی در محیط فعلی موجود نبودند. بنابراین `dart format`، `flutter analyze`، `flutter test`، Build APK و اندازه‌گیری عملی FPS در این محیط اجرا نشده‌اند. این موارد در WF16 اجرا می‌شوند و پس از Build باید روی دستگاه واقعی نیز تست شوند.
