PULSE ARENA — تحویل نسخه 2.2.0+19

محتویات ZIP:
1) Flutter_Source: سورس کامل Flutter/Flame
2) Reports: گزارش تغییرات و اعتبارسنجی
3) DELIVERY_README_FA.txt: راهنمای تحویل

فایل Workflow عمداً داخل ZIP قرار نگرفته است.
فایل مستقل موردنیاز:
PULSE_ARENA_BUILD_APK_WF16.yml

روش استفاده در GitHub:
1) ZIP کامل پروژه را در ریشه Repository قرار بده.
2) فایل PULSE_ARENA_BUILD_APK_WF16.yml را جداگانه در مسیر زیر قرار بده:
   .github/workflows/build-apk.yml
3) تغییرات را Commit کن.
4) Workflow را از تب Actions اجرا کن یا با Push روی شاخه main منتظر اجرای خودکار بمان.
5) خروجی موفق شامل APK بازار، APK مایکت، SHA-256 و Build Manifest است.
6) در صورت شکست، فایل PULSE-ARENA-failure-logs را ارسال کن.

مشخصات:
- Version: 2.2.0+19
- Package Name: com.manyshah.pulsearena
- Flavors: bazaar / myket
- Winning Score: 10
- Workflow: WF16 مستقل

کنترل محلی مستقل از Flutter با موفقیت انجام شده است. Flutter Analyze، Flutter Test و Build واقعی APK به‌دلیل نبود Flutter/Android SDK محلی اجرا نشده و توسط WF16 انجام می‌شود.
