تحویل PULSE PONG نسخه 3.0.0+21
================================

مسیر سورس اصلی:
Flutter_Source/

این نسخه بازنویسی حرفه‌ای رابط و جریان بازی است و شامل لابی، انتخاب حالت، پروفایل، مأموریت‌ها، لیگ، فروشگاه، تنظیمات، HUD مسابقه، دونفره محلی، بهینه‌سازی عملکرد، بنر واکنش‌گرا و End Card تبلیغ ویدئویی است.

Package Name:
com.manyshah.pulsearena

Flavorها:
bazaar
myket

فرمان بررسی اصلی:
cd Flutter_Source
flutter pub get
dart format .
flutter analyze
flutter test
flutter build apk --debug --flavor bazaar
flutter build apk --debug --flavor myket

اعتبارسنجی استاتیک بسته:
202 بررسی موفق

محدودیت شفاف:
Flutter SDK در محیط تولید بسته نصب نبود؛ بنابراین Analyze، Test و Build واقعی APK در همان محیط اجرا نشده است. گزارش کامل در پوشه Reports و Flutter_Source/docs قرار دارد.
