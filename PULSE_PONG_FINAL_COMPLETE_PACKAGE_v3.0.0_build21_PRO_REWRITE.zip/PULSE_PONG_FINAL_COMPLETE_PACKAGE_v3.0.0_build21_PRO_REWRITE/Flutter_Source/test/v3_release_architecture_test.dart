import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

String _read(String path) => File(path).readAsStringSync();

void main() {
  test('release identity and Android store flavors remain valid', () {
    final String pubspec = _read('pubspec.yaml');
    final String gradle = _read('android/app/build.gradle.kts');

    expect(pubspec, contains('version: 3.0.0+21'));
    expect(pubspec, contains('PULSE PONG'));
    expect(gradle, contains('namespace = "com.manyshah.pulsearena"'));
    expect(gradle, contains('applicationId = "com.manyshah.pulsearena"'));
    expect(gradle, contains('create("bazaar")'));
    expect(gradle, contains('create("myket")'));
  });

  test('hub routes to every modular production page', () {
    final String hub = _read('lib/screens/hub_screen.dart');

    expect(hub, contains("import '../v3/features/lobby_page.dart'"));
    expect(hub, contains("import '../v3/features/missions_page.dart'"));
    expect(hub, contains("import '../v3/features/ranking_page.dart'"));
    expect(hub, contains("import '../v3/features/shop_page.dart'"));
    expect(hub, contains("import '../v3/features/profile_page.dart'"));
    expect(hub, contains("import '../v3/features/settings_page.dart'"));
    expect(hub, contains("import '../v3/features/mode_selection_page.dart'"));
    expect(hub, contains('ArenaBottomNavigation'));
    expect(hub, contains('ArenaTab.missions'));
    expect(hub, contains('SceneTransitionManager.openGame'));
  });

  test('legacy duplicated hub and lobby implementations are removed', () {
    expect(Directory('lib/screens/hub').existsSync(), isFalse);
    expect(Directory('lib/features/lobby').existsSync(), isFalse);
    expect(File('lib/screens/mode_selection_screen.dart').existsSync(), isFalse);
  });

  test('v3 visual system uses a shared layered game surface', () {
    final String ui = _read('lib/v3/ui/arena_ui.dart');
    final String lobby = _read('lib/v3/features/lobby_page.dart');

    expect(ui, contains('class ArenaSurface'));
    expect(ui, contains('class ArenaSurfacePainter'));
    expect(ui, contains('canvas.drawShadow'));
    expect(ui, contains('AnimatedScale'));
    expect(ui, contains('RepaintBoundary'));
    expect(lobby, contains('class _ArenaPreviewPainter'));
    expect(lobby, contains('class _PreviewBallPainter'));
    expect(lobby, contains('PULSE'));
    expect(lobby, contains('PONG'));
  });

  test('all primary destinations contain real user actions', () {
    final String modes = _read('lib/v3/features/mode_selection_page.dart');
    final String missions = _read('lib/v3/features/missions_page.dart');
    final String shop = _read('lib/v3/features/shop_page.dart');
    final String settings = _read('lib/v3/features/settings_page.dart');

    expect(modes, contains('GameConfig.forDifficulty'));
    expect(modes, contains('GameConfig.training'));
    expect(modes, contains('GameConfig.localDuel'));
    expect(missions, contains('claimDailyReward'));
    expect(missions, contains('claimMission'));
    expect(shop, contains('purchaseItem'));
    expect(shop, contains('selectItem'));
    expect(settings, contains('setEffectsQuality'));
    expect(settings, contains('setFrameRate'));
    expect(settings, contains('setSoundVolume'));
    expect(settings, contains('setControlSensitivity'));
  });
}
