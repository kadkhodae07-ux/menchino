import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('fixed banner is responsive, clipped, and never stretches artwork', () {
    final String ads = File('lib/v3/ads/ad_surfaces.dart').readAsStringSync();

    expect(ads, contains('class ResponsiveAdBanner'));
    expect(ads, contains('availableWidth / safeRatio'));
    expect(ads, contains('.clamp(minHeight, maxHeight)'));
    expect(ads, contains('BoxFit.cover'));
    expect(ads, contains('ClipPath'));
    expect(ads, contains('class _AdSlotClipper'));
  });

  test('completed video can show a real install end card', () {
    final String ads = File('lib/v3/ads/ad_surfaces.dart').readAsStringSync();
    final String activity = File(
      'android/app/src/main/kotlin/com/manyshah/pulsearena/MainActivity.kt',
    ).readAsStringSync();

    expect(ads, contains('class VideoAdEndCard'));
    expect(ads, contains('class VideoAdFlowController'));
    expect(ads, contains('if (!completed || !context.mounted) return false;'));
    expect(ads, contains('openInlineInstall'));
    expect(activity, contains('https://play.google.com/d'));
    expect(activity, contains('putExtra("overlay", true)'));
    expect(activity, contains('putExtra("callerId", callerId)'));
    expect(activity, contains('store/apps/details?id='));
  });
}
