import 'package:flame/components.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/components/arena_component.dart';

void main() {
  test('arena uses most of a landscape phone screen', () {
    final ArenaComponent arena = ArenaComponent()..layout(Vector2(800, 360));

    expect(arena.playRect.width / 800, greaterThan(0.9));
    expect(arena.playRect.height / 360, greaterThan(0.86));
  });
}
