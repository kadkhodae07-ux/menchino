import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/managers/match_stats_manager.dart';

void main() {
  test('tracks rally, player hits and perfect hits', () {
    final MatchStatsManager stats = MatchStatsManager();
    stats.recordPaddleHit(player: true, perfect: true);
    stats.recordPaddleHit(player: false, perfect: false);
    stats.recordPaddleHit(player: true, perfect: false);

    expect(stats.currentRally, 3);
    expect(stats.longestRally, 3);
    expect(stats.playerHits, 2);
    expect(stats.botHits, 1);
    expect(stats.perfectHits, 1);

    stats.endRally();
    expect(stats.currentRally, 0);
    expect(stats.longestRally, 3);
  });
}
