import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';

void main() {
  test('difficulty profiles change bot reaction and accuracy', () {
    final GameConfig trainee = GameConfig.forDifficulty(BotDifficulty.trainee);
    final GameConfig tactical = GameConfig.forDifficulty(BotDifficulty.tactical);
    final GameConfig champion = GameConfig.forDifficulty(BotDifficulty.champion);

    expect(trainee.botReactionDelay, greaterThan(tactical.botReactionDelay));
    expect(champion.botReactionDelay, lessThan(tactical.botReactionDelay));
    expect(trainee.botBaseAimError, greaterThan(champion.botBaseAimError));
    expect(champion.botPaddleSpeed, greaterThan(trainee.botPaddleSpeed));
  });
}
