import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';
import 'package:pulse_arena/game/managers/match_manager.dart';
import 'package:pulse_arena/game/models/game_view_state.dart';

void main() {
  test('opening countdown launches exactly once', () {
    const GameConfig config = GameConfig(countdownDuration: 3.6);
    final MatchManager match = MatchManager(config)..reset();

    expect(match.phase, MatchPhase.countdown);
    expect(match.openingSequence, isTrue);
    expect(match.update(3.5), isFalse);
    expect(match.update(0.2), isTrue);
    expect(match.phase, MatchPhase.playing);
    expect(match.update(0.1), isFalse);
  });

  test('point serve uses the short transition', () {
    const GameConfig config = GameConfig(pointServeDelay: 0.88);
    final MatchManager match = MatchManager(config)..startCountdown(opening: false);

    expect(match.openingSequence, isFalse);
    expect(match.countdownTotal, 0.88);
    expect(match.update(0.7), isFalse);
    expect(match.update(0.2), isTrue);
    expect(match.phase, MatchPhase.playing);
  });
}
