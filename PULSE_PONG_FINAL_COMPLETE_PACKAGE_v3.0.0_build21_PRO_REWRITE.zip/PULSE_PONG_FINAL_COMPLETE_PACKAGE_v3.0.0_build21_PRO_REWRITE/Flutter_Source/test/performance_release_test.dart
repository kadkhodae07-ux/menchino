import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('orientation changes are awaited around the game route', () {
    final String transition = File(
      'lib/game/managers/scene_transition_manager.dart',
    ).readAsStringSync();

    expect(transition, contains('await OrientationManager.showGame()'));
    expect(transition, contains('await navigator.push'));
    expect(transition, contains('await OrientationManager.showHome()'));
    expect(transition, isNot(contains('unawaited(OrientationManager.showGame())')));
  });

  test('gameplay uses fixed-step physics and recoverable adaptive effects', () {
    final String ball = File(
      'lib/game/components/ball_controller.dart',
    ).readAsStringSync();
    final String game = File(
      'lib/game/pulse_arena_game.dart',
    ).readAsStringSync();

    expect(ball, contains('_physicsStep = 1 / 120'));
    expect(ball, contains('iterations < 8'));
    expect(game, contains('_uiAccumulator >= 0.05'));
    expect(game, contains('_stableFrameCredit'));
    expect(game, contains('_reducedEffects = false'));
    expect(game, contains('PlayerProgressController.instance.effectsQuality'));
  });

  test('local duel has visible split control zones', () {
    final String gameScreen = File('lib/screens/game_screen.dart').readAsStringSync();

    expect(gameScreen, contains('class _LocalDuelControlZones'));
    expect(gameScreen, contains('class _ControlZone'));
    expect(gameScreen, contains('بازیکن ۱'));
    expect(gameScreen, contains('بازیکن ۲'));
  });
}
