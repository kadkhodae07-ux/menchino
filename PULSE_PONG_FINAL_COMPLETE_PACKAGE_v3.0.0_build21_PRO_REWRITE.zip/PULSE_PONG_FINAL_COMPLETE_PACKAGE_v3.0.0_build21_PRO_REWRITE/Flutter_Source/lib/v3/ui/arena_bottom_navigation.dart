import 'package:flutter/material.dart';

import 'arena_ui.dart';

enum ArenaTab { home, ranking, missions, shop }

class ArenaBottomNavigation extends StatelessWidget {
  const ArenaBottomNavigation({
    required this.active,
    required this.onChanged,
    super.key,
  });

  final ArenaTab active;
  final ValueChanged<ArenaTab> onChanged;

  @override
  Widget build(BuildContext context) {
    const List<_TabData> items = <_TabData>[
      _TabData(ArenaTab.home, Icons.home_rounded, 'خانه'),
      _TabData(ArenaTab.ranking, Icons.emoji_events_rounded, 'رقابت'),
      _TabData(ArenaTab.missions, Icons.flag_rounded, 'ماموریت'),
      _TabData(ArenaTab.shop, Icons.storefront_rounded, 'فروشگاه'),
    ];
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(12, 4, 12, 9),
      child: SizedBox(
        height: 68,
        child: ArenaSurface(
          accent: ArenaPalette.blue,
          enableGlow: false,
          padding: const EdgeInsets.all(6),
          child: Row(
            children: items.map((_TabData item) {
              final bool selected = active == item.tab;
              return Expanded(
                child: Semantics(
                  button: true,
                  selected: selected,
                  label: item.label,
                  child: InkWell(
                    splashColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () => onChanged(item.tab),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      curve: Curves.easeOutCubic,
                      transform: Matrix4.translationValues(0, selected ? -3 : 0, 0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(11),
                        gradient: selected
                            ? const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: <Color>[Color(0xFF183A61), Color(0xFF0A1728)],
                              )
                            : null,
                        border: selected
                            ? Border.all(color: ArenaPalette.cyan.withValues(alpha: .52))
                            : null,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(
                            item.icon,
                            size: 24,
                            color: selected ? ArenaPalette.cyan : ArenaPalette.textMuted,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            item.label,
                            maxLines: 1,
                            style: ArenaText.caption.copyWith(
                              fontSize: 10.5,
                              color: selected ? ArenaPalette.text : ArenaPalette.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(growable: false),
          ),
        ),
      ),
    );
  }
}

class _TabData {
  const _TabData(this.tab, this.icon, this.label);
  final ArenaTab tab;
  final IconData icon;
  final String label;
}
