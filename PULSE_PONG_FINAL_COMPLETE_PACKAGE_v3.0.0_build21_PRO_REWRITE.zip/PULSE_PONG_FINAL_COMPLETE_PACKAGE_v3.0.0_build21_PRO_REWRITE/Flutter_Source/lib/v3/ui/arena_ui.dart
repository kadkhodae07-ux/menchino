import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../game/managers/audio_manager.dart';

abstract final class ArenaPalette {
  static const Color backgroundTop = Color(0xFF030816);
  static const Color backgroundMid = Color(0xFF07152B);
  static const Color backgroundBottom = Color(0xFF02050D);
  static const Color surfaceTop = Color(0xFF142744);
  static const Color surfaceMid = Color(0xFF0B172B);
  static const Color surfaceBottom = Color(0xFF050B16);
  static const Color surfaceRaised = Color(0xFF10213A);
  static const Color surfaceInset = Color(0xFF07101D);
  static const Color frame = Color(0xFF223B5E);
  static const Color frameDark = Color(0xFF02060E);
  static const Color cyan = Color(0xFF21C7F4);
  static const Color blue = Color(0xFF2A7EF4);
  static const Color gold = Color(0xFFFFB51E);
  static const Color goldLight = Color(0xFFFFD465);
  static const Color success = Color(0xFF48D59B);
  static const Color danger = Color(0xFFF06D75);
  static const Color text = Color(0xFFF4F8FF);
  static const Color textSoft = Color(0xFFB8C5DA);
  static const Color textMuted = Color(0xFF7E8FA9);
  static const Color divider = Color(0xFF243853);
}

abstract final class ArenaText {
  static const TextStyle display = TextStyle(
    color: ArenaPalette.text,
    fontSize: 28,
    fontWeight: FontWeight.w900,
    height: 1.22,
  );
  static const TextStyle title = TextStyle(
    color: ArenaPalette.text,
    fontSize: 19,
    fontWeight: FontWeight.w900,
    height: 1.35,
  );
  static const TextStyle section = TextStyle(
    color: ArenaPalette.text,
    fontSize: 15,
    fontWeight: FontWeight.w900,
    height: 1.4,
  );
  static const TextStyle body = TextStyle(
    color: ArenaPalette.textSoft,
    fontSize: 13,
    fontWeight: FontWeight.w600,
    height: 1.55,
  );
  static const TextStyle caption = TextStyle(
    color: ArenaPalette.textMuted,
    fontSize: 11.5,
    fontWeight: FontWeight.w700,
    height: 1.45,
  );
}

class ArenaPage extends StatelessWidget {
  const ArenaPage({
    required this.child,
    this.bottomNavigation,
    this.padding = EdgeInsets.zero,
    this.allowScroll = false,
    super.key,
  });

  final Widget child;
  final Widget? bottomNavigation;
  final EdgeInsets padding;
  final bool allowScroll;

  @override
  Widget build(BuildContext context) {
    final Widget content = allowScroll
        ? SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: padding,
            child: child,
          )
        : Padding(padding: padding, child: child);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: ArenaPalette.backgroundBottom,
        body: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            const RepaintBoundary(
              child: CustomPaint(painter: ArenaBackgroundPainter()),
            ),
            SafeArea(
              child: Column(
                children: <Widget>[
                  Expanded(child: content),
                  if (bottomNavigation != null) bottomNavigation!,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ArenaBackgroundPainter extends CustomPainter {
  const ArenaBackgroundPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            ArenaPalette.backgroundTop,
            ArenaPalette.backgroundMid,
            ArenaPalette.backgroundBottom,
          ],
          stops: <double>[0, .46, 1],
        ).createShader(rect),
    );
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(0, -.12),
          radius: 1.02,
          colors: <Color>[Color(0x2B1267B5), Color(0x001267B5)],
        ).createShader(rect),
    );

    final Paint grid = Paint()
      ..color = const Color(0x0C5FA2E9)
      ..strokeWidth = .7;
    final double horizon = size.height * .60;
    for (int i = 0; i <= 8; i++) {
      final double t = i / 8;
      final double y = horizon +
          math.pow(t, 1.55).toDouble() * (size.height - horizon);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    for (int i = -6; i <= 6; i++) {
      final double endX = size.width * .5 + i * size.width * .17;
      canvas.drawLine(Offset(size.width * .5, horizon), Offset(endX, size.height), grid);
    }
  }

  @override
  bool shouldRepaint(covariant ArenaBackgroundPainter oldDelegate) => false;
}

class ArenaSurface extends StatefulWidget {
  const ArenaSurface({
    required this.child,
    this.accent = ArenaPalette.cyan,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.selected = false,
    this.prominent = false,
    this.enableGlow = true,
    this.semanticLabel,
    super.key,
  });

  final Widget child;
  final Color accent;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool selected;
  final bool prominent;
  final bool enableGlow;
  final String? semanticLabel;

  @override
  State<ArenaSurface> createState() => _ArenaSurfaceState();
}

class _ArenaSurfaceState extends State<ArenaSurface> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (widget.onTap == null || _pressed == value) return;
    setState(() => _pressed = value);
  }

  void _activate() {
    final VoidCallback? callback = widget.onTap;
    if (callback == null) return;
    unawaited(AudioManager.instance.playButton());
    unawaited(AudioManager.instance.lightImpact());
    callback();
  }

  @override
  Widget build(BuildContext context) {
    final bool enabled = widget.onTap != null;
    return Semantics(
      button: enabled,
      selected: widget.selected,
      label: widget.semanticLabel,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: enabled ? (_) => _setPressed(true) : null,
        onTapCancel: enabled ? () => _setPressed(false) : null,
        onTapUp: enabled ? (_) => _setPressed(false) : null,
        onTap: enabled ? _activate : null,
        child: AnimatedScale(
          scale: _pressed ? .985 : 1,
          duration: const Duration(milliseconds: 85),
          curve: Curves.easeOutCubic,
          child: AnimatedSlide(
            offset: Offset(0, _pressed ? .025 : 0),
            duration: const Duration(milliseconds: 85),
            curve: Curves.easeOutCubic,
            child: RepaintBoundary(
              child: CustomPaint(
                painter: ArenaSurfacePainter(
                  accent: widget.accent,
                  selected: widget.selected,
                  prominent: widget.prominent,
                  pressed: _pressed,
                  enableGlow: widget.enableGlow,
                ),
                child: Padding(padding: widget.padding, child: widget.child),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ArenaSurfacePainter extends CustomPainter {
  const ArenaSurfacePainter({
    required this.accent,
    required this.selected,
    required this.prominent,
    required this.pressed,
    required this.enableGlow,
  });

  final Color accent;
  final bool selected;
  final bool prominent;
  final bool pressed;
  final bool enableGlow;

  Path _path(Size size, double inset) {
    final double cut = math.min(14.0, math.min(size.width, size.height) * .12);
    return Path()
      ..moveTo(inset + cut, inset)
      ..lineTo(size.width - inset - 8, inset)
      ..quadraticBezierTo(size.width - inset, inset, size.width - inset, inset + 8)
      ..lineTo(size.width - inset, size.height - inset - cut)
      ..lineTo(size.width - inset - cut, size.height - inset)
      ..lineTo(inset + 8, size.height - inset)
      ..quadraticBezierTo(inset, size.height - inset, inset, size.height - inset - 8)
      ..lineTo(inset, inset + cut)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final Rect rect = Offset.zero & size;
    final Path outer = _path(size, 1);
    final Path inner = _path(size, prominent ? 8 : 7);
    final double state = pressed ? .72 : 1;
    final double lift = pressed ? 3 : (prominent ? 11 : 7);

    canvas.drawShadow(
      outer.shift(Offset(0, lift)),
      const Color(0xE6000000),
      prominent ? 18 : 13,
      false,
    );
    if (enableGlow && (selected || prominent)) {
      canvas.drawPath(
        outer,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = prominent ? 7 : 5
          ..color = accent.withValues(alpha: .12 * state)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
    }
    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF213A5D), Color(0xFF0A1527), Color(0xFF02060E)],
          stops: <double>[0, .54, 1],
        ).createShader(rect),
    );
    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = selected
            ? accent.withValues(alpha: .95 * state)
            : ArenaPalette.frame.withValues(alpha: .95),
    );
    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.lerp(ArenaPalette.surfaceTop, accent, selected ? .11 : .035)!,
            ArenaPalette.surfaceMid,
            ArenaPalette.surfaceBottom,
          ],
          stops: const <double>[0, .48, 1],
        ).createShader(rect),
    );
    canvas.drawRect(
      Rect.fromLTWH(10, 8, math.max(0.0, size.width - 20), 1),
      Paint()..color = Colors.white.withValues(alpha: .13 * state),
    );
    canvas.restore();
    canvas.drawLine(
      const Offset(18, 5.5),
      Offset(math.min(84.0, size.width * .34), 5.5),
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = prominent ? 2.8 : 2
        ..color = accent.withValues(alpha: (selected || prominent ? .9 : .48) * state),
    );
  }

  @override
  bool shouldRepaint(covariant ArenaSurfacePainter oldDelegate) {
    return oldDelegate.accent != accent ||
        oldDelegate.selected != selected ||
        oldDelegate.prominent != prominent ||
        oldDelegate.pressed != pressed ||
        oldDelegate.enableGlow != enableGlow;
  }
}

class ArenaHeader extends StatelessWidget {
  const ArenaHeader({
    required this.title,
    this.subtitle,
    this.icon,
    this.onBack,
    this.trailing,
    super.key,
  });

  final String title;
  final String? subtitle;
  final IconData? icon;
  final VoidCallback? onBack;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        if (onBack != null)
          SizedBox(
            width: 46,
            height: 46,
            child: ArenaSurface(
              padding: EdgeInsets.zero,
              onTap: onBack,
              semanticLabel: 'بازگشت',
              child: const Icon(Icons.arrow_forward_rounded, color: ArenaPalette.text),
            ),
          ),
        if (onBack != null) const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  if (icon != null) ...<Widget>[
                    Icon(icon, color: ArenaPalette.cyan, size: 22),
                    const SizedBox(width: 8),
                  ],
                  Flexible(child: Text(title, style: ArenaText.title)),
                ],
              ),
              if (subtitle != null) ...<Widget>[
                const SizedBox(height: 3),
                Text(subtitle!, style: ArenaText.caption),
              ],
            ],
          ),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}

class ArenaSectionTitle extends StatelessWidget {
  const ArenaSectionTitle({
    required this.title,
    this.subtitle,
    this.action,
    super.key,
  });

  final String title;
  final String? subtitle;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: ArenaText.section),
              if (subtitle != null) ...<Widget>[
                const SizedBox(height: 2),
                Text(subtitle!, style: ArenaText.caption),
              ],
            ],
          ),
        ),
        if (action != null) action!,
      ],
    );
  }
}

class ArenaProgressBar extends StatelessWidget {
  const ArenaProgressBar({
    required this.value,
    this.accent = ArenaPalette.cyan,
    this.height = 7,
    super.key,
  });

  final double value;
  final Color accent;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: SizedBox(
        height: height,
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            const ColoredBox(color: ArenaPalette.surfaceInset),
            FractionallySizedBox(
              alignment: Alignment.centerRight,
              widthFactor: value.clamp(0.0, 1.0).toDouble(),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: <Color>[accent, Color.lerp(accent, Colors.white, .32)!]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ArenaChip extends StatelessWidget {
  const ArenaChip({
    required this.label,
    this.icon,
    this.accent = ArenaPalette.cyan,
    this.selected = false,
    this.onTap,
    super.key,
  });

  final String label;
  final IconData? icon;
  final Color accent;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: accent,
      selected: selected,
      onTap: onTap,
      enableGlow: false,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (icon != null) ...<Widget>[
            Icon(icon, color: selected ? accent : ArenaPalette.textSoft, size: 17),
            const SizedBox(width: 6),
          ],
          Text(
            label,
            style: ArenaText.caption.copyWith(
              color: selected ? ArenaPalette.text : ArenaPalette.textSoft,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class ArenaPrimaryButton extends StatelessWidget {
  const ArenaPrimaryButton({
    required this.label,
    required this.onTap,
    this.icon = Icons.play_arrow_rounded,
    this.accent = ArenaPalette.gold,
    this.height = 72,
    super.key,
  });

  final String label;
  final VoidCallback onTap;
  final IconData icon;
  final Color accent;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: ArenaSurface(
        accent: accent,
        prominent: true,
        selected: true,
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
        child: Row(
          children: <Widget>[
            Icon(icon, color: Colors.black, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const Icon(Icons.chevron_left_rounded, color: Colors.black, size: 30),
          ],
        ),
      ),
    );
  }
}

class ArenaEmptyState extends StatelessWidget {
  const ArenaEmptyState({
    required this.icon,
    required this.title,
    required this.message,
    super.key,
  });

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      enableGlow: false,
      padding: const EdgeInsets.all(22),
      child: Column(
        children: <Widget>[
          Icon(icon, color: ArenaPalette.textMuted, size: 42),
          const SizedBox(height: 12),
          Text(title, style: ArenaText.section, textAlign: TextAlign.center),
          const SizedBox(height: 6),
          Text(message, style: ArenaText.body, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
