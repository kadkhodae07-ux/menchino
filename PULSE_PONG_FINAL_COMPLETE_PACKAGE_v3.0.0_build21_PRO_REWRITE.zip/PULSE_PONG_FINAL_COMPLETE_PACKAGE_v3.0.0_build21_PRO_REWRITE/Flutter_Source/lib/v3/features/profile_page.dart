import 'package:flutter/material.dart';

import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({
    required this.progress,
    required this.onEdit,
    required this.onBack,
    super.key,
  });

  final PlayerProgressController progress;
  final VoidCallback onEdit;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return ArenaPage(
      allowScroll: true,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 30),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              ArenaHeader(
                title: 'پروفایل بازیکن',
                subtitle: 'آمار، پیشرفت و سوابق مسابقه',
                icon: Icons.person_rounded,
                onBack: onBack,
                trailing: ArenaChip(
                  label: 'ویرایش',
                  icon: Icons.edit_rounded,
                  onTap: onEdit,
                ),
              ),
              const SizedBox(height: 18),
              _Hero(progress: progress),
              const SizedBox(height: 16),
              const ArenaSectionTitle(title: 'عملکرد کلی'),
              const SizedBox(height: 10),
              _StatsGrid(progress: progress),
              const SizedBox(height: 16),
              const ArenaSectionTitle(
                title: 'مسابقه‌های اخیر',
                subtitle: 'شش نتیجه آخر ذخیره‌شده روی دستگاه',
              ),
              const SizedBox(height: 10),
              if (progress.recentMatches.isEmpty)
                const ArenaEmptyState(
                  icon: Icons.sports_esports_rounded,
                  title: 'هنوز مسابقه‌ای ثبت نشده',
                  message: 'پس از پایان اولین نبرد رقابتی، نتیجه و امتیاز اینجا نمایش داده می‌شود.',
                )
              else
                _RecentMatches(matches: progress.recentMatches),
              const SizedBox(height: 16),
              const ArenaSectionTitle(title: 'نشان‌های مهارتی'),
              const SizedBox(height: 10),
              _Achievements(progress: progress),
            ],
          ),
        ),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  const _Hero({required this.progress});
  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: ArenaPalette.cyan,
      selected: true,
      padding: const EdgeInsets.all(18),
      child: Row(
        children: <Widget>[
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[ArenaPalette.cyan, ArenaPalette.blue],
              ),
              border: Border.all(color: Colors.white.withValues(alpha: .36), width: 2),
              boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x4821C7F4), blurRadius: 18)],
            ),
            child: const Icon(Icons.person_rounded, color: Colors.white, size: 45),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(progress.playerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: ArenaText.title),
                const SizedBox(height: 3),
                Text('سطح ${progress.level} • لیگ ${progress.leagueName}', style: ArenaText.body),
                const SizedBox(height: 10),
                ArenaProgressBar(value: progress.levelProgress, height: 8),
                const SizedBox(height: 5),
                Text(
                  '${_digits(progress.levelXp)} از ${_digits(progress.nextLevelXp)} تجربه تا سطح بعد',
                  style: ArenaText.caption,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatsGrid extends StatelessWidget {
  const _StatsGrid({required this.progress});
  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    final List<({String label, String value, IconData icon, Color accent})> items = <({String label, String value, IconData icon, Color accent})>[
      (label: 'مسابقه', value: '${progress.matches}', icon: Icons.sports_esports_rounded, accent: ArenaPalette.cyan),
      (label: 'برد', value: '${progress.wins}', icon: Icons.emoji_events_rounded, accent: ArenaPalette.gold),
      (label: 'نرخ برد', value: progress.matches == 0 ? '—' : '${(progress.winRate * 100).round()}٪', icon: Icons.query_stats_rounded, accent: ArenaPalette.success),
      (label: 'گل زده', value: '${progress.goals}', icon: Icons.sports_score_rounded, accent: ArenaPalette.blue),
      (label: 'ضربه دقیق', value: '${progress.perfectHits}', icon: Icons.gps_fixed_rounded, accent: ArenaPalette.cyan),
      (label: 'قدرت مصرفی', value: '${progress.powersUsed}', icon: Icons.bolt_rounded, accent: ArenaPalette.gold),
    ];
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double width = (constraints.maxWidth - 10) / 2;
        return Wrap(
          spacing: 10,
          runSpacing: 10,
          children: items.map((item) {
            return SizedBox(
              width: width,
              height: 92,
              child: ArenaSurface(
                accent: item.accent,
                enableGlow: false,
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: <Widget>[
                    Icon(item.icon, color: item.accent, size: 25),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(item.value, textDirection: TextDirection.ltr, style: ArenaText.title.copyWith(fontSize: 21)),
                          Text(item.label, style: ArenaText.caption),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(growable: false),
        );
      },
    );
  }
}

class _RecentMatches extends StatelessWidget {
  const _RecentMatches({required this.matches});
  final List<Map<String, Object>> matches;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: ArenaPalette.blue,
      enableGlow: false,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Column(
        children: matches.map((Map<String, Object> match) {
          final bool won = match['won'] == true;
          final int player = (match['playerScore'] as num?)?.toInt() ?? 0;
          final int bot = (match['botScore'] as num?)?.toInt() ?? 0;
          final int millis = (match['playedAt'] as num?)?.toInt() ?? 0;
          final DateTime date = DateTime.fromMillisecondsSinceEpoch(millis);
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: <Widget>[
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (won ? ArenaPalette.success : ArenaPalette.danger).withValues(alpha: .14),
                    border: Border.all(color: (won ? ArenaPalette.success : ArenaPalette.danger).withValues(alpha: .48)),
                  ),
                  child: Icon(won ? Icons.check_rounded : Icons.close_rounded, color: won ? ArenaPalette.success : ArenaPalette.danger, size: 20),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(won ? 'پیروزی' : 'شکست', style: ArenaText.section.copyWith(fontSize: 13.5)),
                      Text(_dateLabel(date), style: ArenaText.caption),
                    ],
                  ),
                ),
                Text('$player  -  $bot', textDirection: TextDirection.ltr, style: ArenaText.title.copyWith(fontSize: 19)),
              ],
            ),
          );
        }).toList(growable: false),
      ),
    );
  }

  static String _dateLabel(DateTime date) {
    final DateTime now = DateTime.now();
    final Duration difference = now.difference(date);
    if (difference.inMinutes < 1) return 'همین حالا';
    if (difference.inHours < 1) return '${difference.inMinutes} دقیقه پیش';
    if (difference.inDays < 1) return '${difference.inHours} ساعت پیش';
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
  }
}

class _Achievements extends StatelessWidget {
  const _Achievements({required this.progress});
  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    final List<({String title, String target, bool unlocked, IconData icon})> badges = <({String title, String target, bool unlocked, IconData icon})>[
      (title: 'اولین پیروزی', target: 'یک مسابقه را ببر', unlocked: progress.wins >= 1, icon: Icons.military_tech_rounded),
      (title: 'ضربه‌زن دقیق', target: '۱۰ ضربه دقیق ثبت کن', unlocked: progress.perfectHits >= 10, icon: Icons.gps_fixed_rounded),
      (title: 'رقیب جدی', target: '۲۵ مسابقه انجام بده', unlocked: progress.matches >= 25, icon: Icons.local_fire_department_rounded),
      (title: 'فرمانده لیگ', target: 'به لیگ طلایی برس', unlocked: progress.leagueScore >= 2000, icon: Icons.workspace_premium_rounded),
    ];
    return Column(
      children: badges.map((badge) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: ArenaSurface(
            accent: badge.unlocked ? ArenaPalette.gold : ArenaPalette.textMuted,
            enableGlow: false,
            padding: const EdgeInsets.all(13),
            child: Row(
              children: <Widget>[
                Icon(badge.icon, color: badge.unlocked ? ArenaPalette.gold : ArenaPalette.textMuted, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(badge.title, style: ArenaText.section.copyWith(fontSize: 13.5)),
                      Text(badge.target, style: ArenaText.caption),
                    ],
                  ),
                ),
                Icon(
                  badge.unlocked ? Icons.verified_rounded : Icons.lock_outline_rounded,
                  color: badge.unlocked ? ArenaPalette.success : ArenaPalette.textMuted,
                ),
              ],
            ),
          ),
        );
      }).toList(growable: false),
    );
  }
}

String _digits(int value) {
  return value.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => '٬');
}
