import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

class LobbyPage extends StatelessWidget {
  const LobbyPage({
    required this.progress,
    required this.ambient,
    required this.onPlay,
    required this.onProfile,
    required this.onSettings,
    required this.onMissions,
    required this.onRanking,
    required this.onShop,
    super.key,
  });

  final PlayerProgressController progress;
  final Animation<double> ambient;
  final VoidCallback onPlay;
  final VoidCallback onProfile;
  final VoidCallback onSettings;
  final VoidCallback onMissions;
  final VoidCallback onRanking;
  final VoidCallback onShop;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final bool compact = constraints.maxWidth < 390;
        final double side = compact ? 10 : 14;
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.fromLTRB(side, 8, side, 22),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                children: <Widget>[
                  _LobbyTopBar(
                    progress: progress,
                    compact: compact,
                    onProfile: onProfile,
                    onSettings: onSettings,
                    onShop: onShop,
                  ),
                  SizedBox(height: compact ? 14 : 18),
                  const _BrandLockup(),
                  SizedBox(height: compact ? 10 : 14),
                  SizedBox(
                    height: compact ? 190 : 218,
                    child: _ArenaPreview(ambient: ambient),
                  ),
                  SizedBox(height: compact ? 14 : 18),
                  ArenaPrimaryButton(label: 'شروع مسابقه', onTap: onPlay),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: _ActionCard(
                          icon: Icons.flag_rounded,
                          title: 'ماموریت‌ها',
                          subtitle: _missionSubtitle(progress),
                          accent: ArenaPalette.cyan,
                          onTap: onMissions,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _ActionCard(
                          icon: Icons.emoji_events_rounded,
                          title: 'لیگ آفلاین',
                          subtitle: '${progress.leagueName} • رتبه ${progress.offlineRank}',
                          accent: ArenaPalette.gold,
                          onTap: onRanking,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _LoadoutStrip(progress: progress, onTap: onShop),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  static String _missionSubtitle(PlayerProgressController progress) {
    final int done = <bool>[
      progress.dailyMatchesProgress >= 2,
      progress.dailyPerfectHitsProgress >= 3,
      progress.dailyPowersProgress >= 2,
    ].where((bool value) => value).length;
    return '$done از ۳ ماموریت روزانه';
  }
}

class _LobbyTopBar extends StatelessWidget {
  const _LobbyTopBar({
    required this.progress,
    required this.compact,
    required this.onProfile,
    required this.onSettings,
    required this.onShop,
  });

  final PlayerProgressController progress;
  final bool compact;
  final VoidCallback onProfile;
  final VoidCallback onSettings;
  final VoidCallback onShop;

  @override
  Widget build(BuildContext context) {
    final Widget profile = SizedBox(
      height: 72,
      child: ArenaSurface(
        accent: ArenaPalette.cyan,
        onTap: onProfile,
        semanticLabel: 'پروفایل بازیکن',
        padding: const EdgeInsets.fromLTRB(10, 8, 12, 8),
        child: Row(
          children: <Widget>[
            SizedBox(
              width: 52,
              height: 52,
              child: CustomPaint(
                painter: _AvatarPainter(level: progress.level),
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    progress.playerName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: ArenaText.section.copyWith(fontSize: 13.5),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'سطح ${progress.level} • ${_format(progress.levelXp)} از ${_format(progress.nextLevelXp)} XP',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: ArenaText.caption.copyWith(fontSize: 10.5),
                  ),
                  const SizedBox(height: 6),
                  ArenaProgressBar(value: progress.levelProgress, height: 6),
                ],
              ),
            ),
          ],
        ),
      ),
    );
    final Widget settings = SizedBox(
      width: 54,
      height: 54,
      child: ArenaSurface(
        accent: ArenaPalette.textSoft,
        onTap: onSettings,
        semanticLabel: 'تنظیمات',
        padding: EdgeInsets.zero,
        child: const Icon(
          Icons.settings_rounded,
          color: ArenaPalette.text,
          size: 27,
        ),
      ),
    );

    if (compact) {
      return Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(child: profile),
              const SizedBox(width: 9),
              settings,
            ],
          ),
          const SizedBox(height: 9),
          Row(
            children: <Widget>[
              Expanded(
                child: _CurrencyButton(
                  icon: Icons.bolt_rounded,
                  value: progress.energy,
                  accent: ArenaPalette.gold,
                  onTap: onShop,
                  semanticLabel: 'انرژی',
                  expanded: true,
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: _CurrencyButton(
                  icon: Icons.hexagon_rounded,
                  value: progress.pulse,
                  accent: ArenaPalette.cyan,
                  onTap: onShop,
                  semanticLabel: 'پالس',
                  expanded: true,
                ),
              ),
            ],
          ),
        ],
      );
    }

    return Row(
      children: <Widget>[
        Expanded(child: profile),
        const SizedBox(width: 9),
        _CurrencyButton(
          icon: Icons.bolt_rounded,
          value: progress.energy,
          accent: ArenaPalette.gold,
          onTap: onShop,
          semanticLabel: 'انرژی',
        ),
        const SizedBox(width: 8),
        _CurrencyButton(
          icon: Icons.hexagon_rounded,
          value: progress.pulse,
          accent: ArenaPalette.cyan,
          onTap: onShop,
          semanticLabel: 'پالس',
        ),
        const SizedBox(width: 8),
        settings,
      ],
    );
  }

  static String _format(int value) {
    return value.toString().replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (_) => '٬',
    );
  }
}

class _CurrencyButton extends StatelessWidget {
  const _CurrencyButton({
    required this.icon,
    required this.value,
    required this.accent,
    required this.onTap,
    required this.semanticLabel,
    this.expanded = false,
  });

  final IconData icon;
  final int value;
  final Color accent;
  final VoidCallback onTap;
  final String semanticLabel;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: expanded ? double.infinity : 67,
      height: 54,
      child: ArenaSurface(
        accent: accent,
        onTap: onTap,
        semanticLabel: semanticLabel,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: accent, size: 19),
            const SizedBox(height: 1),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                _compact(value),
                textDirection: TextDirection.ltr,
                style: ArenaText.caption.copyWith(color: ArenaPalette.text, fontSize: 10.5),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static String _compact(int value) {
    if (value >= 1000000) return '${(value / 1000000).toStringAsFixed(1)}M';
    if (value >= 10000) return '${(value / 1000).toStringAsFixed(1)}K';
    return value.toString();
  }
}

class _BrandLockup extends StatelessWidget {
  const _BrandLockup();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ShaderMask(
          shaderCallback: (Rect bounds) => const LinearGradient(
            colors: <Color>[Color(0xFFEAF8FF), Color(0xFF8EDFFF), ArenaPalette.goldLight],
            stops: <double>[0, .68, 1],
          ).createShader(bounds),
          child: const Text(
            'PULSE PONG',
            textDirection: TextDirection.ltr,
            style: TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.5,
              shadows: <Shadow>[Shadow(color: Color(0xB0000000), blurRadius: 12, offset: Offset(0, 5))],
            ),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          'نبرد سریع، کنترل دقیق، رقابت واقعی',
          style: ArenaText.caption.copyWith(color: ArenaPalette.textSoft),
        ),
      ],
    );
  }
}

class _ArenaPreview extends StatelessWidget {
  const _ArenaPreview({required this.ambient});
  final Animation<double> ambient;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: ArenaPalette.blue,
      prominent: true,
      enableGlow: false,
      padding: const EdgeInsets.all(8),
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const RepaintBoundary(child: CustomPaint(painter: _PreviewArenaPainter())),
          RepaintBoundary(
            child: AnimatedBuilder(
              animation: ambient,
              builder: (BuildContext context, Widget? child) {
                final double phase = ambient.value * math.pi * 2;
                return CustomPaint(painter: _PreviewBallPainter(phase: phase));
              },
            ),
          ),
          Positioned(
            right: 12,
            top: 10,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xC6071020),
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: ArenaPalette.divider),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(color: ArenaPalette.success, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 6),
                    Text('آماده مسابقه', style: ArenaText.caption.copyWith(fontSize: 10.5)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewArenaPainter extends CustomPainter {
  const _PreviewArenaPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect field = RRect.fromRectAndRadius(rect.deflate(5), const Radius.circular(12));
    canvas.drawRRect(
      field,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF0D2748), Color(0xFF07172C), Color(0xFF030A15)],
        ).createShader(rect),
    );
    final Paint grid = Paint()..color = const Color(0x185B9FDF)..strokeWidth = .7;
    for (int i = 1; i < 8; i++) {
      final double y = rect.height * i / 8;
      canvas.drawLine(Offset(6, y), Offset(size.width - 6, y), grid);
    }
    for (int i = 1; i < 12; i++) {
      final double x = rect.width * i / 12;
      canvas.drawLine(Offset(x, 6), Offset(x, size.height - 6), grid);
    }
    final Paint center = Paint()..color = const Color(0x80DCEBFF)..strokeWidth = 1.4;
    for (double y = 12; y < size.height - 12; y += 17) {
      canvas.drawLine(Offset(size.width / 2, y), Offset(size.width / 2, math.min(y + 8, size.height - 12)), center);
    }
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(20, size.height / 2), width: 9, height: size.height * .34),
        const Radius.circular(5),
      ),
      Paint()..color = ArenaPalette.cyan,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(size.width - 20, size.height / 2), width: 9, height: size.height * .34),
        const Radius.circular(5),
      ),
      Paint()..color = ArenaPalette.gold,
    );
    canvas.drawRRect(
      field,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = ArenaPalette.frame,
    );
    canvas.drawLine(
      const Offset(6, 18),
      Offset(6, size.height - 18),
      Paint()..color = ArenaPalette.cyan..strokeWidth = 2.5,
    );
    canvas.drawLine(
      Offset(size.width - 6, 18),
      Offset(size.width - 6, size.height - 18),
      Paint()..color = ArenaPalette.gold..strokeWidth = 2.5,
    );
  }

  @override
  bool shouldRepaint(covariant _PreviewArenaPainter oldDelegate) => false;
}

class _PreviewBallPainter extends CustomPainter {
  const _PreviewBallPainter({required this.phase});
  final double phase;

  @override
  void paint(Canvas canvas, Size size) {
    final double x = size.width * (.5 + math.sin(phase) * .28);
    final double y = size.height * (.5 + math.sin(phase * 1.7) * .20);
    final Offset center = Offset(x, y);
    canvas.drawCircle(
      center,
      13,
      Paint()
        ..color = const Color(0x5521C7F4)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawCircle(
      center,
      7,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-.35, -.35),
          colors: <Color>[Colors.white, Color(0xFFD2E8FF), ArenaPalette.blue],
        ).createShader(Rect.fromCircle(center: center, radius: 7)),
    );
  }

  @override
  bool shouldRepaint(covariant _PreviewBallPainter oldDelegate) => oldDelegate.phase != phase;
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accent,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 112,
      child: ArenaSurface(
        accent: accent,
        onTap: onTap,
        padding: const EdgeInsets.all(13),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Icon(icon, color: accent, size: 26),
                const Spacer(),
                const Icon(Icons.chevron_left_rounded, color: ArenaPalette.textMuted),
              ],
            ),
            const Spacer(),
            Text(title, style: ArenaText.section),
            const SizedBox(height: 2),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: ArenaText.caption),
          ],
        ),
      ),
    );
  }
}

class _LoadoutStrip extends StatelessWidget {
  const _LoadoutStrip({required this.progress, required this.onTap});
  final PlayerProgressController progress;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final String paddle = _label(progress.selectedItems['paddle']);
    final String ball = _label(progress.selectedItems['ball']);
    final String effect = _label(progress.selectedItems['effect']);
    return ArenaSurface(
      accent: ArenaPalette.blue,
      enableGlow: false,
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: <Widget>[
          const Icon(Icons.tune_rounded, color: ArenaPalette.cyan, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('تجهیزات فعال', style: ArenaText.section.copyWith(fontSize: 13.5)),
                const SizedBox(height: 3),
                Text('$paddle • $ball • $effect', maxLines: 1, overflow: TextOverflow.ellipsis, style: ArenaText.caption),
              ],
            ),
          ),
          const Icon(Icons.chevron_left_rounded, color: ArenaPalette.textMuted),
        ],
      ),
    );
  }

  static String _label(String? id) {
    return switch (id) {
      'paddle:phantom' => 'راکت فانتوم',
      'paddle:titan' => 'راکت تایتان',
      'paddle:crystal' => 'راکت کریستال',
      'paddle:nova' => 'راکت نوا',
      'ball:solar' => 'توپ خورشیدی',
      'ball:shadow' => 'توپ سایه',
      'ball:quantum' => 'توپ کوانتوم',
      'ball:plasma' => 'توپ پلاسما',
      'effect:neon_burst' => 'انفجار نوری',
      'effect:gold_wave' => 'موج طلایی',
      'effect:space_rift' => 'شکاف فضایی',
      'effect:pulse_trail' => 'رد پالس',
      _ => 'تجهیزات پایه',
    };
  }
}

class _AvatarPainter extends CustomPainter {
  const _AvatarPainter({required this.level});
  final int level;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    canvas.drawCircle(
      center,
      size.shortestSide * .49,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[ArenaPalette.cyan, ArenaPalette.blue],
        ).createShader(Offset.zero & size),
    );
    canvas.drawCircle(center, size.shortestSide * .42, Paint()..color = const Color(0xFF071425));
    canvas.drawCircle(Offset(center.dx, center.dy - 5), 10, Paint()..color = const Color(0xFFFFC59E));
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(center.dx, center.dy + 13), width: 25, height: 17),
        const Radius.circular(8),
      ),
      Paint()
        ..shader = const LinearGradient(colors: <Color>[ArenaPalette.cyan, ArenaPalette.blue]).createShader(Offset.zero & size),
    );
    final TextPainter label = TextPainter(
      text: TextSpan(
        text: '$level',
        style: const TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.w900),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    final Rect badge = Rect.fromCircle(center: Offset(size.width - 8, size.height - 8), radius: 8);
    canvas.drawCircle(badge.center, 8, Paint()..color = ArenaPalette.gold);
    label.paint(canvas, badge.center - Offset(label.width / 2, label.height / 2));
  }

  @override
  bool shouldRepaint(covariant _AvatarPainter oldDelegate) => oldDelegate.level != level;
}
