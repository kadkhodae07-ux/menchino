import 'package:flutter/material.dart';

import '../../game/config/game_config.dart';
import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

enum _SelectedMode { competitive, training, localDuel }

class ModeSelectionPage extends StatefulWidget {
  const ModeSelectionPage({
    required this.progress,
    required this.onStart,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<GameConfig> onStart;

  @override
  State<ModeSelectionPage> createState() => _ModeSelectionPageState();
}

class _ModeSelectionPageState extends State<ModeSelectionPage> {
  _SelectedMode _mode = _SelectedMode.competitive;
  late BotDifficulty _difficulty;

  @override
  void initState() {
    super.initState();
    _difficulty = widget.progress.difficulty;
  }

  GameConfig get _config {
    return switch (_mode) {
      _SelectedMode.competitive => GameConfig.forDifficulty(_difficulty),
      _SelectedMode.training => GameConfig.training(),
      _SelectedMode.localDuel => GameConfig.localDuel(),
    };
  }

  @override
  Widget build(BuildContext context) {
    return ArenaPage(
      allowScroll: true,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 28),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              ArenaHeader(
                title: 'انتخاب مسابقه',
                subtitle: 'حالت بازی و سطح رقیب را مشخص کن',
                icon: Icons.sports_esports_rounded,
                onBack: () => Navigator.of(context).pop(),
              ),
              const SizedBox(height: 18),
              _ModeCard(
                selected: _mode == _SelectedMode.competitive,
                accent: ArenaPalette.cyan,
                icon: Icons.smart_toy_rounded,
                title: 'نبرد رقابتی',
                subtitle: 'مسابقه کامل با ثبت آمار، لیگ و پاداش',
                details: 'هدف ۱۰ امتیاز • سه قدرت فعال • ثبت نتیجه',
                onTap: () => setState(() => _mode = _SelectedMode.competitive),
              ),
              const SizedBox(height: 12),
              _ModeCard(
                selected: _mode == _SelectedMode.training,
                accent: ArenaPalette.blue,
                icon: Icons.fitness_center_rounded,
                title: 'تمرین آزاد',
                subtitle: 'تمرین کنترل و زمان‌بندی بدون تغییر آمار',
                details: 'هدف ۵ امتیاز • قدرت نامحدود • بدون پاداش',
                onTap: () => setState(() => _mode = _SelectedMode.training),
              ),
              const SizedBox(height: 12),
              _ModeCard(
                selected: _mode == _SelectedMode.localDuel,
                accent: ArenaPalette.gold,
                icon: Icons.people_alt_rounded,
                title: 'دونفره محلی',
                subtitle: 'دو بازیکن روی یک گوشی در حالت افقی',
                details: 'کنترل مستقل دو نیمه • هدف ۱۰ امتیاز • بدون قدرت',
                onTap: () => setState(() => _mode = _SelectedMode.localDuel),
              ),
              if (_mode == _SelectedMode.competitive) ...<Widget>[
                const SizedBox(height: 18),
                const ArenaSectionTitle(
                  title: 'سطح رقیب',
                  subtitle: 'دشواری بالاتر، پاداش و امتیاز لیگ بیشتری می‌دهد',
                ),
                const SizedBox(height: 10),
                _DifficultySelector(
                  value: _difficulty,
                  onChanged: (BotDifficulty value) {
                    widget.progress.setDifficulty(value);
                    setState(() => _difficulty = value);
                  },
                ),
              ],
              const SizedBox(height: 18),
              _MatchSummary(mode: _mode, difficulty: _difficulty),
              const SizedBox(height: 18),
              ArenaPrimaryButton(
                label: _mode == _SelectedMode.localDuel
                    ? 'آماده‌سازی مسابقه دونفره'
                    : 'ورود به زمین',
                onTap: () => widget.onStart(_config),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.selected,
    required this.accent,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.details,
    required this.onTap,
  });

  final bool selected;
  final Color accent;
  final IconData icon;
  final String title;
  final String subtitle;
  final String details;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: accent,
      selected: selected,
      onTap: onTap,
      padding: const EdgeInsets.all(15),
      child: Row(
        children: <Widget>[
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[
                  accent.withValues(alpha: .32),
                  accent.withValues(alpha: .08),
                ],
              ),
              border: Border.all(color: accent.withValues(alpha: .48)),
            ),
            child: Icon(icon, color: accent, size: 28),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(child: Text(title, style: ArenaText.section)),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: selected ? accent : Colors.transparent,
                        border: Border.all(color: selected ? accent : ArenaPalette.textMuted),
                      ),
                      child: selected
                          ? const Icon(Icons.check_rounded, size: 14, color: Colors.black)
                          : null,
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(subtitle, style: ArenaText.body),
                const SizedBox(height: 7),
                Text(details, style: ArenaText.caption.copyWith(color: accent)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DifficultySelector extends StatelessWidget {
  const _DifficultySelector({required this.value, required this.onChanged});
  final BotDifficulty value;
  final ValueChanged<BotDifficulty> onChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: BotDifficulty.values.map((BotDifficulty item) {
        final Color accent = switch (item) {
          BotDifficulty.trainee => ArenaPalette.success,
          BotDifficulty.tactical => ArenaPalette.cyan,
          BotDifficulty.champion => ArenaPalette.gold,
        };
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: item == BotDifficulty.champion ? 0 : 8),
            child: ArenaSurface(
              accent: accent,
              selected: value == item,
              onTap: () => onChanged(item),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
              child: Column(
                children: <Widget>[
                  Icon(
                    switch (item) {
                      BotDifficulty.trainee => Icons.school_rounded,
                      BotDifficulty.tactical => Icons.track_changes_rounded,
                      BotDifficulty.champion => Icons.workspace_premium_rounded,
                    },
                    color: accent,
                    size: 24,
                  ),
                  const SizedBox(height: 6),
                  Text(item.title, style: ArenaText.caption.copyWith(color: ArenaPalette.text)),
                ],
              ),
            ),
          ),
        );
      }).toList(growable: false),
    );
  }
}

class _MatchSummary extends StatelessWidget {
  const _MatchSummary({required this.mode, required this.difficulty});
  final _SelectedMode mode;
  final BotDifficulty difficulty;

  @override
  Widget build(BuildContext context) {
    final List<({IconData icon, String label, String value})> rows = switch (mode) {
      _SelectedMode.competitive => <({IconData icon, String label, String value})>[
          (icon: Icons.flag_rounded, label: 'هدف مسابقه', value: '۱۰ امتیاز'),
          (icon: Icons.psychology_rounded, label: 'رقیب', value: difficulty.title),
          (icon: Icons.add_chart_rounded, label: 'ثبت پیشرفت', value: 'فعال'),
        ],
      _SelectedMode.training => <({IconData icon, String label, String value})>[
          (icon: Icons.flag_rounded, label: 'هدف مسابقه', value: '۵ امتیاز'),
          (icon: Icons.bolt_rounded, label: 'قدرت‌ها', value: 'نامحدود'),
          (icon: Icons.add_chart_rounded, label: 'ثبت پیشرفت', value: 'غیرفعال'),
        ],
      _SelectedMode.localDuel => <({IconData icon, String label, String value})>[
          (icon: Icons.flag_rounded, label: 'هدف مسابقه', value: '۱۰ امتیاز'),
          (icon: Icons.touch_app_rounded, label: 'کنترل', value: 'دو ناحیه مستقل'),
          (icon: Icons.bolt_rounded, label: 'قدرت‌ها', value: 'غیرفعال'),
        ],
    };
    return ArenaSurface(
      accent: ArenaPalette.blue,
      enableGlow: false,
      padding: const EdgeInsets.all(14),
      child: Column(
        children: rows.map((({IconData icon, String label, String value}) row) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              children: <Widget>[
                Icon(row.icon, color: ArenaPalette.cyan, size: 19),
                const SizedBox(width: 8),
                Text(row.label, style: ArenaText.body),
                const Spacer(),
                Text(row.value, style: ArenaText.section.copyWith(fontSize: 13.5)),
              ],
            ),
          );
        }).toList(growable: false),
      ),
    );
  }
}
