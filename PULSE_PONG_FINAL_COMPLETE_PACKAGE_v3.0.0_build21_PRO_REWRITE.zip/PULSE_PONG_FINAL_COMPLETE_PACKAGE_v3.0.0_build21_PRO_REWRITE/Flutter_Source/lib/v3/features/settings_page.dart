import 'dart:async';

import 'package:flutter/material.dart';

import '../../game/config/game_config.dart';
import '../../game/managers/audio_manager.dart';
import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    required this.progress,
    required this.onBack,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final VoidCallback onBack;
  final ValueChanged<String> onMessage;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    final PlayerProgressController progress = widget.progress;
    return ArenaPage(
      allowScroll: true,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 30),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              ArenaHeader(
                title: 'تنظیمات بازی',
                subtitle: 'کنترل صدا، تصویر، عملکرد و سطح رقیب',
                icon: Icons.settings_rounded,
                onBack: widget.onBack,
              ),
              const SizedBox(height: 18),
              const ArenaSectionTitle(title: 'صدا و بازخورد'),
              const SizedBox(height: 10),
              ArenaSurface(
                accent: ArenaPalette.blue,
                enableGlow: false,
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: <Widget>[
                    _ToggleRow(
                      icon: Icons.volume_up_rounded,
                      title: 'جلوه‌های صوتی',
                      subtitle: 'برخورد، امتیاز، دکمه و شمارش معکوس',
                      value: progress.soundEnabled,
                      onChanged: (bool value) {
                        progress.setSoundEnabled(value);
                        unawaited(AudioManager.instance.setSoundEnabled(value));
                        setState(() {});
                      },
                    ),
                    const _Divider(),
                    _VolumeRow(
                      icon: Icons.graphic_eq_rounded,
                      title: 'شدت جلوه‌ها',
                      value: progress.soundVolume,
                      enabled: progress.soundEnabled,
                      onChanged: (double value) {
                        progress.setSoundVolume(value);
                        unawaited(AudioManager.instance.setSoundVolume(value));
                        setState(() {});
                      },
                    ),
                    const _Divider(),
                    _ToggleRow(
                      icon: Icons.music_note_rounded,
                      title: 'موسیقی زمینه',
                      subtitle: 'موسیقی حلقه‌ای کم‌حجم در لابی و مسابقه',
                      value: progress.musicEnabled,
                      onChanged: (bool value) {
                        progress.setMusicEnabled(value);
                        unawaited(AudioManager.instance.setMusicEnabled(value));
                        setState(() {});
                      },
                    ),
                    const _Divider(),
                    _VolumeRow(
                      icon: Icons.multitrack_audio_rounded,
                      title: 'شدت موسیقی',
                      value: progress.musicVolume,
                      enabled: progress.musicEnabled,
                      onChanged: (double value) {
                        progress.setMusicVolume(value);
                        unawaited(AudioManager.instance.setMusicVolume(value));
                        setState(() {});
                      },
                    ),
                    const _Divider(),
                    _ToggleRow(
                      icon: Icons.vibration_rounded,
                      title: 'لرزش کنترل‌شده',
                      subtitle: 'بازخورد کوتاه برای ضربه‌های مهم و دکمه‌ها',
                      value: progress.vibrationEnabled,
                      onChanged: (bool value) {
                        progress.setVibrationEnabled(value);
                        AudioManager.instance.vibrationEnabled = value;
                        setState(() {});
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const ArenaSectionTitle(
                title: 'کنترل مسابقه',
                subtitle: 'حساسیت حرکت را متناسب با اندازه صفحه تنظیم کن',
              ),
              const SizedBox(height: 10),
              ArenaSurface(
                accent: ArenaPalette.cyan,
                enableGlow: false,
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    _VolumeRow(
                      icon: Icons.touch_app_rounded,
                      title: 'حساسیت لمس',
                      value: progress.controlSensitivity,
                      enabled: true,
                      onChanged: (double value) {
                        progress.setControlSensitivity(value);
                        setState(() {});
                      },
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'مقدار بالاتر، راکت را سریع‌تر به موقعیت انگشت می‌رساند. این گزینه روی سرعت فیزیکی توپ اثر ندارد.',
                      style: ArenaText.caption,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const ArenaSectionTitle(
                title: 'تصویر و عملکرد',
                subtitle: 'گزینه مناسب گوشی‌های متوسط، حالت ۶۰ فریم است',
              ),
              const SizedBox(height: 10),
              ArenaSurface(
                accent: ArenaPalette.cyan,
                enableGlow: false,
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text('کیفیت افکت‌ها', style: ArenaText.section.copyWith(fontSize: 13.5)),
                    const SizedBox(height: 9),
                    Row(
                      children: <Widget>[
                        Expanded(child: ArenaChip(label: 'اقتصادی', selected: progress.effectsQuality == 0, onTap: () => _setQuality(0))),
                        const SizedBox(width: 8),
                        Expanded(child: ArenaChip(label: 'متعادل', selected: progress.effectsQuality == 1, onTap: () => _setQuality(1))),
                        const SizedBox(width: 8),
                        Expanded(child: ArenaChip(label: 'کامل', selected: progress.effectsQuality == 2, onTap: () => _setQuality(2))),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text('نرخ فریم هدف', style: ArenaText.section.copyWith(fontSize: 13.5)),
                    const SizedBox(height: 9),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: ArenaChip(
                            label: '۶۰ فریم',
                            icon: Icons.speed_rounded,
                            selected: progress.frameRate == 60,
                            onTap: () => _setFrameRate(60),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ArenaChip(
                            label: '۹۰ فریم',
                            icon: Icons.bolt_rounded,
                            accent: ArenaPalette.gold,
                            selected: progress.frameRate == 90,
                            onTap: () => _setFrameRate(90),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'حالت ۹۰ فریم فقط روی نمایشگر سازگار فعال می‌شود. کنترل‌گر عملکرد در صورت افت پایدار، افکت‌های سنگین را کاهش می‌دهد.',
                      style: ArenaText.caption,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const ArenaSectionTitle(title: 'رقیب هوش مصنوعی'),
              const SizedBox(height: 10),
              ArenaSurface(
                accent: ArenaPalette.gold,
                enableGlow: false,
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: BotDifficulty.values.map((BotDifficulty difficulty) {
                    final bool selected = progress.difficulty == difficulty;
                    final Color accent = switch (difficulty) {
                      BotDifficulty.trainee => ArenaPalette.success,
                      BotDifficulty.tactical => ArenaPalette.cyan,
                      BotDifficulty.champion => ArenaPalette.gold,
                    };
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ArenaSurface(
                        accent: accent,
                        selected: selected,
                        onTap: () {
                          progress.setDifficulty(difficulty);
                          setState(() {});
                        },
                        enableGlow: false,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        child: Row(
                          children: <Widget>[
                            Icon(
                              switch (difficulty) {
                                BotDifficulty.trainee => Icons.school_rounded,
                                BotDifficulty.tactical => Icons.track_changes_rounded,
                                BotDifficulty.champion => Icons.workspace_premium_rounded,
                              },
                              color: accent,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(difficulty.title, style: ArenaText.section.copyWith(fontSize: 13.5)),
                                  Text(difficulty.description, style: ArenaText.caption),
                                ],
                              ),
                            ),
                            Icon(selected ? Icons.check_circle_rounded : Icons.circle_outlined, color: selected ? accent : ArenaPalette.textMuted),
                          ],
                        ),
                      ),
                    );
                  }).toList(growable: false),
                ),
              ),
              const SizedBox(height: 18),
              ArenaSurface(
                accent: ArenaPalette.blue,
                enableGlow: false,
                padding: const EdgeInsets.all(14),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('نسخه و ذخیره‌سازی', style: ArenaText.section),
                    SizedBox(height: 6),
                    Text('PULSE PONG • 3.0.0+21', textDirection: TextDirection.ltr, style: ArenaText.body),
                    SizedBox(height: 3),
                    Text('تمام پیشرفت‌ها روی همین دستگاه ذخیره می‌شوند و بازی در نسخه فعلی آفلاین است.', style: ArenaText.caption),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _setQuality(int value) {
    widget.progress.setEffectsQuality(value);
    setState(() {});
    widget.onMessage(value == 0 ? 'حالت اقتصادی فعال شد' : value == 1 ? 'کیفیت متعادل فعال شد' : 'کیفیت کامل فعال شد');
  }

  void _setFrameRate(int value) {
    widget.progress.setFrameRate(value);
    setState(() {});
    widget.onMessage('نرخ فریم هدف روی $value تنظیم شد');
  }
}

class _ToggleRow extends StatelessWidget {
  const _ToggleRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: <Widget>[
          Icon(icon, color: value ? ArenaPalette.cyan : ArenaPalette.textMuted, size: 23),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: ArenaText.section.copyWith(fontSize: 13.5)),
                Text(subtitle, style: ArenaText.caption),
              ],
            ),
          ),
          _ArenaSwitch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }
}

class _ArenaSwitch extends StatelessWidget {
  const _ArenaSwitch({required this.value, required this.onChanged});
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      toggled: value,
      button: true,
      child: GestureDetector(
        onTap: () => onChanged(!value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 48,
          height: 27,
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(99),
            color: value ? ArenaPalette.cyan.withValues(alpha: .28) : ArenaPalette.surfaceInset,
            border: Border.all(color: value ? ArenaPalette.cyan : ArenaPalette.divider),
          ),
          child: AnimatedAlign(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
            alignment: value ? Alignment.centerLeft : Alignment.centerRight,
            child: Container(
              width: 19,
              height: 19,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: value ? ArenaPalette.cyan : ArenaPalette.textMuted,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _VolumeRow extends StatelessWidget {
  const _VolumeRow({
    required this.icon,
    required this.title,
    required this.value,
    required this.enabled,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final double value;
  final bool enabled;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: <Widget>[
          Icon(icon, color: enabled ? ArenaPalette.cyan : ArenaPalette.textMuted, size: 23),
          const SizedBox(width: 11),
          SizedBox(width: 90, child: Text(title, style: ArenaText.caption.copyWith(color: enabled ? ArenaPalette.text : ArenaPalette.textMuted))),
          Expanded(
            child: _ArenaSlider(value: value, enabled: enabled, onChanged: onChanged),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 35,
            child: Text('${(value * 100).round()}٪', textAlign: TextAlign.left, style: ArenaText.caption),
          ),
        ],
      ),
    );
  }
}

class _ArenaSlider extends StatelessWidget {
  const _ArenaSlider({required this.value, required this.enabled, required this.onChanged});
  final double value;
  final bool enabled;
  final ValueChanged<double> onChanged;

  void _update(Offset position, double width) {
    if (!enabled || width <= 0) return;
    onChanged((1 - position.dx / width).clamp(0.0, 1.0).toDouble());
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: enabled ? (TapDownDetails details) => _update(details.localPosition, constraints.maxWidth) : null,
          onHorizontalDragUpdate: enabled ? (DragUpdateDetails details) => _update(details.localPosition, constraints.maxWidth) : null,
          child: SizedBox(
            height: 28,
            child: Stack(
              alignment: Alignment.center,
              children: <Widget>[
                Container(
                  height: 7,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(99),
                    color: ArenaPalette.surfaceInset,
                    border: Border.all(color: ArenaPalette.divider),
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: FractionallySizedBox(
                    widthFactor: value,
                    child: Container(
                      height: 7,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(99),
                        gradient: LinearGradient(
                          colors: <Color>[
                            enabled ? ArenaPalette.cyan : ArenaPalette.textMuted,
                            enabled ? ArenaPalette.blue : ArenaPalette.textMuted,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment(1 - value * 2, 0),
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: enabled ? ArenaPalette.cyan : ArenaPalette.textMuted,
                      border: Border.all(color: ArenaPalette.text, width: 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider();
  @override
  Widget build(BuildContext context) => const Divider(height: 1, color: ArenaPalette.divider);
}
