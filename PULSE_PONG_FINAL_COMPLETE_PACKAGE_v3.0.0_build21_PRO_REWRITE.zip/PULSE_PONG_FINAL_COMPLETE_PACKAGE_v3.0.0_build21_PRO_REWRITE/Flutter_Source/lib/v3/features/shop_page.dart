import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

enum _ShopCategory { paddle, ball, effect }

class ShopPage extends StatefulWidget {
  const ShopPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  _ShopCategory _category = _ShopCategory.paddle;

  static const List<_ShopItem> _items = <_ShopItem>[
    _ShopItem(id: 'paddle:nova', category: 'paddle', title: 'راکت نوا', description: 'متعادل و خوانا برای همه زمین‌ها', price: 0, accent: ArenaPalette.cyan, rarity: 'پایه'),
    _ShopItem(id: 'paddle:phantom', category: 'paddle', title: 'راکت فانتوم', description: 'بدنه سبک با هاله آبی یخی کنترل‌شده', price: 720, accent: Color(0xFF68A7FF), rarity: 'کمیاب'),
    _ShopItem(id: 'paddle:titan', category: 'paddle', title: 'راکت تایتان', description: 'قاب طلایی سنگین و صنعتی', price: 980, accent: ArenaPalette.gold, rarity: 'حماسی'),
    _ShopItem(id: 'paddle:crystal', category: 'paddle', title: 'راکت کریستال', description: 'لبه شفاف با درخشش فیروزه‌ای سرد', price: 1250, accent: Color(0xFF67D6C1), rarity: 'افسانه‌ای'),
    _ShopItem(id: 'ball:plasma', category: 'ball', title: 'توپ پلاسما', description: 'هسته آبی و رد پالس فیروزه‌ای', price: 0, accent: Color(0xFF5CA8FF), rarity: 'پایه'),
    _ShopItem(id: 'ball:solar', category: 'ball', title: 'توپ خورشیدی', description: 'هسته طلایی با بازتاب گرم', price: 640, accent: ArenaPalette.gold, rarity: 'کمیاب'),
    _ShopItem(id: 'ball:shadow', category: 'ball', title: 'توپ سایه', description: 'هسته تیره با مرز فولادی واضح', price: 870, accent: Color(0xFF6B7C99), rarity: 'حماسی'),
    _ShopItem(id: 'ball:quantum', category: 'ball', title: 'توپ کوانتوم', description: 'هاله دوگانه و رد حرکتی کوتاه', price: 1180, accent: Color(0xFF52D9E8), rarity: 'افسانه‌ای'),
    _ShopItem(id: 'effect:pulse_trail', category: 'effect', title: 'رد پالس', description: 'رد حرکتی کوتاه و کم‌مصرف', price: 0, accent: ArenaPalette.cyan, rarity: 'پایه'),
    _ShopItem(id: 'effect:neon_burst', category: 'effect', title: 'انفجار نوری', description: 'پاشش کوتاه هنگام برخورد دقیق', price: 590, accent: Color(0xFF4ED5A4), rarity: 'کمیاب'),
    _ShopItem(id: 'effect:gold_wave', category: 'effect', title: 'موج طلایی', description: 'موج حلقه‌ای هنگام ثبت امتیاز', price: 920, accent: ArenaPalette.gold, rarity: 'حماسی'),
    _ShopItem(id: 'effect:space_rift', category: 'effect', title: 'شکاف فضایی', description: 'رد آبی چندلایه با شدت کنترل‌شده', price: 1320, accent: Color(0xFF4C8BFF), rarity: 'افسانه‌ای'),
  ];

  @override
  Widget build(BuildContext context) {
    final String categoryKey = switch (_category) {
      _ShopCategory.paddle => 'paddle',
      _ShopCategory.ball => 'ball',
      _ShopCategory.effect => 'effect',
    };
    final List<_ShopItem> visible = _items.where((_ShopItem item) => item.category == categoryKey).toList(growable: false);
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 540),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              ArenaHeader(
                title: 'فروشگاه آرنا',
                subtitle: 'ظاهر تجهیزات را شخصی‌سازی کن؛ هیچ آیتمی قدرت پنهان نمی‌دهد',
                icon: Icons.storefront_rounded,
                trailing: ArenaChip(
                  label: '${widget.progress.pulse} پالس',
                  icon: Icons.hexagon_rounded,
                  accent: ArenaPalette.cyan,
                ),
              ),
              const SizedBox(height: 18),
              _LoadoutPreview(progress: widget.progress),
              const SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Expanded(child: ArenaChip(label: 'راکت‌ها', icon: Icons.view_week_rounded, selected: _category == _ShopCategory.paddle, onTap: () => setState(() => _category = _ShopCategory.paddle))),
                  const SizedBox(width: 8),
                  Expanded(child: ArenaChip(label: 'توپ‌ها', icon: Icons.circle, selected: _category == _ShopCategory.ball, onTap: () => setState(() => _category = _ShopCategory.ball))),
                  const SizedBox(width: 8),
                  Expanded(child: ArenaChip(label: 'افکت‌ها', icon: Icons.auto_awesome_rounded, selected: _category == _ShopCategory.effect, onTap: () => setState(() => _category = _ShopCategory.effect))),
                ],
              ),
              const SizedBox(height: 14),
              LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) {
                  final double width = (constraints.maxWidth - 10) / 2;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: visible.map((_ShopItem item) {
                      return SizedBox(
                        width: width,
                        child: _ShopCard(
                          item: item,
                          progress: widget.progress,
                          onTap: () => _buyOrEquip(item),
                        ),
                      );
                    }).toList(growable: false),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _buyOrEquip(_ShopItem item) {
    final bool owned = widget.progress.purchasedItems.contains(item.id);
    final bool selected = widget.progress.selectedItems[item.category] == item.id;
    if (selected) {
      widget.onMessage('این آیتم همین حالا فعال است');
      return;
    }
    if (owned) {
      widget.progress.selectItem(item.id, item.category);
      widget.onMessage('${item.title} تجهیز شد');
      return;
    }
    final bool ok = widget.progress.purchaseItem(item.id, item.category, item.price);
    widget.onMessage(ok ? '${item.title} خریداری و تجهیز شد' : 'پالس کافی برای خرید این آیتم وجود ندارد');
  }
}

class _LoadoutPreview extends StatelessWidget {
  const _LoadoutPreview({required this.progress});
  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 178,
      child: ArenaSurface(
        accent: ArenaPalette.blue,
        selected: true,
        enableGlow: false,
        padding: const EdgeInsets.all(10),
        child: CustomPaint(
          painter: _LoadoutPainter(
            paddleId: progress.selectedItems['paddle'],
            ballId: progress.selectedItems['ball'],
            effectId: progress.selectedItems['effect'],
          ),
          child: const Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: EdgeInsets.all(7),
              child: Text('پیش‌نمایش تجهیزات فعال', style: ArenaText.caption),
            ),
          ),
        ),
      ),
    );
  }
}

class _ShopCard extends StatelessWidget {
  const _ShopCard({required this.item, required this.progress, required this.onTap});
  final _ShopItem item;
  final PlayerProgressController progress;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool owned = progress.purchasedItems.contains(item.id);
    final bool selected = progress.selectedItems[item.category] == item.id;
    return SizedBox(
      height: 216,
      child: ArenaSurface(
        accent: item.accent,
        selected: selected,
        onTap: onTap,
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Expanded(
              child: CustomPaint(
                painter: _ItemPreviewPainter(item: item),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: item.accent.withValues(alpha: .13),
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(color: item.accent.withValues(alpha: .38)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: Text(item.rarity, style: ArenaText.caption.copyWith(color: item.accent, fontSize: 10)),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(item.title, style: ArenaText.section.copyWith(fontSize: 13.5)),
            const SizedBox(height: 2),
            Text(item.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: ArenaText.caption),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                Icon(selected ? Icons.check_circle_rounded : owned ? Icons.inventory_2_rounded : Icons.hexagon_rounded, color: selected ? ArenaPalette.success : item.accent, size: 18),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(
                    selected ? 'فعال' : owned ? 'تجهیز' : item.price == 0 ? 'رایگان' : '${item.price} پالس',
                    style: ArenaText.caption.copyWith(color: selected ? ArenaPalette.success : ArenaPalette.text),
                  ),
                ),
                const Icon(Icons.chevron_left_rounded, color: ArenaPalette.textMuted, size: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _LoadoutPainter extends CustomPainter {
  const _LoadoutPainter({required this.paddleId, required this.ballId, required this.effectId});
  final String? paddleId;
  final String? ballId;
  final String? effectId;

  Color get _paddle => switch (paddleId) {
    'paddle:phantom' => const Color(0xFF68A7FF),
    'paddle:titan' => ArenaPalette.gold,
    'paddle:crystal' => const Color(0xFF67D6C1),
    _ => ArenaPalette.cyan,
  };
  Color get _ball => switch (ballId) {
    'ball:solar' => ArenaPalette.gold,
    'ball:shadow' => const Color(0xFF6B7C99),
    'ball:quantum' => const Color(0xFF52D9E8),
    _ => const Color(0xFF5CA8FF),
  };
  Color get _effect => switch (effectId) {
    'effect:neon_burst' => const Color(0xFF4ED5A4),
    'effect:gold_wave' => ArenaPalette.gold,
    'effect:space_rift' => const Color(0xFF4C8BFF),
    _ => ArenaPalette.cyan,
  };

  @override
  void paint(Canvas canvas, Size size) {
    final Rect field = Rect.fromLTWH(7, 7, size.width - 14, size.height - 14);
    canvas.drawRRect(
      RRect.fromRectAndRadius(field, const Radius.circular(12)),
      Paint()
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF0E2949), Color(0xFF05101D)]).createShader(field),
    );
    final Paint grid = Paint()..color = const Color(0x185B9FDF)..strokeWidth = .6;
    for (int i = 1; i < 7; i++) {
      final double y = field.top + field.height * i / 7;
      canvas.drawLine(Offset(field.left, y), Offset(field.right, y), grid);
    }
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(field.left + 28, field.center.dy), width: 13, height: field.height * .45), const Radius.circular(6)),
      Paint()..color = _paddle,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(field.right - 28, field.center.dy), width: 13, height: field.height * .45), const Radius.circular(6)),
      Paint()..color = ArenaPalette.gold,
    );
    final Offset ball = field.center;
    canvas.drawLine(Offset(ball.dx - 50, ball.dy + 18), ball, Paint()..color = _effect.withValues(alpha: .46)..strokeWidth = 4..strokeCap = StrokeCap.round);
    canvas.drawCircle(ball, 13, Paint()..color = _effect.withValues(alpha: .16)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawCircle(ball, 7, Paint()..color = _ball);
    canvas.drawRRect(RRect.fromRectAndRadius(field, const Radius.circular(12)), Paint()..style = PaintingStyle.stroke..strokeWidth = 1.2..color = ArenaPalette.frame);
  }

  @override
  bool shouldRepaint(covariant _LoadoutPainter oldDelegate) => oldDelegate.paddleId != paddleId || oldDelegate.ballId != ballId || oldDelegate.effectId != effectId;
}

class _ItemPreviewPainter extends CustomPainter {
  const _ItemPreviewPainter({required this.item});
  final _ShopItem item;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2 + 8);
    canvas.drawCircle(center, 38, Paint()..color = item.accent.withValues(alpha: .10));
    if (item.category == 'paddle') {
      final Rect body = Rect.fromCenter(center: center, width: 25, height: 76);
      canvas.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(9)), Paint()..shader = LinearGradient(colors: <Color>[Colors.white, item.accent, Color.lerp(item.accent, Colors.black, .6)!]).createShader(body));
      canvas.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(9)), Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = item.accent);
    } else if (item.category == 'ball') {
      canvas.drawCircle(center, 27, Paint()..color = item.accent.withValues(alpha: .13)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));
      canvas.drawCircle(center, 16, Paint()..shader = RadialGradient(center: const Alignment(-.35, -.35), colors: <Color>[Colors.white, item.accent, Color.lerp(item.accent, Colors.black, .55)!]).createShader(Rect.fromCircle(center: center, radius: 16)));
    } else {
      for (int i = 0; i < 4; i++) {
        final double radius = 15 + i * 9;
        canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -math.pi * .8, math.pi * 1.25, false, Paint()..style = PaintingStyle.stroke..strokeWidth = math.max(1.0, 4 - i * .7)..color = item.accent.withValues(alpha: .78 - i * .14));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ItemPreviewPainter oldDelegate) => oldDelegate.item != item;
}

class _ShopItem {
  const _ShopItem({required this.id, required this.category, required this.title, required this.description, required this.price, required this.accent, required this.rarity});
  final String id;
  final String category;
  final String title;
  final String description;
  final int price;
  final Color accent;
  final String rarity;
}
