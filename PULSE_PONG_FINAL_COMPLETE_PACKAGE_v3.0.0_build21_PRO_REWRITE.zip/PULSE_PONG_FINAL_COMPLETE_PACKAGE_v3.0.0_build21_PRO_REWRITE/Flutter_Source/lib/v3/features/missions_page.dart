import 'package:flutter/material.dart';

import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

class MissionsPage extends StatelessWidget {
  const MissionsPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    final List<_Mission> daily = <_Mission>[
      _Mission(
        id: 'daily_matches',
        title: 'ورود به میدان',
        description: 'دو مسابقه رقابتی انجام بده',
        icon: Icons.sports_esports_rounded,
        progress: progress.dailyMatchesProgress,
        target: 2,
        reward: 80,
      ),
      _Mission(
        id: 'daily_perfect',
        title: 'ضربه دقیق',
        description: 'سه ضربه دقیق ثبت کن',
        icon: Icons.gps_fixed_rounded,
        progress: progress.dailyPerfectHitsProgress,
        target: 3,
        reward: 100,
      ),
      _Mission(
        id: 'daily_powers',
        title: 'کنترل انرژی',
        description: 'دو قدرت در مسابقه استفاده کن',
        icon: Icons.bolt_rounded,
        progress: progress.dailyPowersProgress,
        target: 2,
        reward: 90,
      ),
    ];
    final List<_Mission> weekly = <_Mission>[
      _Mission(
        id: 'weekly_wins',
        title: 'هفته پیروزی',
        description: 'هفت مسابقه را ببر',
        icon: Icons.emoji_events_rounded,
        progress: progress.weeklyWinsProgress,
        target: 7,
        reward: 350,
      ),
      _Mission(
        id: 'weekly_goals',
        title: 'مهاجم آرنا',
        description: 'چهل گل به ثمر برسان',
        icon: Icons.sports_score_rounded,
        progress: progress.weeklyGoalsProgress,
        target: 40,
        reward: 420,
      ),
      _Mission(
        id: 'weekly_powers',
        title: 'استاد قدرت‌ها',
        description: 'پانزده قدرت استفاده کن',
        icon: Icons.auto_awesome_rounded,
        progress: progress.weeklyPowersProgress,
        target: 15,
        reward: 380,
      ),
    ];

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const ArenaHeader(
                title: 'ماموریت‌ها',
                subtitle: 'هدف‌های روزانه و هفتگی با پاداش واقعی',
                icon: Icons.flag_rounded,
              ),
              const SizedBox(height: 18),
              _DailyReward(progress: progress, onMessage: onMessage),
              const SizedBox(height: 18),
              const ArenaSectionTitle(
                title: 'ماموریت‌های روزانه',
                subtitle: 'هر روز با ورود دوباره بازی تازه می‌شوند',
              ),
              const SizedBox(height: 10),
              ...daily.map((_Mission mission) => _MissionTile(
                    mission: mission,
                    period: 'daily',
                    progress: progress,
                    onMessage: onMessage,
                  )),
              const SizedBox(height: 12),
              const ArenaSectionTitle(
                title: 'ماموریت‌های هفتگی',
                subtitle: 'چرخه جدید از ابتدای هر هفته آغاز می‌شود',
              ),
              const SizedBox(height: 10),
              ...weekly.map((_Mission mission) => _MissionTile(
                    mission: mission,
                    period: 'weekly',
                    progress: progress,
                    onMessage: onMessage,
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

class _DailyReward extends StatelessWidget {
  const _DailyReward({required this.progress, required this.onMessage});
  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    final bool available = progress.canClaimDailyReward;
    return ArenaSurface(
      accent: ArenaPalette.gold,
      selected: available,
      prominent: available,
      onTap: available
          ? () {
              final bool claimed = progress.claimDailyReward();
              onMessage(claimed ? 'پاداش ورود روزانه دریافت شد' : 'پاداش امروز قبلاً دریافت شده است');
            }
          : null,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: <Widget>[
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: ArenaPalette.gold.withValues(alpha: .14),
              border: Border.all(color: ArenaPalette.gold.withValues(alpha: .48)),
            ),
            child: const Icon(Icons.card_giftcard_rounded, color: ArenaPalette.gold, size: 31),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('پاداش ورود روزانه', style: ArenaText.section),
                const SizedBox(height: 3),
                Text('۵۰ انرژی • ۱۰۰ پالس • ۲۰۰ تجربه', style: ArenaText.caption.copyWith(color: ArenaPalette.goldLight)),
                const SizedBox(height: 3),
                Text('زنجیره فعلی: ${progress.dailyRewardStreak} روز', style: ArenaText.caption),
              ],
            ),
          ),
          Icon(
            available ? Icons.redeem_rounded : Icons.check_circle_rounded,
            color: available ? ArenaPalette.gold : ArenaPalette.success,
          ),
        ],
      ),
    );
  }
}

class _MissionTile extends StatelessWidget {
  const _MissionTile({
    required this.mission,
    required this.period,
    required this.progress,
    required this.onMessage,
  });

  final _Mission mission;
  final String period;
  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    final String claimId = progress.missionClaimId(period, mission.id);
    final bool completed = mission.progress >= mission.target;
    final bool claimed = progress.claimedMissions.contains(claimId);
    final bool canClaim = completed && !claimed;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ArenaSurface(
        accent: canClaim ? ArenaPalette.gold : ArenaPalette.blue,
        selected: canClaim,
        onTap: canClaim
            ? () {
                final bool ok = progress.claimMission(claimId, mission.reward);
                onMessage(ok ? '${mission.reward} پالس دریافت شد' : 'این پاداش قبلاً دریافت شده است');
              }
            : null,
        enableGlow: canClaim,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: <Widget>[
            Icon(mission.icon, color: canClaim ? ArenaPalette.gold : ArenaPalette.cyan, size: 28),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(child: Text(mission.title, style: ArenaText.section.copyWith(fontSize: 13.5))),
                      Text('+${mission.reward} پالس', style: ArenaText.caption.copyWith(color: ArenaPalette.goldLight)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(mission.description, style: ArenaText.caption),
                  const SizedBox(height: 9),
                  ArenaProgressBar(
                    value: mission.progress / mission.target,
                    accent: completed ? ArenaPalette.success : ArenaPalette.cyan,
                    height: 7,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    claimed ? 'دریافت‌شده' : '${mission.progress.clamp(0, mission.target)} از ${mission.target}',
                    style: ArenaText.caption.copyWith(
                      color: claimed ? ArenaPalette.success : ArenaPalette.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            if (canClaim) const Icon(Icons.chevron_left_rounded, color: ArenaPalette.gold),
          ],
        ),
      ),
    );
  }
}

class _Mission {
  const _Mission({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.progress,
    required this.target,
    required this.reward,
  });

  final String id;
  final String title;
  final String description;
  final IconData icon;
  final int progress;
  final int target;
  final int reward;
}
