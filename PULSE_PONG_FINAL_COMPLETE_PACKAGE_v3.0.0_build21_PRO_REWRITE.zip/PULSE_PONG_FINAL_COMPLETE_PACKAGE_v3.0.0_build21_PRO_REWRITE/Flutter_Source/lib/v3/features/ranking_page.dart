import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../player/player_progress_controller.dart';
import '../ui/arena_ui.dart';

class RankingPage extends StatelessWidget {
  const RankingPage({required this.progress, super.key});

  final PlayerProgressController progress;

  @override
  Widget build(BuildContext context) {
    final List<_LeagueEntry> entries = _buildEntries(progress);
    final int playerIndex = entries.indexWhere((_LeagueEntry entry) => entry.isPlayer);
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const ArenaHeader(
                title: 'لیگ آفلاین',
                subtitle: 'رقابت محلی با رقبای هوش مصنوعی؛ بدون نمایش کاربر ساختگی',
                icon: Icons.emoji_events_rounded,
              ),
              const SizedBox(height: 18),
              _LeagueOverview(progress: progress, rank: playerIndex + 1),
              const SizedBox(height: 16),
              _Podium(entries: entries.take(3).toList(growable: false)),
              const SizedBox(height: 16),
              const ArenaSectionTitle(
                title: 'جدول فصل',
                subtitle: 'امتیازها بر اساس نتایج واقعی شما و سطح رقبای محلی محاسبه می‌شوند',
              ),
              const SizedBox(height: 10),
              ArenaSurface(
                accent: ArenaPalette.blue,
                enableGlow: false,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                child: Column(
                  children: entries.asMap().entries.map((MapEntry<int, _LeagueEntry> item) {
                    return _RankRow(rank: item.key + 1, entry: item.value);
                  }).toList(growable: false),
                ),
              ),
              const SizedBox(height: 14),
              const _SeasonRules(),
            ],
          ),
        ),
      ),
    );
  }

  static List<_LeagueEntry> _buildEntries(PlayerProgressController progress) {
    final int playerScore = progress.leagueScore;
    const List<String> names = <String>[
      'نوا پرایم',
      'تایتان آبی',
      'شکارچی مدار',
      'پالس صفر',
      'فانتوم آرنا',
      'کریستال ایکس',
      'مدافع خورشیدی',
      'هسته کوانتوم',
      'رعد نقره‌ای',
      'سایه میدان',
      'موج طلایی',
    ];
    final int seed = math.max(700, playerScore + 450);
    final List<_LeagueEntry> entries = <_LeagueEntry>[
      _LeagueEntry(name: progress.playerName, score: playerScore, isPlayer: true),
    ];
    for (int i = 0; i < names.length; i++) {
      final int spread = 205 + i * 117;
      final int score = math.max(0, seed + 560 - spread + ((i * 37) % 81));
      entries.add(_LeagueEntry(name: names[i], score: score, isPlayer: false));
    }
    entries.sort((_LeagueEntry a, _LeagueEntry b) => b.score.compareTo(a.score));
    return entries;
  }
}

class _LeagueOverview extends StatelessWidget {
  const _LeagueOverview({required this.progress, required this.rank});
  final PlayerProgressController progress;
  final int rank;

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: ArenaPalette.gold,
      selected: true,
      padding: const EdgeInsets.all(17),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: <Color>[ArenaPalette.goldLight, ArenaPalette.gold]),
                  boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x4DFFB51E), blurRadius: 18)],
                ),
                child: const Icon(Icons.workspace_premium_rounded, color: Colors.black, size: 34),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('لیگ ${progress.leagueName}', style: ArenaText.title),
                    const SizedBox(height: 2),
                    Text('رتبه فعلی $rank • ${progress.leagueScore} امتیاز', style: ArenaText.body),
                  ],
                ),
              ),
              Column(
                children: <Widget>[
                  Text('$rank', textDirection: TextDirection.ltr, style: ArenaText.display.copyWith(color: ArenaPalette.goldLight)),
                  Text('رتبه', style: ArenaText.caption),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          ArenaProgressBar(value: progress.leagueProgress, accent: ArenaPalette.gold, height: 9),
          const SizedBox(height: 6),
          Row(
            children: <Widget>[
              Text('${progress.currentLeagueFloor}', style: ArenaText.caption),
              const Spacer(),
              Text(
                progress.pointsToNextLeague == 0
                    ? 'بالاترین لیگ باز شده است'
                    : '${progress.pointsToNextLeague} امتیاز تا ${progress.nextLeagueName}',
                style: ArenaText.caption.copyWith(color: ArenaPalette.goldLight),
              ),
              const Spacer(),
              Text('${progress.nextLeagueThreshold}', style: ArenaText.caption),
            ],
          ),
        ],
      ),
    );
  }
}

class _Podium extends StatelessWidget {
  const _Podium({required this.entries});
  final List<_LeagueEntry> entries;

  @override
  Widget build(BuildContext context) {
    if (entries.length < 3) return const SizedBox.shrink();
    final List<_LeagueEntry> order = <_LeagueEntry>[entries[1], entries[0], entries[2]];
    return SizedBox(
      height: 164,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: order.asMap().entries.map((MapEntry<int, _LeagueEntry> item) {
          final int actualRank = switch (item.key) { 0 => 2, 1 => 1, _ => 3 };
          final double height = switch (actualRank) { 1 => 156, 2 => 132, _ => 116 };
          final Color accent = switch (actualRank) {
            1 => ArenaPalette.gold,
            2 => const Color(0xFFB8C8DA),
            _ => const Color(0xFFB57A54),
          };
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: SizedBox(
                height: height,
                child: ArenaSurface(
                  accent: accent,
                  selected: item.value.isPlayer,
                  enableGlow: item.value.isPlayer,
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('$actualRank', style: ArenaText.title.copyWith(color: accent, fontSize: 24)),
                      const SizedBox(height: 4),
                      Text(
                        item.value.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: ArenaText.caption.copyWith(color: ArenaPalette.text),
                      ),
                      const SizedBox(height: 4),
                      Text('${item.value.score}', style: ArenaText.caption),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(growable: false),
      ),
    );
  }
}

class _RankRow extends StatelessWidget {
  const _RankRow({required this.rank, required this.entry});
  final int rank;
  final _LeagueEntry entry;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        color: entry.isPlayer ? ArenaPalette.cyan.withValues(alpha: .10) : Colors.transparent,
        border: entry.isPlayer ? Border.all(color: ArenaPalette.cyan.withValues(alpha: .38)) : null,
      ),
      child: Row(
        children: <Widget>[
          SizedBox(
            width: 31,
            child: Text('$rank', textDirection: TextDirection.ltr, style: ArenaText.section.copyWith(color: rank <= 3 ? ArenaPalette.gold : ArenaPalette.textSoft)),
          ),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: entry.isPlayer ? ArenaPalette.cyan.withValues(alpha: .18) : ArenaPalette.surfaceRaised,
              border: Border.all(color: entry.isPlayer ? ArenaPalette.cyan : ArenaPalette.divider),
            ),
            child: Icon(entry.isPlayer ? Icons.person_rounded : Icons.smart_toy_rounded, color: entry.isPlayer ? ArenaPalette.cyan : ArenaPalette.textMuted, size: 20),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              entry.isPlayer ? '${entry.name} (شما)' : entry.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: ArenaText.section.copyWith(fontSize: 13.5),
            ),
          ),
          Text('${entry.score}', textDirection: TextDirection.ltr, style: ArenaText.section.copyWith(fontSize: 13.5)),
        ],
      ),
    );
  }
}

class _SeasonRules extends StatelessWidget {
  const _SeasonRules();

  @override
  Widget build(BuildContext context) {
    return ArenaSurface(
      accent: ArenaPalette.blue,
      enableGlow: false,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('قوانین رتبه‌بندی', style: ArenaText.section),
          const SizedBox(height: 8),
          const _Rule(icon: Icons.add_rounded, text: 'برد رقابتی: ۴۲ امتیاز لیگ'),
          const _Rule(icon: Icons.remove_rounded, text: 'شکست رقابتی: ۱۸ امتیاز کسر می‌شود'),
          const _Rule(icon: Icons.card_giftcard_rounded, text: 'ورود به هر لیگ جدید فقط یک بار ۳۰۰ پالس جایزه دارد'),
          const _Rule(icon: Icons.offline_bolt_rounded, text: 'تمام رقبا هوش مصنوعی محلی‌اند و کاربر آنلاین نمایش داده نمی‌شود'),
        ],
      ),
    );
  }
}

class _Rule extends StatelessWidget {
  const _Rule({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: ArenaPalette.cyan, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: ArenaText.body)),
        ],
      ),
    );
  }
}

class _LeagueEntry {
  const _LeagueEntry({required this.name, required this.score, required this.isPlayer});
  final String name;
  final int score;
  final bool isPlayer;
}
