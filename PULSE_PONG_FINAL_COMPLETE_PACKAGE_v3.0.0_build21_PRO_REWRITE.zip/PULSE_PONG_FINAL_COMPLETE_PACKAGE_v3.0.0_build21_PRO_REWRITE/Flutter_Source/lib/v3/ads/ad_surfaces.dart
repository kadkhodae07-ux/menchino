import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../ui/arena_ui.dart';

class AdCreative {
  const AdCreative({
    required this.campaignId,
    required this.title,
    required this.description,
    required this.packageName,
    required this.imageProvider,
    this.iconProvider,
    this.callToAction = 'نصب',
    this.referrer = 'utm_source=pulse_pong&utm_medium=in_app_ad',
  });

  final String campaignId;
  final String title;
  final String description;
  final String packageName;
  final ImageProvider imageProvider;
  final ImageProvider? iconProvider;
  final String callToAction;
  final String referrer;
}

/// Responsive fixed placement. The slot keeps a stable height while the image
/// fills the available bounds with BoxFit.cover and is clipped to the frame.
class ResponsiveAdBanner extends StatelessWidget {
  const ResponsiveAdBanner({
    required this.creative,
    required this.onPressed,
    this.minHeight = 62,
    this.maxHeight = 96,
    this.aspectRatio = 5.2,
    this.reserveSpaceWhenEmpty = true,
    super.key,
  });

  final AdCreative? creative;
  final VoidCallback onPressed;
  final double minHeight;
  final double maxHeight;
  final double aspectRatio;
  final bool reserveSpaceWhenEmpty;

  @override
  Widget build(BuildContext context) {
    final AdCreative? data = creative;
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double availableWidth = constraints.hasBoundedWidth
            ? constraints.maxWidth
            : MediaQuery.sizeOf(context).width;
        final double safeRatio = aspectRatio <= 0 ? 5.2 : aspectRatio;
        final double slotHeight = (availableWidth / safeRatio)
            .clamp(minHeight, maxHeight)
            .toDouble();
        if (data == null) {
          return reserveSpaceWhenEmpty
              ? SizedBox(width: double.infinity, height: slotHeight)
              : const SizedBox.shrink();
        }
        return SizedBox(
          width: double.infinity,
          height: slotHeight,
          child: ArenaSurface(
            accent: ArenaPalette.gold,
            onTap: onPressed,
            enableGlow: false,
            padding: EdgeInsets.zero,
            semanticLabel: '${data.title}، ${data.callToAction}',
            child: ClipPath(
              clipper: const _AdSlotClipper(),
              child: Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  Image(
                    image: data.imageProvider,
                    fit: BoxFit.cover,
                    alignment: Alignment.center,
                    filterQuality: FilterQuality.medium,
                    errorBuilder: (_, __, ___) => const ColoredBox(
                      color: ArenaPalette.surfaceInset,
                    ),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: <Color>[Color(0xE8030812), Color(0x8F030812), Color(0x15030812)],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                    child: Row(
                      children: <Widget>[
                        if (data.iconProvider != null) ...<Widget>[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(11),
                            child: Image(image: data.iconProvider!, width: 42, height: 42, fit: BoxFit.cover),
                          ),
                          const SizedBox(width: 10),
                        ],
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(data.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ArenaText.section),
                              Text(data.description, maxLines: 1, overflow: TextOverflow.ellipsis, style: ArenaText.caption),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        DecoratedBox(
                          decoration: BoxDecoration(
                            color: ArenaPalette.gold,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                            child: Text(data.callToAction, style: ArenaText.caption.copyWith(color: Colors.black, fontWeight: FontWeight.w900)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class VideoAdEndCard extends StatelessWidget {
  const VideoAdEndCard({
    required this.creative,
    required this.onClose,
    this.onInstallStarted,
    super.key,
  });

  final AdCreative creative;
  final VoidCallback onClose;
  final VoidCallback? onInstallStarted;

  Future<void> _install(BuildContext context) async {
    onInstallStarted?.call();
    final bool opened = await AdInstallBridge.openInlineInstall(
      packageName: creative.packageName,
      referrer: creative.referrer,
    );
    if (!context.mounted) return;
    if (!opened) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('فروشگاه سازگار روی این دستگاه پیدا نشد')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xE6000208),
      child: SafeArea(
        minimum: const EdgeInsets.all(18),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: ArenaSurface(
              accent: ArenaPalette.gold,
              prominent: true,
              selected: true,
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topLeft,
                    child: IconButton(
                      tooltip: 'بستن',
                      onPressed: onClose,
                      icon: const Icon(Icons.close_rounded, color: ArenaPalette.text),
                    ),
                  ),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: Image(image: creative.imageProvider, fit: BoxFit.cover),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      if (creative.iconProvider != null) ...<Widget>[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(13),
                          child: Image(image: creative.iconProvider!, width: 58, height: 58, fit: BoxFit.cover),
                        ),
                        const SizedBox(width: 12),
                      ],
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(creative.title, style: ArenaText.title),
                            const SizedBox(height: 3),
                            Text(creative.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: ArenaText.body),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ArenaPrimaryButton(
                    label: creative.callToAction,
                    icon: Icons.download_rounded,
                    onTap: () => _install(context),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'با لمس دکمه نصب، ابتدا پنجره نیم‌صفحه Google Play درخواست می‌شود؛ در دستگاه ناسازگار صفحه فروشگاه باز خواهد شد.',
                    textAlign: TextAlign.center,
                    style: ArenaText.caption,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Call this only after the video playback completion callback is received.
/// It keeps the user inside the game, then requests the platform install sheet
/// only after an explicit tap on the install button.
class VideoAdCompletionPresenter {
  const VideoAdCompletionPresenter._();

  static Future<void> show(
    BuildContext context, {
    required AdCreative creative,
    VoidCallback? onInstallStarted,
  }) async {
    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierLabel: 'پایان تبلیغ و پیشنهاد نصب',
      barrierColor: Colors.transparent,
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (
        BuildContext dialogContext,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
      ) {
        return VideoAdEndCard(
          creative: creative,
          onInstallStarted: onInstallStarted,
          onClose: () => Navigator.of(dialogContext).pop(),
        );
      },
      transitionBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        Widget child,
      ) {
        final Animation<double> curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            scale: Tween<double>(begin: .965, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
  }
}

typedef VideoAdPlayback = Future<bool> Function();

/// Provider-neutral flow: the end card is shown only when the video adapter
/// reports a completed view. Returning false for skip, failure, or early close
/// keeps the end card hidden and prevents a false completion event.
class VideoAdFlowController {
  const VideoAdFlowController._();

  static Future<bool> play(
    BuildContext context, {
    required VideoAdPlayback playVideo,
    required AdCreative creative,
    VoidCallback? onInstallStarted,
  }) async {
    final bool completed = await playVideo();
    if (!completed || !context.mounted) return false;
    await VideoAdCompletionPresenter.show(
      context,
      creative: creative,
      onInstallStarted: onInstallStarted,
    );
    return true;
  }
}

class AdInstallBridge {
  const AdInstallBridge._();

  static const MethodChannel _channel = MethodChannel('com.manyshah.pulsearena/local_state');

  static Future<bool> openInlineInstall({
    required String packageName,
    required String referrer,
  }) async {
    try {
      return await _channel.invokeMethod<bool>('openInlineInstall', <String, String>{
            'packageName': packageName,
            'referrer': referrer,
          }) ??
          false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }
}

class _AdSlotClipper extends CustomClipper<Path> {
  const _AdSlotClipper();

  @override
  Path getClip(Size size) {
    const double cut = 12;
    return Path()
      ..moveTo(cut, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width, size.height - cut)
      ..lineTo(size.width - cut, size.height)
      ..lineTo(0, size.height)
      ..lineTo(0, cut)
      ..close();
  }

  @override
  bool shouldReclip(covariant _AdSlotClipper oldClipper) => false;
}
