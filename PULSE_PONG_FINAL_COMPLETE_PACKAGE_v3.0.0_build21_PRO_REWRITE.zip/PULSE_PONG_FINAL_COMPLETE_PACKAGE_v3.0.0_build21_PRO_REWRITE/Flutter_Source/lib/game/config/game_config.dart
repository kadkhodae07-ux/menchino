enum BotDifficulty { trainee, tactical, champion }

enum GameMode { offline, training, localDuel }

extension GameModeLabel on GameMode {
  String get title => switch (this) {
        GameMode.offline => 'نبرد آفلاین',
        GameMode.training => 'تمرین آزاد',
        GameMode.localDuel => 'دو نفره محلی',
      };

  String get subtitle => switch (this) {
        GameMode.offline => 'مسابقه کامل با ثبت آمار و پاداش',
        GameMode.training => 'تمرین سریع بدون تغییر آمار رقابتی',
        GameMode.localDuel => 'رقابت دو بازیکن روی یک دستگاه',
      };
}

extension BotDifficultyLabel on BotDifficulty {
  String get title {
    switch (this) {
      case BotDifficulty.trainee:
        return 'تمرینی';
      case BotDifficulty.tactical:
        return 'تاکتیکی';
      case BotDifficulty.champion:
        return 'قهرمان';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.trainee:
        return 'کند، خطاپذیر و مناسب یادگیری';
      case BotDifficulty.tactical:
        return 'متعادل، طبیعی و مناسب مسابقه اصلی';
      case BotDifficulty.champion:
        return 'سخت و واکنش‌گرا، اما قابل شکست';
    }
  }
}

class GameConfig {
  const GameConfig({
    this.mode = GameMode.offline,
    this.trackProgress = true,
    this.difficulty = BotDifficulty.tactical,
    this.targetScore = 10,
    this.ballBaseSpeed = 410,
    this.ballMaximumSpeed = 760,
    this.ballSpeedIncreasePerSecond = 1.35,
    this.serveSpeedFactor = .60,
    this.serveRampDuration = 1.45,
    this.playerPaddleSpeed = 6200,
    this.playerPaddleAcceleration = 96000,
    this.playerResponse = 58,
    this.botPaddleSpeed = 790,
    this.botPaddleAcceleration = 8200,
    this.botReactionDelay = 0.18,
    this.botErrorChance = 0.27,
    this.botBaseAimError = 78,
    this.countdownDuration = 3.0,
    this.pointServeDelay = 0.90,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.56,
    this.boostMultiplier = 1.26,
    this.shieldUses = 2,
    this.boostUses = 2,
    this.pulseUses = 2,
  });

  factory GameConfig.forDifficulty(BotDifficulty difficulty) {
    switch (difficulty) {
      case BotDifficulty.trainee:
        return const GameConfig(
          difficulty: BotDifficulty.trainee,
          botPaddleSpeed: 560,
          botPaddleAcceleration: 4700,
          botReactionDelay: 0.31,
          botErrorChance: 0.52,
          botBaseAimError: 136,
          ballBaseSpeed: 370,
          ballMaximumSpeed: 640,
          ballSpeedIncreasePerSecond: 1.05,
          serveSpeedFactor: .56,
        );
      case BotDifficulty.tactical:
        return const GameConfig();
      case BotDifficulty.champion:
        return const GameConfig(
          difficulty: BotDifficulty.champion,
          botPaddleSpeed: 940,
          botPaddleAcceleration: 10800,
          botReactionDelay: 0.125,
          botErrorChance: 0.17,
          botBaseAimError: 52,
          ballBaseSpeed: 440,
          ballMaximumSpeed: 810,
          ballSpeedIncreasePerSecond: 1.60,
          serveSpeedFactor: .66,
        );
    }
  }

  factory GameConfig.training() {
    return const GameConfig(
      mode: GameMode.training,
      trackProgress: false,
      difficulty: BotDifficulty.trainee,
      targetScore: 5,
      ballBaseSpeed: 350,
      ballMaximumSpeed: 610,
      ballSpeedIncreasePerSecond: .90,
      serveSpeedFactor: .54,
      botPaddleSpeed: 490,
      botPaddleAcceleration: 4100,
      botReactionDelay: 0.36,
      botErrorChance: 0.62,
      botBaseAimError: 162,
      shieldUses: 99,
      boostUses: 99,
      pulseUses: 99,
    );
  }


  factory GameConfig.localDuel() {
    return const GameConfig(
      mode: GameMode.localDuel,
      trackProgress: false,
      difficulty: BotDifficulty.tactical,
      targetScore: 10,
      ballBaseSpeed: 390,
      ballMaximumSpeed: 720,
      ballSpeedIncreasePerSecond: 1.15,
      serveSpeedFactor: .58,
      shieldUses: 0,
      boostUses: 0,
      pulseUses: 0,
    );
  }

  final GameMode mode;
  final bool trackProgress;
  final BotDifficulty difficulty;
  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double serveSpeedFactor;
  final double serveRampDuration;
  final double playerPaddleSpeed;
  final double playerPaddleAcceleration;
  final double playerResponse;
  final double botPaddleSpeed;
  final double botPaddleAcceleration;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double pointServeDelay;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
