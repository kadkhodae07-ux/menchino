import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

class ImpactParticle extends PositionComponent {
  ImpactParticle({required Vector2 origin, required Color color, required this.seed})
      : _color = color,
        super(position: origin.clone(), priority: 30);

  final Color _color;
  final int seed;
  late final List<_Spark> _sparks;
  final Paint _haloPaint = Paint();
  final Paint _corePaint = Paint();
  double _life = 0.24;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final math.Random random = math.Random(seed);
    _sparks = List<_Spark>.generate(4, (int index) {
      final double angle = random.nextDouble() * math.pi * 2;
      final double speed = 90.0 + random.nextDouble() * 135.0;
      return _Spark(
        velocity: Vector2(math.cos(angle) * speed, math.sin(angle) * speed),
        radius: 1.1 + random.nextDouble() * 1.6,
      );
    });
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double safeDt = dt.clamp(0.0, 0.04).toDouble();
    _life -= safeDt;
    for (final _Spark spark in _sparks) {
      spark.offset += spark.velocity * safeDt;
      spark.velocity *= math.exp(-6.0 * safeDt);
    }
    if (_life <= 0) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final double opacity = (_life / 0.24).clamp(0.0, 1.0).toDouble();
    _haloPaint.color = _color.withValues(alpha: opacity * 0.10);
    _corePaint.color = _color.withValues(alpha: opacity);
    for (final _Spark spark in _sparks) {
      final Offset center = Offset(spark.offset.x, spark.offset.y);
      canvas.drawCircle(center, spark.radius * 1.9, _haloPaint);
      canvas.drawCircle(center, spark.radius, _corePaint);
    }
  }
}

class _Spark {
  _Spark({required this.velocity, required this.radius});

  Vector2 offset = Vector2.zero();
  Vector2 velocity;
  final double radius;
}
