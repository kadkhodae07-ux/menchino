import 'dart:ui';

import 'package:flame/components.dart';

import 'player_paddle_controller.dart';

class ShieldComponent extends PositionComponent {
  ShieldComponent({required this.player, required this.isActive, super.priority = 5});

  final PlayerPaddleController player;
  final bool Function() isActive;
  Rect arena = Rect.zero;

  void layout(Rect value) {
    arena = value;
    size = Vector2(value.width, value.height);
  }

  double get collisionX => player.position.x - 25;

  @override
  void render(Canvas canvas) {
    if (!isActive() || arena.isEmpty) return;
    final double localX = collisionX - arena.left;
    final Rect bar = Rect.fromLTWH(localX - 4, 5, 8, arena.height - 10);
    canvas.save();
    canvas.translate(arena.left, arena.top);
    canvas.drawRRect(
      RRect.fromRectAndRadius(bar.inflate(8), const Radius.circular(12)),
      Paint()..color = const Color(0x1844E7FF),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(bar.inflate(3), const Radius.circular(9)),
      Paint()..color = const Color(0x5544E7FF),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(bar, const Radius.circular(7)),
      Paint()..color = const Color(0xE8EBFDFF),
    );
    canvas.restore();
  }
}
