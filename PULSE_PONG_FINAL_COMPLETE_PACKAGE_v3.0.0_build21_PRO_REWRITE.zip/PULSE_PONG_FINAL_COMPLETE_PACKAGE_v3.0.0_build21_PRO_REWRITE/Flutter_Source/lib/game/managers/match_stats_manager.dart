class MatchStatsManager {
  int currentRally = 0;
  int longestRally = 0;
  int playerHits = 0;
  int botHits = 0;
  int perfectHits = 0;
  int powersUsed = 0;

  void recordPaddleHit({required bool player, required bool perfect}) {
    currentRally += 1;
    if (currentRally > longestRally) longestRally = currentRally;
    if (player) {
      playerHits += 1;
      if (perfect) perfectHits += 1;
    } else {
      botHits += 1;
    }
  }

  void recordPowerUse() {
    powersUsed += 1;
  }

  void endRally() {
    if (currentRally > longestRally) longestRally = currentRally;
    currentRally = 0;
  }

  void reset() {
    currentRally = 0;
    longestRally = 0;
    playerHits = 0;
    botHits = 0;
    perfectHits = 0;
    powersUsed = 0;
  }
}
