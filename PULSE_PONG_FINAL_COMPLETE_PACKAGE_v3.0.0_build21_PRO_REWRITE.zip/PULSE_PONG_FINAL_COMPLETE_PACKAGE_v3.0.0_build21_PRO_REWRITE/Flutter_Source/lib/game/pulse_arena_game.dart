import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';

import 'components/arena_component.dart';
import 'components/ball_controller.dart';
import 'components/bot_paddle_controller.dart';
import 'components/player_paddle_controller.dart';
import 'components/shield_component.dart';
import 'config/game_config.dart';
import 'managers/audio_manager.dart';
import 'managers/game_manager.dart';
import 'managers/ui_manager.dart';
import '../player/player_progress_controller.dart';
import 'models/game_view_state.dart';

({Color accent, Color deep, Color detail}) _paddlePalette(String? id) {
  return switch (id) {
    'paddle:phantom' => (
        accent: const Color(0xFF68A7FF),
        deep: const Color(0xFF123B66),
        detail: const Color(0xB8194B78),
      ),
    'paddle:titan' => (
        accent: const Color(0xFFE7BC59),
        deep: const Color(0xFF5A3B08),
        detail: const Color(0xB87A4B08),
      ),
    'paddle:crystal' => (
        accent: const Color(0xFF67D6C1),
        deep: const Color(0xFF164B4E),
        detail: const Color(0xB8236664),
      ),
    _ => (
        accent: const Color(0xFF55D4D0),
        deep: const Color(0xFF063F68),
        detail: const Color(0xB8073458),
      ),
  };
}

({Color primary, Color secondary}) _ballPalette(String? id) {
  return switch (id) {
    'ball:solar' => (
        primary: const Color(0xFFFFD56A),
        secondary: const Color(0xFF9F4E13),
      ),
    'ball:shadow' => (
        primary: const Color(0xFF6B7C99),
        secondary: const Color(0xFF1B2534),
      ),
    'ball:quantum' => (
        primary: const Color(0xFF52D9E8),
        secondary: const Color(0xFF14596A),
      ),
    _ => (
        primary: const Color(0xFF5CA8FF),
        secondary: const Color(0xFF174B8A),
      ),
  };
}

Color _effectPalette(String? id) {
  return switch (id) {
    'effect:neon_burst' => const Color(0xFF4ED5A4),
    'effect:gold_wave' => const Color(0xFFE7BC59),
    'effect:space_rift' => const Color(0xFF4C8BFF),
    _ => const Color(0xFF6BE8FF),
  };
}

class PulseArenaGame extends FlameGame {
  PulseArenaGame({this.config = const GameConfig()})
      : manager = GameManager(config),
        ui = UIManager(
          GameViewState(
            countdown: config.countdownDuration.ceil().clamp(1, 3).toInt(),
            countdownRemaining: config.countdownDuration,
            countdownTotal: config.countdownDuration,
            difficulty: config.difficulty,
            targetScore: config.targetScore,
            shieldUses: config.shieldUses,
            boostUses: config.boostUses,
            pulseUses: config.pulseUses,
          ),
        );

  final GameConfig config;
  final GameManager manager;
  final UIManager ui;

  late final ArenaComponent arenaComponent;
  late final PlayerPaddleController player;
  late final BotPaddleController bot;
  late final BallController ball;
  late final ShieldComponent shield;

  bool _loaded = false;
  bool _pausedFromCountdown = false;
  bool _hasTouched = false;
  double _uiAccumulator = 0;
  double _eventRemaining = 0;
  double _slowFrameDebt = 0;
  double _stableFrameCredit = 0;
  bool _reducedEffects = PlayerProgressController.instance.effectsQuality == 0;
  int _lastCountdownLabel = -1;

  ValueListenable<GameViewState> get viewState => ui.state;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    final PlayerProgressController progress = PlayerProgressController.instance;
    final ({Color accent, Color deep, Color detail}) paddlePalette =
        _paddlePalette(progress.selectedItems['paddle']);
    final ({Color primary, Color secondary}) ballPalette =
        _ballPalette(progress.selectedItems['ball']);

    arenaComponent = ArenaComponent();
    player = PlayerPaddleController(
      moveSpeed: config.playerPaddleSpeed,
      acceleration: config.playerPaddleAcceleration,
      response: 42 + progress.controlSensitivity * 26,
      accentColor: paddlePalette.accent,
      deepColor: paddlePalette.deep,
      detailColor: paddlePalette.detail,
    );
    ball = BallController(
      config: config,
      primaryColor: ballPalette.primary,
      secondaryColor: ballPalette.secondary,
      trailColor: _effectPalette(progress.selectedItems['effect']),
      effectQuality: progress.effectsQuality,
      onPlayerScored: _playerScored,
      onBotScored: _botScored,
      isShieldActive: () => manager.powers.shieldActive,
      consumeBoost: manager.powers.consumeBoost,
      isBoostArmed: () => manager.powers.boostArmed,
      matchElapsedSeconds: () => manager.match.elapsedSeconds,
      onPaddleHit: _paddleHit,
    );
    bot = BotPaddleController(
      config: config,
      ball: ball,
      playerScore: () => manager.score.playerScore,
      botScore: () => manager.score.botScore,
      isPulseActive: () => manager.powers.pulseActive,
    );
    ball.attachPaddles(player, bot);
    shield = ShieldComponent(player: player, isActive: () => manager.powers.shieldActive);

    await addAll(<Component>[arenaComponent, shield, player, bot, ball]);
    arenaComponent.reducedEffects = _reducedEffects;
    ball.reducedEffects = _reducedEffects;
    _loaded = true;
    _layout(size);
    await AudioManager.instance.startBgm();
    restartMatch();
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    if (_loaded) {
      _layout(size);
    }
  }

  void _layout(Vector2 gameSize) {
    arenaComponent.layout(gameSize);
    final Rect arena = arenaComponent.playRect;
    player.layout(arena);
    bot.layout(arena);
    ball.layout(arena);
    shield.layout(arena);
  }

  @override
  void update(double dt) {
    super.update(dt);
    _updatePerformanceGovernor(dt);
    if (!_loaded ||
        manager.match.isFinished ||
        manager.match.phase == MatchPhase.paused) {
      return;
    }

    final bool countdownCompleted = manager.match.update(dt);
    manager.powers.update(dt);

    if (_eventRemaining > 0) {
      _eventRemaining -= dt;
      if (_eventRemaining <= 0 &&
          manager.match.phase == MatchPhase.playing) {
        manager.eventText = '';
      }
    }

    if (manager.match.isCountdown && manager.match.openingSequence) {
      final int label = manager.match.countdownLabel;
      if (label != _lastCountdownLabel) {
        _lastCountdownLabel = label;
        AudioManager.instance.playCountdown();
        AudioManager.instance.lightImpact();
      }
    }

    if (countdownCompleted) {
      arenaComponent.triggerServe();
      ball.launch();
      manager.eventText = manager.match.openingSequence ? 'نبرد آغاز شد' : '';
      _eventRemaining = manager.match.openingSequence ? 0.8 : 0;
      AudioManager.instance.importantImpact();
    }

    arenaComponent.setRally(manager.stats.currentRally);
    _uiAccumulator += dt;
    if (_uiAccumulator >= 0.05) {
      _uiAccumulator = 0;
      _syncUi();
    }
  }

  void _updatePerformanceGovernor(double dt) {
    if (!_loaded) return;
    final int quality = PlayerProgressController.instance.effectsQuality;
    if (quality == 0) {
      _reducedEffects = true;
      arenaComponent.reducedEffects = true;
      ball.reducedEffects = true;
      return;
    }

    if (dt > 0.026) {
      _slowFrameDebt += 1;
      _stableFrameCredit = 0;
    } else {
      _slowFrameDebt = math.max(0.0, _slowFrameDebt - 0.8);
      if (_reducedEffects && dt < 0.020) {
        _stableFrameCredit += 1;
      }
    }

    if (!_reducedEffects && _slowFrameDebt >= 18) {
      _reducedEffects = true;
      _stableFrameCredit = 0;
      arenaComponent.reducedEffects = true;
      ball.reducedEffects = true;
      return;
    }

    if (_reducedEffects && _stableFrameCredit >= 180) {
      _reducedEffects = false;
      _slowFrameDebt = 0;
      _stableFrameCredit = 0;
      arenaComponent.reducedEffects = false;
      ball.reducedEffects = false;
    }
  }

  void handleTouch(
    double y, {
    int? eventMicros,
    bool secondPlayer = false,
  }) {
    if (manager.match.phase != MatchPhase.playing &&
        manager.match.phase != MatchPhase.countdown) {
      return;
    }
    _hasTouched = true;
    if (config.mode == GameMode.localDuel && secondPlayer) {
      bot.setTargetFromTouch(y, eventMicros: eventMicros);
      return;
    }
    player.setTargetFromTouch(y, eventMicros: eventMicros);
  }

  void endTouch({bool secondPlayer = false}) {
    if (config.mode == GameMode.localDuel && secondPlayer) {
      bot.endTouch();
      return;
    }
    player.endTouch();
  }

  bool activatePower(PowerType type) {
    if (manager.match.phase != MatchPhase.playing) {
      return false;
    }
    final bool activated = manager.powers.activate(type);
    if (activated) {
      manager.stats.recordPowerUse();
      manager.eventText = switch (type) {
        PowerType.shield => 'سپر انرژی فعال شد',
        PowerType.boost => 'ضربه بعدی تقویت شد',
        PowerType.pulse => config.mode == GameMode.localDuel
            ? 'سرعت بازیکن ۲ کاهش یافت'
            : 'سرعت ربات کاهش یافت',
      };
      _eventRemaining = 1.25;
      AudioManager.instance.playPower();
      AudioManager.instance.lightImpact();
      _syncUi();
    }
    return activated;
  }

  void pauseMatch() {
    if (manager.match.phase != MatchPhase.playing &&
        manager.match.phase != MatchPhase.countdown) {
      return;
    }
    _pausedFromCountdown = manager.match.phase == MatchPhase.countdown;
    manager.match.pause();
    pauseEngine();
    _syncUi();
  }

  void resumeMatch() {
    if (manager.match.phase != MatchPhase.paused) {
      return;
    }
    manager.match.resume(wasCountdown: _pausedFromCountdown);
    resumeEngine();
    _syncUi();
  }

  void restartMatch() {
    resumeEngine();
    manager.reset();
    _lastCountdownLabel = -1;
    _hasTouched = false;
    _eventRemaining = 0;
    _slowFrameDebt = 0;
    _stableFrameCredit = 0;
    _reducedEffects = PlayerProgressController.instance.effectsQuality == 0;
    arenaComponent.reducedEffects = _reducedEffects;
    ball.reducedEffects = _reducedEffects;
    player.movementEnabled = true;
    bot.movementEnabled = true;
    player.resetToCenter();
    bot.resetToCenter();
    ball.resetToCenter(serveDirection: 1);
    arenaComponent.resetEffects();
    arenaComponent.triggerServe();
    _syncUi();
  }

  void _paddleHit({required bool player, required bool perfect}) {
    manager.stats.recordPaddleHit(player: player, perfect: perfect);
    arenaComponent.triggerHit(playerHit: player, perfect: perfect);
    if (perfect) {
      manager.eventText = 'ضربه دقیق!';
      _eventRemaining = 0.9;
    } else if (manager.stats.currentRally == 6 || manager.stats.currentRally == 10) {
      manager.eventText = 'رالی ${manager.stats.currentRally} ضربه‌ای';
      _eventRemaining = 0.9;
    }
  }

  void _playerScored() {
    AudioManager.instance.importantImpact();
    arenaComponent.triggerGoal(playerScored: true);
    final MatchWinner? winner = manager.score.addPlayerPoint();
    if (winner == null) {
      AudioManager.instance.playScore();
    }
    manager.registerPoint(pointWinner: MatchWinner.player, server: MatchWinner.bot);
    _afterPoint(winner, serveDirection: -1);
  }

  void _botScored() {
    AudioManager.instance.importantImpact();
    arenaComponent.triggerGoal(playerScored: false);
    final MatchWinner? winner = manager.score.addBotPoint();
    if (winner == null) {
      AudioManager.instance.playScore();
    }
    manager.registerPoint(pointWinner: MatchWinner.bot, server: MatchWinner.player);
    _afterPoint(winner, serveDirection: 1);
  }

  void _afterPoint(MatchWinner? winner, {required int serveDirection}) {
    if (winner != null) {
      manager.match.finish(winner);
      player.movementEnabled = false;
      bot.movementEnabled = false;
      ball.stop(hide: true);
      if (winner == MatchWinner.player) {
        arenaComponent.triggerVictory();
        AudioManager.instance.playWin();
      } else {
        AudioManager.instance.playLose();
      }
    } else {
      player.resetToCenter();
      bot.resetToCenter();
      ball.resetToCenter(serveDirection: serveDirection);
      manager.match.startCountdown(opening: false);
    }
    _syncUi();
  }

  void toggleSound() {
    final bool enabled = !AudioManager.instance.soundEnabled;
    AudioManager.instance.setSoundEnabled(enabled);
    PlayerProgressController.instance.setSoundEnabled(enabled);
    _syncUi();
  }

  void toggleVibration() {
    final bool enabled = !AudioManager.instance.vibrationEnabled;
    AudioManager.instance.vibrationEnabled = enabled;
    PlayerProgressController.instance.setVibrationEnabled(enabled);
    _syncUi();
  }

  void _syncUi() {
    ui.update(
      manager.makeViewState(
        soundEnabled: AudioManager.instance.soundEnabled,
        vibrationEnabled: AudioManager.instance.vibrationEnabled,
        showControlHint: !_hasTouched && manager.match.elapsedSeconds < 6,
      ),
    );
  }

  @override
  void onRemove() {
    ui.dispose();
    super.onRemove();
  }
}
