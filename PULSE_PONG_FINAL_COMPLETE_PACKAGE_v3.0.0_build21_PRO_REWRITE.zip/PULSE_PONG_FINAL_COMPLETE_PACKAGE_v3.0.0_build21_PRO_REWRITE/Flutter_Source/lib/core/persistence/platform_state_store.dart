import 'package:flutter/services.dart';

/// Android-backed local state without adding another runtime plugin.
/// The matching MethodChannel implementation lives in MainActivity.kt.
class PlatformStateStore {
  const PlatformStateStore._();

  static const MethodChannel _channel = MethodChannel(
    'com.manyshah.pulsearena/local_state',
  );

  static Future<String?> load() async {
    try {
      return await _channel.invokeMethod<String>('loadState');
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  static Future<void> save(String json) async {
    try {
      await _channel.invokeMethod<void>('saveState', json);
    } on PlatformException {
      // Persistence must never interrupt gameplay.
    } on MissingPluginException {
      // Tests and non-Android targets use in-memory defaults.
    }
  }

  static Future<void> setPreferredFrameRate(int framesPerSecond) async {
    try {
      await _channel.invokeMethod<void>('setPreferredFrameRate', framesPerSecond);
    } on PlatformException {
      // Unsupported displays keep the platform default refresh mode.
    } on MissingPluginException {
      // Tests and non-Android targets do not expose display modes.
    }
  }
}
