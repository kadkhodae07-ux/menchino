import 'package:flutter/material.dart';

/// Compatibility design tokens for the PULSE PONG gameplay overlays.
///
/// Cyan is the player accent, blue is secondary structure, and gold is the
/// opponent, reward, and competitive accent. Strong magenta and purple are
/// intentionally excluded from the production palette.
abstract final class PulseColors {
  static const Color voidBlack = Color(0xFF010409);
  static const Color background = Color(0xFF050A12);
  static const Color deepNavy = Color(0xFF08111B);
  static const Color panelTop = Color(0xFF13202D);
  static const Color panelBottom = Color(0xFF0A141F);
  static const Color panelInset = Color(0xFF07101A);
  static const Color elevated = Color(0xFF101C28);
  static const Color elevatedSoft = Color(0xFF0D1722);

  static const Color cyan = Color(0xFF4DC6D6);
  static const Color cyanBright = Color(0xFF79DCE8);
  static const Color blue = Color(0xFF4388C8);
  static const Color violet = Color(0xFF617EA8);
  static const Color rose = Color(0xFFD6B15E);
  static const Color magentaDeep = Color(0xFF51411E);
  static const Color gold = Color(0xFFD6B15E);
  static const Color success = Color(0xFF67C996);
  static const Color danger = Color(0xFFD46E7B);

  static const Color textPrimary = Color(0xFFF3F6F8);
  static const Color textSecondary = Color(0xFFC0C8D2);
  static const Color textMuted = Color(0xFF8997A8);
  static const Color disabled = Color(0xFF566476);
  static const Color divider = Color(0xFF293746);
  static const Color hairline = Color(0xFF405165);
}

abstract final class PulseSpacing {
  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
}

abstract final class PulseRadii {
  static const double control = 12;
  static const double card = 16;
  static const double hero = 20;
  static const double pill = 999;
}

abstract final class PulseDurations {
  static const Duration press = Duration(milliseconds: 85);
  static const Duration micro = Duration(milliseconds: 165);
  static const Duration page = Duration(milliseconds: 220);
  static const Duration dialog = Duration(milliseconds: 210);
  static const Duration reward = Duration(milliseconds: 520);
}

abstract final class PulseTypography {
  static const String family = 'sans-serif';

  static const TextStyle display = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 29,
    fontWeight: FontWeight.w800,
    height: 1.20,
  );

  static const TextStyle title = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 20,
    fontWeight: FontWeight.w800,
    height: 1.28,
  );

  static const TextStyle section = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 15.5,
    fontWeight: FontWeight.w800,
    height: 1.35,
  );

  static const TextStyle body = TextStyle(
    fontFamily: family,
    color: PulseColors.textSecondary,
    fontSize: 13.5,
    fontWeight: FontWeight.w500,
    height: 1.55,
  );

  static const TextStyle label = TextStyle(
    fontFamily: family,
    color: PulseColors.textPrimary,
    fontSize: 12.5,
    fontWeight: FontWeight.w700,
    height: 1.35,
  );
}

ThemeData buildPulseArenaTheme() {
  final ColorScheme scheme = ColorScheme.fromSeed(
    seedColor: PulseColors.cyan,
    brightness: Brightness.dark,
    surface: PulseColors.deepNavy,
    error: PulseColors.danger,
  );
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    fontFamily: PulseTypography.family,
    scaffoldBackgroundColor: PulseColors.voidBlack,
    colorScheme: scheme,
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    hoverColor: Colors.transparent,
    focusColor: PulseColors.cyan.withValues(alpha: .10),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: PulseColors.cyan,
      selectionColor: PulseColors.cyan.withValues(alpha: .20),
      selectionHandleColor: PulseColors.cyan,
    ),
  );
}
