import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A raised game surface with a calm three-layer construction.
///
/// Most corners are rounded. The small top-right shoulder is the only
/// mechanical cut on regular cards, preventing the repeated full-neon frame
/// look that previously made every element compete for attention.
class PulsePanel extends StatelessWidget {
  const PulsePanel({
    required this.colors,
    required this.child,
    this.cut = 16,
    this.padding = EdgeInsets.zero,
    this.pressed = false,
    this.intensity = 1,
    super.key,
  });

  final List<Color> colors;
  final Widget child;
  final double cut;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final double intensity;

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: PulsePanelPainter(
          colors: colors,
          cut: cut,
          pressed: pressed,
          intensity: intensity,
        ),
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

class PulsePanelPainter extends CustomPainter {
  const PulsePanelPainter({
    required this.colors,
    required this.cut,
    required this.pressed,
    required this.intensity,
  });

  final List<Color> colors;
  final double cut;
  final bool pressed;
  final double intensity;

  Path _shape(Size size, double inset) {
    final double left = inset;
    final double top = inset;
    final double right = size.width - inset;
    final double bottom = size.height - inset;
    final double radius = math.min(
      18.0,
      math.max(10.0, math.min(size.width, size.height) * .15),
    );
    final double shoulder = math.min(
      math.max(8.0, cut * .58),
      math.max(8.0, size.width * .12),
    );

    return Path()
      ..moveTo(left + radius, top)
      ..lineTo(right - shoulder - radius * .42, top)
      ..quadraticBezierTo(
        right - shoulder,
        top,
        right - shoulder * .74,
        top + shoulder * .26,
      )
      ..lineTo(right - radius * .40, top + shoulder * .78)
      ..quadraticBezierTo(right, top + shoulder, right, top + shoulder + radius * .46)
      ..lineTo(right, bottom - radius)
      ..quadraticBezierTo(right, bottom, right - radius, bottom)
      ..lineTo(left + radius, bottom)
      ..quadraticBezierTo(left, bottom, left, bottom - radius)
      ..lineTo(left, top + radius)
      ..quadraticBezierTo(left, top, left + radius, top)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final Rect rect = Offset.zero & size;
    final Path outer = _shape(size, 1.5);
    final Path middle = _shape(size, 4.0);
    final Path inner = _shape(size, 6.2);
    final Color primary = colors.isEmpty ? const Color(0xFF4DC6D6) : colors.first;
    final Color secondary = colors.length > 1 ? colors.last : primary;
    final double state = pressed ? .72 : 1.0;
    final double lift = pressed ? 1.5 : 4.5;
    final double accent = intensity.clamp(0.0, 1.25).toDouble();

    canvas.drawShadow(
      outer.shift(Offset(0, lift + 2)),
      const Color(0xE6000000),
      pressed ? 4 : 12,
      false,
    );

    canvas.save();
    canvas.translate(0, lift);
    canvas.drawPath(outer, Paint()..color = const Color(0xFF010307));
    canvas.drawPath(
      middle,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = const Color(0xFF182431),
    );
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFF172634),
            Color(0xFF101B27),
            Color(0xFF09131E),
          ],
          stops: <double>[0, .42, 1],
        ).createShader(rect),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withValues(alpha: pressed ? .025 : .065),
            Colors.transparent,
            const Color(0x66000000),
          ],
          stops: const <double>[0, .36, 1],
        ).createShader(rect),
    );
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            primary.withValues(alpha: .026 * accent * state),
            Colors.transparent,
            secondary.withValues(alpha: .018 * accent * state),
          ],
          stops: const <double>[0, .55, 1],
        ).createShader(rect),
    );
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..color = const Color(0xFF455464).withValues(alpha: .82 * state),
    );
    canvas.drawPath(
      middle,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .65
        ..color = const Color(0xFF91A0AF).withValues(alpha: .16 * state),
    );

    final Paint rail = Paint()
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;
    rail.color = primary.withValues(alpha: .55 * accent * state);
    canvas.drawLine(
      const Offset(16, 3.7),
      Offset(math.min(size.width * .19, 56), 3.7),
      rail,
    );

    rail.color = secondary.withValues(alpha: .32 * accent * state);
    canvas.drawLine(
      Offset(size.width - math.min(48, size.width * .16), size.height - 3.4),
      Offset(size.width - 16, size.height - 3.4),
      rail,
    );

    canvas.drawLine(
      Offset(18, size.height - 2.2),
      Offset(size.width - 18, size.height - 2.2),
      Paint()
        ..strokeWidth = .8
        ..color = const Color(0xCC000205),
    );
  }

  @override
  bool shouldRepaint(covariant PulsePanelPainter oldDelegate) {
    return oldDelegate.pressed != pressed ||
        oldDelegate.intensity != intensity ||
        oldDelegate.colors != colors ||
        oldDelegate.cut != cut;
  }
}
