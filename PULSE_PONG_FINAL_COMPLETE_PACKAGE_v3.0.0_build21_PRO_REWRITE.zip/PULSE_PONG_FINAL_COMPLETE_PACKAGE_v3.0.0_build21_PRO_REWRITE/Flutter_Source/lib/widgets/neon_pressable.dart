import 'dart:async';

import 'package:flutter/material.dart';

import '../game/managers/audio_manager.dart';

class NeonPressable extends StatefulWidget {
  const NeonPressable({
    required this.builder,
    required this.onTap,
    super.key,
    this.pressedScale = 0.96,
    this.playSound = true,
    this.hapticFeedback = true,
    this.semanticLabel,
  });

  final Widget Function(BuildContext context, bool pressed) builder;
  final VoidCallback? onTap;
  final double pressedScale;
  final bool playSound;
  final bool hapticFeedback;
  final String? semanticLabel;

  bool get enabled => onTap != null;

  @override
  State<NeonPressable> createState() => _NeonPressableState();
}

class _NeonPressableState extends State<NeonPressable> {
  bool _pressed = false;
  int _lastActivationMicros = 0;

  void _setPressed(bool value) {
    if (!widget.enabled) value = false;
    if (_pressed == value || !mounted) return;
    setState(() => _pressed = value);
  }

  void _activate() {
    final VoidCallback? callback = widget.onTap;
    if (callback == null) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    if (now - _lastActivationMicros < 280000) return;
    _lastActivationMicros = now;
    _setPressed(false);
    if (widget.playSound) {
      unawaited(AudioManager.instance.playButton());
    }
    if (widget.hapticFeedback) {
      unawaited(AudioManager.instance.lightImpact());
    }
    callback();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      enabled: widget.enabled,
      label: widget.semanticLabel,
      child: GestureDetector(
        behavior: widget.enabled ? HitTestBehavior.opaque : HitTestBehavior.deferToChild,
        onTapDown: widget.enabled ? (_) => _setPressed(true) : null,
        onTapUp: widget.enabled ? (_) => _setPressed(false) : null,
        onTapCancel: widget.enabled ? () => _setPressed(false) : null,
        onTap: widget.enabled ? _activate : null,
        child: AnimatedScale(
          scale: _pressed ? widget.pressedScale : 1,
          duration: const Duration(milliseconds: 92),
          curve: Curves.easeOutCubic,
          child: widget.builder(context, _pressed),
        ),
      ),
    );
  }
}
