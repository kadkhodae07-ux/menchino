import 'dart:async';

import 'package:flutter/material.dart';

import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../player/player_progress_controller.dart';
import '../v3/features/lobby_page.dart';
import '../v3/features/missions_page.dart';
import '../v3/features/mode_selection_page.dart';
import '../v3/features/profile_page.dart';
import '../v3/features/ranking_page.dart';
import '../v3/features/settings_page.dart';
import '../v3/features/shop_page.dart';
import '../v3/ui/arena_bottom_navigation.dart';
import '../v3/ui/arena_ui.dart';

class HubScreen extends StatefulWidget {
  const HubScreen({super.key});

  @override
  State<HubScreen> createState() => _HubScreenState();
}

class _HubScreenState extends State<HubScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  final PlayerProgressController _progress = PlayerProgressController.instance;
  late final AnimationController _ambient;
  ArenaTab _tab = ArenaTab.home;
  bool _openingGame = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _progress.addListener(_onProgressChanged);
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
    unawaited(AudioManager.instance.startBgm());
  }

  void _onProgressChanged() {
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _progress.refreshMissionCycles();
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      unawaited(_progress.flush());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _progress.removeListener(_onProgressChanged);
    unawaited(_progress.flush());
    _ambient.dispose();
    super.dispose();
  }

  void _showMessage(String message) {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(26, 0, 26, 86),
          duration: const Duration(milliseconds: 1450),
          backgroundColor: const Color(0xFF0B1B30),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(13),
            side: BorderSide(color: ArenaPalette.cyan.withValues(alpha: .48)),
          ),
          content: Text(
            message,
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: ArenaText.body.copyWith(color: ArenaPalette.text),
          ),
        ),
      );
  }

  Future<void> _openGame(GameConfig config) async {
    if (_openingGame) return;
    setState(() => _openingGame = true);
    _ambient.stop(canceled: false);
    try {
      await SceneTransitionManager.openGame(context, config: config);
    } finally {
      if (mounted) {
        _ambient.repeat();
        setState(() => _openingGame = false);
      }
    }
  }

  Future<void> _openModeSelection() async {
    await _pushPage(
      ModeSelectionPage(
        progress: _progress,
        onStart: (GameConfig config) => unawaited(_openGame(config)),
      ),
    );
  }

  Future<void> _openProfile() async {
    await _pushPage(
      ProfilePage(
        progress: _progress,
        onEdit: _editProfile,
        onBack: () => Navigator.of(context).pop(),
      ),
    );
  }

  Future<void> _openSettings() async {
    await _pushPage(
      SettingsPage(
        progress: _progress,
        onBack: () => Navigator.of(context).pop(),
        onMessage: _showMessage,
      ),
    );
  }

  Future<void> _pushPage(Widget page) async {
    await Navigator.of(context).push<void>(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 230),
        reverseTransitionDuration: const Duration(milliseconds: 190),
        pageBuilder: (_, Animation<double> animation, __) {
          final Animation<double> curve = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curve,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(.035, 0),
                end: Offset.zero,
              ).animate(curve),
              child: page,
            ),
          );
        },
      ),
    );
  }

  Future<void> _editProfile() async {
    final TextEditingController controller = TextEditingController(
      text: _progress.playerName,
    );
    final String? value = await showDialog<String>(
      context: context,
      barrierColor: const Color(0xD9000208),
      builder: (BuildContext dialogContext) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.symmetric(horizontal: 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: ArenaSurface(
                accent: ArenaPalette.cyan,
                prominent: true,
                selected: true,
                padding: const EdgeInsets.all(18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const Text('ویرایش نام بازیکن', style: ArenaText.title),
                    const SizedBox(height: 6),
                    const Text('نام بین ۲ تا ۲۴ نویسه باشد.', style: ArenaText.caption),
                    const SizedBox(height: 14),
                    TextField(
                      controller: controller,
                      autofocus: true,
                      maxLength: 24,
                      textDirection: TextDirection.rtl,
                      style: ArenaText.body.copyWith(color: ArenaPalette.text),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: ArenaPalette.surfaceInset,
                        hintText: 'نام بازیکن',
                        counterStyle: ArenaText.caption,
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: ArenaPalette.divider),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: ArenaPalette.cyan, width: 1.5),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: ArenaSurface(
                            onTap: () => Navigator.of(dialogContext).pop(),
                            padding: const EdgeInsets.symmetric(vertical: 13),
                            child: const Text('انصراف', textAlign: TextAlign.center, style: ArenaText.section),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ArenaSurface(
                            accent: ArenaPalette.gold,
                            selected: true,
                            onTap: () => Navigator.of(dialogContext).pop(controller.text),
                            padding: const EdgeInsets.symmetric(vertical: 13),
                            child: const Text('ذخیره', textAlign: TextAlign.center, style: ArenaText.section),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    controller.dispose();
    if (value == null) return;
    final String before = _progress.playerName;
    _progress.updateName(value);
    _showMessage(before == _progress.playerName ? 'نام واردشده معتبر نیست یا تغییری نکرده است' : 'نام بازیکن ذخیره شد');
  }

  Widget _currentPage() {
    return switch (_tab) {
      ArenaTab.home => LobbyPage(
          key: const ValueKey<String>('v3-home'),
          progress: _progress,
          ambient: _ambient,
          onPlay: _openModeSelection,
          onProfile: _openProfile,
          onSettings: _openSettings,
          onMissions: () => setState(() => _tab = ArenaTab.missions),
          onRanking: () => setState(() => _tab = ArenaTab.ranking),
          onShop: () => setState(() => _tab = ArenaTab.shop),
        ),
      ArenaTab.ranking => RankingPage(
          key: const ValueKey<String>('v3-ranking'),
          progress: _progress,
        ),
      ArenaTab.missions => MissionsPage(
          key: const ValueKey<String>('v3-missions'),
          progress: _progress,
          onMessage: _showMessage,
        ),
      ArenaTab.shop => ShopPage(
          key: const ValueKey<String>('v3-shop'),
          progress: _progress,
          onMessage: _showMessage,
        ),
    };
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_openingGame,
      child: ArenaPage(
        bottomNavigation: ArenaBottomNavigation(
          active: _tab,
          onChanged: (ArenaTab tab) {
            if (_tab != tab) setState(() => _tab = tab);
          },
        ),
        child: TickerMode(
          enabled: !_openingGame,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 190),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            transitionBuilder: (Widget child, Animation<double> animation) {
              return FadeTransition(
                opacity: animation,
                child: ScaleTransition(
                  scale: Tween<double>(begin: .992, end: 1).animate(animation),
                  child: child,
                ),
              );
            },
            child: _currentPage(),
          ),
        ),
      ),
    );
  }
}
