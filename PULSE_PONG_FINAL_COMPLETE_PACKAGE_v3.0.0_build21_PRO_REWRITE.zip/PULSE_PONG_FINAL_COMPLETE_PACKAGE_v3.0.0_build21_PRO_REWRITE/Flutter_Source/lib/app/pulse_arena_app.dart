import 'package:flutter/material.dart';

import '../core/design/pulse_tokens.dart';
import '../screens/hub_screen.dart';

class PulseArenaApp extends StatelessWidget {
  const PulseArenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PULSE PONG',
      theme: buildPulseArenaTheme(),
      home: const HubScreen(),
    );
  }
}
