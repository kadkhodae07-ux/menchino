#!/usr/bin/env python3
"""Static release validation for PULSE PONG when Flutter SDK is unavailable.

This does not replace `flutter analyze`, `flutter test`, or an Android build.
It verifies package integrity, local imports, delimiters, Android XML, release
identity, modular routes, performance safeguards, ad surfaces, and removal of
legacy duplicate UI implementations.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
FAILURES: list[str] = []
CHECKS = 0


def check(condition: bool, message: str) -> None:
    global CHECKS
    CHECKS += 1
    if not condition:
        FAILURES.append(message)


def read(relative: str) -> str:
    path = ROOT / relative
    check(path.is_file(), f"missing file: {relative}")
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def validate_imports() -> None:
    dart_files = list((ROOT / "lib").rglob("*.dart")) + list(
        (ROOT / "test").rglob("*.dart")
    )
    pattern = re.compile(r"^import\s+['\"]([^'\"]+)['\"]", re.MULTILINE)
    for source in dart_files:
        for match in pattern.finditer(source.read_text(encoding="utf-8")):
            uri = match.group(1)
            target: Path | None = None
            if uri.startswith("package:pulse_arena/"):
                target = ROOT / "lib" / uri.removeprefix("package:pulse_arena/")
            elif uri.startswith("."):
                target = (source.parent / uri).resolve()
            if target is not None:
                check(
                    target.is_file(),
                    f"broken Dart import in {source.relative_to(ROOT)}: {uri}",
                )


def validate_delimiters() -> None:
    pairs = {")": "(", "]": "[", "}": "{"}
    openers = set(pairs.values())
    files = list((ROOT / "lib").rglob("*.dart")) + list(
        (ROOT / "test").rglob("*.dart")
    )
    for path in files:
        source = path.read_text(encoding="utf-8")
        stack: list[tuple[str, int]] = []
        line = 1
        index = 0
        state = "code"
        quote = ""
        triple = False
        raw = False
        valid = True
        while index < len(source):
            char = source[index]
            next_char = source[index + 1] if index + 1 < len(source) else ""
            if char == "\n":
                line += 1
            if state == "line_comment":
                if char == "\n":
                    state = "code"
            elif state == "block_comment":
                if char == "*" and next_char == "/":
                    state = "code"
                    index += 1
            elif state == "string":
                if not raw and char == "\\":
                    index += 1
                elif triple and source[index : index + 3] == quote * 3:
                    state = "code"
                    index += 2
                elif not triple and char == quote:
                    state = "code"
            else:
                if char == "/" and next_char == "/":
                    state = "line_comment"
                    index += 1
                elif char == "/" and next_char == "*":
                    state = "block_comment"
                    index += 1
                elif char in "'\"" or (char in "rR" and next_char in "'\""):
                    if char in "rR":
                        raw = True
                        index += 1
                        char = source[index]
                    else:
                        raw = False
                    quote = char
                    triple = source[index : index + 3] == char * 3
                    state = "string"
                    if triple:
                        index += 2
                elif char in openers:
                    stack.append((char, line))
                elif char in pairs:
                    if not stack or stack[-1][0] != pairs[char]:
                        FAILURES.append(
                            f"delimiter mismatch in {path.relative_to(ROOT)} line {line}"
                        )
                        valid = False
                        break
                    stack.pop()
            index += 1
        check(valid and not stack, f"unclosed delimiter in {path.relative_to(ROOT)}")


def validate_android_xml() -> None:
    xml_files = list((ROOT / "android" / "app" / "src" / "main").rglob("*.xml"))
    check(bool(xml_files), "Android XML files were not found")
    for path in xml_files:
        try:
            ET.parse(path)
        except ET.ParseError as error:
            FAILURES.append(f"invalid XML {path.relative_to(ROOT)}: {error}")


def validate_release_contract() -> None:
    pubspec = read("pubspec.yaml")
    gradle = read("android/app/build.gradle.kts")
    manifest = read("android/app/src/main/AndroidManifest.xml")
    activity = read(
        "android/app/src/main/kotlin/com/manyshah/pulsearena/MainActivity.kt"
    )
    hub = read("lib/screens/hub_screen.dart")
    game = read("lib/game/pulse_arena_game.dart")
    ball = read("lib/game/components/ball_controller.dart")
    transition = read("lib/game/managers/scene_transition_manager.dart")
    ads = read("lib/v3/ads/ad_surfaces.dart")
    settings = read("lib/v3/features/settings_page.dart")
    shop = read("lib/v3/features/shop_page.dart")
    game_screen = read("lib/screens/game_screen.dart")
    wrapper = read("android/gradlew")
    wrapper_properties = read("android/gradle/wrapper/gradle-wrapper.properties")

    check("version: 3.0.0+21" in pubspec, "wrong pubspec version")
    check("PULSE PONG" in pubspec, "release title missing from pubspec")
    check(
        'applicationId = "com.manyshah.pulsearena"' in gradle,
        "Android applicationId changed",
    )
    check('create("bazaar")' in gradle, "Bazaar flavor missing")
    check('create("myket")' in gradle, "Myket flavor missing")
    check("android.permission.INTERNET" in manifest, "INTERNET permission missing")
    check("PULSE PONG" in gradle, "flavor app name not upgraded")
    check("com.android.vending" in manifest, "Google Play package visibility query missing")
    check("GRADLE_VERSION=8.9" in wrapper, "Gradle bootstrap launcher missing or wrong")
    check("gradle-8.9-bin.zip" in wrapper_properties, "Gradle wrapper distribution mismatch")

    for route in (
        "LobbyPage",
        "RankingPage",
        "MissionsPage",
        "ShopPage",
        "ProfilePage",
        "SettingsPage",
        "ModeSelectionPage",
    ):
        check(route in hub, f"hub route missing: {route}")

    check(not (ROOT / "lib/screens/hub").exists(), "legacy hub folder still exists")
    check(not (ROOT / "lib/features/lobby").exists(), "legacy lobby folder still exists")
    check(
        not (ROOT / "lib/screens/mode_selection_screen.dart").exists(),
        "legacy mode selection screen still exists",
    )
    check(not (ROOT / "lib/screens/home_screen.dart").exists(), "obsolete home compatibility screen still exists")
    check(not (ROOT / "lib/core/design/layered_game_panel.dart").exists(), "unused v2 layered panel still exists")
    check(not (ROOT / "lib/core/design/pulse_progress.dart").exists(), "unused v2 progress widget still exists")

    check("_physicsStep = 1 / 120" in ball, "fixed-step ball physics missing")
    check("_uiAccumulator >= 0.05" in game, "20 Hz HUD sync missing")
    check("_stableFrameCredit" in game, "performance recovery counter missing")
    check("_reducedEffects = false" in game, "effect recovery path missing")
    check(
        "await OrientationManager.showGame()" in transition
        and "await OrientationManager.showHome()" in transition,
        "orientation changes are not awaited",
    )
    check("controlSensitivity" in game, "real control sensitivity is not wired")
    check("class _LocalDuelControlZones" in game_screen, "local duel control zones missing")
    check("PlayerProgressController.instance.playerName" in game_screen, "player identity is not connected to gameplay HUD")
    check("فرمانده پالس" not in game_screen and "نوا" not in game_screen, "stale v2 gameplay identity remains")
    check("setControlSensitivity" in settings, "control sensitivity UI missing")

    check("class ResponsiveAdBanner" in ads, "responsive banner missing")
    check("BoxFit.cover" in ads, "banner does not preserve image ratio")
    check("reserveSpaceWhenEmpty" in ads, "banner slot can jump while loading")
    check("class VideoAdEndCard" in ads, "video end card missing")
    check("class VideoAdFlowController" in ads, "completed-video flow controller missing")
    check("if (!completed || !context.mounted) return false;" in ads, "end card can appear after an incomplete video")
    check(
        "class VideoAdCompletionPresenter" in ads,
        "video completion presenter missing",
    )
    check("openInlineInstall" in ads, "install bridge missing in Dart")
    check("https://play.google.com/d" in activity, "inline install deep link missing")
    check('putExtra("overlay", true)' in activity, "inline overlay extra missing")
    check("store/apps/details?id=" in activity, "Play Store fallback missing")

    forbidden_colors = (
        "0xFFD66F96",
        "0xFF8E7AF4",
        "0xFFB765FF",
        "0xFFE678BA",
        "0xFFE86AA9",
        "0xFF8F79F4",
    )
    check(
        not any(token in shop or token in game for token in forbidden_colors),
        "old magenta/purple product palette still exists",
    )

    for marker in ("TODO", "FIXME", "Lorem ipsum", "Placeholder("):
        check(marker not in "\n".join((hub, settings, shop, ads)), f"release marker found: {marker}")


def validate_assets() -> None:
    pubspec = read("pubspec.yaml")
    for directory in ("assets/audio", "assets/branding"):
        path = ROOT / directory
        check(path.is_dir(), f"asset directory missing: {directory}")
        check(any(item.is_file() for item in path.rglob("*")), f"empty asset directory: {directory}")
    check("assets/audio/" in pubspec, "audio asset declaration missing")
    check("assets/branding/" in pubspec, "branding asset declaration missing")


def main() -> int:
    validate_imports()
    validate_delimiters()
    validate_android_xml()
    validate_release_contract()
    validate_assets()

    if FAILURES:
        print(f"STATIC VALIDATION FAILED: {len(FAILURES)} failure(s) / {CHECKS} checks")
        for failure in FAILURES:
            print(f"- {failure}")
        return 1
    print(f"STATIC VALIDATION PASSED: {CHECKS} checks")
    print("Dart/Flutter compilation was not executed by this Python validator.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
