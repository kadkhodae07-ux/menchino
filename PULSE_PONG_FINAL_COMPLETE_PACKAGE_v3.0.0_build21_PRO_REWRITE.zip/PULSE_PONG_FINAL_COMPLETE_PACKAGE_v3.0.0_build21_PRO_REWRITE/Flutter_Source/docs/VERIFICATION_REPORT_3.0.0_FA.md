# گزارش بررسی نسخه 3.0.0+21

## نتیجه قطعی انجام‌شده

اسکریپت `tool/validate_release.py` با نتیجه زیر اجرا شد:

```text
STATIC VALIDATION PASSED: 202 checks
Dart/Flutter compilation was not executed by this Python validator.
```

موارد بررسی‌شده شامل Importهای داخلی، توازن Delimiterهای Dart، XMLهای Android، نسخه، Package Name، Flavorها، مسیر تمام صفحات، حذف پیاده‌سازی‌های قدیمی، فیزیک ثابت، کنترل عملکرد، تغییر جهت صفحه، تنظیم حساسیت، بنر واکنش‌گرا، End Card، پل نصب، Gradle launcher و Assetها است.

## بررسی‌های تکمیلی انجام‌شده

- تمام XMLهای Android با parser استاندارد Python خوانده شدند.
- هیچ Import محلی شکسته‌ای پیدا نشد.
- هیچ پوشه تکراری `lib/screens/hub` یا `lib/features/lobby` باقی نمانده است.
- نسخه در `pubspec.yaml` برابر `3.0.0+21` است.
- Package Name برابر `com.manyshah.pulsearena` حفظ شده است.
- Flavorهای بازار و مایکت حفظ شده‌اند.
- فایل `android/gradlew` اجرایی و Gradle 8.9 برای AGP 8.7.3 تنظیم شده است.

## مواردی که در این محیط اجرا نشد

Flutter SDK و Dart SDK در محیط موجود نبودند. به همین دلیل موارد زیر اجرا نشده‌اند:

```bash
dart format .
flutter analyze
flutter test
flutter build apk --debug --flavor bazaar
flutter build apk --debug --flavor myket
```

بنابراین این گزارش ادعای Compile یا Build موفق APK ندارد. این فرمان‌ها باید در GitHub Actions یا سیستم توسعه دارای Flutter Stable اجرا شوند.

## معیار تست دستگاه

برای ارزیابی نهایی عملکرد روی گوشی واقعی:

- اجرای Profile Mode روی گوشی میان‌رده
- بررسی Frame Time رابط و Raster زیر 16.7ms برای هدف 60FPS
- اجرای حداقل سه مسابقه در هر سطح ربات
- تست دونفره با دو لمس هم‌زمان
- تغییر چندباره Portrait/Landscape بدون فریم چرخیده
- تست ارتفاع‌های 640، 720، 800 و 900dp در لابی
- تست بنرهای با نسبت‌های مختلف در عرض واقعی جایگاه
- تأیید اینکه End Card فقط بعد از callback تکمیل ویدئو ظاهر می‌شود
- تست نصب نیم‌صفحه روی دستگاه واجد شرایط و fallback روی دستگاه ناسازگار

## بررسی Asset و فایل‌ها

- ۸ تصویر PNG پروژه و منابع Android با PIL باز و Verify شدند.
- ۱۴ فایل صوتی با `ffprobe` خوانده شدند.
- تعداد فایل صفر بایت: ۰
- تعداد فایل متنی بررسی‌شده از نظر UTF-8: ۷۳
- مجوز اجرایی `android/gradlew` تأیید شد.
