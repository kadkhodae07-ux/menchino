-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
# Flutter deferred components are not used in this offline APK.
# Keep these optional Google Play Core references from becoming fatal if
# minification is enabled manually in a future local build.
-dontwarn com.google.android.play.core.**
