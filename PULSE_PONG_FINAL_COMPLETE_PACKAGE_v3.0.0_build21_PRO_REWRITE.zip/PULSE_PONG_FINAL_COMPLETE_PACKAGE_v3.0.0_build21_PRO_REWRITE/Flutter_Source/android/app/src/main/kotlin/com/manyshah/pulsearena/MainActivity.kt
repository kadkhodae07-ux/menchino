package com.manyshah.pulsearena

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlin.math.abs

class MainActivity : FlutterActivity() {
    private val channelName = "com.manyshah.pulsearena/local_state"
    private val preferencesName = "pulse_arena_state"
    private val stateKey = "player_state_json"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                val preferences = getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
                when (call.method) {
                    "loadState" -> result.success(preferences.getString(stateKey, null))
                    "saveState" -> {
                        val json = call.arguments as? String
                        if (json == null) {
                            result.error("INVALID_STATE", "State payload must be a JSON string.", null)
                        } else {
                            preferences.edit().putString(stateKey, json).apply()
                            result.success(null)
                        }
                    }
                    "clearState" -> {
                        preferences.edit().remove(stateKey).apply()
                        result.success(null)
                    }
                    "setPreferredFrameRate" -> {
                        val requested = (call.arguments as? Number)?.toInt() ?: 60
                        applyPreferredFrameRate(requested)
                        result.success(null)
                    }
                    "openInlineInstall" -> {
                        val args = call.arguments as? Map<*, *>
                        val targetPackage = args?.get("packageName") as? String
                        val referrer = args?.get("referrer") as? String ?: ""
                        if (targetPackage.isNullOrBlank()) {
                            result.error("INVALID_PACKAGE", "Target package name is required.", null)
                        } else {
                            result.success(openInlineInstall(targetPackage, referrer))
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun applyPreferredFrameRate(requested: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val display = windowManager.defaultDisplay
        val current = display.mode
        val candidates = display.supportedModes.filter {
            it.physicalWidth == current.physicalWidth &&
                it.physicalHeight == current.physicalHeight
        }
        if (candidates.isEmpty()) return
        val target = requested.coerceIn(60, 120).toFloat()
        val best = candidates.minByOrNull { abs(it.refreshRate - target) } ?: return
        val attributes = window.attributes
        attributes.preferredDisplayModeId = best.modeId
        window.attributes = attributes
    }

    private fun openInlineInstall(targetPackage: String, referrer: String): Boolean {
        val callerId = applicationContext.packageName
        val deepLink = Uri.parse("https://play.google.com/d").buildUpon()
            .appendQueryParameter("id", targetPackage)
            .appendQueryParameter("referrer", referrer)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val inlineIntent = Intent(Intent.ACTION_VIEW).apply {
                setPackage("com.android.vending")
                data = deepLink
                putExtra("overlay", true)
                putExtra("callerId", callerId)
            }
            if (inlineIntent.resolveActivity(packageManager) != null) {
                startActivityForResult(inlineIntent, 0)
                return true
            }
        }

        val fallback = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/apps/details?id=$targetPackage"),
        )
        if (fallback.resolveActivity(packageManager) != null) {
            startActivity(fallback)
            return true
        }
        return false
    }
}
