PULSE ARENA — تحویل نسخه 2.1.0+17

محتویات این بسته:
1) Flutter_Source: سورس کامل Flutter/Flame اصلاح‌شده
2) Reports: گزارش تغییرات، اعتبارسنجی و وضعیت انتشار
3) DELIVERY_README_FA.txt: همین راهنما

فایل Workflow عمداً داخل این ZIP قرار نگرفته است.
فایل مستقل موردنیاز:
PULSE_ARENA_BUILD_APK_WF14.yml

روش استفاده در GitHub:
1) محتوای Repository قبلی را پاک یا آرشیو کن.
2) همین ZIP کامل را بدون استخراج در ریشه Repository آپلود کن؛ WF14 قادر به شناسایی Flutter_Source داخل ZIP است.
3) فایل PULSE_ARENA_BUILD_APK_WF14.yml را جداگانه در مسیر زیر قرار بده:
   .github/workflows/build-apk.yml
4) تغییرات را Commit کن و Workflow را از تب Actions اجرا کن.
5) خروجی موفق شامل APK بازار، APK مایکت، SHA-256 و Build Manifest خواهد بود.
6) در صورت شکست، بسته Failure Logs را ارسال کن.

مشخصات:
- Version: 2.1.0+17
- Package Name: com.manyshah.pulsearena
- Flavors: bazaar / myket
- Winning Score: 10
- Workflow: WF14 (standalone)

نکته اعتبارسنجی:
کنترل‌های ساختاری مستقل از Flutter با موفقیت انجام شده‌اند. Flutter Analyze، Flutter Test و Build APK در محیط محلی اجرا نشده‌اند، چون Flutter/Android SDK در دسترس نبود. WF14 این مراحل را روی GitHub Actions اجرا می‌کند.
