import 'dart:io';
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/components/ball_controller.dart';
import 'package:pulse_arena/game/components/bot_paddle_controller.dart';
import 'package:pulse_arena/game/components/player_paddle_controller.dart';
import 'package:pulse_arena/game/config/game_config.dart';

void main() {
  test('player paddle follows finger position immediately', () {
    const Rect arena = Rect.fromLTWH(0, 0, 1000, 400);
    final PlayerPaddleController player = PlayerPaddleController(
      moveSpeed: 5200,
      acceleration: 85000,
      response: 52,
    )..layout(arena);

    player.setTargetFromTouch(
      arena.bottom - 15,
      eventMicros: 1000000,
    );
    expect(
      player.position.y,
      closeTo(arena.bottom - player.size.y, 0.01),
    );

    player.setTargetFromTouch(
      arena.top + 20,
      eventMicros: 1016000,
    );
    expect(player.position.y, closeTo(arena.top, 0.01));
    expect(player.verticalVelocity, lessThan(0));

    player.endTouch();
    player.update(1 / 60);
    expect(player.position.y, closeTo(arena.top, 0.01));
  });

  test('bot paddle uses humanized and beatable motion values', () {
    const GameConfig config = GameConfig();
    expect(config.botPaddleSpeed, inInclusiveRange(650, 900));
    expect(config.botPaddleAcceleration, inInclusiveRange(6000, 9000));
    expect(config.botReactionDelay, greaterThanOrEqualTo(0.17));
    expect(config.botErrorChance, greaterThanOrEqualTo(0.30));
  });

  test('fixed-step ball movement stays consistent across frame rates', () {
    const GameConfig config = GameConfig(
      ballBaseSpeed: 600,
      ballMaximumSpeed: 600,
      ballSpeedIncreasePerSecond: 0,
    );
    const Rect arena = Rect.fromLTWH(0, 0, 5000, 1200);

    BallController makeBall() {
      final BallController ball = BallController(
        config: config,
        onPlayerScored: () {},
        onBotScored: () {},
        isShieldActive: () => false,
        consumeBoost: () {},
        isBoostArmed: () => false,
        matchElapsedSeconds: () => 0,
      );
      final PlayerPaddleController player = PlayerPaddleController(
        moveSpeed: config.playerPaddleSpeed,
        acceleration: config.playerPaddleAcceleration,
      )..layout(arena);
      final BotPaddleController bot = BotPaddleController(
        config: config,
        ball: ball,
        playerScore: () => 0,
        botScore: () => 0,
        isPulseActive: () => false,
      )..layout(arena);
      ball
        ..attachPaddles(player, bot)
        ..layout(arena)
        ..resetToCenter(serveDirection: 1)
        ..velocity = Vector2(600, 0)
        ..launch();
      return ball;
    }

    final BallController at60 = makeBall();
    final BallController at30 = makeBall();

    for (int i = 0; i < 30; i++) {
      at60.update(1 / 60);
    }
    for (int i = 0; i < 15; i++) {
      at30.update(1 / 30);
    }

    expect(at60.position.x, closeTo(at30.position.x, 0.8));
    expect(at60.position.y, closeTo(at30.position.y, 0.8));
  });

  test('sustained performance safeguards remain enabled', () {
    final String ball =
        File('lib/game/components/ball_controller.dart').readAsStringSync();
    final String audio =
        File('lib/game/managers/audio_manager.dart').readAsStringSync();
    final String game =
        File('lib/game/pulse_arena_game.dart').readAsStringSync();

    expect(ball, contains('_physicsStep = 1 / 120'));
    expect(ball, contains('trailLimit = reducedEffects ? 4 : (effectQuality == 1 ? 6 : 8)'));
    expect(game, contains('_updatePerformanceGovernor')); 
    expect(ball, contains('iterations < 8'));
    expect(audio, contains('minimumGapMs'));
    expect(audio, contains('_lastHapticMicros'));
    expect(game, contains('_uiAccumulator >= 0.25'));
  });

  test('default match target is ten goals', () {
    expect(const GameConfig().targetScore, 10);
  });
}
