# PULSE ARENA – Flutter + Flame Demo

دموی آفلاین و قابل‌بازی فونگ آینده‌نگر برای Android، ساخته‌شده با Flutter و Flame.

## نسخه

- Flutter app: `1.0.2+3`
- Hotfix: اصلاح Importهای گرافیکی سازگار با Flutter Stable و رفع ۱۳ خطای `flutter analyze` در Build 39

## امکانات

- صفحه شروع گرافیکی و Transition نرم
- مسابقه آفلاین تا امتیاز ۷ مقابل ربات متوسط
- کنترل لمسی نرم با Drag
- توپ انرژی با Glow، Trail و ذرات برخورد
- ربات با پیش‌بینی مسیر، تأخیر واکنش، محدودیت سرعت و خطای عمدی
- قدرت‌های سپر، شتاب و پالس
- شمارش معکوس ۳، ۲، ۱ بعد از هر امتیاز
- Pause، ادامه، شروع مجدد و بازگشت
- نتیجه برد/باخت و بازی دوباره
- صدا و لرزش قابل خاموش‌کردن از منوی Pause
- Android Landscape و Safe Area
- Flavorهای بازار و مایکت در پروژه؛ Workflow نهایی فقط یک APK بازار می‌سازد

## Workflow نهایی

فایل `.github/workflows/build-pulse-arena.yml`:

- جدیدترین ZIP سورس موجود در مخزن را خودکار تشخیص می‌دهد.
- `flutter pub get` و `flutter analyze` را اجرا می‌کند.
- تست‌ها را فقط در صورت وجود فایل تست اجرا می‌کند.
- فقط یک APK Release با Flavor بازار می‌سازد.
- در صورت شکست، لاگ کامل را به‌صورت Artifact تحویل می‌دهد.
- نام APK را از نسخه داخل `pubspec.yaml` تولید می‌کند.

## امضای Release

برای امضای فروشگاهی Secrets زیر را در GitHub تعریف کنید:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

اگر هیچ Secret امضایی تعریف نشده باشد، تنظیم fallback خود پروژه استفاده می‌شود که برای تست مناسب است، نه انتشار نهایی فروشگاه.
