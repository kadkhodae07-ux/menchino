#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

flutter create \
  --platforms=android \
  --android-language kotlin \
  --project-name pulse_arena \
  "$TMP_DIR/wrapper_seed"

SEED_ANDROID="$TMP_DIR/wrapper_seed/android"
mkdir -p android/gradle/wrapper
cp "$SEED_ANDROID/gradlew" android/gradlew
cp "$SEED_ANDROID/gradlew.bat" android/gradlew.bat
cp "$SEED_ANDROID/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
cp "$SEED_ANDROID/gradle/wrapper/gradle-wrapper.properties" android/gradle/wrapper/gradle-wrapper.properties
chmod +x android/gradlew

SEED_ANDROID="$SEED_ANDROID" python3 - <<'PY'
import os
import re
from pathlib import Path

project = Path('android/settings.gradle.kts')
seed = Path(os.environ['SEED_ANDROID']) / 'settings.gradle.kts'
project_text = project.read_text(encoding='utf-8')
seed_text = seed.read_text(encoding='utf-8')
for plugin_id in ('com.android.application', 'org.jetbrains.kotlin.android'):
    pattern = rf'id\("{re.escape(plugin_id)}"\)\s+version\s+"([^"]+)"'
    version = re.search(pattern, seed_text)
    if version is None:
        raise SystemExit(f'Plugin version not found in Flutter template: {plugin_id}')
    project_text, count = re.subn(
        pattern,
        f'id("{plugin_id}") version "{version.group(1)}"',
        project_text,
        count=1,
    )
    if count != 1:
        raise SystemExit(f'Plugin declaration not found in project: {plugin_id}')
project.write_text(project_text, encoding='utf-8')

project_props = Path('android/gradle.properties')
seed_props = Path(os.environ['SEED_ANDROID']) / 'gradle.properties'
project_lines = project_props.read_text(encoding='utf-8').splitlines()
seed_lines = seed_props.read_text(encoding='utf-8').splitlines()
keys = ('android.newDsl', 'android.builtInKotlin')
values = {
    key: next((line.strip() for line in seed_lines if line.strip().startswith(f'{key}=')), None)
    for key in keys
}
project_lines = [
    line for line in project_lines
    if not any(line.strip().startswith(f'{key}=') for key in keys)
]
project_lines.extend(value for value in values.values() if value is not None)
project_props.write_text('\n'.join(project_lines) + '\n', encoding='utf-8')
PY

./android/gradlew --version
