import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/data.dart';

class AvatarBadge extends StatelessWidget {
  final int index;
  final double size;
  final bool selected;
  final VoidCallback? onTap;

  const AvatarBadge({
    super.key,
    required this.index,
    this.size = 52,
    this.selected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final spec = avatars[index.clamp(0, avatars.length - 1).toInt()];
    final badge = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: spec.background.withOpacity(.76),
        border: Border.all(
          color: selected ? Colors.white.withOpacity(.94) : Colors.white.withOpacity(.15),
          width: selected ? 2 : 1,
        ),
        boxShadow: selected
            ? [BoxShadow(color: spec.shirt.withOpacity(.22), blurRadius: 16)]
            : null,
      ),
      clipBehavior: Clip.antiAlias,
      child: CustomPaint(painter: _AvatarPainter(spec)),
    );
    if (onTap == null) return badge;
    return GestureDetector(onTap: onTap, child: badge);
  }
}

class _AvatarPainter extends CustomPainter {
  final AvatarSpec spec;

  const _AvatarPainter(this.spec);

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;

    canvas.drawCircle(Offset(cx, h * .43), w * .22, Paint()..color = spec.skin);

    final hair = Paint()..color = spec.hair;
    final hairRect = Rect.fromCenter(center: Offset(cx, h * .35), width: w * .46, height: h * .26);
    canvas.drawArc(hairRect, 3.05, 3.25, true, hair);
    if (spec.gender == 'دختر') {
      canvas.drawOval(Rect.fromLTWH(w * .19, h * .33, w * .16, h * .34), hair);
      canvas.drawOval(Rect.fromLTWH(w * .65, h * .33, w * .16, h * .34), hair);
    }

    final eye = Paint()..color = const Color(0xFF20252D);
    canvas.drawCircle(Offset(w * .43, h * .43), max(1.0, w * .018).toDouble(), eye);
    canvas.drawCircle(Offset(w * .57, h * .43), max(1.0, w * .018).toDouble(), eye);

    final mouth = Paint()
      ..color = const Color(0xFF8C4C50)
      ..strokeWidth = max(1.0, w * .015).toDouble()
      ..style = PaintingStyle.stroke;
    canvas.drawArc(Rect.fromCenter(center: Offset(cx, h * .50), width: w * .13, height: h * .07), .15, 2.8, false, mouth);

    final shirt = Paint()..color = spec.shirt;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(w * .22, h * .63, w * .56, h * .42), Radius.circular(w * .18)),
      shirt,
    );
  }

  @override
  bool shouldRepaint(covariant _AvatarPainter oldDelegate) => oldDelegate.spec != spec;
}
