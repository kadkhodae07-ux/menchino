import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/league.dart';
import '../../core/state/app_state.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';

class RankScreen extends StatelessWidget {
  final bool embedded;
  final VoidCallback? onBack;

  const RankScreen({super.key, this.embedded = false, this.onBack});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final league = buildLocalZarbuLeague(
      userName: state.name,
      userAvatar: state.avatar,
      userPoints: state.leaguePoints,
    );
    final myRank = league.rankOf('me');
    final matches = state.stats['matches'] ?? 0;
    final wins = state.stats['wins'] ?? 0;
    final losses = state.stats['losses'] ?? 0;
    final winRate = matches > 0 ? (wins * 100 / matches).round() : 0;

    final content = SafeArea(
      top: true,
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GamePageHeader(
              title: 'لیگ ضربو',
              subtitle: 'ZARBU LEAGUE • یک لیگ، یک جام، یک قهرمان',
              onBack: onBack,
            ),
            const SizedBox(height: 14),
            _LeagueHero(points: state.leaguePoints, rank: myRank, season: state.season),
            const SizedBox(height: 16),
            _SectionTitle(title: 'سه نفر برتر', icon: 'crown', color: theme.gold),
            const SizedBox(height: 10),
            _TopThree(players: league.players.take(3).toList()),
            const SizedBox(height: 16),
            _MyRankCard(player: league.players.firstWhere((p) => p.id == 'me'), rank: myRank),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _MetricCard(label: 'برد', value: '$wins', icon: 'crown', color: theme.accent)),
                const SizedBox(width: 10),
                Expanded(child: _MetricCard(label: 'درصد برد', value: '$winRate٪', icon: 'rank', color: theme.primary)),
                const SizedBox(width: 10),
                Expanded(child: _MetricCard(label: 'رالی', value: '${state.stats['bestRally'] ?? 0}', icon: 'fast', color: theme.secondary)),
              ],
            ),
            const SizedBox(height: 16),
            NeonPanel(
              borderColor: theme.primary,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      AppIcons.icon('rank', size: 22, color: theme.primary),
                      const SizedBox(width: 8),
                      Expanded(child: Text('جدول لیگ ضربو', style: TextStyle(color: theme.text, fontSize: 17, fontWeight: FontWeight.w900))),
                      StatBadge('فصل ${state.season}', color: theme.primary),
                    ],
                  ),
                  const SizedBox(height: 12),
                  for (var index = 3; index < league.players.length; index++) ...[
                    _LeaderboardRow(player: league.players[index], rank: index + 1),
                    if (index != league.players.length - 1) Divider(height: 14, color: theme.dim.withOpacity(.08)),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 14),
            NeonPanel(
              borderColor: theme.secondary,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('رکورد رقابتی', style: TextStyle(color: theme.text, fontSize: 17, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  _statRow(theme, 'مسابقه‌های ثبت‌شده', '$matches'),
                  _divider(theme),
                  _statRow(theme, 'بردها', '$wins'),
                  _divider(theme),
                  _statRow(theme, 'باخت‌ها', '$losses'),
                  _divider(theme),
                  _statRow(theme, 'بهترین برد پیاپی', '${state.stats['bestStreak'] ?? 0}'),
                  _divider(theme),
                  _statRow(theme, 'پاورآپ جمع‌شده', '${state.stats['powerCollected'] ?? 0}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );

    if (embedded) return content;
    return Scaffold(backgroundColor: theme.bg, body: content);
  }

  Widget _statRow(dynamic theme, String label, String value) => Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: theme.dim, fontSize: 13))),
          Text(value, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
        ],
      );

  Widget _divider(dynamic theme) => Divider(height: 20, color: theme.dim.withOpacity(.09));
}

class _LeagueHero extends StatelessWidget {
  final int points;
  final int rank;
  final String season;

  const _LeagueHero({required this.points, required this.rank, required this.season});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return NeonPanel(
      borderColor: theme.gold,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 330;
          final cup = SizedBox(
            width: compact ? 92 : 108,
            height: compact ? 116 : 132,
            child: Image.asset(
              'assets/images/zarbu_league_cup.png',
              fit: BoxFit.contain,
              filterQuality: FilterQuality.high,
              errorBuilder: (_, __, ___) => Center(child: AppIcons.icon('rank', size: 42, color: theme.gold)),
            ),
          );
          final info = Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ZARBU LEAGUE', style: TextStyle(color: theme.gold, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                const SizedBox(height: 4),
                Text('لیگ ضربو', style: TextStyle(color: theme.text, fontSize: 27, fontWeight: FontWeight.w900)),
                const SizedBox(height: 7),
                Wrap(
                  spacing: 7,
                  runSpacing: 7,
                  children: [
                    StatBadge('$points LP', color: theme.gold),
                    StatBadge('رتبه #$rank', color: theme.primary),
                    StatBadge('فصل $season', color: theme.secondary),
                  ],
                ),
                const SizedBox(height: 8),
                Text('تمام رقابت‌های رتبه‌ای بازی در همین لیگ محاسبه می‌شوند.', style: TextStyle(color: theme.dim, fontSize: 11.5, height: 1.55)),
              ],
            ),
          );
          return Row(crossAxisAlignment: CrossAxisAlignment.center, children: [cup, const SizedBox(width: 13), info]);
        },
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String icon;
  final Color color;

  const _SectionTitle({required this.title, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return Row(
      children: [
        AppIcons.icon(icon, size: 20, color: color),
        const SizedBox(width: 8),
        Text(title, style: TextStyle(color: theme.text, fontSize: 18, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _TopThree extends StatelessWidget {
  final List<LeaguePlayer> players;

  const _TopThree({required this.players});

  @override
  Widget build(BuildContext context) {
    if (players.length < 3) return const SizedBox.shrink();
    return LayoutBuilder(
      builder: (context, constraints) {
        final gap = constraints.maxWidth < 360 ? 7.0 : 10.0;
        return Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(child: _PodiumCard(player: players[1], place: 2, height: 178)),
            SizedBox(width: gap),
            Expanded(child: _PodiumCard(player: players[0], place: 1, height: 204)),
            SizedBox(width: gap),
            Expanded(child: _PodiumCard(player: players[2], place: 3, height: 168)),
          ],
        );
      },
    );
  }
}

class _PodiumCard extends StatelessWidget {
  final LeaguePlayer player;
  final int place;
  final double height;

  const _PodiumCard({required this.player, required this.place, required this.height});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    final color = place == 1
        ? theme.gold
        : place == 2
            ? const Color(0xFFC7D8EC)
            : const Color(0xFFC9875A);
    return Container(
      height: height,
      padding: const EdgeInsets.fromLTRB(8, 11, 8, 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(21),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color.withOpacity(.20), theme.panel.withOpacity(.98)],
        ),
        border: Border.all(color: color.withOpacity(player.isCurrentUser ? .86 : .40), width: player.isCurrentUser ? 1.8 : 1.1),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.28), blurRadius: 18, offset: const Offset(0, 9)),
          BoxShadow(color: color.withOpacity(place == 1 ? .20 : .10), blurRadius: place == 1 ? 24 : 15),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: place == 1 ? 34 : 29,
            height: place == 1 ? 34 : 29,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.18), border: Border.all(color: color.withOpacity(.55))),
            child: Text('$place', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: place == 1 ? 16 : 13)),
          ),
          const SizedBox(height: 8),
          AvatarBadge(index: player.avatar, size: place == 1 ? 66 : 55, selected: player.isCurrentUser),
          const SizedBox(height: 8),
          Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontSize: place == 1 ? 14 : 12, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text('${player.points} LP', maxLines: 1, style: TextStyle(color: color, fontSize: place == 1 ? 12 : 10.5, fontWeight: FontWeight.w900)),
          if (place == 1) ...[
            const SizedBox(height: 5),
            SizedBox(height: 25, child: Image.asset('assets/images/zarbu_league_cup.png', fit: BoxFit.contain, filterQuality: FilterQuality.high)),
          ],
        ],
      ),
    );
  }
}

class _MyRankCard extends StatelessWidget {
  final LeaguePlayer player;
  final int rank;

  const _MyRankCard({required this.player, required this.rank});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return NeonPanel(
      borderColor: theme.accent,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: theme.accent.withOpacity(.12), border: Border.all(color: theme.accent.withOpacity(.32))),
            child: Text('#$rank', style: TextStyle(color: theme.accent, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 10),
          AvatarBadge(index: player.avatar, size: 48, selected: true),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('رتبه من', style: TextStyle(color: theme.dim, fontSize: 10.5, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
          ),
          Text('${player.points} LP', style: TextStyle(color: theme.accent, fontSize: 14, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  final LeaguePlayer player;
  final int rank;

  const _LeaderboardRow({required this.player, required this.rank});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: player.isCurrentUser ? theme.primary.withOpacity(.09) : Colors.transparent,
        border: player.isCurrentUser ? Border.all(color: theme.primary.withOpacity(.24)) : null,
      ),
      child: Row(
        children: [
          SizedBox(width: 34, child: Text('#$rank', textAlign: TextAlign.center, style: TextStyle(color: player.isCurrentUser ? theme.primary : theme.dim, fontWeight: FontWeight.w900))),
          AvatarBadge(index: player.avatar, size: 38, selected: player.isCurrentUser),
          const SizedBox(width: 9),
          Expanded(child: Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontSize: 13, fontWeight: FontWeight.w800))),
          Text('${player.points} LP', style: TextStyle(color: player.isCurrentUser ? theme.primary : theme.dim, fontSize: 12, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final String icon;
  final Color color;

  const _MetricCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return NeonPanel(
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      child: Column(
        children: [
          AppIcons.icon(icon, size: 20, color: color),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(color: theme.text, fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim, fontSize: 9.5, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
