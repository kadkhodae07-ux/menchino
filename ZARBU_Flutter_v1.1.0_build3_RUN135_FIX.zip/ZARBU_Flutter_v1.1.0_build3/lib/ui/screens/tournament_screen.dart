import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'game_screen.dart';

class TournamentScreen extends StatelessWidget {
  const TournamentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final activeId = state.tournament['activeId'] as String?;
    final active = _findTournament(activeId);

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        top: true,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          child: Column(
            children: [
              GamePageHeader(
                title: 'تورنمنت',
                subtitle: 'رقابت چندمرحله‌ای با جایزه بزرگ‌تر',
                actions: [Chip3D(text: '${state.coins}')],
              ),
              const SizedBox(height: 14),
              if (active != null) ...[
                NeonPanel(
                  borderColor: theme.gold,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          AppIcons.icon(active.icon, size: 32, color: theme.gold),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(active.name, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 17)),
                                Text('دور ${state.tournament['round']} از ${active.rounds}', style: TextStyle(color: theme.dim, fontSize: 13)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _RoundProgress(total: active.rounds, current: (state.tournament['round'] as num?)?.toInt() ?? 1),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: NeonButton(
                              label: 'انصراف',
                              small: true,
                              color: theme.danger,
                              onTap: () async {
                                final confirmed = await showNeonConfirm(
                                  context,
                                  title: 'انصراف از تورنمنت',
                                  message: 'هزینه ورود بازگردانده نمی‌شود.',
                                  confirmLabel: 'انصراف',
                                  danger: true,
                                );
                                if (!confirmed) return;
                                state.tournament = {'activeId': null, 'round': 0};
                                await state.save();
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: NeonButton(
                              label: 'ادامه مسابقه',
                              small: true,
                              color: theme.accent,
                              onTap: () => Navigator.push(
                                context,
                                zarbuRoute(
                                  GameScreen.tournament(
                                    active,
                                    (state.tournament['round'] as num?)?.toInt() ?? 1,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ] else ...[
                NeonPanel(child: Text('هنوز در تورنومنتی ثبت‌نام نکرده‌ای.', textAlign: TextAlign.center, style: TextStyle(color: theme.dim))),
                const SizedBox(height: 12),
              ],
              for (final tournament in tournaments) ...[
                NeonPanel(
                  borderColor: tournament.id == 'weekly' ? theme.gold : theme.primary,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          AppIcons.icon(tournament.icon, size: 32, color: tournament.id == 'weekly' ? theme.gold : theme.primary),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(tournament.name, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 17)),
                                Text(tournament.desc, style: TextStyle(color: theme.dim, fontSize: 13, height: 1.55)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 7,
                        runSpacing: 7,
                        children: [
                          StatBadge('ورودی: ${tournament.entry} سکه'),
                          StatBadge('جایزه: ${tournament.prize} سکه'),
                          StatBadge('دورها: ${tournament.rounds}'),
                          StatBadge('سختی: ${_difficulty(tournament.difficulty)}'),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _RoundProgress(total: tournament.rounds, current: 0),
                      const SizedBox(height: 12),
                      NeonButton(
                        label: activeId == null ? 'ثبت‌نام' : 'غیرفعال',
                        color: theme.gold,
                        expand: true,
                        onTap: activeId == null
                            ? () async {
                                if (state.coins < tournament.entry) {
                                  showNeonMessage(context, 'سکه کافی برای ورودی تورنمنت نداری.');
                                  return;
                                }
                                state.addCoins(-tournament.entry);
                                state.tournament = {'activeId': tournament.id, 'round': 1};
                                await state.save();
                                if (context.mounted) showNeonMessage(context, 'در ${tournament.name} ثبت‌نام کردی.');
                              }
                            : null,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Tournament? _findTournament(String? id) {
    if (id == null) return null;
    for (final item in tournaments) {
      if (item.id == id) return item;
    }
    return null;
  }

  String _difficulty(String value) => const {'easy': 'آسان', 'medium': 'متوسط', 'hard': 'سخت', 'pro': 'حرفه‌ای'}[value] ?? value;
}

class _RoundProgress extends StatelessWidget {
  final int total;
  final int current;

  const _RoundProgress({required this.total, required this.current});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return Row(
      children: List.generate(total, (index) {
        final round = index + 1;
        final done = current > round;
        final active = current == round;
        return Expanded(
          child: Row(
            children: [
              Expanded(
                child: Container(
                  height: 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(99),
                    color: done || active ? theme.accent.withOpacity(done ? .72 : .40) : theme.dim.withOpacity(.10),
                  ),
                ),
              ),
              const SizedBox(width: 4),
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: done ? theme.accent.withOpacity(.18) : active ? theme.primary.withOpacity(.15) : theme.dim.withOpacity(.08),
                  border: Border.all(color: done ? theme.accent.withOpacity(.45) : active ? theme.primary.withOpacity(.42) : theme.dim.withOpacity(.12)),
                ),
                child: Center(
                  child: done
                      ? AppIcons.icon('check', size: 13, color: theme.accent)
                      : Text('$round', style: TextStyle(color: active ? theme.text : theme.dim, fontWeight: FontWeight.w900, fontSize: 10)),
                ),
              ),
              if (index != total - 1) const SizedBox(width: 4),
            ],
          ),
        );
      }),
    );
  }
}

