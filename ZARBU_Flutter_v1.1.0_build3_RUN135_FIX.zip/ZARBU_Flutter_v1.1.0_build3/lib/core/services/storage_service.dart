import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const _key = 'zarbu_flutter_v1';
  static const _legacyKey = 'phong_flutter_v1';
  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Map<String, dynamic>? load() {
    final raw = _prefs?.getString(_key) ?? _prefs?.getString(_legacyKey);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> save(Map<String, dynamic> data) async {
    final prefs = _prefs;
    if (prefs == null) throw StateError('StorageService.init() must be called first.');
    await prefs.setString(_key, jsonEncode(data));
  }

  Future<void> reset() async {
    final prefs = _prefs;
    if (prefs == null) throw StateError('StorageService.init() must be called first.');
    await prefs.remove(_key);
    await prefs.remove(_legacyKey);
  }
}
