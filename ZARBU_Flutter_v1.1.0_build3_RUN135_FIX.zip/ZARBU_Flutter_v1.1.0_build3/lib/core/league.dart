class LeaguePlayer {
  final String id;
  final String name;
  final int points;
  final int avatar;
  final bool isCurrentUser;

  const LeaguePlayer({
    required this.id,
    required this.name,
    required this.points,
    required this.avatar,
    this.isCurrentUser = false,
  });
}

class ZarbuLeagueSnapshot {
  final String leagueName;
  final List<LeaguePlayer> players;

  const ZarbuLeagueSnapshot({
    this.leagueName = 'لیگ ضربو',
    required this.players,
  });

  int rankOf(String playerId) {
    final index = players.indexWhere((player) => player.id == playerId);
    return index < 0 ? players.length : index + 1;
  }
}

ZarbuLeagueSnapshot buildLocalZarbuLeague({
  required String userName,
  required int userAvatar,
  required int userPoints,
}) {
  final entries = <LeaguePlayer>[
    const LeaguePlayer(id: 'rival_01', name: 'آرین', points: 2360, avatar: 0),
    const LeaguePlayer(id: 'rival_02', name: 'رها', points: 2215, avatar: 5),
    const LeaguePlayer(id: 'rival_03', name: 'کیان', points: 2080, avatar: 2),
    const LeaguePlayer(id: 'rival_04', name: 'آوا', points: 1870, avatar: 7),
    const LeaguePlayer(id: 'rival_05', name: 'سام', points: 1710, avatar: 1),
    const LeaguePlayer(id: 'rival_06', name: 'هلیا', points: 1530, avatar: 6),
    const LeaguePlayer(id: 'rival_07', name: 'رادین', points: 1320, avatar: 3),
    const LeaguePlayer(id: 'rival_08', name: 'نیلا', points: 1110, avatar: 4),
    LeaguePlayer(
      id: 'me',
      name: userName.trim().isEmpty ? 'بازیکن' : userName.trim(),
      points: userPoints,
      avatar: userAvatar,
      isCurrentUser: true,
    ),
  ];
  entries.sort((a, b) {
    final byPoints = b.points.compareTo(a.points);
    if (byPoints != 0) return byPoints;
    return a.id.compareTo(b.id);
  });
  return ZarbuLeagueSnapshot(players: List.unmodifiable(entries));
}
