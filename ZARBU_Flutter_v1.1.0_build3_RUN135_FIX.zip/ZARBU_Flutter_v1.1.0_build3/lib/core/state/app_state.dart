import 'dart:math';

import 'package:flutter/foundation.dart';

import '../data.dart';
import '../services/audio_service.dart';
import '../services/storage_service.dart';
import '../theme.dart';

class AppState extends ChangeNotifier {
  final StorageService storage = StorageService();
  final AudioService audio = AudioService();
  String name = 'بازیکن';
  int avatar = 0;
  String themeId = 'dark';
  int level = 1;
  int xp = 0;
  int coins = 300;
  int gems = 5;
  Map<String, String> selected = {
    'racket': 'r_default',
    'ball': 'b_default',
    'arena': 'a_default',
  };
  List<String> owned = ['r_default', 'b_default', 'a_default'];
  Map<String, int> chests = {'bronze': 1, 'silver': 0, 'gold': 0};
  Map<String, int> missionProgress = {
    'play': 0,
    'win': 0,
    'rally10': 0,
    'power': 0,
    'hardWin': 0,
    'chest': 0,
  };
  Map<String, bool> claimed = {};
  Map<String, int> stats = {
    'matches': 0,
    'wins': 0,
    'losses': 0,
    'bestRally': 0,
    'streak': 0,
    'bestStreak': 0,
    'powerCollected': 0,
  };
  int leaguePoints = 0;
  String season = _seasonNow();
  Map<String, dynamic> tournament = {'activeId': null, 'round': 0};
  List<Map<String, dynamic>> friends = [];
  List<Map<String, dynamic>> publicChat = [];
  Map<String, List<Map<String, dynamic>>> privateChat = {};
  Map<String, dynamic> matchSetup = {
    'mode': 'quick',
    'difficulty': 'medium',
    'orientation': 'portrait',
    'entry': 0,
  };
  double sensitivity = 1;
  String quality = 'medium';
  bool trail = true;
  bool sound = true;
  bool haptics = true;
  bool debug = false;

  GameTheme get theme => Themes.byId(themeId);
  int get xpToNext => 100 + (level - 1) * 70;
  Item get racket => Catalog.byId(selected['racket']);
  Item get ball => Catalog.byId(selected['ball']);
  Item get arena => Catalog.byId(selected['arena']);

  static String _seasonNow() {
    final date = DateTime.now();
    return '${date.year}-${date.month.toString().padLeft(2, '0')}';
  }

  Future<void> bootstrap() async {
    await storage.init();
    await audio.init();
    final data = storage.load();
    if (data != null) _from(data);
    final seasonChanged = _ensureSeason();
    _syncServices();
    if (seasonChanged || data == null) await _persist();
    notifyListeners();
  }

  Map<String, dynamic> _message(String from, String sender, String text) => {
        'from': from,
        'name': sender,
        'text': text,
        'time': _timeNow(),
      };

  String _timeNow() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  int _int(dynamic value, int fallback) => value is num ? value.toInt() : fallback;
  double _double(dynamic value, double fallback) => value is num ? value.toDouble() : fallback;
  bool _bool(dynamic value, bool fallback) => value is bool ? value : fallback;
  String _string(dynamic value, String fallback) => value is String ? value : fallback;

  Map<String, int> _intMap(dynamic value, Map<String, int> fallback) {
    if (value is! Map) return Map<String, int>.from(fallback);
    final result = Map<String, int>.from(fallback);
    value.forEach((key, item) {
      if (key is String && item is num) result[key] = item.toInt();
    });
    return result;
  }

  void _from(Map<String, dynamic> data) {
    name = _string(data['name'], name);
    avatar = _int(data['avatar'], avatar).clamp(0, avatars.length - 1).toInt();
    themeId = _string(data['theme'], themeId);
    level = max(1, _int(data['level'], level)).toInt();
    xp = max(0, _int(data['xp'], xp)).toInt();
    coins = max(0, _int(data['coins'], coins)).toInt();
    gems = max(0, _int(data['gems'], gems)).toInt();

    if (data['selected'] is Map) {
      selected = Map<String, String>.from(selected);
      (data['selected'] as Map).forEach((key, value) {
        if (key is String && value is String) selected[key] = value;
      });
    }
    if (data['owned'] is List) {
      owned = (data['owned'] as List).whereType<String>().toSet().toList();
    }
    for (final id in const ['r_default', 'b_default', 'a_default']) {
      if (!owned.contains(id)) owned.add(id);
    }

    chests = _intMap(data['chests'], chests);
    missionProgress = _intMap(data['missionProgress'], missionProgress);
    stats = _intMap(data['stats'], stats);
    claimed = {};
    if (data['claimed'] is Map) {
      (data['claimed'] as Map).forEach((key, value) {
        if (key is String && value is bool) claimed[key] = value;
      });
    }

    leaguePoints = max(0, _int(data['leaguePoints'], leaguePoints)).toInt();
    season = _string(data['season'], season);
    tournament = data['tournament'] is Map
        ? Map<String, dynamic>.from(data['tournament'] as Map)
        : {'activeId': null, 'round': 0};
    friends = _listOfMaps(data['friends'])
      ..removeWhere((friend) => friend['id'] == 'f1' || friend['id'] == 'f2');
    publicChat = _listOfMaps(data['publicChat'])
      ..removeWhere((message) => message['from'] == 'bot');
    privateChat = {};
    if (data['privateChat'] is Map) {
      (data['privateChat'] as Map).forEach((key, value) {
        if (key is String) {
          final messages = _listOfMaps(value)..removeWhere((message) => message['from'] == 'bot');
          privateChat[key] = messages;
        }
      });
    }
    if (data['matchSetup'] is Map) {
      matchSetup = {...matchSetup, ...Map<String, dynamic>.from(data['matchSetup'] as Map)};
    }
    sensitivity = _double(data['sensitivity'], sensitivity).clamp(.6, 2.0).toDouble();
    quality = _string(data['quality'], quality);
    if (!const ['low', 'medium', 'high'].contains(quality)) quality = 'medium';
    trail = _bool(data['trail'], trail);
    sound = _bool(data['sound'], sound);
    haptics = _bool(data['haptics'], haptics);
    debug = _bool(data['debug'], debug);
  }

  List<Map<String, dynamic>> _listOfMaps(dynamic value) {
    if (value is! List) return [];
    return value.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
  }

  Map<String, dynamic> _to() => {
        'name': name,
        'avatar': avatar,
        'theme': themeId,
        'level': level,
        'xp': xp,
        'coins': coins,
        'gems': gems,
        'selected': selected,
        'owned': owned,
        'chests': chests,
        'missionProgress': missionProgress,
        'claimed': claimed,
        'stats': stats,
        'leaguePoints': leaguePoints,
        'season': season,
        'tournament': tournament,
        'friends': friends,
        'publicChat': publicChat,
        'privateChat': privateChat,
        'matchSetup': matchSetup,
        'sensitivity': sensitivity,
        'quality': quality,
        'trail': trail,
        'sound': sound,
        'haptics': haptics,
        'debug': debug,
      };

  Future<void> _persist() => storage.save(_to());

  Future<void> save({bool notify = true}) async {
    _syncServices();
    await _persist();
    if (notify) notifyListeners();
  }

  void _syncServices() {
    audio.enabled = sound;
  }

  bool _ensureSeason() {
    if (season == _seasonNow()) return false;
    season = _seasonNow();
    leaguePoints = 0;
    return true;
  }

  void addCoins(int amount) => coins = (coins + amount).clamp(0, 999999999).toInt();
  void addGems(int amount) => gems = (gems + amount).clamp(0, 999999999).toInt();

  void addXp(int amount) {
    xp += max(0, amount).toInt();
    while (xp >= xpToNext) {
      xp -= xpToNext;
      level++;
    }
  }

  void incMission(String key, [int amount = 1]) {
    missionProgress[key] = (missionProgress[key] ?? 0) + amount;
  }

  Future<bool> buy(Item item) async {
    if (owned.contains(item.id) || coins < item.price) return false;
    addCoins(-item.price);
    owned.add(item.id);
    await audio.play('coin');
    await save();
    return true;
  }

  Future<void> equip(Item item) async {
    if (!owned.contains(item.id)) return;
    selected[item.type] = item.id;
    await save();
  }

  Future<void> updateName(String value) async {
    final clean = value.trim().replaceAll(RegExp(r'[<>{}]'), '');
    if (clean.length < 2 || clean.length > 16) return;
    name = clean;
    await save();
  }

  Future<void> setAvatar(int value) async {
    avatar = value.clamp(0, avatars.length - 1).toInt();
    await save();
  }

  Future<void> setTheme(String value) async {
    themeId = Themes.byId(value).id;
    await save();
  }

  Future<void> setSetting({double? sensitivityValue, String? qualityValue, bool? trailValue, bool? soundValue, bool? hapticsValue, bool? debugValue}) async {
    if (sensitivityValue != null) sensitivity = sensitivityValue.clamp(.6, 2.0).toDouble();
    if (qualityValue != null && const ['low', 'medium', 'high'].contains(qualityValue)) quality = qualityValue;
    if (trailValue != null) trail = trailValue;
    if (soundValue != null) sound = soundValue;
    if (hapticsValue != null) haptics = hapticsValue;
    if (debugValue != null) debug = debugValue;
    await save();
  }

  Future<void> updateMatchSetup(Map<String, dynamic> setup) async {
    matchSetup = {...matchSetup, ...setup};
    await save();
  }

  Future<void> addFriend(String value) async {
    final clean = value.trim();
    if (clean.length < 2) return;
    friends.add({
      'id': 'f${DateTime.now().microsecondsSinceEpoch}',
      'name': clean,
      'local': true,
    });
    await save();
  }

  Future<void> sendPublic(String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    publicChat.add(_message('me', name, clean));
    if (publicChat.length > 100) publicChat.removeAt(0);
    await save();
  }

  Future<void> sendPrivate(String friendId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    final messages = privateChat.putIfAbsent(friendId, () => []);
    messages.add({'from': 'me', 'text': clean, 'time': _timeNow()});
    if (messages.length > 100) messages.removeAt(0);
    await save();
  }

  Future<void> clearChat({required bool isPublic, String? friendId}) async {
    if (isPublic) {
      publicChat.clear();
    } else if (friendId != null) {
      privateChat[friendId] = [];
    }
    await save();
  }

  Future<void> resetData() async {
    await storage.reset();
    name = 'بازیکن';
    avatar = 0;
    themeId = 'dark';
    level = 1;
    xp = 0;
    coins = 300;
    gems = 5;
    selected = {'racket': 'r_default', 'ball': 'b_default', 'arena': 'a_default'};
    owned = ['r_default', 'b_default', 'a_default'];
    chests = {'bronze': 1, 'silver': 0, 'gold': 0};
    missionProgress = {'play': 0, 'win': 0, 'rally10': 0, 'power': 0, 'hardWin': 0, 'chest': 0};
    claimed = {};
    stats = {'matches': 0, 'wins': 0, 'losses': 0, 'bestRally': 0, 'streak': 0, 'bestStreak': 0, 'powerCollected': 0};
    leaguePoints = 0;
    season = _seasonNow();
    tournament = {'activeId': null, 'round': 0};
    friends = [];
    publicChat = [];
    privateChat = {};
    matchSetup = {'mode': 'quick', 'difficulty': 'medium', 'orientation': 'portrait', 'entry': 0};
    sensitivity = 1;
    quality = 'medium';
    trail = true;
    sound = true;
    haptics = true;
    debug = false;
    await save();
  }
}
