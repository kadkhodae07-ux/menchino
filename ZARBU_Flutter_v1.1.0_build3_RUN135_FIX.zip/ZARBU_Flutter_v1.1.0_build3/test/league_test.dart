import 'package:flutter_test/flutter_test.dart';
import 'package:zarbu/core/league.dart';

void main() {
  test('ZARBU uses one league identity', () {
    final snapshot = buildLocalZarbuLeague(
      userName: 'بازیکن',
      userAvatar: 0,
      userPoints: 100,
    );
    expect(snapshot.leagueName, 'لیگ ضربو');
  });

  test('leaderboard is sorted by league points', () {
    final snapshot = buildLocalZarbuLeague(
      userName: 'بازیکن',
      userAvatar: 0,
      userPoints: 3000,
    );
    expect(snapshot.players.first.isCurrentUser, isTrue);
    for (var i = 1; i < snapshot.players.length; i++) {
      expect(snapshot.players[i - 1].points >= snapshot.players[i].points, isTrue);
    }
  });
}
