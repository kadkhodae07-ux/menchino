import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

class ArenaComponent extends PositionComponent {
  ArenaComponent({super.priority = -100});

  Rect arenaRect = Rect.zero;
  final List<Offset> _stars = <Offset>[];
  final math.Random _random = math.Random(4137);

  void layout(Vector2 gameSize) {
    final double top = math.max(78.0, gameSize.y * 0.105);
    final double bottom = math.max(100.0, gameSize.y * 0.15);
    final double horizontal = math.max(42.0, gameSize.x * 0.045);
    arenaRect = Rect.fromLTRB(
      horizontal,
      top,
      gameSize.x - horizontal,
      gameSize.y - bottom,
    );
    size = gameSize;

    if (_stars.isEmpty) {
      for (int i = 0; i < 38; i++) {
        _stars.add(Offset(_random.nextDouble(), _random.nextDouble()));
      }
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final Rect full = Offset.zero & Size(size.x, size.y);
    canvas.drawRect(
      full,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFF03040B),
            Color(0xFF090D20),
            Color(0xFF120719),
          ],
        ).createShader(full),
    );

    for (final Offset star in _stars) {
      final Offset point = Offset(star.dx * size.x, star.dy * size.y);
      canvas.drawCircle(point, 1.1, Paint()..color = const Color(0x6677D8FF));
    }

    if (arenaRect.isEmpty) return;

    final Path outer = _chamferedRect(arenaRect, 26);
    canvas.drawPath(
      outer,
      Paint()
        ..shader = LinearGradient(
          colors: const <Color>[
            Color(0xFF08283A),
            Color(0xFF0B1122),
            Color(0xFF35102D),
          ],
        ).createShader(arenaRect),
    );

    final Rect innerRect = arenaRect.deflate(10);
    final Path inner = _chamferedRect(innerRect, 18);
    canvas.drawPath(
      inner,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 1.1,
          colors: <Color>[Color(0xFF10182B), Color(0xFF050712)],
        ).createShader(innerRect),
    );

    _drawHexGrid(canvas, innerRect);

    final Paint leftGlow = Paint()
      ..color = const Color(0xFF2EDBFF)
      ..strokeWidth = 5
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9);
    canvas.drawLine(innerRect.topLeft, innerRect.bottomLeft, leftGlow);

    final Paint rightGlow = Paint()
      ..color = const Color(0xFFFF3FAD)
      ..strokeWidth = 5
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9);
    canvas.drawLine(innerRect.topRight, innerRect.bottomRight, rightGlow);

    final double centerX = innerRect.center.dx;
    final Paint centerGlow = Paint()
      ..color = const Color(0x887F7CFF)
      ..strokeWidth = 2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
    for (double y = innerRect.top + 16; y < innerRect.bottom; y += 34) {
      canvas.drawLine(Offset(centerX, y), Offset(centerX, math.min(y + 18.0, innerRect.bottom)), centerGlow);
    }

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xFF5A6A8B),
    );
  }

  Path _chamferedRect(Rect rect, double cut) {
    return Path()
      ..moveTo(rect.left + cut, rect.top)
      ..lineTo(rect.right - cut, rect.top)
      ..lineTo(rect.right, rect.top + cut)
      ..lineTo(rect.right, rect.bottom - cut)
      ..lineTo(rect.right - cut, rect.bottom)
      ..lineTo(rect.left + cut, rect.bottom)
      ..lineTo(rect.left, rect.bottom - cut)
      ..lineTo(rect.left, rect.top + cut)
      ..close();
  }

  void _drawHexGrid(Canvas canvas, Rect rect) {
    final Paint grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.65
      ..color = const Color(0x183FD9FF);
    const double radius = 20;
    const double h = radius * 1.732;
    for (double x = rect.left - radius; x < rect.right + radius; x += radius * 3) {
      for (double y = rect.top; y < rect.bottom + h; y += h) {
        _drawHex(canvas, Offset(x, y), radius, grid, rect);
        _drawHex(canvas, Offset(x + radius * 1.5, y + h / 2), radius, grid, rect);
      }
    }
  }

  void _drawHex(Canvas canvas, Offset center, double radius, Paint paint, Rect clip) {
    if (!clip.inflate(radius).contains(center)) return;
    final Path path = Path();
    for (int i = 0; i < 6; i++) {
      final double a = math.pi / 3 * i;
      final Offset p = center + Offset(math.cos(a) * radius, math.sin(a) * radius);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.save();
    canvas.clipRect(clip);
    canvas.drawPath(path, paint);
    canvas.restore();
  }
}
