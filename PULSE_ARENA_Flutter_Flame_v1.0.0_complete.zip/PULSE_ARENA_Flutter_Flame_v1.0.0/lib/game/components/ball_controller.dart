import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

import '../config/game_config.dart';
import '../managers/audio_manager.dart';
import 'bot_paddle_controller.dart';
import 'impact_particle.dart';
import 'player_paddle_controller.dart';

class BallController extends PositionComponent {
  BallController({
    required this.config,
    required this.onPlayerScored,
    required this.onBotScored,
    required this.isShieldActive,
    required this.consumeBoost,
    required this.isBoostArmed,
    required this.matchElapsedSeconds,
  }) : super(priority: 20);

  final GameConfig config;
  final VoidCallback onPlayerScored;
  final VoidCallback onBotScored;
  final bool Function() isShieldActive;
  final VoidCallback consumeBoost;
  final bool Function() isBoostArmed;
  final double Function() matchElapsedSeconds;

  late PlayerPaddleController player;
  late BotPaddleController bot;
  Rect arena = Rect.zero;
  Vector2 velocity = Vector2.zero();
  bool active = false;
  double radius = 16;
  double _currentSpeed = 0;
  int _serveDirection = 1;
  int _particleSeed = 100;
  final List<Vector2> _trail = <Vector2>[];

  void attachPaddles(PlayerPaddleController playerPaddle, BotPaddleController botPaddle) {
    player = playerPaddle;
    bot = botPaddle;
  }

  void layout(Rect value) {
    arena = value;
    radius = math.max(12.0, value.height * 0.027);
    size = Vector2.all(radius * 2);
    resetToCenter();
  }

  void resetToCenter({int? serveDirection}) {
    if (arena.isEmpty) return;
    if (serveDirection != null) _serveDirection = serveDirection;
    position = Vector2(arena.center.dx, arena.center.dy);
    _trail.clear();
    active = false;
    _currentSpeed = math.min(
      config.ballMaximumSpeed,
      config.ballBaseSpeed + matchElapsedSeconds() * config.ballSpeedIncreasePerSecond,
    );
    final double angle = (_serveDirection > 0 ? 1.0 : -1.0) * 0.16;
    velocity = Vector2(_serveDirection * math.cos(angle), math.sin(angle)) * _currentSpeed;
  }

  void launch() {
    active = true;
  }

  void stop() {
    active = false;
    velocity = Vector2.zero();
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!active || arena.isEmpty) return;

    final double timedMinimum = math.min(
      config.ballMaximumSpeed,
      config.ballBaseSpeed + matchElapsedSeconds() * config.ballSpeedIncreasePerSecond,
    );
    _currentSpeed = math.max(
      timedMinimum,
      math.min(config.ballMaximumSpeed, _currentSpeed + config.ballSpeedIncreasePerSecond * dt),
    );
    _normalizeVelocityToCurrentSpeed();

    _trail.insert(0, position.clone());
    if (_trail.length > 13) _trail.removeLast();

    position += velocity * dt;
    _handleWalls();
    _handlePaddles();
    _handleShield();
    _handleScore();
  }

  void _handleWalls() {
    if (position.y - radius <= arena.top && velocity.y < 0) {
      position.y = arena.top + radius;
      velocity.y = velocity.y.abs();
      _impact(const Color(0xFF8D7CFF));
      AudioManager.instance.playWall();
    } else if (position.y + radius >= arena.bottom && velocity.y > 0) {
      position.y = arena.bottom - radius;
      velocity.y = -velocity.y.abs();
      _impact(const Color(0xFF8D7CFF));
      AudioManager.instance.playWall();
    }
  }

  void _handlePaddles() {
    final Rect ballRect = Rect.fromCircle(center: Offset(position.x, position.y), radius: radius);
    if (velocity.x < 0 && ballRect.overlaps(player.rect)) {
      position.x = player.rect.right + radius;
      _bounceFromPaddle(player.rect, direction: 1, isPlayer: true);
    } else if (velocity.x > 0 && ballRect.overlaps(bot.rect)) {
      position.x = bot.rect.left - radius;
      _bounceFromPaddle(bot.rect, direction: -1, isPlayer: false);
    }
  }

  void _bounceFromPaddle(Rect paddle, {required int direction, required bool isPlayer}) {
    final double relative = ((position.y - paddle.center.dy) / (paddle.height / 2)).clamp(-1.0, 1.0).toDouble();
    final double angle = relative * (math.pi * 0.31);
    double speed = math.min(config.ballMaximumSpeed, _currentSpeed + 22.0);
    if (isPlayer && isBoostArmed()) {
      speed = math.min(config.ballMaximumSpeed, speed * config.boostMultiplier);
      consumeBoost();
    }
    _currentSpeed = speed;
    velocity = Vector2(direction * math.cos(angle), math.sin(angle)) * speed;
    _impact(isPlayer ? const Color(0xFF35E3FF) : const Color(0xFFFF4DB4));
    AudioManager.instance.playPaddle();
    AudioManager.instance.lightImpact();
  }

  void _handleShield() {
    if (!isShieldActive() || velocity.x >= 0) return;
    final double shieldX = player.position.x - 25;
    if (position.x - radius <= shieldX && position.x > shieldX - 35) {
      position.x = shieldX + radius;
      velocity.x = velocity.x.abs();
      _currentSpeed = math.min(config.ballMaximumSpeed, _currentSpeed + 35.0);
      _normalizeVelocityToCurrentSpeed();
      _impact(const Color(0xFF6CF3FF));
      AudioManager.instance.playPower();
      AudioManager.instance.importantImpact();
    }
  }

  void _handleScore() {
    if (position.x < arena.left - radius * 2) {
      active = false;
      _serveDirection = 1;
      onBotScored();
    } else if (position.x > arena.right + radius * 2) {
      active = false;
      _serveDirection = -1;
      onPlayerScored();
    }
  }

  void _normalizeVelocityToCurrentSpeed() {
    final double length = velocity.length;
    if (length < 0.001) {
      velocity = Vector2(_serveDirection * _currentSpeed, 0);
      return;
    }
    velocity = velocity / length * _currentSpeed;
  }

  void _impact(Color color) {
    parent?.add(ImpactParticle(origin: position.clone(), color: color, seed: _particleSeed++));
  }

  @override
  void render(Canvas canvas) {
    for (int i = _trail.length - 1; i >= 0; i--) {
      final Vector2 p = _trail[i];
      final double opacity = (1.0 - i / _trail.length) * 0.22;
      final double trailRadius = radius * (1.0 - i / (_trail.length * 1.3));
      canvas.drawCircle(
        Offset(p.x - position.x, p.y - position.y),
        trailRadius,
        Paint()
          ..color = const Color(0xFFB34DFF).withValues(alpha: opacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
    }

    canvas.drawCircle(
      Offset.zero,
      radius * 1.75,
      Paint()
        ..color = const Color(0x884E2BFF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16),
    );
    canvas.drawCircle(
      Offset.zero,
      radius,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Color(0xFFFFFFFF), Color(0xFFEBD7FF), Color(0xFF9C4DFF)],
        ).createShader(Rect.fromCircle(center: Offset.zero, radius: radius)),
    );
    canvas.drawCircle(Offset(-radius * 0.24, -radius * 0.28), radius * 0.24, Paint()..color = const Color(0xFFFFFFFF));
  }
}

typedef VoidCallback = void Function();
