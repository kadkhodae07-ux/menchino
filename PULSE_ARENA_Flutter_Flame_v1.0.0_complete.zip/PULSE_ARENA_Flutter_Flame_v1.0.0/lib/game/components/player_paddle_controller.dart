import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

class PlayerPaddleController extends PositionComponent {
  PlayerPaddleController({required this.moveSpeed});

  final double moveSpeed;
  Rect movementBounds = Rect.zero;
  double targetY = 0;
  bool movementEnabled = true;

  void layout(Rect arena) {
    movementBounds = arena;
    size = Vector2(math.max(34.0, arena.width * 0.025), math.max(118.0, arena.height * 0.25));
    position = Vector2(arena.left + 34, arena.center.dy - size.y / 2);
    targetY = position.y;
  }

  void setTargetFromTouch(double touchY) {
    targetY = (touchY - size.y / 2).clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  void resetToCenter() {
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!movementEnabled) return;
    final double delta = targetY - position.y;
    final double maxStep = moveSpeed * dt;
    position.y += delta.clamp(-maxStep, maxStep).toDouble();
    position.y = position.y.clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final Rect r = Offset.zero & Size(size.x, size.y);
    final RRect body = RRect.fromRectAndRadius(r, Radius.circular(size.x * 0.46));

    canvas.drawRRect(
      body.inflate(7),
      Paint()
        ..color = const Color(0xCC1FD9FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13),
    );
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFFBDF7FF), Color(0xFF23D6FF), Color(0xFF0867B7)],
        ).createShader(r),
    );
    canvas.drawRRect(
      body.deflate(5),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xBFFFFFFF),
    );
    canvas.drawCircle(Offset(size.x * 0.56, size.y * 0.5), size.x * 0.16, Paint()..color = const Color(0xE6FFFFFF));
  }
}
