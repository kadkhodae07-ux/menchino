# PULSE ARENA – Flutter + Flame Demo

دموی آفلاین و قابل‌بازی فونگ آینده‌نگر برای Android، ساخته‌شده با Flutter و Flame.

## امکانات این نسخه

- صفحه شروع گرافیکی و Transition نرم
- مسابقه آفلاین تا امتیاز ۷ مقابل ربات متوسط
- کنترل لمسی نرم با Drag
- توپ انرژی با Glow، Trail و ذرات برخورد
- هوش مصنوعی با پیش‌بینی مسیر، تأخیر واکنش، محدودیت سرعت و خطا
- قدرت‌های سپر، شتاب و پالس
- شمارش معکوس ۳، ۲، ۱ بعد از هر امتیاز
- Pause، ادامه، شروع مجدد و بازگشت
- نتیجه برد/باخت و بازی دوباره
- صدا و لرزش قابل خاموش‌کردن از منوی Pause
- Android Landscape و Safe Area
- دو Flavor برای بازار و مایکت

## اجرا

در اولین اجرا، اگر Gradle Wrapper داخل ZIP وجود ندارد:

```bash
bash tool/bootstrap_android_wrapper.sh
```

سپس:

```bash
flutter pub get
flutter run --flavor bazaar
```

برای مایکت:

```bash
flutter run --flavor myket
```

## ساخت APK

```bash
flutter build apk --release --flavor bazaar
flutter build apk --release --flavor myket
```

## امضای Release

فایل `android/key.properties` را ایجاد کنید:

```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=YOUR_KEY_ALIAS
storeFile=/absolute/path/to/your-release.jks
```

اگر این فایل وجود نداشته باشد، نسخه Release برای تست با کلید Debug امضا می‌شود و برای انتشار فروشگاهی مناسب نیست.

## Workflow

فایل `.github/workflows/build-pulse-arena.yml`:

- `flutter analyze`
- `flutter test`
- ساخت APK بازار
- ساخت APK مایکت
- بارگذاری لاگ‌ها فقط در صورت خطا

برای امضای فروشگاهی، Secrets زیر را در GitHub تعریف کنید:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`
