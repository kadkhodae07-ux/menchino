package com.fong.neonpong

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
