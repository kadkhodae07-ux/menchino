class ChatBot {
  const ChatBot({required this.name, required this.emoji});

  final String name;
  final String emoji;
}

const List<ChatBot> chatBots = <ChatBot>[
  ChatBot(name: 'نئون‌مستر', emoji: '👾'),
  ChatBot(name: 'سارا', emoji: '🌸'),
  ChatBot(name: 'توفان', emoji: '🌪️'),
  ChatBot(name: 'پیکسل', emoji: '🎮'),
  ChatBot(name: 'کیان', emoji: '🦁'),
];

const List<String> chatLines = <String>[
  'کسی هست دو نفره بازی کنه؟ 🎮',
  'این راکت رنگین‌کمانی عجب چیزیه! 🌈',
  'دیروز رتبه‌م شد ۵ 😎',
  'سطح غیرممکن رو کسی برده؟ 💀',
  'یه دست با ربات سخت بردم، عرق کردم 😅',
  'فروشگاه آیتم جدید بذاره دیگه',
  'کی میتونه رکورد نئون‌مستر رو بشکنه؟',
  'این بازی اعتیادآور شده 🤩',
  'GG به همه 🏆',
  'با تم ماتریکس بازی کنید حرف نداره 💚',
  'جایزه روزانه‌تون رو گرفتید؟ 🎁',
  'Power-Up سپر خیلی خفنه! 🛡️',
];

const List<String> chatReplies = <String>[
  'موافقم! 👍',
  'جدی میگی؟ 😄',
  'دمت گرم 🙌',
  'بیا یه دست بازی کنیم 🎮',
  'من تازه اومدم، چی شده؟',
  '😂😂',
  'آره دقیقاً',
  'خوش اومدی! 🎉',
  'منم همینطور',
];
