class RankBot {
  const RankBot({required this.name, required this.emoji, required this.points});

  final String name;
  final String emoji;
  final int points;
}

const List<RankBot> rankBots = <RankBot>[
  RankBot(name: 'نئون‌مستر', emoji: '👾', points: 940),
  RankBot(name: 'شاهین', emoji: '🦅', points: 870),
  RankBot(name: 'آذرخش', emoji: '⚡', points: 805),
  RankBot(name: 'گرگ شب', emoji: '🐺', points: 760),
  RankBot(name: 'پیکسل', emoji: '🎮', points: 710),
  RankBot(name: 'سارا', emoji: '🌸', points: 665),
  RankBot(name: 'توفان', emoji: '🌪️', points: 620),
  RankBot(name: 'کیان', emoji: '🦁', points: 575),
  RankBot(name: 'مهدی', emoji: '🎯', points: 530),
  RankBot(name: 'الینا', emoji: '🦋', points: 490),
  RankBot(name: 'آرش', emoji: '🏹', points: 450),
  RankBot(name: 'نیما', emoji: '🌊', points: 410),
  RankBot(name: 'بردیا', emoji: '🛡️', points: 370),
  RankBot(name: 'شبنم', emoji: '💧', points: 330),
  RankBot(name: 'کاوه', emoji: '🔨', points: 290),
  RankBot(name: 'آتنا', emoji: '🦉', points: 250),
  RankBot(name: 'دریا', emoji: '🐬', points: 210),
  RankBot(name: 'رادین', emoji: '🚀', points: 170),
  RankBot(name: 'پارسا', emoji: '🎲', points: 130),
];
