import 'package:flutter/services.dart';

import '../data/save_data.dart';

enum FeedbackEvent { tap, launch, paddle, wall, score, losePoint, pickup, win, lose }

class AudioFeedbackService {
  AudioFeedbackService._();

  static final AudioFeedbackService instance = AudioFeedbackService._();

  Future<void> play(FeedbackEvent event) async {
    if (SaveData.instance.muted) return;

    switch (event) {
      case FeedbackEvent.tap:
      case FeedbackEvent.launch:
      case FeedbackEvent.wall:
        await SystemSound.play(SystemSoundType.click);
        break;
      case FeedbackEvent.paddle:
      case FeedbackEvent.pickup:
        await SystemSound.play(SystemSoundType.click);
        await HapticFeedback.lightImpact();
        break;
      case FeedbackEvent.score:
        await SystemSound.play(SystemSoundType.alert);
        await HapticFeedback.mediumImpact();
        break;
      case FeedbackEvent.losePoint:
        await SystemSound.play(SystemSoundType.alert);
        await HapticFeedback.selectionClick();
        break;
      case FeedbackEvent.win:
        await SystemSound.play(SystemSoundType.alert);
        await HapticFeedback.heavyImpact();
        break;
      case FeedbackEvent.lose:
        await SystemSound.play(SystemSoundType.alert);
        await HapticFeedback.mediumImpact();
        break;
    }
  }
}
