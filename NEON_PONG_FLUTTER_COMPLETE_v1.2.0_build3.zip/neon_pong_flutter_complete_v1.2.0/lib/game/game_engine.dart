import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';

enum GameState { menu, serve, play, pause, over }
enum GameMode { bot, friend }
enum GameEvent { launch, paddleHit, wallHit, playerPoint, opponentPoint, pickup, win, lose }
enum PowerUpType { big, small, multi, slow, fast, shield, giantBall, paddleBoost, freeze, curve, doublePoint, coin }

class DifficultyData {
  const DifficultyData({required this.speed, required this.error, required this.reaction});
  final double speed;
  final double error;
  final double reaction;
}

const List<DifficultyData> difficulties = <DifficultyData>[
  DifficultyData(speed: 250, error: 115, reaction: 0.50),
  DifficultyData(speed: 370, error: 60, reaction: 0.75),
  DifficultyData(speed: 530, error: 26, reaction: 0.92),
  DifficultyData(speed: 780, error: 8, reaction: 1),
];

class PaddleBody {
  double x = 0;
  double y = 0;
  double width = 13;
  double height = 120;
  double velocityY = 0;
  double targetY = 0;
}

class BallBody {
  BallBody({this.x = 0, this.y = 0, this.vx = 0, this.vy = 0, this.radius = 9, this.speed = 460});
  double x;
  double y;
  double vx;
  double vy;
  double radius;
  double speed;
}

class StarBody {
  StarBody({required this.x, required this.y, required this.depth, required this.phase});
  double x;
  double y;
  final double depth;
  final double phase;
}

class ParticleBody {
  ParticleBody({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.life,
    required this.color,
    required this.size,
  }) : maxLife = life;

  double x;
  double y;
  double vx;
  double vy;
  double life;
  final double maxLife;
  final Color color;
  final double size;
}

class TrailBody {
  TrailBody({required this.x, required this.y, this.life = 1});
  final double x;
  final double y;
  double life;
}

class FieldPowerUp {
  FieldPowerUp({required this.type, required this.x, required this.y, required this.radius});
  final PowerUpType type;
  double x;
  double y;
  double radius;
  double life = 8;
  double pulse = 0;

  String get emoji => switch (type) {
        PowerUpType.big => '📏',
        PowerUpType.small => '🤏',
        PowerUpType.multi => '✨',
        PowerUpType.slow => '🐢',
        PowerUpType.fast => '⚡',
        PowerUpType.shield => '🛡️',
        PowerUpType.giantBall => '⚪',
        PowerUpType.paddleBoost => '🏎️',
        PowerUpType.freeze => '❄️',
        PowerUpType.curve => '🌀',
        PowerUpType.doublePoint => '✌️',
        PowerUpType.coin => '🪙',
      };

  String get name => switch (type) {
        PowerUpType.big => 'راکت بزرگ',
        PowerUpType.small => 'حریف کوچک',
        PowerUpType.multi => 'چند توپی',
        PowerUpType.slow => 'زمان آهسته',
        PowerUpType.fast => 'سرعت بالا',
        PowerUpType.shield => 'سپر',
        PowerUpType.giantBall => 'توپ غول‌پیکر',
        PowerUpType.paddleBoost => 'راکت سریع',
        PowerUpType.freeze => 'فریز حریف',
        PowerUpType.curve => 'توپ خمیده',
        PowerUpType.doublePoint => 'امتیاز دوبرابر',
        PowerUpType.coin => 'سکه فوری',
      };

  Color get color => switch (type) {
        PowerUpType.big => const Color(0xFF00E5FF),
        PowerUpType.small => const Color(0xFFFF2FD6),
        PowerUpType.multi => const Color(0xFFFFE259),
        PowerUpType.slow => const Color(0xFF38FFB0),
        PowerUpType.fast => const Color(0xFFFF9500),
        PowerUpType.shield => const Color(0xFFB388FF),
        PowerUpType.giantBall => const Color(0xFFFFFFFF),
        PowerUpType.paddleBoost => const Color(0xFF64FFDA),
        PowerUpType.freeze => const Color(0xFF80D8FF),
        PowerUpType.curve => const Color(0xFFFF4FD8),
        PowerUpType.doublePoint => const Color(0xFFFFE259),
        PowerUpType.coin => const Color(0xFFFFD54F),
      };
}

class ActiveEffect {
  ActiveEffect({required this.type, required this.remaining});
  final PowerUpType type;
  double remaining;

  FieldPowerUp get descriptor => FieldPowerUp(type: type, x: 0, y: 0, radius: 0);
}

class MatchResult {
  const MatchResult({required this.won, required this.reward});
  final bool won;
  final MatchReward reward;
}

class GameEngine extends ChangeNotifier {
  GameEngine({required this.save, required this.onEvent});

  static const int winScore = 7;
  final SaveData save;
  final void Function(GameEvent event) onEvent;
  final Random _random = Random();

  Size viewport = Size.zero;
  double scale = 1;
  double time = 0;
  GameState state = GameState.menu;
  GameState previousState = GameState.serve;
  GameMode mode = GameMode.bot;
  int difficulty = 1;
  int scorePlayer = 0;
  int scoreOpponent = 0;
  double serveTimer = 1;
  int serveDirection = 1;
  double botTargetError = 0;
  double shake = 0;
  double flash = 0;
  Color flashColor = const Color(0xFF00E5FF);
  int flashSide = 1;
  double nextPowerUpTime = 10;
  double timeScale = 1;
  bool shieldActive = false;
  double playerMoveMultiplier = 1;
  double opponentMoveMultiplier = 1;
  double ballRadiusMultiplier = 1;
  double curveStrength = 0;
  MatchResult? result;

  final PaddleBody player = PaddleBody();
  final PaddleBody opponent = PaddleBody();
  final BallBody ball = BallBody();
  final List<BallBody> extraBalls = <BallBody>[];
  final List<StarBody> stars = <StarBody>[];
  final List<ParticleBody> particles = <ParticleBody>[];
  final List<TrailBody> trail = <TrailBody>[];
  final List<ActiveEffect> activeEffects = <ActiveEffect>[];
  FieldPowerUp? activePowerUp;

  double get basePaddleHeight => _clamp(viewport.height * 0.17, 70, 170);
  double get baseBallRadius => 9 * scale;
  double get baseBallSpeed => 460 * scale;

  double _clamp(num value, num minValue, num maxValue) => value.clamp(minValue, maxValue).toDouble();
  double _rand(double minValue, double maxValue) => minValue + _random.nextDouble() * (maxValue - minValue);

  void setSize(double width, double height) {
    final Size next = Size(width, height);
    if (width <= 0 || height <= 0 || viewport == next) return;
    final bool first = viewport == Size.zero;
    final double oldHeight = viewport.height;
    viewport = next;
    scale = _clamp(min(width, height) / 640, 0.65, 1.7);
    player.width = opponent.width = 13 * scale;
    ball.radius = baseBallRadius;
    for (final BallBody extra in extraBalls) extra.radius = ball.radius;
    final double margin = max(26.0, width * 0.045);
    player.x = margin + player.width / 2;
    opponent.x = width - margin - opponent.width / 2;
    _recomputeEffects();

    if (first) {
      player.y = opponent.y = height / 2;
      player.targetY = opponent.targetY = height / 2;
      ball.x = width / 2;
      ball.y = height / 2;
    } else if (oldHeight > 0) {
      final double ratio = height / oldHeight;
      player.y *= ratio;
      player.targetY *= ratio;
      opponent.y *= ratio;
      opponent.targetY *= ratio;
      ball.y *= ratio;
    }
    _clampPaddles();
    _makeStars();
  }

  void _makeStars() {
    stars.clear();
    final int count = max(26, (viewport.width * viewport.height / 20000).round()).toInt();
    for (int index = 0; index < count; index++) {
      stars.add(StarBody(
        x: _random.nextDouble() * viewport.width,
        y: _random.nextDouble() * viewport.height,
        depth: _random.nextDouble() * 0.8 + 0.2,
        phase: _random.nextDouble() * pi * 2,
      ));
    }
  }

  void startMatch({required GameMode gameMode, int diff = 1}) {
    mode = gameMode;
    difficulty = diff.clamp(0, difficulties.length - 1).toInt();
    scorePlayer = 0;
    scoreOpponent = 0;
    particles.clear();
    trail.clear();
    extraBalls.clear();
    activeEffects.clear();
    activePowerUp = null;
    shieldActive = false;
    playerMoveMultiplier = 1;
    opponentMoveMultiplier = 1;
    ballRadiusMultiplier = 1;
    curveStrength = 0;
    timeScale = 1;
    nextPowerUpTime = _rand(4.5, 7.5);
    result = null;
    player.y = opponent.y = viewport.height / 2;
    player.targetY = opponent.targetY = viewport.height / 2;
    _recomputeEffects();
    startServe();
    notifyListeners();
  }

  void startServe([int? direction]) {
    state = GameState.serve;
    serveTimer = 1;
    serveDirection = direction ?? (_random.nextBool() ? 1 : -1);
    ball.x = viewport.width / 2;
    ball.y = viewport.height / 2;
    ball.vx = 0;
    ball.vy = 0;
    ball.speed = baseBallSpeed;
    ball.radius = baseBallRadius * ballRadiusMultiplier;
    extraBalls.clear();
  }

  void _launch() {
    final double angle = _rand(-0.42, 0.42);
    ball.vx = cos(angle) * ball.speed * serveDirection;
    ball.vy = sin(angle) * ball.speed;
    _rollBotError();
    state = GameState.play;
    onEvent(GameEvent.launch);
  }

  void update(double rawDt) {
    if (viewport == Size.zero || rawDt <= 0) return;
    final double frameDt = min(rawDt, 0.033);
    time += frameDt;
    for (final StarBody star in stars) {
      star.x -= star.depth * 12 * frameDt;
      if (star.x < 0) star.x += viewport.width;
    }

    if (state == GameState.pause || state == GameState.over || state == GameState.menu) {
      return;
    }

    final double dt = frameDt * timeScale;
    _updateEffects(dt);
    _updateParticles(dt);
    shake *= exp(-7 * dt);
    if (shake < 0.2) shake = 0;
    flash *= exp(-4 * dt);

    _movePlayer(dt);
    _moveOpponent(dt);

    if (state == GameState.serve) {
      ball.x = viewport.width / 2;
      ball.y = viewport.height / 2;
      serveTimer -= dt;
      if (serveTimer <= 0) _launch();
      notifyListeners();
      return;
    }

    _updateMainBall(dt);
    if (state == GameState.play) {
      _updatePowerUps(dt);
      _updateExtraBalls(dt);
      trail.add(TrailBody(x: ball.x, y: ball.y));
      if (trail.length > 30) trail.removeAt(0);
    }
    notifyListeners();
  }

  void _updateParticles(double dt) {
    for (int index = particles.length - 1; index >= 0; index--) {
      final ParticleBody particle = particles[index];
      particle.life -= dt;
      if (particle.life <= 0) {
        particles.removeAt(index);
        continue;
      }
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= exp(-2 * dt);
      particle.vy *= exp(-2 * dt);
    }
    for (int index = trail.length - 1; index >= 0; index--) {
      trail[index].life -= dt * 2.4;
      if (trail[index].life <= 0) trail.removeAt(index);
    }
  }

  void _movePlayer(double dt) {
    player.targetY = _clamp(player.targetY, player.height / 2, viewport.height - player.height / 2);
    final double factor = 1 - exp(-18 * playerMoveMultiplier * dt);
    final double nextY = player.y + (player.targetY - player.y) * factor;
    player.velocityY = (nextY - player.y) / dt;
    player.y = nextY;
  }

  void _moveOpponent(double dt) {
    if (mode == GameMode.bot) {
      final DifficultyData data = difficulties[difficulty];
      double target = state == GameState.play && ball.vx > 0
          ? _predictY() + botTargetError
          : viewport.height / 2 + (ball.y - viewport.height / 2) * 0.2;
      target = _clamp(target, opponent.height / 2, viewport.height - opponent.height / 2);
      final double step = _clamp(target - opponent.y, -data.speed * opponentMoveMultiplier * scale * dt, data.speed * opponentMoveMultiplier * scale * dt);
      opponent.velocityY = step / dt;
      opponent.y = _clamp(opponent.y + step, opponent.height / 2, viewport.height - opponent.height / 2);
    } else {
      opponent.targetY = _clamp(opponent.targetY, opponent.height / 2, viewport.height - opponent.height / 2);
      final double factor = 1 - exp(-18 * opponentMoveMultiplier * dt);
      final double nextY = opponent.y + (opponent.targetY - opponent.y) * factor;
      opponent.velocityY = (nextY - opponent.y) / dt;
      opponent.y = nextY;
    }
  }

  double _predictY() {
    if (ball.vx <= 0) return ball.y;
    final double travel = (opponent.x - opponent.width / 2 - ball.radius - ball.x) / ball.vx;
    if (travel < 0) return ball.y;
    double projected = ball.y + ball.vy * travel;
    final double span = viewport.height - 2 * ball.radius;
    projected = (projected - ball.radius) % (2 * span);
    if (projected < 0) projected += 2 * span;
    if (projected > span) projected = 2 * span - projected;
    return projected + ball.radius;
  }

  void _rollBotError() {
    final DifficultyData data = difficulties[difficulty];
    botTargetError = _rand(-1, 1) * data.error * scale;
    if (_random.nextDouble() > data.reaction) botTargetError *= 2.6;
  }

  void _updateMainBall(double dt) {
    final int steps = (ball.speed * dt / max(ball.radius, 1.0)).ceil().clamp(1, 4).toInt();
    final double stepDt = dt / steps;
    for (int index = 0; index < steps && state == GameState.play; index++) {
      if (curveStrength > 0) {
        ball.vy += sin(time * 5.2) * ball.speed * curveStrength * stepDt;
        final double curvedMagnitude = max(sqrt(ball.vx * ball.vx + ball.vy * ball.vy), 1.0);
        ball.vx = ball.vx / curvedMagnitude * ball.speed;
        ball.vy = ball.vy / curvedMagnitude * ball.speed;
      }
      ball.x += ball.vx * stepDt;
      ball.y += ball.vy * stepDt;
      _bounceVertical(ball);
      if (ball.vx < 0) {
        _collideMainPaddle(player, true);
      } else {
        _collideMainPaddle(opponent, false);
      }
      if (ball.x < -80) {
        final double shieldHeight = min(viewport.height * 0.68, player.height * 2.35);
        final bool shieldHit = shieldActive && (ball.y - player.y).abs() <= shieldHeight / 2 + ball.radius;
        if (shieldHit) {
          shieldActive = false;
          ball.x = max(ball.radius + 8, player.x - player.width / 2 - ball.radius - 8);
          ball.vx = ball.vx.abs();
          ball.vy *= 0.92;
          _spawnParticles(ball.x, ball.y, const Color(0xFFB388FF), 20);
          onEvent(GameEvent.wallHit);
        } else {
          _score(playerScored: false);
        }
      } else if (ball.x > viewport.width + 80) {
        _score(playerScored: true);
      }
    }
  }

  void _bounceVertical(BallBody body) {
    if (body.y - body.radius < 0) {
      body.y = body.radius;
      body.vy = body.vy.abs();
      onEvent(GameEvent.wallHit);
    } else if (body.y + body.radius > viewport.height) {
      body.y = viewport.height - body.radius;
      body.vy = -body.vy.abs();
      onEvent(GameEvent.wallHit);
    }
  }

  void _collideMainPaddle(PaddleBody paddle, bool isPlayer) {
    final double left = paddle.x - paddle.width / 2;
    final double top = paddle.y - paddle.height / 2;
    final double closestX = _clamp(ball.x, left, left + paddle.width);
    final double closestY = _clamp(ball.y, top, top + paddle.height);
    final double dx = ball.x - closestX;
    final double dy = ball.y - closestY;
    if (dx * dx + dy * dy > ball.radius * ball.radius) return;

    final double relative = _clamp((ball.y - paddle.y) / (paddle.height / 2 + ball.radius), -1, 1);
    final double angle = relative * 1.05;
    ball.speed = min(ball.speed * 1.06, 1250 * scale);
    final int direction = isPlayer ? 1 : -1;
    ball.vx = cos(angle) * ball.speed * direction;
    ball.vy = sin(angle) * ball.speed + paddle.velocityY * 0.18;
    final double magnitude = max(sqrt(ball.vx * ball.vx + ball.vy * ball.vy), 1.0);
    ball.vx = ball.vx / magnitude * ball.speed;
    ball.vy = ball.vy / magnitude * ball.speed;
    ball.x = direction > 0 ? left + paddle.width + ball.radius + 0.5 : left - ball.radius - 0.5;
    _spawnParticles(ball.x, ball.y, isPlayer ? const Color(0xFF00E5FF) : const Color(0xFFFF2FD6), 10);
    shake = min(shake + 3, 7);
    onEvent(GameEvent.paddleHit);
    if (isPlayer && mode == GameMode.bot) _rollBotError();
  }

  void _score({required bool playerScored}) {
    trail.clear();
    shake = 12;
    flash = 1;
    final bool doublePoint = playerScored && activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.doublePoint);
    if (playerScored) {
      scorePlayer += doublePoint ? 2 : 1;
      if (doublePoint) {
        activeEffects.removeWhere((ActiveEffect effect) => effect.type == PowerUpType.doublePoint);
        _recomputeEffects();
      }
      flashSide = 1;
      flashColor = doublePoint ? const Color(0xFFFFD54F) : const Color(0xFF00E5FF);
      _spawnBoom(viewport.width - 30, viewport.height / 2);
      onEvent(GameEvent.playerPoint);
    } else {
      scoreOpponent++;
      flashSide = -1;
      flashColor = const Color(0xFFFF2F78);
      _spawnBoom(30, viewport.height / 2);
      onEvent(GameEvent.opponentPoint);
    }
    if (scorePlayer >= winScore || scoreOpponent >= winScore) {
      _finishMatch();
    } else {
      startServe(playerScored ? 1 : -1);
    }
  }

  void _finishMatch() {
    state = GameState.over;
    final bool won = scorePlayer > scoreOpponent;
    final MatchReward reward = save.recordMatch(
      won: won,
      mode: mode == GameMode.bot ? 'bot' : 'friend',
      playerScore: scorePlayer,
      opponentScore: scoreOpponent,
    );
    result = MatchResult(won: won, reward: reward);
    onEvent(won ? GameEvent.win : GameEvent.lose);
  }

  void _spawnParticles(double x, double y, Color color, int count) {
    for (int index = 0; index < count; index++) {
      final double angle = _rand(0, pi * 2);
      final double velocity = _rand(40, 260) * scale;
      particles.add(ParticleBody(
        x: x,
        y: y,
        vx: cos(angle) * velocity,
        vy: sin(angle) * velocity,
        life: _rand(0.3, 0.7),
        color: color,
        size: _rand(1.5, 3.5) * scale,
      ));
    }
    if (particles.length > 220) particles.removeRange(0, particles.length - 220);
  }

  void _spawnBoom(double x, double y) {
    final List<Color> colors = save.selectedItem(ItemCategory.boom).boomColors;
    final List<Color> safeColors = colors.isEmpty ? <Color>[const Color(0xFF00E5FF)] : colors;
    for (int index = 0; index < 24; index++) {
      final double angle = _rand(0, pi * 2);
      final double velocity = _rand(60, 420) * scale;
      particles.add(ParticleBody(
        x: x,
        y: y,
        vx: cos(angle) * velocity,
        vy: sin(angle) * velocity,
        life: _rand(0.5, 1.1),
        color: safeColors[index % safeColors.length],
        size: _rand(2, 4) * scale,
      ));
    }
  }

  void _updatePowerUps(double dt) {
    nextPowerUpTime -= dt;
    if (nextPowerUpTime <= 0 && activePowerUp == null) {
      final List<PowerUpType> pool = <PowerUpType>[
        PowerUpType.big,
        PowerUpType.small,
        PowerUpType.multi,
        PowerUpType.slow,
        PowerUpType.fast,
        PowerUpType.shield,
        PowerUpType.giantBall,
        PowerUpType.paddleBoost,
        PowerUpType.freeze,
        PowerUpType.curve,
        PowerUpType.doublePoint,
        PowerUpType.coin,
      ];
      final PowerUpType type = pool[_random.nextInt(pool.length)];
      activePowerUp = FieldPowerUp(
        type: type,
        x: viewport.width * 0.28 + _random.nextDouble() * viewport.width * 0.44,
        y: viewport.height * 0.16 + _random.nextDouble() * viewport.height * 0.68,
        radius: 30 * scale,
      )..life = 12;
      nextPowerUpTime = _rand(8, 13);
    }

    final FieldPowerUp? field = activePowerUp;
    if (field == null) return;
    field.pulse += dt * 4.6;
    field.life -= dt;
    if (field.life <= 0) {
      activePowerUp = null;
      return;
    }
    final double dx = ball.x - field.x;
    final double dy = ball.y - field.y;
    final double dist = sqrt(dx * dx + dy * dy);
    if (dist < 170 * scale && dist > 0.001) {
      final double pull = (1 - dist / (170 * scale)).clamp(0, 1).toDouble();
      field.x += (dx / dist) * pull * 120 * dt;
      field.y += (dy / dist) * pull * 120 * dt;
    }
    field.x = _clamp(field.x, field.radius + 8, viewport.width - field.radius - 8);
    field.y = _clamp(field.y, field.radius + 8, viewport.height - field.radius - 8);
    if (_hitsPowerUp(ball, field)) {
      _activatePowerUp(field);
      activePowerUp = null;
      return;
    }
    for (final BallBody extra in extraBalls) {
      if (_hitsPowerUp(extra, field)) {
        _activatePowerUp(field);
        activePowerUp = null;
        return;
      }
    }
  }

  bool _hitsPowerUp(BallBody body, FieldPowerUp field) {
    final double dx = body.x - field.x;
    final double dy = body.y - field.y;
    return sqrt(dx * dx + dy * dy) < body.radius + field.radius + 10 * scale;
  }

  void _activatePowerUp(FieldPowerUp powerUp) {
    save.recordPowerUp();
    _spawnParticles(powerUp.x, powerUp.y, powerUp.color, 22);
    onEvent(GameEvent.pickup);
    switch (powerUp.type) {
      case PowerUpType.big:
      case PowerUpType.small:
      case PowerUpType.giantBall:
      case PowerUpType.paddleBoost:
      case PowerUpType.freeze:
      case PowerUpType.curve:
      case PowerUpType.doublePoint:
        activeEffects.removeWhere((ActiveEffect effect) => effect.type == powerUp.type);
        final double duration = switch (powerUp.type) {
          PowerUpType.freeze => 4.5,
          PowerUpType.curve => 6,
          PowerUpType.doublePoint => 12,
          _ => 8,
        };
        activeEffects.add(ActiveEffect(type: powerUp.type, remaining: duration));
        break;
      case PowerUpType.multi:
        for (int index = 0; index < 2; index++) {
          final double angle = _rand(-1, 1);
          final int direction = _random.nextBool() ? 1 : -1;
          extraBalls.add(BallBody(
            x: ball.x,
            y: ball.y,
            vx: cos(angle) * ball.speed * direction,
            vy: sin(angle) * ball.speed,
            radius: ball.radius,
            speed: ball.speed,
          ));
        }
        activeEffects.removeWhere((ActiveEffect effect) => effect.type == PowerUpType.multi);
        activeEffects.add(ActiveEffect(type: powerUp.type, remaining: 10));
        break;
      case PowerUpType.slow:
      case PowerUpType.fast:
        activeEffects.removeWhere((ActiveEffect effect) => effect.type == PowerUpType.slow || effect.type == PowerUpType.fast);
        activeEffects.add(ActiveEffect(type: powerUp.type, remaining: 5));
        break;
      case PowerUpType.shield:
        shieldActive = true;
        break;
      case PowerUpType.coin:
        save.grantCoins(35);
        break;
    }
    _recomputeEffects();
  }

  void _updateEffects(double dt) {
    bool changed = false;
    for (int index = activeEffects.length - 1; index >= 0; index--) {
      activeEffects[index].remaining -= dt;
      if (activeEffects[index].remaining <= 0) {
        activeEffects.removeAt(index);
        changed = true;
      }
    }
    if (changed) _recomputeEffects();
  }

  void _recomputeEffects() {
    final bool big = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.big);
    final bool small = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.small);
    final bool slow = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.slow);
    final bool fast = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.fast);
    final bool giantBall = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.giantBall);
    final bool paddleBoost = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.paddleBoost);
    final bool freeze = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.freeze);
    final bool curve = activeEffects.any((ActiveEffect effect) => effect.type == PowerUpType.curve);
    player.height = basePaddleHeight * (big ? 1.55 : 1);
    opponent.height = basePaddleHeight * (small ? 0.58 : 1);
    timeScale = fast ? 1.48 : (slow ? 0.68 : 1);
    playerMoveMultiplier = paddleBoost ? 1.5 : 1;
    opponentMoveMultiplier = freeze ? 0.42 : 1;
    ballRadiusMultiplier = giantBall ? 1.65 : 1;
    curveStrength = curve ? 0.32 : 0;
    ball.radius = baseBallRadius * ballRadiusMultiplier;
    for (final BallBody extra in extraBalls) {
      extra.radius = ball.radius;
    }
    _clampPaddles();
  }

  void _clampPaddles() {
    if (viewport == Size.zero) return;
    player.y = _clamp(player.y == 0 ? viewport.height / 2 : player.y, player.height / 2, viewport.height - player.height / 2);
    player.targetY = _clamp(player.targetY == 0 ? player.y : player.targetY, player.height / 2, viewport.height - player.height / 2);
    opponent.y = _clamp(opponent.y == 0 ? viewport.height / 2 : opponent.y, opponent.height / 2, viewport.height - opponent.height / 2);
    opponent.targetY = _clamp(opponent.targetY == 0 ? opponent.y : opponent.targetY, opponent.height / 2, viewport.height - opponent.height / 2);
  }

  void _updateExtraBalls(double dt) {
    for (int index = extraBalls.length - 1; index >= 0; index--) {
      final BallBody extra = extraBalls[index];
      extra.x += extra.vx * dt;
      extra.y += extra.vy * dt;
      _bounceVertical(extra);
      _collideExtraPaddle(extra, player, true);
      _collideExtraPaddle(extra, opponent, false);
      if (extra.x < -80 || extra.x > viewport.width + 80) extraBalls.removeAt(index);
    }
  }

  void _collideExtraPaddle(BallBody extra, PaddleBody paddle, bool isPlayer) {
    if ((isPlayer && extra.vx >= 0) || (!isPlayer && extra.vx <= 0)) return;
    final double left = paddle.x - paddle.width / 2;
    final double top = paddle.y - paddle.height / 2;
    final double closestX = _clamp(extra.x, left, left + paddle.width);
    final double closestY = _clamp(extra.y, top, top + paddle.height);
    final double dx = extra.x - closestX;
    final double dy = extra.y - closestY;
    if (dx * dx + dy * dy > extra.radius * extra.radius) return;
    final double relative = _clamp((extra.y - paddle.y) / (paddle.height / 2 + extra.radius), -1, 1);
    final double speed = max(sqrt(extra.vx * extra.vx + extra.vy * extra.vy), baseBallSpeed);
    final double angle = relative * 1.05;
    extra.vx = cos(angle) * speed * (isPlayer ? 1 : -1);
    extra.vy = sin(angle) * speed;
    extra.x = isPlayer ? left + paddle.width + extra.radius + 1 : left - extra.radius - 1;
    _spawnParticles(extra.x, extra.y, isPlayer ? const Color(0xFF00E5FF) : const Color(0xFFFF2FD6), 5);
  }

  void movePlayer(double y) {
    player.targetY = _clamp(y, player.height / 2, viewport.height - player.height / 2);
  }

  void moveOpponent(double y) {
    opponent.targetY = _clamp(y, opponent.height / 2, viewport.height - opponent.height / 2);
  }

  void nudgePlayer(double amount) => movePlayer(player.targetY + amount);
  void nudgeOpponent(double amount) => moveOpponent(opponent.targetY + amount);

  void togglePause() {
    if (state == GameState.play || state == GameState.serve) {
      previousState = state;
      state = GameState.pause;
    } else if (state == GameState.pause) {
      state = previousState;
    }
    notifyListeners();
  }
}
