import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../widgets/pressable_surface.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'shop_screen.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 2;

  void _go(int index) {
    if (_currentIndex == index) return;
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    final List<Widget> screens = <Widget>[
      const ShopScreen(),
      const RankScreen(),
      HomeScreen(
        onOpenShop: () => _go(0),
        onOpenRank: () => _go(1),
        onOpenProfile: () => _go(3),
      ),
      ProfileScreen(onOpenShop: () => _go(0)),
      const ChatScreen(),
    ];

    return AnimatedBuilder(
      animation: save,
      builder: (BuildContext context, Widget? child) {
        return Scaffold(
          backgroundColor: const Color(0xFF05060F),
          body: Stack(
            children: <Widget>[
              IndexedStack(index: _currentIndex, children: screens),
              Positioned(
                left: 0,
                right: 0,
                bottom: 6,
                child: SafeArea(
                  top: false,
                  child: Center(child: _buildNavigation()),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNavigation() {
    const List<(IconData, String)> items = <(IconData, String)>[
      (Icons.storefront_rounded, 'فروشگاه'),
      (Icons.emoji_events_rounded, 'رتبه'),
      (Icons.home_rounded, 'خانه'),
      (Icons.person_rounded, 'پروفایل'),
      (Icons.chat_bubble_rounded, 'چت'),
    ];

    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxWidth: 438),
      margin: const EdgeInsets.symmetric(horizontal: 10),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xF4161C3B), Color(0xEB0A0E20)],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 40, offset: const Offset(0, 14)),
          BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.12), blurRadius: 24),
          const BoxShadow(color: Color(0x22FFFFFF), blurRadius: 2, offset: Offset(0, -1)),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: List<Widget>.generate(items.length, (int index) {
          final bool selected = _currentIndex == index;
          if (index == 2) {
            return Transform.translate(
              offset: const Offset(0, -8),
              child: PressableSurface(
                onTap: () => _go(index),
                pressedScale: 0.90,
                pressedOffset: const Offset(0, 2),
                borderRadius: BorderRadius.circular(32),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: 64,
                  height: 64,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: <Color>[Color(0xFF61F6FF), Color(0xFF00B8FF), Color(0xFF7A2BFF)],
                    ),
                    border: Border.all(color: const Color(0xFF0A0E20), width: 3),
                    boxShadow: <BoxShadow>[
                      BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.42), blurRadius: 26, offset: const Offset(0, 8)),
                      BoxShadow(color: Colors.white.withOpacity(0.12), blurRadius: 2, offset: const Offset(0, -1)),
                    ],
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: <Widget>[
                      Positioned(
                        top: 11,
                        child: Container(
                          width: 28,
                          height: 10,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const Icon(Icons.home_rounded, size: 29, color: Colors.white),
                    ],
                  ),
                ),
              ),
            );
          }
          return Expanded(
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => _go(index),
                borderRadius: BorderRadius.circular(20),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: selected
                        ? LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: <Color>[
                              const Color(0xFF00E5FF).withOpacity(0.22),
                              const Color(0xFF7A2BFF).withOpacity(0.14),
                            ],
                          )
                        : null,
                    color: selected ? null : Colors.white.withOpacity(0.01),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: selected ? const Color(0xFF00E5FF).withOpacity(0.30) : Colors.white.withOpacity(0.03)),
                    boxShadow: selected
                        ? <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.18), blurRadius: 18, offset: const Offset(0, 8))]
                        : null,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Icon(items[index].$1, size: 20, color: selected ? Colors.white : const Color(0xFF7D8DB3)),
                      const SizedBox(height: 3),
                      Text(
                        items[index].$2,
                        style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: selected ? Colors.white : const Color(0xFF7D8DB3)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
