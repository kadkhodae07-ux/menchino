import 'package:flutter/material.dart';

import '../data/save_data.dart';
import '../data/shop_items.dart';
import 'game_screen.dart';
import '../game/game_engine.dart';

class FriendScreen extends StatelessWidget {
  const FriendScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final SaveData save = SaveData.instance;
    return Scaffold(
      backgroundColor: const Color(0xFF05060F),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('👥 بازی با دوستان', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          _card(
            child: Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 14,
              runSpacing: 14,
              children: <Widget>[
                const Text('🎮', style: TextStyle(fontSize: 44)),
                const SizedBox(
                  width: 245,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                    Text('دو نفره روی یک دستگاه', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                    SizedBox(height: 6),
                    Text('بازیکن ۱: لمس نیمه چپ یا W / S\nبازیکن ۲: لمس نیمه راست یا ↑ / ↓\nاولین نفر با ۷ امتیاز برنده است.', style: TextStyle(fontSize: 13, height: 1.9, color: Color(0xFF9FB2D8))),
                  ]),
                ),
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const GameScreen(mode: GameMode.friend))),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('شروع'),
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00E5FF), foregroundColor: Colors.black),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            child: const Row(children: <Widget>[
              Text('🌐', style: TextStyle(fontSize: 44)),
              SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text('بازی آنلاین با دوستان', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), Text('دعوت دوستت از راه دور', style: TextStyle(color: Color(0xFF9FB2D8)))])),
              Chip(label: Text('🔜 به‌زودی')),
            ]),
          ),
          const SizedBox(height: 12),
          _card(
            child: Text(
              '🎨 تجهیزات فعلی — راکت: ${save.selectedItem(ItemCategory.paddle).name} • توپ: ${save.selectedItem(ItemCategory.ball).name} • زمین: ${save.selectedItem(ItemCategory.theme).name}\nاز فروشگاه شخصی‌سازیشون کن!',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13.5, height: 2, color: Color(0xFF9FB2D8)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF141A3A), Color(0xFF0A0C1E)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.16)),
      ),
      child: child,
    );
  }
}
