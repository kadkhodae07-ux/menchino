import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../data/save_data.dart';
import '../game/game_engine.dart';
import '../game/pong_painter.dart';
import '../services/audio_feedback.dart';
import '../utils/fa_digits.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.mode, this.difficulty = 1});

  final GameMode mode;
  final int difficulty;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  late final GameEngine _engine;
  late final Ticker _ticker;
  final FocusNode _focusNode = FocusNode();
  final Map<int, bool> _pointerSides = <int, bool>{};
  Duration? _lastElapsed;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    _engine = GameEngine(save: SaveData.instance, onEvent: _handleEvent);
    _ticker = createTicker(_tick)..start();
    _enterGameMode();
    WidgetsBinding.instance.addPostFrameCallback((_) => _focusNode.requestFocus());
  }

  Future<void> _enterGameMode() async {
    await SystemChrome.setPreferredOrientations(<DeviceOrientation>[DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _engine.dispose();
    _focusNode.dispose();
    SystemChrome.setPreferredOrientations(<DeviceOrientation>[DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _tick(Duration elapsed) {
    if (_lastElapsed == null) {
      _lastElapsed = elapsed;
      return;
    }
    final double dt = (elapsed - _lastElapsed!).inMicroseconds / 1000000;
    _lastElapsed = elapsed;
    _engine.update(dt);
  }

  void _handleEvent(GameEvent event) {
    final AudioFeedbackService audio = AudioFeedbackService.instance;
    switch (event) {
      case GameEvent.launch:
        audio.play(FeedbackEvent.launch);
        break;
      case GameEvent.paddleHit:
        audio.play(FeedbackEvent.paddle);
        break;
      case GameEvent.wallHit:
        audio.play(FeedbackEvent.wall);
        break;
      case GameEvent.playerPoint:
        audio.play(FeedbackEvent.score);
        break;
      case GameEvent.opponentPoint:
        audio.play(FeedbackEvent.losePoint);
        break;
      case GameEvent.pickup:
        audio.play(FeedbackEvent.pickup);
        break;
      case GameEvent.win:
        audio.play(FeedbackEvent.win);
        break;
      case GameEvent.lose:
        audio.play(FeedbackEvent.lose);
        break;
    }
  }

  void _handlePointer(PointerEvent event) {
    final bool left = _pointerSides[event.pointer] ?? (event.localPosition.dx < _engine.viewport.width / 2);
    _pointerSides[event.pointer] = left;
    if (widget.mode == GameMode.friend) {
      if (left) {
        _engine.movePlayer(event.localPosition.dy);
      } else {
        _engine.moveOpponent(event.localPosition.dy);
      }
    } else {
      _engine.movePlayer(event.localPosition.dy);
    }
  }

  void _key(KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) return;
    const double step = 45;
    switch (event.logicalKey) {
      case LogicalKeyboardKey.keyW:
        _engine.nudgePlayer(-step);
        break;
      case LogicalKeyboardKey.keyS:
        _engine.nudgePlayer(step);
        break;
      case LogicalKeyboardKey.arrowUp:
        if (widget.mode == GameMode.friend) {
          _engine.nudgeOpponent(-step);
        } else {
          _engine.nudgePlayer(-step);
        }
        break;
      case LogicalKeyboardKey.arrowDown:
        if (widget.mode == GameMode.friend) {
          _engine.nudgeOpponent(step);
        } else {
          _engine.nudgePlayer(step);
        }
        break;
      case LogicalKeyboardKey.keyP:
      case LogicalKeyboardKey.escape:
        _engine.togglePause();
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_engine.state == GameState.over) return true;
        if (_engine.state == GameState.play || _engine.state == GameState.serve) {
          _engine.togglePause();
        }
        return false;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF05060F),
        body: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            _engine.setSize(constraints.maxWidth, constraints.maxHeight);
            if (!_started && constraints.maxWidth > 0 && constraints.maxHeight > 0) {
              _started = true;
              WidgetsBinding.instance.addPostFrameCallback((_) => _engine.startMatch(gameMode: widget.mode, diff: widget.difficulty));
            }
            return KeyboardListener(
              focusNode: _focusNode,
              onKeyEvent: _key,
              child: Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: _handlePointer,
                onPointerMove: _handlePointer,
                onPointerUp: (PointerUpEvent event) => _pointerSides.remove(event.pointer),
                onPointerCancel: (PointerCancelEvent event) => _pointerSides.remove(event.pointer),
                child: AnimatedBuilder(
                  animation: _engine,
                  builder: (BuildContext context, Widget? child) {
                    return Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        CustomPaint(painter: PongPainter(_engine, SaveData.instance)),
                        Positioned(top: 12, right: 12, child: _roundButton(icon: _engine.state == GameState.pause ? Icons.play_arrow_rounded : Icons.pause_rounded, onTap: _engine.togglePause)),
                        Positioned(top: 12, left: 12, child: _roundButton(icon: SaveData.instance.muted ? Icons.volume_off_rounded : Icons.volume_up_rounded, onTap: () => SaveData.instance.setMuted(!SaveData.instance.muted))),
                        if (_engine.activeEffects.isNotEmpty || _engine.shieldActive) _effectChips(),
                        if (_engine.state == GameState.pause) _pauseOverlay(),
                        if (_engine.state == GameState.over) _gameOverOverlay(),
                      ],
                    );
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _roundButton({required IconData icon, required VoidCallback onTap}) {
    return IconButton(
      onPressed: onTap,
      icon: Icon(icon, color: Colors.white),
      style: IconButton.styleFrom(backgroundColor: const Color(0x990A0E20), side: BorderSide(color: Colors.white.withOpacity(0.18))),
    );
  }

  Widget _effectChips() {
    return Positioned(
      top: 62,
      left: 12,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ..._engine.activeEffects.map((ActiveEffect effect) {
            final FieldPowerUp data = effect.descriptor;
            return Container(
              margin: const EdgeInsets.only(bottom: 5),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(color: const Color(0xDD0A0E20), borderRadius: BorderRadius.circular(14), border: Border.all(color: data.color.withOpacity(0.6))),
              child: Text('${data.emoji} ${data.name} (${faNumber(effect.remaining.ceil())}s)', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
            );
          }),
          if (_engine.shieldActive)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(color: const Color(0xDD0A0E20), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFB388FF))),
              child: const Text('🛡️ سپر فعال', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
            ),
        ],
      ),
    );
  }

  Widget _pauseOverlay() {
    return _overlay(
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        const Text('⏸️ توقف', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: _engine.togglePause, icon: const Icon(Icons.play_arrow_rounded), label: const Text('ادامه بازی'), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00E5FF), foregroundColor: Colors.black)),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.home_rounded), label: const Text('خروج به خانه')),
      ]),
    );
  }

  Widget _gameOverOverlay() {
    final MatchResult? result = _engine.result;
    final bool won = result?.won ?? false;
    final String title = widget.mode == GameMode.bot ? (won ? '🏆 برنده شدی!' : '🤖 ربات برنده شد!') : (won ? '🏆 بازیکن ۱ برنده شد!' : '🎉 بازیکن ۲ برنده شد!');
    return _overlay(
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: won || widget.mode == GameMode.friend ? const Color(0xFF4DFFB0) : const Color(0xFFFF5577))),
        const SizedBox(height: 8),
        Text('نتیجه: ${faNumber(_engine.scorePlayer)} — ${faNumber(_engine.scoreOpponent)}', style: const TextStyle(color: Color(0xFF9FB2D8), fontSize: 15)),
        const SizedBox(height: 14),
        if (result != null)
          Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
            _reward('🪙 +${faNumber(result.reward.coins)}', const Color(0xFFFFE259)),
            const SizedBox(width: 8),
            _reward('⭐ +${faNumber(result.reward.xp)} تجربه', const Color(0xFF8FF4FF)),
          ]),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: () => _engine.startMatch(gameMode: widget.mode, diff: widget.difficulty), icon: const Icon(Icons.refresh_rounded), label: const Text('بازی دوباره'), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00E5FF), foregroundColor: Colors.black)),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.home_rounded), label: const Text('بازگشت به خانه')),
      ]),
    );
  }

  Widget _reward(String text, Color color) {
    return Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(13), border: Border.all(color: color.withOpacity(0.4))), child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w900)));
  }

  Widget _overlay({required Widget child}) {
    return Container(
      color: const Color(0xC0040612),
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 430),
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF141A3A), Color(0xFF0A0C1E)]),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
            boxShadow: <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.15), blurRadius: 50)],
          ),
          child: child,
        ),
      ),
    );
  }
}
