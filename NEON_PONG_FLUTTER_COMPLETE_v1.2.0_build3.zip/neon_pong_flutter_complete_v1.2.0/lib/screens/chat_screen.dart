import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../data/chat_data.dart';
import '../data/save_data.dart';
import '../utils/fa_digits.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  List<StoredChatMessage> get _messages => SaveData.instance.chatMessages;
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final Random _random = Random();
  Timer? _timer;
  int _online = 27;

  @override
  void initState() {
    super.initState();
    _scheduleBot();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scheduleBot() {
    _timer?.cancel();
    _timer = Timer(Duration(seconds: 9 + _random.nextInt(10)), () {
      if (!mounted) return;
      final ChatBot bot = chatBots[_random.nextInt(chatBots.length)];
      SaveData.instance.appendChat(StoredChatMessage(name: bot.name, emoji: bot.emoji, text: chatLines[_random.nextInt(chatLines.length)]));
      setState(() => _online = 18 + _random.nextInt(29));
      _scroll();
      _scheduleBot();
    });
  }

  void _send() {
    final String text = _controller.text.trim();
    if (text.isEmpty) return;
    final SaveData save = SaveData.instance;
    save.appendChat(StoredChatMessage(name: save.name, emoji: save.avatarEmoji, text: text, isMe: true));
    _controller.clear();
    _scroll();
    Future<void>.delayed(Duration(milliseconds: 1200 + _random.nextInt(1600)), () {
      if (!mounted) return;
      final ChatBot bot = chatBots[_random.nextInt(chatBots.length)];
      SaveData.instance.appendChat(StoredChatMessage(name: bot.name, emoji: bot.emoji, text: chatReplies[_random.nextInt(chatReplies.length)]));
      _scroll();
    });
  }

  void _scroll() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 260), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: SaveData.instance,
      builder: (BuildContext context, Widget? child) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 100),
        child: Column(children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
            child: Row(children: <Widget>[
              const Expanded(child: Text('💬 چت سراسری', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900))),
              Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF38FFB0), boxShadow: <BoxShadow>[BoxShadow(color: Color(0xFF38FFB0), blurRadius: 8)])),
              const SizedBox(width: 6),
              Text('${faNumber(_online)} نفر آنلاین', style: const TextStyle(fontSize: 12, color: Color(0xFF9FB2D8))),
            ]),
          ),
          Divider(height: 1, color: Colors.white.withOpacity(0.08)),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (BuildContext context, int index) => _bubble(_messages[index]),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
            child: Row(children: <Widget>[
              Expanded(
                child: TextField(
                  controller: _controller,
                  maxLength: 120,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(counterText: '', hintText: 'پیامت رو بنویس...', filled: true, fillColor: Colors.white.withOpacity(0.07), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: Colors.white.withOpacity(0.2))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFF00E5FF)))),
                ),
              ),
              const SizedBox(width: 9),
              Container(
                height: 48,
                decoration: BoxDecoration(gradient: const LinearGradient(colors: <Color>[Color(0xFF00E5FF), Color(0xFF38FFB0)]), borderRadius: BorderRadius.circular(18), boxShadow: <BoxShadow>[BoxShadow(color: const Color(0xFF00E5FF).withOpacity(0.4), blurRadius: 16)]),
                child: IconButton(onPressed: _send, icon: const Icon(Icons.send_rounded, color: Colors.black)),
              ),
            ]),
          ),
        ]),
      ),
    ),
    );
  }

  Widget _bubble(StoredChatMessage message) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 13),
      child: Row(
        mainAxisAlignment: message.isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (!message.isMe) ...<Widget>[_avatar(message.emoji), const SizedBox(width: 9)],
          Flexible(
            child: Column(
              crossAxisAlignment: message.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: <Widget>[
                Text(message.isMe ? 'تو' : message.name, style: const TextStyle(fontSize: 11, color: Color(0xFF8FA3C8))),
                const SizedBox(height: 3),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: message.isMe ? LinearGradient(colors: <Color>[const Color(0xFF00E5FF).withOpacity(0.24), const Color(0xFF7A2BFF).withOpacity(0.26)]) : null,
                    color: message.isMe ? null : Colors.white.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: message.isMe ? const Color(0xFF00E5FF).withOpacity(0.4) : Colors.white.withOpacity(0.1)),
                  ),
                  child: Text(message.text, style: const TextStyle(fontSize: 13.5, height: 1.7)),
                ),
              ],
            ),
          ),
          if (message.isMe) ...<Widget>[const SizedBox(width: 9), _avatar(message.emoji)],
        ],
      ),
    );
  }

  Widget _avatar(String emoji) => CircleAvatar(radius: 18, backgroundColor: Colors.white.withOpacity(0.08), child: Text(emoji, style: const TextStyle(fontSize: 18)));
}
