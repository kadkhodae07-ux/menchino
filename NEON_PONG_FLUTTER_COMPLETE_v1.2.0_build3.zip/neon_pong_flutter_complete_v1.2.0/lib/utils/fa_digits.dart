const String _persianDigits = '۰۱۲۳۴۵۶۷۸۹';

String faNumber(Object value) {
  return value.toString().replaceAllMapped(
    RegExp(r'\d'),
    (match) => _persianDigits[int.parse(match.group(0)!)],
  );
}
