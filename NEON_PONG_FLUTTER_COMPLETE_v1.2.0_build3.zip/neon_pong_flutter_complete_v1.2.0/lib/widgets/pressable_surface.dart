import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PressableSurface extends StatefulWidget {
  const PressableSurface({
    super.key,
    required this.child,
    this.onTap,
    this.enabled = true,
    this.haptic = true,
    this.pressedScale = 0.965,
    this.pressedOffset = const Offset(0, 3),
    this.duration = const Duration(milliseconds: 110),
    this.borderRadius = const BorderRadius.all(Radius.circular(20)),
  });

  final Widget child;
  final VoidCallback? onTap;
  final bool enabled;
  final bool haptic;
  final double pressedScale;
  final Offset pressedOffset;
  final Duration duration;
  final BorderRadius borderRadius;

  @override
  State<PressableSurface> createState() => _PressableSurfaceState();
}

class _PressableSurfaceState extends State<PressableSurface> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (!widget.enabled || _pressed == value || !mounted) return;
    setState(() => _pressed = value);
  }

  void _handleTap() {
    if (!widget.enabled) return;
    if (widget.haptic) HapticFeedback.selectionClick();
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    Widget content = widget.child;
    if (widget.onTap != null) {
      content = GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _handleTap,
        child: content,
      );
    }

    return Semantics(
      button: widget.onTap != null,
      enabled: widget.enabled,
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: widget.enabled ? (_) => _setPressed(true) : null,
        onPointerUp: widget.enabled ? (_) => _setPressed(false) : null,
        onPointerCancel: widget.enabled ? (_) => _setPressed(false) : null,
        child: AnimatedScale(
          scale: _pressed ? widget.pressedScale : 1,
          duration: widget.duration,
          curve: Curves.easeOutCubic,
          child: AnimatedContainer(
            duration: widget.duration,
            curve: Curves.easeOutCubic,
            transformAlignment: Alignment.center,
            transform: Matrix4.translationValues(
              _pressed ? widget.pressedOffset.dx : 0,
              _pressed ? widget.pressedOffset.dy : 0,
              0,
            ),
            child: content,
          ),
        ),
      ),
    );
  }
}
