import 'package:flutter_test/flutter_test.dart';
import 'package:neon_pong/data/shop_items.dart';

void main() {
  test('all shop categories have a free starter item', () {
    for (final ItemCategory category in ItemCategory.values) {
      expect(
        shopItems.any((ShopItem item) => item.category == category && item.price == 0),
        isTrue,
        reason: 'Missing starter item for $category',
      );
    }
  });

  test('shop item ids are unique', () {
    expect(shopItems.map((ShopItem item) => item.id).toSet().length, shopItems.length);
  });
}
