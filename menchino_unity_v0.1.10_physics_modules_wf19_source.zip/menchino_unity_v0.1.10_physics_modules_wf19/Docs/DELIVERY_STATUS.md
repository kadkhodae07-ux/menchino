# وضعیت تحویل 0.1.10

## انجام‌شده

- خطای Compile مربوط به `UnityEngine.Collider` با فعال‌سازی صریح `com.unity.modules.physics` رفع شد.
- وابستگی‌های Built-in مستقیم سورس اسکن و در Manifest ثبت شدند.
- نسخه اپ `0.1.10` و Version Code برابر `10` است.
- Workflow مستقل `WF-19` دارای Dependency Preflight قبل از اجرای Unity است.
- مسیر فعال‌سازی موفق WF-18، ذخیره‌سازی Docker روی `/mnt`، ساخت دو APK، لاگ خطا و پاک‌سازی خروجی‌های قبلی حفظ شده‌اند.

## نیازمند اجرای GitHub Actions

- Resolve پکیج‌ها و Compile واقعی Unity
- تولید دو APK و نصب روی دستگاه ARM64
- تست عملکرد، Safe Area، زبان فارسی و نرخ فریم
- امضای Release با keystore مالک پروژه
