# گزارش اعتبارسنجی استاتیک نسخه 0.1.10

- تاریخ: 2026-07-20
- Unity: `2022.3.62f1`
- Workflow: `WF-19`
- اصلاح اصلی: فعال‌سازی Physics و کنترل صریح ماژول‌های Built-in مورد استفاده سورس

## کنترل‌های مورد انتظار

- Manifest JSON معتبر و دارای UGUI، Android JNI، Audio، IMGUI، Legacy Input، JSON Serialize، Physics و UI است.
- Assembly Definition به `Unity.ugui` ارجاع دارد.
- نسخه C#، ProjectSettings و نام ZIP همگام هستند.
- Workflow مستقل WF-19 داخل سورس و فایل تحویلی بایت‌به‌بایت یکسان است.
- Compile واقعی Unity و تولید APK در GitHub Actions انجام می‌شود.
