# منچینو — مار و پله سه‌بعدی Android

نسخه سورس: `0.1.10`  
موتور هدف: `Unity 2022.3.62f1 LTS`  
رندر: Built-in Render Pipeline  
نمایش: Portrait  
شناسه بسته: `com.menchino.game`

## اصلاح نسخه 0.1.10

- ماژول Built-in فیزیک برای `UnityEngine.Collider` به‌صورت صریح فعال شد.
- تمام ماژول‌های Built-in که مستقیماً در سورس استفاده می‌شوند در `Packages/manifest.json` پین شدند: Android JNI، Audio، IMGUI، Legacy Input، JSON Serialize، Physics و UI.
- `MenchinoBuildConfigurator` پیش از Build وجود همه پکیج‌های لازم را کنترل می‌کند.
- Workflow شماره‌گذاری‌شده `WF-19` پیش از دانلود/اجرای Unity، Manifest و وابستگی‌های سورس را کنترل می‌کند.

## خروجی Android

Build از متد `Menchino.Editor.AndroidBuilder.Build` انجام می‌شود و دقیقاً دو فایل تولید می‌کند:

- `Builds/Android/Menchino-arm64-v8a.apk`
- `Builds/Android/Menchino-universal.apk`

Workflow این دو APK را بدون فایل اضافی داخل `Menchino-Android-Latest.zip` قرار می‌دهد.

## GitHub Actions

1. فایل سورس `menchino_unity_v0.1.10_physics_modules_wf19_source.zip` را در ریشه Repository خصوصی قرار دهید.
2. Workflow مستقل را در مسیر `.github/workflows/menchino-build-wf19.yml` قرار دهید.
3. Workflowهای قدیمی منچینو را از `.github/workflows` حذف کنید.
4. عنوان اجرای صحیح با `Menchino WF-19` شروع می‌شود.

Workflow جدیدترین ZIP معتبر را براساس SemVer انتخاب می‌کند، ساختار ZIP و Manifest را بررسی می‌کند، لایسنس داخلی را در Home پاک و نوشتنی Runner فعال می‌کند، دو APK مستقل می‌سازد و در صورت خطا بسته لاگ شماره‌گذاری‌شده تحویل می‌دهد.

> فایل لایسنس و اطلاعات حساب Unity طبق درخواست مالک داخل `.unity-ci` قرار دارند؛ Repository باید خصوصی باقی بماند.

## ساختار کلیدی

- `Assets/Scripts/Core`: Composition Root و Scene Flow
- `Assets/Scripts/Data`: مدل‌ها و Config Loader
- `Assets/Scripts/Gameplay`: تخته، قوانین و Match State Machine
- `Assets/Scripts/Presentation`: UI، World View، تاس، مهره و Screenها
- `Assets/Scripts/Services`: ذخیره، اقتصاد، جوایز، مأموریت، صدا و Share
- `Assets/Resources/Configs`: فایل‌های تنظیمات Data-driven
- `Assets/Tests`: تست‌های EditMode
- `Assets/Editor`: پیکربندی Android، کنترل وابستگی‌ها و Build
- `Docs`: معماری، QA و گزارش‌های استاتیک
