import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient, RadialGradient;

class ArenaComponent extends PositionComponent {
  ArenaComponent({super.priority = -100});

  Rect arenaRect = Rect.zero;
  Rect playRect = Rect.zero;
  final List<Offset> _stars = <Offset>[];
  final math.Random _random = math.Random(4137);
  double _time = 0;
  double _goalFlash = 0;
  double _servePulse = 0;
  bool _playerGoal = true;

  void layout(Vector2 gameSize) {
    final double horizontal = (gameSize.x * 0.018).clamp(14.0, 24.0).toDouble();
    final double vertical = (gameSize.y * 0.028).clamp(9.0, 17.0).toDouble();
    arenaRect = Rect.fromLTRB(
      horizontal,
      vertical,
      gameSize.x - horizontal,
      gameSize.y - vertical,
    );
    playRect = arenaRect.deflate((gameSize.y * 0.018).clamp(7.0, 11.0).toDouble());
    size = gameSize;

    if (_stars.isEmpty) {
      for (int i = 0; i < 64; i++) {
        _stars.add(Offset(_random.nextDouble(), _random.nextDouble()));
      }
    }
  }

  void triggerGoal({required bool playerScored}) {
    _playerGoal = playerScored;
    _goalFlash = 1;
  }

  void triggerServe() {
    _servePulse = 1;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _time += dt;
    _goalFlash = math.max(0.0, _goalFlash - dt * 1.7);
    _servePulse = math.max(0.0, _servePulse - dt * 1.4);
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final Rect full = Offset.zero & Size(size.x, size.y);
    canvas.drawRect(
      full,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFF02040A),
            Color(0xFF071127),
            Color(0xFF120718),
          ],
        ).createShader(full),
    );

    _drawAurora(canvas, full);
    _drawStars(canvas);
    if (arenaRect.isEmpty) return;

    final Path outer = _chamferedRect(arenaRect, (arenaRect.height * 0.065).clamp(18.0, 30.0).toDouble());
    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xFF0A3850),
            Color(0xFF111A31),
            Color(0xFF421434),
          ],
        ).createShader(arenaRect),
    );

    final Path inner = _chamferedRect(playRect, (playRect.height * 0.05).clamp(14.0, 23.0).toDouble());
    canvas.drawPath(
      inner,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 1.05,
          colors: <Color>[Color(0xFF14223B), Color(0xFF07101F), Color(0xFF030610)],
        ).createShader(playRect),
    );

    canvas.save();
    canvas.clipPath(inner);
    _drawSpeedLanes(canvas, playRect);
    _drawHexGrid(canvas, playRect);
    _drawPerspectiveRails(canvas, playRect);
    _drawCenterReactor(canvas, playRect);
    _drawGoalZones(canvas, playRect);
    _drawGoalFlash(canvas, playRect);
    canvas.restore();

    _drawFrame(canvas, outer, playRect);
  }

  void _drawAurora(Canvas canvas, Rect full) {
    final double drift = math.sin(_time * 0.45) * full.width * 0.035;
    canvas.drawCircle(
      Offset(full.width * 0.2 + drift, full.height * 0.35),
      full.height * 0.72,
      Paint()
        ..color = const Color(0x3324CFFF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 80),
    );
    canvas.drawCircle(
      Offset(full.width * 0.82 - drift, full.height * 0.68),
      full.height * 0.68,
      Paint()
        ..color = const Color(0x33FF3EAD)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 84),
    );
  }

  void _drawStars(Canvas canvas) {
    for (int i = 0; i < _stars.length; i++) {
      final Offset star = _stars[i];
      final double twinkle = 0.25 + 0.5 * (0.5 + 0.5 * math.sin(_time * (0.7 + i % 5 * 0.13) + i));
      final Offset point = Offset(star.dx * size.x, star.dy * size.y);
      canvas.drawCircle(
        point,
        i % 7 == 0 ? 1.45 : 0.8,
        Paint()..color = const Color(0xFF9EEAFF).withValues(alpha: twinkle),
      );
    }
  }

  void _drawSpeedLanes(Canvas canvas, Rect rect) {
    final Paint lane = Paint()
      ..strokeWidth = 1
      ..color = const Color(0x1439DBFF);
    final double offset = (_time * 46) % 72;
    for (double x = rect.left - rect.height; x < rect.right + rect.height; x += 72) {
      canvas.drawLine(
        Offset(x + offset, rect.bottom),
        Offset(x + rect.height * 0.48 + offset, rect.top),
        lane,
      );
    }
  }

  void _drawPerspectiveRails(Canvas canvas, Rect rect) {
    final Paint rail = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..color = const Color(0x244D7CFF);
    for (int i = 1; i <= 4; i++) {
      final double insetY = rect.height * i * 0.085;
      final double insetX = rect.width * i * 0.035;
      final Path p = Path()
        ..moveTo(rect.left + insetX, rect.top + insetY)
        ..lineTo(rect.right - insetX, rect.top + insetY)
        ..moveTo(rect.left + insetX, rect.bottom - insetY)
        ..lineTo(rect.right - insetX, rect.bottom - insetY);
      canvas.drawPath(p, rail);
    }
  }

  void _drawCenterReactor(Canvas canvas, Rect rect) {
    final Offset c = rect.center;
    final double base = rect.height * 0.13;
    final double pulse = 1 + math.sin(_time * 2.6) * 0.055;
    final Paint glow = Paint()
      ..color = const Color(0x355A58FF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14);
    canvas.drawCircle(c, base * pulse, glow);

    for (int i = 0; i < 3; i++) {
      final double r = base * (0.55 + i * 0.25) * pulse;
      final double start = _time * (i.isEven ? 0.6 : -0.75) + i;
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: r),
        start,
        math.pi * (0.55 + i * 0.12),
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 2.8 : 1.5
          ..strokeCap = StrokeCap.round
          ..color = i == 1 ? const Color(0x99FF50B5) : const Color(0xAA5DE7FF),
      );
    }

    final Paint centerLine = Paint()
      ..color = const Color(0x996E73FF)
      ..strokeWidth = 2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
    final double dash = (rect.height * 0.045).clamp(12.0, 20.0).toDouble();
    for (double y = rect.top + 12; y < rect.bottom; y += dash * 1.75) {
      canvas.drawLine(Offset(c.dx, y), Offset(c.dx, math.min(y + dash, rect.bottom)), centerLine);
    }

    if (_servePulse > 0) {
      final double progress = 1 - _servePulse;
      final double radius = rect.height * (0.08 + progress * 0.5);
      canvas.drawCircle(
        c,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4 * _servePulse + 1
          ..color = const Color(0xFFB9F8FF).withValues(alpha: _servePulse * 0.8),
      );
    }
  }

  void _drawGoalZones(Canvas canvas, Rect rect) {
    final double width = rect.width * 0.055;
    final Rect left = Rect.fromLTWH(rect.left, rect.top, width, rect.height);
    final Rect right = Rect.fromLTWH(rect.right - width, rect.top, width, rect.height);
    canvas.drawRect(
      left,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0x552DDEFF), Color(0x002DDEFF)],
        ).createShader(left),
    );
    canvas.drawRect(
      right,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
          colors: <Color>[Color(0x55FF42AD), Color(0x00FF42AD)],
        ).createShader(right),
    );
  }

  void _drawGoalFlash(Canvas canvas, Rect rect) {
    if (_goalFlash <= 0) return;
    final bool right = _playerGoal;
    final Rect zone = Rect.fromLTWH(
      right ? rect.center.dx : rect.left,
      rect.top,
      rect.width / 2,
      rect.height,
    );
    final Color color = right ? const Color(0xFF4AE5FF) : const Color(0xFFFF4DAF);
    canvas.drawRect(
      zone,
      Paint()
        ..shader = LinearGradient(
          begin: right ? Alignment.centerLeft : Alignment.centerRight,
          end: right ? Alignment.centerRight : Alignment.centerLeft,
          colors: <Color>[
            color.withValues(alpha: 0),
            color.withValues(alpha: _goalFlash * 0.38),
          ],
        ).createShader(zone),
    );
  }

  void _drawFrame(Canvas canvas, Path outer, Rect rect) {
    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.2
        ..color = const Color(0xFF63799B),
    );
    canvas.drawLine(
      rect.topLeft,
      rect.bottomLeft,
      Paint()
        ..color = const Color(0xFF38DFFF)
        ..strokeWidth = 4
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawLine(
      rect.topRight,
      rect.bottomRight,
      Paint()
        ..color = const Color(0xFFFF47AD)
        ..strokeWidth = 4
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
  }

  Path _chamferedRect(Rect rect, double cut) {
    return Path()
      ..moveTo(rect.left + cut, rect.top)
      ..lineTo(rect.right - cut, rect.top)
      ..lineTo(rect.right, rect.top + cut)
      ..lineTo(rect.right, rect.bottom - cut)
      ..lineTo(rect.right - cut, rect.bottom)
      ..lineTo(rect.left + cut, rect.bottom)
      ..lineTo(rect.left, rect.bottom - cut)
      ..lineTo(rect.left, rect.top + cut)
      ..close();
  }

  void _drawHexGrid(Canvas canvas, Rect rect) {
    final Paint grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.7
      ..color = const Color(0x183FD9FF);
    final double radius = (rect.height * 0.052).clamp(14.0, 22.0).toDouble();
    final double h = radius * 1.732;
    for (double x = rect.left - radius; x < rect.right + radius; x += radius * 3) {
      for (double y = rect.top; y < rect.bottom + h; y += h) {
        _drawHex(canvas, Offset(x, y), radius, grid, rect);
        _drawHex(canvas, Offset(x + radius * 1.5, y + h / 2), radius, grid, rect);
      }
    }
  }

  void _drawHex(Canvas canvas, Offset center, double radius, Paint paint, Rect clip) {
    if (!clip.inflate(radius).contains(center)) return;
    final Path path = Path();
    for (int i = 0; i < 6; i++) {
      final double a = math.pi / 3 * i;
      final Offset p = center + Offset(math.cos(a) * radius, math.sin(a) * radius);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }
}
