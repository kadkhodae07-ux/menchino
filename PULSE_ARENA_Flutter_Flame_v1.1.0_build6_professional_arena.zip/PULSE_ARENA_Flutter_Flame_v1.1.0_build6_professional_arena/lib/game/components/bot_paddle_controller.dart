import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

import '../config/game_config.dart';
import 'ball_controller.dart';

class BotPaddleController extends PositionComponent {
  BotPaddleController({
    required this.config,
    required this.ball,
    required this.playerScore,
    required this.isPulseActive,
  });

  final GameConfig config;
  final BallController ball;
  final int Function() playerScore;
  final bool Function() isPulseActive;
  final math.Random _random = math.Random(9721);

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  double _reactionTimer = 0;
  double _motionEnergy = 0;
  bool movementEnabled = true;

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) / movementBounds.height).clamp(0.0, 1.0).toDouble();
    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.018).clamp(19.0, 29.0).toDouble(),
      (arena.height * 0.235).clamp(72.0, 126.0).toDouble(),
    );
    position.x = arena.right - (arena.width * 0.026).clamp(18.0, 34.0).toDouble() - size.x;
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    _reactionTimer = 0;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!movementEnabled || movementBounds.isEmpty) return;

    _reactionTimer -= dt;
    if (_reactionTimer <= 0) {
      final int score = playerScore();
      final double difficulty = (score / 7).clamp(0.0, 1.0).toDouble();
      _reactionTimer = math.max(0.095, config.botReactionDelay - difficulty * 0.045);
      _chooseTarget(difficulty);
    }

    final double pulseFactor = isPulseActive() ? config.pulseSlowFactor : 1.0;
    final double difficultySpeed = 1.0 + playerScore().clamp(0, 7).toInt() * 0.025;
    final double maxStep = config.botPaddleSpeed * pulseFactor * difficultySpeed * dt;
    final double delta = targetY - position.y;
    final double step = delta.clamp(-maxStep, maxStep).toDouble();
    position.y += step;
    _motionEnergy = math.min(1.0, step.abs() / math.max(1.0, maxStep));
    position.y = position.y.clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  void _chooseTarget(double difficulty) {
    final bool ballThreatening = ball.velocity.x > 0 && ball.position.x > movementBounds.center.dx;
    if (!ballThreatening || !ball.active) {
      targetY = movementBounds.center.dy - size.y / 2;
      return;
    }

    final double travelX = position.x - ball.position.x;
    final double travelTime = travelX / math.max(1.0, ball.velocity.x);
    double predictedY = ball.position.y + ball.velocity.y * travelTime;
    predictedY = _reflectY(predictedY, movementBounds.top, movementBounds.bottom);

    double error = config.botBaseAimError * (1 - difficulty * 0.38);
    if (_random.nextDouble() < config.botErrorChance * (1 - difficulty * 0.28)) {
      error *= 2.2;
    }
    predictedY += (_random.nextDouble() * 2 - 1) * error;
    targetY = (predictedY - size.y / 2).clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  double _reflectY(double y, double top, double bottom) {
    final double height = bottom - top;
    if (height <= 0) return top;
    double local = (y - top) % (height * 2);
    if (local < 0) local += height * 2;
    if (local > height) local = height * 2 - local;
    return top + local;
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final Rect r = Offset.zero & Size(size.x, size.y);
    final RRect body = RRect.fromRectAndRadius(r, Radius.circular(size.x * 0.48));
    for (int i = 3; i >= 1; i--) {
      final double alpha = 0.05 + _motionEnergy * 0.07;
      canvas.drawRRect(
        body.shift(Offset(i * 5.0, 0)),
        Paint()..color = const Color(0xFFFF42AD).withValues(alpha: alpha),
      );
    }
    canvas.drawRRect(
      body.inflate(8),
      Paint()
        ..color = const Color(0xCCFF3EAD)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF731867), Color(0xFFFF43AD), Color(0xFFFFDCF0)],
        ).createShader(r),
    );
    canvas.drawRRect(
      body.deflate(4),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8
        ..color = const Color(0xE6FFFFFF),
    );
    canvas.drawRect(
      Rect.fromLTWH(size.x * 0.66, size.y * 0.18, size.x * 0.12, size.y * 0.64),
      Paint()..color = const Color(0xAAFFFFFF),
    );
    canvas.drawCircle(Offset(size.x * 0.44, size.y * 0.5), size.x * 0.17, Paint()..color = const Color(0xFFFFFFFF));
  }
}
