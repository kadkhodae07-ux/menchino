import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, RadialGradient;

import '../config/game_config.dart';
import '../managers/audio_manager.dart';
import 'bot_paddle_controller.dart';
import 'impact_particle.dart';
import 'player_paddle_controller.dart';

class BallController extends PositionComponent {
  BallController({
    required this.config,
    required this.onPlayerScored,
    required this.onBotScored,
    required this.isShieldActive,
    required this.consumeBoost,
    required this.isBoostArmed,
    required this.matchElapsedSeconds,
  }) : super(priority: 20);

  final GameConfig config;
  final VoidCallback onPlayerScored;
  final VoidCallback onBotScored;
  final bool Function() isShieldActive;
  final VoidCallback consumeBoost;
  final bool Function() isBoostArmed;
  final double Function() matchElapsedSeconds;

  late PlayerPaddleController player;
  late BotPaddleController bot;
  Rect arena = Rect.zero;
  Vector2 velocity = Vector2.zero();
  bool active = false;
  double radius = 16;
  double _currentSpeed = 0;
  double _spin = 0;
  double _energy = 0;
  int _serveDirection = 1;
  int _particleSeed = 100;
  final List<Vector2> _trail = <Vector2>[];

  void attachPaddles(PlayerPaddleController playerPaddle, BotPaddleController botPaddle) {
    player = playerPaddle;
    bot = botPaddle;
  }

  void layout(Rect value) {
    final bool firstLayout = arena.isEmpty;
    final bool wasActive = active;
    final double xRatio = firstLayout ? 0.5 : ((position.x - arena.left) / arena.width).clamp(0.0, 1.0).toDouble();
    final double yRatio = firstLayout ? 0.5 : ((position.y - arena.top) / arena.height).clamp(0.0, 1.0).toDouble();

    arena = value;
    radius = (value.height * 0.031).clamp(11.0, 18.0).toDouble();
    size = Vector2.all(radius * 2);

    if (firstLayout) {
      resetToCenter();
      return;
    }

    position = Vector2(
      value.left + value.width * xRatio,
      value.top + value.height * yRatio,
    );
    position.x = position.x.clamp(value.left + radius, value.right - radius).toDouble();
    position.y = position.y.clamp(value.top + radius, value.bottom - radius).toDouble();
    active = wasActive;
  }

  void resetToCenter({int? serveDirection}) {
    if (arena.isEmpty) return;
    if (serveDirection != null) _serveDirection = serveDirection;
    position = Vector2(arena.center.dx, arena.center.dy);
    _trail.clear();
    active = false;
    _energy = 0;
    _currentSpeed = math.min(
      config.ballMaximumSpeed,
      config.ballBaseSpeed + matchElapsedSeconds() * config.ballSpeedIncreasePerSecond,
    );
    final double verticalAngle = math.sin(matchElapsedSeconds() * 0.37 + _serveDirection) * 0.16;
    velocity = Vector2(_serveDirection * math.cos(verticalAngle), math.sin(verticalAngle)) * _currentSpeed;
  }

  void launch() {
    if (arena.isEmpty) return;
    if (velocity.length < 1) {
      velocity = Vector2(_serveDirection * _currentSpeed, 0);
    }
    active = true;
    _energy = 1;
  }

  void stop() {
    active = false;
    velocity = Vector2.zero();
    _trail.clear();
  }

  @override
  void update(double dt) {
    super.update(dt);
    _spin += dt * (active ? 5.6 : 1.8);
    _energy = math.max(0.2, _energy - dt * 0.45);
    if (!active || arena.isEmpty) return;

    final double timedMinimum = math.min(
      config.ballMaximumSpeed,
      config.ballBaseSpeed + matchElapsedSeconds() * config.ballSpeedIncreasePerSecond,
    );
    _currentSpeed = math.max(
      timedMinimum,
      math.min(config.ballMaximumSpeed, _currentSpeed + config.ballSpeedIncreasePerSecond * dt),
    );
    _normalizeVelocityToCurrentSpeed();

    _trail.insert(0, position.clone());
    if (_trail.length > 20) _trail.removeLast();

    position += velocity * dt;
    _handleWalls();
    _handlePaddles();
    _handleShield();
    _handleScore();
  }

  void _handleWalls() {
    if (position.y - radius <= arena.top && velocity.y < 0) {
      position.y = arena.top + radius;
      velocity.y = velocity.y.abs();
      _energy = 1;
      _impact(const Color(0xFF8D7CFF));
      AudioManager.instance.playWall();
    } else if (position.y + radius >= arena.bottom && velocity.y > 0) {
      position.y = arena.bottom - radius;
      velocity.y = -velocity.y.abs();
      _energy = 1;
      _impact(const Color(0xFF8D7CFF));
      AudioManager.instance.playWall();
    }
  }

  void _handlePaddles() {
    final Rect ballRect = Rect.fromCircle(center: Offset(position.x, position.y), radius: radius);
    if (velocity.x < 0 && ballRect.overlaps(player.rect)) {
      position.x = player.rect.right + radius;
      _bounceFromPaddle(player.rect, direction: 1, isPlayer: true);
    } else if (velocity.x > 0 && ballRect.overlaps(bot.rect)) {
      position.x = bot.rect.left - radius;
      _bounceFromPaddle(bot.rect, direction: -1, isPlayer: false);
    }
  }

  void _bounceFromPaddle(Rect paddle, {required int direction, required bool isPlayer}) {
    final double relative = ((position.y - paddle.center.dy) / (paddle.height / 2)).clamp(-1.0, 1.0).toDouble();
    final double angle = relative * (math.pi * 0.31);
    double speed = math.min(config.ballMaximumSpeed, _currentSpeed + 28.0);
    if (isPlayer && isBoostArmed()) {
      speed = math.min(config.ballMaximumSpeed, speed * config.boostMultiplier);
      consumeBoost();
    }
    _currentSpeed = speed;
    velocity = Vector2(direction * math.cos(angle), math.sin(angle)) * speed;
    _energy = 1;
    _impact(isPlayer ? const Color(0xFF35E3FF) : const Color(0xFFFF4DB4));
    AudioManager.instance.playPaddle();
    AudioManager.instance.lightImpact();
  }

  void _handleShield() {
    if (!isShieldActive() || velocity.x >= 0) return;
    final double shieldX = player.position.x - 25;
    if (position.x - radius <= shieldX && position.x > shieldX - 35) {
      position.x = shieldX + radius;
      velocity.x = velocity.x.abs();
      _currentSpeed = math.min(config.ballMaximumSpeed, _currentSpeed + 35.0);
      _normalizeVelocityToCurrentSpeed();
      _energy = 1;
      _impact(const Color(0xFF6CF3FF));
      AudioManager.instance.playPower();
      AudioManager.instance.importantImpact();
    }
  }

  void _handleScore() {
    if (position.x < arena.left - radius * 2) {
      active = false;
      _serveDirection = 1;
      onBotScored();
    } else if (position.x > arena.right + radius * 2) {
      active = false;
      _serveDirection = -1;
      onPlayerScored();
    }
  }

  void _normalizeVelocityToCurrentSpeed() {
    final double length = velocity.length;
    if (length < 0.001) {
      velocity = Vector2(_serveDirection * _currentSpeed, 0);
      return;
    }
    velocity = velocity / length * _currentSpeed;
  }

  void _impact(Color color) {
    parent?.add(ImpactParticle(origin: position.clone(), color: color, seed: _particleSeed++));
  }

  @override
  void render(Canvas canvas) {
    if (_trail.isNotEmpty) {
      final Path streak = Path()..moveTo(0, 0);
      for (int i = 0; i < _trail.length; i++) {
        final Vector2 p = _trail[i];
        streak.lineTo(p.x - position.x, p.y - position.y);
      }
      canvas.drawPath(
        streak,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = radius * 0.8
          ..strokeCap = StrokeCap.round
          ..shader = const RadialGradient(
            colors: <Color>[Color(0xCCFFFFFF), Color(0x77563BFF), Color(0x00563BFF)],
          ).createShader(Rect.fromCircle(center: Offset.zero, radius: radius * 12))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
    }

    for (int i = _trail.length - 1; i >= 0; i--) {
      final Vector2 p = _trail[i];
      final double life = 1 - i / _trail.length;
      final double trailRadius = radius * (0.18 + life * 0.62);
      canvas.drawCircle(
        Offset(p.x - position.x, p.y - position.y),
        trailRadius,
        Paint()
          ..color = const Color(0xFFB34DFF).withValues(alpha: life * 0.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
      );
    }

    canvas.drawCircle(
      Offset.zero,
      radius * (1.75 + _energy * 0.25),
      Paint()
        ..color = const Color(0x995733FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
    );
    canvas.drawCircle(
      Offset.zero,
      radius * 1.15,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..color = const Color(0xCC8FEFFF),
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset.zero, radius: radius * 1.42),
      _spin,
      math.pi * 1.1,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xDDFF5BC2),
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset.zero, radius: radius * 1.42),
      -_spin * 0.8 + math.pi,
      math.pi * 0.62,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xDD55E7FF),
    );
    canvas.drawCircle(
      Offset.zero,
      radius,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.28, -0.3),
          colors: <Color>[Color(0xFFFFFFFF), Color(0xFFF2E9FF), Color(0xFFB564FF), Color(0xFF5A2BC6)],
          stops: <double>[0, 0.28, 0.72, 1],
        ).createShader(Rect.fromCircle(center: Offset.zero, radius: radius)),
    );
    canvas.drawCircle(
      Offset(-radius * 0.25, -radius * 0.3),
      radius * 0.22,
      Paint()..color = const Color(0xFFFFFFFF),
    );
  }
}

typedef VoidCallback = void Function();
