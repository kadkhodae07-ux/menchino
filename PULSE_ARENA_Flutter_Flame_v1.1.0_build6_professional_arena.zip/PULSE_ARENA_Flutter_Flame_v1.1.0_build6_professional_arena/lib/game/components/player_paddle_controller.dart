import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

class PlayerPaddleController extends PositionComponent {
  PlayerPaddleController({required this.moveSpeed});

  final double moveSpeed;
  Rect movementBounds = Rect.zero;
  double targetY = 0;
  bool movementEnabled = true;
  double _motionEnergy = 0;

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) / movementBounds.height).clamp(0.0, 1.0).toDouble();
    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.018).clamp(19.0, 29.0).toDouble(),
      (arena.height * 0.235).clamp(72.0, 126.0).toDouble(),
    );
    position.x = arena.left + (arena.width * 0.026).clamp(18.0, 34.0).toDouble();
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
  }

  void setTargetFromTouch(double touchY) {
    targetY = (touchY - size.y / 2).clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!movementEnabled) return;
    final double delta = targetY - position.y;
    final double maxStep = moveSpeed * dt;
    final double step = delta.clamp(-maxStep, maxStep).toDouble();
    position.y += step;
    _motionEnergy = math.min(1.0, step.abs() / math.max(1.0, maxStep));
    position.y = position.y.clamp(movementBounds.top, movementBounds.bottom - size.y).toDouble();
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final Rect r = Offset.zero & Size(size.x, size.y);
    final RRect body = RRect.fromRectAndRadius(r, Radius.circular(size.x * 0.48));

    for (int i = 3; i >= 1; i--) {
      final double alpha = 0.05 + _motionEnergy * 0.07;
      canvas.drawRRect(
        body.shift(Offset(-i * 5.0, 0)),
        Paint()..color = const Color(0xFF2EE3FF).withValues(alpha: alpha),
      );
    }
    canvas.drawRRect(
      body.inflate(8),
      Paint()
        ..color = const Color(0xCC1FD9FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFFE7FDFF), Color(0xFF36E3FF), Color(0xFF0870C3)],
        ).createShader(r),
    );
    canvas.drawRRect(
      body.deflate(4),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8
        ..color = const Color(0xE6FFFFFF),
    );
    canvas.drawRect(
      Rect.fromLTWH(size.x * 0.22, size.y * 0.18, size.x * 0.12, size.y * 0.64),
      Paint()..color = const Color(0xAAFFFFFF),
    );
    canvas.drawCircle(Offset(size.x * 0.56, size.y * 0.5), size.x * 0.17, Paint()..color = const Color(0xFFFFFFFF));
  }
}
