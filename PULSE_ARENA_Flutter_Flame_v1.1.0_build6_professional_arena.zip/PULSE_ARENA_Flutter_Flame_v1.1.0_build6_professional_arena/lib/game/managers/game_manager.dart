import '../config/game_config.dart';
import '../models/game_view_state.dart';
import 'match_manager.dart';
import 'power_up_manager.dart';
import 'score_manager.dart';

class GameManager {
  GameManager(this.config)
      : match = MatchManager(config),
        score = ScoreManager(config),
        powers = PowerUpManager(config);

  final GameConfig config;
  final MatchManager match;
  final ScoreManager score;
  final PowerUpManager powers;

  void reset() {
    match.reset();
    score.reset();
    powers.reset();
  }

  GameViewState makeViewState({
    required bool soundEnabled,
    required bool vibrationEnabled,
  }) {
    return GameViewState(
      playerScore: score.playerScore,
      botScore: score.botScore,
      elapsedSeconds: match.elapsedSeconds,
      countdown: match.countdownLabel,
      countdownRemaining: match.countdownRemaining,
      countdownTotal: match.countdownTotal,
      openingSequence: match.openingSequence,
      phase: match.phase,
      winner: match.winner,
      shieldUses: powers.shieldUses,
      boostUses: powers.boostUses,
      pulseUses: powers.pulseUses,
      shieldActive: powers.shieldActive,
      boostArmed: powers.boostArmed,
      pulseActive: powers.pulseActive,
      soundEnabled: soundEnabled,
      vibrationEnabled: vibrationEnabled,
    );
  }
}
