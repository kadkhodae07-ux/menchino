class GameConfig {
  const GameConfig({
    this.targetScore = 7,
    this.ballBaseSpeed = 650,
    this.ballMaximumSpeed = 1180,
    this.ballSpeedIncreasePerSecond = 5.2,
    this.playerPaddleSpeed = 1720,
    this.botPaddleSpeed = 735,
    this.botReactionDelay = 0.17,
    this.botErrorChance = 0.16,
    this.botBaseAimError = 52,
    this.countdownDuration = 3.6,
    this.pointServeDelay = 0.88,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.52,
    this.boostMultiplier = 1.3,
    this.shieldUses = 2,
    this.boostUses = 1,
    this.pulseUses = 2,
  });

  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double playerPaddleSpeed;
  final double botPaddleSpeed;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double pointServeDelay;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
