enum MatchPhase { countdown, playing, paused, finished }

enum MatchWinner { player, bot }

enum PowerType { shield, boost, pulse }

class GameViewState {
  const GameViewState({
    this.playerScore = 0,
    this.botScore = 0,
    this.elapsedSeconds = 0,
    this.countdown = 3,
    this.countdownRemaining = 3.6,
    this.countdownTotal = 3.6,
    this.openingSequence = true,
    this.phase = MatchPhase.countdown,
    this.winner,
    this.shieldUses = 2,
    this.boostUses = 1,
    this.pulseUses = 2,
    this.shieldActive = false,
    this.boostArmed = false,
    this.pulseActive = false,
    this.soundEnabled = true,
    this.vibrationEnabled = true,
  });

  final int playerScore;
  final int botScore;
  final double elapsedSeconds;
  final int countdown;
  final double countdownRemaining;
  final double countdownTotal;
  final bool openingSequence;
  final MatchPhase phase;
  final MatchWinner? winner;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
  final bool shieldActive;
  final bool boostArmed;
  final bool pulseActive;
  final bool soundEnabled;
  final bool vibrationEnabled;

  GameViewState copyWith({
    int? playerScore,
    int? botScore,
    double? elapsedSeconds,
    int? countdown,
    double? countdownRemaining,
    double? countdownTotal,
    bool? openingSequence,
    MatchPhase? phase,
    MatchWinner? winner,
    bool clearWinner = false,
    int? shieldUses,
    int? boostUses,
    int? pulseUses,
    bool? shieldActive,
    bool? boostArmed,
    bool? pulseActive,
    bool? soundEnabled,
    bool? vibrationEnabled,
  }) {
    return GameViewState(
      playerScore: playerScore ?? this.playerScore,
      botScore: botScore ?? this.botScore,
      elapsedSeconds: elapsedSeconds ?? this.elapsedSeconds,
      countdown: countdown ?? this.countdown,
      countdownRemaining: countdownRemaining ?? this.countdownRemaining,
      countdownTotal: countdownTotal ?? this.countdownTotal,
      openingSequence: openingSequence ?? this.openingSequence,
      phase: phase ?? this.phase,
      winner: clearWinner ? null : (winner ?? this.winner),
      shieldUses: shieldUses ?? this.shieldUses,
      boostUses: boostUses ?? this.boostUses,
      pulseUses: pulseUses ?? this.pulseUses,
      shieldActive: shieldActive ?? this.shieldActive,
      boostArmed: boostArmed ?? this.boostArmed,
      pulseActive: pulseActive ?? this.pulseActive,
      soundEnabled: soundEnabled ?? this.soundEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
    );
  }
}
