import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../game/models/game_view_state.dart';
import '../game/pulse_arena_game.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final PulseArenaGame game;

  @override
  void initState() {
    super.initState();
    game = PulseArenaGame();
  }

  @override
  Widget build(BuildContext context) {
    final Widget gameLayer = _GameInput(game: game);
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) game.pauseMatch();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF02040A),
        body: SafeArea(
          minimum: const EdgeInsets.all(2),
          child: ValueListenableBuilder<GameViewState>(
            valueListenable: game.viewState,
            child: gameLayer,
            builder: (BuildContext context, GameViewState state, Widget? child) {
              return LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) {
                  final bool compact = constraints.maxHeight < 390 || constraints.maxWidth < 760;
                  return Stack(
                    fit: StackFit.expand,
                    children: <Widget>[
                      child!,
                      _Hud(state: state, compact: compact, onPause: game.pauseMatch),
                      _PowerDock(state: state, compact: compact, onActivate: game.activatePower),
                      if (state.phase == MatchPhase.countdown)
                        state.openingSequence
                            ? _MatchIntro(state: state, compact: compact)
                            : _QuickServe(state: state),
                      if (state.phase == MatchPhase.paused)
                        _PausePanel(
                          state: state,
                          onResume: game.resumeMatch,
                          onRestart: game.restartMatch,
                          onHome: () => SceneTransitionManager.openStart(context),
                          onToggleSound: game.toggleSound,
                          onToggleVibration: game.toggleVibration,
                        ),
                      if (state.phase == MatchPhase.finished)
                        _EndPanel(
                          state: state,
                          onReplay: game.restartMatch,
                          onHome: () => SceneTransitionManager.openStart(context),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}

class _GameInput extends StatelessWidget {
  const _GameInput({required this.game});
  final PulseArenaGame game;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (DragStartDetails details) => game.handleTouch(details.localPosition.dy),
      onPanUpdate: (DragUpdateDetails details) => game.handleTouch(details.localPosition.dy),
      onTapDown: (TapDownDetails details) => game.handleTouch(details.localPosition.dy),
      child: GameWidget<PulseArenaGame>(game: game),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({required this.state, required this.compact, required this.onPause});
  final GameViewState state;
  final bool compact;
  final VoidCallback onPause;

  String get _time {
    final int total = state.elapsedSeconds.floor();
    final int minutes = total ~/ 60;
    final int seconds = total % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: compact ? 18 : 30,
      right: compact ? 18 : 30,
      top: compact ? 12 : 16,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: _FighterPlate(
                name: 'شما',
                subtitle: 'PULSE PILOT',
                score: state.playerScore,
                color: const Color(0xFF39E4FF),
                player: true,
                compact: compact,
              ),
            ),
          ),
          _CenterStatus(time: _time, compact: compact),
          Expanded(
            child: Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  _FighterPlate(
                    name: 'ربات',
                    subtitle: 'NOVA AI',
                    score: state.botScore,
                    color: const Color(0xFFFF4DB1),
                    player: false,
                    compact: compact,
                  ),
                  SizedBox(width: compact ? 6 : 10),
                  _PauseButton(onTap: onPause, compact: compact),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FighterPlate extends StatelessWidget {
  const _FighterPlate({
    required this.name,
    required this.subtitle,
    required this.score,
    required this.color,
    required this.player,
    required this.compact,
  });
  final String name;
  final String subtitle;
  final int score;
  final Color color;
  final bool player;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final Widget identity = Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        _PilotCore(color: color, player: player, size: compact ? 31 : 38),
        SizedBox(width: compact ? 7 : 10),
        if (!compact)
          Column(
            crossAxisAlignment: player ? CrossAxisAlignment.start : CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                name,
                textDirection: TextDirection.rtl,
                style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900),
              ),
              Text(
                subtitle,
                style: TextStyle(color: color.withValues(alpha: 0.82), fontSize: 8, letterSpacing: 1.5, fontWeight: FontWeight.w800),
              ),
            ],
          ),
      ],
    );

    return ClipRRect(
      borderRadius: BorderRadius.circular(compact ? 15 : 20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          height: compact ? 46 : 58,
          width: compact ? 118 : 205,
          padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 12),
          decoration: BoxDecoration(
            color: const Color(0xC40A1020),
            borderRadius: BorderRadius.circular(compact ? 15 : 20),
            border: Border.all(color: color.withValues(alpha: 0.66), width: 1.2),
            boxShadow: <BoxShadow>[BoxShadow(color: color.withValues(alpha: 0.22), blurRadius: 18)],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: player
                ? <Widget>[
                    identity,
                    const Spacer(),
                    _ScoreNumber(value: score, color: color, compact: compact),
                  ]
                : <Widget>[
                    _ScoreNumber(value: score, color: color, compact: compact),
                    const Spacer(),
                    identity,
                  ],
          ),
        ),
      ),
    );
  }
}

class _PilotCore extends StatelessWidget {
  const _PilotCore({required this.color, required this.player, required this.size});
  final Color color;
  final bool player;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.35),
          colors: <Color>[Colors.white, color, color.withValues(alpha: 0.3)],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: 0.7), width: 1.5),
        boxShadow: <BoxShadow>[BoxShadow(color: color.withValues(alpha: 0.65), blurRadius: 14)],
      ),
      child: Icon(player ? Icons.person_rounded : Icons.memory_rounded, size: size * 0.56, color: const Color(0xFF07101E)),
    );
  }
}

class _ScoreNumber extends StatelessWidget {
  const _ScoreNumber({required this.value, required this.color, required this.compact});
  final int value;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Text(
      '$value',
      style: TextStyle(
        color: Colors.white,
        fontSize: compact ? 25 : 34,
        fontWeight: FontWeight.w900,
        height: 1,
        shadows: <Shadow>[Shadow(color: color, blurRadius: 16)],
      ),
    );
  }
}

class _CenterStatus extends StatelessWidget {
  const _CenterStatus({required this.time, required this.compact});
  final String time;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: compact ? 43 : 54,
      margin: EdgeInsets.symmetric(horizontal: compact ? 8 : 15),
      padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 18),
      decoration: BoxDecoration(
        color: const Color(0xD10A1020),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0x887B7CFF), width: 1.2),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(time, style: TextStyle(fontSize: compact ? 16 : 19, fontWeight: FontWeight.w900, letterSpacing: 2.2)),
          if (!compact)
            const Text(
              'FIRST TO 7',
              style: TextStyle(fontSize: 7.5, color: Color(0xFFA8B5D8), letterSpacing: 2.2, fontWeight: FontWeight.w800),
            ),
        ],
      ),
    );
  }
}

class _PauseButton extends StatelessWidget {
  const _PauseButton({required this.onTap, required this.compact});
  final VoidCallback onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          width: compact ? 42 : 48,
          height: compact ? 42 : 48,
          decoration: BoxDecoration(
            color: const Color(0xD10A1020),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0x667E8FB9)),
          ),
          child: Icon(Icons.pause_rounded, size: compact ? 22 : 26, color: const Color(0xFFE9F6FF)),
        ),
      ),
    );
  }
}

class _PowerDock extends StatelessWidget {
  const _PowerDock({required this.state, required this.compact, required this.onActivate});
  final GameViewState state;
  final bool compact;
  final bool Function(PowerType type) onActivate;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 0,
      right: 0,
      bottom: compact ? 10 : 14,
      child: Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(compact ? 18 : 23),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 12, vertical: compact ? 5 : 7),
              decoration: BoxDecoration(
                color: const Color(0xC80A0F1E),
                borderRadius: BorderRadius.circular(compact ? 18 : 23),
                border: Border.all(color: const Color(0x556D7DA5)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  _PowerButton(
                    title: 'سپر',
                    icon: Icons.shield_rounded,
                    count: state.shieldUses,
                    active: state.shieldActive,
                    color: const Color(0xFF27DFFF),
                    compact: compact,
                    enabled: state.phase == MatchPhase.playing && state.shieldUses > 0 && !state.shieldActive,
                    onTap: () => onActivate(PowerType.shield),
                  ),
                  _DockDivider(compact: compact),
                  _PowerButton(
                    title: 'شتاب',
                    icon: Icons.bolt_rounded,
                    count: state.boostUses,
                    active: state.boostArmed,
                    color: const Color(0xFFFFA63A),
                    compact: compact,
                    enabled: state.phase == MatchPhase.playing && state.boostUses > 0 && !state.boostArmed,
                    onTap: () => onActivate(PowerType.boost),
                  ),
                  _DockDivider(compact: compact),
                  _PowerButton(
                    title: 'پالس',
                    icon: Icons.graphic_eq_rounded,
                    count: state.pulseUses,
                    active: state.pulseActive,
                    color: const Color(0xFFB66CFF),
                    compact: compact,
                    enabled: state.phase == MatchPhase.playing && state.pulseUses > 0 && !state.pulseActive,
                    onTap: () => onActivate(PowerType.pulse),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _DockDivider extends StatelessWidget {
  const _DockDivider({required this.compact});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: compact ? 28 : 36,
      margin: EdgeInsets.symmetric(horizontal: compact ? 4 : 7),
      color: const Color(0x335E6E96),
    );
  }
}

class _PowerButton extends StatefulWidget {
  const _PowerButton({
    required this.title,
    required this.icon,
    required this.count,
    required this.active,
    required this.color,
    required this.compact,
    required this.enabled,
    required this.onTap,
  });
  final String title;
  final IconData icon;
  final int count;
  final bool active;
  final Color color;
  final bool compact;
  final bool enabled;
  final VoidCallback onTap;

  @override
  State<_PowerButton> createState() => _PowerButtonState();
}

class _PowerButtonState extends State<_PowerButton> {
  bool pressed = false;

  @override
  Widget build(BuildContext context) {
    final double opacity = widget.enabled || widget.active ? 1 : 0.34;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.enabled ? (_) => setState(() => pressed = true) : null,
      onTapCancel: widget.enabled ? () => setState(() => pressed = false) : null,
      onTapUp: widget.enabled
          ? (_) {
              setState(() => pressed = false);
              widget.onTap();
            }
          : null,
      child: AnimatedScale(
        scale: pressed ? 0.91 : 1,
        duration: const Duration(milliseconds: 90),
        child: AnimatedOpacity(
          opacity: opacity,
          duration: const Duration(milliseconds: 160),
          child: SizedBox(
            width: widget.compact ? 70 : 92,
            height: widget.compact ? 37 : 46,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  width: widget.compact ? 28 : 34,
                  height: widget.compact ? 28 : 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: widget.color.withValues(alpha: widget.active ? 0.34 : 0.13),
                    border: Border.all(color: widget.color.withValues(alpha: 0.8)),
                    boxShadow: widget.active
                        ? <BoxShadow>[BoxShadow(color: widget.color.withValues(alpha: 0.55), blurRadius: 15)]
                        : null,
                  ),
                  child: Icon(widget.icon, color: widget.color, size: widget.compact ? 17 : 21),
                ),
                SizedBox(width: widget.compact ? 5 : 7),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    if (!widget.compact)
                      Text(widget.title, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                    Text('×${widget.count}', style: TextStyle(fontSize: widget.compact ? 11 : 12, color: widget.color, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MatchIntro extends StatelessWidget {
  const _MatchIntro({required this.state, required this.compact});
  final GameViewState state;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final double progress = state.countdownTotal <= 0
        ? 1
        : (1 - state.countdownRemaining / state.countdownTotal).clamp(0.0, 1.0).toDouble();
    final bool ready = state.countdownRemaining > 3;
    final bool pulse = state.countdownRemaining <= 0.38;
    final String centerText = ready ? 'MATCH READY' : (pulse ? 'PULSE!' : '${state.countdown}');

    return IgnorePointer(
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          ColoredBox(color: Color.lerp(const Color(0xBE01040B), const Color(0x5801040B), progress)!),
          CustomPaint(painter: _IntroEnergyPainter(progress: progress)),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                AnimatedOpacity(
                  opacity: ready ? 1 : 0.72,
                  duration: const Duration(milliseconds: 180),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      _IntroFighter(label: 'شما', caption: 'PULSE PILOT', color: const Color(0xFF39E4FF), compact: compact),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: compact ? 20 : 34),
                        child: const Text(
                          'VS',
                          style: TextStyle(color: Color(0xFFC7D2F0), fontSize: 15, letterSpacing: 4, fontWeight: FontWeight.w900),
                        ),
                      ),
                      _IntroFighter(label: 'ربات', caption: 'NOVA AI', color: const Color(0xFFFF4DB1), compact: compact),
                    ],
                  ),
                ),
                SizedBox(height: compact ? 16 : 24),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 180),
                  transitionBuilder: (Widget child, Animation<double> animation) {
                    final Animation<double> scale = Tween<double>(begin: 1.55, end: 1).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutBack));
                    return FadeTransition(opacity: animation, child: ScaleTransition(scale: scale, child: child));
                  },
                  child: Text(
                    centerText,
                    key: ValueKey<String>(centerText),
                    style: TextStyle(
                      fontSize: ready ? (compact ? 25 : 34) : (pulse ? (compact ? 48 : 66) : (compact ? 78 : 104)),
                      fontWeight: FontWeight.w900,
                      letterSpacing: ready ? 7 : (pulse ? 6 : 1),
                      color: Colors.white,
                      shadows: const <Shadow>[
                        Shadow(color: Color(0xFF5AE7FF), blurRadius: 20),
                        Shadow(color: Color(0xFFFF4FB3), blurRadius: 38),
                      ],
                    ),
                  ),
                ),
                if (ready) ...<Widget>[
                  const SizedBox(height: 7),
                  const Text(
                    'OFFLINE DUEL • FIRST TO 7',
                    style: TextStyle(fontSize: 9, color: Color(0xFFB2C2E6), letterSpacing: 2.8, fontWeight: FontWeight.w800),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _IntroFighter extends StatelessWidget {
  const _IntroFighter({required this.label, required this.caption, required this.color, required this.compact});
  final String label;
  final String caption;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: compact ? 105 : 142,
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 14, vertical: compact ? 8 : 11),
      decoration: BoxDecoration(
        color: const Color(0xC90A1020),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withValues(alpha: 0.72)),
        boxShadow: <BoxShadow>[BoxShadow(color: color.withValues(alpha: 0.25), blurRadius: 24)],
      ),
      child: Column(
        children: <Widget>[
          _PilotCore(color: color, player: color == const Color(0xFF39E4FF), size: compact ? 32 : 42),
          SizedBox(height: compact ? 5 : 7),
          Text(label, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
          if (!compact)
            Text(caption, style: TextStyle(fontSize: 7.5, letterSpacing: 1.4, color: color, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _IntroEnergyPainter extends CustomPainter {
  const _IntroEnergyPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = size.center(Offset.zero);
    final double base = size.height * 0.27;
    for (int i = 0; i < 4; i++) {
      final double radius = base + i * size.height * 0.055;
      final double direction = i.isEven ? 1 : -1;
      final double start = progress * math.pi * 2.4 * direction + i * 0.8;
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: radius),
        start,
        math.pi * (0.38 + i * 0.08),
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 3.2 : 1.5
          ..strokeCap = StrokeCap.round
          ..color = (i.isEven ? const Color(0xFF48E5FF) : const Color(0xFFFF4DB1)).withValues(alpha: 0.42),
      );
    }
    final double wave = size.height * (0.1 + progress * 0.65);
    canvas.drawCircle(
      c,
      wave,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..color = const Color(0xFFB8F7FF).withValues(alpha: (1 - progress) * 0.4),
    );
  }

  @override
  bool shouldRepaint(covariant _IntroEnergyPainter oldDelegate) => oldDelegate.progress != progress;
}

class _QuickServe extends StatelessWidget {
  const _QuickServe({required this.state});
  final GameViewState state;

  @override
  Widget build(BuildContext context) {
    final double progress = state.countdownTotal <= 0
        ? 1
        : (1 - state.countdownRemaining / state.countdownTotal).clamp(0.0, 1.0).toDouble();
    return IgnorePointer(
      child: Center(
        child: Transform.scale(
          scale: 0.78 + progress * 0.28,
          child: Opacity(
            opacity: math.sin(progress * math.pi).clamp(0.0, 1.0).toDouble(),
            child: Container(
              width: 138,
              height: 74,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                color: const Color(0xD70A1020),
                border: Border.all(color: const Color(0xFF9EEFFF), width: 1.5),
                boxShadow: const <BoxShadow>[
                  BoxShadow(color: Color(0x8858E5FF), blurRadius: 28),
                  BoxShadow(color: Color(0x66FF4DB1), blurRadius: 40),
                ],
              ),
              child: const Text(
                'SERVE',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 5, color: Colors.white),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PausePanel extends StatelessWidget {
  const _PausePanel({
    required this.state,
    required this.onResume,
    required this.onRestart,
    required this.onHome,
    required this.onToggleSound,
    required this.onToggleVibration,
  });
  final GameViewState state;
  final VoidCallback onResume;
  final VoidCallback onRestart;
  final VoidCallback onHome;
  final VoidCallback onToggleSound;
  final VoidCallback onToggleVibration;

  @override
  Widget build(BuildContext context) {
    return _OverlayPanel(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const _PanelTitle(icon: Icons.pause_circle_filled_rounded, title: 'توقف بازی', subtitle: 'MATCH PAUSED', color: Color(0xFF6DE8FF)),
          const SizedBox(height: 17),
          _MenuButton(text: 'ادامه بازی', icon: Icons.play_arrow_rounded, primary: true, onTap: onResume),
          _MenuButton(text: 'شروع مجدد', icon: Icons.refresh_rounded, onTap: onRestart),
          _MenuButton(text: 'بازگشت به شروع', icon: Icons.home_rounded, onTap: onHome),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              _ToggleButton(
                icon: state.soundEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                label: 'صدا',
                enabled: state.soundEnabled,
                onTap: onToggleSound,
              ),
              const SizedBox(width: 12),
              _ToggleButton(
                icon: state.vibrationEnabled ? Icons.vibration_rounded : Icons.mobile_off_rounded,
                label: 'لرزش',
                enabled: state.vibrationEnabled,
                onTap: onToggleVibration,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _EndPanel extends StatelessWidget {
  const _EndPanel({required this.state, required this.onReplay, required this.onHome});
  final GameViewState state;
  final VoidCallback onReplay;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    final bool won = state.winner == MatchWinner.player;
    final Color color = won ? const Color(0xFF39E2FF) : const Color(0xFFFF4FAE);
    return _OverlayPanel(
      glow: color,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          _PanelTitle(
            icon: won ? Icons.emoji_events_rounded : Icons.sports_esports_rounded,
            title: won ? 'پیروزی کامل' : 'شکست در نبرد',
            subtitle: won ? 'PULSE MASTER' : 'NOVA AI WINS',
            color: color,
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0x99101729),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withValues(alpha: 0.35)),
            ),
            child: Text(
              '${state.playerScore}   —   ${state.botScore}',
              style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, letterSpacing: 5, shadows: <Shadow>[Shadow(color: color, blurRadius: 18)]),
            ),
          ),
          const SizedBox(height: 18),
          _MenuButton(text: 'بازی دوباره', icon: Icons.replay_rounded, primary: true, onTap: onReplay),
          _MenuButton(text: 'بازگشت به شروع', icon: Icons.home_rounded, onTap: onHome),
        ],
      ),
    );
  }
}

class _PanelTitle extends StatelessWidget {
  const _PanelTitle({required this.icon, required this.title, required this.subtitle, required this.color});
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Icon(icon, size: 45, color: color, shadows: <Shadow>[Shadow(color: color, blurRadius: 20)]),
        const SizedBox(height: 5),
        Text(title, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        Text(subtitle, style: TextStyle(fontSize: 8.5, letterSpacing: 2.7, color: color, fontWeight: FontWeight.w800)),
      ],
    );
  }
}

class _OverlayPanel extends StatelessWidget {
  const _OverlayPanel({required this.child, this.glow = const Color(0xFF704BFF)});
  final Widget child;
  final Color glow;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xC8000208),
      child: Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(27),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              width: 390,
              constraints: const BoxConstraints(maxHeight: 352),
              padding: const EdgeInsets.fromLTRB(25, 20, 25, 20),
              decoration: BoxDecoration(
                color: const Color(0xED0A0F1D),
                borderRadius: BorderRadius.circular(27),
                border: Border.all(color: glow.withValues(alpha: 0.72), width: 1.4),
                boxShadow: <BoxShadow>[BoxShadow(color: glow.withValues(alpha: 0.3), blurRadius: 40)],
              ),
              child: SingleChildScrollView(child: child),
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({required this.text, required this.icon, required this.onTap, this.primary = false});
  final String text;
  final IconData icon;
  final VoidCallback onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: SizedBox(
        width: 280,
        height: 47,
        child: FilledButton.icon(
          onPressed: () {
            AudioManager.instance.playButton();
            onTap();
          },
          style: FilledButton.styleFrom(
            backgroundColor: primary ? const Color(0xFF0C6F9A) : const Color(0xFF151E35),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
              side: BorderSide(color: primary ? const Color(0xFF7DEAFF) : const Color(0x665DE3FF)),
            ),
          ),
          icon: Icon(icon, size: 21),
          label: Text(text, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        ),
      ),
    );
  }
}

class _ToggleButton extends StatelessWidget {
  const _ToggleButton({required this.icon, required this.label, required this.enabled, required this.onTap});
  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = enabled ? const Color(0xFF46DFFF) : const Color(0xFF7C849C);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: onTap,
        child: Container(
          width: 105,
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFF141B2D),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: color.withValues(alpha: 0.45)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 7),
              Text(label, textDirection: TextDirection.rtl, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }
}
