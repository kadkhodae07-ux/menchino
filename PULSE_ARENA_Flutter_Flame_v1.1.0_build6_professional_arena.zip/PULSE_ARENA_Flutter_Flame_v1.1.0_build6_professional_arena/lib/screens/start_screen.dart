import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';

class StartScreen extends StatefulWidget {
  const StartScreen({super.key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  bool _pressed = false;
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    if (_leaving) return;
    setState(() {
      _pressed = true;
      _leaving = true;
    });
    await AudioManager.instance.playButton();
    await Future<void>.delayed(const Duration(milliseconds: 150));
    if (!mounted) return;
    await SceneTransitionManager.openGame(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 420),
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              AnimatedBuilder(
                animation: _controller,
                builder: (_, __) => CustomPaint(
                  painter: _StartBackgroundPainter(progress: _controller.value),
                ),
              ),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    const Text(
                      'PULSE',
                      style: TextStyle(
                        fontSize: 56,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 12,
                        color: Color(0xFFE9FBFF),
                        shadows: <Shadow>[
                          Shadow(color: Color(0xFF29D9FF), blurRadius: 24),
                          Shadow(color: Color(0xFFB044FF), blurRadius: 42),
                        ],
                      ),
                    ),
                    const Text(
                      'A R E N A',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 11,
                        color: Color(0xFFFF69BE),
                      ),
                    ),
                    const SizedBox(height: 48),
                    GestureDetector(
                      onTapDown: (_) => setState(() => _pressed = true),
                      onTapCancel: () => setState(() => _pressed = false),
                      onTapUp: (_) => _start(),
                      child: AnimatedScale(
                        scale: _pressed ? 0.94 : 1,
                        duration: const Duration(milliseconds: 100),
                        child: Container(
                          width: 260,
                          height: 76,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            gradient: const LinearGradient(
                              colors: <Color>[Color(0xFF0D6EA8), Color(0xFF6934B6), Color(0xFFB7217A)],
                            ),
                            border: Border.all(color: const Color(0xFFBFF8FF), width: 2),
                            boxShadow: const <BoxShadow>[
                              BoxShadow(color: Color(0xAA2FD9FF), blurRadius: 26, spreadRadius: 1),
                              BoxShadow(color: Color(0x88FF3EAC), blurRadius: 34, spreadRadius: -4),
                            ],
                          ),
                          child: const Text(
                            'شروع بازی',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const Positioned(
                left: 20,
                bottom: 12,
                child: Text('OFFLINE DUEL', style: TextStyle(fontSize: 10, letterSpacing: 2, color: Color(0x668DE8FF))),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StartBackgroundPainter extends CustomPainter {
  const _StartBackgroundPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment.center,
          radius: 0.95,
          colors: <Color>[Color(0xFF101A34), Color(0xFF070914), Color(0xFF020309)],
        ).createShader(rect),
    );

    final Paint line = Paint()
      ..color = const Color(0x162FD9FF)
      ..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 52) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), line);
    }
    for (double y = 0; y < size.height; y += 52) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), line);
    }

    final double centerY = size.height * 0.46;
    final Rect leftPaddle = Rect.fromCenter(center: Offset(size.width * 0.22, centerY), width: 22, height: 112);
    final Rect rightPaddle = Rect.fromCenter(center: Offset(size.width * 0.78, centerY), width: 22, height: 112);
    _drawPaddle(canvas, leftPaddle, const Color(0xFF32DDFF));
    _drawPaddle(canvas, rightPaddle, const Color(0xFFFF46AE));

    final double t = Curves.easeInOut.transform(progress);
    final double ballX = lerpDouble(size.width * 0.29, size.width * 0.71, t)!;
    final double ballY = centerY + math.sin(progress * math.pi * 2) * 28;
    final Offset ball = Offset(ballX, ballY);
    canvas.drawCircle(
      ball,
      25,
      Paint()
        ..color = const Color(0x885839FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
    );
    canvas.drawCircle(
      ball,
      11,
      Paint()
        ..shader = const RadialGradient(colors: <Color>[Colors.white, Color(0xFFC98CFF), Color(0xFF7A32E8)])
            .createShader(Rect.fromCircle(center: ball, radius: 11)),
    );
  }

  void _drawPaddle(Canvas canvas, Rect rect, Color color) {
    final RRect rrect = RRect.fromRectAndRadius(rect, const Radius.circular(12));
    canvas.drawRRect(
      rrect.inflate(6),
      Paint()
        ..color = color.withValues(alpha: 0.55)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawRRect(rrect, Paint()..color = color);
    canvas.drawRRect(rrect.deflate(4), Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white70);
  }

  @override
  bool shouldRepaint(covariant _StartBackgroundPainter oldDelegate) => oldDelegate.progress != progress;
}
