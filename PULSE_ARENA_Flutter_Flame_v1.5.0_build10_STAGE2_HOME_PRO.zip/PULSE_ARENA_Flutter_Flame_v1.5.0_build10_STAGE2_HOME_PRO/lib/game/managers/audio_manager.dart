import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/services.dart';

class AudioManager {
  AudioManager._();

  static final AudioManager instance = AudioManager._();

  bool soundEnabled = true;
  bool vibrationEnabled = true;
  bool _bgmStarted = false;

  static const List<String> _sounds = <String>[
    'button.wav',
    'paddle.wav',
    'wall.wav',
    'score.wav',
    'power.wav',
    'win.wav',
    'lose.wav',
    'countdown.wav',
    'perfect.wav',
    'arena_loop.wav',
  ];

  Future<void> preload() async {
    try {
      await FlameAudio.audioCache.loadAll(_sounds);
    } catch (_) {
      // Audio failure must never block gameplay.
    }
  }

  Future<void> startBgm() async {
    if (!soundEnabled || _bgmStarted) return;
    try {
      await FlameAudio.bgm.play('arena_loop.wav', volume: 0.22);
      _bgmStarted = true;
    } catch (_) {
      _bgmStarted = false;
    }
  }

  Future<void> stopBgm() async {
    try {
      await FlameAudio.bgm.stop();
    } catch (_) {
      // Ignore unavailable audio backends.
    }
    _bgmStarted = false;
  }

  Future<void> setSoundEnabled(bool enabled) async {
    soundEnabled = enabled;
    if (enabled) {
      await startBgm();
    } else {
      await stopBgm();
    }
  }

  Future<void> playButton() => _play('button.wav', volume: 0.42);
  Future<void> playPaddle() => _play('paddle.wav', volume: 0.48);
  Future<void> playPerfect() => _play('perfect.wav', volume: 0.62);
  Future<void> playCountdown() => _play('countdown.wav', volume: 0.55);
  Future<void> playWall() => _play('wall.wav', volume: 0.28);
  Future<void> playScore() => _play('score.wav', volume: 0.58);
  Future<void> playPower() => _play('power.wav', volume: 0.56);
  Future<void> playWin() => _play('win.wav', volume: 0.68);
  Future<void> playLose() => _play('lose.wav', volume: 0.62);

  Future<void> _play(String fileName, {double volume = 1}) async {
    if (!soundEnabled) return;
    try {
      await FlameAudio.play(fileName, volume: volume);
    } catch (_) {
      // Keep gameplay functional even when a device audio backend fails.
    }
  }

  Future<void> lightImpact() async {
    if (vibrationEnabled) await HapticFeedback.lightImpact();
  }

  Future<void> importantImpact() async {
    if (vibrationEnabled) await HapticFeedback.mediumImpact();
  }
}
