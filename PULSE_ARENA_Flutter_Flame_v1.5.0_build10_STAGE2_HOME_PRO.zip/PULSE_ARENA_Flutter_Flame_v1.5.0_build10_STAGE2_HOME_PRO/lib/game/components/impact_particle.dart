import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

class ImpactParticle extends PositionComponent {
  ImpactParticle({required Vector2 origin, required Color color, required this.seed})
      : _color = color,
        super(position: origin.clone(), priority: 30);

  final Color _color;
  final int seed;
  late final List<_Spark> _sparks;
  double _life = 0.28;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final math.Random random = math.Random(seed);
    _sparks = List<_Spark>.generate(7, (int index) {
      final double angle = random.nextDouble() * math.pi * 2;
      final double speed = 95.0 + random.nextDouble() * 150.0;
      return _Spark(
        velocity: Vector2(math.cos(angle) * speed, math.sin(angle) * speed),
        radius: 1.2 + random.nextDouble() * 2.0,
      );
    });
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double safeDt = dt.clamp(0.0, 0.05).toDouble();
    _life -= safeDt;
    for (final _Spark spark in _sparks) {
      spark.offset += spark.velocity * safeDt;
      spark.velocity *= math.exp(-5.0 * safeDt);
    }
    if (_life <= 0) removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final double opacity = (_life / 0.28).clamp(0.0, 1.0).toDouble();
    for (final _Spark spark in _sparks) {
      final Offset center = Offset(spark.offset.x, spark.offset.y);
      canvas.drawCircle(
        center,
        spark.radius * 2.2,
        Paint()..color = _color.withValues(alpha: opacity * 0.12),
      );
      canvas.drawCircle(
        center,
        spark.radius,
        Paint()..color = _color.withValues(alpha: opacity),
      );
    }
  }
}

class _Spark {
  _Spark({required this.velocity, required this.radius});

  Vector2 offset = Vector2.zero();
  Vector2 velocity;
  final double radius;
}
