import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

class PlayerPaddleController extends PositionComponent {
  PlayerPaddleController({
    required this.moveSpeed,
    this.acceleration = 36000,
    this.response = 32,
  });

  final double moveSpeed;
  final double acceleration;
  final double response;

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  bool movementEnabled = true;
  double verticalVelocity = 0;

  double _inputVelocity = 0;
  double _lastInputTarget = 0;
  int _lastInputMicros = 0;
  double _motionEnergy = 0;
  double _hitEnergy = 0;
  Path _bodyPath = Path();
  Rect _localBounds = Rect.zero;

  static const Color _cyan = Color(0xFF25E2FF);

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) /
                movementBounds.height)
            .clamp(0.0, 1.0)
            .toDouble();

    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.024).clamp(23.0, 35.0).toDouble(),
      (arena.height * 0.275).clamp(86.0, 138.0).toDouble(),
    );
    position.x =
        arena.left + (arena.width * 0.032).clamp(24.0, 42.0).toDouble();
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
    _lastInputTarget = targetY;
    _rebuildVisuals();
  }

  void _rebuildVisuals() {
    _localBounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * 0.32;
    _bodyPath = Path()
      ..moveTo(cut, 0)
      ..lineTo(size.x - cut * 0.22, 0)
      ..lineTo(size.x, cut)
      ..lineTo(size.x, size.y - cut)
      ..lineTo(size.x - cut * 0.22, size.y)
      ..lineTo(cut, size.y)
      ..lineTo(0, size.y - cut * 0.65)
      ..lineTo(0, cut * 0.65)
      ..close();
  }

  void setTargetFromTouch(double touchY) {
    if (movementBounds.isEmpty) return;
    final double nextTarget = (touchY - size.y / 2)
        .clamp(movementBounds.top, movementBounds.bottom - size.y)
        .toDouble();

    final int now = DateTime.now().microsecondsSinceEpoch;
    if (_lastInputMicros != 0) {
      final double seconds = (now - _lastInputMicros) / 1000000;
      if (seconds > 0.001 && seconds < 0.10) {
        final double sample = (nextTarget - _lastInputTarget) / seconds;
        _inputVelocity = (_inputVelocity * .42 + sample * .58)
            .clamp(-5200.0, 5200.0)
            .toDouble();
      }
    }
    _lastInputMicros = now;
    _lastInputTarget = nextTarget;
    targetY = nextTarget;
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    verticalVelocity = 0;
    _inputVelocity = 0;
    _motionEnergy = 0;
    _lastInputTarget = targetY;
    _lastInputMicros = 0;
  }

  void registerHit({required bool perfect}) {
    _hitEnergy = perfect ? 1.35 : 0.9;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double frameDt = dt.clamp(1 / 300, 1 / 20).toDouble();
    _hitEnergy = math.max(0.0, _hitEnergy - frameDt * 6.2);
    _inputVelocity *= math.exp(-9.5 * frameDt);
    if (!movementEnabled || movementBounds.isEmpty) return;

    final double delta = targetY - position.y;
    final double distanceRatio =
        (delta.abs() / math.max(1.0, movementBounds.height * .34))
            .clamp(0.0, 1.0)
            .toDouble();

    final double dynamicResponse = response + distanceRatio * 18;
    final double dynamicMaxSpeed = moveSpeed * (1 + distanceRatio * .38);
    final double desiredVelocity =
        (delta * dynamicResponse + _inputVelocity * .18)
            .clamp(-dynamicMaxSpeed, dynamicMaxSpeed)
            .toDouble();

    final bool braking =
        verticalVelocity != 0 && delta != 0 && verticalVelocity.sign != delta.sign;
    final double maxVelocityChange =
        acceleration * (braking ? 1.65 : 1.0) * frameDt;
    verticalVelocity += (desiredVelocity - verticalVelocity)
        .clamp(-maxVelocityChange, maxVelocityChange)
        .toDouble();

    position.y += verticalVelocity * frameDt;

    if (delta.abs() < .42 && verticalVelocity.abs() < 18) {
      position.y = targetY;
      verticalVelocity = 0;
    }

    final double minY = movementBounds.top;
    final double maxY = movementBounds.bottom - size.y;
    if (position.y <= minY) {
      position.y = minY;
      if (verticalVelocity < 0) verticalVelocity = 0;
    } else if (position.y >= maxY) {
      position.y = maxY;
      if (verticalVelocity > 0) verticalVelocity = 0;
    }

    final double targetEnergy =
        (verticalVelocity.abs() / math.max(1.0, dynamicMaxSpeed))
            .clamp(0.0, 1.0)
            .toDouble();
    _motionEnergy +=
        (targetEnergy - _motionEnergy) * (1 - math.exp(-18 * frameDt));
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final double ghostDistance = 2.5 + _motionEnergy * 7;
    for (int i = 2; i >= 1; i--) {
      canvas.save();
      canvas.translate(-i * ghostDistance, 0);
      canvas.drawPath(
        _bodyPath,
        Paint()
          ..color = _cyan.withValues(
            alpha: .025 + _motionEnergy * (.065 / i),
          ),
      );
      canvas.restore();
    }

    canvas.drawPath(
      _bodyPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 7 + _hitEnergy * 3
        ..color = _cyan.withValues(alpha: .15 + _hitEnergy * .11),
    );
    canvas.drawPath(
      _bodyPath,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            Color(0xFF063F68),
            Color(0xFF25E2FF),
            Color(0xFFF2FFFF),
          ],
        ).createShader(_localBounds),
    );
    canvas.drawPath(
      _bodyPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.7
        ..color = const Color(0xEFFFFFFF),
    );

    final Rect energyChannel =
        Rect.fromLTWH(size.x * .20, size.y * .10, size.x * .22, size.y * .80);
    canvas.drawRRect(
      RRect.fromRectAndRadius(energyChannel, Radius.circular(size.x * .12)),
      Paint()..color = const Color(0xEAF5FFFF),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(size.x * .66, size.y * .5),
          width: size.x * (.48 + _hitEnergy * .08),
          height: size.x * (.48 + _hitEnergy * .08),
        ),
        Radius.circular(size.x),
      ),
      Paint()..color = const Color(0xFFFFFFFF),
    );

    final Paint detailPaint = Paint()..color = const Color(0xB8073458);
    for (final double y in <double>[.16, .84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(size.x * .58, size.y * y),
            width: size.x * .54,
            height: size.x * .14,
          ),
          Radius.circular(size.x * .07),
        ),
        detailPaint,
      );
    }
  }
}
