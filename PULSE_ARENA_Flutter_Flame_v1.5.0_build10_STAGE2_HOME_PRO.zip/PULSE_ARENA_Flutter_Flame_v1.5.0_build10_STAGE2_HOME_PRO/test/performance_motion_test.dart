import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/components/ball_controller.dart';
import 'package:pulse_arena/game/components/bot_paddle_controller.dart';
import 'package:pulse_arena/game/components/player_paddle_controller.dart';
import 'package:pulse_arena/game/config/game_config.dart';

void main() {
  test('player paddle follows touch quickly without teleporting', () {
    const Rect arena = Rect.fromLTWH(0, 0, 1000, 400);
    final PlayerPaddleController player = PlayerPaddleController(
      moveSpeed: 2850,
      acceleration: 36000,
      response: 32,
    )..layout(arena);

    final double startY = player.position.y;
    player.setTargetFromTouch(arena.bottom - 15);
    player.update(1 / 60);

    expect(player.position.y, greaterThan(startY));
    expect(player.position.y - startY, lessThan(55));
    expect(player.verticalVelocity, greaterThan(0));

    for (int i = 0; i < 42; i++) {
      player.update(1 / 60);
    }
    expect(player.position.y, closeTo(arena.bottom - player.size.y, 1.0));
  });

  test('bot paddle uses responsive predictive motion values', () {
    const GameConfig config = GameConfig();
    expect(config.botPaddleSpeed, greaterThanOrEqualTo(800));
    expect(config.botPaddleAcceleration, greaterThanOrEqualTo(10000));
    expect(config.botReactionDelay, lessThanOrEqualTo(0.11));
  });

  test('fixed-step ball movement stays consistent across frame rates', () {
    const GameConfig config = GameConfig(
      ballBaseSpeed: 600,
      ballMaximumSpeed: 600,
      ballSpeedIncreasePerSecond: 0,
    );
    const Rect arena = Rect.fromLTWH(0, 0, 5000, 1200);

    BallController makeBall() {
      final BallController ball = BallController(
        config: config,
        onPlayerScored: () {},
        onBotScored: () {},
        isShieldActive: () => false,
        consumeBoost: () {},
        isBoostArmed: () => false,
        matchElapsedSeconds: () => 0,
      );
      final PlayerPaddleController player = PlayerPaddleController(
        moveSpeed: config.playerPaddleSpeed,
        acceleration: config.playerPaddleAcceleration,
      )..layout(arena);
      final BotPaddleController bot = BotPaddleController(
        config: config,
        ball: ball,
        playerScore: () => 0,
        botScore: () => 0,
        isPulseActive: () => false,
      )..layout(arena);
      ball
        ..attachPaddles(player, bot)
        ..layout(arena)
        ..resetToCenter(serveDirection: 1)
        ..velocity = Vector2(600, 0)
        ..launch();
      return ball;
    }

    final BallController at60 = makeBall();
    final BallController at30 = makeBall();

    for (int i = 0; i < 30; i++) {
      at60.update(1 / 60);
    }
    for (int i = 0; i < 15; i++) {
      at30.update(1 / 30);
    }

    expect(at60.position.x, closeTo(at30.position.x, 0.6));
    expect(at60.position.y, closeTo(at30.position.y, 0.6));
  });

  test('default match target is ten goals', () {
    expect(const GameConfig().targetScore, 10);
  });
}
