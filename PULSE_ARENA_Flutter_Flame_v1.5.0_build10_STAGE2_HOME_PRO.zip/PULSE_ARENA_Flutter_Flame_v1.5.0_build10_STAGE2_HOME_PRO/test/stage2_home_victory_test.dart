import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('stage 2 home screen is coded, reference-matched, and pressable', () {
    final String home = File('lib/screens/home_screen.dart').readAsStringSync();
    final String pressable =
        File('lib/widgets/neon_pressable.dart').readAsStringSync();

    expect(home, contains('class HomeScreen'));
    expect(home, contains('_HomeCanvas'));
    expect(home, contains('_TechPanelPainter'));
    expect(home, contains('_ArenaPreviewPainter'));
    expect(home, contains('_ActionButtonPainter'));
    expect(home, contains('PULSE ARENA'));
    expect(home, contains('شروع بازی'));
    expect(home, contains('بازی آفلاین'));
    expect(home, contains('تنظیمات'));
    expect(home, contains('ماموریت‌ها'));
    expect(pressable, contains('AnimatedScale'));
    expect(pressable, contains('pressedScale = 0.96'));
  });

  test('home and game use separate production orientations', () {
    final String orientation =
        File('lib/core/orientation_manager.dart').readAsStringSync();
    final String manifest =
        File('android/app/src/main/AndroidManifest.xml').readAsStringSync();

    expect(orientation, contains('DeviceOrientation.portraitUp'));
    expect(orientation, contains('DeviceOrientation.landscapeLeft'));
    expect(orientation, contains('DeviceOrientation.landscapeRight'));
    expect(manifest, contains('android:screenOrientation="unspecified"'));
  });

  test('real-player victory has a dedicated professional celebration', () {
    final String gameScreen =
        File('lib/screens/game_screen.dart').readAsStringSync();
    final String game =
        File('lib/game/pulse_arena_game.dart').readAsStringSync();
    final String arena =
        File('lib/game/components/arena_component.dart').readAsStringSync();

    expect(gameScreen, contains('_VictoryFxPainter'));
    expect(gameScreen, contains("'VICTORY'"));
    expect(game, contains('arenaComponent.triggerVictory()'));
    expect(arena, contains('void triggerVictory()'));
    expect(arena, contains('_drawVictoryGlow'));
  });
}
