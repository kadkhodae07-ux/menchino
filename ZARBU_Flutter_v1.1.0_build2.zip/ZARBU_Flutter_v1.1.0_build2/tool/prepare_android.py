#!/usr/bin/env python3
from pathlib import Path
import re
import shutil
import sys

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
android = root / 'android'
app = android / 'app'
release = root / 'release'
package_id = 'mk.kadkhodai.zarbu'

if not android.exists() or not app.exists():
    raise SystemExit('Android project is missing.')
if not (release / 'bazikhone_release_key.jks').is_file():
    raise SystemExit('Release keystore is missing.')
if not (release / 'key.properties').is_file():
    raise SystemExit('Release key.properties is missing.')

shutil.copy2(release / 'bazikhone_release_key.jks', android / 'bazikhone_release_key.jks')
props = (release / 'key.properties').read_text(encoding='utf-8')
props = re.sub(r'(?m)^storeFile=.*$', 'storeFile=../bazikhone_release_key.jks', props)
(android / 'key.properties').write_text(props, encoding='utf-8')

kts = app / 'build.gradle.kts'
groovy = app / 'build.gradle'

if kts.exists():
    text = kts.read_text(encoding='utf-8')
    text = re.sub(r'namespace\s*=\s*"[^"]+"', f'namespace = "{package_id}"', text)
    text = re.sub(r'applicationId\s*=\s*"[^"]+"', f'applicationId = "{package_id}"', text)

    if 'val keystoreProperties = java.util.Properties()' not in text:
        block = '''val keystoreProperties = java.util.Properties()\nval keystorePropertiesFile = rootProject.file("key.properties")\nif (keystorePropertiesFile.exists()) {\n    keystorePropertiesFile.inputStream().use { keystoreProperties.load(it) }\n}\n\n'''
        text = text.replace('android {', block + 'android {', 1)

    if 'create("release")' not in text:
        signing = '''    signingConfigs {\n        create("release") {\n            keyAlias = keystoreProperties["keyAlias"] as String\n            keyPassword = keystoreProperties["keyPassword"] as String\n            storeFile = file(keystoreProperties["storeFile"] as String)\n            storePassword = keystoreProperties["storePassword"] as String\n        }\n    }\n\n'''
        text = text.replace('    buildTypes {', signing + '    buildTypes {', 1)

    text = re.sub(
        r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
        'signingConfig = signingConfigs.getByName("release")',
        text,
    )
    if 'signingConfig = signingConfigs.getByName("release")' not in text:
        text, count = re.subn(
            r'(buildTypes\s*\{\s*(?:getByName\("release"\)|release)\s*\{)',
            r'\1\n            signingConfig = signingConfigs.getByName("release")',
            text,
            count=1,
        )
        if count == 0:
            raise SystemExit('Could not bind release build type to release signing config.')
    kts.write_text(text, encoding='utf-8')

elif groovy.exists():
    text = groovy.read_text(encoding='utf-8')
    text = re.sub(r'namespace\s+["\'][^"\']+["\']', f'namespace "{package_id}"', text)
    text = re.sub(r'applicationId\s+["\'][^"\']+["\']', f'applicationId "{package_id}"', text)

    if 'keystoreProperties = new Properties()' not in text:
        prefix = '''def keystoreProperties = new Properties()\ndef keystorePropertiesFile = rootProject.file('key.properties')\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))\n}\n\n'''
        text = prefix + text

    if 'signingConfigs {' not in text:
        signing = '''    signingConfigs {\n        release {\n            keyAlias keystoreProperties['keyAlias']\n            keyPassword keystoreProperties['keyPassword']\n            storeFile file(keystoreProperties['storeFile'])\n            storePassword keystoreProperties['storePassword']\n        }\n    }\n\n'''
        text = text.replace('    buildTypes {', signing + '    buildTypes {', 1)

    text = re.sub(r'signingConfig\s+signingConfigs\.debug', 'signingConfig signingConfigs.release', text)
    if 'signingConfig signingConfigs.release' not in text:
        text, count = re.subn(
            r'(buildTypes\s*\{\s*release\s*\{)',
            r'\1\n            signingConfig signingConfigs.release',
            text,
            count=1,
        )
        if count == 0:
            raise SystemExit('Could not bind release build type to release signing config.')
    groovy.write_text(text, encoding='utf-8')
else:
    raise SystemExit('android/app/build.gradle(.kts) is missing.')

manifest = app / 'src' / 'main' / 'AndroidManifest.xml'
if manifest.exists():
    manifest_text = manifest.read_text(encoding='utf-8')
    manifest_text = re.sub(r'android:label="[^"]*"', 'android:label="ZARBU"', manifest_text, count=1)
    manifest.write_text(manifest_text, encoding='utf-8')

joined = ''
for candidate in (kts, groovy):
    if candidate.exists():
        joined += candidate.read_text(encoding='utf-8')
if package_id not in joined:
    raise SystemExit('Package ID verification failed.')
if 'release' not in joined or 'keystoreProperties' not in joined:
    raise SystemExit('Release signing configuration verification failed.')

print('Android identity and release signing prepared.')
