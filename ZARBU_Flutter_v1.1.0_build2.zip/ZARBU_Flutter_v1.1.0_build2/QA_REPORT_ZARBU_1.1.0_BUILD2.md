# ZARBU v1.1.0+2 — QA REPORT

Overall static QA: **PASS**

| Check | Status | Detail |
|---|---|---|
| Relative Dart imports | PASS | no missing imports |
| Dart delimiter structure | PASS | balanced |
| Single ZARBU league | PASS | legacy multi-tier league removed |
| Top 3 podium | PASS | #2 / #1 / #3 podium implemented |
| Three-layer frame removal | PASS | shared surface has one face + bottom depth |
| Press interaction | PASS | panel/button/back press feedback enabled |
| Version | PASS | 1.1.0+2 |
| Package name | PASS | Dart package zarbu |
| Cup asset declared | PASS | asset exists and is declared |
| Cup original quality | PASS | SHA-256 fc6034bfef65f5cfd8cd12ad620ebaf431695eaeef5b48c48c163bf22fe62ca5 |
| Release keystore integrity | PASS | SHA-256 6fda62d47e354c4149e3a95938048d08a7209c77561031179f894ad1057940d5 |
| Workflow YAML | PASS | parsed successfully |
| Android Package ID enforcement | PASS | mk.kadkhodai.zarbu |
| Release signing workflow | PASS | signing prepared and APK signature verified |
| Analyze + Test in workflow | PASS | both enabled |
| Safe artifact cleanup | PASS | only prior ZARBU APK artifact name is deleted |
| Helper scripts syntax | PASS | bash and Python syntax valid |

## Runtime note

Flutter SDK is not installed in this execution environment, so a local `flutter analyze/test/build` could not be executed here. The delivered GitHub Actions workflow performs Analyze, Test, Release Build, applicationId verification and APK signature verification on the runner before accepting the artifact.
