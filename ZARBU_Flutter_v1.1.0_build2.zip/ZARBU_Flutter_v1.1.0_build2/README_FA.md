# ZARBU / ضربو — Flutter Source

نسخه: `1.1.0+2`

Package ID ثابت Android: `mk.kadkhodai.zarbu`

## تغییرات این نسخه

- برند بازی از PHONG به `ZARBU / ضربو` منتقل شد.
- فقط یک لیگ وجود دارد: `لیگ ضربو`.
- کاپ اختصاصی لیگ ضربو به‌صورت PNG شفاف و بدون بازفشرده‌سازی استفاده می‌شود.
- صفحه لیگ دارای سکوی گرافیکی سه نفر برتر، رتبه شخصی و جدول یکپارچه است.
- مدل داده لیگ از UI جدا شده تا بعداً API آنلاین جایگزین منبع محلی شود.
- قاب‌های سه‌لایه تو‌در‌تو از سیستم UI مرکزی حذف شدند.
- پنل‌ها و دکمه‌ها اکنون یک سطح اصلی با عمق پایین و حالت Press واقعی دارند.
- کارت‌های لابی، دکمه برگشت و Bottom Navigation بازخورد فشاری، صدا و Haptic دارند.
- موتور Gameplay و قوانین بازی تغییر نکرده‌اند.
- Workflow، Package ID و Release Signing را قبل از تحویل APK کنترل می‌کند.
- Release Keystore ثابت ارائه‌شده توسط مالک پروژه در پوشه `release/` قرار دارد.

## ساخت محلی

```bash
flutter pub get
bash tool/materialize_project.sh
flutter analyze
flutter test
flutter build apk --release
```

اسکریپت `materialize_project.sh` پوشه Android را با Package ID صحیح می‌سازد و `tool/prepare_android.py` Release Signing را اعمال می‌کند.

## GitHub Actions

Workflow اصلی:

`.github/workflows/ZARBU_BUILD_LATEST_ZIP_AUTO_FIXED_V4.yml`

Workflow پس از Analyze و Test، APK Release را می‌سازد، Package ID `mk.kadkhodai.zarbu` را Verify می‌کند و اعتبار امضای APK را بررسی می‌کند.
