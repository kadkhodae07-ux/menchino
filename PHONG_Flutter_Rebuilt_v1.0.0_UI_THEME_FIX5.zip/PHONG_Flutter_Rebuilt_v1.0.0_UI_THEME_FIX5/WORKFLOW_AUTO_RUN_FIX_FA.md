# Workflow اجرای خودکار PHONG

فایل فعال Workflow:

`.github/workflows/PHONG_BUILD_LATEST_ZIP_AUTO_FIXED.yml`

رفتار:

- با Push هر فایل ZIP در هر شاخه‌ای که Workflow در همان شاخه وجود داشته باشد، اجرا می‌شود.
- با تغییر فایل‌های `.github/workflows` نیز اجرا می‌شود.
- اجرای دستی از تب Actions فعال است.
- Push جدید اجرای فعال را لغو نمی‌کند و اجرای بعدی در صف قرار می‌گیرد.
- پس از Build موفق، فقط Artifact فعلی APK نگه داشته می‌شود.
- در صورت خطا، بسته `PHONG-build-error-logs` آپلود می‌شود.

نکته مهم: Workflow باید به‌صورت فایل واقعی در مسیر `.github/workflows/` ریپو Commit شود. وجود آن فقط داخل ZIP باعث شناسایی توسط GitHub Actions نمی‌شود.
