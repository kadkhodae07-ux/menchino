import 'package:flutter/material.dart';

class GameTheme {
  final String id;
  final String label;
  final Brightness brightness;
  final Color bg;
  final Color panel;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color danger;
  final Color gold;
  final Color text;
  final Color dim;
  final Color canvasBg;
  final Color grid;
  final Color center;
  final Color top;
  final Color bottom;
  final Color ball;
  final Color trail;

  const GameTheme({
    required this.id,
    required this.label,
    required this.brightness,
    required this.bg,
    required this.panel,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.danger,
    required this.gold,
    required this.text,
    required this.dim,
    required this.canvasBg,
    required this.grid,
    required this.center,
    required this.top,
    required this.bottom,
    required this.ball,
    required this.trail,
  });
}

class Themes {
  static const dark = GameTheme(
    id: 'dark',
    label: 'نئون شب',
    brightness: Brightness.dark,
    bg: Color(0xFF040815),
    panel: Color(0xF0121A30),
    primary: Color(0xFF2CD7FF),
    secondary: Color(0xFF7B6DFF),
    accent: Color(0xFF11F0C6),
    danger: Color(0xFFFF4C95),
    gold: Color(0xFFFFD76E),
    text: Color(0xFFF4F8FF),
    dim: Color(0xFFA4B1CF),
    canvasBg: Color(0xFF030714),
    grid: Color(0x1233CFFF),
    center: Color(0xFF38E5FF),
    top: Color(0xFF8C7CFF),
    bottom: Color(0xFF00F0C8),
    ball: Color(0xFFF7FBFF),
    trail: Color(0xFF48DFFF),
  );

  static const light = GameTheme(
    id: 'light',
    label: 'کریستال',
    brightness: Brightness.light,
    bg: Color(0xFFF4F8FF),
    panel: Color(0xF8FFFFFF),
    primary: Color(0xFF2563EB),
    secondary: Color(0xFF7C3AED),
    accent: Color(0xFF059669),
    danger: Color(0xFFDB2777),
    gold: Color(0xFFD97706),
    text: Color(0xFF111827),
    dim: Color(0xFF5B6B84),
    canvasBg: Color(0xFFEAF1FF),
    grid: Color(0x122563EB),
    center: Color(0xFF2563EB),
    top: Color(0xFF7C3AED),
    bottom: Color(0xFF059669),
    ball: Color(0xFF122034),
    trail: Color(0xFF2563EB),
  );

  static const girly = GameTheme(
    id: 'girly',
    label: 'بلوسوم',
    brightness: Brightness.dark,
    bg: Color(0xFF150814),
    panel: Color(0xF1260E27),
    primary: Color(0xFFFF7BC6),
    secondary: Color(0xFFC58BFF),
    accent: Color(0xFFFFC2E7),
    danger: Color(0xFFFF4B84),
    gold: Color(0xFFFFD67A),
    text: Color(0xFFFFF3FA),
    dim: Color(0xFFE5A9CE),
    canvasBg: Color(0xFF170716),
    grid: Color(0x12FF7BC6),
    center: Color(0xFFFF92DA),
    top: Color(0xFFD597FF),
    bottom: Color(0xFFFFB9E3),
    ball: Color(0xFFFFF4FB),
    trail: Color(0xFFFF7BC6),
  );

  static const boyish = GameTheme(
    id: 'boyish',
    label: 'سایبر اسپرت',
    brightness: Brightness.dark,
    bg: Color(0xFF061017),
    panel: Color(0xF00D1D28),
    primary: Color(0xFF31C8FF),
    secondary: Color(0xFF21D68A),
    accent: Color(0xFFA8F24B),
    danger: Color(0xFFFF874D),
    gold: Color(0xFFFAD95A),
    text: Color(0xFFF0FBFF),
    dim: Color(0xFF94AEBB),
    canvasBg: Color(0xFF041018),
    grid: Color(0x1131C8FF),
    center: Color(0xFF34D3FF),
    top: Color(0xFF25D48C),
    bottom: Color(0xFFA6F04A),
    ball: Color(0xFFF2FBFF),
    trail: Color(0xFF31C8FF),
  );

  static const child = GameTheme(
    id: 'child',
    label: 'فان پاپ',
    brightness: Brightness.light,
    bg: Color(0xFFFFF8EA),
    panel: Color(0xF9FFFFFF),
    primary: Color(0xFFFF8A00),
    secondary: Color(0xFF7C5CFF),
    accent: Color(0xFF00B8A9),
    danger: Color(0xFFFF5A7A),
    gold: Color(0xFFFFC93C),
    text: Color(0xFF35255D),
    dim: Color(0xFF72639D),
    canvasBg: Color(0xFFFFF3DA),
    grid: Color(0x12FF8A00),
    center: Color(0xFFFF9500),
    top: Color(0xFF7C5CFF),
    bottom: Color(0xFF00B8A9),
    ball: Color(0xFF35255D),
    trail: Color(0xFFFF8A00),
  );

  static const all = [dark, light, girly, boyish, child];

  static GameTheme byId(String? id) =>
      all.firstWhere((theme) => theme.id == id, orElse: () => dark);
}
