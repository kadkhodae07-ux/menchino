import 'package:flutter/material.dart';

class Item {
  final String id;
  final String type;
  final String name;
  final String rarity;
  final String icon;
  final String desc;
  final int price;
  final Map<String, double> stats;
  final Color? color;
  final Color? trailColor;

  const Item(
    this.id,
    this.type,
    this.name,
    this.rarity,
    this.icon,
    this.desc,
    this.price, [
    this.stats = const {},
    this.color,
    this.trailColor,
  ]);
}

class Catalog {
  static const rackets = [
    Item('r_default', 'racket', 'راکت کلاسیک', 'common', 'racket', 'راکت متعادل برای شروع.', 0),
    Item('r_long', 'racket', 'راکت بلند', 'rare', 'racketLong', 'سطح دفاعی بزرگ‌تر برای کنترل بیشتر.', 250, {'widthMult': 1.28, 'spinMult': .9, 'moveSpeedMult': .94}),
    Item('r_spin', 'racket', 'راکت اسپین', 'epic', 'racketSpin', 'زاویه‌ها و اسپین‌های قوی‌تر.', 420, {'widthMult': .92, 'spinMult': 1.75}),
    Item('r_turbo', 'racket', 'راکت توربو', 'legendary', 'racketTurbo', 'هر ضربه توپ را سریع‌تر می‌کند.', 650, {'widthMult': .96, 'spinMult': 1.1, 'hitSpeed': 35}),
    Item('r_phantom', 'racket', 'راکت فانتوم', 'epic', 'racket', 'کوچک‌تر، اما بسیار سریع.', 540, {'widthMult': .82, 'spinMult': 1.05, 'moveSpeedMult': 1.35}),
    Item('r_guardian', 'racket', 'راکت محافظ', 'rare', 'shield', 'در ابتدای هر مسابقه یک سپر داری.', 380, {'widthMult': 1.02, 'spinMult': .95, 'moveSpeedMult': .98, 'startShield': 1}),
    Item('r_magnet', 'racket', 'راکت مگنت', 'legendary', 'power', 'توپ‌های نزدیک را کمی به سمت راکت می‌کشد.', 760, {'widthMult': .96, 'magnet': .8}),
    Item('r_echo', 'racket', 'راکت اکو', 'epic', 'restart', 'شانس کُند شدن توپ بعد از ضربه تو.', 600, {'widthMult': .98, 'spinMult': 1.15, 'echoSlow': .18}),
  ];

  static const balls = [
    Item('b_default', 'ball', 'توپ نئونی', 'common', 'ball', 'توپ استاندارد مسابقه.', 0, {}, Color(0xFFE8F2FF), Color(0xFF2DE2FF)),
    Item('b_comet', 'ball', 'توپ دنباله‌دار', 'rare', 'ball', 'سریع‌تر با رد درخشان‌تر.', 220, {'speedMult': 1.08, 'radiusMult': .95, 'powerRate': 1.15}, Color(0xFF8DF6FF), Color(0xFF2DE2FF)),
    Item('b_heavy', 'ball', 'توپ سنگین', 'rare', 'ball', 'کنترل آسان‌تر و رشد سرعت کمتر.', 260, {'speedMult': .92, 'radiusMult': 1.18, 'powerRate': .9, 'speedIncrementMult': .85, 'minVerticalBonus': .08}, Color(0xFFFFD28D), Color(0xFFFF9D5C)),
    Item('b_plasma', 'ball', 'توپ پلاسما', 'legendary', 'ball', 'سرعت بالا و پاورآپ بیشتر.', 700, {'speedMult': 1.16, 'radiusMult': .9, 'powerRate': 1.35, 'speedIncrementMult': 1.1}, Color(0xFFFF7AD9), Color(0xFFFF3B8D)),
    Item('b_ghost', 'ball', 'توپ شبح', 'epic', 'ball', 'حرکت تو برای حریف سخت‌تر خوانده می‌شود.', 580, {'speedMult': 1.03, 'radiusMult': .98, 'aiErrorBonus': 26}, Color(0xFFC9D7F0), Color(0xFF8A5CFF)),
    Item('b_gold', 'ball', 'توپ طلایی', 'epic', 'coin', 'سکه بیشتر در پایان مسابقه.', 620, {'coinBonus': .25}, Color(0xFFFFD54D), Color(0xFFFFD54D)),
    Item('b_moon', 'ball', 'توپ ماه', 'rare', 'ball', 'سرعت توپ آرام‌تر رشد می‌کند.', 340, {'speedMult': .98, 'radiusMult': 1.05, 'speedIncrementMult': .65, 'minVerticalBonus': .04}, Color(0xFFBFD9FF), Color(0xFF7DE3FF)),
    Item('b_rubber', 'ball', 'توپ لاستیکی', 'legendary', 'ball', 'مسیر کمی خمیده و غیرقابل پیش‌بینی.', 760, {'speedMult': 1.02, 'powerRate': 1.1, 'curve': 22}, Color(0xFF7DFFB2), Color(0xFF00FFC6)),
  ];

  static const arenas = [
    Item('a_default', 'arena', 'آرنای سایبر', 'common', 'arena', 'زمین استاندارد PHONG.', 0),
    Item('a_speed', 'arena', 'آرنای توربو', 'epic', 'fast', 'سرعت پایه بالاتر برای حرفه‌ای‌ها.', 520, {'baseSpeedMult': 1.12, 'maxSpeedMult': 1.1, 'powerRate': .9}),
    Item('a_control', 'arena', 'آرنای کنترل', 'rare', 'shield', 'سرعت محدودتر برای تمرکز روی کنترل.', 320, {'baseSpeedMult': .94, 'maxSpeedMult': .95, 'powerRate': 1.1}),
    Item('a_void', 'arena', 'آرنای ووید', 'legendary', 'power', 'پاورآپ بیشتر و سرعت زیاد.', 800, {'baseSpeedMult': 1.06, 'maxSpeedMult': 1.12, 'powerRate': 1.45}),
    Item('a_narrow', 'arena', 'آرنای باریک', 'epic', 'shrink', 'دیواره‌های نزدیک‌تر؛ مسابقه فشرده‌تر.', 560, {'baseSpeedMult': 1.02, 'maxSpeedMult': 1.05, 'sideInset': 36}),
    Item('a_fortune', 'arena', 'آرنای ثروت', 'epic', 'coin', 'سکه بیشتر در پایان مسابقه.', 640, {'coinBonus': .2}),
    Item('a_time', 'arena', 'آرنای زمان', 'legendary', 'timer', 'پاورآپ‌ها مدت بیشتری فعال می‌مانند.', 780, {'maxSpeedMult': .98, 'powerRate': 1.15, 'powerDurationMult': 1.4}),
    Item('a_mirror', 'arena', 'آرنای آینه', 'rare', 'arena', 'حرکت هوش مصنوعی کمی کندتر می‌شود.', 420, {'aiSpeedMult': .88}),
  ];

  static final List<Item> all = [...rackets, ...balls, ...arenas];

  static Item byId(String? id) => all.firstWhere((item) => item.id == id, orElse: () => rackets.first);

  static List<Item> of(String tab) {
    switch (tab) {
      case 'rackets': return rackets;
      case 'balls': return balls;
      case 'arenas': return arenas;
      default: return rackets;
    }
  }
}

class Tournament {
  final String id;
  final String name;
  final String icon;
  final String desc;
  final String difficulty;
  final int entry;
  final int prize;
  final int rounds;

  const Tournament(this.id, this.name, this.icon, this.desc, this.difficulty, this.entry, this.prize, this.rounds);
}

const tournaments = [
  Tournament('neon', 'جام نئونی', 'power', 'دو مسابقه کوتاه برای شروع.', 'medium', 20, 90, 2),
  Tournament('daily', 'جام روزانه', 'rank', 'سه مسابقه متوالی با حریف‌های سخت.', 'hard', 50, 250, 3),
  Tournament('weekly', 'جام قهرمانی', 'crown', 'چهار مسابقه حرفه‌ای برای قهرمانان.', 'pro', 100, 600, 4),
];

class Mission {
  final String id;
  final String title;
  final String key;
  final int target;
  final Map<String, dynamic> reward;

  const Mission(this.id, this.title, this.key, this.target, this.reward);
}

const missions = [
  Mission('play3', '۳ مسابقه انجام بده', 'play', 3, {'coins': 50}),
  Mission('win2', '۲ مسابقه ببر', 'win', 2, {'chest': 'bronze'}),
  Mission('rally10', 'یک رالی ۱۰ ضربه‌ای بساز', 'rally10', 1, {'coins': 80}),
  Mission('power3', '۳ پاورآپ جمع کن', 'power', 3, {'gems': 2}),
  Mission('hardWin', 'یک برد روی سخت', 'hardWin', 1, {'chest': 'silver'}),
  Mission('chestOpen', 'یک صندوق باز کن', 'chest', 1, {'coins': 60}),
];

const rarityColor = {
  'common': Color(0xFFB7C8E8),
  'rare': Color(0xFF2DE2FF),
  'epic': Color(0xFFB491FF),
  'legendary': Color(0xFFFFD54D),
};

const rarityLabel = {
  'common': 'معمولی',
  'rare': 'کمیاب',
  'epic': 'حماسی',
  'legendary': 'افسانه‌ای',
};

const avatars = [
  [Color(0xFF2DE2FF), Color(0xFF8A5CFF)],
  [Color(0xFF00FFC6), Color(0xFF2DE2FF)],
  [Color(0xFF8A5CFF), Color(0xFFFF3B8D)],
  [Color(0xFFFFD54D), Color(0xFFFF3B8D)],
];
