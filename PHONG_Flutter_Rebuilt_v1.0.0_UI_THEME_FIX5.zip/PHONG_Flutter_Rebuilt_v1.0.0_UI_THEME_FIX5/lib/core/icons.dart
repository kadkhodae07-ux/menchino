import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AppIcons {
  static const Map<String, String> _paths = {
    'back': '<path d="M14.5 5.5 8 12l6.5 6.5"/>',
    'home': '<path d="M4 10.5 12 4l8 6.5V20h-5.5v-5h-5v5H4z"/>',
    'play': '<path d="M8 5.5v13l10-6.5z"/>',
    'practice': '<circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/>',
    'friends': '<circle cx="9" cy="9" r="3.1"/><path d="M3.5 19c.6-3 2.8-4.7 5.5-4.7s4.9 1.7 5.5 4.7"/><circle cx="16.8" cy="8.2" r="2.4"/><path d="M15.3 13.2c2.7.1 4.6 1.5 5.2 4.2"/>',
    'rank': '<path d="M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4.5a3 3 0 0 0 3.2 3.8M17 6h2.5a3 3 0 0 1-3.2 3.8"/><path d="M12 14v3M8.5 20h7M10 17h4"/>',
    'chest': '<rect x="4" y="9" width="16" height="10" rx="2"/><path d="M4 12h16"/><path d="M12 10.5V13"/><path d="M6.5 9c0-2.5 2.2-4.5 5.5-4.5s5.5 2 5.5 4.5"/>',
    'mission': '<path d="M6 21V4"/><path d="M6 4h11l-2.5 3.5L17 11H6"/>',
    'chat': '<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v7a2.5 2.5 0 0 1-2.5 2.5H9l-4 3.5v-3.5H6.5A2.5 2.5 0 0 1 4 13.5z"/><path d="M8 9h8M8 12h5"/>',
    'profile': '<circle cx="12" cy="8.5" r="3.5"/><path d="M4.5 20c.8-3.7 3.7-5.8 7.5-5.8s6.7 2.1 7.5 5.8"/>',
    'settings': '<circle cx="12" cy="12" r="2.8"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4 18 18M18 6l-1.6 1.6M7.6 16.4 6 18"/>',
    'shop': '<path d="M5 8h14l-1 12H6z"/><path d="M8.5 8a3.5 3.5 0 0 1 7 0"/>',
    'racket': '<ellipse cx="11" cy="8.5" rx="5.5" ry="4.2"/><path d="M14.8 11.8 19 16M8 8.5h6M11 5.5v6"/>',
    'racketLong': '<rect x="8" y="3.5" width="8" height="9" rx="4"/><path d="M12 12.5V20"/>',
    'racketSpin': '<circle cx="12" cy="9" r="4.5"/><path d="M7.5 9a4.5 4.5 0 0 0 9 0"/><path d="M12 13.5V20"/>',
    'racketTurbo': '<ellipse cx="11" cy="8.5" rx="5.5" ry="4.2"/><path d="M14.8 11.8 19 16"/><path d="M10.5 6.5 8 9h3l-2.5 2.5"/>',
    'ball': '<circle cx="12" cy="12" r="7.5"/><path d="M5.5 9.5c3.8 1.8 9.2 1.8 13 0M5.5 14.5c3.8-1.8 9.2-1.8 13 0"/>',
    'arena': '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 12h16M12 4v16"/><path d="M7.5 7.5h.01M16.5 16.5h.01"/>',
    'coin': '<circle cx="12" cy="12" r="7.5"/><path d="M12 7.5v9M9.5 9.5c0-1 1.1-1.7 2.5-1.7s2.5.7 2.5 1.7-1 1.4-2.5 1.8-2.5.8-2.5 1.8 1.1 1.7 2.5 1.7 2.5-.7 2.5-1.7"/>',
    'gem': '<path d="M7 4h10l4 5-9 11L3 9z"/><path d="M3 9h18M12 20 8 9l4-5 4 5z"/>',
    'pause': '<path d="M8.5 5.5v13M15.5 5.5v13"/>',
    'resume': '<path d="M8 5.5v13l10-6.5z"/>',
    'restart': '<path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3"/><path d="M4.5 5.5v4h4"/>',
    'exit': '<path d="M14 5H7a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h7"/><path d="M10 12h9M16 8.5 19.5 12 16 15.5"/>',
    'shield': '<path d="M12 3.5 5.5 6v5c0 4.2 2.7 7.5 6.5 9.5 3.8-2 6.5-5.3 6.5-9.5V6z"/>',
    'big': '<path d="M9 3.5H3.5V9M15 3.5h5.5V9M9 20.5H3.5V15M15 20.5h5.5V15"/>',
    'shrink': '<path d="M3.5 3.5H9v5.5M20.5 3.5H15v5.5M3.5 20.5H9V15M20.5 20.5H15V15"/>',
    'slow': '<circle cx="12" cy="12" r="7.5"/><path d="M12 7.5V12l3 2.5"/>',
    'fast': '<path d="M13 3 5.5 13.5H11L9.5 21 18 10.5h-5.5z"/>',
    'power': '<path d="M12 3.5c2.5 3.2 6 5.2 6 9a6 6 0 0 1-12 0c0-3.8 3.5-5.8 6-9z"/>',
    'send': '<path d="M4 11.5 20 4l-4.5 16-3.8-6.2z"/><path d="M11.7 13.8 20 4"/>',
    'check': '<path d="M5 12.5 10 17.5 19 7"/>',
    'crown': '<path d="M4.5 8.5 8 11l4-5 4 5 3.5-2.5-1.5 9h-12z"/><path d="M7 19h10"/>',
    'timer': '<circle cx="12" cy="13" r="7"/><path d="M12 10v3.5l2.5 2M9.5 4h5"/>',
    'gift': '<rect x="4.5" y="10" width="15" height="10" rx="2"/><path d="M4.5 13h15M12 10v10"/><path d="M12 10s-4.5.5-4.5-2.5C7.5 5.5 10 5 12 7.5c2-2.5 4.5-2 4.5 0 0 3-4.5 2.5-4.5 2.5z"/>',
    'close': '<path d="M6 6l12 12M18 6 6 18"/>',
    'lock': '<rect x="6" y="10.5" width="12" height="9" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
  };

  static Widget icon(String name, {double size = 20, Color color = Colors.white}) {
    final inner = _paths[name] ?? _paths['power']!;
    final svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
        'stroke="${_hex(color)}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">$inner</svg>';
    return SvgPicture.string(svg, width: size, height: size);
  }

  static String _hex(Color color) =>
      '#${(color.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';
}
