import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../core/data.dart';
import '../core/state/app_state.dart';

class Powerup {
  final String type;
  final double x;
  final double y;
  final double expire;

  const Powerup(this.type, this.x, this.y, this.expire);

  double get radius => 16;
}

class BallState {
  double x = 0;
  double y = 0;
  double vx = 0;
  double vy = 0;
  double radius = 9;
  double speed = 340;
}

class PaddleState {
  double x = 0;
  double y = 0;
  double targetX = 0;
  double width = 110;
  double height = 14;
  double velocity = 0;
}

const powerNames = {
  'big': 'راکت بزرگ',
  'shrink': 'کوچک‌سازی حریف',
  'slow': 'توپ آهسته',
  'fast': 'توپ سریع',
  'shield': 'سپر دفاعی',
  'gold': 'سکه طلایی',
};

class Engine extends ChangeNotifier {
  final AppState state;
  final String mode;
  final String difficulty;
  final String orientation;
  final int entry;
  final bool twoPlayer;
  final String? friendName;
  final Tournament? tournament;
  final int tournamentRound;

  Engine({
    required this.state,
    required this.mode,
    required this.difficulty,
    required this.orientation,
    required this.entry,
    this.twoPlayer = false,
    this.friendName,
    this.tournament,
    this.tournamentRound = 0,
  });

  final Random random = Random();
  final BallState ball = BallState();
  final PaddleState bottom = PaddleState();
  final PaddleState top = PaddleState();
  final List<OffsetPoint> trail = [];
  final List<Powerup> powerups = [];

  bool started = false;
  bool paused = false;
  bool finished = false;
  String phase = 'idle';
  double phaseTimer = 0;
  int countdown = 3;
  double elapsed = 0;
  int bottomScore = 0;
  int topScore = 0;
  int rally = 0;
  int longestRally = 0;
  double hitCooldown = 0;
  double width = 0;
  double height = 0;
  double powerTimer = 6;
  String lastHitter = 'bottom';
  String? lastPowerup;
  double lastPowerupUntil = 0;
  int playerGold = 0;

  final Map<String, Map<String, double>> effects = {
    'bottom': {'big': 0, 'small': 0, 'shield': 0},
    'top': {'big': 0, 'small': 0, 'shield': 0},
  };
  final Map<String, double> ai = {'timer': 0, 'targetX': 0};

  bool get isLandscape => orientation == 'landscape';

  double get baseSpeed => 340 * (state.ball.stats['speedMult'] ?? 1) * (state.arena.stats['baseSpeedMult'] ?? 1);
  double get maxSpeed => (860 * (state.arena.stats['maxSpeedMult'] ?? 1) * max(1, (state.ball.stats['speedMult'] ?? 1) * .8)).toDouble();
  double get sideInset => state.arena.stats['sideInset'] ?? 0;
  double get paddleBase => 110 * (state.racket.stats['widthMult'] ?? 1);
  double get paddleOffset => isLandscape ? 82 : 86;
  double get coinBonus => (state.ball.stats['coinBonus'] ?? 0) + (state.arena.stats['coinBonus'] ?? 0);
  double get minPrimaryRatio => .35 + (state.ball.stats['minVerticalBonus'] ?? 0);
  int get targetScore => mode == 'challenge' || mode == 'tournament' ? 5 : 7;

  void resize(double newWidth, double newHeight) {
    if (newWidth <= 0 || newHeight <= 0) return;
    final oldWidth = width;
    final oldHeight = height;
    final oldPrimarySize = _playSpan;
    width = newWidth;
    height = newHeight;
    ball.radius = (min(width, height) * .0175).clamp(7.0, 11.0).toDouble() * (state.ball.stats['radiusMult'] ?? 1);
    _layoutFixedAxes();

    if (oldWidth <= 0 || oldHeight <= 0 || oldPrimarySize <= 0) {
      _resetPaddlePositions();
      ball.x = width / 2;
      ball.y = height / 2;
    } else {
      final scale = _playSpan / oldPrimarySize;
      bottom.targetX = _clampTarget(bottom.targetX * scale, bottom);
      top.targetX = _clampTarget(top.targetX * scale, top);
      _setMovable(bottom, bottom.targetX);
      _setMovable(top, top.targetX);
      ball.x = (ball.x * (width / oldWidth)).clamp(ball.radius + sideInset, width - ball.radius - sideInset).toDouble();
      ball.y = (ball.y * (height / oldHeight)).clamp(ball.radius + sideInset, height - ball.radius - sideInset).toDouble();
    }
    notifyListeners();
  }

  void _layoutFixedAxes() {
    if (isLandscape) {
      bottom.x = width - paddleOffset;
      top.x = paddleOffset;
      bottom.width = top.width = 16;
      bottom.height = top.height = paddleBase;
    } else {
      bottom.y = height - paddleOffset;
      top.y = paddleOffset;
      bottom.width = top.width = paddleBase;
      bottom.height = top.height = 16;
    }
  }

  void _resetPaddlePositions() {
    if (isLandscape) {
      bottom.y = bottom.targetX = height / 2;
      top.y = top.targetX = height / 2;
    } else {
      bottom.x = bottom.targetX = width / 2;
      top.x = top.targetX = width / 2;
    }
  }

  double get _playSpan => isLandscape ? height : width;

  double _movableOf(PaddleState paddle) => isLandscape ? paddle.y : paddle.x;

  void _setMovable(PaddleState paddle, double value) {
    if (isLandscape) {
      paddle.y = value;
    } else {
      paddle.x = value;
    }
  }

  double _spanOf(PaddleState paddle) => isLandscape ? paddle.height : paddle.width;

  double _clampTarget(double value, PaddleState paddle) {
    return value.clamp(_spanOf(paddle) / 2 + sideInset, _playSpan - sideInset - _spanOf(paddle) / 2).toDouble();
  }

  void start() {
    if (width <= 0 || height <= 0) return;
    started = true;
    finished = false;
    paused = false;
    phase = 'countdown';
    phaseTimer = 3;
    countdown = 3;
    elapsed = 0;
    bottomScore = 0;
    topScore = 0;
    longestRally = 0;
    playerGold = 0;
    powerups.clear();
    lastPowerup = null;
    lastPowerupUntil = 0;
    powerTimer = (5 + random.nextDouble() * 3) / _powerRate;
    effects['bottom'] = {'big': 0, 'small': 0, 'shield': 0};
    effects['top'] = {'big': 0, 'small': 0, 'shield': 0};
    if ((state.racket.stats['startShield'] ?? 0) >= 1) {
      effects['bottom']!['shield'] = 1.0;
    }
    _resetPaddlePositions();
    _serve();
    unawaited(state.audio.play('count'));
    notifyListeners();
  }

  double get _powerRate => (state.ball.stats['powerRate'] ?? 1) * (state.arena.stats['powerRate'] ?? 1);

  void restart() => start();

  void setPaused(bool value) {
    if (!started || finished) return;
    paused = value;
    notifyListeners();
  }

  void abandon() {
    started = false;
    finished = false;
    paused = false;
    phase = 'idle';
    notifyListeners();
  }

  void _serve() {
    ball.x = width / 2;
    ball.y = height / 2;
    ball.speed = baseSpeed;
    final angle = random.nextDouble() * .7 - .35;
    final direction = random.nextBool() ? 1 : -1;
    if (isLandscape) {
      ball.vx = cos(angle) * ball.speed * direction;
      ball.vy = sin(angle) * ball.speed;
    } else {
      ball.vx = sin(angle) * ball.speed;
      ball.vy = cos(angle) * ball.speed * direction;
    }
    hitCooldown = .05;
    trail.clear();
    rally = 0;
  }

  void update(double dt) {
    if (!started || paused || finished || dt <= 0) return;
    final safeDt = dt.clamp(0.0, .033).toDouble();

    if (phase == 'countdown') {
      phaseTimer -= safeDt;
      final value = phaseTimer.ceil();
      if (value != countdown && value > 0) {
        countdown = value;
        unawaited(state.audio.play('count'));
      }
      if (phaseTimer <= 0) {
        phase = 'playing';
        countdown = 0;
        unawaited(state.audio.play('go'));
      }
      notifyListeners();
      return;
    }

    if (phase == 'point') {
      phaseTimer -= safeDt;
      if (phaseTimer <= 0) {
        _serve();
        phase = 'playing';
      }
      notifyListeners();
      return;
    }

    if (phase != 'playing') return;

    elapsed += safeDt;
    if (lastPowerup != null && elapsed >= lastPowerupUntil) lastPowerup = null;
    hitCooldown = max(0, hitCooldown - safeDt).toDouble();
    powerTimer -= safeDt;
    if (powerTimer <= 0) {
      _spawnPowerup();
      powerTimer = (7 + random.nextDouble() * 5) / _powerRate;
    }

    _updatePaddles(safeDt);
    _updateBall(safeDt);
    notifyListeners();
  }

  void _spawnPowerup() {
    if (powerups.length >= 2) return;
    final types = powerNames.keys.toList();
    final minX = isLandscape ? width * .28 : width * .15 + sideInset;
    final maxX = isLandscape ? width * .72 : width * .85 - sideInset;
    final minY = isLandscape ? height * .15 + sideInset : height * .28;
    final maxY = isLandscape ? height * .85 - sideInset : height * .72;
    final x = maxX <= minX ? width / 2 : minX + random.nextDouble() * (maxX - minX);
    final y = maxY <= minY ? height / 2 : minY + random.nextDouble() * (maxY - minY);
    powerups.add(Powerup(types[random.nextInt(types.length)], x, y, elapsed + 7));
  }

  void _updatePaddles(double dt) {
    var bottomSpan = paddleBase;
    var topSpan = paddleBase;
    if (effects['bottom']!['big']! > elapsed) bottomSpan *= 1.35;
    if (effects['bottom']!['small']! > elapsed) bottomSpan *= .72;
    if (effects['top']!['big']! > elapsed) topSpan *= 1.35;
    if (effects['top']!['small']! > elapsed) topSpan *= .72;

    if (isLandscape) {
      bottom.width = top.width = 16;
      bottom.height = bottomSpan.clamp(56.0, height * .55).toDouble();
      top.height = topSpan.clamp(56.0, height * .55).toDouble();
      bottom.x = width - paddleOffset;
      top.x = paddleOffset;
    } else {
      bottom.height = top.height = 16;
      bottom.width = bottomSpan.clamp(56.0, width * .58).toDouble();
      top.width = topSpan.clamp(56.0, width * .58).toDouble();
      bottom.y = height - paddleOffset;
      top.y = paddleOffset;
    }

    if (!twoPlayer) _updateAi(dt);

    final sensitivity = state.sensitivity;
    _move(bottom, bottom.targetX, 950 * sensitivity * (state.racket.stats['moveSpeedMult'] ?? 1), dt);
    final topSpeed = twoPlayer
        ? 950 * sensitivity * (state.racket.stats['moveSpeedMult'] ?? 1)
        : _aiMax * (state.arena.stats['aiSpeedMult'] ?? 1);
    _move(top, top.targetX, topSpeed, dt);

    _setMovable(bottom, _clampTarget(_movableOf(bottom), bottom));
    _setMovable(top, _clampTarget(_movableOf(top), top));
  }

  void _move(PaddleState paddle, double target, double speed, double dt) {
    final old = _movableOf(paddle);
    final distance = target - old;
    final maxMove = speed * dt;
    final next = old + distance.clamp(-maxMove, maxMove).toDouble();
    _setMovable(paddle, next);
    paddle.velocity = dt > 0 ? (_movableOf(paddle) - old) / dt : 0.0;
  }

  double get _aiMax => const {'easy': 260.0, 'medium': 360.0, 'hard': 480.0, 'pro': 620.0}[difficulty] ?? 360.0;
  double get _aiError => (const {'easy': 56.0, 'medium': 34.0, 'hard': 18.0, 'pro': 8.0}[difficulty] ?? 34.0) + (state.ball.stats['aiErrorBonus'] ?? 0);
  double get _aiReaction => const {'easy': .34, 'medium': .22, 'hard': .14, 'pro': .08}[difficulty] ?? .22;

  void _updateAi(double dt) {
    ai['timer'] = ai['timer']! - dt;
    if (ai['timer']! <= 0) {
      ai['timer'] = _aiReaction;
      ai['targetX'] = _predictTopTarget();
    }
    top.targetX = _clampTarget(ai['targetX']!, top);
  }

  double _predictTopTarget() {
    if (!isLandscape) {
      if (ball.vy >= 0) return width / 2;
      if (difficulty == 'easy') return ball.x + (random.nextDouble() * 2 - 1) * _aiError;
      final time = (ball.y - top.y) / -ball.vy;
      var x = ball.x + ball.vx * time;
      x = _fold(x, width);
      if (difficulty == 'pro') x += random.nextBool() ? -18 : 18;
      return x + (random.nextDouble() * 2 - 1) * _aiError;
    }

    if (ball.vx >= 0) return height / 2;
    if (difficulty == 'easy') return ball.y + (random.nextDouble() * 2 - 1) * _aiError;
    final time = (ball.x - top.x) / -ball.vx;
    var y = ball.y + ball.vy * time;
    y = _fold(y, height);
    if (difficulty == 'pro') y += random.nextBool() ? -18 : 18;
    return y + (random.nextDouble() * 2 - 1) * _aiError;
  }

  double _fold(double x, double maxValue) {
    final period = maxValue * 2;
    var value = x % period;
    if (value < 0) value += period;
    if (value > maxValue) value = period - value;
    return value;
  }

  void _updateBall(double dt) {
    final curve = state.ball.stats['curve'] ?? 0;
    if (curve != 0) {
      if (isLandscape) {
        ball.vy += (ball.vx >= 0 ? 1 : -1) * curve * dt;
      } else {
        ball.vx += (ball.vy >= 0 ? 1 : -1) * curve * dt;
      }
    }

    final magnet = state.racket.stats['magnet'] ?? 0;
    if (magnet != 0) {
      if (!isLandscape && ball.vy > 0) {
        final distance = bottom.y - ball.y;
        if (distance > 0 && distance < 220) {
          ball.x += (bottom.x - ball.x) * min(1, magnet * dt).toDouble();
        }
      } else if (isLandscape && ball.vx > 0) {
        final distance = bottom.x - ball.x;
        if (distance > 0 && distance < 220) {
          ball.y += (bottom.y - ball.y) * min(1, magnet * dt).toDouble();
        }
      }
    }

    final speed = hypot;
    final steps = max(1, (speed * dt / (ball.radius * .55)).ceil()).toInt();
    final stepDt = dt / steps;

    for (var i = 0; i < steps; i++) {
      ball.x += ball.vx * stepDt;
      ball.y += ball.vy * stepDt;
      _walls();
      _paddleHit();
      _powerCollision();

      if (!isLandscape) {
        if (ball.y < -ball.radius) {
          if (effects['top']!['shield']! > 0) {
            effects['top']!['shield'] = 0;
            ball.y = top.y + top.height / 2 + ball.radius + 2;
            ball.vy = ball.vy.abs();
            unawaited(state.audio.play('power'));
            return;
          }
          _score(true);
          return;
        }
        if (ball.y > height + ball.radius) {
          if (effects['bottom']!['shield']! > 0) {
            effects['bottom']!['shield'] = 0;
            ball.y = bottom.y - bottom.height / 2 - ball.radius - 2;
            ball.vy = -ball.vy.abs();
            unawaited(state.audio.play('power'));
            return;
          }
          _score(false);
          return;
        }
      } else {
        if (ball.x < -ball.radius) {
          if (effects['top']!['shield']! > 0) {
            effects['top']!['shield'] = 0;
            ball.x = top.x + top.width / 2 + ball.radius + 2;
            ball.vx = ball.vx.abs();
            unawaited(state.audio.play('power'));
            return;
          }
          _score(true);
          return;
        }
        if (ball.x > width + ball.radius) {
          if (effects['bottom']!['shield']! > 0) {
            effects['bottom']!['shield'] = 0;
            ball.x = bottom.x - bottom.width / 2 - ball.radius - 2;
            ball.vx = -ball.vx.abs();
            unawaited(state.audio.play('power'));
            return;
          }
          _score(false);
          return;
        }
      }
    }

    if (state.trail) {
      trail.add(OffsetPoint(ball.x, ball.y));
      final maxTrail = switch (state.quality) {
        'low' => 8,
        'high' => 20,
        _ => 14,
      };
      if (trail.length > maxTrail) trail.removeAt(0);
    }
  }

  double get hypot => sqrt(ball.vx * ball.vx + ball.vy * ball.vy);

  void _walls() {
    if (!isLandscape) {
      if (ball.x - ball.radius <= sideInset) {
        ball.x = sideInset + ball.radius;
        ball.vx = ball.vx.abs();
        unawaited(state.audio.play('wall'));
      } else if (ball.x + ball.radius >= width - sideInset) {
        ball.x = width - sideInset - ball.radius;
        ball.vx = -ball.vx.abs();
        unawaited(state.audio.play('wall'));
      }
      return;
    }

    if (ball.y - ball.radius <= sideInset) {
      ball.y = sideInset + ball.radius;
      ball.vy = ball.vy.abs();
      unawaited(state.audio.play('wall'));
    } else if (ball.y + ball.radius >= height - sideInset) {
      ball.y = height - sideInset - ball.radius;
      ball.vy = -ball.vy.abs();
      unawaited(state.audio.play('wall'));
    }
  }

  void _paddleHit() {
    if (hitCooldown > 0) return;
    if (!isLandscape) {
      if (ball.vy > 0 && _over(bottom)) {
        _bounce(bottom, false);
      } else if (ball.vy < 0 && _over(top)) {
        _bounce(top, true);
      }
      return;
    }

    if (ball.vx > 0 && _over(bottom)) {
      _bounce(bottom, false);
    } else if (ball.vx < 0 && _over(top)) {
      _bounce(top, true);
    }
  }

  bool _over(PaddleState paddle) {
    if (!isLandscape) {
      return ball.y + ball.radius >= paddle.y - paddle.height / 2 &&
          ball.y - ball.radius <= paddle.y + paddle.height / 2 &&
          (ball.x - paddle.x).abs() <= paddle.width / 2 + ball.radius;
    }
    return ball.x + ball.radius >= paddle.x - paddle.width / 2 &&
        ball.x - ball.radius <= paddle.x + paddle.width / 2 &&
        (ball.y - paddle.y).abs() <= paddle.height / 2 + ball.radius;
  }

  void _bounce(PaddleState paddle, bool isTop) {
    final increment = 14 * (state.ball.stats['speedIncrementMult'] ?? 1) + (state.racket.stats['hitSpeed'] ?? 0) * .25;
    ball.speed = min(ball.speed + increment, maxSpeed).toDouble();

    if (!isLandscape) {
      final relative = ((ball.x - paddle.x) / (paddle.width / 2)).clamp(-1.0, 1.0).toDouble();
      final angle = relative * 1.05;
      final spin = (paddle.velocity * .22 * (state.racket.stats['spinMult'] ?? 1)).clamp(-160.0, 160.0).toDouble();
      var vx = sin(angle) * ball.speed + spin;
      var vy = cos(angle) * ball.speed;
      final minVy = ball.speed * minPrimaryRatio;
      if (vy.abs() < minVy) vy = minVy;
      vy = vy.abs() * (isTop ? 1 : -1);
      final length = sqrt(vx * vx + vy * vy);
      final scale = ball.speed / max(length, .001).toDouble();
      ball.vx = vx * scale;
      ball.vy = vy * scale;
      ball.y = isTop
          ? paddle.y + paddle.height / 2 + ball.radius + 1
          : paddle.y - paddle.height / 2 - ball.radius - 1;
    } else {
      final relative = ((ball.y - paddle.y) / (paddle.height / 2)).clamp(-1.0, 1.0).toDouble();
      final angle = relative * 1.05;
      final spin = (paddle.velocity * .22 * (state.racket.stats['spinMult'] ?? 1)).clamp(-160.0, 160.0).toDouble();
      var vx = cos(angle) * ball.speed;
      var vy = sin(angle) * ball.speed + spin;
      final minVx = ball.speed * minPrimaryRatio;
      if (vx.abs() < minVx) vx = minVx;
      vx = vx.abs() * (isTop ? 1 : -1);
      final length = sqrt(vx * vx + vy * vy);
      final scale = ball.speed / max(length, .001).toDouble();
      ball.vx = vx * scale;
      ball.vy = vy * scale;
      ball.x = isTop
          ? paddle.x + paddle.width / 2 + ball.radius + 1
          : paddle.x - paddle.width / 2 - ball.radius - 1;
    }

    hitCooldown = .05;
    rally++;
    longestRally = max(longestRally, rally).toInt();
    lastHitter = isTop ? 'top' : 'bottom';

    final echoChance = state.racket.stats['echoSlow'] ?? 0;
    if (!isTop && echoChance > 0 && random.nextDouble() < echoChance) {
      _scaleBall(.85);
      lastPowerup = 'اکو فعال شد';
      lastPowerupUntil = elapsed + 1.5;
    }

    unawaited(state.audio.play('hit'));
    if (state.haptics && !isTop) unawaited(HapticFeedback.lightImpact());
  }

  void _powerCollision() {
    powerups.removeWhere((powerup) {
      if (powerup.expire < elapsed) return true;
      final distance = sqrt(pow(ball.x - powerup.x, 2) + pow(ball.y - powerup.y, 2));
      if (distance < powerup.radius + ball.radius) {
        _applyPowerup(powerup.type);
        return true;
      }
      return false;
    });
  }

  void _applyPowerup(String type) {
    final side = lastHitter;
    final opponent = side == 'bottom' ? 'top' : 'bottom';
    final duration = (type == 'big' || type == 'shrink' ? 6.0 : 0.0) * (state.arena.stats['powerDurationMult'] ?? 1);
    if (type == 'big') effects[side]!['big'] = elapsed + duration;
    if (type == 'shrink') effects[opponent]!['small'] = elapsed + duration;
    if (type == 'slow') _scaleBall(.78);
    if (type == 'fast') _scaleBall(1.24);
    if (type == 'shield') effects[side]!['shield'] = 1.0;
    if (type == 'gold' && side == 'bottom') playerGold += 5;
    lastPowerup = powerNames[type];
    lastPowerupUntil = elapsed + 1.5;

    if (side == 'bottom') {
      state.stats['powerCollected'] = (state.stats['powerCollected'] ?? 0) + 1;
      state.incMission('power');
      unawaited(state.save(notify: false));
    }
    unawaited(state.audio.play('power'));
    if (state.haptics && side == 'bottom') unawaited(HapticFeedback.mediumImpact());
  }

  void _scaleBall(double factor) {
    final current = max(hypot, .001).toDouble();
    final target = (current * factor).clamp(170.0, maxSpeed).toDouble();
    final scale = target / current;
    ball.vx *= scale;
    ball.vy *= scale;
    ball.speed = target;
  }

  void _score(bool bottomScores) {
    if (bottomScores) {
      bottomScore++;
    } else {
      topScore++;
    }
    unawaited(state.audio.play('score'));
    if (state.haptics) unawaited(HapticFeedback.mediumImpact());
    trail.clear();
    rally = 0;

    if (_isMatchOver) {
      finish();
      return;
    }
    phase = 'point';
    phaseTimer = .8;
  }

  bool get _isMatchOver {
    if (mode == 'practice') return false;
    return bottomScore >= targetScore || topScore >= targetScore;
  }

  void finish() {
    started = false;
    finished = true;
    paused = false;
    phase = 'idle';
    notifyListeners();
  }

  void setTarget(String owner, double value) {
    final paddle = owner == 'bottom' ? bottom : top;
    paddle.targetX = _clampTarget(value, paddle);
  }
}

class OffsetPoint {
  final double x;
  final double y;

  const OffsetPoint(this.x, this.y);
}
