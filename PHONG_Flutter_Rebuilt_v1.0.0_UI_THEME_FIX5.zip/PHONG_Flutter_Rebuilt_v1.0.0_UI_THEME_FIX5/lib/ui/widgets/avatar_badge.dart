import 'package:flutter/material.dart';

import '../../core/data.dart';
import '../../core/icons.dart';

class AvatarBadge extends StatelessWidget {
  final int index;
  final double size;
  final bool selected;
  final VoidCallback? onTap;

  const AvatarBadge({
    super.key,
    required this.index,
    this.size = 52,
    this.selected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final colors = avatars[index.clamp(0, avatars.length - 1).toInt()];
    final badge = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * .32),
        gradient: LinearGradient(colors: colors),
        border: Border.all(color: selected ? Colors.white : Colors.transparent, width: 2),
        boxShadow: [
          BoxShadow(color: colors.first.withOpacity(.30), blurRadius: selected ? 20 : 12),
          BoxShadow(color: Colors.black.withOpacity(.30), offset: const Offset(0, 8), blurRadius: 16),
        ],
      ),
      child: Center(child: AppIcons.icon('profile', size: size * .44, color: Colors.white)),
    );
    if (onTap == null) return badge;
    return GestureDetector(onTap: onTap, child: badge);
  }
}
