import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class RewardsScreen extends StatefulWidget {
  const RewardsScreen({super.key});

  @override
  State<RewardsScreen> createState() => _RewardsScreenState();
}

class _RewardsScreenState extends State<RewardsScreen> {
  final Random _random = Random();
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    return SafeArea(
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 22),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: Text('جوایز و مأموریت‌ها', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 22))),
                Chip3D(text: '${state.coins}'),
                const SizedBox(width: 6),
                Chip3D(text: '${state.gems}', gem: true),
              ],
            ),
            const SizedBox(height: 12),
            for (final tier in const ['bronze', 'silver', 'gold']) ...[
              NeonPanel(
                borderColor: _chestColor(tier),
                child: Row(
                  children: [
                    AppIcons.icon('chest', size: 32, color: _chestColor(tier)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_chestName(tier), style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                          Text('تعداد: ${state.chests[tier] ?? 0}', style: TextStyle(color: theme.dim, fontSize: 13)),
                        ],
                      ),
                    ),
                    NeonButton(
                      label: 'باز کردن',
                      small: true,
                      color: theme.gold,
                      onTap: !_busy && (state.chests[tier] ?? 0) > 0 ? () => _openChest(state, tier) : null,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ],
            Align(
              alignment: Alignment.centerRight,
              child: Text('مأموریت‌ها', style: TextStyle(color: theme.text, fontSize: 19, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 10),
            for (final mission in missions) ...[
              Builder(builder: (context) {
                final progress = state.missionProgress[mission.key] ?? 0;
                final done = progress >= mission.target;
                final claimed = state.claimed[mission.id] == true;
                return NeonPanel(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          AppIcons.icon('mission', size: 27, color: theme.primary),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(mission.title, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 3),
                                Text(_rewardText(mission), style: TextStyle(color: theme.dim, fontSize: 12)),
                              ],
                            ),
                          ),
                          if (claimed)
                            AppIcons.icon('check', color: theme.accent)
                          else
                            NeonButton(
                              label: done ? 'گرفتن' : 'قفل',
                              icon: done ? 'gift' : 'lock',
                              small: true,
                              onTap: done ? () => _claim(state, mission) : null,
                            ),
                        ],
                      ),
                      const SizedBox(height: 9),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: LinearProgressIndicator(
                          minHeight: 9,
                          value: (progress / mission.target).clamp(0.0, 1.0).toDouble(),
                          color: theme.accent,
                          backgroundColor: theme.accent.withOpacity(.14),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text('${min(progress, mission.target)} / ${mission.target}', style: TextStyle(color: theme.dim, fontSize: 11)),
                      ),
                    ],
                  ),
                );
              }),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _openChest(AppState state, String tier) async {
    if (_busy || (state.chests[tier] ?? 0) <= 0) return;
    setState(() => _busy = true);
    state.chests[tier] = (state.chests[tier] ?? 0) - 1;
    final rewards = <String>[];
    final ranges = switch (tier) {
      'silver' => (80, 160, 1, 3, .25, const ['rare', 'epic']),
      'gold' => (150, 300, 3, 6, .45, const ['epic', 'legendary']),
      _ => (30, 80, 0, 1, .10, const ['common', 'rare']),
    };
    final coins = ranges.$1 + _random.nextInt(ranges.$2 - ranges.$1 + 1);
    final gems = ranges.$3 == 0 ? (_random.nextDouble() < .25 ? 1 : 0) : ranges.$3 + _random.nextInt(ranges.$4 - ranges.$3 + 1);
    state.addCoins(coins);
    state.addGems(gems);
    rewards.add('+$coins سکه');
    if (gems > 0) rewards.add('+$gems الماس');

    if (_random.nextDouble() < ranges.$5) {
      final pool = Catalog.all.where((item) => ranges.$6.contains(item.rarity)).toList();
      final item = pool[_random.nextInt(pool.length)];
      if (state.owned.contains(item.id)) {
        state.addCoins(40);
        rewards.add('آیتم تکراری: +۴۰ سکه');
      } else {
        state.owned.add(item.id);
        rewards.add('آیتم جدید: ${item.name}');
      }
    }
    state.incMission('chest');
    await state.audio.play('coin');
    await state.save();
    if (!mounted) return;
    setState(() => _busy = false);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: state.theme.panel,
        title: Row(children: [AppIcons.icon('chest', size: 30, color: state.theme.gold), const SizedBox(width: 10), Text('صندوق باز شد', style: TextStyle(color: state.theme.text, fontWeight: FontWeight.w900))]),
        content: Column(mainAxisSize: MainAxisSize.min, children: rewards.map((reward) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: StatBadge(reward, color: state.theme.gold))).toList()),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('بستن'))],
      ),
    );
  }

  Future<void> _claim(AppState state, Mission mission) async {
    if (state.claimed[mission.id] == true || (state.missionProgress[mission.key] ?? 0) < mission.target) return;
    state.claimed[mission.id] = true;
    final coins = mission.reward['coins'];
    final gems = mission.reward['gems'];
    final chest = mission.reward['chest'];
    if (coins is int) state.addCoins(coins);
    if (gems is int) state.addGems(gems);
    if (chest is String) state.chests[chest] = (state.chests[chest] ?? 0) + 1;
    await state.audio.play('coin');
    await state.save();
    if (mounted) showNeonMessage(context, 'جایزه مأموریت دریافت شد.');
  }

  String _rewardText(Mission mission) {
    final parts = <String>[];
    if (mission.reward['coins'] is int) parts.add('+${mission.reward['coins']} سکه');
    if (mission.reward['gems'] is int) parts.add('+${mission.reward['gems']} الماس');
    if (mission.reward['chest'] is String) parts.add('+ صندوق ${mission.reward['chest'] == 'bronze' ? 'برنزی' : 'نقره‌ای'}');
    return parts.join(' | ');
  }

  Color _chestColor(String tier) => switch (tier) {
        'silver' => const Color(0xFFC9D7F0),
        'gold' => const Color(0xFFFFD54D),
        _ => const Color(0xFFD08A5F),
      };

  String _chestName(String tier) => switch (tier) {
        'silver' => 'صندوق نقره‌ای',
        'gold' => 'صندوق طلایی',
        _ => 'صندوق برنزی',
      };
}
