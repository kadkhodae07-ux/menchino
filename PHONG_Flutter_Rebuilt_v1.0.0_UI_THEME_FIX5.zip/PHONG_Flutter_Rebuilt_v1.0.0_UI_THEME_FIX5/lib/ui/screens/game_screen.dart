import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show Ticker;
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/state/app_state.dart';
import '../../core/theme.dart';
import '../../game/engine.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';

class GameScreen extends StatefulWidget {
  final String? modeOverride;
  final String? friendName;
  final Tournament? tournament;
  final int tournamentRound;

  const GameScreen({
    super.key,
    this.modeOverride,
    this.friendName,
    this.tournament,
    this.tournamentRound = 0,
  });

  factory GameScreen.fromSetup() => const GameScreen();
  factory GameScreen.local(String friendName) => GameScreen(modeOverride: 'local', friendName: friendName);
  factory GameScreen.tournament(Tournament tournament, int round) =>
      GameScreen(modeOverride: 'tournament', tournament: tournament, tournamentRound: round);

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AppState _state;
  late final Engine engine;
  late final Ticker _ticker;
  Duration? _lastTick;
  Size _lastSize = Size.zero;
  bool _resultHandled = false;
  bool _started = false;
  bool _prepared = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _state = context.read<AppState>();
    final setup = _state.matchSetup;
    final mode = widget.modeOverride ?? (setup['mode'] as String? ?? 'quick');
    final difficulty = mode == 'tournament'
        ? widget.tournament?.difficulty ?? 'hard'
        : mode == 'challenge'
            ? 'hard'
            : setup['difficulty'] as String? ?? 'medium';
    final entry = mode == 'practice' || mode == 'local' || mode == 'tournament'
        ? 0
        : setup['entry'] as int? ?? 0;

    engine = Engine(
      state: _state,
      mode: mode,
      difficulty: difficulty,
      orientation: setup['orientation'] as String? ?? 'portrait',
      entry: entry,
      twoPlayer: mode == 'local',
      friendName: widget.friendName,
      tournament: widget.tournament,
      tournamentRound: widget.tournamentRound,
    );
    engine.addListener(_engineChanged);
    _ticker = createTicker(_tick);

    WidgetsBinding.instance.addPostFrameCallback((_) => _prepare());
  }

  Future<void> _applyGameplayOrientation() async {
    await SystemChrome.setPreferredOrientations(
      engine.isLandscape
          ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
          : [DeviceOrientation.portraitUp],
    );
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  Future<void> _restorePortrait() async {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  Future<void> _prepare() async {
    if (!mounted) return;
    await _applyGameplayOrientation();
    if (!mounted) return;
    if (engine.entry > 0) {
      if (_state.coins < engine.entry) {
        showNeonMessage(context, 'سکه کافی برای ورودی مسابقه نداری.');
        Navigator.pop(context);
        return;
      }
      _state.addCoins(-engine.entry);
      await _state.save();
    }
    if (!mounted) return;
    _prepared = true;
    _tryStart();
  }

  void _tryStart() {
    if (!_prepared || _started || _lastSize == Size.zero || !mounted) return;
    engine.resize(_lastSize.width, _lastSize.height);
    engine.start();
    _started = true;
    _lastTick = null;
    _ticker.start();
  }

  void _tick(Duration elapsed) {
    final previous = _lastTick;
    _lastTick = elapsed;
    if (previous == null) return;
    final dt = (elapsed - previous).inMicroseconds / 1000000.0;
    engine.update(dt);
  }

  void _engineChanged() {
    if (engine.finished && !_resultHandled) {
      _resultHandled = true;
      _ticker.stop();
      WidgetsBinding.instance.addPostFrameCallback((_) => _finishMatch());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed && engine.started && !engine.paused) {
      engine.setPaused(true);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    engine.removeListener(_engineChanged);
    engine.dispose();
    _ticker.dispose();
    unawaited(_restorePortrait());
    super.dispose();
  }

  Future<void> _finishMatch() async {
    if (!mounted) return;
    final won = engine.bottomScore > engine.topScore;
    _state.stats['matches'] = (_state.stats['matches'] ?? 0) + 1;
    if (won) {
      _state.stats['wins'] = (_state.stats['wins'] ?? 0) + 1;
      _state.stats['streak'] = (_state.stats['streak'] ?? 0) + 1;
      _state.stats['bestStreak'] = max(_state.stats['bestStreak'] ?? 0, _state.stats['streak'] ?? 0).toInt();
    } else {
      _state.stats['losses'] = (_state.stats['losses'] ?? 0) + 1;
      _state.stats['streak'] = 0;
    }
    _state.stats['bestRally'] = max(_state.stats['bestRally'] ?? 0, engine.longestRally).toInt();
    _state.incMission('play');
    if (won) _state.incMission('win');
    if (engine.longestRally >= 10) _state.incMission('rally10');
    if (engine.difficulty == 'hard' && won && engine.mode != 'local') _state.incMission('hardWin');

    if (engine.mode == 'tournament' && engine.tournament != null) {
      await _finishTournament(won);
      return;
    }

    final difficultyBonus = const {'easy': 5, 'medium': 10, 'hard': 18, 'pro': 28}[engine.difficulty] ?? 5;
    final modeBonus = engine.mode == 'challenge' ? 16 : difficultyBonus;
    final scoreDifference = max(0, engine.bottomScore - engine.topScore).toInt();
    final rallyBonus = engine.longestRally ~/ 3;
    var xp = 18 + modeBonus + scoreDifference * 2 + rallyBonus;
    var baseCoins = 8 + modeBonus ~/ 2 + engine.playerGold;
    if (won) {
      xp += 26;
      baseCoins += 14;
    }
    if (engine.mode == 'practice') {
      baseCoins = 0;
      xp ~/= 2;
    }
    if (engine.mode == 'challenge' && won) baseCoins += 20;
    baseCoins = (baseCoins * (1 + engine.coinBonus)).floor();
    final entryPrize = won ? (engine.entry * 2 * .75).floor() : 0;
    final totalCoins = baseCoins + entryPrize;

    _state.addXp(xp);
    _state.addCoins(totalCoins);
    if (engine.mode == 'quick' || engine.mode == 'challenge') {
      _state.leaguePoints = max(0, _state.leaguePoints + (won ? 18 : -8)).toInt();
    } else if (engine.mode == 'local' && engine.friendName != null) {
      _state.leaguePoints = max(0, _state.leaguePoints + (won ? 8 : -4)).toInt();
    }
    await _state.audio.play(won ? 'win' : 'lose');
    await _state.save();
    await _restorePortrait();
    if (!mounted) return;

    final action = await _showResult(
      title: won ? 'پیروزی' : 'شکست',
      win: won,
      info: '+$xp تجربه\nپاداش مسابقه: +$baseCoins سکه\nپاداش ورودی: +$entryPrize سکه\nلیگ: ${_state.leaguePoints} امتیاز\nرالی: ${engine.longestRally}',
      allowRetry: true,
    );
    if (!mounted) return;
    if (action == 'retry') {
      await _retry();
    } else {
      Navigator.pop(context);
    }
  }

  Future<void> _finishTournament(bool won) async {
    final tournament = engine.tournament!;
    final round = max(1, engine.tournamentRound).toInt();
    if (won && round < tournament.rounds) {
      _state.tournament = {'activeId': tournament.id, 'round': round + 1};
      _state.addXp(35);
      await _state.audio.play('win');
      await _state.save();
      await _restorePortrait();
      if (!mounted) return;
      await _showResult(
        title: 'پیروزی',
        win: true,
        info: 'به دور ${round + 1} رفتی\n+35 تجربه',
        allowRetry: false,
      );
    } else if (won) {
      _state.addCoins(tournament.prize);
      _state.addXp(90);
      _state.tournament = {'activeId': null, 'round': 0};
      await _state.audio.play('win');
      await _state.save();
      await _restorePortrait();
      if (!mounted) return;
      await _showResult(
        title: 'قهرمان شدی',
        win: true,
        info: 'پاداش تورنمنت: +${tournament.prize} سکه\n+90 تجربه',
        allowRetry: false,
      );
    } else {
      _state.tournament = {'activeId': null, 'round': 0};
      _state.addXp(10);
      await _state.audio.play('lose');
      await _state.save();
      await _restorePortrait();
      if (!mounted) return;
      await _showResult(
        title: 'حذف شدی',
        win: false,
        info: 'در تورنمنت حذف شدی\n+10 تجربه',
        allowRetry: false,
      );
    }
    if (mounted) Navigator.pop(context);
  }

  Future<String?> _showResult({
    required String title,
    required bool win,
    required String info,
    required bool allowRetry,
  }) {
    final theme = _state.theme;
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: NeonPanel(
            borderColor: win ? theme.accent : theme.danger,
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          (win ? theme.accent : theme.danger).withOpacity(.26),
                          theme.panel.withOpacity(.12),
                          Colors.transparent,
                        ],
                      ),
                    ),
                    child: Center(
                      child: Text(
                        win ? '✓' : '×',
                        style: TextStyle(
                          color: win ? theme.accent : theme.danger,
                          fontSize: 34,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: win ? theme.accent : theme.danger,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '${engine.bottomScore} - ${engine.topScore}',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: theme.text, fontSize: 30, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 12),
                  Text(info, textAlign: TextAlign.center, style: TextStyle(color: theme.dim, height: 1.8, fontSize: 14)),
                  const SizedBox(height: 18),
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final compact = constraints.maxWidth < 310;
                      final exit = NeonButton(
                        label: allowRetry ? 'بازگشت' : 'باشه',
                        small: true,
                        expand: true,
                        onTap: () => Navigator.pop(dialogContext, 'exit'),
                      );
                      final retry = NeonButton(
                        label: 'بازی مجدد',
                        icon: 'restart',
                        small: true,
                        expand: true,
                        color: theme.accent,
                        onTap: () => Navigator.pop(dialogContext, 'retry'),
                      );
                      if (!allowRetry) return exit;
                      if (compact) {
                        return Column(
                          children: [
                            retry,
                            const SizedBox(height: 10),
                            exit,
                          ],
                        );
                      }
                      return Row(
                        children: [
                          Expanded(child: retry),
                          const SizedBox(width: 10),
                          Expanded(child: exit),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _retry() async {
    if (engine.entry > 0) {
      if (_state.coins < engine.entry) {
        if (mounted) showNeonMessage(context, 'سکه کافی برای بازی مجدد نداری.');
        if (mounted) Navigator.pop(context);
        return;
      }
      _state.addCoins(-engine.entry);
      await _state.save();
    }
    await _applyGameplayOrientation();
    _resultHandled = false;
    _lastTick = null;
    engine.restart();
    if (!_ticker.isActive) _ticker.start();
  }

  Future<void> _exitGame() async {
    await _restorePortrait();
    if (!mounted) return;
    engine.abandon();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        engine.setPaused(true);
        final exit = await showNeonConfirm(
          context,
          title: 'خروج از مسابقه',
          message: 'مسابقه فعلی بدون ثبت نتیجه بسته می‌شود.',
          confirmLabel: 'خروج',
          danger: true,
        );
        if (!mounted) return;
        if (exit) {
          await _exitGame();
        } else {
          engine.setPaused(false);
        }
      },
      child: Scaffold(
        backgroundColor: theme.bg,
        body: LayoutBuilder(
          builder: (context, constraints) {
            final size = Size(constraints.maxWidth, constraints.maxHeight);
            if (size != _lastSize) {
              _lastSize = size;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                engine.resize(size.width, size.height);
                _tryStart();
              });
            }
            return AnimatedBuilder(
              animation: engine,
              builder: (context, _) => Stack(
                children: [
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onPanDown: (details) => _handle(details.localPosition),
                      onPanUpdate: (details) => _handle(details.localPosition),
                      child: CustomPaint(painter: _GamePainter(engine, theme)),
                    ),
                  ),
                  Positioned(
                    top: MediaQuery.paddingOf(context).top + 10,
                    left: 12,
                    right: 12,
                    child: _hud(theme),
                  ),
                  if (engine.phase == 'countdown')
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                engine.countdown > 0 ? '${engine.countdown}' : 'شروع',
                                style: TextStyle(
                                  color: theme.primary,
                                  fontSize: 72,
                                  fontWeight: FontWeight.w900,
                                  shadows: [Shadow(color: theme.primary, blurRadius: 30)],
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                engine.twoPlayer
                                    ? (engine.isLandscape
                                        ? 'بازیکن ۱: سمت راست • بازیکن ۲: سمت چپ'
                                        : 'بازیکن ۱: پایین • بازیکن ۲: بالا')
                                    : (engine.isLandscape ? 'حرکت راکت با لمس نیمه راست' : 'حرکت راکت با لمس پایین صفحه'),
                                textAlign: TextAlign.center,
                                style: TextStyle(color: theme.dim),
                              ),
                              if (engine.mode == 'tournament' && engine.tournament != null)
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Text('${engine.tournament!.name} • دور ${engine.tournamentRound}', style: TextStyle(color: theme.dim)),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (engine.paused) _pauseOverlay(theme),
                  if (engine.lastPowerup != null && engine.phase == 'playing')
                    Positioned(
                      top: MediaQuery.paddingOf(context).top + 96,
                      left: 0,
                      right: 0,
                      child: IgnorePointer(
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: theme.panel.withOpacity(.9),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: theme.primary.withOpacity(.32)),
                              boxShadow: [BoxShadow(color: theme.primary.withOpacity(.12), blurRadius: 18)],
                            ),
                            child: Text(engine.lastPowerup!, style: TextStyle(color: theme.text, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _hud(GameTheme theme) {
    final topLabel = engine.twoPlayer ? 'بازیکن ۲' : 'حریف';
    final bottomLabel = engine.twoPlayer ? 'بازیکن ۱' : 'شما';

    return Row(
      children: [
        Expanded(
          child: _scoreCard(
            topLabel,
            engine.topScore,
            theme,
            theme.top,
            avatarIndex: (
              (_state.avatar + (engine.twoPlayer ? 1 : 2)) % avatars.length
            ),
          ),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: min(168, max(126, _lastSize.width * .22)).toDouble(),
          child: NeonButton(
            label: engine.paused ? 'ادامه' : 'توقف',
            icon: engine.paused ? 'resume' : 'pause',
            small: true,
            color: theme.danger,
            onTap: () => engine.setPaused(!engine.paused),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _scoreCard(
            bottomLabel,
            engine.bottomScore,
            theme,
            theme.bottom,
            avatarIndex: _state.avatar,
            alignRight: true,
          ),
        ),
      ],
    );
  }

  Widget _pauseOverlay(GameTheme theme) => Positioned.fill(
        child: Container(
          color: theme.bg.withOpacity(.72),
          alignment: Alignment.center,
          padding: const EdgeInsets.all(18),
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 380),
              child: NeonPanel(
                borderColor: theme.primary,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('توقف', style: TextStyle(color: theme.text, fontSize: 30, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Text(
                      'بازی متوقف شده؛ می‌تونی ادامه بدی، از اول شروع کنی یا از مسابقه خارج بشی.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: theme.dim, height: 1.75),
                    ),
                    const SizedBox(height: 16),
                    NeonButton(label: 'ادامه', icon: 'resume', color: theme.accent, expand: true, onTap: () => engine.setPaused(false)),
                    const SizedBox(height: 10),
                    NeonButton(
                      label: 'شروع مجدد',
                      icon: 'restart',
                      color: theme.secondary,
                      expand: true,
                      onTap: () {
                        _resultHandled = false;
                        _lastTick = null;
                        engine.restart();
                      },
                    ),
                    const SizedBox(height: 10),
                    NeonButton(
                      label: 'خروج از مسابقه',
                      icon: 'exit',
                      color: theme.danger,
                      expand: true,
                      onTap: () async {
                        final exit = await showNeonConfirm(
                          context,
                          title: 'خروج از مسابقه',
                          message: 'نتیجه این مسابقه ثبت نمی‌شود.',
                          confirmLabel: 'خروج',
                          danger: true,
                        );
                        if (!exit || !mounted) return;
                        await _exitGame();
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );

  void _handle(Offset position) {
    if (engine.paused || !engine.started) return;
    final owner = engine.twoPlayer
        ? (engine.isLandscape ? (position.dx < engine.width / 2 ? 'top' : 'bottom') : (position.dy < engine.height / 2 ? 'top' : 'bottom'))
        : 'bottom';
    engine.setTarget(owner, engine.isLandscape ? position.dy : position.dx);
  }

  Widget _scoreCard(
    String label,
    int value,
    GameTheme theme,
    Color accent, {
    required int avatarIndex,
    bool alignRight = false,
  }) => Container(
        height: 58,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: theme.panel.withOpacity(.84),
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: accent.withOpacity(.34)),
          boxShadow: [
            BoxShadow(color: accent.withOpacity(.09), blurRadius: 18),
            BoxShadow(color: Colors.black.withOpacity(.20), blurRadius: 14, offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          children: alignRight
              ? [
                  Expanded(child: _scoreTexts(label, value, theme, alignRight: true)),
                  const SizedBox(width: 8),
                  Opacity(opacity: .72, child: AvatarBadge(index: avatarIndex, size: 24)),
                ]
              : [
                  Opacity(opacity: .72, child: AvatarBadge(index: avatarIndex, size: 24)),
                  const SizedBox(width: 8),
                  Expanded(child: _scoreTexts(label, value, theme)),
                ],
        ),
      );

  Widget _scoreTexts(String label, int value, GameTheme theme, {bool alignRight = false}) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim.withOpacity(.88), fontSize: 10, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text('$value', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 24, height: 1)),
        ],
      );
}

class _GamePainter extends CustomPainter {
  final Engine engine;
  final GameTheme theme;

  _GamePainter(this.engine, this.theme) : super(repaint: engine);

  @override
  void paint(Canvas canvas, Size size) {
    final width = engine.width > 0 ? engine.width : size.width;
    final height = engine.height > 0 ? engine.height : size.height;
    final rect = Rect.fromLTWH(0, 0, width, height);

    final bg = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          theme.canvasBg,
          Color.lerp(theme.canvasBg, Colors.black, .18)!,
          Color.lerp(theme.canvasBg, theme.primary.withOpacity(.02), .08)!,
        ],
      ).createShader(rect);
    canvas.drawRect(rect, bg);

    final vignette = Paint()
      ..shader = RadialGradient(
        center: Alignment.center,
        radius: .92,
        colors: [
          Colors.transparent,
          Colors.black.withOpacity(.18),
          Colors.black.withOpacity(.42),
        ],
        stops: const [0.0, .72, 1.0],
      ).createShader(rect);
    canvas.drawRect(rect, vignette);

    _drawArenaLights(canvas, width, height);
    _drawSurfacePattern(canvas, width, height);
    _drawCenterline(canvas, width, height);
    _drawGoalZones(canvas, width, height);
    _drawWalls(canvas, width, height);

    if (engine.state.trail && engine.trail.isNotEmpty) {
      for (var index = 0; index < engine.trail.length; index++) {
        final point = engine.trail[index];
        final ratio = (index + 1) / engine.trail.length;
        canvas.drawCircle(
          Offset(point.x, point.y),
          engine.ball.radius * ratio * .95,
          Paint()..color = (engine.state.ball.trailColor ?? theme.trail).withOpacity(ratio * .33),
        );
      }
    }

    for (final powerup in engine.powerups) {
      final color = _powerColor(powerup.type);
      canvas.drawCircle(Offset(powerup.x, powerup.y), powerup.radius + 7, Paint()..color = color.withOpacity(.12));
      canvas.drawCircle(Offset(powerup.x, powerup.y), powerup.radius, Paint()..color = color.withOpacity(.16));
      canvas.drawCircle(Offset(powerup.x, powerup.y), powerup.radius, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 2);
      _drawPowerGlyph(canvas, powerup, color);
    }

    final glow = switch (engine.state.quality) {
      'low' => 0.0,
      'high' => 20.0,
      _ => 12.0,
    };
    final ballColor = engine.state.ball.color ?? theme.ball;
    canvas.drawCircle(
      Offset(engine.ball.x, engine.ball.y),
      engine.ball.radius + 10,
      Paint()..color = ballColor.withOpacity(.11),
    );
    canvas.drawCircle(
      Offset(engine.ball.x, engine.ball.y),
      engine.ball.radius,
      Paint()..color = ballColor..maskFilter = glow > 0 ? MaskFilter.blur(BlurStyle.normal, glow) : null,
    );

    _drawPaddle(canvas, engine.top, theme.top, engine.effects['top']!['shield']! > 0, glow, side: 'top');
    _drawPaddle(canvas, engine.bottom, theme.bottom, engine.effects['bottom']!['shield']! > 0, glow, side: 'bottom');

    if (engine.state.debug) {
      final textPainter = TextPainter(
        textDirection: TextDirection.ltr,
        text: TextSpan(
          text: 'Phase: ${engine.phase}\nSpeed: ${engine.hypot.round()}\nPowerups: ${engine.powerups.length}',
          style: TextStyle(color: theme.text, fontSize: 11),
        ),
      )..layout();
      textPainter.paint(canvas, const Offset(10, 95));
    }
  }

  void _drawArenaLights(Canvas canvas, double width, double height) {
    final topLight = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [theme.secondary.withOpacity(.24), Colors.transparent],
      ).createShader(Rect.fromLTWH(width * .28, 0, width * .44, height * .12));
    canvas.drawRect(Rect.fromLTWH(width * .28, 0, width * .44, height * .12), topLight);

    final bottomLight = Paint()
      ..shader = LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [theme.accent.withOpacity(.18), Colors.transparent],
      ).createShader(Rect.fromLTWH(width * .18, height * .82, width * .64, height * .18));
    canvas.drawRect(Rect.fromLTWH(width * .18, height * .82, width * .64, height * .18), bottomLight);
  }

  void _drawSurfacePattern(Canvas canvas, double width, double height) {
    final frameRect = Rect.fromLTWH(10, 10, width - 20, height - 20);
    final frame = RRect.fromRectAndRadius(frameRect, const Radius.circular(26));
    canvas.drawRRect(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = theme.grid.withOpacity(.55),
    );

    final inner = RRect.fromRectAndRadius(frameRect.deflate(18), const Radius.circular(22));
    canvas.drawRRect(
      inner,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = theme.grid.withOpacity(.26),
    );

    final lane = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = theme.grid.withOpacity(.22);

    if (engine.isLandscape) {
      final y1 = height * .23;
      final y2 = height * .77;
      canvas.drawLine(Offset(22, y1), Offset(width - 22, y1), lane);
      canvas.drawLine(Offset(22, y2), Offset(width - 22, y2), lane);
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(width * .34, height * .28, width * .32, height * .44), const Radius.circular(28)),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = theme.grid.withOpacity(.18),
      );
    } else {
      final x1 = width * .23;
      final x2 = width * .77;
      canvas.drawLine(Offset(x1, 22), Offset(x1, height - 22), lane);
      canvas.drawLine(Offset(x2, 22), Offset(x2, height - 22), lane);
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(width * .20, height * .34, width * .60, height * .32), const Radius.circular(28)),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = theme.grid.withOpacity(.18),
      );
    }
  }

  void _drawCenterline(Canvas canvas, double width, double height) {
    final linePaint = Paint()..color = theme.center.withOpacity(.46)..strokeWidth = 2;
    if (engine.isLandscape) {
      canvas.drawLine(Offset(width / 2, 0), Offset(width / 2, height), linePaint);
      canvas.drawCircle(Offset(width / 2, height / 2), 22, Paint()..color = theme.center.withOpacity(.06));
      canvas.drawCircle(Offset(width / 2, height / 2), 22, Paint()..color = theme.center.withOpacity(.36)..style = PaintingStyle.stroke..strokeWidth = 1.2);
    } else {
      canvas.drawLine(Offset(0, height / 2), Offset(width, height / 2), linePaint);
      canvas.drawCircle(Offset(width / 2, height / 2), 22, Paint()..color = theme.center.withOpacity(.06));
      canvas.drawCircle(Offset(width / 2, height / 2), 22, Paint()..color = theme.center.withOpacity(.36)..style = PaintingStyle.stroke..strokeWidth = 1.2);
    }
  }

  void _drawGoalZones(Canvas canvas, double width, double height) {
    if (engine.isLandscape) {
      final left = Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [theme.top.withOpacity(.14), Colors.transparent],
        ).createShader(Rect.fromLTWH(0, height * .2, 70, height * .6));
      final right = Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
          colors: [theme.bottom.withOpacity(.14), Colors.transparent],
        ).createShader(Rect.fromLTWH(width - 70, height * .2, 70, height * .6));
      canvas.drawRect(Rect.fromLTWH(0, height * .2, 70, height * .6), left);
      canvas.drawRect(Rect.fromLTWH(width - 70, height * .2, 70, height * .6), right);
    } else {
      final topGlow = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [theme.top.withOpacity(.12), Colors.transparent],
        ).createShader(Rect.fromLTWH(width * .2, 0, width * .6, 70));
      final bottomGlow = Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [theme.bottom.withOpacity(.12), Colors.transparent],
        ).createShader(Rect.fromLTWH(width * .2, height - 70, width * .6, 70));
      canvas.drawRect(Rect.fromLTWH(width * .2, 0, width * .6, 70), topGlow);
      canvas.drawRect(Rect.fromLTWH(width * .2, height - 70, width * .6, 70), bottomGlow);
    }
  }

  void _drawWalls(Canvas canvas, double width, double height) {
    if (engine.sideInset <= 0) return;
    final wall = Paint()..color = Colors.white.withOpacity(.06);
    if (engine.isLandscape) {
      canvas.drawRect(Rect.fromLTWH(0, 0, width, engine.sideInset), wall);
      canvas.drawRect(Rect.fromLTWH(0, height - engine.sideInset, width, engine.sideInset), wall);
    } else {
      canvas.drawRect(Rect.fromLTWH(0, 0, engine.sideInset, height), wall);
      canvas.drawRect(Rect.fromLTWH(width - engine.sideInset, 0, engine.sideInset, height), wall);
    }
  }

  void _drawPaddle(Canvas canvas, PaddleState paddle, Color color, bool shield, double glow, {required String side}) {
    final rect = Rect.fromCenter(center: Offset(paddle.x, paddle.y), width: paddle.width, height: paddle.height);
    final outer = RRect.fromRectAndRadius(rect, const Radius.circular(14));
    canvas.drawRRect(
      outer.inflate(3),
      Paint()..color = color.withOpacity(.08),
    );
    canvas.drawRRect(
      outer,
      Paint()..color = color.withOpacity(.14)..maskFilter = glow > 0 ? MaskFilter.blur(BlurStyle.normal, glow) : null,
    );
    canvas.drawRRect(
      outer,
      Paint()
        ..shader = LinearGradient(
          begin: engine.isLandscape ? Alignment.topCenter : Alignment.centerLeft,
          end: engine.isLandscape ? Alignment.bottomCenter : Alignment.centerRight,
          colors: [
            Colors.white.withOpacity(.22),
            color.withOpacity(.95),
            color.withOpacity(.72),
          ],
        ).createShader(rect),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect.deflate(3), const Radius.circular(11)),
      Paint()..color = Colors.black.withOpacity(.16),
    );

    final coreRect = engine.isLandscape
        ? Rect.fromCenter(center: Offset(paddle.x, paddle.y), width: max(4, paddle.width - 6).toDouble(), height: paddle.height * .56)
        : Rect.fromCenter(center: Offset(paddle.x, paddle.y), width: paddle.width * .56, height: max(4, paddle.height - 6).toDouble());
    canvas.drawRRect(
      RRect.fromRectAndRadius(coreRect, const Radius.circular(10)),
      Paint()..color = Colors.white.withOpacity(.18),
    );

    if (shield) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect.inflate(8), const Radius.circular(18)),
        Paint()..color = theme.secondary.withOpacity(.9)..style = PaintingStyle.stroke..strokeWidth = 2,
      );
    }
  }

  void _drawPowerGlyph(Canvas canvas, Powerup powerup, Color color) {
    final painter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      text: TextSpan(
        text: switch (powerup.type) {
          'big' => '+',
          'shrink' => '−',
          'slow' => '◷',
          'fast' => '⚡',
          'shield' => '◇',
          _ => '¢',
        },
        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900),
      ),
    )..layout();
    painter.paint(canvas, Offset(powerup.x - painter.width / 2, powerup.y - painter.height / 2));
  }

  Color _powerColor(String type) => switch (type) {
        'big' => const Color(0xFF00FFC6),
        'shrink' => const Color(0xFFFF3B8D),
        'slow' => const Color(0xFF2DE2FF),
        'fast' => const Color(0xFFFFB84D),
        'shield' => const Color(0xFF8A5CFF),
        _ => const Color(0xFFFFD54D),
      };

  @override
  bool shouldRepaint(covariant _GamePainter oldDelegate) => oldDelegate.theme != theme || oldDelegate.engine != engine;
}
