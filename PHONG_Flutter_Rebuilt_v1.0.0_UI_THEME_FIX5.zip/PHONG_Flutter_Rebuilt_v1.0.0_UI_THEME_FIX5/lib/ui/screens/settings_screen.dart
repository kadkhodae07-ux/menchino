import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/state/app_state.dart';
import '../../core/theme.dart';
import '../widgets/neon.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(title: const Text('تنظیمات')),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: NeonPanel(
            child: Column(
              children: [
                _row(theme, 'تم بازی', DropdownButton<String>(
                  value: state.themeId,
                  dropdownColor: theme.panel,
                  items: Themes.all.map((item) => DropdownMenuItem(value: item.id, child: Text(item.label))).toList(),
                  onChanged: (value) {
                    if (value != null) state.setTheme(value);
                  },
                )),
                _divider(theme),
                _row(theme, 'حساسیت کنترل', SizedBox(
                  width: 150,
                  child: Slider(
                    min: .6,
                    max: 2,
                    divisions: 14,
                    label: state.sensitivity.toStringAsFixed(1),
                    value: state.sensitivity,
                    onChanged: (value) => state.setSetting(sensitivityValue: value),
                  ),
                )),
                _divider(theme),
                _row(theme, 'کیفیت گرافیک', DropdownButton<String>(
                  value: state.quality,
                  dropdownColor: theme.panel,
                  items: const [
                    DropdownMenuItem(value: 'low', child: Text('کم')),
                    DropdownMenuItem(value: 'medium', child: Text('متوسط')),
                    DropdownMenuItem(value: 'high', child: Text('زیاد')),
                  ],
                  onChanged: (value) {
                    if (value != null) state.setSetting(qualityValue: value);
                  },
                )),
                _divider(theme),
                _switch(theme, 'رد نور توپ', state.trail, (value) => state.setSetting(trailValue: value)),
                _divider(theme),
                _switch(theme, 'صدا', state.sound, (value) => state.setSetting(soundValue: value)),
                _divider(theme),
                _switch(theme, 'لرزش', state.haptics, (value) => state.setSetting(hapticsValue: value)),
                _divider(theme),
                _switch(theme, 'حالت دیباگ', state.debug, (value) => state.setSetting(debugValue: value)),
                const SizedBox(height: 18),
                NeonButton(
                  label: 'بازنشانی اطلاعات',
                  icon: 'restart',
                  color: theme.danger,
                  expand: true,
                  onTap: () async {
                    final first = await showNeonConfirm(
                      context,
                      title: 'بازنشانی اطلاعات',
                      message: 'تمام پیشرفت، سکه‌ها، آیتم‌ها و تنظیمات حذف می‌شوند. ادامه می‌دهی؟',
                      confirmLabel: 'ادامه',
                      danger: true,
                    );
                    if (!first || !context.mounted) return;
                    final second = await showNeonConfirm(
                      context,
                      title: 'تأیید نهایی',
                      message: 'این عملیات قابل بازگشت نیست.',
                      confirmLabel: 'حذف همه',
                      danger: true,
                    );
                    if (!second) return;
                    await state.resetData();
                    if (context.mounted) {
                      showNeonMessage(context, 'اطلاعات بازی بازنشانی شد.');
                      Navigator.pop(context);
                    }
                  },
                ),
                const SizedBox(height: 14),
                Text('نسخه 1.0.0+1 • داده‌ها فقط روی دستگاه ذخیره می‌شوند.', textAlign: TextAlign.center, style: TextStyle(color: theme.dim, fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(dynamic theme, String label, Widget control) => Row(children: [Expanded(child: Text(label, style: TextStyle(color: theme.text, fontWeight: FontWeight.w700))), control]);
  Widget _switch(dynamic theme, String label, bool value, ValueChanged<bool> onChanged) => _row(theme, label, Switch(value: value, onChanged: onChanged));
  Widget _divider(dynamic theme) => Divider(height: 20, color: theme.dim.withOpacity(.12));
}
