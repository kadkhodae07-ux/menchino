import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';
import 'chat_screen.dart';
import 'friends_screen.dart';
import 'game_screen.dart';
import 'match_setup_dialog.dart';
import 'settings_screen.dart';
import 'shop_screen.dart';
import 'rewards_screen.dart';
import 'tournament_screen.dart';

class LobbyScreen extends StatelessWidget {
  const LobbyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return SafeArea(
      bottom: false,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 390;
          final columns = constraints.maxWidth < 380 ? 1 : (constraints.maxWidth >= 900 ? 3 : 2);
          final aspect = columns == 1 ? 2.15 : (constraints.maxWidth >= 900 ? 1.14 : 1.02);

          return SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _LobbyHeader(state: state),
                const SizedBox(height: 18),
                NeonPanel(
                  borderColor: theme.accent,
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
                  child: Column(
                    children: [
                      Container(
                        width: 86,
                        height: 86,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              theme.accent.withOpacity(.32),
                              theme.secondary.withOpacity(.22),
                              Colors.transparent,
                            ],
                          ),
                        ),
                        child: Center(child: AppIcons.icon('arena', size: 38, color: theme.text)),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'آماده‌ی ورود به میدان؟',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: theme.text, fontSize: compact ? 26 : 30, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'مسابقه سریع، تمرین حرفه‌ای یا تورنمنت را انتخاب کن. حالت عمودی و افقی هر دو آماده‌اند.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: theme.dim, height: 1.7),
                      ),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        alignment: WrapAlignment.center,
                        children: [
                          StatBadge('راکت: ${state.racket.name}', color: theme.primary),
                          StatBadge('توپ: ${state.ball.name}', color: theme.secondary),
                          StatBadge('آرنا: ${state.arena.name}', color: theme.accent),
                        ],
                      ),
                      const SizedBox(height: 18),
                      NeonButton(
                        label: 'شروع بازی',
                        icon: 'play',
                        color: theme.accent,
                        expand: true,
                        onTap: () async {
                          final setup = await showDialog<Map<String, dynamic>>(
                            context: context,
                            builder: (_) => const MatchSetupDialog(),
                          );
                          if (setup == null || !context.mounted) return;
                          await state.updateMatchSetup(setup);
                          if (!context.mounted) return;
                          Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen.fromSetup()));
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                GridView.count(
                  crossAxisCount: columns,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: aspect,
                  children: [
                    _LobbyActionCard(
                      title: 'تورنمنت',
                      subtitle: 'چند مرحله پیاپی با ورودی و جایزه بیشتر',
                      icon: 'crown',
                      color: theme.secondary,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TournamentScreen())),
                    ),
                    _LobbyActionCard(
                      title: 'تمرین',
                      subtitle: 'بدون ورودی؛ برای گرم کردن و تست تجهیزات',
                      icon: 'practice',
                      color: theme.primary,
                      onTap: () async {
                        await state.updateMatchSetup({'mode': 'practice', 'entry': 0});
                        if (!context.mounted) return;
                        Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen.fromSetup()));
                      },
                    ),
                    _LobbyActionCard(
                      title: 'دوستانه',
                      subtitle: 'بازی محلی دو نفره روی یک دستگاه',
                      icon: 'friends',
                      color: theme.accent,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FriendsScreen())),
                    ),
                    _LobbyActionCard(
                      title: 'ماموریت‌ها',
                      subtitle: 'جایزه روزانه، صندوق‌ها و پیشرفت مأموریت',
                      icon: 'mission',
                      color: theme.gold,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RewardsScreen())),
                    ),
                    _LobbyActionCard(
                      title: 'چت',
                      subtitle: 'پیام همگانی و خصوصی برای هماهنگی مسابقه',
                      icon: 'chat',
                      color: theme.danger,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())),
                    ),
                    _LobbyActionCard(
                      title: 'فروشگاه',
                      subtitle: 'راکت، توپ و آرناهای جدید را تجهیز کن',
                      icon: 'shop',
                      color: theme.primary,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ShopScreen())),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _LobbyHeader extends StatelessWidget {
  final AppState state;

  const _LobbyHeader({required this.state});

  @override
  Widget build(BuildContext context) {
    final theme = state.theme;
    return NeonPanel(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final stacked = constraints.maxWidth < 430;
          final profile = Row(
            children: [
              AvatarBadge(index: state.avatar),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      state.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 18),
                    ),
                    const SizedBox(height: 3),
                    Text('سطح ${state.level} • لیگ ${state.leaguePoints}', style: TextStyle(color: theme.dim, fontSize: 13)),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(
                        minHeight: 10,
                        value: (state.xp / state.xpToNext).clamp(0.0, 1.0).toDouble(),
                        color: theme.primary,
                        backgroundColor: theme.primary.withOpacity(.14),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );

          final actions = Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Chip3D(text: '${state.coins}'),
              Chip3D(text: '${state.gems}', gem: true),
              _miniIconButton(context, 'chat', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen()))),
              _miniIconButton(context, 'settings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
            ],
          );

          if (stacked) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                profile,
                const SizedBox(height: 12),
                actions,
              ],
            );
          }

          return Row(
            children: [
              Expanded(child: profile),
              const SizedBox(width: 12),
              actions,
            ],
          );
        },
      ),
    );
  }

  Widget _miniIconButton(BuildContext context, String icon, VoidCallback onTap) {
    final theme = context.read<AppState>().theme;
    return IconButton.filledTonal(
      onPressed: onTap,
      style: IconButton.styleFrom(
        backgroundColor: theme.primary.withOpacity(.08),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      icon: AppIcons.icon(icon, color: theme.text),
    );
  }
}

class _LobbyActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color color;
  final VoidCallback onTap;

  const _LobbyActionCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: NeonPanel(
        borderColor: color,
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 148),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          color.withOpacity(.30),
                          theme.panel.withOpacity(.90),
                        ],
                      ),
                      border: Border.all(color: color.withOpacity(.40)),
                      boxShadow: [BoxShadow(color: color.withOpacity(.18), blurRadius: 18)],
                    ),
                    child: Center(child: AppIcons.icon(icon, size: 28, color: theme.text)),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                      color: color.withOpacity(.10),
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(color: color.withOpacity(.18)),
                    ),
                    child: Text('ورود', style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 11)),
                  ),
                ],
              ),
              const Spacer(),
              Text(title, style: TextStyle(color: theme.text, fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text(subtitle, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim, height: 1.72, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}
