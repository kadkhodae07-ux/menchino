import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class MatchSetupDialog extends StatefulWidget {
  const MatchSetupDialog({super.key});

  @override
  State<MatchSetupDialog> createState() => _MatchSetupDialogState();
}

class _MatchSetupDialogState extends State<MatchSetupDialog> {
  late String mode;
  late String difficulty;
  late String orientation;
  late int entry;

  @override
  void initState() {
    super.initState();
    final setup = context.read<AppState>().matchSetup;
    mode = setup['mode'] as String? ?? 'quick';
    difficulty = setup['difficulty'] as String? ?? 'medium';
    orientation = setup['orientation'] as String? ?? 'portrait';
    entry = setup['entry'] as int? ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final prize = (entry * 2 * .75).floor();

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(18),
      child: NeonPanel(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('تنظیم مسابقه', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 21)),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: const {
                  'quick': 'سریع',
                  'challenge': 'چالش',
                  'practice': 'تمرین',
                  'local': 'دوستانه',
                }.entries.map((item) {
                  final active = mode == item.key;
                  return ChoiceChip(
                    label: Text(item.value),
                    selected: active,
                    selectedColor: theme.primary.withOpacity(.22),
                    side: BorderSide(color: active ? theme.primary : theme.dim.withOpacity(.25)),
                    onSelected: (_) => setState(() {
                      mode = item.key;
                      if (mode == 'practice') entry = 0;
                    }),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              _row(
                context,
                'سختی هوش مصنوعی',
                DropdownButton<String>(
                  value: difficulty,
                  dropdownColor: theme.panel,
                  items: const {'easy': 'آسان', 'medium': 'متوسط', 'hard': 'سخت', 'pro': 'حرفه‌ای'}
                      .entries
                      .map((item) => DropdownMenuItem(value: item.key, child: Text(item.value)))
                      .toList(),
                  onChanged: mode == 'local' ? null : (value) => setState(() => difficulty = value ?? difficulty),
                ),
              ),
              _row(
                context,
                'جهت صفحه بازی',
                DropdownButton<String>(
                  value: orientation,
                  dropdownColor: theme.panel,
                  items: const [
                    DropdownMenuItem(value: 'portrait', child: Text('عمودی')),
                    DropdownMenuItem(value: 'landscape', child: Text('افقی')),
                  ],
                  onChanged: (value) => setState(() => orientation = value ?? orientation),
                ),
              ),
              _row(
                context,
                'ورودی مسابقه',
                DropdownButton<int>(
                  value: mode == 'practice' ? 0 : entry,
                  dropdownColor: theme.panel,
                  items: const [0, 20, 50, 100]
                      .map((value) => DropdownMenuItem(value: value, child: Text(value == 0 ? 'آزاد' : '$value سکه')))
                      .toList(),
                  onChanged: mode == 'practice' ? null : (value) => setState(() => entry = value ?? entry),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                entry > 0 ? 'جایزه برنده: $prize سکه' : 'ورودی آزاد؛ جایزه ورودی ندارد.',
                style: TextStyle(color: theme.dim, fontSize: 13),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: NeonButton(label: 'انصراف', small: true, onTap: () => Navigator.pop(context))),
                  const SizedBox(width: 10),
                  Expanded(
                    child: NeonButton(
                      label: 'شروع',
                      small: true,
                      color: theme.accent,
                      onTap: () {
                        if (entry > state.coins) {
                          showNeonMessage(context, 'سکه کافی برای ورودی مسابقه نداری.');
                          return;
                        }
                        Navigator.pop(context, {
                          'mode': mode,
                          'difficulty': mode == 'challenge' ? 'hard' : difficulty,
                          'orientation': orientation,
                          'entry': mode == 'practice' ? 0 : entry,
                        });
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(BuildContext context, String label, Widget control) {
    final theme = context.read<AppState>().theme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: theme.dim, fontWeight: FontWeight.w700))),
          control,
        ],
      ),
    );
  }
}
