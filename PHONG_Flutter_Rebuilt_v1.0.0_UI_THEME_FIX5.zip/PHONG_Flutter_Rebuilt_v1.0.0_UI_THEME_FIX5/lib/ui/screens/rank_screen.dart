import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class RankScreen extends StatelessWidget {
  const RankScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final entries = [
      ...state.bots.map((entry) => Map<String, dynamic>.from(entry)),
      {'name': '${state.name} (شما)', 'points': state.leaguePoints, 'me': true},
    ]..sort((a, b) => ((b['points'] as num?)?.toInt() ?? 0).compareTo((a['points'] as num?)?.toInt() ?? 0));

    final top3 = entries.take(3).toList();
    final podium = [if (top3.length > 1) top3[1], if (top3.isNotEmpty) top3[0], if (top3.length > 2) top3[2]];
    final rest = entries.skip(3).toList();

    return SafeArea(
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 22),
        child: Column(
          children: [
            Text('رتبه‌بندی ماهانه', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 22)),
            const SizedBox(height: 12),
            NeonPanel(
              child: Column(
                children: [
                  _infoRow(theme, 'فصل فعلی', state.season),
                  _infoRow(theme, 'ریست بعدی', _seasonCountdown()),
                  _infoRow(theme, 'امتیاز شما', '${state.leaguePoints}', last: true),
                ],
              ),
            ),
            const SizedBox(height: 12),
            NeonPanel(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: List.generate(podium.length, (index) {
                  final entry = podium[index];
                  final isFirst = index == 1;
                  final color = isFirst ? theme.gold : index == 0 ? const Color(0xFFC9D7F0) : const Color(0xFFD08A5F);
                  return Expanded(
                    child: Container(
                      constraints: BoxConstraints(minHeight: isFirst ? 150 : 122),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: color.withOpacity(.08),
                        border: Border.all(color: color.withOpacity(.50)),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          AppIcons.icon('crown', size: isFirst ? 35 : 27, color: color),
                          const SizedBox(height: 7),
                          Text('${entry['name']}', textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 12)),
                          const SizedBox(height: 4),
                          Text('${entry['points']}', style: TextStyle(color: theme.primary, fontWeight: FontWeight.w900, fontSize: 17)),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
            const SizedBox(height: 12),
            for (var index = 0; index < rest.length; index++) ...[
              NeonPanel(
                borderColor: rest[index]['me'] == true ? theme.primary : theme.dim,
                child: Row(
                  children: [
                    AppIcons.icon('rank', color: rest[index]['me'] == true ? theme.primary : theme.dim),
                    const SizedBox(width: 12),
                    Expanded(child: Text('${rest[index]['name']}', style: TextStyle(color: theme.text, fontWeight: rest[index]['me'] == true ? FontWeight.w900 : FontWeight.w700))),
                    Text('رتبه ${index + 4}', style: TextStyle(color: theme.dim, fontSize: 12)),
                    const SizedBox(width: 8),
                    Text('${rest[index]['points']}', style: TextStyle(color: theme.primary, fontWeight: FontWeight.w900)),
                  ],
                ),
              ),
              const SizedBox(height: 10),
            ],
          ],
        ),
      ),
    );
  }

  Widget _infoRow(dynamic theme, String label, String value, {bool last = false}) => Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(border: last ? null : Border(bottom: BorderSide(color: theme.dim.withOpacity(.12)))),
        child: Row(children: [Text(label, style: TextStyle(color: theme.dim)), const Spacer(), Text(value, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900))]),
      );

  String _seasonCountdown() {
    final now = DateTime.now();
    final next = DateTime(now.year, now.month + 1);
    final difference = next.difference(now);
    return '${difference.inDays} روز و ${difference.inHours % 24} ساعت';
  }
}
