import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'chat_screen.dart';
import 'game_screen.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(title: const Text('بازی با دوستان')),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
              child: NeonPanel(
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        style: TextStyle(color: theme.text),
                        decoration: InputDecoration(
                          hintText: 'نام دوست...',
                          hintStyle: TextStyle(color: theme.dim),
                          filled: true,
                          fillColor: theme.primary.withOpacity(.06),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
                        ),
                        onSubmitted: (_) => _add(state),
                      ),
                    ),
                    const SizedBox(width: 8),
                    NeonButton(label: 'افزودن', small: true, color: theme.accent, onTap: () => _add(state)),
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 2, 16, 22),
                itemCount: state.friends.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final friend = state.friends[index];
                  final online = friend['online'] == true;
                  return NeonPanel(
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: online ? theme.accent : theme.dim,
                            boxShadow: online ? [BoxShadow(color: theme.accent, blurRadius: 10)] : null,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${friend['name']}', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                              Text(online ? 'آنلاین' : 'آفلاین', style: TextStyle(color: theme.dim, fontSize: 12)),
                            ],
                          ),
                        ),
                        NeonButton(
                          label: 'چت',
                          small: true,
                          color: theme.secondary,
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(initialFriendId: '${friend['id']}'))),
                        ),
                        const SizedBox(width: 7),
                        NeonButton(label: 'دعوت', small: true, color: theme.accent, onTap: () => _invite(state, friend)),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _add(AppState state) async {
    final name = _controller.text.trim();
    if (name.length < 2) {
      showNeonMessage(context, 'نام دوست خیلی کوتاه است.');
      return;
    }
    await state.addFriend(name);
    _controller.clear();
    if (mounted) showNeonMessage(context, '$name اضافه شد.');
  }

  Future<void> _invite(AppState state, Map<String, dynamic> friend) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: state.theme.panel,
        title: Text('دعوت ${friend['name']}', style: TextStyle(color: state.theme.text, fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('در حال آماده‌سازی مسابقه دونفره محلی...', style: TextStyle(color: state.theme.dim)),
            const SizedBox(height: 14),
            LinearProgressIndicator(color: state.theme.accent, backgroundColor: state.theme.accent.withOpacity(.12)),
          ],
        ),
      ),
    );
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;
    Navigator.pop(context);
    await state.updateMatchSetup({'mode': 'local', 'entry': 0});
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen.local('${friend['name']}')));
  }
}
