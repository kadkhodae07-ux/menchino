import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  String _tab = 'rackets';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: Column(
          children: [
            Row(
              children: [
                Text('فروشگاه', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 23)),
                const Spacer(),
                Chip3D(text: '${state.coins}'),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: const {'rackets': 'راکت‌ها', 'balls': 'توپ‌ها', 'arenas': 'زمین‌ها'}.entries.map((entry) {
                final active = _tab == entry.key;
                return ChoiceChip(
                  label: Text(entry.value),
                  selected: active,
                  selectedColor: theme.primary.withOpacity(.20),
                  side: BorderSide(color: active ? theme.primary : theme.dim.withOpacity(.25)),
                  onSelected: (_) => setState(() => _tab = entry.key),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.only(bottom: 20),
                itemCount: Catalog.of(_tab).length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final item = Catalog.of(_tab)[index];
                  final owned = state.owned.contains(item.id);
                  final equipped = state.selected[item.type] == item.id;
                  final color = rarityColor[item.rarity] ?? theme.primary;
                  return NeonPanel(
                    borderColor: color,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 58,
                              height: 58,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(17),
                                color: color.withOpacity(.07),
                                border: Border.all(color: color.withOpacity(.20)),
                              ),
                              child: Center(child: AppIcons.icon(item.icon, size: 30, color: color)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(item.name, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 16)),
                                  const SizedBox(height: 3),
                                  Text('${rarityLabel[item.rarity] ?? item.rarity} • ${item.desc}', style: TextStyle(color: color, fontSize: 13, height: 1.55)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Wrap(spacing: 6, runSpacing: 6, children: _itemStats(item).map((text) => StatBadge(text, color: color)).toList()),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Chip3D(text: item.price == 0 ? 'رایگان' : '${item.price}'),
                            const Spacer(),
                            if (equipped)
                              const NeonButton(label: 'انتخاب شد', icon: 'check', small: true)
                            else if (owned)
                              NeonButton(
                                label: 'استفاده',
                                small: true,
                                color: theme.accent,
                                onTap: () async {
                                  await state.equip(item);
                                  if (context.mounted) showNeonMessage(context, '${item.name} انتخاب شد.');
                                },
                              )
                            else
                              NeonButton(
                                label: 'خرید',
                                small: true,
                                color: theme.gold,
                                onTap: () async {
                                  final success = await state.buy(item);
                                  if (!context.mounted) return;
                                  showNeonMessage(context, success ? '${item.name} خریداری شد.' : 'سکه کافی نیست.');
                                },
                              ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<String> _itemStats(Item item) {
    final stats = item.stats;
    final result = <String>[];
    void add(String key, String label, {double defaultValue = 1}) {
      final value = stats[key];
      if (value != null && value != defaultValue) result.add('$label ×${_fmt(value)}');
    }

    add('widthMult', 'عرض');
    add('spinMult', 'اسپین');
    add('moveSpeedMult', 'سرعت حرکت');
    add('speedMult', 'سرعت توپ');
    add('radiusMult', 'اندازه');
    add('powerRate', 'پاورآپ');
    add('speedIncrementMult', 'رشد سرعت');
    add('baseSpeedMult', 'سرعت پایه');
    add('maxSpeedMult', 'حداکثر سرعت');
    add('powerDurationMult', 'مدت پاورآپ');
    add('aiSpeedMult', 'سرعت حریف');
    if ((stats['hitSpeed'] ?? 0) > 0) result.add('سرعت ضربه +${_fmt(stats['hitSpeed']!)}');
    if ((stats['magnet'] ?? 0) > 0) result.add('جذب ملایم توپ');
    if ((stats['startShield'] ?? 0) > 0) result.add('سپر ابتدایی');
    if ((stats['echoSlow'] ?? 0) > 0) result.add('شانس کُندشدن توپ');
    if ((stats['aiErrorBonus'] ?? 0) > 0) result.add('خطای دید حریف');
    if ((stats['coinBonus'] ?? 0) > 0) result.add('سکه +${(stats['coinBonus']! * 100).round()}٪');
    if ((stats['curve'] ?? 0) > 0) result.add('مسیر خمیده');
    if ((stats['minVerticalBonus'] ?? 0) > 0) result.add('کنترل عمودی بیشتر');
    if ((stats['sideInset'] ?? 0) > 0) result.add('زمین باریک‌تر');
    if (result.isEmpty) result.add('آیتم متعادل');
    return result;
  }

  String _fmt(double value) => value == value.roundToDouble() ? value.round().toString() : value.toStringAsFixed(2);
}
