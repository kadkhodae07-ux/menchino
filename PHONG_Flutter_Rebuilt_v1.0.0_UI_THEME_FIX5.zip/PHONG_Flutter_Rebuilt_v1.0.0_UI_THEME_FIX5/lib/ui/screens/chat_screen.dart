import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class ChatScreen extends StatefulWidget {
  final String? initialFriendId;

  const ChatScreen({super.key, this.initialFriendId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _public = true;
  String? _friendId;

  @override
  void initState() {
    super.initState();
    _friendId = widget.initialFriendId;
    _public = _friendId == null;
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final selectedFriend = _findFriend(state);
    final messages = _public
        ? state.publicChat
        : _friendId == null
            ? const <Map<String, dynamic>>[]
            : state.privateChat[_friendId] ?? const <Map<String, dynamic>>[];

    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(
        title: const Text('چت'),
        actions: [
          TextButton(
            onPressed: () async {
              await state.clearChat(isPublic: _public, friendId: _friendId);
              if (mounted) showNeonMessage(context, 'گفتگو پاک شد.');
            },
            child: Text('پاک کردن', style: TextStyle(color: theme.danger)),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: NeonButton(
                      label: 'همگانی',
                      small: true,
                      color: _public ? theme.primary : theme.dim,
                      onTap: () => setState(() {
                        _public = true;
                        _friendId = null;
                      }),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: NeonButton(
                      label: 'خصوصی',
                      small: true,
                      color: !_public ? theme.secondary : theme.dim,
                      onTap: () => setState(() => _public = false),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Expanded(
                child: NeonPanel(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          _public
                              ? 'چت همگانی شبیه‌سازی‌شده'
                              : selectedFriend == null
                                  ? 'یک دوست را انتخاب کن.'
                                  : 'گفتگو با ${selectedFriend['name']}',
                          style: TextStyle(color: theme.dim, fontSize: 12),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Expanded(
                        child: !_public && selectedFriend == null
                            ? ListView.separated(
                                itemCount: state.friends.length,
                                separatorBuilder: (_, __) => const SizedBox(height: 8),
                                itemBuilder: (context, index) {
                                  final friend = state.friends[index];
                                  return InkWell(
                                    borderRadius: BorderRadius.circular(15),
                                    onTap: () => setState(() => _friendId = '${friend['id']}'),
                                    child: Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        color: theme.secondary.withOpacity(.07),
                                        border: Border.all(color: theme.secondary.withOpacity(.18)),
                                      ),
                                      child: Row(
                                        children: [
                                          Container(width: 9, height: 9, decoration: BoxDecoration(shape: BoxShape.circle, color: friend['online'] == true ? theme.accent : theme.dim)),
                                          const SizedBox(width: 10),
                                          Expanded(child: Text('${friend['name']}', style: TextStyle(color: theme.text, fontWeight: FontWeight.w800))),
                                          Text('${(state.privateChat['${friend['id']}'] ?? const []).length} پیام', style: TextStyle(color: theme.dim, fontSize: 11)),
                                          const SizedBox(width: 8),
                                          AppIcons.icon('chat', size: 18, color: theme.secondary),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              )
                            : ListView.builder(
                                controller: _scrollController,
                                itemCount: messages.length,
                                itemBuilder: (context, index) => _bubble(messages[index], theme),
                              ),
                      ),
                      const SizedBox(height: 10),
                      if (_public || selectedFriend != null)
                        Row(
                          children: [
                            if (!_public)
                              IconButton(
                                tooltip: 'تغییر دوست',
                                onPressed: () => setState(() => _friendId = null),
                                icon: AppIcons.icon('friends', color: theme.secondary),
                              ),
                            Expanded(
                              child: TextField(
                                controller: _controller,
                                style: TextStyle(color: theme.text),
                                textInputAction: TextInputAction.send,
                                onSubmitted: (_) => _send(state),
                                decoration: InputDecoration(
                                  hintText: 'پیام...',
                                  hintStyle: TextStyle(color: theme.dim),
                                  filled: true,
                                  fillColor: theme.primary.withOpacity(.06),
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton.filled(
                              onPressed: () => _send(state),
                              style: IconButton.styleFrom(backgroundColor: theme.accent.withOpacity(.22)),
                              icon: AppIcons.icon('send', color: theme.text),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Map<String, dynamic>? _findFriend(AppState state) {
    for (final friend in state.friends) {
      if (friend['id'] == _friendId) return friend;
    }
    return null;
  }

  Widget _bubble(Map<String, dynamic> message, dynamic theme) {
    final me = message['from'] == 'me';
    return Align(
      alignment: me ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 290),
        margin: const EdgeInsets.only(bottom: 9),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: (me ? theme.accent : theme.secondary).withOpacity(.13),
          border: Border.all(color: (me ? theme.accent : theme.secondary).withOpacity(.30)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_public) Text('${message['name'] ?? ''}', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 12)),
            if (_public) const SizedBox(height: 3),
            Text('${message['text'] ?? ''}', style: TextStyle(color: theme.text, height: 1.5)),
            const SizedBox(height: 4),
            Text('${message['time'] ?? ''}', style: TextStyle(color: theme.dim, fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Future<void> _send(AppState state) async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _controller.clear();
    if (_public) {
      await state.sendPublic(text);
      unawaited(Future<void>.delayed(const Duration(milliseconds: 850), state.replyPublic));
    } else if (_friendId != null) {
      final friendId = _friendId!;
      await state.sendPrivate(friendId, text);
      unawaited(Future<void>.delayed(const Duration(milliseconds: 750), () => state.replyPrivate(friendId)));
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOut,
    );
  }
}
