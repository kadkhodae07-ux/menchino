import 'package:flutter_test/flutter_test.dart';
import 'package:phong/core/data.dart';
import 'package:phong/core/theme.dart';

void main() {
  test('catalog identifiers are unique', () {
    final ids = Catalog.all.map((item) => item.id).toList();
    expect(ids.toSet().length, ids.length);
  });

  test('default equipment exists', () {
    expect(Catalog.byId('r_default').type, 'racket');
    expect(Catalog.byId('b_default').type, 'ball');
    expect(Catalog.byId('a_default').type, 'arena');
  });

  test('all themes have unique identifiers', () {
    expect(Themes.all.map((theme) => theme.id).toSet().length, Themes.all.length);
  });
}
