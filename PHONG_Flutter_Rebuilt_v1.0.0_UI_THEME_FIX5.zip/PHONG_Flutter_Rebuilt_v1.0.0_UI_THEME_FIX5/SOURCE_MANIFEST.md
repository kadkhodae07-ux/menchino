# فهرست بسته PHONG

تعداد فایل‌ها: **30**

## فایل‌ها

- `.github/workflows/build-android.yml`
- `QUALITY_REPORT.md`
- `README_FA.md`
- `analysis_options.yaml`
- `lib/core/data.dart`
- `lib/core/icons.dart`
- `lib/core/services/audio_service.dart`
- `lib/core/services/storage_service.dart`
- `lib/core/state/app_state.dart`
- `lib/core/theme.dart`
- `lib/game/engine.dart`
- `lib/main.dart`
- `lib/ui/screens/chat_screen.dart`
- `lib/ui/screens/friends_screen.dart`
- `lib/ui/screens/game_screen.dart`
- `lib/ui/screens/lobby_screen.dart`
- `lib/ui/screens/main_shell.dart`
- `lib/ui/screens/match_setup_dialog.dart`
- `lib/ui/screens/profile_screen.dart`
- `lib/ui/screens/rank_screen.dart`
- `lib/ui/screens/rewards_screen.dart`
- `lib/ui/screens/settings_screen.dart`
- `lib/ui/screens/shop_screen.dart`
- `lib/ui/screens/splash_screen.dart`
- `lib/ui/screens/tournament_screen.dart`
- `lib/ui/widgets/avatar_badge.dart`
- `lib/ui/widgets/neon.dart`
- `pubspec.yaml`
- `test/data_test.dart`
- `tool/materialize_project.sh`

## فایل‌های بازیابی‌شده از HTML

- `settings_screen.dart`
- `friends_screen.dart`
- `chat_screen.dart`

## فایل‌های بازنویسی‌شده اصلی

- `engine.dart`
- `game_screen.dart`
- `app_state.dart`
- `tournament_screen.dart`
- `rewards_screen.dart`
- `profile_screen.dart`
- `rank_screen.dart`
- `shop_screen.dart`
- `main_shell.dart`
- `neon.dart`
