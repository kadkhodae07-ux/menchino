#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required." >&2
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

flutter create --platforms=android --org com.phong.game --project-name phong "$TMP/phong"
rm -rf "$TMP/phong/lib" "$TMP/phong/test"
cp -R "$ROOT/lib" "$TMP/phong/lib"
cp -R "$ROOT/test" "$TMP/phong/test"
cp "$ROOT/pubspec.yaml" "$TMP/phong/pubspec.yaml"
cp "$ROOT/analysis_options.yaml" "$TMP/phong/analysis_options.yaml"
cp -R "$TMP/phong/android" "$ROOT/android"
cp "$TMP/phong/.metadata" "$ROOT/.metadata"
cp "$TMP/phong/.gitignore" "$ROOT/.gitignore"

echo "Android platform files generated in $ROOT/android"
