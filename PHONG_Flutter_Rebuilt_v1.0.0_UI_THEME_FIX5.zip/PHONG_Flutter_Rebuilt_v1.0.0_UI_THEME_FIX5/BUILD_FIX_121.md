# BUILD FIX 121

Run 121 reached flutter analyze successfully. Workflow V3 is working.

Fixed source errors:
- Removed invalid Item.level references from lobby_screen.dart.
- Lobby badges now show equipped item names.
- Removed unused optional parameter solid from neon.dart.

Workflow was not changed.
