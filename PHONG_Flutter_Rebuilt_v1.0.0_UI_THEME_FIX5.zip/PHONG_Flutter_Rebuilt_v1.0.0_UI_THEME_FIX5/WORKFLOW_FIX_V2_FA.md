# اصلاح Workflow V2

- رفع خطای `Expected to find project root in current working directory` با اجرای `flutter pub get` از ریشه پروژه شناسایی‌شده (`$PROJECT_DIR`).
- حفظ اجرای خودکار روی Push فایل ZIP و اجرای دستی.
- `cancel-in-progress: false` برای جلوگیری از توقف اجرای قبلی.
- خروجی موفق: فقط یک APK در Artifact با نام `PHONG-APK`.
- پاک‌سازی Artifactهای قبلی فقط بعد از آپلود موفق APK جدید.
- خروجی خطا: پوشه Diagnostics مستقیماً به GitHub Artifact داده می‌شود تا ZIP تو در تو ساخته نشود.
