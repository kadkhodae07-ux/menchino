import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/material.dart';

import 'app/pulse_arena_app.dart';
import 'core/orientation_manager.dart';
import 'core/persistence/platform_state_store.dart';
import 'game/managers/audio_manager.dart';
import 'player/player_progress_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await OrientationManager.showHome();
  await PlayerProgressController.instance.load();

  final PlayerProgressController progress = PlayerProgressController.instance;
  AudioManager.instance.soundEnabled = progress.soundEnabled;
  AudioManager.instance.musicEnabled = progress.musicEnabled;
  AudioManager.instance.vibrationEnabled = progress.vibrationEnabled;
  await PlatformStateStore.setPreferredFrameRate(progress.frameRate);

  FlameAudio.bgm.initialize();
  await AudioManager.instance.preload();

  runApp(const PulseArenaApp());
}
