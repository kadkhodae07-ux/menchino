import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';

import 'components/arena_component.dart';
import 'components/ball_controller.dart';
import 'components/bot_paddle_controller.dart';
import 'components/player_paddle_controller.dart';
import 'components/shield_component.dart';
import 'config/game_config.dart';
import 'managers/audio_manager.dart';
import 'managers/game_manager.dart';
import 'managers/ui_manager.dart';
import '../player/player_progress_controller.dart';
import 'models/game_view_state.dart';

({Color accent, Color deep, Color detail}) _paddlePalette(String? id) {
  return switch (id) {
    'paddle:phantom' => (
        accent: const Color(0xFFD66F96),
        deep: const Color(0xFF4A123A),
        detail: const Color(0xB86E174E),
      ),
    'paddle:titan' => (
        accent: const Color(0xFFE7BC59),
        deep: const Color(0xFF5A3B08),
        detail: const Color(0xB87A4B08),
      ),
    'paddle:crystal' => (
        accent: const Color(0xFF816FE5),
        deep: const Color(0xFF2B1E68),
        detail: const Color(0xB83C2A86),
      ),
    _ => (
        accent: const Color(0xFF55D4D0),
        deep: const Color(0xFF063F68),
        detail: const Color(0xB8073458),
      ),
  };
}

({Color primary, Color secondary}) _ballPalette(String? id) {
  return switch (id) {
    'ball:solar' => (
        primary: const Color(0xFFFFD56A),
        secondary: const Color(0xFF9F4E13),
      ),
    'ball:shadow' => (
        primary: const Color(0xFF8E79F2),
        secondary: const Color(0xFF21164F),
      ),
    'ball:quantum' => (
        primary: const Color(0xFFE678BA),
        secondary: const Color(0xFF5D1A74),
      ),
    _ => (
        primary: const Color(0xFFB765FF),
        secondary: const Color(0xFF45239F),
      ),
  };
}

Color _effectPalette(String? id) {
  return switch (id) {
    'effect:neon_burst' => const Color(0xFFE86AA9),
    'effect:gold_wave' => const Color(0xFFE7BC59),
    'effect:space_rift' => const Color(0xFF8F79F4),
    _ => const Color(0xFF6BE8FF),
  };
}

class PulseArenaGame extends FlameGame {
  PulseArenaGame({this.config = const GameConfig()})
      : manager = GameManager(config),
        ui = UIManager(
          GameViewState(
            countdown: config.countdownDuration.ceil().clamp(1, 3).toInt(),
            countdownRemaining: config.countdownDuration,
            countdownTotal: config.countdownDuration,
            difficulty: config.difficulty,
            targetScore: config.targetScore,
            shieldUses: config.shieldUses,
            boostUses: config.boostUses,
            pulseUses: config.pulseUses,
          ),
        );

  final GameConfig config;
  final GameManager manager;
  final UIManager ui;
  final math.Random _random = math.Random();

  late final ArenaComponent arenaComponent;
  late final PlayerPaddleController player;
  late final BotPaddleController bot;
  late final BallController ball;
  late final ShieldComponent shield;

  bool _loaded = false;
  bool _pausedFromCountdown = false;
  bool _hasTouched = false;
  double _uiAccumulator = 0;
  double _eventRemaining = 0;
  double _slowFrameDebt = 0;
  bool _reducedEffects = PlayerProgressController.instance.effectsQuality == 0;
  int _lastCountdownLabel = -1;

  ValueListenable<GameViewState> get viewState => ui.state;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    final PlayerProgressController progress = PlayerProgressController.instance;
    final ({Color accent, Color deep, Color detail}) paddlePalette =
        _paddlePalette(progress.selectedItems['paddle']);
    final ({Color primary, Color secondary}) ballPalette =
        _ballPalette(progress.selectedItems['ball']);

    arenaComponent = ArenaComponent();
    player = PlayerPaddleController(
      moveSpeed: config.playerPaddleSpeed,
      acceleration: config.playerPaddleAcceleration,
      response: config.playerResponse,
      accentColor: paddlePalette.accent,
      deepColor: paddlePalette.deep,
      detailColor: paddlePalette.detail,
    );
    ball = BallController(
      config: config,
      primaryColor: ballPalette.primary,
      secondaryColor: ballPalette.secondary,
      trailColor: _effectPalette(progress.selectedItems['effect']),
      effectQuality: progress.effectsQuality,
      onPlayerScored: _playerScored,
      onBotScored: _botScored,
      isShieldActive: () => manager.powers.shieldActive,
      consumeBoost: manager.powers.consumeBoost,
      isBoostArmed: () => manager.powers.boostArmed,
      matchElapsedSeconds: () => manager.match.elapsedSeconds,
      onPaddleHit: _paddleHit,
    );
    bot = BotPaddleController(
      config: config,
      ball: ball,
      playerScore: () => manager.score.playerScore,
      botScore: () => manager.score.botScore,
      isPulseActive: () => manager.powers.pulseActive,
    );
    ball.attachPaddles(player, bot);
    shield = ShieldComponent(player: player, isActive: () => manager.powers.shieldActive);

    await addAll(<Component>[arenaComponent, shield, player, bot, ball]);
    arenaComponent.reducedEffects = _reducedEffects;
    ball.reducedEffects = _reducedEffects;
    _loaded = true;
    _layout(size);
    await AudioManager.instance.startBgm();
    restartMatch();
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    if (_loaded) {
      _layout(size);
    }
  }

  void _layout(Vector2 gameSize) {
    arenaComponent.layout(gameSize);
    final Rect arena = arenaComponent.playRect;
    player.layout(arena);
    bot.layout(arena);
    ball.layout(arena);
    shield.layout(arena);
  }

  @override
  void update(double dt) {
    super.update(dt);
    _updatePerformanceGovernor(dt);
    if (!_loaded ||
        manager.match.isFinished ||
        manager.match.phase == MatchPhase.paused) {
      return;
    }

    final bool countdownCompleted = manager.match.update(dt);
    manager.powers.update(dt);

    if (_eventRemaining > 0) {
      _eventRemaining -= dt;
      if (_eventRemaining <= 0 &&
          manager.match.phase == MatchPhase.playing) {
        manager.eventText = '';
      }
    }

    if (manager.match.isCountdown && manager.match.openingSequence) {
      final int label = manager.match.countdownLabel;
      if (label != _lastCountdownLabel) {
        _lastCountdownLabel = label;
        AudioManager.instance.playCountdown();
        AudioManager.instance.lightImpact();
      }
    }

    if (countdownCompleted) {
      arenaComponent.triggerServe();
      ball.launch();
      manager.eventText = manager.match.openingSequence ? 'نبرد آغاز شد' : '';
      _eventRemaining = manager.match.openingSequence ? 0.8 : 0;
      AudioManager.instance.importantImpact();
    }

    arenaComponent.setRally(manager.stats.currentRally);
    _uiAccumulator += dt;
    if (_uiAccumulator >= 0.25) {
      _uiAccumulator = 0;
      _syncUi();
    }
  }

  void _updatePerformanceGovernor(double dt) {
    if (!_loaded || _reducedEffects) {
      return;
    }
    if (dt > 0.024) {
      _slowFrameDebt += 1;
    } else {
      _slowFrameDebt = math.max(0.0, _slowFrameDebt - 0.65);
    }
    if (_slowFrameDebt < 18) {
      return;
    }
    _reducedEffects = true;
    arenaComponent.reducedEffects = true;
    ball.reducedEffects = true;
  }

  void handleTouch(double y, {int? eventMicros}) {
    if (manager.match.phase == MatchPhase.playing ||
        manager.match.phase == MatchPhase.countdown) {
      _hasTouched = true;
      player.setTargetFromTouch(y, eventMicros: eventMicros);
    }
  }

  void endTouch() {
    player.endTouch();
  }

  bool activatePower(PowerType type) {
    if (manager.match.phase != MatchPhase.playing) {
      return false;
    }
    final bool activated = manager.powers.activate(type);
    if (activated) {
      manager.stats.recordPowerUse();
      manager.eventText = switch (type) {
        PowerType.shield => 'سپر انرژی فعال شد',
        PowerType.boost => 'ضربه بعدی تقویت شد',
        PowerType.pulse => 'سرعت نوا کاهش یافت',
      };
      _eventRemaining = 1.25;
      AudioManager.instance.playPower();
      AudioManager.instance.lightImpact();
      _syncUi();
    }
    return activated;
  }

  void pauseMatch() {
    if (manager.match.phase != MatchPhase.playing &&
        manager.match.phase != MatchPhase.countdown) {
      return;
    }
    _pausedFromCountdown = manager.match.phase == MatchPhase.countdown;
    manager.match.pause();
    pauseEngine();
    _syncUi();
  }

  void resumeMatch() {
    if (manager.match.phase != MatchPhase.paused) {
      return;
    }
    manager.match.resume(wasCountdown: _pausedFromCountdown);
    resumeEngine();
    _syncUi();
  }

  void restartMatch() {
    resumeEngine();
    manager.reset();
    _lastCountdownLabel = -1;
    _hasTouched = false;
    _eventRemaining = 0;
    _slowFrameDebt = 0;
    _reducedEffects = false;
    arenaComponent.reducedEffects = false;
    ball.reducedEffects = false;
    player.movementEnabled = true;
    bot.movementEnabled = true;
    player.resetToCenter();
    bot.resetToCenter();
    ball.resetToCenter(serveDirection: _random.nextBool() ? 1 : -1);
    arenaComponent.resetEffects();
    arenaComponent.triggerServe();
    _syncUi();
  }

  void _paddleHit({required bool player, required bool perfect}) {
    manager.stats.recordPaddleHit(player: player, perfect: perfect);
    arenaComponent.triggerHit(playerHit: player, perfect: perfect);
    if (perfect) {
      manager.eventText = 'ضربه دقیق!';
      _eventRemaining = 0.9;
    } else if (manager.stats.currentRally == 6 || manager.stats.currentRally == 10) {
      manager.eventText = 'رالی ${manager.stats.currentRally} ضربه‌ای';
      _eventRemaining = 0.9;
    }
  }

  void _playerScored() {
    AudioManager.instance.playScore();
    AudioManager.instance.importantImpact();
    arenaComponent.triggerGoal(playerScored: true);
    final MatchWinner? winner = manager.score.addPlayerPoint();
    manager.registerPoint(pointWinner: MatchWinner.player, server: MatchWinner.bot);
    _afterPoint(winner, serveDirection: -1);
  }

  void _botScored() {
    AudioManager.instance.playScore();
    AudioManager.instance.importantImpact();
    arenaComponent.triggerGoal(playerScored: false);
    final MatchWinner? winner = manager.score.addBotPoint();
    manager.registerPoint(pointWinner: MatchWinner.bot, server: MatchWinner.player);
    _afterPoint(winner, serveDirection: 1);
  }

  void _afterPoint(MatchWinner? winner, {required int serveDirection}) {
    if (winner != null) {
      manager.match.finish(winner);
      player.movementEnabled = false;
      bot.movementEnabled = false;
      ball.stop(hide: true);
      if (winner == MatchWinner.player) {
        arenaComponent.triggerVictory();
        AudioManager.instance.playWin();
      } else {
        AudioManager.instance.playLose();
      }
    } else {
      player.resetToCenter();
      bot.resetToCenter();
      ball.resetToCenter(serveDirection: serveDirection);
      manager.match.startCountdown(opening: false);
    }
    _syncUi();
  }

  void toggleSound() {
    final bool enabled = !AudioManager.instance.soundEnabled;
    AudioManager.instance.setSoundEnabled(enabled);
    PlayerProgressController.instance.setSoundEnabled(enabled);
    _syncUi();
  }

  void toggleVibration() {
    final bool enabled = !AudioManager.instance.vibrationEnabled;
    AudioManager.instance.vibrationEnabled = enabled;
    PlayerProgressController.instance.setVibrationEnabled(enabled);
    _syncUi();
  }

  void _syncUi() {
    ui.update(
      manager.makeViewState(
        soundEnabled: AudioManager.instance.soundEnabled,
        vibrationEnabled: AudioManager.instance.vibrationEnabled,
        showControlHint: !_hasTouched && manager.match.elapsedSeconds < 6,
      ),
    );
  }

  @override
  void onRemove() {
    ui.dispose();
    super.onRemove();
  }
}
