import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/services.dart';

class AudioManager {
  AudioManager._();

  static final AudioManager instance = AudioManager._();

  bool soundEnabled = true;
  bool musicEnabled = true;
  bool vibrationEnabled = true;
  bool _bgmStarted = false;
  int _lastHapticMicros = 0;
  final Map<String, int> _lastSoundMicros = <String, int>{};

  static const List<String> _sounds = <String>[
    'button.wav',
    'paddle.wav',
    'wall.wav',
    'score.wav',
    'power.wav',
    'win.wav',
    'lose.wav',
    'countdown.wav',
    'perfect.wav',
    'arena_loop.wav',
  ];

  Future<void> preload() async {
    try {
      await FlameAudio.audioCache.loadAll(_sounds);
    } catch (_) {
      // Audio failure must never block gameplay.
    }
  }

  Future<void> startBgm() async {
    if (!musicEnabled || _bgmStarted) return;
    try {
      await FlameAudio.bgm.play('arena_loop.wav', volume: 0.20);
      _bgmStarted = true;
    } catch (_) {
      _bgmStarted = false;
    }
  }

  Future<void> stopBgm() async {
    try {
      await FlameAudio.bgm.stop();
    } catch (_) {
      // Ignore unavailable audio backends.
    }
    _bgmStarted = false;
  }

  Future<void> setSoundEnabled(bool enabled) async {
    soundEnabled = enabled;
  }

  Future<void> setMusicEnabled(bool enabled) async {
    musicEnabled = enabled;
    if (enabled) {
      await startBgm();
    } else {
      await stopBgm();
    }
  }

  Future<void> playButton() =>
      _play('button.wav', volume: 0.40, minimumGapMs: 90);
  Future<void> playPaddle() =>
      _play('paddle.wav', volume: 0.46, minimumGapMs: 55);
  Future<void> playPerfect() =>
      _play('perfect.wav', volume: 0.60, minimumGapMs: 90);
  Future<void> playCountdown() =>
      _play('countdown.wav', volume: 0.53, minimumGapMs: 180);
  Future<void> playWall() =>
      _play('wall.wav', volume: 0.25, minimumGapMs: 65);
  Future<void> playScore() =>
      _play('score.wav', volume: 0.56, minimumGapMs: 250);
  Future<void> playPower() =>
      _play('power.wav', volume: 0.54, minimumGapMs: 120);
  Future<void> playWin() =>
      _play('win.wav', volume: 0.66, minimumGapMs: 500);
  Future<void> playLose() =>
      _play('lose.wav', volume: 0.60, minimumGapMs: 500);

  Future<void> _play(
    String fileName, {
    double volume = 1,
    int minimumGapMs = 0,
  }) async {
    if (!soundEnabled) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    final int last = _lastSoundMicros[fileName] ?? 0;
    if (minimumGapMs > 0 && now - last < minimumGapMs * 1000) return;
    _lastSoundMicros[fileName] = now;
    try {
      await FlameAudio.play(fileName, volume: volume);
    } catch (_) {
      // Keep gameplay functional even when a device audio backend fails.
    }
  }

  Future<void> lightImpact() async {
    if (!vibrationEnabled) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    if (now - _lastHapticMicros < 85000) return;
    _lastHapticMicros = now;
    await HapticFeedback.lightImpact();
  }

  Future<void> importantImpact() async {
    if (!vibrationEnabled) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    if (now - _lastHapticMicros < 120000) return;
    _lastHapticMicros = now;
    await HapticFeedback.mediumImpact();
  }
}
