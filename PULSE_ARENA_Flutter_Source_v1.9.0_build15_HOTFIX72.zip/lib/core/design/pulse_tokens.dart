import 'package:flutter/material.dart';

/// Shared visual language for every production screen in PULSE ARENA.
abstract final class PulseColors {
  static const Color voidBlack = Color(0xFF01030A);
  static const Color deepNavy = Color(0xFF040916);
  static const Color panelTop = Color(0xFF111A2A);
  static const Color panelBottom = Color(0xFF070C16);
  static const Color panelInset = Color(0xFF050A13);
  static const Color cyan = Color(0xFF54D7D1);
  static const Color blue = Color(0xFF48B9E8);
  static const Color violet = Color(0xFF816FE5);
  static const Color rose = Color(0xFFD66F96);
  static const Color gold = Color(0xFFE7BC59);
  static const Color danger = Color(0xFFE36B77);
  static const Color textPrimary = Color(0xFFF0F5FF);
  static const Color textSecondary = Color(0xFF9AA9C2);
  static const Color textMuted = Color(0xFF697894);
  static const Color divider = Color(0xFF1B2A40);
}

abstract final class PulseDurations {
  static const Duration press = Duration(milliseconds: 95);
  static const Duration micro = Duration(milliseconds: 150);
  static const Duration page = Duration(milliseconds: 190);
  static const Duration dialog = Duration(milliseconds: 220);
}

abstract final class PulseTypography {
  static const TextStyle title = TextStyle(
    color: PulseColors.textPrimary,
    fontSize: 21,
    fontWeight: FontWeight.w900,
    height: 1.1,
  );

  static const TextStyle section = TextStyle(
    color: PulseColors.textPrimary,
    fontSize: 15,
    fontWeight: FontWeight.w900,
    height: 1.15,
  );

  static const TextStyle body = TextStyle(
    color: PulseColors.textSecondary,
    fontSize: 12,
    fontWeight: FontWeight.w700,
    height: 1.35,
  );

  static const TextStyle label = TextStyle(
    color: PulseColors.textPrimary,
    fontSize: 12,
    fontWeight: FontWeight.w900,
    height: 1.1,
  );
}

ThemeData buildPulseArenaTheme() {
  final ColorScheme scheme = ColorScheme.fromSeed(
    seedColor: PulseColors.cyan,
    brightness: Brightness.dark,
    surface: PulseColors.deepNavy,
    error: PulseColors.danger,
  );
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    scaffoldBackgroundColor: PulseColors.voidBlack,
    colorScheme: scheme,
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    hoverColor: Colors.transparent,
    focusColor: PulseColors.cyan.withValues(alpha: .12),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: PulseColors.cyan,
      selectionColor: PulseColors.cyan.withValues(alpha: .24),
      selectionHandleColor: PulseColors.cyan,
    ),
  );
}
