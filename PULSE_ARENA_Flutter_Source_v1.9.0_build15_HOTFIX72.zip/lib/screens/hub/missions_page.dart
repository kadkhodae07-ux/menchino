part of '../hub_screen.dart';

class _MissionsPage extends StatefulWidget {
  const _MissionsPage({
    required this.progress,
    required this.onMessage,
    super.key,
  });

  final PlayerProgressController progress;
  final ValueChanged<String> onMessage;

  @override
  State<_MissionsPage> createState() => _MissionsPageState();
}

class _MissionsPageState extends State<_MissionsPage> {
  int _segment = 0;

  List<_MissionData> _missions() {
    final PlayerProgressController progress = widget.progress;
    if (_segment == 0) {
      return <_MissionData>[
        _MissionData(
          progress.missionClaimId('daily', 'matches'),
          'سه نبرد کامل',
          '۳ مسابقه انجام بده',
          progress.dailyMatchesProgress.clamp(0, 3).toInt(),
          3,
          120,
          Icons.sports_esports_rounded,
        ),
        _MissionData(
          progress.missionClaimId('daily', 'perfect'),
          'پالس دقیق',
          '۱۰ ضربه دقیق ثبت کن',
          progress.dailyPerfectHitsProgress.clamp(0, 10).toInt(),
          10,
          80,
          Icons.track_changes_rounded,
        ),
        _MissionData(
          progress.missionClaimId('daily', 'power'),
          'توان آرنا',
          '۲ قدرت ویژه استفاده کن',
          progress.dailyPowersProgress.clamp(0, 2).toInt(),
          2,
          60,
          Icons.shield_rounded,
        ),
      ];
    }
    return <_MissionData>[
      _MissionData(
        progress.missionClaimId('weekly', 'wins'),
        'قهرمان هفته',
        '۲۰ مسابقه را برنده شو',
        progress.weeklyWinsProgress.clamp(0, 20).toInt(),
        20,
        600,
        Icons.emoji_events_rounded,
      ),
      _MissionData(
        progress.missionClaimId('weekly', 'goals'),
        'نبرد طولانی',
        '۱۰۰ گل در مجموع ثبت کن',
        progress.weeklyGoalsProgress.clamp(0, 100).toInt(),
        100,
        450,
        Icons.timeline_rounded,
      ),
      _MissionData(
        progress.missionClaimId('weekly', 'powers'),
        'استاد تقویت',
        '۱۵ قدرت ویژه اجرا کن',
        progress.weeklyPowersProgress.clamp(0, 15).toInt(),
        15,
        350,
        Icons.bolt_rounded,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final List<_MissionData> missions = _missions();
    final int available = missions.where((m) {
      return m.current >= m.target &&
          !widget.progress.claimedMissions.contains(m.id);
    }).length;
    final int rewards = missions.fold<int>(0, (int total, _MissionData mission) {
      if (widget.progress.claimedMissions.contains(mission.id)) return total;
      return total + mission.reward;
    });

    return _PageScaffold(
      title: 'ماموریت‌ها',
      subtitle: 'پاداش‌های آفلاین متصل به عملکرد واقعی شما',
      icon: Icons.track_changes_rounded,
      colors: const <Color>[PulseColors.violet, PulseColors.rose],
      children: <Widget>[
        PulsePanel(
          colors: const <Color>[PulseColors.cyan, PulseColors.rose],
          cut: 22,
          padding: const EdgeInsets.fromLTRB(15, 13, 15, 15),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: _MetricPanel(
                      value: '$available',
                      label: 'آماده دریافت',
                      icon: Icons.bolt_rounded,
                      color: PulseColors.gold,
                      compact: true,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _MetricPanel(
                      value: _groupDigits(rewards),
                      label: 'پاداش باقی‌مانده',
                      icon: Icons.motion_photos_on_rounded,
                      color: PulseColors.rose,
                      compact: true,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _SegmentButton(
                      label: 'روزانه',
                      selected: _segment == 0,
                      color: PulseColors.cyan,
                      onTap: () => setState(() => _segment = 0),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _SegmentButton(
                      label: 'هفتگی',
                      selected: _segment == 1,
                      color: PulseColors.rose,
                      onTap: () => setState(() => _segment = 1),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 13),
        for (int i = 0; i < missions.length; i++) ...<Widget>[
          _MissionTile(
            data: missions[i],
            claimed: widget.progress.claimedMissions.contains(missions[i].id),
            onTap: () {
              final _MissionData mission = missions[i];
              if (mission.current < mission.target) {
                widget.onMessage('این ماموریت هنوز کامل نشده است');
                return;
              }
              final bool claimed = widget.progress.claimMission(
                mission.id,
                mission.reward,
              );
              widget.onMessage(
                claimed
                    ? '${mission.reward} پالس به حساب محلی اضافه شد'
                    : 'پاداش این ماموریت قبلاً دریافت شده است',
              );
            },
          ),
          if (i != missions.length - 1) const SizedBox(height: 10),
        ],
      ],
    );
  }
}
