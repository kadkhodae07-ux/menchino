part of '../hub_screen.dart';

class _SettingsScreen extends StatefulWidget {
  const _SettingsScreen({required this.initialDifficulty});

  final BotDifficulty initialDifficulty;

  @override
  State<_SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<_SettingsScreen> {
  final PlayerProgressController _progress = PlayerProgressController.instance;
  late BotDifficulty _difficulty;

  @override
  void initState() {
    super.initState();
    _difficulty = widget.initialDifficulty;
  }

  Future<void> _showInfo(String title, String body) async {
    await showDialog<void>(
      context: context,
      barrierColor: const Color(0xCC01030A),
      builder: (BuildContext dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 28),
          child: PulsePanel(
            colors: const <Color>[PulseColors.cyan, PulseColors.violet],
            cut: 22,
            padding: const EdgeInsets.all(17),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: PulseTypography.title,
                ),
                const SizedBox(height: 12),
                Text(
                  body,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: PulseTypography.body,
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: _GraphicButton(
                    label: 'متوجه شدم',
                    icon: Icons.check_rounded,
                    colors: const <Color>[PulseColors.cyan, PulseColors.violet],
                    onTap: () => Navigator.of(dialogContext).pop(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PulseColors.voidBlack,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const RepaintBoundary(
            child: CustomPaint(painter: _HubBackgroundPainter()),
          ),
          SafeArea(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
                  child: PulsePanel(
                    colors: const <Color>[PulseColors.cyan, PulseColors.rose],
                    cut: 20,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    child: Row(
                      children: <Widget>[
                        _MiniIconButton(
                          icon: Icons.arrow_back_rounded,
                          color: PulseColors.cyan,
                          onTap: () => Navigator.of(context).pop(_difficulty),
                        ),
                        const Expanded(
                          child: Column(
                            children: <Widget>[
                              Text(
                                'تنظیمات',
                                textDirection: TextDirection.rtl,
                                style: PulseTypography.title,
                              ),
                              Text(
                                'کنترل عملکرد، صدا و تجربه مسابقه',
                                textDirection: TextDirection.rtl,
                                style: PulseTypography.body,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(14, 8, 14, 18),
                    child: Column(
                      children: <Widget>[
                        const _SectionTitle(
                          title: 'سطح ربات',
                          icon: Icons.smart_toy_rounded,
                          color: PulseColors.cyan,
                        ),
                        const SizedBox(height: 10),
                        for (final BotDifficulty value in BotDifficulty.values) ...<Widget>[
                          _DifficultyTile(
                            value: value,
                            selected: value == _difficulty,
                            onTap: () {
                              setState(() => _difficulty = value);
                              _progress.setDifficulty(value);
                            },
                          ),
                          const SizedBox(height: 9),
                        ],
                        const SizedBox(height: 5),
                        const _SectionTitle(
                          title: 'صدا و بازخورد',
                          icon: Icons.tune_rounded,
                          color: PulseColors.rose,
                        ),
                        const SizedBox(height: 10),
                        _SettingToggleTile(
                          icon: Icons.surround_sound_rounded,
                          label: 'افکت‌های صوتی',
                          subtitle: 'برخورد، گل، قدرت‌ها و اعلام نتیجه',
                          enabled: _progress.soundEnabled,
                          color: PulseColors.cyan,
                          onTap: () async {
                            final bool enabled = !_progress.soundEnabled;
                            _progress.setSoundEnabled(enabled);
                            await AudioManager.instance.setSoundEnabled(enabled);
                            if (mounted) setState(() {});
                          },
                        ),
                        const SizedBox(height: 9),
                        _SettingToggleTile(
                          icon: Icons.music_note_rounded,
                          label: 'موسیقی محیطی',
                          subtitle: 'صدای پس‌زمینه کم‌حجم Arena',
                          enabled: _progress.musicEnabled,
                          color: PulseColors.violet,
                          onTap: () async {
                            final bool enabled = !_progress.musicEnabled;
                            _progress.setMusicEnabled(enabled);
                            await AudioManager.instance.setMusicEnabled(enabled);
                            if (mounted) setState(() {});
                          },
                        ),
                        const SizedBox(height: 9),
                        _SettingToggleTile(
                          icon: Icons.vibration_rounded,
                          label: 'بازخورد لرزشی',
                          subtitle: 'لرزش کوتاه و کنترل‌شده هنگام برخورد و لمس',
                          enabled: _progress.vibrationEnabled,
                          color: PulseColors.rose,
                          onTap: () {
                            final bool enabled = !_progress.vibrationEnabled;
                            _progress.setVibrationEnabled(enabled);
                            AudioManager.instance.vibrationEnabled = enabled;
                            setState(() {});
                          },
                        ),
                        const SizedBox(height: 14),
                        const _SectionTitle(
                          title: 'عملکرد و تصویر',
                          icon: Icons.speed_rounded,
                          color: PulseColors.gold,
                        ),
                        const SizedBox(height: 10),
                        PulsePanel(
                          colors: const <Color>[PulseColors.gold, PulseColors.violet],
                          cut: 19,
                          padding: const EdgeInsets.all(13),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: <Widget>[
                              const Text(
                                'کیفیت افکت‌ها',
                                textDirection: TextDirection.rtl,
                                style: PulseTypography.section,
                              ),
                              const SizedBox(height: 9),
                              Row(
                                children: <Widget>[
                                  for (int i = 0; i < 3; i++) ...<Widget>[
                                    Expanded(
                                      child: _SegmentButton(
                                        label: const <String>['اقتصادی', 'متعادل', 'کامل'][i],
                                        selected: _progress.effectsQuality == i,
                                        color: i == 0
                                            ? PulseColors.blue
                                            : i == 1
                                                ? PulseColors.cyan
                                                : PulseColors.gold,
                                        onTap: () {
                                          _progress.setEffectsQuality(i);
                                          setState(() {});
                                        },
                                      ),
                                    ),
                                    if (i != 2) const SizedBox(width: 7),
                                  ],
                                ],
                              ),
                              const SizedBox(height: 13),
                              const Text(
                                'نرخ فریم هدف',
                                textDirection: TextDirection.rtl,
                                style: PulseTypography.section,
                              ),
                              const SizedBox(height: 9),
                              Row(
                                children: <Widget>[
                                  Expanded(
                                    child: _SegmentButton(
                                      label: '۶۰ FPS پایدار',
                                      selected: _progress.frameRate == 60,
                                      color: PulseColors.cyan,
                                      onTap: () {
                                        _progress.setFrameRate(60);
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: _SegmentButton(
                                      label: '۹۰ FPS سازگار',
                                      selected: _progress.frameRate == 90,
                                      color: PulseColors.violet,
                                      onTap: () {
                                        _progress.setFrameRate(90);
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        const PulsePanel(
                          colors: <Color>[PulseColors.gold, PulseColors.rose],
                          cut: 20,
                          padding: EdgeInsets.all(14),
                          child: Row(
                            children: <Widget>[
                              Icon(Icons.info_rounded, color: PulseColors.gold, size: 30),
                              SizedBox(width: 11),
                              Expanded(
                                child: Text(
                                  'قانون مسابقه: هر بازیکنی که زودتر ۱۰ گل دریافت کند، بازنده است.',
                                  textDirection: TextDirection.rtl,
                                  textAlign: TextAlign.right,
                                  style: PulseTypography.body,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: _GraphicButton(
                                label: 'راهنمای کنترل',
                                icon: Icons.touch_app_rounded,
                                colors: const <Color>[PulseColors.cyan, PulseColors.blue],
                                onTap: () => _showInfo(
                                  'راهنمای کنترل',
                                  'انگشت را روی نیمه بازیکن قرار بده و عمودی حرکت بده. راکت بدون ژست اضافی موقعیت انگشت را دنبال می‌کند. قدرت‌ها از نوار پایین فعال می‌شوند و هرکدام تعداد استفاده محدود دارند.',
                                ),
                              ),
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: _GraphicButton(
                                label: 'حریم خصوصی',
                                icon: Icons.privacy_tip_rounded,
                                colors: const <Color>[PulseColors.violet, PulseColors.rose],
                                onTap: () => _showInfo(
                                  'حریم خصوصی',
                                  'نسخه فعلی آفلاین است. پیشرفت، تنظیمات، خریدهای درون‌بازی محلی و نتایج مسابقه فقط در حافظه داخلی همین دستگاه ذخیره می‌شوند و به سرور ارسال نمی‌شوند.',
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'PULSE ARENA • 1.9.0+15',
                          textDirection: TextDirection.ltr,
                          style: TextStyle(
                            color: PulseColors.textMuted,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 14),
                        _GraphicButton(
                          label: 'ذخیره و بازگشت',
                          icon: Icons.check_circle_rounded,
                          colors: const <Color>[PulseColors.cyan, PulseColors.rose],
                          tall: true,
                          onTap: () => Navigator.of(context).pop(_difficulty),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
