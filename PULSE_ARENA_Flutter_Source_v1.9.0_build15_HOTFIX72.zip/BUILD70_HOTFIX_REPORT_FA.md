# گزارش اصلاح Build 70 — PULSE ARENA

## وضعیت نسخه

- نسخه برنامه: `1.9.0+15`
- نسخه Workflow: `WF10`
- Package Name: `com.manyshah.pulsearena`
- Flavorها: `bazaar` و `myket`

**Workflow تغییری نکرده** و شماره آن افزایش نیافته است.

## علت شکست Build 70

Workflow از مرحله `dart format` و `flutter analyze` عبور کرد و در `flutter test` متوقف شد.

نتیجه ثبت‌شده در لاگ:

- 29 تست موفق
- 3 تست ناموفق

هر سه شکست مربوط به تست‌های متنی شکننده در فایل `test/release_readiness_v190_test.dart` بودند و خرابی منطق مسابقه یا Flavorها نبودند:

1. نام کامپوننت اختصاصی `_ProfileCard(` به‌اشتباه به‌عنوان استفاده از `Card(` پیش‌فرض Flutter تشخیص داده شد.
2. تست رتبه‌بندی منتظر متن قدیمی بود، درحالی‌که صفحه ماژولار رتبه‌بندی متن شفاف‌تر «هیچ بازیکن زنده یا اتصال سرور را شبیه‌سازی نمی‌کند» را نمایش می‌دهد.
3. تست Loadout منتظر دسترسی مستقیم `PlayerProgressController.instance.selectedItems` بود، درحالی‌که کد تولیدی ابتدا Singleton را در متغیر محلی `progress` نگه می‌دارد و سپس از `progress.selectedItems` استفاده می‌کند.

## اصلاحات انجام‌شده

- تشخیص کنترل‌های پیش‌فرض Flutter از جست‌وجوی ساده رشته‌ای به تشخیص سازنده واقعی تغییر کرد؛ نام‌هایی مانند `_ProfileCard` دیگر False Positive ایجاد نمی‌کنند.
- انتظار تست وضعیت آفلاین با متن واقعی صفحه رتبه‌بندی همگام شد.
- تست اعمال Loadout اکنون مسیر واقعی Paddle، Ball و Effect را جداگانه بررسی می‌کند.
- 7 مورد گزارش‌شده توسط `flutter analyze` اصلاح شد:
  - افزودن آکولاد به Control Flowهای تک‌خطی
  - حذف `return` از بلوک `finally`
  - استفاده از سازنده `const` در بخش قابل‌ثابت
- هیچ منطق مسابقه، قانون 10 گل، Physics، Persistence، Flavor یا Package Name تغییر نکرد.

## فایل‌های تغییرکرده

- `test/release_readiness_v190_test.dart`
- `lib/game/pulse_arena_game.dart`
- `lib/screens/game_screen.dart`
- `lib/screens/hub_screen.dart`
- `lib/screens/hub/ranking_page.dart`

## اعتبارسنجی انجام‌شده در محیط فعلی

- اعتبارسنجی مستقل Release: موفق
- نسخه و Package Name: موفق
- Flavorهای بازار و مایکت: موفق
- قانون 10 گل و Fixed-Step Physics: موفق
- Persistence و ماژولار بودن Hub: موفق
- نبود کنترل‌های پیش‌فرض در UI تولیدی: موفق
- XMLهای Android و Assetهای Branding: موفق
- بازاجرای منطقی سه Assertion شکست‌خورده با محتوای اصلاح‌شده: موفق
- سلامت ساختار ZIP: موفق

Flutter و Android SDK در محیط محلی فعلی نصب نیست؛ بنابراین اجرای واقعی `flutter analyze`، `flutter test` و Build دو APK باید توسط همان WF10 در GitHub Actions انجام شود.
