# گزارش اصلاح Build 72 — PULSE ARENA

## نتیجه بررسی لاگ

Workflow Run: `30521345861`

فایل مبنا در اجرای ناموفق:

`PULSE_ARENA_Flutter_Source_v1.9.0_build15_HOTFIX70.zip`

مراحل زیر در GitHub Actions با موفقیت عبور کرده بودند:

- `dart format`
- `flutter analyze` با نتیجه `No issues found`
- `flutter test` با نتیجه `32 tests passed`
- Release Readiness Validation
- Android Configuration Validation

شکست در مرحله زیر رخ داد:

`flutter build apk --release --flavor bazaar`

## علت قطعی خطا

AAPT در مرحله `:app:processBazaarReleaseResources` نتوانست رنگ مستقیم زیر را به‌عنوان Drawable تفسیر کند:

`android:drawable="#050A15"`

فایل خطادار:

`android/app/src/main/res/drawable-v21/launch_background.xml`

پیام اصلی:

`'#050A15' is incompatible with attribute drawable (attr) reference.`

همین ساختار در مسیر عمومی `drawable/launch_background.xml` نیز وجود داشت و برای جلوگیری از شکست بعدی هر دو فایل اصلاح شدند.

## اصلاح انجام‌شده

فایل جدید زیر ایجاد شد:

`android/app/src/main/res/values/colors.xml`

رنگ Splash با نام زیر تعریف شد:

`launch_background_color`

در هر دو فایل Launch Background، مقدار مستقیم رنگ با مرجع استاندارد زیر جایگزین شد:

`@color/launch_background_color`

## وضعیت نسخه

- نسخه برنامه: `1.9.0+15`
- Package Name: `com.manyshah.pulsearena`
- Flavor بازار: حفظ شد
- Flavor مایکت: حفظ شد
- Workflow: `WF10`

**Workflow تغییری نکرده**

فایل YAML یا رفتار اجرایی Workflow تغییر داده نشده است؛ بنابراین افزایش نسخه Workflow لازم نیست.

## اعتبارسنجی پس از اصلاح

- تمام XMLهای Android با XML Parser معتبر هستند.
- هیچ نمونه دیگری از `android:drawable="#..."` در منابع Android باقی نمانده است.
- هر دو Launch Background به منبع رنگ معتبر ارجاع می‌دهند.
- اعتبارسنجی مستقل `tool/validate_release.py` کامل عبور کرد.
- نسخه، Package Name، دو Flavor، قانون ۱۰ گل، فیزیک و Persistence بدون تغییر باقی ماندند.

## محدودیت محیط فعلی

در محیط فعلی Flutter SDK و Android SDK نصب نیست؛ بنابراین Build APK پس از اصلاح در همین محیط اجرا نشد. اجرای Build 72 اثبات می‌کند Format، Analyze و تمام ۳۲ تست پیش از رسیدن به خطای AAPT موفق بوده‌اند. فایل HOTFIX72 باید با همان WF10 مجدداً اجرا شود تا APK بازار و سپس مایکت ساخته شوند.
