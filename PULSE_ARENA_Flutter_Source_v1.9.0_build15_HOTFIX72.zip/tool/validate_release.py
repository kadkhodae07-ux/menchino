#!/usr/bin/env python3
"""Dependency-free structural release checks for PULSE ARENA."""

from __future__ import annotations

import re
import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FAILURES: list[str] = []


def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        FAILURES.append(f"missing file: {path}")
        return ""
    return file.read_text(encoding="utf-8")


def check(name: str, condition: bool) -> None:
    print(f"{'PASS' if condition else 'FAIL'}: {name}")
    if not condition:
        FAILURES.append(name)


def png_size(path: Path) -> tuple[int, int] | None:
    if not path.is_file():
        return None
    data = path.read_bytes()[:24]
    if len(data) != 24 or data[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return struct.unpack(">II", data[16:24])


def strip_dart_comments_and_strings(source: str) -> tuple[str, bool]:
    output: list[str] = []
    index = 0
    state = "code"
    quote = ""
    triple = False
    while index < len(source):
        char = source[index]
        following = source[index + 1] if index + 1 < len(source) else ""
        if state == "code":
            if char == "/" and following == "/":
                state = "line"
                output.extend("  ")
                index += 2
            elif char == "/" and following == "*":
                state = "block"
                output.extend("  ")
                index += 2
            elif char in "'\"":
                quote = char
                triple = source[index : index + 3] == char * 3
                state = "string"
                width = 3 if triple else 1
                output.extend(" " * width)
                index += width
            else:
                output.append(char)
                index += 1
        elif state == "line":
            output.append("\n" if char == "\n" else " ")
            if char == "\n":
                state = "code"
            index += 1
        elif state == "block":
            if char == "*" and following == "/":
                output.extend("  ")
                state = "code"
                index += 2
            else:
                output.append("\n" if char == "\n" else " ")
                index += 1
        else:
            if char == "\\":
                output.extend("  ")
                index += 2
            elif triple and source[index : index + 3] == quote * 3:
                output.extend("   ")
                state = "code"
                index += 3
            elif not triple and char == quote:
                output.append(" ")
                state = "code"
                index += 1
            else:
                output.append("\n" if char == "\n" else " ")
                index += 1
    return "".join(output), state in {"code", "line"}


def dart_structure_is_valid() -> bool:
    pairs = {")": "(", "]": "[", "}": "{"}
    for path in [*ROOT.glob("lib/**/*.dart"), *ROOT.glob("test/**/*.dart")]:
        source = path.read_text(encoding="utf-8")
        cleaned, terminated = strip_dart_comments_and_strings(source)
        if not terminated:
            return False
        stack: list[str] = []
        for char in cleaned:
            if char in "([{":
                stack.append(char)
            elif char in ")]}":
                if not stack or stack.pop() != pairs[char]:
                    return False
        if stack:
            return False
        for match in re.finditer(
            r"^\s*(?:import|export|part)\s+['\"]([^'\"]+)['\"]",
            source,
            re.MULTILINE,
        ):
            target = match.group(1)
            if target.startswith(("dart:", "package:")):
                continue
            if not (path.parent / target).resolve().exists():
                return False
    return True


def main() -> int:
    pubspec = read("pubspec.yaml")
    gradle = read("android/app/build.gradle.kts")
    workflow = read(".github/workflows/build-apk.yml")
    config = read("lib/game/config/game_config.dart")
    ball = read("lib/game/components/ball_controller.dart")
    hub = read("lib/screens/hub_screen.dart") + "\n" + "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted((ROOT / "lib/screens/hub").glob("*.dart"))
    )
    game_screen = read("lib/screens/game_screen.dart")
    production_ui = hub + "\n" + game_screen
    state = read("lib/player/player_progress_controller.dart")
    activity = read(
        "android/app/src/main/kotlin/com/manyshah/pulsearena/MainActivity.kt"
    )

    check("version is 1.9.0+15", "version: 1.9.0+15" in pubspec)
    check(
        "package name is preserved",
        'applicationId = "com.manyshah.pulsearena"' in gradle,
    )
    check(
        "Bazaar and Myket flavors exist",
        'create("bazaar")' in gradle and 'create("myket")' in gradle,
    )
    check("workflow is WF10", "Build PULSE ARENA APK - WF10" in workflow)
    check("ten-goal rule is preserved", "this.targetScore = 10" in config)
    check(
        "fixed-step bounded physics remains enabled",
        "_physicsStep = 1 / 120" in ball and "iterations < 6" in ball,
    )
    check(
        "local progression is persistent",
        all(
            token in state
            for token in (
                "claimedMissions",
                "purchasedItems",
                "selectedItems",
                "recentMatches",
                "recordMatch",
            )
        )
        and "getSharedPreferences" in activity,
    )
    check(
        "hub is modular",
        all(
            (ROOT / path).is_file()
            for path in (
                "lib/screens/hub/profile_page.dart",
                "lib/screens/hub/missions_page.dart",
                "lib/screens/hub/ranking_page.dart",
                "lib/screens/hub/shop_page.dart",
                "lib/screens/hub/settings_page.dart",
            )
        ),
    )
    check(
        "default Flutter controls are absent from production UI",
        not re.search(
            r"\b(?:Card|ElevatedButton|FilledButton|OutlinedButton|TextButton|"
            r"IconButton|LinearProgressIndicator|CircularProgressIndicator|Switch|"
            r"Slider|InkWell)\s*(?:\.|\()",
            production_ui,
        ),
    )
    check(
        "no visible demo placeholders remain",
        not re.search(
            r"(?:Lorem Ipsum|Coming Soon|\bDEMO\b|\bDemo\b|\bTODO\b|"
            r"کاربر آزمایشی|به زودی)",
            "\n".join(
                path.read_text(encoding="utf-8")
                for path in ROOT.glob("lib/**/*.dart")
            ),
        ),
    )
    check("Dart source structure is balanced", dart_structure_is_valid())

    xml_valid = True
    for path in (ROOT / "android").glob("**/*.xml"):
        try:
            ET.parse(path)
        except ET.ParseError:
            xml_valid = False
    check("Android XML resources parse", xml_valid)

    check(
        "production icon is 1024x1024",
        png_size(ROOT / "assets/branding/pulse_arena_icon_1024.png")
        == (1024, 1024),
    )
    check(
        "production splash mark exists",
        png_size(ROOT / "assets/branding/pulse_arena_splash_mark.png")
        == (768, 768),
    )

    if FAILURES:
        print("\nRelease validation failed:")
        for failure in FAILURES:
            print(f"- {failure}")
        return 1
    print("\nAll dependency-free release checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
