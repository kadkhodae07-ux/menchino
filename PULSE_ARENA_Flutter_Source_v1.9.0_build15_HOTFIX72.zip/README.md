# PULSE ARENA — نسخه حرفه‌ای 1.9.0+15

پروژه کامل Flutter + Flame بازی PULSE ARENA با Package Name ثابت زیر:

`com.manyshah.pulsearena`

## وضعیت نسخه

- نسخه برنامه: `1.9.0+15`
- Workflow: `WF10`
- خروجی‌های هدف: APK جداگانه بازار و مایکت
- منطق مسابقه: اولین بازیکن با ۱۰ گل برنده است
- حالت فعلی رتبه‌بندی: کاملاً آفلاین و بدون نمایش جعلی سرور یا بازیکن زنده

## ارتقاهای اصلی

- Design System اختصاصی با پنل‌های چندلایه، لبه‌های تراش‌خورده و کنترل‌های گرافیکی
- تفکیک صفحه بزرگ Hub به ماژول‌های پروفایل، مأموریت‌ها، رتبه‌بندی، فروشگاه و تنظیمات
- ذخیره محلی نام، سطح، XP، ارزها، آمار، مأموریت‌ها، خریدها، Loadout، تنظیمات و تاریخچه مسابقات
- اتصال اسکین راکت، توپ و افکت انتخاب‌شده به رندر واقعی مسابقه
- HUD اختصاصی بدون ProgressIndicatorهای پیش‌فرض Flutter
- آیکن و Splash اختصاصی PULSE ARENA
- حفظ کنترل مستقیم انگشت، فیزیک Fixed-Step، ربات‌ها، قدرت‌ها و قانون امتیاز ۱۰
- کنترل کیفیت افکت و ترجیح نرخ تازه‌سازی ۶۰/۹۰ هرتز روی Android

## اجرای محلی

```bash
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release --flavor bazaar
flutter build apk --release --flavor myket
```

اعتبارسنجی ساختاری بدون وابستگی نیز در دسترس است:

```bash
python3 tool/validate_release.py
```

## GitHub Actions

فایل `.github/workflows/build-apk.yml` با نسخه WF10 جدیدترین ZIP معتبر Flutter را استخراج می‌کند، نسخه و ساختار پروژه را کنترل می‌کند، فرمت و تحلیل و تست را اجرا می‌کند و دو APK بازار و مایکت می‌سازد. در صورت شکست، فقط بسته لاگ خطا بارگذاری می‌شود.

برای امضای واقعی انتشار، چهار Secret زیر باید در Repository تنظیم شده باشند:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_STORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

در نبود Secretها، Workflow برای تشخیص خطای Build از امضای Debug روی Build نوع Release استفاده می‌کند؛ این خروجی برای انتشار نهایی مارکت مناسب نیست.
