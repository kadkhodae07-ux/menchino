# منچینو — مار و پله سه‌بعدی Android

نسخه سورس: `0.1.9`  
موتور هدف: `Unity 2022.3.62f1 LTS`  
رندر: `URP 14`  
نمایش: `Portrait`  
شناسه بسته: `com.menchino.game`

## وضعیت تحویل

این بسته، سورس ماژولار فاز آفلاین «منچینو» است. صفحه اصلی، انتخاب حالت، آماده‌سازی ۲ تا ۴ بازیکن، تخته واقعی ۱۰×۱۰، Rule Engine، تاس کنترل‌شده، حرکت خانه‌به‌خانه، مار و نردبان Data-driven، ربات، ذخیره/بازیابی، نتیجه، مأموریت روزانه، جایزه هفت‌روزه، پروفایل، فروشگاه و تنظیمات در سورس پیاده‌سازی شده‌اند.

هیچ‌یک از تصاویر مرجع به‌عنوان پس‌زمینه ثابت یا صفحه غیرقابل‌تعامل استفاده نشده است. قاب‌ها، دکمه‌ها، تخته، مهره، تاس، HUD و پنجره‌ها به‌صورت اجزای مستقل ایجاد می‌شوند. ابزار Editor نیز Prefabهای پایه UI و Gameplay را پس از اولین Import تولید می‌کند.

این محیط به Unity Editor و Android SDK دسترسی نداشت؛ بنابراین Import، اجرای Test Runner، Build واقعی APK و کنترل روی دستگاه در این تحویل اجرا نشده‌اند. موارد قابل‌اجرای داخل Unity در `Docs/QA_CHECKLIST.md` مشخص شده‌اند. کیفیت هنری نهایی باید پس از Import و بازبینی روی دستگاه با مدل‌ها، صوت‌ها و Artwork اختصاصی نهایی ارزیابی شود؛ سورس حاضر از اسکرین‌شات ثابت یا UI پیش‌فرض سیستم استفاده نمی‌کند.

## اجرای پروژه

1. پروژه را با Unity Hub و نسخه `2022.3.62f1` باز کنید.
2. تا پایان Import پکیج‌های URP و Test Framework صبر کنید.
3. از منوی `Menchino > Apply Android Configuration` تنظیمات Android و URP را اعمال کنید.
4. Prefabهای ماژولار به‌صورت خودکار ساخته می‌شوند؛ بازتولید دستی: `Menchino > Regenerate Modular Prefabs`.
5. Scene زیر را باز کنید: `Assets/Scenes/Boot.unity`.
6. Play را اجرا کنید.

## ساخت APK

از داخل Unity:

`Menchino > Build Two Android APKs`

خروجی:

`Builds/Android/Menchino-arm64-v8a.apk` و `Builds/Android/Menchino-universal.apk`

ساخت Release نهایی به keystore مالک پروژه نیاز دارد. کلید انتشار داخل سورس نگهداری نشده است.

## ساخت خودکار در GitHub Actions

1. هر نسخه ZIP سورس را با شماره نسخه در ریشه Repository قرار دهید؛ برای نمونه: `menchino_unity_v0.1.9_embedded_credentials_source.zip`.
2. فایل `menchino_unity_android_build_latest.yml` را در مسیر `.github/workflows/menchino_unity_android_build_latest.yml` قرار دهید.
3. Workflow همه ZIPهای معتبر Unity در ریشه Repository را بررسی می‌کند و بالاترین نسخه SemVer را به‌صورت خودکار انتخاب می‌کند.
4. تست‌های EditMode اجرا می‌شوند و دو APK واقعی ساخته می‌شود:
   - `Menchino-arm64-v8a.apk`
   - `Menchino-universal.apk`
5. Artifact موفق فقط یک فایل به نام `Menchino-Android-Latest.zip` است و داخل آن دقیقاً همین دو APK قرار دارد.
6. پس از موفقیت، Artifactها و Workflow Runهای تکمیل‌شده قبلی منچینو حذف می‌شوند. در صورت خطا، بسته جداگانه لاگ‌های پاک‌سازی‌شده بارگذاری می‌شود.

یک نسخه از Workflow داخل خود سورس نیز نگهداری شده است، اما GitHub برای اجرای آن باید فایل Workflow را به‌صورت جداگانه و خارج از ZIP در مسیر `.github/workflows` ببیند.

فایل لایسنس Unity طبق درخواست مالک پروژه در مسیر `.unity-ci/Unity_lic.ulf` داخل سورس قرار دارد و Workflow محتوای همان فایل را به متغیر محیطی `UNITY_LICENSE` منتقل می‌کند. بنابراین برای این نسخه نیازی به Secretهای `UNITY_LICENSE`، `UNITY_EMAIL` یا `UNITY_PASSWORD` نیست.

> هشدار امنیتی: این روش فقط برای Repository خصوصی مناسب است. قرار دادن ZIP سورس در Repository عمومی، فایل لایسنس Unity را نیز عمومی می‌کند.

## امکانات پیاده‌سازی‌شده

- UI فارسی، Safe Area و مرجع طراحی 1080×1920
- صفحه اصلی بازی‌محور با پروفایل، سکه، جواهر، جایزه و مأموریت
- حالت آفلاین، ربات و چندنفره روی یک دستگاه؛ آنلاین قفل و Future-ready
- انتخاب ۲، ۳ یا ۴ بازیکن، نام، آواتار، رنگ، نوع و درجه هر ربات
- تخته ۱۰×۱۰ با شماره‌گذاری زیگزاگی استاندارد
- چیدمان ۱۰ مار و ۱۰ نردبان از فایل JSON قابل تغییر
- تاس سه‌بعدی که نتیجه آن را Logic تعیین می‌کند، نه فیزیک Unity
- حرکت خانه‌به‌خانه، صعود نردبان، سقوط مار و برخورد اختیاری مهره‌ها
- رسیدن دقیق به ۱۰۰، Bounce Back، ورود با ۶، نوبت اضافه و سقف ۶ متوالی
- State Machine و قفل ورودی هنگام انیمیشن
- ربات آسان، متوسط و سخت بدون دست‌کاری نتیجه تاس
- ذخیره Atomic و بازیابی مسابقه نیمه‌تمام
- مأموریت‌های روزانه با Reset بر مبنای UTC
- جایزه روزانه هفت‌روزه با تشخیص بازگرداندن ساعت دستگاه
- کیف پول، Inventory و خرید داخلی با پول مجازی
- ساختار اتصال پرداخت فروشگاهی بدون نگهداری کلید یا تراکنش واقعی
- پروفایل، آمار، افتخارات، دوستان و هدیه
- اشتراک‌گذاری نتیجه با Android Share Intent و Clipboard fallback
- موسیقی و SFX پایه Runtime، Mixer-ready
- تست‌های EditMode برای Board Mapping، Rule Engine و Config
- Workflow ساخت Android با GameCI

## ساختار کلیدی

- `Assets/Scripts/Core`: Composition Root و Scene Flow
- `Assets/Scripts/Data`: مدل‌ها و Config Loader
- `Assets/Scripts/Gameplay`: تخته، قوانین و Match State Machine
- `Assets/Scripts/Presentation`: UI، World View، تاس، مهره و Screenها
- `Assets/Scripts/Services`: ذخیره، اقتصاد، جوایز، مأموریت، صدا و Share
- `Assets/Resources/Configs`: فایل‌های تنظیمات Data-driven
- `Assets/Prefabs`: Prefabهای تولیدشونده و قراردادهای ماژولار
- `Assets/Tests`: تست‌های EditMode
- `Assets/Editor`: پیکربندی Android، URP، Prefab و Build
- `Docs`: معماری، سیاست مرجع، QA و وضعیت تحویل

## نکته ضروری درباره Workflow

GitHub فقط فایل `.github/workflows/menchino-build-wf13.yml` موجود در خود Repository را اجرا می‌کند. فایل Workflow داخل ZIP به‌تنهایی اجرا یا جایگزین نمی‌شود. هنگام انتشار این نسخه، فایل `menchino-build-wf13.yml` تحویلی را نیز در مسیر `.github/workflows/menchino-build-wf13.yml` Repository جایگزین کنید. در Run صحیح باید عنوان `v6` دیده شود.
