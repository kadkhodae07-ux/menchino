import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../../core/theme.dart';
import '../widgets/neon.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(title: const Text('تنظیمات بازی')),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('ظاهر', style: _sectionTitle(theme)),
              const SizedBox(height: 10),
              NeonPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('تم بازی', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 15)),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: Themes.all.map((item) => _ThemeCard(theme: item, selected: item.id == state.themeId, onTap: () => state.setTheme(item.id))).toList(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text('کنترل و گرافیک', style: _sectionTitle(theme)),
              const SizedBox(height: 10),
              NeonPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        AppIcons.icon('racket', size: 22, color: theme.primary),
                        const SizedBox(width: 10),
                        Expanded(child: Text('حساسیت کنترل', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900))),
                        StatBadge(state.sensitivity.toStringAsFixed(1), color: theme.primary),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _NeonSensitivitySlider(
                      value: state.sensitivity,
                      color: theme.primary,
                      onChanged: (value) => state.setSetting(sensitivityValue: value),
                    ),
                    const SizedBox(height: 14),
                    Text('کیفیت گرافیک', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 9),
                    Row(
                      children: [
                        Expanded(child: _Segment(label: 'کم', active: state.quality == 'low', color: theme.primary, onTap: () => state.setSetting(qualityValue: 'low'))),
                        const SizedBox(width: 8),
                        Expanded(child: _Segment(label: 'متعادل', active: state.quality == 'medium', color: theme.primary, onTap: () => state.setSetting(qualityValue: 'medium'))),
                        const SizedBox(width: 8),
                        Expanded(child: _Segment(label: 'زیاد', active: state.quality == 'high', color: theme.primary, onTap: () => state.setSetting(qualityValue: 'high'))),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text('بازخورد بازی', style: _sectionTitle(theme)),
              const SizedBox(height: 10),
              NeonPanel(
                child: Column(
                  children: [
                    _ToggleTile(icon: 'ball', title: 'رد نور توپ', subtitle: 'دنباله نرم بر اساس سرعت توپ', value: state.trail, color: theme.primary, onChanged: (v) => state.setSetting(trailValue: v)),
                    const SizedBox(height: 10),
                    _ToggleTile(icon: 'power', title: 'صدا', subtitle: 'ضربه، امتیاز، برد و پاورآپ', value: state.sound, color: theme.accent, onChanged: (v) => state.setSetting(soundValue: v)),
                    const SizedBox(height: 10),
                    _ToggleTile(icon: 'racket', title: 'لرزش', subtitle: 'بازخورد لمسی هنگام ضربه و امتیاز', value: state.haptics, color: theme.secondary, onChanged: (v) => state.setSetting(hapticsValue: v)),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              NeonButton(
                label: 'بازنشانی اطلاعات',
                icon: 'restart',
                color: theme.danger,
                expand: true,
                onTap: () async {
                  final first = await showNeonConfirm(
                    context,
                    title: 'بازنشانی اطلاعات',
                    message: 'تمام پیشرفت، سکه‌ها، آیتم‌ها و تنظیمات حذف می‌شوند. ادامه می‌دهی؟',
                    confirmLabel: 'ادامه',
                    danger: true,
                  );
                  if (!first || !context.mounted) return;
                  final second = await showNeonConfirm(
                    context,
                    title: 'تأیید نهایی',
                    message: 'این عملیات قابل بازگشت نیست.',
                    confirmLabel: 'حذف همه',
                    danger: true,
                  );
                  if (!second) return;
                  await state.resetData();
                  if (context.mounted) {
                    showNeonMessage(context, 'اطلاعات بازی بازنشانی شد.');
                    Navigator.pop(context);
                  }
                },
              ),
              const SizedBox(height: 14),
              Text('نسخه 1.0.0+1 • اطلاعات بازی روی دستگاه ذخیره می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: theme.dim, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  TextStyle _sectionTitle(GameTheme theme) => TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 18);
}

class _NeonSensitivitySlider extends StatelessWidget {
  final double value;
  final Color color;
  final ValueChanged<double> onChanged;

  const _NeonSensitivitySlider({
    required this.value,
    required this.color,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return LayoutBuilder(
      builder: (context, constraints) {
        final t = ((value - .6) / 1.4).clamp(0.0, 1.0).toDouble();
        void update(double dx) {
          final ratio = (dx / constraints.maxWidth).clamp(0.0, 1.0).toDouble();
          final next = (.6 + ratio * 1.4);
          onChanged((next * 10).round() / 10);
        }
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (d) => update(d.localPosition.dx),
          onHorizontalDragUpdate: (d) => update(d.localPosition.dx),
          child: SizedBox(
            height: 42,
            child: Stack(
              alignment: Alignment.centerLeft,
              children: [
                Positioned(
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 9,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(99),
                      color: color.withOpacity(.10),
                      border: Border.all(color: color.withOpacity(.18)),
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  width: constraints.maxWidth * t,
                  child: Container(
                    height: 9,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(99),
                      color: color.withOpacity(.70),
                      boxShadow: [BoxShadow(color: color.withOpacity(.24), blurRadius: 12)],
                    ),
                  ),
                ),
                Positioned(
                  left: (constraints.maxWidth - 24) * t,
                  child: Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: theme.panel,
                      border: Border.all(color: color.withOpacity(.86), width: 2),
                      boxShadow: [
                        BoxShadow(color: color.withOpacity(.28), blurRadius: 14),
                        BoxShadow(color: Colors.black.withOpacity(.28), blurRadius: 8, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Center(
                      child: Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final GameTheme theme;
  final bool selected;
  final VoidCallback onTap;

  const _ThemeCard({required this.theme, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final width = (MediaQuery.sizeOf(context).width - 62) / 2;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: width.clamp(130.0, 190.0).toDouble(),
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: theme.panel,
          border: Border.all(color: selected ? theme.primary : theme.primary.withOpacity(.18), width: selected ? 1.8 : 1),
          boxShadow: selected ? [BoxShadow(color: theme.primary.withOpacity(.20), blurRadius: 18)] : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _dot(theme.primary),
                const SizedBox(width: 5),
                _dot(theme.secondary),
                const SizedBox(width: 5),
                _dot(theme.accent),
                const Spacer(),
                if (selected) AppIcons.icon('check', size: 17, color: theme.accent),
              ],
            ),
            const SizedBox(height: 10),
            Text(theme.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Widget _dot(Color color) => Container(width: 16, height: 16, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}

class _Segment extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  final VoidCallback onTap;

  const _Segment({required this.label, required this.active, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: active ? color.withOpacity(.16) : state.theme.bg.withOpacity(.35),
          border: Border.all(color: active ? color.withOpacity(.60) : state.theme.dim.withOpacity(.16)),
        ),
        child: Text(label, textAlign: TextAlign.center, style: TextStyle(color: active ? state.theme.text : state.theme.dim, fontWeight: FontWeight.w900, fontSize: 12)),
      ),
    );
  }
}

class _ToggleTile extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final bool value;
  final Color color;
  final ValueChanged<bool> onChanged;

  const _ToggleTile({required this.icon, required this.title, required this.subtitle, required this.value, required this.color, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final theme = state.theme;
    return GestureDetector(
      onTap: () => onChanged(!value),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: value ? color.withOpacity(.08) : theme.bg.withOpacity(.30),
          border: Border.all(color: value ? color.withOpacity(.26) : theme.dim.withOpacity(.12)),
        ),
        child: Row(
          children: [
            AppIcons.icon(icon, size: 22, color: value ? color : theme.dim),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text(subtitle, style: TextStyle(color: theme.dim, fontSize: 11, height: 1.45)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              width: 46,
              height: 26,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(99),
                color: value ? color.withOpacity(.32) : theme.dim.withOpacity(.16),
                border: Border.all(color: value ? color.withOpacity(.52) : theme.dim.withOpacity(.20)),
              ),
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 160),
                alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(width: 18, height: 18, decoration: BoxDecoration(shape: BoxShape.circle, color: value ? color : theme.dim)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
