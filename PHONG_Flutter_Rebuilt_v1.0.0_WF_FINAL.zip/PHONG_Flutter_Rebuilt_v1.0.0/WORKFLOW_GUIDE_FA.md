# راهنمای Workflow نهایی PHONG

فایل Workflow:

`.github/workflows/PHONG_BUILD_LATEST_ZIP_FINAL.yml`

عملکرد:

- جدیدترین ZIP سورس موجود در ریپو را بر اساس آخرین Commit انتخاب می‌کند.
- در اجرای دستی می‌توان مسیر ZIP مشخصی وارد کرد.
- فایل ZIP را تست و استخراج می‌کند.
- ریشه واقعی پروژه Flutter را از روی `pubspec.yaml` و `lib/main.dart` تشخیص می‌دهد.
- اگر پوشه Android ناقص باشد، آن را با Flutter Stable تولید می‌کند.
- Java 17، Flutter Stable، دریافت وابستگی‌ها، Analyze و Build Release را اجرا می‌کند.
- بدون `split-per-abi` فقط یک APK عمومی با نام `PHONG-release.apk` می‌سازد.
- پس از آپلود موفق APK جدید، تمام Artifactهای قدیمی ریپو را حذف می‌کند.
- در صورت شکست، فایل `PHONG-build-error-logs.zip` را به‌عنوان Artifact خطا تحویل می‌دهد.

## روش استفاده

1. ZIP جدید سورس را در ریپو قرار دهید.
2. فایل Workflow باید مستقیماً در مسیر `.github/workflows/` ریپو باشد؛ وجود آن فقط داخل ZIP باعث اجرا نمی‌شود.
3. Commit و Push کنید یا Workflow را از تب Actions به‌صورت دستی اجرا کنید.
4. در اجرای دستی، ورودی `source_zip` را خالی بگذارید تا جدیدترین ZIP خودکار انتخاب شود.

## خروجی موفق

Artifact با نام `PHONG-APK` فقط شامل یک فایل است:

`PHONG-release.apk`

GitHub فایل Artifact را هنگام دانلود در یک ZIP انتقال می‌دهد، اما محتوای آن فقط همان یک APK است.
