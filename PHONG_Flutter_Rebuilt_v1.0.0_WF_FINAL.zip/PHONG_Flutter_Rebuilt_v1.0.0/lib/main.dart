import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/state/app_state.dart';
import 'ui/screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.bootstrap();
  runApp(ChangeNotifierProvider.value(value: state, child: const PhongApp()));
}

class PhongApp extends StatelessWidget {
  const PhongApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;

    return MaterialApp(
      title: 'PHONG',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: theme.brightness,
        scaffoldBackgroundColor: theme.bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: theme.primary,
          brightness: theme.brightness,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: theme.bg,
          foregroundColor: theme.text,
          elevation: 0,
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: theme.panel,
          contentTextStyle: TextStyle(color: theme.text, fontWeight: FontWeight.w700),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
