import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';

class AudioService {
  final Map<String, String> _paths = {};
  final List<AudioPlayer> _pool = List.generate(6, (_) => AudioPlayer());
  int _index = 0;
  double sfxVolume = .8;
  bool enabled = true;
  bool _ready = false;

  Future<void> init() async {
    final dir = await getTemporaryDirectory();
    final root = Directory('${dir.path}/phong_audio');
    if (!await root.exists()) await root.create(recursive: true);

    Future<void> write(String name, Uint8List bytes) async {
      final file = File('${root.path}/$name.wav');
      if (!await file.exists()) await file.writeAsBytes(bytes, flush: true);
      _paths[name] = file.path;
    }

    await write('tap', _tone(660, .05));
    await write('hit', _tone(240, .05, type: 1));
    await write('wall', _tone(330, .04));
    await write('score', _tone(660, .12));
    await write('win', _tone(880, .25));
    await write('lose', _tone(180, .25, type: 2));
    await write('coin', _tone(1318, .08));
    await write('count', _tone(440, .08));
    await write('go', _tone(880, .12));
    await write('power', _tone(990, .10));
    _ready = true;
  }

  Uint8List _tone(double frequency, double duration, {int type = 0}) {
    const rate = 22050;
    final count = (duration * rate).toInt();
    final samples = List<double>.filled(count, 0);
    for (var i = 0; i < count; i++) {
      final time = i / rate;
      final envelope = exp(-8 * time);
      double value = 0;
      if (type == 0) value = sin(2 * pi * frequency * time);
      if (type == 1) value = sin(2 * pi * frequency * time) >= 0 ? 1 : -1;
      if (type == 2) value = sin(2 * pi * frequency * time * .5);
      samples[i] = value * .5 * envelope;
    }
    return _wav(samples);
  }

  Uint8List _wav(List<double> samples) {
    final sampleBytes = samples.length * 2;
    final data = ByteData(44 + sampleBytes);

    void writeString(int offset, String text) {
      for (var i = 0; i < text.length; i++) {
        data.setUint8(offset + i, text.codeUnitAt(i));
      }
    }

    writeString(0, 'RIFF');
    data.setUint32(4, 36 + sampleBytes, Endian.little);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, 22050, Endian.little);
    data.setUint32(28, 22050 * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    writeString(36, 'data');
    data.setUint32(40, sampleBytes, Endian.little);

    for (var i = 0; i < samples.length; i++) {
      final value = (samples[i].clamp(-1.0, 1.0) * 32767).round();
      data.setInt16(44 + i * 2, value, Endian.little);
    }
    return data.buffer.asUint8List();
  }

  Future<void> play(String name) async {
    if (!_ready || !enabled || sfxVolume <= 0) return;
    final path = _paths[name];
    if (path == null) return;
    final player = _pool[_index];
    _index = (_index + 1) % _pool.length;
    try {
      await player.stop();
      await player.setVolume(sfxVolume.clamp(0.0, 1.0).toDouble());
      await player.play(DeviceSource(path));
    } catch (_) {
      // A dropped sound must never interrupt gameplay.
    }
  }

  Future<void> dispose() async {
    for (final player in _pool) {
      await player.dispose();
    }
  }
}
