import 'package:flutter/material.dart';

class GameTheme {
  final String id;
  final String label;
  final Brightness brightness;
  final Color bg;
  final Color panel;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color danger;
  final Color gold;
  final Color text;
  final Color dim;
  final Color canvasBg;
  final Color grid;
  final Color center;
  final Color top;
  final Color bottom;
  final Color ball;
  final Color trail;

  const GameTheme({
    required this.id,
    required this.label,
    required this.brightness,
    required this.bg,
    required this.panel,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.danger,
    required this.gold,
    required this.text,
    required this.dim,
    required this.canvasBg,
    required this.grid,
    required this.center,
    required this.top,
    required this.bottom,
    required this.ball,
    required this.trail,
  });
}

class Themes {
  static const dark = GameTheme(
    id: 'dark', label: 'تاریک', brightness: Brightness.dark,
    bg: Color(0xFF040714), panel: Color(0xE60D1630),
    primary: Color(0xFF2DE2FF), secondary: Color(0xFF8A5CFF),
    accent: Color(0xFF00FFC6), danger: Color(0xFFFF3B8D),
    gold: Color(0xFFFFD54D), text: Color(0xFFE8F2FF), dim: Color(0xFF92A7D0),
    canvasBg: Color(0xFF040714), grid: Color(0x142DE2FF),
    center: Color(0xFF2DE2FF), top: Color(0xFF8A5CFF),
    bottom: Color(0xFF00FFC6), ball: Color(0xFFE8F2FF), trail: Color(0xFF2DE2FF),
  );

  static const light = GameTheme(
    id: 'light', label: 'روشن', brightness: Brightness.light,
    bg: Color(0xFFEAF2FF), panel: Color(0xF0FFFFFF),
    primary: Color(0xFF2563EB), secondary: Color(0xFF7C3AED),
    accent: Color(0xFF0EA5E9), danger: Color(0xFFDB2777),
    gold: Color(0xFFD97706), text: Color(0xFF07101F), dim: Color(0xFF4A5A7A),
    canvasBg: Color(0xFFEAF2FF), grid: Color(0x1F2563EB),
    center: Color(0xFF2563EB), top: Color(0xFF7C3AED),
    bottom: Color(0xFF0EA5E9), ball: Color(0xFF07101F), trail: Color(0xFF2563EB),
  );

  static const girly = GameTheme(
    id: 'girly', label: 'دخترونه', brightness: Brightness.dark,
    bg: Color(0xFF19041F), panel: Color(0xE6300A28),
    primary: Color(0xFFFF6AD5), secondary: Color(0xFFC084FC),
    accent: Color(0xFFFF9DE2), danger: Color(0xFFFF3B8D),
    gold: Color(0xFFFFD54D), text: Color(0xFFFFE9FB), dim: Color(0xFFD18BC7),
    canvasBg: Color(0xFF19041F), grid: Color(0x1FFF6AD5),
    center: Color(0xFFFF6AD5), top: Color(0xFFC084FC),
    bottom: Color(0xFFFF9DE2), ball: Color(0xFFFFE9FB), trail: Color(0xFFFF6AD5),
  );

  static const boyish = GameTheme(
    id: 'boyish', label: 'پسرونه', brightness: Brightness.dark,
    bg: Color(0xFF031118), panel: Color(0xE6061E28),
    primary: Color(0xFF38BDF8), secondary: Color(0xFF22C55E),
    accent: Color(0xFFA3E635), danger: Color(0xFFF97316),
    gold: Color(0xFFFACC15), text: Color(0xFFE8FBFF), dim: Color(0xFF7FA8B8),
    canvasBg: Color(0xFF031118), grid: Color(0x1F38BDF8),
    center: Color(0xFF38BDF8), top: Color(0xFF22C55E),
    bottom: Color(0xFFA3E635), ball: Color(0xFFE8FBFF), trail: Color(0xFF38BDF8),
  );

  static const child = GameTheme(
    id: 'child', label: 'بچگونه', brightness: Brightness.light,
    bg: Color(0xFFFFF4DE), panel: Color(0xF2FFFFFF),
    primary: Color(0xFFFF7A00), secondary: Color(0xFF7C3AED),
    accent: Color(0xFF00C853), danger: Color(0xFFFF3D71),
    gold: Color(0xFFFFC400), text: Color(0xFF2A1B56), dim: Color(0xFF6B5CA5),
    canvasBg: Color(0xFFFFF4DE), grid: Color(0x24FF7A00),
    center: Color(0xFFFF7A00), top: Color(0xFF7C3AED),
    bottom: Color(0xFF00C853), ball: Color(0xFF2A1B56), trail: Color(0xFFFF7A00),
  );

  static const all = [dark, light, girly, boyish, child];

  static GameTheme byId(String? id) =>
      all.firstWhere((theme) => theme.id == id, orElse: () => dark);
}
