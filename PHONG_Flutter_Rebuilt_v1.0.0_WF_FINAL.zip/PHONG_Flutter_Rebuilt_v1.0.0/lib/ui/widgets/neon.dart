import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';

class NeonButton extends StatefulWidget {
  final String label;
  final String? icon;
  final VoidCallback? onTap;
  final Color? color;
  final bool small;
  final bool expand;

  const NeonButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.color,
    this.small = false,
    this.expand = false,
  });

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = widget.color ?? theme.primary;
    final enabled = widget.onTap != null;

    final content = AnimatedScale(
      scale: _pressed && enabled ? .965 : 1,
      duration: const Duration(milliseconds: 90),
      child: AnimatedOpacity(
        opacity: enabled ? 1 : .42,
        duration: const Duration(milliseconds: 120),
        child: Container(
          constraints: BoxConstraints(minHeight: widget.small ? 42 : 52),
          padding: EdgeInsets.symmetric(horizontal: widget.small ? 13 : 16, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.small ? 13 : 16),
            border: Border.all(color: color.withOpacity(_pressed ? .9 : .55)),
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [color.withOpacity(.25), theme.panel.withOpacity(.96)],
            ),
            boxShadow: [
              BoxShadow(color: color.withOpacity(_pressed ? .30 : .18), blurRadius: _pressed ? 10 : 22),
              BoxShadow(color: Colors.black.withOpacity(.45), offset: Offset(0, _pressed ? 5 : 13), blurRadius: 22),
              BoxShadow(color: Colors.white.withOpacity(.035), offset: const Offset(0, -2), blurRadius: 5),
            ],
          ),
          child: Row(
            mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.icon != null) ...[
                AppIcons.icon(widget.icon!, size: widget.small ? 17 : 19, color: theme.text),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Text(
                  widget.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.text,
                    fontWeight: FontWeight.w900,
                    fontSize: widget.small ? 14 : 17,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    return Semantics(
      button: true,
      enabled: enabled,
      label: widget.label,
      child: MouseRegion(
        cursor: enabled ? SystemMouseCursors.click : SystemMouseCursors.forbidden,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
          onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
          onTapUp: enabled
              ? (_) {
                  setState(() => _pressed = false);
                  widget.onTap?.call();
                }
              : null,
          child: widget.expand ? SizedBox(width: double.infinity, child: content) : content,
        ),
      ),
    );
  }
}

class NeonPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;

  const NeonPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = borderColor ?? theme.primary;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: theme.panel,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(.35)),
        boxShadow: [
          BoxShadow(color: color.withOpacity(.12), blurRadius: 24),
          BoxShadow(color: Colors.black.withOpacity(.48), offset: const Offset(0, 17), blurRadius: 27),
          BoxShadow(color: Colors.white.withOpacity(.025), offset: const Offset(0, -2), blurRadius: 4),
        ],
      ),
      child: child,
    );
  }
}

class Chip3D extends StatelessWidget {
  final String text;
  final bool gem;

  const Chip3D({super.key, required this.text, this.gem = false});

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = gem ? theme.secondary : theme.accent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        color: theme.primary.withOpacity(.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(.45)),
        boxShadow: [BoxShadow(color: color.withOpacity(.09), blurRadius: 14)],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppIcons.icon(gem ? 'gem' : 'coin', size: 16, color: color),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class StatBadge extends StatelessWidget {
  final String text;
  final Color? color;

  const StatBadge(this.text, {super.key, this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final accent = color ?? theme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: accent.withOpacity(.07),
        border: Border.all(color: accent.withOpacity(.16)),
      ),
      child: Text(text, style: TextStyle(color: theme.dim, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

void showNeonMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message), duration: const Duration(milliseconds: 1900)));
}

Future<bool> showNeonConfirm(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'تأیید',
  bool danger = false,
}) async {
  final state = context.read<AppState>();
  final result = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      backgroundColor: state.theme.panel,
      title: Text(title, style: TextStyle(color: danger ? state.theme.danger : state.theme.text, fontWeight: FontWeight.w900)),
      content: Text(message, style: TextStyle(color: state.theme.dim, height: 1.7)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('انصراف')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: danger ? state.theme.danger : state.theme.primary),
          onPressed: () => Navigator.pop(dialogContext, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}
