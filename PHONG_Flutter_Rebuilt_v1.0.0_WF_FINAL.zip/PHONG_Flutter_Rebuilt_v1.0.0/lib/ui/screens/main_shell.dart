import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import 'lobby_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'rewards_screen.dart';
import 'shop_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 2;

  static const _screens = [
    ShopScreen(),
    RewardsScreen(),
    LobbyScreen(),
    RankScreen(),
    ProfileScreen(),
  ];

  static const _tabs = [
    ('shop', 'فروشگاه'),
    ('gift', 'جوایز'),
    ('home', 'خانه'),
    ('rank', 'رتبه‌بندی'),
    ('profile', 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return Scaffold(
      backgroundColor: theme.bg,
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 7),
          decoration: BoxDecoration(
            color: theme.panel,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: theme.primary.withOpacity(.3)),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(.46), offset: const Offset(0, 14), blurRadius: 26),
              BoxShadow(color: theme.primary.withOpacity(.11), blurRadius: 22),
            ],
          ),
          child: Row(
            children: List.generate(_tabs.length, (index) {
              final active = index == _index;
              final home = index == 2;
              return Expanded(
                child: GestureDetector(
                  onTap: () {
                    context.read<AppState>().audio.play('tap');
                    setState(() => _index = index);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    transform: Matrix4.translationValues(0, home ? -5 : 0, 0),
                    margin: EdgeInsets.only(top: home ? 1 : 7, bottom: 2),
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(home ? 18 : 14),
                      color: active ? theme.primary.withOpacity(.11) : Colors.transparent,
                      border: home ? Border.all(color: theme.primary.withOpacity(.28)) : null,
                      boxShadow: home ? [BoxShadow(color: theme.primary.withOpacity(.12), blurRadius: 16)] : null,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AppIcons.icon(_tabs[index].$1, size: home ? 26 : 22, color: active ? theme.primary : theme.dim),
                        const SizedBox(height: 4),
                        Text(
                          _tabs[index].$2,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: active ? theme.primary : theme.dim),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
