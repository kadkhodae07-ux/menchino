import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';
import 'chat_screen.dart';
import 'friends_screen.dart';
import 'game_screen.dart';
import 'match_setup_dialog.dart';
import 'settings_screen.dart';
import 'tournament_screen.dart';

class LobbyScreen extends StatelessWidget {
  const LobbyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    return SafeArea(
      bottom: false,
      child: LayoutBuilder(
        builder: (context, constraints) => SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 22),
          child: Column(
            children: [
              NeonPanel(
                child: Wrap(
                  runSpacing: 12,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    SizedBox(
                      width: constraints.maxWidth < 410 ? constraints.maxWidth - 64 : constraints.maxWidth * .48,
                      child: Row(
                        children: [
                          AvatarBadge(index: state.avatar),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(state.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 17)),
                                const SizedBox(height: 3),
                                Text('سطح ${state.level} • لیگ ${state.leaguePoints}', style: TextStyle(color: theme.dim, fontSize: 13)),
                                const SizedBox(height: 7),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(99),
                                  child: LinearProgressIndicator(
                                    minHeight: 9,
                                    value: (state.xp / state.xpToNext).clamp(0.0, 1.0).toDouble(),
                                    color: theme.primary,
                                    backgroundColor: theme.primary.withOpacity(.15),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Chip3D(text: '${state.coins}'),
                        const SizedBox(width: 6),
                        Chip3D(text: '${state.gems}', gem: true),
                        const SizedBox(width: 6),
                        _iconButton(context, 'chat', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen()))),
                        const SizedBox(width: 4),
                        _iconButton(context, 'settings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              NeonPanel(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(minHeight: 190),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('شروع بازی', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: theme.text)),
                      const SizedBox(height: 8),
                      Text('انتخاب حالت، سختی، جهت صفحه و ورودی', textAlign: TextAlign.center, style: TextStyle(color: theme.dim)),
                      const SizedBox(height: 18),
                      NeonButton(
                        label: 'شروع بازی',
                        icon: 'play',
                        color: theme.accent,
                        onTap: () async {
                          final setup = await showDialog<Map<String, dynamic>>(
                            context: context,
                            builder: (_) => const MatchSetupDialog(),
                          );
                          if (setup == null || !context.mounted) return;
                          await state.updateMatchSetup(setup);
                          if (!context.mounted) return;
                          Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen.fromSetup()));
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: constraints.maxWidth < 370 ? 1.55 : 1.85,
                children: [
                  NeonButton(label: 'تورنمنت', icon: 'crown', color: theme.secondary, expand: true, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TournamentScreen()))),
                  NeonButton(
                    label: 'تمرین',
                    icon: 'practice',
                    expand: true,
                    onTap: () async {
                      await state.updateMatchSetup({'mode': 'practice', 'entry': 0});
                      if (!context.mounted) return;
                      Navigator.push(context, MaterialPageRoute(builder: (_) => GameScreen.fromSetup()));
                    },
                  ),
                  NeonButton(label: 'دوستانه', icon: 'friends', expand: true, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FriendsScreen()))),
                  NeonButton(label: 'چت', icon: 'chat', expand: true, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen()))),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _iconButton(BuildContext context, String icon, VoidCallback onTap) {
    final theme = context.read<AppState>().theme;
    return IconButton.filledTonal(
      onPressed: onTap,
      style: IconButton.styleFrom(backgroundColor: theme.primary.withOpacity(.08), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
      icon: AppIcons.icon(icon, color: theme.text),
    );
  }
}
