import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/state/app_state.dart';
import '../../core/theme.dart';
import '../../game/engine.dart';
import '../widgets/neon.dart';

class GameScreen extends StatefulWidget {
  final String? modeOverride;
  final String? friendName;
  final Tournament? tournament;
  final int tournamentRound;

  const GameScreen({
    super.key,
    this.modeOverride,
    this.friendName,
    this.tournament,
    this.tournamentRound = 0,
  });

  factory GameScreen.fromSetup() => const GameScreen();
  factory GameScreen.local(String friendName) => GameScreen(modeOverride: 'local', friendName: friendName);
  factory GameScreen.tournament(Tournament tournament, int round) =>
      GameScreen(modeOverride: 'tournament', tournament: tournament, tournamentRound: round);

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AppState _state;
  late final Engine engine;
  late final Ticker _ticker;
  Duration? _lastTick;
  Size _lastSize = Size.zero;
  bool _resultHandled = false;
  bool _started = false;
  bool _prepared = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _state = context.read<AppState>();
    final setup = _state.matchSetup;
    final mode = widget.modeOverride ?? (setup['mode'] as String? ?? 'quick');
    final difficulty = mode == 'tournament'
        ? widget.tournament?.difficulty ?? 'hard'
        : mode == 'challenge'
            ? 'hard'
            : setup['difficulty'] as String? ?? 'medium';
    final entry = mode == 'practice' || mode == 'local' || mode == 'tournament'
        ? 0
        : setup['entry'] as int? ?? 0;

    engine = Engine(
      state: _state,
      mode: mode,
      difficulty: difficulty,
      orientation: setup['orientation'] as String? ?? 'portrait',
      entry: entry,
      twoPlayer: mode == 'local',
      friendName: widget.friendName,
      tournament: widget.tournament,
      tournamentRound: widget.tournamentRound,
    );
    engine.addListener(_engineChanged);
    _ticker = createTicker(_tick);

    WidgetsBinding.instance.addPostFrameCallback((_) => _prepare());
  }

  Future<void> _prepare() async {
    if (!mounted) return;
    final landscape = engine.orientation == 'landscape';
    await SystemChrome.setPreferredOrientations(
      landscape
          ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
          : [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
    );
    if (!mounted) return;
    if (engine.entry > 0) {
      if (_state.coins < engine.entry) {
        showNeonMessage(context, 'سکه کافی برای ورودی مسابقه نداری.');
        Navigator.pop(context);
        return;
      }
      _state.addCoins(-engine.entry);
      await _state.save();
    }
    if (!mounted) return;
    _prepared = true;
    _tryStart();
  }

  void _tryStart() {
    if (!_prepared || _started || _lastSize == Size.zero || !mounted) return;
    engine.resize(_lastSize.width, _lastSize.height);
    engine.start();
    _started = true;
    _lastTick = null;
    _ticker.start();
  }

  void _tick(Duration elapsed) {
    final previous = _lastTick;
    _lastTick = elapsed;
    if (previous == null) return;
    final dt = (elapsed - previous).inMicroseconds / 1000000.0;
    engine.update(dt);
  }

  void _engineChanged() {
    if (engine.finished && !_resultHandled) {
      _resultHandled = true;
      _ticker.stop();
      WidgetsBinding.instance.addPostFrameCallback((_) => _finishMatch());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed && engine.started && !engine.paused) {
      engine.setPaused(true);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    engine.removeListener(_engineChanged);
    engine.dispose();
    _ticker.dispose();
    unawaited(SystemChrome.setPreferredOrientations(DeviceOrientation.values));
    super.dispose();
  }

  Future<void> _finishMatch() async {
    if (!mounted) return;
    final won = engine.bottomScore > engine.topScore;
    _state.stats['matches'] = (_state.stats['matches'] ?? 0) + 1;
    if (won) {
      _state.stats['wins'] = (_state.stats['wins'] ?? 0) + 1;
      _state.stats['streak'] = (_state.stats['streak'] ?? 0) + 1;
      _state.stats['bestStreak'] = max(_state.stats['bestStreak'] ?? 0, _state.stats['streak'] ?? 0).toInt();
    } else {
      _state.stats['losses'] = (_state.stats['losses'] ?? 0) + 1;
      _state.stats['streak'] = 0;
    }
    _state.stats['bestRally'] = max(_state.stats['bestRally'] ?? 0, engine.longestRally).toInt();
    _state.incMission('play');
    if (won) _state.incMission('win');
    if (engine.longestRally >= 10) _state.incMission('rally10');
    if (engine.difficulty == 'hard' && won && engine.mode != 'local') _state.incMission('hardWin');

    if (engine.mode == 'tournament' && engine.tournament != null) {
      await _finishTournament(won);
      return;
    }

    final difficultyBonus = const {'easy': 5, 'medium': 10, 'hard': 18, 'pro': 28}[engine.difficulty] ?? 5;
    final modeBonus = engine.mode == 'challenge' ? 16 : difficultyBonus;
    final scoreDifference = max(0, engine.bottomScore - engine.topScore).toInt();
    final rallyBonus = engine.longestRally ~/ 3;
    var xp = 18 + modeBonus + scoreDifference * 2 + rallyBonus;
    var baseCoins = 8 + modeBonus ~/ 2 + engine.playerGold;
    if (won) {
      xp += 26;
      baseCoins += 14;
    }
    if (engine.mode == 'practice') {
      baseCoins = 0;
      xp ~/= 2;
    }
    if (engine.mode == 'challenge' && won) baseCoins += 20;
    baseCoins = (baseCoins * (1 + engine.coinBonus)).floor();
    final entryPrize = won ? (engine.entry * 2 * .75).floor() : 0;
    final totalCoins = baseCoins + entryPrize;

    _state.addXp(xp);
    _state.addCoins(totalCoins);
    if (engine.mode == 'quick' || engine.mode == 'challenge') {
      _state.leaguePoints = max(0, _state.leaguePoints + (won ? 18 : -8)).toInt();
    } else if (engine.mode == 'local' && engine.friendName != null) {
      _state.leaguePoints = max(0, _state.leaguePoints + (won ? 8 : -4)).toInt();
    }
    await _state.audio.play(won ? 'win' : 'lose');
    await _state.save();
    if (!mounted) return;

    final action = await _showResult(
      title: won ? 'پیروزی' : 'شکست',
      win: won,
      info: '+$xp تجربه\nپاداش مسابقه: +$baseCoins سکه\nپاداش ورودی: +$entryPrize سکه\nلیگ: ${_state.leaguePoints} امتیاز\nرالی: ${engine.longestRally}',
      allowRetry: true,
    );
    if (!mounted) return;
    if (action == 'retry') {
      await _retry();
    } else {
      Navigator.pop(context);
    }
  }

  Future<void> _finishTournament(bool won) async {
    final tournament = engine.tournament!;
    final round = max(1, engine.tournamentRound).toInt();
    if (won && round < tournament.rounds) {
      _state.tournament = {'activeId': tournament.id, 'round': round + 1};
      _state.addXp(35);
      await _state.audio.play('win');
      await _state.save();
      if (!mounted) return;
      await _showResult(
        title: 'پیروزی',
        win: true,
        info: 'به دور ${round + 1} رفتی\n+35 تجربه',
        allowRetry: false,
      );
    } else if (won) {
      _state.addCoins(tournament.prize);
      _state.addXp(90);
      _state.tournament = {'activeId': null, 'round': 0};
      await _state.audio.play('win');
      await _state.save();
      if (!mounted) return;
      await _showResult(
        title: 'قهرمان شدی',
        win: true,
        info: 'پاداش تورنمنت: +${tournament.prize} سکه\n+90 تجربه',
        allowRetry: false,
      );
    } else {
      _state.tournament = {'activeId': null, 'round': 0};
      _state.addXp(10);
      await _state.audio.play('lose');
      await _state.save();
      if (!mounted) return;
      await _showResult(
        title: 'حذف شدی',
        win: false,
        info: 'در تورنمنت حذف شدی\n+10 تجربه',
        allowRetry: false,
      );
    }
    if (mounted) Navigator.pop(context);
  }

  Future<String?> _showResult({
    required String title,
    required bool win,
    required String info,
    required bool allowRetry,
  }) {
    final theme = _state.theme;
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: theme.panel,
        title: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(color: win ? theme.accent : theme.danger, fontSize: 32, fontWeight: FontWeight.w900),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${engine.bottomScore} - ${engine.topScore}', style: TextStyle(color: theme.text, fontSize: 28, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Text(info, textAlign: TextAlign.center, style: TextStyle(color: theme.dim, height: 1.8)),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          if (allowRetry)
            TextButton(onPressed: () => Navigator.pop(dialogContext, 'retry'), child: const Text('بازی مجدد')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, 'exit'), child: Text(allowRetry ? 'بازگشت' : 'باشه')),
        ],
      ),
    );
  }

  Future<void> _retry() async {
    if (engine.entry > 0) {
      if (_state.coins < engine.entry) {
        if (mounted) showNeonMessage(context, 'سکه کافی برای بازی مجدد نداری.');
        if (mounted) Navigator.pop(context);
        return;
      }
      _state.addCoins(-engine.entry);
      await _state.save();
    }
    _resultHandled = false;
    _lastTick = null;
    engine.restart();
    if (!_ticker.isActive) _ticker.start();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        engine.setPaused(true);
        final exit = await showNeonConfirm(
          context,
          title: 'خروج از مسابقه',
          message: 'مسابقه فعلی بدون ثبت نتیجه بسته می‌شود.',
          confirmLabel: 'خروج',
          danger: true,
        );
        if (!mounted) return;
        if (exit) {
          engine.abandon();
          Navigator.pop(context);
        } else {
          engine.setPaused(false);
        }
      },
      child: Scaffold(
        backgroundColor: theme.bg,
        body: LayoutBuilder(
          builder: (context, constraints) {
            final size = Size(constraints.maxWidth, constraints.maxHeight);
            if (size != _lastSize) {
              _lastSize = size;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                engine.resize(size.width, size.height);
                _tryStart();
              });
            }
            return AnimatedBuilder(
              animation: engine,
              builder: (context, _) => Stack(
                children: [
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onPanDown: (details) => _handle(details.localPosition),
                      onPanUpdate: (details) => _handle(details.localPosition),
                      child: CustomPaint(painter: _GamePainter(engine, theme)),
                    ),
                  ),
                  Positioned(
                    top: MediaQuery.paddingOf(context).top + 10,
                    left: 12,
                    right: 12,
                    child: Row(
                      children: [
                        _score(engine.topScore, theme),
                        const Spacer(),
                        NeonButton(
                          label: engine.paused ? 'ادامه' : 'توقف',
                          icon: engine.paused ? 'resume' : 'pause',
                          small: true,
                          color: theme.danger,
                          onTap: () => engine.setPaused(!engine.paused),
                        ),
                        const Spacer(),
                        _score(engine.bottomScore, theme),
                      ],
                    ),
                  ),
                  if (engine.phase == 'countdown')
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                engine.countdown > 0 ? '${engine.countdown}' : 'شروع',
                                style: TextStyle(color: theme.primary, fontSize: 72, fontWeight: FontWeight.w900, shadows: [Shadow(color: theme.primary, blurRadius: 30)]),
                              ),
                              if (engine.twoPlayer)
                                Text(
                                  engine.orientation == 'landscape' ? 'بازیکن ۱: نیمه پایین • بازیکن ۲: نیمه بالا' : 'بازیکن ۱: نیمه پایین • بازیکن ۲: نیمه بالا',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: theme.dim),
                                ),
                              if (engine.mode == 'tournament' && engine.tournament != null)
                                Text('${engine.tournament!.name} • دور ${engine.tournamentRound}', style: TextStyle(color: theme.dim)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (engine.paused) _pauseOverlay(theme),
                  if (engine.lastPowerup != null && engine.phase == 'playing')
                    Positioned(
                      top: MediaQuery.paddingOf(context).top + 82,
                      left: 0,
                      right: 0,
                      child: IgnorePointer(
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                            decoration: BoxDecoration(color: theme.panel.withOpacity(.85), borderRadius: BorderRadius.circular(13), border: Border.all(color: theme.primary.withOpacity(.3))),
                            child: Text(engine.lastPowerup!, style: TextStyle(color: theme.text, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _pauseOverlay(GameTheme theme) => Positioned.fill(
        child: Container(
          color: theme.bg.withOpacity(.68),
          alignment: Alignment.center,
          padding: const EdgeInsets.all(22),
          child: NeonPanel(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('توقف', style: TextStyle(color: theme.text, fontSize: 30, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 16),
                  NeonButton(label: 'ادامه', icon: 'resume', color: theme.accent, expand: true, onTap: () => engine.setPaused(false)),
                  const SizedBox(height: 10),
                  NeonButton(
                    label: 'شروع مجدد',
                    icon: 'restart',
                    color: theme.secondary,
                    expand: true,
                    onTap: () {
                      _resultHandled = false;
                      _lastTick = null;
                      engine.restart();
                    },
                  ),
                  const SizedBox(height: 10),
                  NeonButton(
                    label: 'خروج از مسابقه',
                    icon: 'exit',
                    color: theme.danger,
                    expand: true,
                    onTap: () async {
                      final exit = await showNeonConfirm(
                        context,
                        title: 'خروج از مسابقه',
                        message: 'نتیجه این مسابقه ثبت نمی‌شود.',
                        confirmLabel: 'خروج',
                        danger: true,
                      );
                      if (!exit || !mounted) return;
                      engine.abandon();
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      );

  void _handle(Offset position) {
    if (engine.paused || !engine.started) return;
    final owner = engine.twoPlayer && position.dy < engine.height / 2 ? 'top' : 'bottom';
    engine.setTarget(owner, position.dx);
  }

  Widget _score(int value, GameTheme theme) => Container(
        width: 62,
        height: 62,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: theme.panel.withOpacity(.88),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.primary.withOpacity(.4)),
          boxShadow: [BoxShadow(color: theme.primary.withOpacity(.12), blurRadius: 18)],
        ),
        child: Text('$value', style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 27)),
      );
}

class _GamePainter extends CustomPainter {
  final Engine engine;
  final GameTheme theme;

  _GamePainter(this.engine, this.theme) : super(repaint: engine);

  @override
  void paint(Canvas canvas, Size size) {
    final width = engine.width > 0 ? engine.width : size.width;
    final height = engine.height > 0 ? engine.height : size.height;
    canvas.drawRect(Rect.fromLTWH(0, 0, width, height), Paint()..color = theme.canvasBg);

    final grid = Paint()..color = theme.grid..strokeWidth = 1;
    for (var x = 0.0; x <= width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, height), grid);
    }
    for (var y = 0.0; y <= height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(width, y), grid);
    }
    canvas.drawLine(
      Offset(0, height / 2),
      Offset(width, height / 2),
      Paint()..color = theme.center.withOpacity(.42)..strokeWidth = 2,
    );

    if (engine.sideInset > 0) {
      canvas.drawRect(Rect.fromLTWH(0, 0, engine.sideInset, height), Paint()..color = Colors.white.withOpacity(.07));
      canvas.drawRect(Rect.fromLTWH(width - engine.sideInset, 0, engine.sideInset, height), Paint()..color = Colors.white.withOpacity(.07));
    }

    if (engine.state.trail && engine.trail.isNotEmpty) {
      for (var index = 0; index < engine.trail.length; index++) {
        final point = engine.trail[index];
        final ratio = (index + 1) / engine.trail.length;
        canvas.drawCircle(
          Offset(point.x, point.y),
          engine.ball.radius * ratio * .85,
          Paint()..color = (engine.state.ball.trailColor ?? theme.trail).withOpacity(ratio * .30),
        );
      }
    }

    for (final powerup in engine.powerups) {
      final color = _powerColor(powerup.type);
      canvas.drawCircle(Offset(powerup.x, powerup.y), powerup.radius, Paint()..color = color.withOpacity(.18));
      canvas.drawCircle(Offset(powerup.x, powerup.y), powerup.radius, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 2);
      _drawPowerGlyph(canvas, powerup, color);
    }

    final glow = switch (engine.state.quality) {'low' => 0.0, 'high' => 18.0, _ => 10.0};
    final ballColor = engine.state.ball.color ?? theme.ball;
    canvas.drawCircle(
      Offset(engine.ball.x, engine.ball.y),
      engine.ball.radius,
      Paint()..color = ballColor..maskFilter = glow > 0 ? MaskFilter.blur(BlurStyle.normal, glow) : null,
    );

    _drawPaddle(canvas, engine.top, theme.top, engine.effects['top']!['shield']! > 0, glow);
    _drawPaddle(canvas, engine.bottom, theme.bottom, engine.effects['bottom']!['shield']! > 0, glow);

    if (engine.state.debug) {
      final textPainter = TextPainter(
        textDirection: TextDirection.ltr,
        text: TextSpan(
          text: 'Phase: ${engine.phase}\nSpeed: ${engine.hypot.round()}\nPowerups: ${engine.powerups.length}',
          style: TextStyle(color: theme.text, fontSize: 11),
        ),
      )..layout();
      textPainter.paint(canvas, const Offset(10, 95));
    }
  }

  void _drawPaddle(Canvas canvas, PaddleState paddle, Color color, bool shield, double glow) {
    final rect = Rect.fromCenter(center: Offset(paddle.x, paddle.y), width: paddle.width, height: paddle.height);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(8)),
      Paint()..color = color..maskFilter = glow > 0 ? MaskFilter.blur(BlurStyle.normal, glow) : null,
    );
    if (shield) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect.inflate(5), const Radius.circular(11)),
        Paint()..color = theme.secondary..style = PaintingStyle.stroke..strokeWidth = 2,
      );
    }
  }

  void _drawPowerGlyph(Canvas canvas, Powerup powerup, Color color) {
    final painter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      text: TextSpan(
        text: switch (powerup.type) {'big' => '+', 'shrink' => '−', 'slow' => '◷', 'fast' => '⚡', 'shield' => '◇', _ => '¢'},
        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900),
      ),
    )..layout();
    painter.paint(canvas, Offset(powerup.x - painter.width / 2, powerup.y - painter.height / 2));
  }

  Color _powerColor(String type) => switch (type) {
        'big' => const Color(0xFF00FFC6),
        'shrink' => const Color(0xFFFF3B8D),
        'slow' => const Color(0xFF2DE2FF),
        'fast' => const Color(0xFFFFB84D),
        'shield' => const Color(0xFF8A5CFF),
        _ => const Color(0xFFFFD54D),
      };

  @override
  bool shouldRepaint(covariant _GamePainter oldDelegate) => oldDelegate.theme != theme || oldDelegate.engine != engine;
}
