#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
WARNINGS: list[str] = []
CHECKS: list[str] = []


def ok(message: str) -> None:
    CHECKS.append(message)


def fail(message: str) -> None:
    ERRORS.append(message)


def warn(message: str) -> None:
    WARNINGS.append(message)


def read(path: str) -> str:
    p = ROOT / path
    if not p.exists():
        fail(f"Missing required file: {path}")
        return ""
    return p.read_text(encoding="utf-8")


def strip_csharp(text: str) -> str:
    out: list[str] = []
    i = 0
    state = "code"
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if c == '/' and n == '/':
                state = "line_comment"; out.extend("  "); i += 2; continue
            if c == '/' and n == '*':
                state = "block_comment"; out.extend("  "); i += 2; continue
            if c == '@' and n == '"':
                state = "verbatim_string"; out.extend("  "); i += 2; continue
            if c == '"':
                state = "string"; out.append(' '); i += 1; continue
            if c == "'":
                state = "char"; out.append(' '); i += 1; continue
            out.append(c); i += 1; continue
        if state == "line_comment":
            if c == '\n': state = "code"; out.append('\n')
            else: out.append(' ')
            i += 1; continue
        if state == "block_comment":
            if c == '*' and n == '/': state = "code"; out.extend("  "); i += 2
            else: out.append('\n' if c == '\n' else ' '); i += 1
            continue
        if state == "string":
            if c == '\\': out.extend("  "); i += 2
            elif c == '"': state = "code"; out.append(' '); i += 1
            else: out.append('\n' if c == '\n' else ' '); i += 1
            continue
        if state == "verbatim_string":
            if c == '"' and n == '"': out.extend("  "); i += 2
            elif c == '"': state = "code"; out.append(' '); i += 1
            else: out.append('\n' if c == '\n' else ' '); i += 1
            continue
        if state == "char":
            if c == '\\': out.extend("  "); i += 2
            elif c == "'": state = "code"; out.append(' '); i += 1
            else: out.append(' '); i += 1
            continue
    if state in {"string", "verbatim_string", "char", "block_comment"}:
        fail(f"Unterminated C# lexical construct ({state})")
    return ''.join(out)


def balanced(text: str, path: Path) -> None:
    clean = strip_csharp(text)
    pairs = {'}': '{', ')': '(', ']': '['}
    stack: list[tuple[str, int]] = []
    for index, c in enumerate(clean):
        if c in '{([': stack.append((c, index))
        elif c in pairs:
            if not stack or stack[-1][0] != pairs[c]:
                fail(f"Unbalanced {c} in {path.relative_to(ROOT)} near offset {index}")
                return
            stack.pop()
    if stack:
        fail(f"Unclosed delimiter {stack[-1][0]} in {path.relative_to(ROOT)}")


def enum_members(text: str, enum_name: str) -> set[str]:
    match = re.search(rf'enum\s+{re.escape(enum_name)}\s*\{{([^}}]+)\}}', text, re.S)
    if not match:
        fail(f"Enum not found: {enum_name}")
        return set()
    return {part.strip().split('=')[0].strip() for part in match.group(1).split(',') if part.strip()}


def assert_contains(text: str, needle: str, message: str) -> None:
    if needle not in text: fail(message)
    else: ok(message)


def main() -> int:
    # Required project descriptors.
    version = read("ProjectSettings/ProjectVersion.txt")
    assert_contains(version, "2022.3.75f1", "Unity version is pinned to 2022.3.75f1")
    try:
        manifest = json.loads(read("Packages/manifest.json"))
        deps = manifest.get("dependencies", {})
        for package in ("com.unity.textmeshpro", "com.unity.ugui", "com.unity.test-framework"):
            if package not in deps: fail(f"Missing package: {package}")
        ok("Package manifest JSON is valid and contains required UI/test packages")
        runtime_asmdef = json.loads(read("Assets/Game/Menchino.RoyalSnakesLadders.asmdef"))
        for assembly_ref in ("Unity.TextMeshPro", "Unity.ugui"):
            if assembly_ref not in runtime_asmdef.get("references", []): fail(f"Runtime assembly is missing reference: {assembly_ref}")
        ok("Runtime assembly references TextMeshPro and UGUI")
    except json.JSONDecodeError as exc:
        fail(f"Invalid Packages/manifest.json: {exc}")

    csharp_files = sorted((ROOT / "Assets").rglob("*.cs"))
    if len(csharp_files) < 70: fail(f"Unexpectedly low C# file count: {len(csharp_files)}")
    else: ok(f"Modular C# source count: {len(csharp_files)} files")

    type_names: dict[str, Path] = {}
    for path in csharp_files:
        text = path.read_text(encoding="utf-8")
        balanced(text, path)
        for type_name in re.findall(r'\b(?:class|struct|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)', strip_csharp(text)):
            if type_name in type_names and type_name not in {"Forms"}:
                fail(f"Duplicate type name {type_name}: {path.relative_to(ROOT)} and {type_names[type_name].relative_to(ROOT)}")
            else:
                type_names[type_name] = path

    all_text = "\n".join(p.read_text(encoding="utf-8") for p in csharp_files)
    forbidden = re.findall(r'\b(?:TODO|FIXME|NotImplementedException|PLACEHOLDER_ASSET)\b', all_text, re.I)
    if forbidden: fail(f"Forbidden unfinished markers found: {sorted(set(forbidden))}")
    else: ok("No TODO/FIXME/NotImplementedException/placeholder-asset markers")

    image_files = [p for p in (ROOT / "Assets").rglob('*') if p.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.bmp'}]
    if image_files:
        warn("Static image files are present under Assets; verify they are independent art, not page screenshots: " + ", ".join(str(p.relative_to(ROOT)) for p in image_files))
    else:
        ok("No reference screenshots are embedded under Assets; UI is component/procedural")

    # Route completeness.
    route_text = read("Assets/Game/Core/AppRoute.cs")
    routes = enum_members(route_text, "AppRoute")
    installer = read("Assets/Game/Editor/RoyalProjectInstaller.cs")
    navigation = read("Assets/Game/Core/RoyalNavigationController.cs")
    for route in routes:
        if f"[AppRoute.{route}]" not in installer: fail(f"Route missing from installer mapping: {route}")
        if f"case AppRoute.{route}:" not in navigation: fail(f"Route missing from runtime navigation mapping: {route}")
    if routes and not ERRORS: ok(f"All {len(routes)} routes map to generated Prefabs/Scenes and runtime navigation")

    screen_files = list((ROOT / "Assets/Game/UI/Screens").glob("*Screen.cs"))
    if len(screen_files) < 28: fail(f"Expected at least 28 screen classes, found {len(screen_files)}")
    else: ok(f"Screen implementation count: {len(screen_files)}")

    # Core acceptance checks.
    board_view = read("Assets/Game/Board/BoardView.cs")
    assert_contains(board_view, "for (var cell = 1; cell <= 100; cell++)", "BoardView creates 100 real cells")
    mapper = read("Assets/Game/Board/BoardCoordinateMapper.cs")
    assert_contains(mapper, "rowFromBottom % 2 == 0", "Board mapping uses serpentine row order")
    engine = read("Assets/Game/Game/SnakesLaddersEngine.cs")
    for needle, label in [
        ("burnTurnOnThirdSix", "third consecutive six rule"),
        ("captureEnabled", "optional capture rule"),
        ("bounceBackAfterHundred", "optional bounce-back rule"),
        ("exactRollToFinish", "exact-roll finish rule"),
        ("TryGetTransition", "data-driven snake/ladder transitions"),
        ("AssignRemainingRanks", "end-of-match ranking")]:
        assert_contains(engine, needle, f"Engine includes {label}")

    die = read("Assets/Game/Board/RoyalDie3D.cs")
    for needle in ("RenderTexture", "BuildRoundedBody", "BuildPips", "RollTo", "RotationForResult"):
        assert_contains(die, needle, f"3D die implementation includes {needle}")

    font_provider = read("Assets/Game/Common/RoyalFontProvider.cs")
    assert_contains(font_provider, "LegacyRuntime.ttf", "Runtime font uses the Unity 2022 legacy built-in font resource")

    icon = read("Assets/Game/UI/RoyalIconGraphic.cs")
    assert_contains(icon, "MaskableGraphic", "Icons are procedural UI geometry rather than emoji-only assets")
    assert_contains(read("Assets/Game/UI/RoyalUIFactory.cs"), "RoyalIconGraphic.CanRender", "UI factory routes icon tokens to vector graphics")

    save = read("Assets/Game/Services/EncryptedSaveService.cs")
    for needle in ("HMACSHA256", "FixedTimeEquals", "schemaVersion", ".corrupt_"):
        assert_contains(save, needle, f"Save system includes {needle}")

    workflow = read(".github/workflows/build-android.yml")
    for needle in (
        "game-ci/unity-test-runner@v4.3.1",
        "game-ci/unity-builder@v5.0.0",
        "BuildApkBatch",
        "MarOPelePadshahi-Bazaar.apk",
        "MarOPelePadshahi-Myket.apk",
        "Upload failure logs",
        "Delete artifacts from older runs"):
        assert_contains(workflow, needle, f"Android workflow contains {needle}")

    # Source-level tests and critical anti-duplication safeguards.
    tests = "\n".join(p.read_text(encoding="utf-8") for p in (ROOT / "Assets/Game/Tests").rglob("*.cs"))
    for test_name in ("CellToGrid_IsSerpentine", "ExactHundred_RejectsOvershoot", "ThirdConsecutiveSix_BurnsTurn", "DuplicateColors_AreRejected", "MatchReward_IsAppliedOnlyOncePerMatchId", "Purchase_DeductsCurrencyAndPersistsOwnership", "ClaimMission_CannotPayTwice"):
        assert_contains(tests, test_name, f"EditMode tests include {test_name}")

    if "gameObject.AddComponent<MatchCoordinator>();\n            _coordinator = gameObject.AddComponent<MatchCoordinator>();" in all_text:
        fail("Duplicate MatchCoordinator component creation detected")
    else:
        ok("No duplicate MatchCoordinator creation")

    if re.search(r'=>\s*\{\s*\}', strip_csharp(all_text)):
        fail("Empty callback or method body detected")
    else:
        ok("No empty callbacks or no-op method bodies in C# source")

    # Report.
    report_lines = [
        "# گزارش اعتبارسنجی استاتیک پروژه",
        "",
        "- مسیر پروژه: `ریشه همین بسته`",
        f"- فایل‌های C#: **{len(csharp_files)}**",
        f"- کنترل‌های موفق: **{len(CHECKS)}**",
        f"- هشدارها: **{len(WARNINGS)}**",
        f"- خطاها: **{len(ERRORS)}**",
        "",
        "## کنترل‌های موفق",
    ]
    report_lines += [f"- {item}" for item in CHECKS]
    report_lines += ["", "## هشدارها"] + ([f"- {item}" for item in WARNINGS] or ["- موردی ثبت نشد."])
    report_lines += ["", "## خطاها"] + ([f"- {item}" for item in ERRORS] or ["- موردی ثبت نشد."])
    report_lines += [
        "",
        "## محدودیت اعتبارسنجی",
        "این گزارش ساختار، قراردادها، مسیرها، داده‌ها و الگوهای خطای شناخته‌شده را بررسی می‌کند. اجرای Compile واقعی، EditMode Test و Android Build باید داخل Unity Editor یا Workflow انجام شود.",
    ]
    (ROOT / "Docs/STATIC_VALIDATION_REPORT.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")

    print("\n".join(report_lines[:7]))
    if WARNINGS:
        print("Warnings:")
        for item in WARNINGS: print(" -", item)
    if ERRORS:
        print("Errors:")
        for item in ERRORS: print(" -", item)
        return 1
    print(f"Static validation passed: {len(CHECKS)} checks")
    return 0


if __name__ == "__main__":
    sys.exit(main())
