# تطبیق صفحات مرجع

فایل مرجع شامل ۲۷ صفحه بود. برای هر مورد Route، Screen Component، Prefab و Scene مستقل تعریف شده است.

| صفحه مرجع | Route / Screen |
|---|---|
| اسپلش | `Splash / SplashScreen` |
| انتخاب زبان اولیه | `Language / LanguageScreen` |
| ورود اولیه یا مهمان | `Login / LoginScreen` |
| صفحه اصلی | `Home / HomeScreen` |
| انتخاب حالت بازی | `ModeSelection / ModeSelectionScreen` |
| تنظیمات بازی با ربات | `BotSetup / BotSetupScreen` |
| بازی دونفره روی یک گوشی | `LocalTwoPlayer / LocalTwoPlayerScreen` |
| ساخت اتاق دوستانه | `FriendlyRoomCreate / FriendlyRoomCreateScreen` |
| ورود به اتاق | `FriendlyRoomJoin / FriendlyRoomJoinScreen` |
| لابی اتاق دوستانه | `FriendlyLobby / FriendlyLobbyScreen` |
| حریف‌یابی آنلاین | `Matchmaking / MatchmakingScreen` |
| صفحه اصلی بازی | `Gameplay / GameplayScreen` |
| نتیجه مسابقه | `Results / ResultsScreen` |
| فروشگاه | `Shop / ShopScreen` |
| جزئیات محصول | `ProductDetails / ProductDetailsScreen` |
| صندوق جوایز | `RewardChest / RewardChestScreen` |
| لیگ و رتبه‌بندی | `League / LeagueScreen` |
| مأموریت‌های روزانه | `Missions / MissionsScreen` |
| دوستان | `Friends / FriendsScreen` |
| پیام‌ها و دعوت‌ها | `Messages / MessagesScreen` |
| پروفایل | `Profile / ProfileScreen` |
| ویرایش پروفایل | `ProfileEdit / ProfileEditScreen` |
| تنظیمات | `Settings / SettingsScreen` |
| قوانین بازی | `Rules / RulesScreen` |
| پشتیبانی | `Support / SupportScreen` |
| پاپ‌آپ انتخاب مهره | `PiecePickerPopup / PiecePickerPopupScreen` |
| پاپ‌آپ توقف بازی | `PausePopup / PausePopupScreen` |

صفحه `Tutorial` نیز برای آموزش تعاملی اولیه اضافه شده است.
