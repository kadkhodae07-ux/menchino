# Build اندروید

## پیش‌نیاز

در Unity Hub برای نسخه پروژه ماژول‌های زیر نصب شوند:

- Android Build Support
- Android SDK & NDK Tools
- OpenJDK

## Build محلی

1. پروژه را باز کنید و منتظر پایان Import بمانید.
2. از منوی Menchino نصب یا بروزرسانی را اجرا کنید.
3. APK یا AAB را از منوی همان بخش بسازید.

## امضای Release

چهار متغیر محیطی توسط `AndroidBuild` خوانده می‌شوند:

```text
ANDROID_KEYSTORE_PATH
ANDROID_KEYSTORE_PASS
ANDROID_KEYALIAS_NAME
ANDROID_KEYALIAS_PASS
```

اگر فایل Keystore معتبر در مسیر تعیین‌شده وجود نداشته باشد، Custom Keystore غیرفعال می‌شود.

## بررسی قبل از انتشار

- Package Name و Version Code
- امضای نهایی
- آیکن Adaptive و Splash فروشگاه
- Privacy Policy
- Receipt Validation
- Backend Production
- تست دستگاه‌های 720×1280، 1080×1920 و نمایشگر کشیده
