# گزارش اعتبارسنجی استاتیک پروژه

- مسیر پروژه: `ریشه همین بسته`
- فایل‌های C#: **78**
- کنترل‌های موفق: **44**
- هشدارها: **0**
- خطاها: **0**

## کنترل‌های موفق
- Unity version is pinned to 2022.3.75f1
- Package manifest JSON is valid and contains required UI/test packages
- Runtime assembly references TextMeshPro and UGUI
- Modular C# source count: 78 files
- No TODO/FIXME/NotImplementedException/placeholder-asset markers
- No reference screenshots are embedded under Assets; UI is component/procedural
- All 28 routes map to generated Prefabs/Scenes and runtime navigation
- Screen implementation count: 28
- BoardView creates 100 real cells
- Board mapping uses serpentine row order
- Engine includes third consecutive six rule
- Engine includes optional capture rule
- Engine includes optional bounce-back rule
- Engine includes exact-roll finish rule
- Engine includes data-driven snake/ladder transitions
- Engine includes end-of-match ranking
- 3D die implementation includes RenderTexture
- 3D die implementation includes BuildRoundedBody
- 3D die implementation includes BuildPips
- 3D die implementation includes RollTo
- 3D die implementation includes RotationForResult
- Runtime font uses the Unity 2022 legacy built-in font resource
- Icons are procedural UI geometry rather than emoji-only assets
- UI factory routes icon tokens to vector graphics
- Save system includes HMACSHA256
- Save system includes FixedTimeEquals
- Save system includes schemaVersion
- Save system includes .corrupt_
- Android workflow contains game-ci/unity-test-runner@v4.3.1
- Android workflow contains game-ci/unity-builder@v5.0.0
- Android workflow contains BuildApkBatch
- Android workflow contains MarOPelePadshahi-Bazaar.apk
- Android workflow contains MarOPelePadshahi-Myket.apk
- Android workflow contains Upload failure logs
- Android workflow contains Delete artifacts from older runs
- EditMode tests include CellToGrid_IsSerpentine
- EditMode tests include ExactHundred_RejectsOvershoot
- EditMode tests include ThirdConsecutiveSix_BurnsTurn
- EditMode tests include DuplicateColors_AreRejected
- EditMode tests include MatchReward_IsAppliedOnlyOncePerMatchId
- EditMode tests include Purchase_DeductsCurrencyAndPersistsOwnership
- EditMode tests include ClaimMission_CannotPayTwice
- No duplicate MatchCoordinator creation
- No empty callbacks or no-op method bodies in C# source

## هشدارها
- موردی ثبت نشد.

## خطاها
- موردی ثبت نشد.

## محدودیت اعتبارسنجی
این گزارش ساختار، قراردادها، مسیرها، داده‌ها و الگوهای خطای شناخته‌شده را بررسی می‌کند. اجرای Compile واقعی، EditMode Test و Android Build باید داخل Unity Editor یا Workflow انجام شود.
