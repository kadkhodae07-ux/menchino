# معماری

## Core

- `RoyalGameApp`: Composition Root و ساخت Canvas/Services
- `RoyalNavigationController`: Stack Navigation و Back اندروید
- `RoyalEventBus`: رویدادهای کم‌وابستگی
- `RoyalServiceRegistry`: Dependency Registry محدود

## Game Engine

`SnakesLaddersEngine` هیچ وابستگی به UI ندارد. ورودی آن `MatchConfig` و `IDiceService` است و خروجی آن Snapshot و RollResolution است.

مراحل Roll:

1. اعتبارسنجی State
2. دریافت نتیجه تاس
3. بررسی سومین ۶
4. ساخت مسیر خانه‌به‌خانه
5. بررسی مار یا نردبان
6. بررسی برخورد
7. بررسی خانه ۱۰۰
8. تعیین نوبت بعد یا پایان

## UI

- تمام UI در Runtime از Componentهای واقعی Unity ساخته می‌شود.
- `RoyalUIFactory` دکمه، پنل، متن، Slider، Toggle، Scroll و Progress را می‌سازد.
- `RoyalThemeAsset` منبع رنگ، اندازه، فاصله و Animation Token است.
- صفحات داخل `UI/Screens` مستقل هستند.
- هیچ صفحه کامل PNG داخل Build وجود ندارد.

## Board

- `BoardCoordinateMapper`: نگاشت Cell و Grid
- `BoardView`: ساخت ۱۰۰ خانه، مار، نردبان و مهره‌ها
- `RoyalLineGraphic`: ترسیم مسیر مستقل
- `RoyalDie3D`: RenderTexture و مدل سه‌بعدی Runtime

## Data and Services

- `RoyalCatalogAsset`: محصولات، مأموریت‌ها، لیگ و دوستان
- `EncryptedSaveService`: Save رمزگذاری‌شده و Atomic Write
- `CatalogService`: مالکیت و انتخاب آیتم
- `MockNetworkService`: Adapter آزمایشی قابل تعویض با Backend
