# مار و پله پادشاهی — پروژه Unity

پروژه اندرویدی Portrait با معماری ماژولار، UI کامپوننتی و موتور مستقل بازی مار و پله. تصاویر ZIP مرجع فقط برای تحلیل زبان بصری استفاده شده‌اند و هیچ Screenshot کامل، Click Map یا صفحه تصویری داخل پروژه قرار نگرفته است.

## نسخه و شناسه

- Unity: `2022.3.75f1 LTS`
- Package Name: `mk.kadkhodai.menchino`
- Version: `1.0.0`
- Android minSdk: 24
- معماری خروجی: ARM64
- Backend فعلی: Adapter آزمایشی محلی؛ سرویس واقعی در بخش «موارد نیازمند سرویس واقعی» توضیح داده شده است.

## شروع سریع

1. پوشه پروژه را با Unity Hub و نسخه `2022.3.75f1` باز کنید.
2. پس از نخستین Compile، نصب‌کننده خودکار موارد زیر را می‌سازد:
   - Theme و Catalog داخل `Assets/Game/Generated/Resources`
   - Prefab مستقل تمام صفحات
   - Scene مستقل تمام صفحات
   - Scene اصلی `Bootstrap`
   - Build Settings اندروید
3. Scene زیر را اجرا کنید:
   - `Assets/Game/Generated/Scenes/Bootstrap.unity`
4. برای بازسازی خودکار فایل‌های Generated:
   - `Menchino > مار و پله پادشاهی > نصب یا بروزرسانی پروژه`

## خروجی اندروید

- APK:
  - `Menchino > مار و پله پادشاهی > ساخت APK اندروید`
- AAB:
  - `Menchino > مار و پله پادشاهی > ساخت AAB اندروید`
- خروجی‌ها در `Builds/Android` ذخیره می‌شوند.

## امکانات پیاده‌سازی‌شده

- UI سلطنتی آبی/طلایی با Safe Area و ScaleWithScreenSize
- صفحات مستقل و قابل Navigation برای ۲۷ صفحه مرجع به‌علاوه آموزش
- TextMeshPro با فونت Dynamic داخلی، شکل‌دهی فارسی و مدیریت متن‌های Runtime
- آیکن‌های مستقل Procedural/Vector بدون استفاده از Emoji به‌عنوان آیکن نهایی
- Bottom Navigation سه‌قسمتی: فروشگاه، خانه، پروفایل
- تخته واقعی ۱۰×۱۰ و شماره‌گذاری مارپیچی ۱ تا ۱۰۰
- مارها و نردبان‌های داده‌ای
- حرکت مرحله‌ای مهره‌ها و Offset چند مهره روی یک خانه
- تاس سه‌بعدی Runtime با نتیجه از پیش تعیین‌شده و توقف دقیق
- بازی ۲، ۳ و ۴ نفره
- بازی با ربات و بازی محلی روی یک گوشی
- قوانین اختیاری: نوبت اضافه ۶، سومین ۶، برخورد، خانه ۱۰۰، شروع با ۶، Bounce، تایمر
- نتیجه و رتبه‌بندی مسابقه
- فروشگاه داده‌محور، خرید محلی سکه/الماس، انتخاب آیتم
- پروفایل، لیگ، مأموریت، دوستان، پیام‌ها، صندوق روزانه و تنظیمات
- Save رمزگذاری‌شده و نسخه‌دار
- صدای Procedural برای کلیک، تاس، حرکت، مار، نردبان، برد و خطا
- تست‌های EditMode برای موتور حیاتی
- Workflow اعتبارسنجی، EditMode Test و ساخت APK/AAB در GitHub Actions

## ساختار اصلی

```text
Assets/Game/
├── Core
├── Game
├── UI
│   └── Screens
├── Board
├── Players
├── Bots
├── Networking
├── Audio
├── Data
├── Services
├── Shop
├── Profile
├── League
├── Missions
├── Settings
├── Common
├── Editor
└── Tests
```

## موارد نیازمند سرویس واقعی

موارد زیر دارای Interface و UI اجرایی هستند، اما برای انتشار آنلاین باید به Backend معتبر متصل شوند:

- ورود شماره موبایل و OTP
- Matchmaking و WebSocket واقعی
- اتاق خصوصی و دعوت دوستان
- Dice سرورمحور و Snapshot/Reconnect
- ذخیره قطعی سکه، الماس، لیگ و جوایز روی سرور
- اعتبارسنجی Receipt بازار/مایکت/Google Play
- جدول رتبه‌بندی جهانی و کشوری
- Push Notification
- پشتیبانی و تیکت آنلاین
- حذف حساب و حریم خصوصی سمت سرور

`MockNetworkService` فقط برای اجرای کامل UI و مسیرهای پروژه بدون Backend استفاده می‌شود و منبع قطعی بازی آنلاین نیست.

## نکات امنیتی

- Save محلی با AES رمزگذاری می‌شود.
- کلید از شناسه دستگاه و Salt پروژه مشتق می‌شود.
- موجودی و خرید آنلاین در نسخه انتشار نباید فقط از Save محلی خوانده شود.
- اطلاعات ورود، رمز Keystore و کلید سرویس‌ها نباید داخل سورس Commit شوند.

## Workflow

فایل `.github/workflows/build-android.yml` ابتدا تست‌ها را اجرا می‌کند و سپس APK و AAB را می‌سازد. Secretهای لازم:

- `UNITY_LICENSE`
- `UNITY_EMAIL`
- `UNITY_PASSWORD`
- `ANDROID_KEYSTORE_BASE64` اختیاری برای امضای Release
- `ANDROID_KEYSTORE_PASS`
- `ANDROID_KEYALIAS_NAME`
- `ANDROID_KEYALIAS_PASS`

در نبود Keystore، Build با امضای توسعه انجام می‌شود و برای انتشار فروشگاهی مناسب نیست.

## گزارش‌های کنترل کیفیت

- `Docs/STATIC_VALIDATION_REPORT.md`
- `Docs/ACCEPTANCE_CHECKLIST.md`
- `Docs/PROJECT_STATUS.md`
- `Docs/ASSET_POLICY.md`

این بسته در محیطی بدون Unity Editor تولید شده است؛ بنابراین ادعای Compile یا Build محلی نشده است. Workflow موجود Compile، Test و Android Build را در محیط دارای لایسنس Unity انجام می‌دهد.
