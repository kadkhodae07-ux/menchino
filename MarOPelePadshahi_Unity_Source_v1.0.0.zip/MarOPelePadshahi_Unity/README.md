# مار و پله پادشاهی — Unity Source

راهنمای کامل فارسی پروژه در فایل [`README_FA.md`](README_FA.md) قرار دارد.
