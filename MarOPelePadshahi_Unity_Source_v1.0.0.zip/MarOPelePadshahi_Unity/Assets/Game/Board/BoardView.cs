using System.Collections;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.Board
{
    public sealed class BoardView : MonoBehaviour
    {
        private readonly Dictionary<int, RectTransform> _cells = new Dictionary<int, RectTransform>();
        private readonly Dictionary<int, RectTransform> _pawns = new Dictionary<int, RectTransform>();
        private RoyalUIFactory _ui;
        private RectTransform _boardRoot;
        private BoardDefinition _definition;
        private readonly Color[] _pawnColors =
        {
            new Color32(29, 125, 220, 255),
            new Color32(218, 68, 49, 255),
            new Color32(58, 180, 72, 255),
            new Color32(129, 70, 205, 255)
        };

        public void Build(RoyalUIFactory ui, BoardDefinition definition)
        {
            _ui = ui;
            _definition = definition;
            var root = GetComponent<RectTransform>() ?? gameObject.AddComponent<RectTransform>();
            var frame = ui.Panel("BoardFrame", root, new Color32(92, 63, 30, 255), new Color32(32, 26, 22, 255), ui.Theme.gold, 20, 7);
            frame.rectTransform.anchorMin = Vector2.zero;
            frame.rectTransform.anchorMax = Vector2.one;
            frame.rectTransform.offsetMin = Vector2.zero;
            frame.rectTransform.offsetMax = Vector2.zero;

            _boardRoot = ui.Rect("BoardGrid", frame.transform).GetComponent<RectTransform>();
            _boardRoot.anchorMin = Vector2.zero;
            _boardRoot.anchorMax = Vector2.one;
            _boardRoot.offsetMin = new Vector2(18, 18);
            _boardRoot.offsetMax = new Vector2(-18, -18);

            BuildCells();
            BuildTransitions();
        }

        private void BuildCells()
        {
            for (var cell = 1; cell <= 100; cell++)
            {
                var grid = BoardCoordinateMapper.CellToGrid(cell);
                var min = new Vector2(grid.x / 10f, grid.y / 10f);
                var max = new Vector2((grid.x + 1) / 10f, (grid.y + 1) / 10f);
                var isBlue = (grid.x + grid.y) % 2 == 0;
                var colorTop = isBlue ? new Color32(27, 94, 143, 255) : new Color32(218, 184, 125, 255);
                var colorBottom = isBlue ? new Color32(12, 57, 101, 255) : new Color32(155, 113, 60, 255);
                var image = _ui.Panel("Cell_" + cell, _boardRoot, colorTop, colorBottom, new Color32(78, 57, 35, 255), 4, 1);
                var rect = image.rectTransform;
                rect.anchorMin = min;
                rect.anchorMax = max;
                rect.offsetMin = new Vector2(1.2f, 1.2f);
                rect.offsetMax = new Vector2(-1.2f, -1.2f);
                _cells[cell] = rect;
                var label = _ui.Text("Number", rect, cell.ToString(), 20, isBlue ? _ui.Theme.lightGold : new Color32(28, 44, 58, 255), TextAlignmentOptions.TopLeft, FontStyles.Bold);
                label.rectTransform.anchorMin = Vector2.zero;
                label.rectTransform.anchorMax = Vector2.one;
                label.rectTransform.offsetMin = new Vector2(5, 2);
                label.rectTransform.offsetMax = new Vector2(-2, -3);
            }
        }

        private void BuildTransitions()
        {
            foreach (var transition in _definition.transitions)
            {
                if (transition.IsLadder) BuildLadder(transition.from, transition.to);
                else BuildSnake(transition.from, transition.to);
            }
        }

        private void BuildLadder(int from, int to)
        {
            var a = CellAnchor(from);
            var b = CellAnchor(to);
            var direction = (b - a).normalized;
            var normal = new Vector2(-direction.y, direction.x) * 0.018f;
            BuildLine("LadderRailA", new[] { a - normal, b - normal }, new Color32(240, 171, 43, 255), 9f);
            BuildLine("LadderRailB", new[] { a + normal, b + normal }, new Color32(240, 171, 43, 255), 9f);
            var distance = Vector2.Distance(a, b);
            var rungCount = Mathf.Clamp(Mathf.RoundToInt(distance * 18f), 4, 12);
            for (var i = 1; i < rungCount; i++)
            {
                var t = i / (float)rungCount;
                var center = Vector2.Lerp(a, b, t);
                BuildLine("LadderRung", new[] { center - normal * 1.2f, center + normal * 1.2f }, new Color32(255, 204, 78, 255), 7f);
            }
        }

        private void BuildSnake(int from, int to)
        {
            var start = CellAnchor(from);
            var end = CellAnchor(to);
            var points = new List<Vector2>();
            var side = (from % 2 == 0 ? 1f : -1f) * 0.055f;
            for (var i = 0; i <= 16; i++)
            {
                var t = i / 16f;
                var basePoint = Vector2.Lerp(start, end, t);
                var wave = Mathf.Sin(t * Mathf.PI * 3f) * side * (0.55f + 0.45f * Mathf.Sin(t * Mathf.PI));
                points.Add(basePoint + new Vector2(wave, -wave * 0.35f));
            }
            var paletteIndex = Mathf.Abs(from + to) % 4;
            var colors = new[]
            {
                new Color32(69, 175, 76, 255),
                new Color32(201, 60, 49, 255),
                new Color32(44, 126, 210, 255),
                new Color32(126, 70, 184, 255)
            };
            BuildLine("Snake", points, colors[paletteIndex], 16f);
            var head = _ui.Panel("SnakeHead", _boardRoot, Color.Lerp(colors[paletteIndex], Color.white, 0.16f), colors[paletteIndex], _ui.Theme.gold, 18, 2);
            head.rectTransform.anchorMin = head.rectTransform.anchorMax = start;
            head.rectTransform.sizeDelta = new Vector2(34, 28);
            head.rectTransform.anchoredPosition = Vector2.zero;
        }

        private void BuildLine(string name, IEnumerable<Vector2> points, Color color, float thickness)
        {
            var lineObject = _ui.Rect(name, _boardRoot);
            var rect = lineObject.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            var line = lineObject.AddComponent<RoyalLineGraphic>();
            line.color = color;
            line.thickness = thickness;
            line.raycastTarget = false;
            line.SetPoints(points);
        }

        public void CreatePawn(int playerIndex, int cell)
        {
            if (_pawns.ContainsKey(playerIndex)) return;
            var pawn = _ui.Panel("Pawn_" + playerIndex, _boardRoot, Color.Lerp(_pawnColors[playerIndex], Color.white, 0.18f), Color.Lerp(_pawnColors[playerIndex], Color.black, 0.25f), _ui.Theme.lightGold, 16, 2);
            var rect = pawn.rectTransform;
            rect.anchorMin = rect.anchorMax = cell <= 0 ? StartAnchor(playerIndex) : OffsetAnchor(cell, playerIndex);
            rect.sizeDelta = new Vector2(38, 46);
            rect.anchoredPosition = Vector2.zero;
            var symbol = _ui.Icon("PawnSymbol", rect, "pawn", _ui.Theme.textPrimary);
            symbol.rectTransform.anchorMin = new Vector2(0.18f, 0.10f);
            symbol.rectTransform.anchorMax = new Vector2(0.82f, 0.90f);
            symbol.rectTransform.offsetMin = Vector2.zero;
            symbol.rectTransform.offsetMax = Vector2.zero;
            _pawns[playerIndex] = rect;
        }

        public IEnumerator AnimatePath(int playerIndex, IReadOnlyList<int> path, float stepDuration = 0.18f)
        {
            if (!_pawns.TryGetValue(playerIndex, out var pawn)) yield break;
            for (var i = 0; i < path.Count; i++)
                yield return MovePawn(pawn, OffsetAnchor(path[i], playerIndex), stepDuration, true);
        }

        public IEnumerator AnimateTransition(int playerIndex, int from, int to, bool ladder)
        {
            if (!_pawns.TryGetValue(playerIndex, out var pawn)) yield break;
            var start = OffsetAnchor(from, playerIndex);
            var end = OffsetAnchor(to, playerIndex);
            var duration = ladder ? 0.75f : 0.9f;
            var elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                var t = Mathf.Clamp01(elapsed / duration);
                var eased = t * t * (3f - 2f * t);
                var point = Vector2.Lerp(start, end, eased);
                point += ladder ? new Vector2(0, Mathf.Sin(t * Mathf.PI * 8f) * 0.006f) : new Vector2(Mathf.Sin(t * Mathf.PI * 3f) * 0.025f, 0);
                pawn.anchorMin = pawn.anchorMax = point;
                yield return null;
            }
            pawn.anchorMin = pawn.anchorMax = end;
        }

        public void SetPawnCell(int playerIndex, int cell)
        {
            if (!_pawns.TryGetValue(playerIndex, out var pawn)) return;
            pawn.anchorMin = pawn.anchorMax = cell <= 0 ? StartAnchor(playerIndex) : OffsetAnchor(cell, playerIndex);
        }

        private IEnumerator MovePawn(RectTransform pawn, Vector2 target, float duration, bool hop)
        {
            var start = pawn.anchorMin;
            var elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                var t = Mathf.Clamp01(elapsed / duration);
                var point = Vector2.Lerp(start, target, t);
                pawn.anchorMin = pawn.anchorMax = point;
                pawn.anchoredPosition = hop ? new Vector2(0, Mathf.Sin(t * Mathf.PI) * 10f) : Vector2.zero;
                yield return null;
            }
            pawn.anchorMin = pawn.anchorMax = target;
            pawn.anchoredPosition = Vector2.zero;
        }

        private static Vector2 CellAnchor(int cell)
        {
            var grid = BoardCoordinateMapper.CellToGrid(cell);
            return new Vector2((grid.x + 0.5f) / 10f, (grid.y + 0.5f) / 10f);
        }

        private static Vector2 OffsetAnchor(int cell, int playerIndex)
        {
            var baseAnchor = CellAnchor(cell);
            var offsets = new[]
            {
                new Vector2(-0.012f, 0.012f),
                new Vector2(0.012f, 0.012f),
                new Vector2(-0.012f, -0.012f),
                new Vector2(0.012f, -0.012f)
            };
            return baseAnchor + offsets[Mathf.Clamp(playerIndex, 0, offsets.Length - 1)];
        }

        private static Vector2 StartAnchor(int playerIndex) => new Vector2(0.04f + playerIndex * 0.035f, -0.035f);
    }
}
