using System;
using System.Collections;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Services;
using Menchino.RoyalSnakesLadders.UI;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.Board
{
    public enum DieVisualState { Ready, Rolling, Locked, WaitingTurn, Result, Disabled, Disconnected }

    [RequireComponent(typeof(RawImage))]
    public sealed class RoyalDie3D : MonoBehaviour
    {
        private RawImage _image;
        private RenderTexture _renderTexture;
        private GameObject _worldRoot;
        private Transform _die;
        private Camera _camera;
        private IAudioService _audio;
        private Coroutine _rollRoutine;
        private Material _ivory;
        private Material _gold;
        private Material _navy;
        public DieVisualState State { get; private set; } = DieVisualState.Ready;
        public int CurrentResult { get; private set; } = 1;

        public void Initialize(IAudioService audio)
        {
            _audio = audio;
            _image = GetComponent<RawImage>();
            BuildWorld();
        }

        public void SetState(DieVisualState state)
        {
            State = state;
            if (_image != null)
                _image.color = state == DieVisualState.Disabled || state == DieVisualState.Disconnected ? new Color(0.45f, 0.45f, 0.45f, 0.75f) : Color.white;
        }

        public void RollTo(int result, Action onComplete)
        {
            if (State == DieVisualState.Rolling || result < 1 || result > 6) return;
            if (_rollRoutine != null) StopCoroutine(_rollRoutine);
            _rollRoutine = StartCoroutine(RollRoutine(result, onComplete));
        }

        private IEnumerator RollRoutine(int result, Action onComplete)
        {
            State = DieVisualState.Rolling;
            _audio?.PlayDice();
            var startRotation = _die.rotation;
            var targetRotation = RotationForResult(result);
            var startPosition = _die.localPosition;
            const float duration = 0.82f;
            var elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                var t = Mathf.Clamp01(elapsed / duration);
                var lift = Mathf.Sin(t * Mathf.PI) * 0.75f;
                _die.localPosition = startPosition + Vector3.up * lift;
                if (t < 0.68f)
                {
                    var spin = Quaternion.Euler(900f * t, 720f * t, 560f * t);
                    _die.rotation = startRotation * spin;
                }
                else
                {
                    var settle = Mathf.InverseLerp(0.68f, 1f, t);
                    settle = 1f - Mathf.Pow(1f - settle, 3f);
                    _die.rotation = Quaternion.Slerp(_die.rotation, targetRotation, settle);
                }
                yield return null;
            }
            _die.localPosition = startPosition;
            _die.rotation = targetRotation;
            CurrentResult = result;
            State = DieVisualState.Result;
            _rollRoutine = null;
            onComplete?.Invoke();
        }

        private void BuildWorld()
        {
            _renderTexture = new RenderTexture(420, 420, 24, RenderTextureFormat.ARGB32)
            {
                name = "RoyalDieRenderTexture",
                antiAliasing = 4,
                filterMode = FilterMode.Bilinear
            };
            _renderTexture.Create();
            _image.texture = _renderTexture;
            _image.color = Color.white;

            _worldRoot = new GameObject("RoyalDieWorld");
            _worldRoot.hideFlags = HideFlags.HideAndDontSave;
            _camera = new GameObject("DieCamera").AddComponent<Camera>();
            _camera.transform.SetParent(_worldRoot.transform, false);
            _camera.transform.localPosition = new Vector3(0, 1.1f, -6.2f);
            _camera.transform.LookAt(new Vector3(0, 0.25f, 0));
            _camera.clearFlags = CameraClearFlags.SolidColor;
            _camera.backgroundColor = new Color(0, 0, 0, 0);
            _camera.orthographic = false;
            _camera.fieldOfView = 34f;
            _camera.targetTexture = _renderTexture;
            _camera.cullingMask = 1 << 30;

            _ivory = CreateMaterial(new Color32(244, 231, 195, 255), 0.12f, 0.72f);
            _gold = CreateMaterial(new Color32(231, 164, 35, 255), 0.18f, 0.82f);
            _navy = CreateMaterial(new Color32(6, 34, 68, 255), 0.25f, 0.58f);

            var pedestal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pedestal.name = "Pedestal";
            pedestal.layer = 30;
            pedestal.transform.SetParent(_worldRoot.transform, false);
            pedestal.transform.localPosition = new Vector3(0, -1.02f, 0.2f);
            pedestal.transform.localScale = new Vector3(1.65f, 0.22f, 1.65f);
            pedestal.GetComponent<Renderer>().material = _navy;
            DestroyImmediateSafe(pedestal.GetComponent<Collider>());

            var pedestalRing = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pedestalRing.name = "GoldRing";
            pedestalRing.layer = 30;
            pedestalRing.transform.SetParent(_worldRoot.transform, false);
            pedestalRing.transform.localPosition = new Vector3(0, -0.88f, 0.2f);
            pedestalRing.transform.localScale = new Vector3(1.45f, 0.10f, 1.45f);
            pedestalRing.GetComponent<Renderer>().material = _gold;
            DestroyImmediateSafe(pedestalRing.GetComponent<Collider>());

            _die = new GameObject("Die").transform;
            _die.SetParent(_worldRoot.transform, false);
            _die.localPosition = new Vector3(0, 0.22f, 0);
            BuildRoundedBody(_die);
            BuildPips(_die);

            var key = new GameObject("KeyLight").AddComponent<Light>();
            key.type = LightType.Directional;
            key.color = new Color(1f, 0.83f, 0.56f);
            key.intensity = 1.35f;
            key.transform.SetParent(_worldRoot.transform, false);
            key.transform.rotation = Quaternion.Euler(38, -34, 0);
            key.gameObject.layer = 30;

            var fill = new GameObject("FillLight").AddComponent<Light>();
            fill.type = LightType.Point;
            fill.color = new Color(0.17f, 0.55f, 1f);
            fill.intensity = 2.0f;
            fill.range = 8f;
            fill.transform.SetParent(_worldRoot.transform, false);
            fill.transform.localPosition = new Vector3(-2.4f, 1.8f, -2.2f);
            fill.gameObject.layer = 30;
        }

        private void BuildRoundedBody(Transform parent)
        {
            var core = GameObject.CreatePrimitive(PrimitiveType.Cube);
            core.name = "IvoryCore";
            core.layer = 30;
            core.transform.SetParent(parent, false);
            core.transform.localScale = new Vector3(1.55f, 1.55f, 1.55f);
            core.GetComponent<Renderer>().material = _ivory;
            DestroyImmediateSafe(core.GetComponent<Collider>());

            var edgeRadius = 0.17f;
            var half = 0.77f;
            var edgePositions = new List<(Vector3 position, Vector3 scale, Quaternion rotation)>();
            for (var x = -1; x <= 1; x += 2)
                for (var y = -1; y <= 1; y += 2)
                    edgePositions.Add((new Vector3(x * half, y * half, 0), new Vector3(edgeRadius, 0.77f, edgeRadius), Quaternion.Euler(90, 0, 0)));
            for (var x = -1; x <= 1; x += 2)
                for (var z = -1; z <= 1; z += 2)
                    edgePositions.Add((new Vector3(x * half, 0, z * half), new Vector3(edgeRadius, 0.77f, edgeRadius), Quaternion.identity));
            for (var y = -1; y <= 1; y += 2)
                for (var z = -1; z <= 1; z += 2)
                    edgePositions.Add((new Vector3(0, y * half, z * half), new Vector3(edgeRadius, 0.77f, edgeRadius), Quaternion.Euler(0, 0, 90)));

            foreach (var edge in edgePositions)
            {
                var cylinder = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                cylinder.name = "RoundedEdge";
                cylinder.layer = 30;
                cylinder.transform.SetParent(parent, false);
                cylinder.transform.localPosition = edge.position;
                cylinder.transform.localRotation = edge.rotation;
                cylinder.transform.localScale = edge.scale;
                cylinder.GetComponent<Renderer>().material = _ivory;
                DestroyImmediateSafe(cylinder.GetComponent<Collider>());
            }

            for (var x = -1; x <= 1; x += 2)
                for (var y = -1; y <= 1; y += 2)
                    for (var z = -1; z <= 1; z += 2)
                    {
                        var sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        sphere.name = "RoundedCorner";
                        sphere.layer = 30;
                        sphere.transform.SetParent(parent, false);
                        sphere.transform.localPosition = new Vector3(x * half, y * half, z * half);
                        sphere.transform.localScale = Vector3.one * edgeRadius * 2f;
                        sphere.GetComponent<Renderer>().material = _ivory;
                        DestroyImmediateSafe(sphere.GetComponent<Collider>());
                    }
        }

        private void BuildPips(Transform parent)
        {
            CreateFacePips(parent, 1, Vector3.up, Vector3.right, Vector3.forward);
            CreateFacePips(parent, 6, Vector3.down, Vector3.right, Vector3.back);
            CreateFacePips(parent, 2, Vector3.back, Vector3.right, Vector3.up);
            CreateFacePips(parent, 5, Vector3.forward, Vector3.left, Vector3.up);
            CreateFacePips(parent, 3, Vector3.right, Vector3.back, Vector3.up);
            CreateFacePips(parent, 4, Vector3.left, Vector3.forward, Vector3.up);
        }

        private void CreateFacePips(Transform parent, int value, Vector3 normal, Vector3 right, Vector3 up)
        {
            foreach (var offset in PipPattern(value))
            {
                var pip = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                pip.name = $"Pip_{value}";
                pip.layer = 30;
                pip.transform.SetParent(parent, false);
                pip.transform.localPosition = normal * 0.89f + right * offset.x * 0.42f + up * offset.y * 0.42f;
                pip.transform.localScale = new Vector3(0.20f, 0.07f, 0.20f);
                pip.transform.localRotation = Quaternion.FromToRotation(Vector3.up, normal);
                pip.GetComponent<Renderer>().material = _gold;
                DestroyImmediateSafe(pip.GetComponent<Collider>());
            }
        }

        private static IEnumerable<Vector2> PipPattern(int value)
        {
            var tl = new Vector2(-1, 1); var tr = new Vector2(1, 1);
            var ml = new Vector2(-1, 0); var mr = new Vector2(1, 0);
            var bl = new Vector2(-1, -1); var br = new Vector2(1, -1);
            var c = Vector2.zero;
            switch (value)
            {
                case 1: return new[] { c };
                case 2: return new[] { tl, br };
                case 3: return new[] { tl, c, br };
                case 4: return new[] { tl, tr, bl, br };
                case 5: return new[] { tl, tr, c, bl, br };
                default: return new[] { tl, tr, ml, mr, bl, br };
            }
        }

        private static Quaternion RotationForResult(int result)
        {
            switch (result)
            {
                case 1: return Quaternion.identity;
                case 2: return Quaternion.Euler(90, 0, 0);
                case 3: return Quaternion.Euler(0, 0, 90);
                case 4: return Quaternion.Euler(0, 0, -90);
                case 5: return Quaternion.Euler(-90, 0, 0);
                case 6: return Quaternion.Euler(180, 0, 0);
                default: return Quaternion.identity;
            }
        }

        private static Material CreateMaterial(Color color, float metallic, float smoothness)
        {
            var shader = Shader.Find("Standard") ?? Shader.Find("Universal Render Pipeline/Lit");
            var material = new Material(shader) { color = color, hideFlags = HideFlags.HideAndDontSave };
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", smoothness);
            return material;
        }

        private static void DestroyImmediateSafe(UnityEngine.Object obj)
        {
            if (obj == null) return;
            if (Application.isPlaying) UnityEngine.Object.Destroy(obj);
            else UnityEngine.Object.DestroyImmediate(obj);
        }

        private void OnDestroy()
        {
            if (_renderTexture != null)
            {
                _renderTexture.Release();
                DestroyImmediateSafe(_renderTexture);
            }
            DestroyImmediateSafe(_worldRoot);
            DestroyImmediateSafe(_ivory);
            DestroyImmediateSafe(_gold);
            DestroyImmediateSafe(_navy);
        }
    }
}
