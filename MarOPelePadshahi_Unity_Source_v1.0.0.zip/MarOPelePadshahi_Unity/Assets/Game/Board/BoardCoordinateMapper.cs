using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Board
{
    public static class BoardCoordinateMapper
    {
        public static Vector2Int CellToGrid(int cell)
        {
            if (cell < 1 || cell > 100) return new Vector2Int(-1, -1);
            var zero = cell - 1;
            var rowFromBottom = zero / 10;
            var indexInRow = zero % 10;
            var column = rowFromBottom % 2 == 0 ? indexInRow : 9 - indexInRow;
            return new Vector2Int(column, rowFromBottom);
        }

        public static int GridToCell(int column, int rowFromBottom)
        {
            if (column < 0 || column > 9 || rowFromBottom < 0 || rowFromBottom > 9) return -1;
            var indexInRow = rowFromBottom % 2 == 0 ? column : 9 - column;
            return rowFromBottom * 10 + indexInRow + 1;
        }

        public static Vector2 CellCenter(int cell, Rect boardRect)
        {
            var grid = CellToGrid(cell);
            if (grid.x < 0) return boardRect.min;
            var cellWidth = boardRect.width / 10f;
            var cellHeight = boardRect.height / 10f;
            return new Vector2(
                boardRect.xMin + (grid.x + 0.5f) * cellWidth,
                boardRect.yMin + (grid.y + 0.5f) * cellHeight);
        }
    }
}
