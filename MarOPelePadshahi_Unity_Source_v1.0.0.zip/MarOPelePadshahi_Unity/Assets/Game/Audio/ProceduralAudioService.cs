using Menchino.RoyalSnakesLadders.Services;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Audio
{
    public sealed class ProceduralAudioService : IAudioService
    {
        private readonly AudioSource _sfxSource;
        private float _sfxVolume = 0.85f;

        private readonly AudioClip _click;
        private readonly AudioClip _dice;
        private readonly AudioClip _move;
        private readonly AudioClip _ladder;
        private readonly AudioClip _snake;
        private readonly AudioClip _win;
        private readonly AudioClip _error;

        public ProceduralAudioService(GameObject host)
        {
            _sfxSource = host.AddComponent<AudioSource>();
            _sfxSource.playOnAwake = false;
            _click = CreateTone("click", 620f, 0.07f, 0.23f);
            _dice = CreateNoise("dice", 0.28f, 0.30f);
            _move = CreateTone("move", 420f, 0.08f, 0.18f);
            _ladder = CreateSweep("ladder", 420f, 960f, 0.42f, 0.22f);
            _snake = CreateSweep("snake", 520f, 170f, 0.45f, 0.24f);
            _win = CreateSweep("win", 520f, 1180f, 0.75f, 0.26f);
            _error = CreateTone("error", 160f, 0.18f, 0.28f);
        }

        public void PlayClick() => Play(_click);
        public void PlayDice() => Play(_dice);
        public void PlayMove() => Play(_move);
        public void PlayLadder() => Play(_ladder);
        public void PlaySnake() => Play(_snake);
        public void PlayWin() => Play(_win);
        public void PlayError() => Play(_error);

        public void SetVolumes(float music, float sfx)
        {
            _sfxVolume = Mathf.Clamp01(sfx);
            _sfxSource.volume = _sfxVolume;
        }

        private void Play(AudioClip clip)
        {
            if (clip != null && _sfxVolume > 0.001f) _sfxSource.PlayOneShot(clip, _sfxVolume);
        }

        private static AudioClip CreateTone(string name, float frequency, float duration, float amplitude)
        {
            const int sampleRate = 44100;
            var length = Mathf.Max(1, Mathf.CeilToInt(sampleRate * duration));
            var samples = new float[length];
            for (var i = 0; i < length; i++)
            {
                var t = i / (float)sampleRate;
                var envelope = 1f - i / (float)length;
                samples[i] = Mathf.Sin(2f * Mathf.PI * frequency * t) * amplitude * envelope;
            }
            var clip = AudioClip.Create(name, length, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip CreateSweep(string name, float start, float end, float duration, float amplitude)
        {
            const int sampleRate = 44100;
            var length = Mathf.Max(1, Mathf.CeilToInt(sampleRate * duration));
            var samples = new float[length];
            var phase = 0f;
            for (var i = 0; i < length; i++)
            {
                var p = i / (float)length;
                var frequency = Mathf.Lerp(start, end, p);
                phase += 2f * Mathf.PI * frequency / sampleRate;
                samples[i] = Mathf.Sin(phase) * amplitude * (1f - p);
            }
            var clip = AudioClip.Create(name, length, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }

        private static AudioClip CreateNoise(string name, float duration, float amplitude)
        {
            const int sampleRate = 44100;
            var length = Mathf.Max(1, Mathf.CeilToInt(sampleRate * duration));
            var samples = new float[length];
            var state = 1234567u;
            for (var i = 0; i < length; i++)
            {
                state = 1664525u * state + 1013904223u;
                var value = ((state >> 8) & 0xFFFF) / 32767.5f - 1f;
                samples[i] = value * amplitude * (1f - i / (float)length);
            }
            var clip = AudioClip.Create(name, length, 1, sampleRate, false);
            clip.SetData(samples, 0);
            return clip;
        }
    }
}
