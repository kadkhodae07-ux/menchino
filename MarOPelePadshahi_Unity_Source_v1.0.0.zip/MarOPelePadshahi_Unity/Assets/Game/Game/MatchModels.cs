using System;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Data;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Game
{
    public enum PlayerControlType { LocalHuman, Bot, Remote }
    public enum MatchPhase { Waiting, AwaitingRoll, Rolling, Moving, ResolvingTransition, Finished, Paused }

    [Serializable]
    public sealed class MatchPlayer
    {
        public string id;
        public string displayName;
        public PlayerControlType controlType;
        public int position;
        public int colorIndex;
        public bool connected = true;
        public bool finished;
        public int finishRank;
        public int consecutiveSixes;
        public float turnTimeRemaining;

        public MatchPlayer Clone() => (MatchPlayer)MemberwiseClone();
    }

    [Serializable]
    public sealed class MatchConfig
    {
        public string matchId = Guid.NewGuid().ToString("N");
        public BoardDefinition board = BoardDefinition.CreateRoyalStandard();
        public RuleSet rules = new RuleSet();
        public List<MatchPlayer> players = new List<MatchPlayer>();
        public int targetRanks = 1;
    }

    [Serializable]
    public sealed class MatchSnapshot
    {
        public string matchId;
        public MatchPhase phase;
        public int activePlayerIndex;
        public int lastRoll;
        public int turnNumber;
        public List<MatchPlayer> players = new List<MatchPlayer>();
        public List<int> pendingPath = new List<int>();
        public int transitionFrom;
        public int transitionTo;
        public bool transitionIsLadder;
        public string statusText;

        public MatchPlayer ActivePlayer => players != null && activePlayerIndex >= 0 && activePlayerIndex < players.Count ? players[activePlayerIndex] : null;
    }

    public readonly struct RollResolution
    {
        public RollResolution(int roll, List<int> path, int transitionFrom, int transitionTo, bool isLadder, bool extraTurn, bool turnBurned, bool finished)
        {
            Roll = roll;
            Path = path;
            TransitionFrom = transitionFrom;
            TransitionTo = transitionTo;
            IsLadder = isLadder;
            ExtraTurn = extraTurn;
            TurnBurned = turnBurned;
            Finished = finished;
        }

        public int Roll { get; }
        public List<int> Path { get; }
        public int TransitionFrom { get; }
        public int TransitionTo { get; }
        public bool IsLadder { get; }
        public bool ExtraTurn { get; }
        public bool TurnBurned { get; }
        public bool Finished { get; }
    }

    public interface IDiceService
    {
        int NextRoll();
    }

    public sealed class SecureDiceService : IDiceService
    {
        public int NextRoll()
        {
            var bytes = new byte[4];
            using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create())
                rng.GetBytes(bytes);
            var value = BitConverter.ToUInt32(bytes, 0);
            return (int)(value % 6u) + 1;
        }
    }

    public sealed class FixedDiceService : IDiceService
    {
        private readonly Queue<int> _values;
        public FixedDiceService(IEnumerable<int> values) => _values = new Queue<int>(values);
        public int NextRoll() => _values.Count > 0 ? Mathf.Clamp(_values.Dequeue(), 1, 6) : 1;
    }
}
