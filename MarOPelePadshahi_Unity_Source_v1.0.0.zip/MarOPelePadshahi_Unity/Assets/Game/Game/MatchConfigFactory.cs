using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Data;

namespace Menchino.RoyalSnakesLadders.Game
{
    public static class MatchConfigFactory
    {
        public static MatchConfig CreateBotMatch(int playerCount, RuleSet rules)
        {
            var names = new[] { "شاهین", "رادین", "یلدا", "آرمان" };
            var players = new List<MatchPlayer>();
            for (var i = 0; i < playerCount; i++)
            {
                players.Add(new MatchPlayer
                {
                    id = i == 0 ? "local" : $"bot_{i}",
                    displayName = names[i],
                    controlType = i == 0 ? PlayerControlType.LocalHuman : PlayerControlType.Bot,
                    colorIndex = i,
                    position = 0
                });
            }
            return new MatchConfig { board = BoardDefinition.CreateRoyalStandard(), rules = rules.Clone(), players = players, targetRanks = 1 };
        }

        public static MatchConfig CreateLocalMatch(IReadOnlyList<string> names, RuleSet rules)
        {
            var players = new List<MatchPlayer>();
            for (var i = 0; i < names.Count; i++)
            {
                players.Add(new MatchPlayer
                {
                    id = $"local_{i}",
                    displayName = string.IsNullOrWhiteSpace(names[i]) ? $"بازیکن {i + 1}" : names[i].Trim(),
                    controlType = PlayerControlType.LocalHuman,
                    colorIndex = i,
                    position = 0
                });
            }
            return new MatchConfig { board = BoardDefinition.CreateRoyalStandard(), rules = rules.Clone(), players = players, targetRanks = 1 };
        }

        public static MatchConfig CreateOnlinePreview()
        {
            return new MatchConfig
            {
                board = BoardDefinition.CreateRoyalStandard(),
                rules = new RuleSet(),
                targetRanks = 1,
                players = new List<MatchPlayer>
                {
                    new MatchPlayer { id = "local", displayName = "شاهین", controlType = PlayerControlType.LocalHuman, colorIndex = 0 },
                    new MatchPlayer { id = "remote_1", displayName = "یلدا", controlType = PlayerControlType.Bot, colorIndex = 1 }
                }
            };
        }
    }
}
