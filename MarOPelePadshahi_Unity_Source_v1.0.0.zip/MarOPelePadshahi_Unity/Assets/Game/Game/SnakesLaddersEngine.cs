using System;
using System.Collections.Generic;
using System.Linq;
using Menchino.RoyalSnakesLadders.Data;

namespace Menchino.RoyalSnakesLadders.Game
{
    public sealed class SnakesLaddersEngine
    {
        private readonly MatchConfig _config;
        private readonly IDiceService _dice;
        private readonly MatchSnapshot _state = new MatchSnapshot();
        private int _finishedCount;

        public SnakesLaddersEngine(MatchConfig config, IDiceService dice)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _dice = dice ?? throw new ArgumentNullException(nameof(dice));
            ValidateConfig(_config);
            _state.matchId = string.IsNullOrWhiteSpace(_config.matchId) ? Guid.NewGuid().ToString("N") : _config.matchId;
            _state.players = _config.players.Select(x => x.Clone()).ToList();
            _state.activePlayerIndex = 0;
            _state.phase = MatchPhase.Waiting;
            _state.statusText = "آماده شروع";
            foreach (var player in _state.players)
                player.turnTimeRemaining = _config.rules.turnSeconds;
        }

        public MatchSnapshot Snapshot => CloneSnapshot(_state);
        public bool CanRoll => _state.phase == MatchPhase.AwaitingRoll && !_state.ActivePlayer.finished;

        public void Start()
        {
            if (_state.phase != MatchPhase.Waiting) return;
            _state.phase = MatchPhase.AwaitingRoll;
            _state.turnNumber = 1;
            ResetTurnTimer();
            _state.statusText = $"نوبت {_state.ActivePlayer.displayName}";
        }

        public RollResolution Roll()
        {
            if (!CanRoll) throw new InvalidOperationException("Roll is not allowed in current match phase.");
            var value = _dice.NextRoll();
            return ResolveRoll(value);
        }

        public RollResolution ResolveRoll(int roll)
        {
            if (!CanRoll) throw new InvalidOperationException("Roll is not allowed in current match phase.");
            if (roll < 1 || roll > 6) throw new ArgumentOutOfRangeException(nameof(roll));

            var player = _state.ActivePlayer;
            _state.lastRoll = roll;
            _state.phase = MatchPhase.Rolling;
            _state.pendingPath.Clear();
            _state.transitionFrom = 0;
            _state.transitionTo = 0;
            _state.transitionIsLadder = false;

            if (roll == 6) player.consecutiveSixes++;
            else player.consecutiveSixes = 0;

            var thirdSixBurns = _config.rules.burnTurnOnThirdSix && player.consecutiveSixes >= 3;
            if (thirdSixBurns)
            {
                player.consecutiveSixes = 0;
                _state.phase = MatchPhase.AwaitingRoll;
                AdvanceTurn();
                return new RollResolution(roll, new List<int>(), 0, 0, false, false, true, false);
            }

            var path = BuildPath(player.position, roll);
            _state.pendingPath.AddRange(path);
            _state.phase = path.Count > 0 ? MatchPhase.Moving : MatchPhase.ResolvingTransition;
            if (path.Count > 0) player.position = path[path.Count - 1];

            var transitionFrom = 0;
            var transitionTo = 0;
            var isLadder = false;
            if (path.Count > 0 && _config.board.TryGetTransition(player.position, out var transition))
            {
                transitionFrom = transition.from;
                transitionTo = transition.to;
                isLadder = transition.IsLadder;
                player.position = transition.to;
                _state.transitionFrom = transitionFrom;
                _state.transitionTo = transitionTo;
                _state.transitionIsLadder = isLadder;
                _state.phase = MatchPhase.ResolvingTransition;
            }

            if (_config.rules.captureEnabled)
                ResolveCapture(player);

            var finished = player.position == _config.board.cellCount;
            if (finished && !player.finished)
            {
                player.finished = true;
                player.finishRank = ++_finishedCount;
                player.consecutiveSixes = 0;
            }

            var shouldFinish = _finishedCount >= Math.Max(1, Math.Min(_config.targetRanks, _state.players.Count - 1));
            var extraTurn = !finished && _config.rules.extraTurnOnSix && roll == 6;
            if (shouldFinish)
            {
                AssignRemainingRanks();
                _state.phase = MatchPhase.Finished;
                _state.statusText = "بازی پایان یافت";
            }
            else if (extraTurn)
            {
                _state.phase = MatchPhase.AwaitingRoll;
                ResetTurnTimer();
                _state.statusText = $"دوباره نوبت {player.displayName}";
            }
            else
            {
                _state.phase = MatchPhase.AwaitingRoll;
                AdvanceTurn();
            }

            return new RollResolution(roll, path, transitionFrom, transitionTo, isLadder, extraTurn, false, finished);
        }

        public bool TickTurnTimer(float deltaSeconds)
        {
            if (!_config.rules.turnTimerEnabled || _state.phase != MatchPhase.AwaitingRoll) return false;
            var player = _state.ActivePlayer;
            player.turnTimeRemaining = Math.Max(0, player.turnTimeRemaining - deltaSeconds);
            if (player.turnTimeRemaining > 0) return false;
            return true;
        }

        public void SkipTimedOutTurn()
        {
            if (_state.phase != MatchPhase.AwaitingRoll) return;
            _state.ActivePlayer.consecutiveSixes = 0;
            AdvanceTurn();
        }

        public void Pause()
        {
            if (_state.phase != MatchPhase.Finished) _state.phase = MatchPhase.Paused;
        }

        public void Resume()
        {
            if (_state.phase == MatchPhase.Paused)
            {
                _state.phase = MatchPhase.AwaitingRoll;
                ResetTurnTimer();
            }
        }

        private List<int> BuildPath(int current, int roll)
        {
            var max = _config.board.cellCount;
            if (_config.rules.requireSixToEnter && current == 0 && roll != 6) return new List<int>();
            if (_config.rules.requireSixToEnter && current == 0 && roll == 6) return new List<int> { 1 };

            var rawTarget = current + roll;
            if (_config.rules.exactRollToFinish && !_config.rules.bounceBackAfterHundred && rawTarget > max)
                return new List<int>();

            var path = new List<int>();
            var direction = 1;
            var position = current;
            for (var step = 0; step < roll; step++)
            {
                position += direction;
                if (position > max)
                {
                    if (_config.rules.bounceBackAfterHundred)
                    {
                        position = max - 1;
                        direction = -1;
                    }
                    else return new List<int>();
                }
                if (position < 0) position = 0;
                path.Add(position);
            }
            return path;
        }

        private void ResolveCapture(MatchPlayer mover)
        {
            if (mover.position <= 0 || mover.position >= _config.board.cellCount) return;
            if (_config.rules.safeCellsEnabled && _config.board.safeCells.Contains(mover.position)) return;
            foreach (var opponent in _state.players)
            {
                if (ReferenceEquals(opponent, mover) || opponent.finished) continue;
                if (opponent.position == mover.position)
                {
                    opponent.position = 0;
                    opponent.consecutiveSixes = 0;
                }
            }
        }

        private void AdvanceTurn()
        {
            if (_state.phase == MatchPhase.Finished) return;
            var attempts = 0;
            do
            {
                _state.activePlayerIndex = (_state.activePlayerIndex + 1) % _state.players.Count;
                attempts++;
            } while (_state.ActivePlayer.finished && attempts <= _state.players.Count);
            _state.turnNumber++;
            ResetTurnTimer();
            _state.statusText = $"نوبت {_state.ActivePlayer.displayName}";
        }

        private void ResetTurnTimer() => _state.ActivePlayer.turnTimeRemaining = _config.rules.turnSeconds;

        private void AssignRemainingRanks()
        {
            var remaining = _state.players.Where(p => !p.finished).OrderByDescending(p => p.position).ToList();
            foreach (var player in remaining)
            {
                player.finished = true;
                player.finishRank = ++_finishedCount;
            }
        }

        private static void ValidateConfig(MatchConfig config)
        {
            if (config.board == null) throw new ArgumentException("Board definition is required.");
            if (config.rules == null) throw new ArgumentException("Rule set is required.");
            if (config.players == null || config.players.Count < 2 || config.players.Count > 4)
                throw new ArgumentException("Match must contain 2 to 4 players.");
            if (config.players.Select(x => x.id).Distinct().Count() != config.players.Count)
                throw new ArgumentException("Player identifiers must be unique.");
            if (config.players.Select(x => x.colorIndex).Distinct().Count() != config.players.Count)
                throw new ArgumentException("Player colors must be unique.");
            foreach (var transition in config.board.transitions)
            {
                if (transition.from < 1 || transition.from > config.board.cellCount || transition.to < 1 || transition.to > config.board.cellCount || transition.from == transition.to)
                    throw new ArgumentException("Board transition is invalid.");
            }
        }

        private static MatchSnapshot CloneSnapshot(MatchSnapshot source)
        {
            return new MatchSnapshot
            {
                matchId = source.matchId,
                phase = source.phase,
                activePlayerIndex = source.activePlayerIndex,
                lastRoll = source.lastRoll,
                turnNumber = source.turnNumber,
                players = source.players.Select(x => x.Clone()).ToList(),
                pendingPath = new List<int>(source.pendingPath),
                transitionFrom = source.transitionFrom,
                transitionTo = source.transitionTo,
                transitionIsLadder = source.transitionIsLadder,
                statusText = source.statusText
            };
        }
    }
}
