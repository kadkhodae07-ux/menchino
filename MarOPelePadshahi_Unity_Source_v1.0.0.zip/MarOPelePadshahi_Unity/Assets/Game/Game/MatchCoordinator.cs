using System;
using System.Collections;
using Menchino.RoyalSnakesLadders.Board;
using Menchino.RoyalSnakesLadders.Bots;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Game
{
    public sealed class MatchCoordinator : MonoBehaviour
    {
        private SnakesLaddersEngine _engine;
        private BoardView _board;
        private RoyalDie3D _die;
        private RoyalGameApp _app;
        private IAudioService _audio;
        private Action<MatchSnapshot> _onChanged;
        private bool _animating;
        private Coroutine _botRoutine;
        private BotDifficulty _difficulty = BotDifficulty.Medium;
        private bool _autoRollOnTimeout;
        private float _timerUiAccumulator;

        public MatchSnapshot Snapshot => _engine?.Snapshot;
        public bool IsAnimating => _animating;

        public void Initialize(RoyalGameApp app, MatchConfig config, BoardView board, RoyalDie3D die, Action<MatchSnapshot> onChanged, BotDifficulty difficulty = BotDifficulty.Medium)
        {
            if (app == null) throw new ArgumentNullException(nameof(app));
            if (config == null) throw new ArgumentNullException(nameof(config));
            if (board == null) throw new ArgumentNullException(nameof(board));
            if (die == null) throw new ArgumentNullException(nameof(die));
            _app = app;
            _audio = app.Services.Resolve<IAudioService>();
            _board = board;
            _die = die;
            _onChanged = onChanged;
            _difficulty = difficulty;
            _autoRollOnTimeout = config?.rules != null && config.rules.autoRollOnTimeout;
            _engine = new SnakesLaddersEngine(config, new SecureDiceService());
            for (var i = 0; i < config.players.Count; i++) _board.CreatePawn(i, config.players[i].position);
            _engine.Start();
            Notify();
            ScheduleBotIfNeeded();
        }

        public void RequestRoll()
        {
            if (_engine == null || _animating || !_engine.CanRoll) return;
            var before = _engine.Snapshot;
            if (before.ActivePlayer.controlType == PlayerControlType.Remote) return;
            var moverIndex = before.activePlayerIndex;
            var resolution = _engine.Roll();
            if (_app.Services.TryResolve<ICatalogService>(out var catalog))
                catalog.RecordRollResult(resolution.Roll, resolution.IsLadder);
            _animating = true;
            _die.SetState(DieVisualState.Rolling);
            _die.RollTo(resolution.Roll, () => StartCoroutine(ApplyResolution(moverIndex, resolution)));
            Notify();
        }

        public void Pause()
        {
            _engine?.Pause();
            _die?.SetState(DieVisualState.Locked);
            Notify();
        }

        public void Resume()
        {
            _engine?.Resume();
            Notify();
            ScheduleBotIfNeeded();
        }

        private IEnumerator ApplyResolution(int moverIndex, RollResolution resolution)
        {
            if (resolution.Path.Count > 0)
            {
                foreach (var _ in resolution.Path) _audio?.PlayMove();
                yield return _board.AnimatePath(moverIndex, resolution.Path);
            }
            if (resolution.TransitionFrom > 0)
            {
                if (resolution.IsLadder) _audio?.PlayLadder(); else _audio?.PlaySnake();
                yield return _board.AnimateTransition(moverIndex, resolution.TransitionFrom, resolution.TransitionTo, resolution.IsLadder);
            }

            var snapshot = _engine.Snapshot;
            for (var i = 0; i < snapshot.players.Count; i++)
                _board.SetPawnCell(i, snapshot.players[i].position);
            _animating = false;
            if (snapshot.phase == MatchPhase.Finished)
            {
                _die.SetState(DieVisualState.Locked);
                _audio?.PlayWin();
            }
            else
            {
                _die.SetState(snapshot.ActivePlayer.controlType == PlayerControlType.LocalHuman ? DieVisualState.Ready : DieVisualState.WaitingTurn);
            }
            Notify();
            ScheduleBotIfNeeded();
        }

        private void Update()
        {
            if (_engine == null || _animating) return;
            var timedOut = _engine.TickTurnTimer(Time.unscaledDeltaTime);
            _timerUiAccumulator += Time.unscaledDeltaTime;
            if (_timerUiAccumulator >= 0.25f)
            {
                _timerUiAccumulator = 0f;
                Notify();
            }
            if (!timedOut) return;

            var current = _engine.Snapshot.ActivePlayer;
            if (current == null) return;
            if (_autoRollOnTimeout || current.controlType != PlayerControlType.LocalHuman)
                RequestRoll();
            else
            {
                _engine.SkipTimedOutTurn();
                Notify();
                ScheduleBotIfNeeded();
            }
        }

        private void ScheduleBotIfNeeded()
        {
            if (_engine == null || _animating || _engine.Snapshot.phase != MatchPhase.AwaitingRoll) return;
            if (_engine.Snapshot.ActivePlayer.controlType != PlayerControlType.Bot) return;
            if (_botRoutine != null) StopCoroutine(_botRoutine);
            _botRoutine = StartCoroutine(BotRollAfterDelay());
        }

        private IEnumerator BotRollAfterDelay()
        {
            yield return new WaitForSecondsRealtime(BotTiming.GetDelay(_difficulty));
            _botRoutine = null;
            RequestRoll();
        }

        private void Notify()
        {
            var snapshot = _engine?.Snapshot;
            if (snapshot == null) return;
            _onChanged?.Invoke(snapshot);
            _app.Events.Publish(new MatchStateChangedEvent(snapshot));
        }

        private void OnDestroy()
        {
            if (_botRoutine != null) StopCoroutine(_botRoutine);
        }
    }
}
