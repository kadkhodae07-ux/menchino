using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Menchino.RoyalSnakesLadders.Data;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Services
{
    public sealed class EncryptedSaveService : ISaveService
    {
        private const string FileName = "royal_save.dat";
        private const int CurrentSchema = 2;
        private readonly string _path;
        private readonly string _backupPath;
        public SaveEnvelope Current { get; private set; } = new SaveEnvelope();

        public EncryptedSaveService()
        {
            _path = Path.Combine(Application.persistentDataPath, FileName);
            _backupPath = _path + ".bak";
        }

        public void Load()
        {
            if (!File.Exists(_path))
            {
                Current = new SaveEnvelope();
                Save();
                return;
            }

            try
            {
                var encrypted = File.ReadAllBytes(_path);
                var json = Decrypt(encrypted);
                var loaded = JsonUtility.FromJson<SaveEnvelope>(json);
                if (loaded == null) throw new InvalidDataException("Save payload is empty.");
                Current = Migrate(loaded);
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Save load failed. Safe defaults restored. {exception.GetType().Name}");
                TryBackupCorruptFile();
                ResetToSafeDefaults();
            }
        }

        public void Save()
        {
            Current.schemaVersion = CurrentSchema;
            var json = JsonUtility.ToJson(Current);
            var bytes = Encrypt(json);
            Directory.CreateDirectory(Path.GetDirectoryName(_path) ?? Application.persistentDataPath);
            var temp = _path + ".tmp";
            File.WriteAllBytes(temp, bytes);
            if (File.Exists(_path)) File.Copy(_path, _backupPath, true);
            if (File.Exists(_path)) File.Delete(_path);
            File.Move(temp, _path);
        }

        public void ResetToSafeDefaults()
        {
            Current = new SaveEnvelope();
            Save();
        }

        private SaveEnvelope Migrate(SaveEnvelope input)
        {
            if (input.schemaVersion <= 0) input.schemaVersion = 1;
            if (input.profile == null) input.profile = new PlayerProfile();
            if (input.wallet == null) input.wallet = new CurrencyWallet();
            if (input.settings == null) input.settings = new GameSettingsData();
            if (input.ownedProductIds == null) input.ownedProductIds = new System.Collections.Generic.List<string>();
            if (input.claimedMissionIds == null) input.claimedMissionIds = new System.Collections.Generic.List<string>();
            if (input.rewardedMatchIds == null) input.rewardedMatchIds = new System.Collections.Generic.List<string>();
            if (input.missionProgress == null) input.missionProgress = new System.Collections.Generic.List<MissionProgressRecord>();
            input.schemaVersion = CurrentSchema;
            return input;
        }

        private void TryBackupCorruptFile()
        {
            try
            {
                if (File.Exists(_path))
                    File.Copy(_path, _path + ".corrupt_" + DateTimeOffset.UtcNow.ToUnixTimeSeconds(), true);
            }
            catch
            {
                // Backup is best effort; recovery must continue.
            }
        }

        private static readonly byte[] PayloadMagic = { (byte)'R', (byte)'S', (byte)'L', 1 };

        private static byte[] Encrypt(string plainText)
        {
            byte[] iv;
            byte[] cipherText;
            using (var aes = Aes.Create())
            {
                aes.Key = DeriveKey("encryption");
                aes.GenerateIV();
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                iv = aes.IV;
                using (var encryptor = aes.CreateEncryptor())
                using (var output = new MemoryStream())
                {
                    using (var crypto = new CryptoStream(output, encryptor, CryptoStreamMode.Write))
                    using (var writer = new StreamWriter(crypto, Encoding.UTF8))
                        writer.Write(plainText);
                    cipherText = output.ToArray();
                }
            }

            var authenticated = new byte[PayloadMagic.Length + iv.Length + cipherText.Length];
            Buffer.BlockCopy(PayloadMagic, 0, authenticated, 0, PayloadMagic.Length);
            Buffer.BlockCopy(iv, 0, authenticated, PayloadMagic.Length, iv.Length);
            Buffer.BlockCopy(cipherText, 0, authenticated, PayloadMagic.Length + iv.Length, cipherText.Length);
            byte[] signature;
            using (var hmac = new HMACSHA256(DeriveKey("authentication")))
                signature = hmac.ComputeHash(authenticated);
            var result = new byte[authenticated.Length + signature.Length];
            Buffer.BlockCopy(authenticated, 0, result, 0, authenticated.Length);
            Buffer.BlockCopy(signature, 0, result, authenticated.Length, signature.Length);
            return result;
        }

        private static string Decrypt(byte[] payload)
        {
            if (payload == null || payload.Length == 0) throw new InvalidDataException("Encrypted payload is empty.");
            if (HasMagic(payload)) return DecryptAuthenticated(payload);
            return DecryptLegacy(payload);
        }

        private static string DecryptAuthenticated(byte[] payload)
        {
            const int ivSize = 16;
            const int signatureSize = 32;
            var headerSize = PayloadMagic.Length + ivSize;
            if (payload.Length <= headerSize + signatureSize) throw new InvalidDataException("Encrypted payload is invalid.");
            var authenticatedLength = payload.Length - signatureSize;
            var expected = new byte[signatureSize];
            using (var hmac = new HMACSHA256(DeriveKey("authentication")))
                expected = hmac.ComputeHash(payload, 0, authenticatedLength);
            var actual = new byte[signatureSize];
            Buffer.BlockCopy(payload, authenticatedLength, actual, 0, signatureSize);
            if (!FixedTimeEquals(expected, actual)) throw new CryptographicException("Save integrity verification failed.");

            var iv = new byte[ivSize];
            Buffer.BlockCopy(payload, PayloadMagic.Length, iv, 0, ivSize);
            var cipherLength = authenticatedLength - headerSize;
            var cipher = new byte[cipherLength];
            Buffer.BlockCopy(payload, headerSize, cipher, 0, cipherLength);
            return DecryptCbc(cipher, iv, DeriveKey("encryption"));
        }

        private static string DecryptLegacy(byte[] payload)
        {
            const int ivSize = 16;
            if (payload.Length <= ivSize) throw new InvalidDataException("Encrypted payload is invalid.");
            var iv = new byte[ivSize];
            Buffer.BlockCopy(payload, 0, iv, 0, ivSize);
            var cipher = new byte[payload.Length - ivSize];
            Buffer.BlockCopy(payload, ivSize, cipher, 0, cipher.Length);
            return DecryptCbc(cipher, iv, DeriveLegacyKey());
        }

        private static string DecryptCbc(byte[] cipher, byte[] iv, byte[] key)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using (var decryptor = aes.CreateDecryptor())
                using (var input = new MemoryStream(cipher))
                using (var crypto = new CryptoStream(input, decryptor, CryptoStreamMode.Read))
                using (var reader = new StreamReader(crypto, Encoding.UTF8))
                    return reader.ReadToEnd();
            }
        }

        private static bool HasMagic(byte[] payload)
        {
            if (payload.Length < PayloadMagic.Length) return false;
            for (var i = 0; i < PayloadMagic.Length; i++)
                if (payload[i] != PayloadMagic[i]) return false;
            return true;
        }

        private static bool FixedTimeEquals(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;
            var difference = 0;
            for (var i = 0; i < left.Length; i++) difference |= left[i] ^ right[i];
            return difference == 0;
        }

        private static byte[] DeriveKey(string purpose)
        {
            var seed = $"Menchino.RoyalSnakesLadders|{SystemInfo.deviceUniqueIdentifier}|v2|{purpose}";
            using (var sha = SHA256.Create()) return sha.ComputeHash(Encoding.UTF8.GetBytes(seed));
        }

        private static byte[] DeriveLegacyKey()
        {
            var seed = $"Menchino.RoyalSnakesLadders|{SystemInfo.deviceUniqueIdentifier}|v1";
            using (var sha = SHA256.Create()) return sha.ComputeHash(Encoding.UTF8.GetBytes(seed));
        }
    }
}
