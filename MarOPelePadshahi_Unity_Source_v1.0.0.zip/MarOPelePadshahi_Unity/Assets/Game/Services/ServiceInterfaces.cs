using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;

namespace Menchino.RoyalSnakesLadders.Services
{
    public interface ISaveService
    {
        SaveEnvelope Current { get; }
        void Load();
        void Save();
        void ResetToSafeDefaults();
    }

    public interface IProfileService
    {
        PlayerProfile Profile { get; }
        CurrencyWallet Wallet { get; }
        void UpdateName(string newName);
        bool Spend(CurrencyType currency, int amount);
        void Add(CurrencyType currency, int amount);
        void RecordCompletedMatch(bool won, int xpReward, int trophyReward);
        bool TryApplyMatchRewards(string matchId, bool won, int coinReward, int xpReward, int trophyReward);
    }

    public interface ICatalogService
    {
        IReadOnlyList<ShopProduct> Products { get; }
        IReadOnlyList<MissionData> Missions { get; }
        IReadOnlyList<LeagueEntry> LeagueEntries { get; }
        IReadOnlyList<FriendData> Friends { get; }
        ShopProduct FindProduct(string id);
        bool Buy(string id);
        bool Select(string id);
        bool ClaimMission(string id);
        void RecordRollResult(int roll, bool climbedLadder);
        void RecordMatchCompleted(bool online, bool won);
    }

    public interface ILocalizationService
    {
        string CurrentLanguage { get; }
        void SetLanguage(string code);
        string T(string key);
    }

    public interface IAudioService
    {
        void PlayClick();
        void PlayDice();
        void PlayMove();
        void PlayLadder();
        void PlaySnake();
        void PlayWin();
        void PlayError();
        void SetVolumes(float music, float sfx);
    }

    public interface INetworkService
    {
        bool IsOnline { get; }
        void SetOnline(bool online);
        FriendlyRoomSnapshot CreateRoom(int playerCount, RuleSet rules);
        FriendlyRoomSnapshot JoinRoom(string code);
        MatchmakingStatus StartMatchmaking();
        void CancelMatchmaking();
    }

    public sealed class FriendlyRoomSnapshot
    {
        public string code;
        public bool isHost;
        public int maxPlayers;
        public List<string> playerNames = new List<string>();
        public bool canStart;
        public string status;
    }

    public sealed class MatchmakingStatus
    {
        public string state;
        public int secondsWaiting;
        public string opponentName;
    }
}
