using Menchino.RoyalSnakesLadders.Bots;
using Menchino.RoyalSnakesLadders.Game;

namespace Menchino.RoyalSnakesLadders.Services
{
    public interface IMatchSessionService
    {
        MatchConfig CurrentConfig { get; set; }
        MatchSnapshot LastSnapshot { get; set; }
        string ModeName { get; set; }
        BotDifficulty BotDifficulty { get; set; }
    }

    public sealed class MatchSessionService : IMatchSessionService
    {
        public MatchConfig CurrentConfig { get; set; }
        public MatchSnapshot LastSnapshot { get; set; }
        public string ModeName { get; set; } = "بازی محلی";
        public BotDifficulty BotDifficulty { get; set; } = BotDifficulty.Medium;
    }
}
