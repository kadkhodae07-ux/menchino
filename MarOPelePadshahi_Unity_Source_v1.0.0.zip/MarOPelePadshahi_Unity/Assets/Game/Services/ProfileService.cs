using System;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Services
{
    public sealed class ProfileService : IProfileService
    {
        private readonly ISaveService _save;
        private readonly RoyalEventBus _events;

        public ProfileService(ISaveService save, RoyalEventBus events)
        {
            _save = save;
            _events = events;
        }

        public PlayerProfile Profile => _save.Current.profile;
        public CurrencyWallet Wallet => _save.Current.wallet;

        public void UpdateName(string newName)
        {
            var value = (newName ?? string.Empty).Trim();
            if (value.Length < 2 || value.Length > 18) throw new ArgumentException("نام باید بین ۲ تا ۱۸ نویسه باشد.");
            Profile.displayName = value;
            _save.Save();
            _events.Publish(new ProfileChangedEvent(Profile));
        }

        public bool Spend(CurrencyType currency, int amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount));
            var success = false;
            switch (currency)
            {
                case CurrencyType.Coin:
                    if (Wallet.coins >= amount) { Wallet.coins -= amount; success = true; }
                    break;
                case CurrencyType.Gem:
                    if (Wallet.gems >= amount) { Wallet.gems -= amount; success = true; }
                    break;
                case CurrencyType.Rial:
                    return false;
            }
            if (success)
            {
                _save.Save();
                _events.Publish(new WalletChangedEvent(Wallet));
            }
            return success;
        }


        public void RecordCompletedMatch(bool won, int xpReward, int trophyReward)
        {
            Profile.gamesPlayed++;
            if (won) Profile.wins++;
            Profile.xp = Math.Max(0, Profile.xp + Math.Max(0, xpReward));
            Profile.trophies = Math.Max(0, Profile.trophies + trophyReward);
            while (Profile.xp >= Math.Max(1, Profile.xpForNextLevel))
            {
                Profile.xp -= Math.Max(1, Profile.xpForNextLevel);
                Profile.level++;
                Profile.xpForNextLevel = Mathf.RoundToInt(Profile.xpForNextLevel * 1.12f);
            }
            _save.Save();
            _events.Publish(new ProfileChangedEvent(Profile));
        }

        public bool TryApplyMatchRewards(string matchId, bool won, int coinReward, int xpReward, int trophyReward)
        {
            if (string.IsNullOrWhiteSpace(matchId)) return false;
            if (_save.Current.rewardedMatchIds.Contains(matchId)) return false;
            Wallet.coins = Math.Max(0, Wallet.coins + Math.Max(0, coinReward));
            Profile.gamesPlayed++;
            if (won) Profile.wins++;
            Profile.xp = Math.Max(0, Profile.xp + Math.Max(0, xpReward));
            Profile.trophies = Math.Max(0, Profile.trophies + trophyReward);
            while (Profile.xp >= Math.Max(1, Profile.xpForNextLevel))
            {
                Profile.xp -= Math.Max(1, Profile.xpForNextLevel);
                Profile.level++;
                Profile.xpForNextLevel = Mathf.RoundToInt(Profile.xpForNextLevel * 1.12f);
            }
            _save.Current.rewardedMatchIds.Add(matchId);
            if (_save.Current.rewardedMatchIds.Count > 100)
                _save.Current.rewardedMatchIds.RemoveRange(0, _save.Current.rewardedMatchIds.Count - 100);
            _save.Save();
            _events.Publish(new WalletChangedEvent(Wallet));
            _events.Publish(new ProfileChangedEvent(Profile));
            return true;
        }

        public void Add(CurrencyType currency, int amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount));
            if (currency == CurrencyType.Coin) Wallet.coins += amount;
            else if (currency == CurrencyType.Gem) Wallet.gems += amount;
            else return;
            _save.Save();
            _events.Publish(new WalletChangedEvent(Wallet));
        }
    }
}
