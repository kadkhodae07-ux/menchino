using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Data;

namespace Menchino.RoyalSnakesLadders.Services
{
    public sealed class LocalizationService : ILocalizationService
    {
        private readonly ISaveService _save;
        private readonly Dictionary<string, string> _fa = new Dictionary<string, string>
        {
            ["loading"] = "در حال آماده‌سازی پادشاهی...",
            ["start"] = "شروع بازی",
            ["home"] = "خانه",
            ["shop"] = "فروشگاه",
            ["profile"] = "پروفایل",
            ["back"] = "بازگشت",
            ["retry"] = "تلاش مجدد",
            ["cancel"] = "لغو"
        };

        public LocalizationService(ISaveService save) => _save = save;
        public string CurrentLanguage => _save.Current.settings.language;

        public void SetLanguage(string code)
        {
            _save.Current.settings.language = string.IsNullOrWhiteSpace(code) ? "fa" : code;
            _save.Save();
        }

        public string T(string key) => _fa.TryGetValue(key, out var value) ? value : key;
    }
}
