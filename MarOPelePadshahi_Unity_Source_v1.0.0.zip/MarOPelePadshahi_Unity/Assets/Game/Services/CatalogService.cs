using System;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Data;

namespace Menchino.RoyalSnakesLadders.Services
{
    public sealed class CatalogService : ICatalogService
    {
        private readonly RoyalCatalogAsset _catalog;
        private readonly IProfileService _profile;
        private readonly ISaveService _save;

        public CatalogService(RoyalCatalogAsset catalog, IProfileService profile, ISaveService save)
        {
            _catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
            _profile = profile;
            _save = save;
            SynchronizeOwnership();
            SynchronizeMissionClaims();
        }

        public IReadOnlyList<ShopProduct> Products => _catalog.products;
        public IReadOnlyList<MissionData> Missions => _catalog.missions;
        public IReadOnlyList<LeagueEntry> LeagueEntries => _catalog.leagueEntries;
        public IReadOnlyList<FriendData> Friends => _catalog.friends;

        public ShopProduct FindProduct(string id) => _catalog.products.Find(p => p.id == id);

        public bool Buy(string id)
        {
            var product = FindProduct(id);
            if (product == null || product.owned) return false;
            if (product.currency == CurrencyType.Rial) return false;
            if (!_profile.Spend(product.currency, product.price)) return false;
            product.owned = true;
            if (!_save.Current.ownedProductIds.Contains(product.id)) _save.Current.ownedProductIds.Add(product.id);
            if (product.category == ProductCategory.Piece || product.category == ProductCategory.Dice || product.category == ProductCategory.Avatar || product.category == ProductCategory.Frame)
                Select(product.id);
            _save.Save();
            return true;
        }

        public bool Select(string id)
        {
            var product = FindProduct(id);
            if (product == null || !product.owned) return false;
            foreach (var entry in _catalog.products)
                if (entry.category == product.category) entry.selected = false;
            product.selected = true;
            if (product.category == ProductCategory.Piece)
                _save.Current.settings.selectedPieceId = product.id;
            if (product.category == ProductCategory.Dice)
                _save.Current.settings.selectedDiceId = product.id;
            _save.Save();
            return true;
        }

        private void SynchronizeOwnership()
        {
            foreach (var product in _catalog.products)
            {
                if (product.owned && !_save.Current.ownedProductIds.Contains(product.id))
                    _save.Current.ownedProductIds.Add(product.id);
                if (_save.Current.ownedProductIds.Contains(product.id)) product.owned = true;
                if (product.category == ProductCategory.Piece)
                    product.selected = product.id == _save.Current.settings.selectedPieceId;
                else if (product.category == ProductCategory.Dice)
                    product.selected = product.id == _save.Current.settings.selectedDiceId;
            }
            _save.Save();
        }


        private void SynchronizeMissionClaims()
        {
            if (_save.Current.claimedMissionIds == null)
                _save.Current.claimedMissionIds = new List<string>();
            if (_save.Current.missionProgress == null)
                _save.Current.missionProgress = new List<MissionProgressRecord>();
            foreach (var mission in _catalog.missions)
            {
                mission.claimed = _save.Current.claimedMissionIds.Contains(mission.id);
                var saved = _save.Current.missionProgress.Find(entry => entry.id == mission.id);
                if (saved != null) mission.progress = Math.Max(mission.progress, Math.Min(mission.target, saved.progress));
            }
            PersistMissionProgress();
        }

        public void RecordRollResult(int roll, bool climbedLadder)
        {
            if (roll == 6) IncrementMission("roll_six", 1);
            if (climbedLadder) IncrementMission("climb_ladder", 1);
            PersistMissionProgress();
            _save.Save();
        }

        public void RecordMatchCompleted(bool online, bool won)
        {
            IncrementMission("play_one", 1);
            if (online && won) IncrementMission("win_online", 1);
            PersistMissionProgress();
            _save.Save();
        }

        private void IncrementMission(string id, int amount)
        {
            var mission = _catalog.missions.Find(entry => entry.id == id);
            if (mission == null || mission.claimed || amount <= 0) return;
            mission.progress = Math.Min(mission.target, mission.progress + amount);
        }

        private void PersistMissionProgress()
        {
            if (_save.Current.missionProgress == null)
                _save.Current.missionProgress = new List<MissionProgressRecord>();
            foreach (var mission in _catalog.missions)
            {
                var record = _save.Current.missionProgress.Find(entry => entry.id == mission.id);
                if (record == null)
                {
                    record = new MissionProgressRecord { id = mission.id };
                    _save.Current.missionProgress.Add(record);
                }
                record.progress = Math.Max(0, Math.Min(mission.target, mission.progress));
            }
        }

        public bool ClaimMission(string id)
        {
            var mission = _catalog.missions.Find(m => m.id == id);
            if (mission == null || mission.claimed || mission.progress < mission.target) return false;
            mission.claimed = true;
            if (!_save.Current.claimedMissionIds.Contains(mission.id)) _save.Current.claimedMissionIds.Add(mission.id);
            _profile.Add(CurrencyType.Coin, mission.rewardCoins);
            _save.Save();
            return true;
        }
    }
}
