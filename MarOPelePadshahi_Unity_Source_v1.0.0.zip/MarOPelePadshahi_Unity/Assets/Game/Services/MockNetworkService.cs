using System;
using Menchino.RoyalSnakesLadders.Data;

namespace Menchino.RoyalSnakesLadders.Services
{
    public sealed class MockNetworkService : INetworkService
    {
        private readonly Random _random = new Random();
        private bool _matchmakingActive;
        public bool IsOnline { get; private set; } = true;
        public void SetOnline(bool online)
        {
            IsOnline = online;
            if (!online) _matchmakingActive = false;
        }

        public FriendlyRoomSnapshot CreateRoom(int playerCount, RuleSet rules)
        {
            if (!IsOnline) return new FriendlyRoomSnapshot { status = "قطع اینترنت" };
            return new FriendlyRoomSnapshot
            {
                code = _random.Next(100000, 999999).ToString(),
                isHost = true,
                maxPlayers = Math.Max(2, Math.Min(4, playerCount)),
                playerNames = { "شاهین" },
                canStart = false,
                status = "در انتظار بازیکن"
            };
        }

        public FriendlyRoomSnapshot JoinRoom(string code)
        {
            if (!IsOnline) return new FriendlyRoomSnapshot { status = "قطع اینترنت" };
            if (string.IsNullOrWhiteSpace(code) || code.Trim().Length != 6)
                return new FriendlyRoomSnapshot { status = "کد اتاق نامعتبر است" };
            return new FriendlyRoomSnapshot
            {
                code = code.Trim(),
                isHost = false,
                maxPlayers = 4,
                playerNames = { "میزبان", "شاهین" },
                canStart = false,
                status = "متصل شدید"
            };
        }

        public MatchmakingStatus StartMatchmaking()
        {
            _matchmakingActive = IsOnline;
            return IsOnline
                ? new MatchmakingStatus { state = "در حال جست‌وجو", secondsWaiting = 0 }
                : new MatchmakingStatus { state = "قطع اینترنت", secondsWaiting = 0 };
        }

        public void CancelMatchmaking()
        {
            _matchmakingActive = false;
        }

        public bool IsMatchmakingActive => _matchmakingActive;
    }
}
