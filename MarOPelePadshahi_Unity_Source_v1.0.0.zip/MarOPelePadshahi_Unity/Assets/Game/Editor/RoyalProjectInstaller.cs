#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.UI;
using Menchino.RoyalSnakesLadders.UI.Screens;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace Menchino.RoyalSnakesLadders.Editor
{
    [InitializeOnLoad]
    public static class RoyalProjectInstaller
    {
        private const string GeneratedRoot = "Assets/Game/Generated";
        private const string ResourcesRoot = GeneratedRoot + "/Resources";
        private const string PrefabRoot = ResourcesRoot + "/ScreenPrefabs";
        private const string SceneRoot = GeneratedRoot + "/Scenes";
        private const string MarkerPath = GeneratedRoot + "/installation_v4.txt";

        private static readonly Dictionary<AppRoute, Type> ScreenTypes = new Dictionary<AppRoute, Type>
        {
            [AppRoute.Splash] = typeof(SplashScreen),
            [AppRoute.Language] = typeof(LanguageScreen),
            [AppRoute.Login] = typeof(LoginScreen),
            [AppRoute.Home] = typeof(HomeScreen),
            [AppRoute.ModeSelection] = typeof(ModeSelectionScreen),
            [AppRoute.BotSetup] = typeof(BotSetupScreen),
            [AppRoute.LocalTwoPlayer] = typeof(LocalTwoPlayerScreen),
            [AppRoute.FriendlyRoomCreate] = typeof(FriendlyRoomCreateScreen),
            [AppRoute.FriendlyRoomJoin] = typeof(FriendlyRoomJoinScreen),
            [AppRoute.FriendlyLobby] = typeof(FriendlyLobbyScreen),
            [AppRoute.Matchmaking] = typeof(MatchmakingScreen),
            [AppRoute.Gameplay] = typeof(GameplayScreen),
            [AppRoute.Results] = typeof(ResultsScreen),
            [AppRoute.Shop] = typeof(ShopScreen),
            [AppRoute.ProductDetails] = typeof(ProductDetailsScreen),
            [AppRoute.RewardChest] = typeof(RewardChestScreen),
            [AppRoute.League] = typeof(LeagueScreen),
            [AppRoute.Missions] = typeof(MissionsScreen),
            [AppRoute.Friends] = typeof(FriendsScreen),
            [AppRoute.Messages] = typeof(MessagesScreen),
            [AppRoute.Profile] = typeof(ProfileScreen),
            [AppRoute.ProfileEdit] = typeof(ProfileEditScreen),
            [AppRoute.Settings] = typeof(SettingsScreen),
            [AppRoute.Rules] = typeof(RulesScreen),
            [AppRoute.Support] = typeof(SupportScreen),
            [AppRoute.PiecePickerPopup] = typeof(PiecePickerPopupScreen),
            [AppRoute.PausePopup] = typeof(PausePopupScreen),
            [AppRoute.Tutorial] = typeof(TutorialScreen)
        };

        static RoyalProjectInstaller()
        {
            EditorApplication.delayCall += AutoInstall;
        }

        private static void AutoInstall()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating) return;
            if (!File.Exists(MarkerPath) || !File.Exists(ResourcesRoot + "/RoyalTheme.asset") || !File.Exists(SceneRoot + "/Bootstrap.unity"))
                InstallOrUpdate();
        }

        [MenuItem("Menchino/مار و پله پادشاهی/نصب یا بروزرسانی پروژه")]
        public static void InstallOrUpdate()
        {
            try
            {
                EnsureFolder("Assets/Game", "Generated");
                EnsureFolder(GeneratedRoot, "Resources");
                EnsureFolder(ResourcesRoot, "ScreenPrefabs");
                EnsureFolder(GeneratedRoot, "Scenes");
                CreateAppIcon();
                CreateThemeAsset();
                CreateCatalogAsset();
                CreateScreenPrefabs();
                CreateScenes();
                ConfigurePlayerSettings();
                File.WriteAllText(MarkerPath, "Royal Snakes & Ladders generated content v4\n");
                AssetDatabase.ImportAsset(MarkerPath);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                Debug.Log("مار و پله پادشاهی: نصب پروژه، Prefabها و Sceneها تکمیل شد.");
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                throw;
            }
        }

        private static void CreateAppIcon()
        {
            var path = GeneratedRoot + "/RoyalAppIcon.png";
            if (!File.Exists(path))
            {
                const int size = 512;
                var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
                var pixels = new Color32[size * size];
                var navy = new Color32(3, 22, 52, 255);
                var blue = new Color32(8, 82, 143, 255);
                var gold = new Color32(241, 177, 43, 255);
                var lightGold = new Color32(255, 226, 132, 255);
                var center = new Vector2(size * 0.5f, size * 0.5f);
                for (var y = 0; y < size; y++)
                {
                    for (var x = 0; x < size; x++)
                    {
                        var normalized = new Vector2(x, y) - center;
                        var radial = Mathf.Clamp01(normalized.magnitude / (size * 0.72f));
                        var baseColor = Color32.Lerp(blue, navy, radial);
                        var borderDistance = Mathf.Min(Mathf.Min(x, size - 1 - x), Mathf.Min(y, size - 1 - y));
                        if (borderDistance < 22) baseColor = Color32.Lerp(gold, lightGold, borderDistance / 22f);
                        pixels[y * size + x] = baseColor;
                    }
                }

                DrawBoard(pixels, size, 112, 98, 288, 288, gold, lightGold);
                DrawCrown(pixels, size, 122, 345, 268, 104, gold, lightGold);
                texture.SetPixels32(pixels);
                texture.Apply(false, false);
                File.WriteAllBytes(path, texture.EncodeToPNG());
                UnityEngine.Object.DestroyImmediate(texture);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                if (AssetImporter.GetAtPath(path) is TextureImporter importer)
                {
                    importer.textureType = TextureImporterType.Default;
                    importer.alphaIsTransparency = true;
                    importer.mipmapEnabled = false;
                    importer.maxTextureSize = 512;
                    importer.SaveAndReimport();
                }
            }

            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (icon != null) PlayerSettings.SetIconsForTargetGroup(BuildTargetGroup.Android, new[] { icon });
        }

        private static void DrawBoard(Color32[] pixels, int canvas, int x0, int y0, int width, int height, Color32 gold, Color32 lightGold)
        {
            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                {
                    var border = x < 8 || y < 8 || x >= width - 8 || y >= height - 8;
                    var cellX = Mathf.Clamp((x - 8) / 34, 0, 7);
                    var cellY = Mathf.Clamp((y - 8) / 34, 0, 7);
                    var dark = new Color32(8, 58, 105, 255);
                    var sand = new Color32(217, 178, 111, 255);
                    var value = border ? gold : ((cellX + cellY) % 2 == 0 ? dark : sand);
                    SetPixelSafe(pixels, canvas, x0 + x, y0 + y, value);
                }
            }
            for (var i = 0; i < 4; i++)
            {
                var px = x0 + 72 + i * 48;
                var py = y0 + 42;
                DrawCircle(pixels, canvas, px, py, 17, i == 0 ? new Color32(214, 63, 47, 255) : i == 1 ? new Color32(40, 126, 218, 255) : i == 2 ? gold : new Color32(58, 174, 76, 255));
                DrawRect(pixels, canvas, px - 12, py - 42, 24, 44, lightGold);
            }
        }

        private static void DrawCrown(Color32[] pixels, int canvas, int x0, int y0, int width, int height, Color32 gold, Color32 lightGold)
        {
            DrawRect(pixels, canvas, x0, y0, width, 24, gold);
            for (var x = 0; x < width; x++)
            {
                var normalized = x / (float)Mathf.Max(1, width - 1);
                var wave = Mathf.Sin(normalized * Mathf.PI * 3f);
                var top = Mathf.RoundToInt(24 + Mathf.Max(0, wave) * (height - 24));
                for (var y = 24; y < top; y++) SetPixelSafe(pixels, canvas, x0 + x, y0 + y, Color32.Lerp(gold, lightGold, y / (float)height));
            }
            DrawCircle(pixels, canvas, x0 + width / 2, y0 + height / 2, 12, new Color32(21, 146, 206, 255));
        }

        private static void DrawRect(Color32[] pixels, int canvas, int x, int y, int width, int height, Color32 color)
        {
            for (var py = 0; py < height; py++) for (var px = 0; px < width; px++) SetPixelSafe(pixels, canvas, x + px, y + py, color);
        }

        private static void DrawCircle(Color32[] pixels, int canvas, int cx, int cy, int radius, Color32 color)
        {
            var radiusSquared = radius * radius;
            for (var y = -radius; y <= radius; y++)
                for (var x = -radius; x <= radius; x++)
                    if (x * x + y * y <= radiusSquared) SetPixelSafe(pixels, canvas, cx + x, cy + y, color);
        }

        private static void SetPixelSafe(Color32[] pixels, int canvas, int x, int y, Color32 color)
        {
            if (x < 0 || y < 0 || x >= canvas || y >= canvas) return;
            pixels[y * canvas + x] = color;
        }

        private static void CreateThemeAsset()
        {
            var path = ResourcesRoot + "/RoyalTheme.asset";
            var existing = AssetDatabase.LoadAssetAtPath<RoyalThemeAsset>(path);
            if (existing != null) return;
            var asset = ScriptableObject.CreateInstance<RoyalThemeAsset>();
            AssetDatabase.CreateAsset(asset, path);
        }

        private static void CreateCatalogAsset()
        {
            var path = ResourcesRoot + "/RoyalCatalog.asset";
            var existing = AssetDatabase.LoadAssetAtPath<RoyalCatalogAsset>(path);
            if (existing != null) return;
            var asset = RoyalRuntimeDefaults.CreateCatalog();
            asset.name = "RoyalCatalog";
            AssetDatabase.CreateAsset(asset, path);
        }

        private static void CreateScreenPrefabs()
        {
            foreach (var pair in ScreenTypes)
            {
                var path = $"{PrefabRoot}/{pair.Key}.prefab";
                if (AssetDatabase.LoadAssetAtPath<GameObject>(path) != null) continue;
                var go = new GameObject(pair.Key + "ScreenPrefab", typeof(RectTransform));
                go.AddComponent(pair.Value);
                PrefabUtility.SaveAsPrefabAsset(go, path);
                UnityEngine.Object.DestroyImmediate(go);
            }
        }

        private static void CreateScenes()
        {
            var bootstrapPath = SceneRoot + "/Bootstrap.unity";
            CreateRouteScene(bootstrapPath, AppRoute.Splash);
            foreach (var route in ScreenTypes.Keys)
                CreateRouteScene($"{SceneRoot}/{route}.unity", route);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(bootstrapPath, true)
            };
        }

        private static void CreateRouteScene(string path, AppRoute route)
        {
            if (File.Exists(path)) return;
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("RoyalGameApp");
            var bootstrap = root.AddComponent<SingleScreenBootstrap>();
            bootstrap.route = route;
            root.AddComponent<RoyalGameApp>();
            EditorSceneManager.SaveScene(scene, path);
        }

        private static void ConfigurePlayerSettings()
        {
            PlayerSettings.companyName = "Menchino";
            PlayerSettings.productName = "مار و پله پادشاهی";
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "mk.kadkhodai.menchino");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Medium);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.usePlayerLog = true;
        }

        private static void EnsureFolder(string parent, string child)
        {
            var path = parent + "/" + child;
            if (!AssetDatabase.IsValidFolder(path)) AssetDatabase.CreateFolder(parent, child);
        }
    }
}
#endif
