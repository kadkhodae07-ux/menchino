#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Editor
{
    public static class AndroidBuild
    {
        [MenuItem("Menchino/مار و پله پادشاهی/ساخت APK اندروید")]
        public static void BuildApkMenu() => Build("Builds/Android/MarOPelePadshahi.apk", false, "Generic");

        [MenuItem("Menchino/مار و پله پادشاهی/ساخت AAB اندروید")]
        public static void BuildAabMenu() => Build("Builds/Android/MarOPelePadshahi.aab", true, "Generic");

        public static void BuildApkBatch() => Build(
            GetArgument("-outputPath", "Builds/Android/MarOPelePadshahi.apk"),
            false,
            GetArgument("-storeTarget", "Generic"));

        public static void BuildAabBatch() => Build(
            GetArgument("-outputPath", "Builds/Android/MarOPelePadshahi.aab"),
            true,
            GetArgument("-storeTarget", "Generic"));

        private static void Build(string outputPath, bool appBundle, string storeTarget)
        {
            RoyalProjectInstaller.InstallOrUpdate();
            ConfigureStoreTarget(storeTarget);
            ConfigureSigningFromEnvironment();
            var scenes = EditorBuildSettings.scenes.Where(x => x.enabled).Select(x => x.path).ToArray();
            if (scenes.Length == 0) throw new InvalidOperationException("No enabled scenes in build settings.");
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? "Builds/Android");
            EditorUserBuildSettings.buildAppBundle = appBundle;
            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.CleanBuildCache
            };
            var report = BuildPipeline.BuildPlayer(options);
            var summary = report.summary;
            Debug.Log($"Android build result: {summary.result}; size={summary.totalSize}; errors={summary.totalErrors}; warnings={summary.totalWarnings}");
            if (summary.result != BuildResult.Succeeded)
                throw new BuildFailedException($"Android build failed with {summary.totalErrors} errors.");
        }



        private static void ConfigureStoreTarget(string storeTarget)
        {
            var current = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android)
                .Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Where(x => !string.Equals(x, "STORE_BAZAAR", StringComparison.OrdinalIgnoreCase)
                         && !string.Equals(x, "STORE_MYKET", StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (string.Equals(storeTarget, "Bazaar", StringComparison.OrdinalIgnoreCase))
                current.Add("STORE_BAZAAR");
            else if (string.Equals(storeTarget, "Myket", StringComparison.OrdinalIgnoreCase))
                current.Add("STORE_MYKET");

            PlayerSettings.SetScriptingDefineSymbolsForGroup(
                BuildTargetGroup.Android,
                string.Join(";", current.Distinct(StringComparer.OrdinalIgnoreCase)));
            Debug.Log($"Android store target: {storeTarget}");
        }

        private static void ConfigureSigningFromEnvironment()
        {
            var keystorePath = Environment.GetEnvironmentVariable("ANDROID_KEYSTORE_PATH");
            if (string.IsNullOrWhiteSpace(keystorePath) || !File.Exists(keystorePath))
            {
                PlayerSettings.Android.useCustomKeystore = false;
                return;
            }
            PlayerSettings.Android.useCustomKeystore = true;
            PlayerSettings.Android.keystoreName = Path.GetFullPath(keystorePath);
            PlayerSettings.Android.keystorePass = Environment.GetEnvironmentVariable("ANDROID_KEYSTORE_PASS") ?? string.Empty;
            PlayerSettings.Android.keyaliasName = Environment.GetEnvironmentVariable("ANDROID_KEYALIAS_NAME") ?? string.Empty;
            PlayerSettings.Android.keyaliasPass = Environment.GetEnvironmentVariable("ANDROID_KEYALIAS_PASS") ?? string.Empty;
        }

        private static string GetArgument(string name, string fallback)
        {
            var args = Environment.GetCommandLineArgs();
            for (var i = 0; i < args.Length - 1; i++)
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
            return fallback;
        }
    }
}
#endif
