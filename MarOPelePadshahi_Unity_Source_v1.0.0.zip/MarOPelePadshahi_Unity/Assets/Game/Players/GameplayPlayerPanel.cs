using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.Players
{
    public sealed class GameplayPlayerPanel : MonoBehaviour
    {
        private RoyalUIFactory _ui;
        private Image _background;
        private TMP_Text _name;
        private TMP_Text _timer;
        private TMP_Text _status;
        private Color _accent;

        public void Build(RoyalUIFactory ui, MatchPlayer player, Color accent)
        {
            _ui = ui;
            _accent = accent;
            var root = GetComponent<RectTransform>() ?? gameObject.AddComponent<RectTransform>();
            _background = ui.Panel("Background", root, Color.Lerp(accent, ui.Theme.royalBlue, 0.55f), Color.Lerp(accent, ui.Theme.navy, 0.72f), ui.Theme.darkGold, 20, 4);
            _background.rectTransform.anchorMin = Vector2.zero;
            _background.rectTransform.anchorMax = Vector2.one;
            _background.rectTransform.offsetMin = Vector2.zero;
            _background.rectTransform.offsetMax = Vector2.zero;

            var avatar = ui.Panel("Avatar", root, Color.Lerp(accent, Color.white, 0.12f), Color.Lerp(accent, Color.black, 0.35f), ui.Theme.gold, 32, 4);
            avatar.rectTransform.anchorMin = new Vector2(0.02f, 0.12f);
            avatar.rectTransform.anchorMax = new Vector2(0.29f, 0.88f);
            avatar.rectTransform.offsetMin = Vector2.zero;
            avatar.rectTransform.offsetMax = Vector2.zero;
            var crown = ui.Icon("AvatarSymbol", avatar.transform, "crown", ui.Theme.lightGold);
            crown.rectTransform.anchorMin = new Vector2(0.18f, 0.18f);
            crown.rectTransform.anchorMax = new Vector2(0.82f, 0.82f);
            crown.rectTransform.offsetMin = Vector2.zero;
            crown.rectTransform.offsetMax = Vector2.zero;

            _name = ui.Text("Name", root, player.displayName, 25, ui.Theme.textPrimary, TextAlignmentOptions.Right, FontStyles.Bold);
            _name.rectTransform.anchorMin = new Vector2(0.31f, 0.52f);
            _name.rectTransform.anchorMax = new Vector2(0.80f, 0.93f);
            _name.rectTransform.offsetMin = Vector2.zero;
            _name.rectTransform.offsetMax = Vector2.zero;
            _timer = ui.Text("Timer", root, "00:30", 21, ui.Theme.lightGold, TextAlignmentOptions.Right, FontStyles.Bold);
            _timer.rectTransform.anchorMin = new Vector2(0.31f, 0.08f);
            _timer.rectTransform.anchorMax = new Vector2(0.78f, 0.49f);
            _timer.rectTransform.offsetMin = Vector2.zero;
            _timer.rectTransform.offsetMax = Vector2.zero;
            var pawnIcon = ui.Icon("Pawn", root, "pawn", Color.Lerp(accent, Color.white, 0.18f));
            pawnIcon.rectTransform.anchorMin = new Vector2(0.81f, 0.34f);
            pawnIcon.rectTransform.anchorMax = new Vector2(0.96f, 0.84f);
            pawnIcon.rectTransform.offsetMin = Vector2.zero;
            pawnIcon.rectTransform.offsetMax = Vector2.zero;
            _status = ui.Text("Status", root, "●", 20, ui.Theme.success, TextAlignmentOptions.Center, FontStyles.Bold);
            _status.rectTransform.anchorMin = new Vector2(0.83f, 0.05f);
            _status.rectTransform.anchorMax = new Vector2(0.98f, 0.30f);
            _status.rectTransform.offsetMin = Vector2.zero;
            _status.rectTransform.offsetMax = Vector2.zero;
        }

        public void UpdateState(MatchPlayer player, bool active)
        {
            _ui.SetText(_name, player.displayName);
            var seconds = Mathf.CeilToInt(player.turnTimeRemaining);
            _ui.SetText(_timer, $"⏳ 00:{seconds:00}");
            _ui.SetText(_status, player.connected ? "●" : "×");
            _status.color = player.connected ? _ui.Theme.success : _ui.Theme.danger;
            _background.sprite = RoyalSpriteCache.Rounded(
                Color.Lerp(_accent, _ui.Theme.royalBlue, active ? 0.25f : 0.62f),
                Color.Lerp(_accent, _ui.Theme.navy, 0.74f),
                active ? _ui.Theme.lightGold : _ui.Theme.darkGold,
                20,
                active ? 6 : 3);
        }
    }
}
