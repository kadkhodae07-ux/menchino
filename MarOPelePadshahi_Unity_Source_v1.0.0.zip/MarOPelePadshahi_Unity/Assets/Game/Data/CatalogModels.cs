using System;
using System.Collections.Generic;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Data
{
    public enum ProductCategory { Coin, Gem, Piece, Dice, Avatar, Frame, Trail, Bundle }
    public enum CurrencyType { Coin, Gem, Rial }

    [Serializable]
    public sealed class ShopProduct
    {
        public string id;
        public string title;
        [TextArea] public string description;
        public ProductCategory category;
        public CurrencyType currency;
        public int price;
        public int discountPercent;
        public bool owned;
        public bool selected;
        public string iconKey;
    }

    [Serializable]
    public sealed class MissionData
    {
        public string id;
        public string title;
        public string description;
        public int progress;
        public int target;
        public int rewardCoins;
        public bool claimed;
        public long expiresUnix;
        public float Progress01 => target <= 0 ? 0 : Mathf.Clamp01(progress / (float)target);
    }

    [Serializable]
    public sealed class LeagueEntry
    {
        public int rank;
        public string userId;
        public string name;
        public int score;
        public string avatarId;
        public string league;
        public bool online;
    }

    [Serializable]
    public sealed class FriendData
    {
        public string userId;
        public string name;
        public string avatarId;
        public bool online;
        public long lastSeenUnix;
    }

    [CreateAssetMenu(menuName = "Menchino/Royal Catalog", fileName = "RoyalCatalog")]
    public sealed class RoyalCatalogAsset : ScriptableObject
    {
        public List<ShopProduct> products = new List<ShopProduct>();
        public List<MissionData> missions = new List<MissionData>();
        public List<LeagueEntry> leagueEntries = new List<LeagueEntry>();
        public List<FriendData> friends = new List<FriendData>();
    }
}
