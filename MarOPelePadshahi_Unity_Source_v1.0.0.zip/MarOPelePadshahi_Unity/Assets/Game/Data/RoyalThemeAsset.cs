using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Data
{
    [CreateAssetMenu(menuName = "Menchino/Royal Theme", fileName = "RoyalTheme")]
    public sealed class RoyalThemeAsset : ScriptableObject
    {
        [Header("Colors")]
        public Color navy = new Color32(4, 24, 54, 255);
        public Color royalBlue = new Color32(8, 63, 118, 255);
        public Color teal = new Color32(0, 164, 190, 255);
        public Color gold = new Color32(243, 180, 46, 255);
        public Color lightGold = new Color32(255, 225, 133, 255);
        public Color darkGold = new Color32(133, 78, 9, 255);
        public Color success = new Color32(58, 190, 95, 255);
        public Color warning = new Color32(242, 156, 48, 255);
        public Color danger = new Color32(190, 55, 55, 255);
        public Color disabled = new Color32(90, 103, 119, 255);
        public Color textPrimary = new Color32(255, 239, 199, 255);
        public Color textSecondary = new Color32(199, 215, 231, 255);

        [Header("Spacing")]
        public float spacingXs = 6f;
        public float spacingSm = 10f;
        public float spacingMd = 16f;
        public float spacingLg = 24f;
        public float spacingXl = 34f;

        [Header("Sizing")]
        public float buttonHeight = 72f;
        public float smallButtonHeight = 54f;
        public float panelRadius = 26f;
        public float borderWidth = 5f;
        public float iconSize = 46f;
        public float titleSize = 54f;
        public float headingSize = 36f;
        public float bodySize = 25f;
        public float captionSize = 20f;

        [Header("Animation")]
        public float fastDuration = 0.12f;
        public float normalDuration = 0.22f;
        public float slowDuration = 0.42f;
    }
}
