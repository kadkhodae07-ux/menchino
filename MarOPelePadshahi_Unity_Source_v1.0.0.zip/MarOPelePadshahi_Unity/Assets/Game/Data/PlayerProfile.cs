using System;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Data
{
    [Serializable]
    public sealed class PlayerProfile
    {
        public string userId = "7583921";
        public string displayName = "شاهین";
        public int level = 15;
        public int xp = 6250;
        public int xpForNextLevel = 10000;
        public string league = "لیگ الماس";
        public int gamesPlayed = 124;
        public int wins = 89;
        public int trophies = 2450;
        public string favoritePieceId = "emerald_snake";
        public string avatarId = "king_male_01";
        public string frameId = "royal_gold";
        public string titleId = "royal_champion";
        public string flagCode = "IR";
        public long joinedUnix = 1735689600;

        public int WinRatePercent => gamesPlayed <= 0 ? 0 : Mathf.RoundToInt(wins * 100f / gamesPlayed);
    }

    [Serializable]
    public sealed class CurrencyWallet
    {
        public int coins = 12450;
        public int gems = 320;
    }
}
