using System;
using System.Collections.Generic;

namespace Menchino.RoyalSnakesLadders.Data
{
    [Serializable]
    public sealed class BoardTransition
    {
        public int from;
        public int to;
        public bool IsLadder => to > from;
    }

    [Serializable]
    public sealed class BoardDefinition
    {
        public string id = "royal_standard";
        public int cellCount = 100;
        public List<BoardTransition> transitions = new List<BoardTransition>();
        public List<int> safeCells = new List<int>();

        public static BoardDefinition CreateRoyalStandard()
        {
            return new BoardDefinition
            {
                transitions = new List<BoardTransition>
                {
                    new BoardTransition { from = 4, to = 24 },
                    new BoardTransition { from = 13, to = 30 },
                    new BoardTransition { from = 33, to = 49 },
                    new BoardTransition { from = 54, to = 67 },
                    new BoardTransition { from = 63, to = 84 },
                    new BoardTransition { from = 18, to = 7 },
                    new BoardTransition { from = 36, to = 15 },
                    new BoardTransition { from = 60, to = 39 },
                    new BoardTransition { from = 75, to = 55 },
                    new BoardTransition { from = 91, to = 50 },
                    new BoardTransition { from = 96, to = 76 }
                },
                safeCells = new List<int> { 1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
            };
        }

        public bool TryGetTransition(int cell, out BoardTransition transition)
        {
            transition = transitions.Find(x => x.from == cell);
            return transition != null;
        }
    }
}
