using System;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Data
{
    public static class RoyalRuntimeDefaults
    {
        public static RoyalCatalogAsset CreateCatalog()
        {
            var asset = ScriptableObject.CreateInstance<RoyalCatalogAsset>();
            asset.products.Add(new ShopProduct { id = "emerald_snake", title = "مهره مار زمردی", description = "مهره‌ای سلطنتی با درخشش زمرد", category = ProductCategory.Piece, currency = CurrencyType.Coin, price = 2500, owned = true, selected = true, iconKey = "snake_green" });
            asset.products.Add(new ShopProduct { id = "fire_snake", title = "مهره مار آتشین", description = "مار آتشین با جلوه حرکت گرم", category = ProductCategory.Piece, currency = CurrencyType.Coin, price = 2000, iconKey = "snake_red" });
            asset.products.Add(new ShopProduct { id = "gold_pawn", title = "مهره طلایی", description = "مهره کلاسیک سلطنتی", category = ProductCategory.Piece, currency = CurrencyType.Coin, price = 1800, iconKey = "pawn_gold" });
            asset.products.Add(new ShopProduct { id = "ice_snake", title = "مهره مار یخی", description = "مهره سرد و درخشان", category = ProductCategory.Piece, currency = CurrencyType.Gem, price = 180, iconKey = "snake_blue" });
            asset.products.Add(new ShopProduct { id = "ivory_gold", title = "تاس عاجی سلطنتی", description = "تاس سه‌بعدی اختصاصی با لبه‌های نرم", category = ProductCategory.Dice, currency = CurrencyType.Coin, price = 0, owned = true, selected = true, iconKey = "dice_ivory" });
            asset.products.Add(new ShopProduct { id = "royal_bundle", title = "باندل پادشاهی", description = "مجموعه سکه، الماس و قاب سلطنتی", category = ProductCategory.Bundle, currency = CurrencyType.Rial, price = 189000, iconKey = "bundle_royal" });

            var expires = DateTimeOffset.UtcNow.AddDays(1).ToUnixTimeSeconds();
            asset.missions.Add(new MissionData { id = "play_one", title = "یک بازی انجام بده", description = "یک مسابقه کامل انجام بده", progress = 0, target = 1, rewardCoins = 100, expiresUnix = expires });
            asset.missions.Add(new MissionData { id = "roll_six", title = "سه بار عدد ۶ بیاور", description = "در مسابقه‌ها سه بار تاس ۶ بگیر", progress = 1, target = 3, rewardCoins = 200, expiresUnix = expires });
            asset.missions.Add(new MissionData { id = "climb_ladder", title = "از سه نردبان بالا برو", description = "سه نردبان را در بازی‌های مختلف طی کن", progress = 2, target = 3, rewardCoins = 150, expiresUnix = expires });
            asset.missions.Add(new MissionData { id = "win_online", title = "یک بازی آنلاین برنده شو", description = "در حالت آنلاین پیروز شو", progress = 0, target = 1, rewardCoins = 250, expiresUnix = expires });

            string[] names = { "شهرزاد آرش", "سلطان رادین", "امیرحسام", "لیانا", "پارسا", "شاهین", "نگار", "کیان" };
            int[] scores = { 6820, 6450, 6120, 5580, 5375, 5320, 5210, 5150 };
            for (var i = 0; i < names.Length; i++)
                asset.leagueEntries.Add(new LeagueEntry { rank = i + 1, userId = i == 5 ? "7583921" : $"league_{i}", name = names[i], score = scores[i], avatarId = $"avatar_{i}", league = "الماس", online = i % 2 == 0 });

            string[] friendNames = { "آرمان", "یلدا", "سارا", "رادین", "مینا", "هیراد" };
            for (var i = 0; i < friendNames.Length; i++)
                asset.friends.Add(new FriendData { userId = $"friend_{i}", name = friendNames[i], avatarId = $"friend_avatar_{i}", online = i < 3, lastSeenUnix = DateTimeOffset.UtcNow.AddMinutes(-20 * i).ToUnixTimeSeconds() });
            return asset;
        }
    }
}
