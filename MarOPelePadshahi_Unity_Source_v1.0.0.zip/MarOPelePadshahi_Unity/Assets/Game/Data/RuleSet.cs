using System;

namespace Menchino.RoyalSnakesLadders.Data
{
    [Serializable]
    public sealed class RuleSet
    {
        public bool exactRollToFinish = true;
        public bool extraTurnOnSix = true;
        public bool burnTurnOnThirdSix = true;
        public bool captureEnabled;
        public bool safeCellsEnabled;
        public bool requireSixToEnter;
        public bool bounceBackAfterHundred;
        public bool turnTimerEnabled = true;
        public int turnSeconds = 30;
        public bool autoRollOnTimeout = true;

        public RuleSet Clone() => (RuleSet)MemberwiseClone();
    }
}
