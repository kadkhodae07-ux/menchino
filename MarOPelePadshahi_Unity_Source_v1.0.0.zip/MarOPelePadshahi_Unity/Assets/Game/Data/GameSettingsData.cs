using System;

namespace Menchino.RoyalSnakesLadders.Data
{
    [Serializable]
    public sealed class GameSettingsData
    {
        public float musicVolume = 0.65f;
        public float sfxVolume = 0.85f;
        public bool vibrationEnabled = true;
        public bool notificationsEnabled = true;
        public bool lowPowerMode;
        public int graphicsQuality = 2;
        public string language = "fa";
        public bool tutorialCompleted;
        public string selectedPieceId = "emerald_snake";
        public string selectedDiceId = "ivory_gold";
    }
}
