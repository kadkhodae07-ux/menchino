using System;
using System.Collections.Generic;

namespace Menchino.RoyalSnakesLadders.Data
{
    [Serializable]
    public sealed class SaveEnvelope
    {
        public int schemaVersion = 2;
        public PlayerProfile profile = new PlayerProfile();
        public CurrencyWallet wallet = new CurrencyWallet();
        public GameSettingsData settings = new GameSettingsData();
        public long dailyRewardLastClaimUnix;
        public int dailyRewardStreak;
        public string lastValidRoute = "Home";
        public List<string> ownedProductIds = new List<string>();
        public List<string> claimedMissionIds = new List<string>();
        public List<string> rewardedMatchIds = new List<string>();
        public List<MissionProgressRecord> missionProgress = new List<MissionProgressRecord>();
    }

    [Serializable]
    public sealed class MissionProgressRecord
    {
        public string id;
        public int progress;
    }
}
