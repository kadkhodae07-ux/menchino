using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using NUnit.Framework;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Tests.EditMode
{
    public sealed class EconomyAndMissionTests
    {
        [Test]
        public void MatchReward_IsAppliedOnlyOncePerMatchId()
        {
            var save = new MemorySaveService();
            var profile = new ProfileService(save, new RoyalEventBus());
            var initialCoins = save.Current.wallet.coins;

            Assert.IsTrue(profile.TryApplyMatchRewards("match-1", true, 250, 120, 18));
            Assert.IsFalse(profile.TryApplyMatchRewards("match-1", true, 250, 120, 18));
            Assert.AreEqual(initialCoins + 250, save.Current.wallet.coins);
            Assert.AreEqual(1, save.Current.rewardedMatchIds.Count);
        }

        [Test]
        public void Purchase_DeductsCurrencyAndPersistsOwnership()
        {
            var save = new MemorySaveService();
            save.Current.wallet.coins = 1000;
            var profile = new ProfileService(save, new RoyalEventBus());
            var catalogAsset = ScriptableObject.CreateInstance<RoyalCatalogAsset>();
            catalogAsset.products.Add(new ShopProduct
            {
                id = "piece_test",
                title = "مهره تست",
                category = ProductCategory.Piece,
                currency = CurrencyType.Coin,
                price = 400
            });
            var catalog = new CatalogService(catalogAsset, profile, save);

            Assert.IsTrue(catalog.Buy("piece_test"));
            Assert.AreEqual(600, save.Current.wallet.coins);
            Assert.Contains("piece_test", save.Current.ownedProductIds);
            Assert.IsTrue(catalogAsset.products[0].owned);
            Object.DestroyImmediate(catalogAsset);
        }

        [Test]
        public void MissionProgress_TracksRollLadderAndCompletedMatch()
        {
            var save = new MemorySaveService();
            var profile = new ProfileService(save, new RoyalEventBus());
            var catalogAsset = ScriptableObject.CreateInstance<RoyalCatalogAsset>();
            catalogAsset.missions.Add(new MissionData { id = "play_one", target = 1 });
            catalogAsset.missions.Add(new MissionData { id = "roll_six", target = 3 });
            catalogAsset.missions.Add(new MissionData { id = "climb_ladder", target = 3 });
            catalogAsset.missions.Add(new MissionData { id = "win_online", target = 1 });
            var catalog = new CatalogService(catalogAsset, profile, save);

            catalog.RecordRollResult(6, true);
            catalog.RecordMatchCompleted(true, true);

            Assert.AreEqual(1, catalogAsset.missions.Find(x => x.id == "roll_six").progress);
            Assert.AreEqual(1, catalogAsset.missions.Find(x => x.id == "climb_ladder").progress);
            Assert.AreEqual(1, catalogAsset.missions.Find(x => x.id == "play_one").progress);
            Assert.AreEqual(1, catalogAsset.missions.Find(x => x.id == "win_online").progress);
            Assert.AreEqual(4, save.Current.missionProgress.Count);
            Object.DestroyImmediate(catalogAsset);
        }

        [Test]
        public void ClaimMission_CannotPayTwice()
        {
            var save = new MemorySaveService();
            save.Current.wallet.coins = 0;
            var profile = new ProfileService(save, new RoyalEventBus());
            var catalogAsset = ScriptableObject.CreateInstance<RoyalCatalogAsset>();
            catalogAsset.missions.Add(new MissionData { id = "done", target = 1, progress = 1, rewardCoins = 100 });
            var catalog = new CatalogService(catalogAsset, profile, save);

            Assert.IsTrue(catalog.ClaimMission("done"));
            Assert.IsFalse(catalog.ClaimMission("done"));
            Assert.AreEqual(100, save.Current.wallet.coins);
            Assert.AreEqual(1, save.Current.claimedMissionIds.Count);
            Object.DestroyImmediate(catalogAsset);
        }

        private sealed class MemorySaveService : ISaveService
        {
            public SaveEnvelope Current { get; private set; } = new SaveEnvelope();
            public int SaveCount { get; private set; }
            public void Load() { }
            public void Save() => SaveCount++;
            public void ResetToSafeDefaults() => Current = new SaveEnvelope();
        }
    }
}
