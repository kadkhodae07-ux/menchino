using Menchino.RoyalSnakesLadders.Board;
using NUnit.Framework;

namespace Menchino.RoyalSnakesLadders.Tests.EditMode
{
    public sealed class BoardCoordinateMapperTests
    {
        [TestCase(1, 0, 0)]
        [TestCase(10, 9, 0)]
        [TestCase(11, 9, 1)]
        [TestCase(20, 0, 1)]
        [TestCase(91, 0, 9)]
        [TestCase(100, 9, 9)]
        public void CellToGrid_IsSerpentine(int cell, int expectedX, int expectedY)
        {
            var grid = BoardCoordinateMapper.CellToGrid(cell);
            Assert.AreEqual(expectedX, grid.x);
            Assert.AreEqual(expectedY, grid.y);
            Assert.AreEqual(cell, BoardCoordinateMapper.GridToCell(grid.x, grid.y));
        }
    }
}
