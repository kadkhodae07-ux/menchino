using System;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;
using NUnit.Framework;

namespace Menchino.RoyalSnakesLadders.Tests.EditMode
{
    public sealed class SnakesLaddersEngineTests
    {
        [Test]
        public void Move_UsesEveryIntermediateCell()
        {
            var engine = CreateEngine(new[] { 3 });
            engine.Start();
            var result = engine.Roll();
            CollectionAssert.AreEqual(new[] { 1, 2, 3 }, result.Path);
            Assert.AreEqual(3, engine.Snapshot.players[0].position);
        }

        [Test]
        public void Ladder_MovesToDestination()
        {
            var board = BoardDefinition.CreateRoyalStandard();
            board.transitions.Clear();
            board.transitions.Add(new BoardTransition { from = 3, to = 22 });
            var engine = CreateEngine(new[] { 3 }, board);
            engine.Start();
            var result = engine.Roll();
            Assert.IsTrue(result.IsLadder);
            Assert.AreEqual(3, result.TransitionFrom);
            Assert.AreEqual(22, engine.Snapshot.players[0].position);
        }

        [Test]
        public void Snake_MovesToDestination()
        {
            var board = BoardDefinition.CreateRoyalStandard();
            board.transitions.Clear();
            board.transitions.Add(new BoardTransition { from = 5, to = 2 });
            var engine = CreateEngine(new[] { 5 }, board);
            engine.Start();
            var result = engine.Roll();
            Assert.IsFalse(result.IsLadder);
            Assert.AreEqual(2, engine.Snapshot.players[0].position);
        }

        [Test]
        public void ExactHundred_RejectsOvershoot()
        {
            var config = CreateConfig(new RuleSet { exactRollToFinish = true, extraTurnOnSix = false });
            config.players[0].position = 98;
            var engine = new SnakesLaddersEngine(config, new FixedDiceService(new[] { 4 }));
            engine.Start();
            var result = engine.Roll();
            Assert.AreEqual(0, result.Path.Count);
            Assert.AreEqual(98, engine.Snapshot.players[0].position);
        }

        [Test]
        public void Six_GrantsExtraTurn()
        {
            var rules = new RuleSet { extraTurnOnSix = true, burnTurnOnThirdSix = true };
            var engine = CreateEngine(new[] { 6 }, null, rules);
            engine.Start();
            var result = engine.Roll();
            Assert.IsTrue(result.ExtraTurn);
            Assert.AreEqual(0, engine.Snapshot.activePlayerIndex);
        }

        [Test]
        public void ThirdConsecutiveSix_BurnsTurn()
        {
            var rules = new RuleSet { extraTurnOnSix = true, burnTurnOnThirdSix = true };
            var engine = CreateEngine(new[] { 6, 6, 6 }, null, rules);
            engine.Start();
            Assert.IsFalse(engine.Roll().TurnBurned);
            Assert.IsFalse(engine.Roll().TurnBurned);
            Assert.IsTrue(engine.Roll().TurnBurned);
            Assert.AreEqual(1, engine.Snapshot.activePlayerIndex);
        }

        [Test]
        public void Capture_ReturnsOpponentToStart()
        {
            var rules = new RuleSet { captureEnabled = true, extraTurnOnSix = false };
            var config = CreateConfig(rules);
            config.players[0].position = 5;
            config.players[1].position = 8;
            var engine = new SnakesLaddersEngine(config, new FixedDiceService(new[] { 3 }));
            engine.Start();
            engine.Roll();
            Assert.AreEqual(8, engine.Snapshot.players[0].position);
            Assert.AreEqual(0, engine.Snapshot.players[1].position);
        }

        [TestCase(2)]
        [TestCase(3)]
        [TestCase(4)]
        public void SupportsTwoThreeAndFourPlayers(int count)
        {
            var config = MatchConfigFactory.CreateBotMatch(count, new RuleSet());
            var engine = new SnakesLaddersEngine(config, new FixedDiceService(new[] { 1 }));
            engine.Start();
            Assert.AreEqual(count, engine.Snapshot.players.Count);
        }

        [Test]
        public void DuplicateColors_AreRejected()
        {
            var config = CreateConfig(new RuleSet());
            config.players[1].colorIndex = config.players[0].colorIndex;
            Assert.Throws<ArgumentException>(() => new SnakesLaddersEngine(config, new FixedDiceService(new[] { 1 })));
        }

        private static SnakesLaddersEngine CreateEngine(IEnumerable<int> rolls, BoardDefinition board = null, RuleSet rules = null)
        {
            var config = CreateConfig(rules ?? new RuleSet());
            config.board = board ?? new BoardDefinition { cellCount = 100 };
            return new SnakesLaddersEngine(config, new FixedDiceService(rolls));
        }

        private static MatchConfig CreateConfig(RuleSet rules)
        {
            return new MatchConfig
            {
                board = new BoardDefinition { cellCount = 100 },
                rules = rules,
                players = new List<MatchPlayer>
                {
                    new MatchPlayer { id = "a", displayName = "A", controlType = PlayerControlType.LocalHuman, colorIndex = 0 },
                    new MatchPlayer { id = "b", displayName = "B", controlType = PlayerControlType.Bot, colorIndex = 1 }
                },
                targetRanks = 1
            };
        }
    }
}
