using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;

namespace Menchino.RoyalSnakesLadders.Core
{
    public readonly struct RouteChangedEvent
    {
        public RouteChangedEvent(AppRoute route) => Route = route;
        public AppRoute Route { get; }
    }

    public readonly struct ProfileChangedEvent
    {
        public ProfileChangedEvent(PlayerProfile profile) => Profile = profile;
        public PlayerProfile Profile { get; }
    }

    public readonly struct WalletChangedEvent
    {
        public WalletChangedEvent(CurrencyWallet wallet) => Wallet = wallet;
        public CurrencyWallet Wallet { get; }
    }

    public readonly struct MatchStateChangedEvent
    {
        public MatchStateChangedEvent(MatchSnapshot snapshot) => Snapshot = snapshot;
        public MatchSnapshot Snapshot { get; }
    }
}
