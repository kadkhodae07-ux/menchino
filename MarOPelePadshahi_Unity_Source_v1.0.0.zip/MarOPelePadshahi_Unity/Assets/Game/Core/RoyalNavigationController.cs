using System;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.UI;
using Menchino.RoyalSnakesLadders.UI.Screens;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Core
{
    public sealed class RoyalNavigationController
    {
        private readonly RoyalGameApp _app;
        private readonly Stack<RoyalScreenBase> _stack = new Stack<RoyalScreenBase>();

        public RoyalNavigationController(RoyalGameApp app) => _app = app;
        public AppRoute CurrentRoute => _stack.Count == 0 ? AppRoute.Splash : _stack.Peek().Route;

        public void Navigate(AppRoute route)
        {
            if (_stack.Count > 0) _stack.Peek().gameObject.SetActive(false);
            var screen = Create(route);
            _stack.Push(screen);
            _app.Events.Publish(new RouteChangedEvent(route));
            PersistRoute(route);
        }

        public void Replace(AppRoute route)
        {
            if (_stack.Count > 0)
            {
                var current = _stack.Pop();
                UnityEngine.Object.Destroy(current.gameObject);
            }
            var screen = Create(route);
            _stack.Push(screen);
            _app.Events.Publish(new RouteChangedEvent(route));
            PersistRoute(route);
        }

        public void Reset(AppRoute route)
        {
            while (_stack.Count > 0)
            {
                var old = _stack.Pop();
                if (old != null) UnityEngine.Object.Destroy(old.gameObject);
            }
            foreach (Transform child in _app.ScreenHost)
                UnityEngine.Object.Destroy(child.gameObject);
            RoyalPopupService.CloseActive();
            var screen = Create(route);
            _stack.Push(screen);
            _app.Events.Publish(new RouteChangedEvent(route));
            PersistRoute(route);
        }

        public void HandleBack()
        {
            if (RoyalPopupService.HasPopup)
            {
                RoyalPopupService.CloseActive();
                return;
            }
            if (_stack.Count > 1)
            {
                var current = _stack.Pop();
                if (current != null) UnityEngine.Object.Destroy(current.gameObject);
                var previous = _stack.Peek();
                if (previous != null) previous.gameObject.SetActive(true);
                _app.Events.Publish(new RouteChangedEvent(previous.Route));
                PersistRoute(previous.Route);
                return;
            }
            if (_stack.Count == 1 && _stack.Peek().Route != AppRoute.Home)
            {
                Reset(AppRoute.Home);
                return;
            }
            RoyalPopupService.ShowConfirm(_app, "خروج از بازی", "از مار و پله پادشاهی خارج می‌شوید؟", "خروج", Application.Quit, "ماندن");
        }

        private RoyalScreenBase Create(AppRoute route)
        {
            var prefab = Resources.Load<GameObject>("ScreenPrefabs/" + route);
            GameObject go;
            RoyalScreenBase screen;
            if (prefab != null)
            {
                go = UnityEngine.Object.Instantiate(prefab, _app.ScreenHost);
                screen = go.GetComponent<RoyalScreenBase>();
                if (screen == null) throw new InvalidOperationException($"Screen prefab {route} has no RoyalScreenBase component.");
            }
            else
            {
                go = new GameObject(route + "Screen", typeof(RectTransform));
                go.transform.SetParent(_app.ScreenHost, false);
                screen = AddScreenComponent(go, route);
            }
            go.name = route + "Screen";
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            screen.Initialize(_app);
            return screen;
        }

        private static RoyalScreenBase AddScreenComponent(GameObject go, AppRoute route)
        {
            switch (route)
            {
                case AppRoute.Splash: return go.AddComponent<SplashScreen>();
                case AppRoute.Language: return go.AddComponent<LanguageScreen>();
                case AppRoute.Login: return go.AddComponent<LoginScreen>();
                case AppRoute.Home: return go.AddComponent<HomeScreen>();
                case AppRoute.ModeSelection: return go.AddComponent<ModeSelectionScreen>();
                case AppRoute.BotSetup: return go.AddComponent<BotSetupScreen>();
                case AppRoute.LocalTwoPlayer: return go.AddComponent<LocalTwoPlayerScreen>();
                case AppRoute.FriendlyRoomCreate: return go.AddComponent<FriendlyRoomCreateScreen>();
                case AppRoute.FriendlyRoomJoin: return go.AddComponent<FriendlyRoomJoinScreen>();
                case AppRoute.FriendlyLobby: return go.AddComponent<FriendlyLobbyScreen>();
                case AppRoute.Matchmaking: return go.AddComponent<MatchmakingScreen>();
                case AppRoute.Gameplay: return go.AddComponent<GameplayScreen>();
                case AppRoute.Results: return go.AddComponent<ResultsScreen>();
                case AppRoute.Shop: return go.AddComponent<ShopScreen>();
                case AppRoute.ProductDetails: return go.AddComponent<ProductDetailsScreen>();
                case AppRoute.RewardChest: return go.AddComponent<RewardChestScreen>();
                case AppRoute.League: return go.AddComponent<LeagueScreen>();
                case AppRoute.Missions: return go.AddComponent<MissionsScreen>();
                case AppRoute.Friends: return go.AddComponent<FriendsScreen>();
                case AppRoute.Messages: return go.AddComponent<MessagesScreen>();
                case AppRoute.Profile: return go.AddComponent<ProfileScreen>();
                case AppRoute.ProfileEdit: return go.AddComponent<ProfileEditScreen>();
                case AppRoute.Settings: return go.AddComponent<SettingsScreen>();
                case AppRoute.Rules: return go.AddComponent<RulesScreen>();
                case AppRoute.Support: return go.AddComponent<SupportScreen>();
                case AppRoute.PiecePickerPopup: return go.AddComponent<PiecePickerPopupScreen>();
                case AppRoute.PausePopup: return go.AddComponent<PausePopupScreen>();
                case AppRoute.Tutorial: return go.AddComponent<TutorialScreen>();
                default: throw new ArgumentOutOfRangeException(nameof(route), route, null);
            }
        }

        private void PersistRoute(AppRoute route)
        {
            if (route == AppRoute.Gameplay || route == AppRoute.Results || route == AppRoute.PausePopup) return;
            if (_app.Services.TryResolve<Menchino.RoyalSnakesLadders.Services.ISaveService>(out var save))
            {
                save.Current.lastValidRoute = route.ToString();
                save.Save();
            }
        }
    }
}
