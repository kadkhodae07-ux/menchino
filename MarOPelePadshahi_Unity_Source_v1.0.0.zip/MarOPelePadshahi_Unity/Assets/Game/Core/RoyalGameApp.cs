using Menchino.RoyalSnakesLadders.Audio;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using Menchino.RoyalSnakesLadders.UI;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.Core
{
    [DefaultExecutionOrder(-1000)]
    public sealed class RoyalGameApp : MonoBehaviour
    {
        public static RoyalGameApp Instance { get; private set; }

        public RoyalServiceRegistry Services { get; private set; }
        public RoyalEventBus Events { get; private set; }
        public RoyalUIFactory UI { get; private set; }
        public RoyalNavigationController Navigation { get; private set; }
        public RectTransform ScreenHost { get; private set; }
        public RectTransform PopupHost { get; private set; }
        public Canvas Canvas { get; private set; }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Initialize();
        }

        private void Initialize()
        {
            Screen.orientation = ScreenOrientation.Portrait;
            Events = new RoyalEventBus();
            Services = new RoyalServiceRegistry();

            var save = new EncryptedSaveService();
            save.Load();
            Application.targetFrameRate = save.Current.settings.lowPowerMode ? 45 : 60;
            if (QualitySettings.names.Length > 0)
                QualitySettings.SetQualityLevel(Mathf.Clamp(save.Current.settings.graphicsQuality, 0, QualitySettings.names.Length - 1), true);
            var theme = Resources.Load<RoyalThemeAsset>("RoyalTheme") ?? ScriptableObject.CreateInstance<RoyalThemeAsset>();
            var catalog = Resources.Load<RoyalCatalogAsset>("RoyalCatalog") ?? RoyalRuntimeDefaults.CreateCatalog();
            var audio = new ProceduralAudioService(gameObject);
            audio.SetVolumes(save.Current.settings.musicVolume, save.Current.settings.sfxVolume);
            var profile = new ProfileService(save, Events);
            var localization = new LocalizationService(save);
            var catalogService = new CatalogService(catalog, profile, save);
            var network = new MockNetworkService();
            var matchSession = new MatchSessionService();

            Services.Register<ISaveService>(save);
            Services.Register<IProfileService>(profile);
            Services.Register<ILocalizationService>(localization);
            Services.Register<ICatalogService>(catalogService);
            Services.Register<IAudioService>(audio);
            Services.Register<INetworkService>(network);
            Services.Register<IMatchSessionService>(matchSession);
            Services.Register(theme);
            Services.Register(catalog);

            UI = new RoyalUIFactory(theme, audio);
            CreateCanvas();
            Navigation = new RoyalNavigationController(this);

            var bootstrap = FindObjectOfType<SingleScreenBootstrap>();
            var initialRoute = bootstrap != null ? bootstrap.route : AppRoute.Splash;
            Navigation.Reset(initialRoute);
        }

        private void CreateCanvas()
        {
            var canvasObject = new GameObject("RoyalCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(transform, false);
            Canvas = canvasObject.GetComponent<Canvas>();
            Canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            Canvas.sortingOrder = 10;
            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(941, 1672);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.52f;

            var backdrop = UI.FullRect("Backdrop", canvasObject.transform);
            RoyalBackdrop.Build(UI, backdrop);

            var safe = UI.FullRect("SafeArea", canvasObject.transform);
            safe.gameObject.AddComponent<SafeAreaFitter>();
            ScreenHost = UI.FullRect("ScreenHost", safe).GetComponent<RectTransform>();
            PopupHost = UI.FullRect("PopupHost", safe).GetComponent<RectTransform>();

            if (FindObjectOfType<EventSystem>() == null)
            {
                var eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
                eventSystem.transform.SetParent(transform, false);
            }
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape)) Navigation.HandleBack();
        }

        private void OnApplicationPause(bool pause)
        {
            if (!pause) return;
            if (Services.TryResolve<ISaveService>(out var save)) save.Save();
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                Events?.Clear();
                Instance = null;
            }
        }
    }

    public sealed class SingleScreenBootstrap : MonoBehaviour
    {
        public AppRoute route = AppRoute.Home;
    }
}
