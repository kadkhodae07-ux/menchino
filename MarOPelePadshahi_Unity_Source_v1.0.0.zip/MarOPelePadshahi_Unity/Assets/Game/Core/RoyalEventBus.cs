using System;
using System.Collections.Generic;

namespace Menchino.RoyalSnakesLadders.Core
{
    public sealed class RoyalEventBus
    {
        private readonly Dictionary<Type, Delegate> _handlers = new Dictionary<Type, Delegate>();

        public void Subscribe<T>(Action<T> handler)
        {
            if (handler == null) return;
            var type = typeof(T);
            _handlers.TryGetValue(type, out var current);
            _handlers[type] = Delegate.Combine(current, handler);
        }

        public void Unsubscribe<T>(Action<T> handler)
        {
            if (handler == null) return;
            var type = typeof(T);
            if (!_handlers.TryGetValue(type, out var current)) return;
            var next = Delegate.Remove(current, handler);
            if (next == null) _handlers.Remove(type);
            else _handlers[type] = next;
        }

        public void Publish<T>(T payload)
        {
            if (_handlers.TryGetValue(typeof(T), out var value) && value is Action<T> action)
                action.Invoke(payload);
        }

        public void Clear() => _handlers.Clear();
    }
}
