namespace Menchino.RoyalSnakesLadders.Bots
{
    public enum BotDifficulty { Easy, Medium, Hard, Professional }

    public static class BotTiming
    {
        public static float GetDelay(BotDifficulty difficulty)
        {
            switch (difficulty)
            {
                case BotDifficulty.Easy: return 1.4f;
                case BotDifficulty.Medium: return 0.9f;
                case BotDifficulty.Hard: return 0.55f;
                case BotDifficulty.Professional: return 0.38f;
                default: return 0.9f;
            }
        }
    }
}
