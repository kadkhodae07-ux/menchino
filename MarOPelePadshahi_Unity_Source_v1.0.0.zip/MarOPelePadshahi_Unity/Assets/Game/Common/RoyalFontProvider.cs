using TMPro;
using UnityEngine;
using UnityEngine.TextCore.LowLevel;

namespace Menchino.RoyalSnakesLadders.Common
{
    public static class RoyalFontProvider
    {
        private static TMP_FontAsset _font;

        public static TMP_FontAsset Get()
        {
            if (_font != null) return _font;
            var builtin = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            _font = TMP_FontAsset.CreateFontAsset(builtin, 90, 9, GlyphRenderMode.SDFAA, 1024, 1024, AtlasPopulationMode.Dynamic, true);
            _font.name = "RoyalDynamicPersianFont";
            return _font;
        }
    }
}
