using System.Collections.Generic;
using System.Text;

namespace Menchino.RoyalSnakesLadders.Common
{
    public static class PersianTextShaper
    {
        private readonly struct Forms
        {
            public Forms(char isolated, char final, char initial, char medial, bool joinsLeft)
            {
                Isolated = isolated; Final = final; Initial = initial; Medial = medial; JoinsLeft = joinsLeft;
            }
            public char Isolated { get; }
            public char Final { get; }
            public char Initial { get; }
            public char Medial { get; }
            public bool JoinsLeft { get; }
        }

        private static readonly Dictionary<char, Forms> Map = new Dictionary<char, Forms>
        {
            ['ا'] = new Forms('\uFE8D','\uFE8E','\uFE8D','\uFE8E',false),
            ['أ'] = new Forms('\uFE83','\uFE84','\uFE83','\uFE84',false),
            ['إ'] = new Forms('\uFE87','\uFE88','\uFE87','\uFE88',false),
            ['آ'] = new Forms('\uFE81','\uFE82','\uFE81','\uFE82',false),
            ['ب'] = new Forms('\uFE8F','\uFE90','\uFE91','\uFE92',true),
            ['پ'] = new Forms('\uFB56','\uFB57','\uFB58','\uFB59',true),
            ['ت'] = new Forms('\uFE95','\uFE96','\uFE97','\uFE98',true),
            ['ث'] = new Forms('\uFE99','\uFE9A','\uFE9B','\uFE9C',true),
            ['ج'] = new Forms('\uFE9D','\uFE9E','\uFE9F','\uFEA0',true),
            ['چ'] = new Forms('\uFB7A','\uFB7B','\uFB7C','\uFB7D',true),
            ['ح'] = new Forms('\uFEA1','\uFEA2','\uFEA3','\uFEA4',true),
            ['خ'] = new Forms('\uFEA5','\uFEA6','\uFEA7','\uFEA8',true),
            ['د'] = new Forms('\uFEA9','\uFEAA','\uFEA9','\uFEAA',false),
            ['ذ'] = new Forms('\uFEAB','\uFEAC','\uFEAB','\uFEAC',false),
            ['ر'] = new Forms('\uFEAD','\uFEAE','\uFEAD','\uFEAE',false),
            ['ز'] = new Forms('\uFEAF','\uFEB0','\uFEAF','\uFEB0',false),
            ['ژ'] = new Forms('\uFB8A','\uFB8B','\uFB8A','\uFB8B',false),
            ['س'] = new Forms('\uFEB1','\uFEB2','\uFEB3','\uFEB4',true),
            ['ش'] = new Forms('\uFEB5','\uFEB6','\uFEB7','\uFEB8',true),
            ['ص'] = new Forms('\uFEB9','\uFEBA','\uFEBB','\uFEBC',true),
            ['ض'] = new Forms('\uFEBD','\uFEBE','\uFEBF','\uFEC0',true),
            ['ط'] = new Forms('\uFEC1','\uFEC2','\uFEC3','\uFEC4',true),
            ['ظ'] = new Forms('\uFEC5','\uFEC6','\uFEC7','\uFEC8',true),
            ['ع'] = new Forms('\uFEC9','\uFECA','\uFECB','\uFECC',true),
            ['غ'] = new Forms('\uFECD','\uFECE','\uFECF','\uFED0',true),
            ['ف'] = new Forms('\uFED1','\uFED2','\uFED3','\uFED4',true),
            ['ق'] = new Forms('\uFED5','\uFED6','\uFED7','\uFED8',true),
            ['ک'] = new Forms('\uFB8E','\uFB8F','\uFB90','\uFB91',true),
            ['ك'] = new Forms('\uFED9','\uFEDA','\uFEDB','\uFEDC',true),
            ['گ'] = new Forms('\uFB92','\uFB93','\uFB94','\uFB95',true),
            ['ل'] = new Forms('\uFEDD','\uFEDE','\uFEDF','\uFEE0',true),
            ['م'] = new Forms('\uFEE1','\uFEE2','\uFEE3','\uFEE4',true),
            ['ن'] = new Forms('\uFEE5','\uFEE6','\uFEE7','\uFEE8',true),
            ['و'] = new Forms('\uFEED','\uFEEE','\uFEED','\uFEEE',false),
            ['ؤ'] = new Forms('\uFE85','\uFE86','\uFE85','\uFE86',false),
            ['ه'] = new Forms('\uFEE9','\uFEEA','\uFEEB','\uFEEC',true),
            ['ة'] = new Forms('\uFE93','\uFE94','\uFE93','\uFE94',false),
            ['ی'] = new Forms('\uFBFC','\uFBFD','\uFBFE','\uFBFF',true),
            ['ي'] = new Forms('\uFEF1','\uFEF2','\uFEF3','\uFEF4',true),
            ['ئ'] = new Forms('\uFE89','\uFE8A','\uFE8B','\uFE8C',true),
            ['ء'] = new Forms('\uFE80','\uFE80','\uFE80','\uFE80',false)
        };

        public static string Shape(string input)
        {
            if (string.IsNullOrEmpty(input)) return string.Empty;
            var lines = input.Replace("\r", string.Empty).Split('\n');
            for (var lineIndex = 0; lineIndex < lines.Length; lineIndex++)
                lines[lineIndex] = ShapeLine(lines[lineIndex]);
            return string.Join("\n", lines);
        }

        private static string ShapeLine(string input)
        {
            var shaped = new char[input.Length];
            for (var i = 0; i < input.Length; i++)
            {
                var current = input[i];
                if (!Map.TryGetValue(current, out var form))
                {
                    shaped[i] = current;
                    continue;
                }

                var previousConnects = i > 0 && CanConnectForward(input[i - 1]) && CanConnectBackward(current);
                var nextConnects = i < input.Length - 1 && CanConnectForward(current) && CanConnectBackward(input[i + 1]);
                shaped[i] = previousConnects && nextConnects ? form.Medial
                    : previousConnects ? form.Final
                    : nextConnects ? form.Initial
                    : form.Isolated;
            }

            System.Array.Reverse(shaped);
            var result = new StringBuilder(shaped.Length);
            var run = new StringBuilder();
            foreach (var c in shaped)
            {
                if (IsLeftToRightToken(c)) run.Append(c);
                else
                {
                    FlushLtrRun(result, run);
                    result.Append(Mirror(c));
                }
            }
            FlushLtrRun(result, run);
            return result.ToString();
        }

        private static bool CanConnectBackward(char c) => Map.ContainsKey(c);
        private static bool CanConnectForward(char c) => Map.TryGetValue(c, out var form) && form.JoinsLeft;
        private static bool IsLeftToRightToken(char c) => char.IsDigit(c) || (c >= 'A' && c <= 'z') || c == '/' || c == ':' || c == '%' || c == '+' || c == '-' || c == '.';

        private static void FlushLtrRun(StringBuilder result, StringBuilder run)
        {
            if (run.Length == 0) return;
            for (var i = run.Length - 1; i >= 0; i--) result.Append(run[i]);
            run.Clear();
        }

        private static char Mirror(char c)
        {
            if (c == '(') return ')';
            if (c == ')') return '(';
            if (c == '[') return ']';
            if (c == ']') return '[';
            return c;
        }
    }
}
