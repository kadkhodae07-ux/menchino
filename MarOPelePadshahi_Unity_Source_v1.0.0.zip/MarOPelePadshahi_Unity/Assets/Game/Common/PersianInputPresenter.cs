using TMPro;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.Common
{
    /// <summary>
    /// Keeps TMP_InputField's backing value untouched while presenting a shaped Persian string.
    /// The shaped and raw strings have the same character count, so selection and limits remain stable.
    /// </summary>
    public sealed class PersianInputPresenter : MonoBehaviour
    {
        private TMP_InputField _input;
        private string _lastRaw = string.Empty;
        private string _lastVisible = string.Empty;

        public void Bind(TMP_InputField input)
        {
            _input = input;
            _lastRaw = string.Empty;
            _lastVisible = string.Empty;
            Refresh();
        }

        private void LateUpdate()
        {
            Refresh();
        }

        private void Refresh()
        {
            if (_input == null || _input.textComponent == null) return;
            var raw = _input.text ?? string.Empty;
            var shaped = PersianTextShaper.Shape(raw);
            if (raw == _lastRaw && shaped == _lastVisible && _input.textComponent.text == shaped) return;
            _lastRaw = raw;
            _lastVisible = shaped;
            _input.textComponent.isRightToLeftText = false;
            _input.textComponent.text = shaped;
        }
    }
}
