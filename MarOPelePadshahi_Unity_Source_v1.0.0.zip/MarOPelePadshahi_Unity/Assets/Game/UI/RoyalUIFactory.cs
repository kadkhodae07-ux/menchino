using System;
using Menchino.RoyalSnakesLadders.Common;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    public sealed class RoyalUIFactory
    {
        private readonly RoyalThemeAsset _theme;
        private readonly IAudioService _audio;

        public RoyalUIFactory(RoyalThemeAsset theme, IAudioService audio)
        {
            _theme = theme;
            _audio = audio;
        }

        public RoyalThemeAsset Theme => _theme;

        public GameObject Rect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return go;
        }

        public RectTransform FullRect(string name, Transform parent)
        {
            var rect = Rect(name, parent).GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            return rect;
        }

        public Image Image(string name, Transform parent, Color color, Sprite sprite = null)
        {
            var go = Rect(name, parent);
            var image = go.AddComponent<Image>();
            image.color = color;
            image.sprite = sprite ?? RoyalSpriteCache.Solid(Color.white);
            image.type = Image.Type.Sliced;
            return image;
        }

        public Image Panel(string name, Transform parent, Color? top = null, Color? bottom = null, Color? border = null, int radius = 18, int borderWidth = 4)
        {
            var image = Image(name, parent, Color.white, RoyalSpriteCache.Rounded(
                top ?? _theme.royalBlue,
                bottom ?? _theme.navy,
                border ?? _theme.gold,
                radius,
                borderWidth));
            image.type = Image.Type.Sliced;
            return image;
        }

        public TMP_Text Text(string name, Transform parent, string content, float size, Color color, TextAlignmentOptions alignment = TextAlignmentOptions.Center, FontStyles style = FontStyles.Normal)
        {
            var go = Rect(name, parent);
            var text = go.AddComponent<TextMeshProUGUI>();
            text.font = RoyalFontProvider.Get();
            text.fontSize = size;
            text.color = color;
            text.alignment = alignment;
            text.fontStyle = style;
            text.enableWordWrapping = true;
            text.overflowMode = TextOverflowModes.Ellipsis;
            text.raycastTarget = false;
            SetText(text, content);
            return text;
        }

        public void SetText(TMP_Text text, string content)
        {
            if (text == null) return;
            text.isRightToLeftText = false;
            text.text = PersianTextShaper.Shape(content ?? string.Empty);
        }

        public Button Button(string name, Transform parent, string label, UnityAction onClick, bool primary = true, bool danger = false)
        {
            var top = danger ? new Color32(188, 67, 58, 255) : primary ? _theme.gold : _theme.royalBlue;
            var bottom = danger ? new Color32(105, 30, 28, 255) : primary ? new Color32(190, 112, 15, 255) : _theme.navy;
            var border = danger ? _theme.lightGold : _theme.lightGold;
            var image = Panel(name, parent, top, bottom, border, 18, 4);
            var button = image.gameObject.AddComponent<Button>();
            button.targetGraphic = image;
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1.05f, 1.05f, 1.05f, 1f);
            colors.pressedColor = new Color(0.82f, 0.82f, 0.82f, 1f);
            colors.disabledColor = new Color(0.45f, 0.45f, 0.45f, 0.8f);
            colors.fadeDuration = 0.08f;
            button.colors = colors;
            if (onClick != null) button.onClick.AddListener(onClick);

            if (RoyalIconGraphic.CanRender(label))
            {
                var iconColor = primary ? new Color32(60, 37, 7, 255) : _theme.textPrimary;
                var icon = Icon("Icon", image.transform, label, iconColor);
                icon.rectTransform.anchorMin = new Vector2(0.26f, 0.20f);
                icon.rectTransform.anchorMax = new Vector2(0.74f, 0.80f);
                icon.rectTransform.offsetMin = Vector2.zero;
                icon.rectTransform.offsetMax = Vector2.zero;
            }
            else
            {
                var labelText = Text("Label", image.transform, label, primary ? _theme.headingSize : _theme.bodySize + 3f, primary ? new Color32(60, 37, 7, 255) : _theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
                var labelRect = labelText.rectTransform;
                labelRect.anchorMin = Vector2.zero;
                labelRect.anchorMax = Vector2.one;
                labelRect.offsetMin = new Vector2(10, 4);
                labelRect.offsetMax = new Vector2(-10, -4);
            }

            var royalButton = image.gameObject.AddComponent<RoyalButton>();
            royalButton.Initialize(_audio);
            var layout = image.gameObject.AddComponent<LayoutElement>();
            layout.preferredHeight = primary ? _theme.buttonHeight : _theme.smallButtonHeight;
            layout.minHeight = primary ? _theme.buttonHeight : _theme.smallButtonHeight;
            return button;
        }

        public RoyalIconGraphic Icon(string name, Transform parent, string iconKey, Color color)
        {
            var go = Rect(name, parent);
            var graphic = go.AddComponent<RoyalIconGraphic>();
            graphic.color = color;
            graphic.SetIcon(iconKey);
            graphic.raycastTarget = false;
            return graphic;
        }

        public GameObject IconBadge(string name, Transform parent, string symbol, Color color, float size = 58f)
        {
            var image = Panel(name, parent, color, Color.Lerp(color, Color.black, 0.45f), _theme.gold, 28, 4);
            var rect = image.rectTransform;
            rect.sizeDelta = new Vector2(size, size);
            var layout = image.gameObject.AddComponent<LayoutElement>();
            layout.preferredWidth = size;
            layout.preferredHeight = size;
            if (RoyalIconGraphic.CanRender(symbol))
            {
                var icon = Icon("Icon", image.transform, symbol, _theme.lightGold);
                icon.rectTransform.anchorMin = Vector2.zero;
                icon.rectTransform.anchorMax = Vector2.one;
                icon.rectTransform.offsetMin = new Vector2(size * 0.18f, size * 0.18f);
                icon.rectTransform.offsetMax = new Vector2(-size * 0.18f, -size * 0.18f);
            }
            else
            {
                var text = Text("Symbol", image.transform, symbol, size * 0.45f, _theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
                text.rectTransform.anchorMin = Vector2.zero;
                text.rectTransform.anchorMax = Vector2.one;
                text.rectTransform.offsetMin = Vector2.zero;
                text.rectTransform.offsetMax = Vector2.zero;
            }
            return image.gameObject;
        }

        public Slider Slider(string name, Transform parent, float value, UnityAction<float> onChanged)
        {
            var root = Rect(name, parent);
            var slider = root.AddComponent<Slider>();
            slider.minValue = 0f;
            slider.maxValue = 1f;
            slider.value = value;
            slider.direction = Slider.Direction.LeftToRight;
            var layout = root.AddComponent<LayoutElement>();
            layout.preferredHeight = 42f;

            var background = Panel("Background", root.transform, _theme.navy, _theme.navy, _theme.darkGold, 14, 3);
            background.rectTransform.anchorMin = new Vector2(0, 0.28f);
            background.rectTransform.anchorMax = new Vector2(1, 0.72f);
            background.rectTransform.offsetMin = Vector2.zero;
            background.rectTransform.offsetMax = Vector2.zero;

            var fillArea = FullRect("FillArea", root.transform);
            fillArea.offsetMin = new Vector2(7, 9);
            fillArea.offsetMax = new Vector2(-7, -9);
            var fill = Panel("Fill", fillArea, _theme.lightGold, _theme.gold, _theme.gold, 11, 0);
            fill.rectTransform.anchorMin = Vector2.zero;
            fill.rectTransform.anchorMax = Vector2.one;
            fill.rectTransform.offsetMin = Vector2.zero;
            fill.rectTransform.offsetMax = Vector2.zero;

            var handleArea = FullRect("HandleArea", root.transform);
            handleArea.offsetMin = new Vector2(10, 0);
            handleArea.offsetMax = new Vector2(-10, 0);
            var handle = Panel("Handle", handleArea, _theme.lightGold, _theme.gold, _theme.darkGold, 20, 3);
            handle.rectTransform.sizeDelta = new Vector2(34, 34);

            slider.fillRect = fill.rectTransform;
            slider.handleRect = handle.rectTransform;
            slider.targetGraphic = handle;
            if (onChanged != null) slider.onValueChanged.AddListener(onChanged);
            return slider;
        }

        public Toggle Toggle(string name, Transform parent, bool value, UnityAction<bool> onChanged)
        {
            var root = Rect(name, parent);
            var toggle = root.AddComponent<Toggle>();
            toggle.isOn = value;
            var layout = root.AddComponent<LayoutElement>();
            layout.preferredWidth = 82f;
            layout.preferredHeight = 42f;

            var track = Panel("Track", root.transform, value ? _theme.success : _theme.disabled, value ? new Color32(30, 110, 55, 255) : new Color32(48, 58, 70, 255), _theme.gold, 18, 3);
            track.rectTransform.anchorMin = Vector2.zero;
            track.rectTransform.anchorMax = Vector2.one;
            track.rectTransform.offsetMin = Vector2.zero;
            track.rectTransform.offsetMax = Vector2.zero;
            var knob = Panel("Knob", root.transform, _theme.textPrimary, _theme.lightGold, _theme.darkGold, 18, 2);
            knob.rectTransform.anchorMin = new Vector2(value ? 0.53f : 0.03f, 0.08f);
            knob.rectTransform.anchorMax = new Vector2(value ? 0.97f : 0.47f, 0.92f);
            knob.rectTransform.offsetMin = Vector2.zero;
            knob.rectTransform.offsetMax = Vector2.zero;

            toggle.targetGraphic = track;
            toggle.graphic = null;
            toggle.onValueChanged.AddListener(isOn =>
            {
                track.sprite = RoyalSpriteCache.Rounded(isOn ? _theme.success : _theme.disabled, isOn ? new Color32(30, 110, 55, 255) : new Color32(48, 58, 70, 255), _theme.gold, 18, 3);
                knob.rectTransform.anchorMin = new Vector2(isOn ? 0.53f : 0.03f, 0.08f);
                knob.rectTransform.anchorMax = new Vector2(isOn ? 0.97f : 0.47f, 0.92f);
                onChanged?.Invoke(isOn);
            });
            return toggle;
        }

        public Image Progress(string name, Transform parent, float value, Color? fillColor = null)
        {
            var background = Panel(name, parent, _theme.navy, new Color32(2, 13, 30, 255), _theme.darkGold, 14, 3);
            var layout = background.gameObject.AddComponent<LayoutElement>();
            layout.preferredHeight = 30f;
            var fill = Panel("Fill", background.transform, fillColor ?? _theme.lightGold, fillColor ?? _theme.gold, _theme.gold, 11, 1);
            fill.rectTransform.anchorMin = Vector2.zero;
            fill.rectTransform.anchorMax = new Vector2(Mathf.Clamp01(value), 1f);
            fill.rectTransform.offsetMin = new Vector2(4, 4);
            fill.rectTransform.offsetMax = new Vector2(-4, -4);
            return fill;
        }

        public VerticalLayoutGroup Vertical(Transform parent, float spacing = 12f, RectOffset padding = null, TextAnchor alignment = TextAnchor.UpperCenter)
        {
            var layout = parent.gameObject.AddComponent<VerticalLayoutGroup>();
            layout.spacing = spacing;
            layout.padding = padding ?? new RectOffset(16, 16, 16, 16);
            layout.childAlignment = alignment;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;
            return layout;
        }

        public HorizontalLayoutGroup Horizontal(Transform parent, float spacing = 10f, RectOffset padding = null, TextAnchor alignment = TextAnchor.MiddleCenter)
        {
            var layout = parent.gameObject.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = spacing;
            layout.padding = padding ?? new RectOffset(8, 8, 8, 8);
            layout.childAlignment = alignment;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;
            return layout;
        }

        public ScrollRect ScrollView(string name, Transform parent, out RectTransform content)
        {
            var viewportImage = Panel(name, parent, new Color32(4, 27, 58, 240), new Color32(2, 15, 37, 240), _theme.darkGold, 20, 3);
            var scroll = viewportImage.gameObject.AddComponent<ScrollRect>();
            var mask = viewportImage.gameObject.AddComponent<RectMask2D>();
            mask.padding = new Vector4(4, 4, 4, 4);
            content = Rect("Content", viewportImage.transform).GetComponent<RectTransform>();
            content.anchorMin = new Vector2(0, 1);
            content.anchorMax = new Vector2(1, 1);
            content.pivot = new Vector2(0.5f, 1);
            content.offsetMin = Vector2.zero;
            content.offsetMax = Vector2.zero;
            content.sizeDelta = Vector2.zero;
            var fitter = content.gameObject.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            scroll.viewport = viewportImage.rectTransform;
            scroll.content = content;
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.movementType = ScrollRect.MovementType.Elastic;
            scroll.scrollSensitivity = 36f;
            return scroll;
        }

        public void SetAnchors(RectTransform rect, Vector2 min, Vector2 max, Vector2 offsetMin, Vector2 offsetMax)
        {
            rect.anchorMin = min;
            rect.anchorMax = max;
            rect.offsetMin = offsetMin;
            rect.offsetMax = offsetMax;
        }
    }
}
