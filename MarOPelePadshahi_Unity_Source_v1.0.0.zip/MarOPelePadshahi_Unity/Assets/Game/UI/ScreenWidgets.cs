using System;
using Menchino.RoyalSnakesLadders.Common;
using Menchino.RoyalSnakesLadders.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    public static class ScreenWidgets
    {
        public static RectTransform MainColumn(RoyalGameApp app, RectTransform page, float spacing = 16f, int padding = 8)
        {
            var column = app.UI.Rect("MainColumn", page).GetComponent<RectTransform>();
            column.anchorMin = Vector2.zero;
            column.anchorMax = Vector2.one;
            column.offsetMin = Vector2.zero;
            column.offsetMax = Vector2.zero;
            app.UI.Vertical(column, spacing, new RectOffset(padding, padding, padding, padding), TextAnchor.UpperCenter);
            return column;
        }

        public static GameObject InfoCard(RoyalGameApp app, Transform parent, string icon, string title, string subtitle, Color accent, Action action = null, float height = 150f)
        {
            var ui = app.UI;
            var panel = ui.Panel("InfoCard", parent, Color.Lerp(accent, ui.Theme.royalBlue, 0.55f), Color.Lerp(accent, ui.Theme.navy, 0.72f), ui.Theme.gold, 22, 4);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = height;
            var row = ui.Horizontal(panel.transform, 14, new RectOffset(18, 18, 14, 14), TextAnchor.MiddleCenter);
            row.childForceExpandWidth = false;
            ui.IconBadge("Icon", panel.transform, icon, accent, 82);
            var texts = ui.Rect("Texts", panel.transform);
            var textLayout = ui.Vertical(texts.transform, 4, new RectOffset(6, 6, 6, 6), TextAnchor.MiddleRight);
            textLayout.childAlignment = TextAnchor.MiddleRight;
            texts.AddComponent<LayoutElement>().flexibleWidth = 1;
            var titleText = ui.Text("Title", texts.transform, title, 32, ui.Theme.lightGold, TextAlignmentOptions.Right, FontStyles.Bold);
            titleText.gameObject.AddComponent<LayoutElement>().preferredHeight = 52;
            var subtitleText = ui.Text("Subtitle", texts.transform, subtitle, 22, ui.Theme.textSecondary, TextAlignmentOptions.Right);
            subtitleText.gameObject.AddComponent<LayoutElement>().preferredHeight = 55;
            if (action != null)
            {
                var button = panel.gameObject.AddComponent<Button>();
                button.targetGraphic = panel;
                button.onClick.AddListener(() => action());
                var royal = panel.gameObject.AddComponent<RoyalButton>();
                royal.Initialize(app.Services.Resolve<Menchino.RoyalSnakesLadders.Services.IAudioService>());
            }
            return panel.gameObject;
        }

        public static GameObject StatTile(RoyalGameApp app, Transform parent, string icon, string label, string value, Color accent)
        {
            var ui = app.UI;
            var panel = ui.Panel("StatTile", parent, Color.Lerp(accent, ui.Theme.royalBlue, 0.75f), ui.Theme.navy, ui.Theme.darkGold, 18, 3);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 120;
            var layout = ui.Horizontal(panel.transform, 8, new RectOffset(10, 10, 8, 8), TextAnchor.MiddleCenter);
            layout.childForceExpandWidth = false;
            ui.IconBadge("Icon", panel.transform, icon, accent, 58);
            var textRoot = ui.Rect("Texts", panel.transform);
            textRoot.AddComponent<LayoutElement>().flexibleWidth = 1;
            ui.Vertical(textRoot.transform, 0, new RectOffset(2, 2, 2, 2), TextAnchor.MiddleRight);
            var labelText = ui.Text("Label", textRoot.transform, label, 20, ui.Theme.textSecondary, TextAlignmentOptions.Right);
            labelText.gameObject.AddComponent<LayoutElement>().preferredHeight = 38;
            var valueText = ui.Text("Value", textRoot.transform, value, 31, ui.Theme.lightGold, TextAlignmentOptions.Right, FontStyles.Bold);
            valueText.gameObject.AddComponent<LayoutElement>().preferredHeight = 50;
            return panel.gameObject;
        }

        public static GameObject SectionTitle(RoyalGameApp app, Transform parent, string title)
        {
            var text = app.UI.Text("SectionTitle", parent, title, 31, app.UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            var layout = text.gameObject.AddComponent<LayoutElement>();
            layout.preferredHeight = 56;
            return text.gameObject;
        }

        public static GameObject ListRow(RoyalGameApp app, Transform parent, string icon, string title, string subtitle, string trailing, Color accent, Action action = null, float height = 94f)
        {
            var ui = app.UI;
            var panel = ui.Panel("ListRow", parent, new Color32(10, 54, 91, 248), new Color32(3, 24, 51, 248), ui.Theme.darkGold, 16, 2);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = height;
            var row = ui.Horizontal(panel.transform, 12, new RectOffset(12, 12, 8, 8), TextAnchor.MiddleCenter);
            row.childForceExpandWidth = false;
            ui.IconBadge("Icon", panel.transform, icon, accent, 58);
            var texts = ui.Rect("Texts", panel.transform);
            texts.AddComponent<LayoutElement>().flexibleWidth = 1;
            ui.Vertical(texts.transform, 1, new RectOffset(2, 2, 2, 2), TextAnchor.MiddleRight);
            var titleText = ui.Text("Title", texts.transform, title, 25, ui.Theme.textPrimary, TextAlignmentOptions.Right, FontStyles.Bold);
            titleText.gameObject.AddComponent<LayoutElement>().preferredHeight = 38;
            var subText = ui.Text("Subtitle", texts.transform, subtitle, 19, ui.Theme.textSecondary, TextAlignmentOptions.Right);
            subText.gameObject.AddComponent<LayoutElement>().preferredHeight = 30;
            var trailingText = ui.Text("Trailing", panel.transform, trailing, 23, ui.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            trailingText.gameObject.AddComponent<LayoutElement>().preferredWidth = 120;
            trailingText.gameObject.GetComponent<LayoutElement>().flexibleWidth = 0;
            if (action != null)
            {
                var button = panel.gameObject.AddComponent<Button>();
                button.targetGraphic = panel;
                button.onClick.AddListener(() => action());
                var royal = panel.gameObject.AddComponent<RoyalButton>();
                royal.Initialize(app.Services.Resolve<Menchino.RoyalSnakesLadders.Services.IAudioService>());
            }
            return panel.gameObject;
        }

        public static TMP_InputField Input(RoyalGameApp app, Transform parent, string placeholder, string initial = "", bool numeric = false)
        {
            var ui = app.UI;
            var panel = ui.Panel("Input", parent, new Color32(7, 44, 79, 255), new Color32(2, 20, 44, 255), ui.Theme.darkGold, 16, 3);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 66;
            var input = panel.gameObject.AddComponent<TMP_InputField>();
            var text = ui.Text("Text", panel.transform, initial, 25, ui.Theme.textPrimary, TextAlignmentOptions.Right);
            text.rectTransform.anchorMin = Vector2.zero;
            text.rectTransform.anchorMax = Vector2.one;
            text.rectTransform.offsetMin = new Vector2(18, 8);
            text.rectTransform.offsetMax = new Vector2(-18, -8);
            var placeholderText = ui.Text("Placeholder", panel.transform, placeholder, 24, new Color(ui.Theme.textSecondary.r, ui.Theme.textSecondary.g, ui.Theme.textSecondary.b, 0.55f), TextAlignmentOptions.Right);
            placeholderText.rectTransform.anchorMin = Vector2.zero;
            placeholderText.rectTransform.anchorMax = Vector2.one;
            placeholderText.rectTransform.offsetMin = new Vector2(18, 8);
            placeholderText.rectTransform.offsetMax = new Vector2(-18, -8);
            input.textComponent = text;
            input.placeholder = placeholderText;
            input.text = initial;
            input.contentType = numeric ? TMP_InputField.ContentType.IntegerNumber : TMP_InputField.ContentType.Standard;
            input.characterLimit = numeric ? 6 : 18;
            input.targetGraphic = panel;
            var presenter = panel.gameObject.AddComponent<PersianInputPresenter>();
            presenter.Bind(input);
            return input;
        }

        public static GameObject SettingRow(RoyalGameApp app, Transform parent, string icon, string title, string subtitle, bool value, Action<bool> changed)
        {
            var ui = app.UI;
            var panel = ui.Panel("SettingRow", parent, new Color32(9, 52, 88, 250), new Color32(3, 23, 49, 250), ui.Theme.darkGold, 16, 2);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 92;
            var row = ui.Horizontal(panel.transform, 12, new RectOffset(12, 12, 8, 8), TextAnchor.MiddleCenter);
            row.childForceExpandWidth = false;
            ui.IconBadge("Icon", panel.transform, icon, ui.Theme.royalBlue, 58);
            var texts = ui.Rect("Texts", panel.transform);
            texts.AddComponent<LayoutElement>().flexibleWidth = 1;
            ui.Vertical(texts.transform, 0, new RectOffset(2, 2, 2, 2), TextAnchor.MiddleRight);
            var titleText = ui.Text("Title", texts.transform, title, 24, ui.Theme.textPrimary, TextAlignmentOptions.Right, FontStyles.Bold);
            titleText.gameObject.AddComponent<LayoutElement>().preferredHeight = 38;
            var subText = ui.Text("Subtitle", texts.transform, subtitle, 18, ui.Theme.textSecondary, TextAlignmentOptions.Right);
            subText.gameObject.AddComponent<LayoutElement>().preferredHeight = 28;
            ui.Toggle("Toggle", panel.transform, value, v => changed?.Invoke(v));
            return panel.gameObject;
        }
    }
}
