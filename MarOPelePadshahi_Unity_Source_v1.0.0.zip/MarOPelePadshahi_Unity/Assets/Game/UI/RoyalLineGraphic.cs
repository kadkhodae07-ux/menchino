using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    public sealed class RoyalLineGraphic : MaskableGraphic
    {
        public List<Vector2> points = new List<Vector2>();
        public float thickness = 8f;

        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();
            if (points == null || points.Count < 2) return;
            var rect = rectTransform.rect;
            for (var i = 0; i < points.Count - 1; i++)
            {
                var a = new Vector2(rect.xMin + points[i].x * rect.width, rect.yMin + points[i].y * rect.height);
                var b = new Vector2(rect.xMin + points[i + 1].x * rect.width, rect.yMin + points[i + 1].y * rect.height);
                var direction = (b - a).normalized;
                var normal = new Vector2(-direction.y, direction.x) * thickness * 0.5f;
                var index = vh.currentVertCount;
                vh.AddVert(a - normal, color, Vector2.zero);
                vh.AddVert(a + normal, color, Vector2.up);
                vh.AddVert(b + normal, color, Vector2.one);
                vh.AddVert(b - normal, color, Vector2.right);
                vh.AddTriangle(index, index + 1, index + 2);
                vh.AddTriangle(index, index + 2, index + 3);
            }
        }

        public void SetPoints(IEnumerable<Vector2> value)
        {
            points.Clear();
            points.AddRange(value);
            SetVerticesDirty();
        }
    }
}
