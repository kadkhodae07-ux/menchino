using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    public static class RoyalChrome
    {
        public static void BuildTopStatusBar(RoyalGameApp app, Transform parent)
        {
            var ui = app.UI;
            var profile = app.Services.Resolve<IProfileService>();
            var bar = ui.Rect("TopStatusBar", parent).GetComponent<RectTransform>();
            bar.anchorMin = new Vector2(0, 1);
            bar.anchorMax = new Vector2(1, 1);
            bar.pivot = new Vector2(0.5f, 1);
            bar.sizeDelta = new Vector2(0, 132);
            bar.anchoredPosition = Vector2.zero;
            ui.Horizontal(bar, 12, new RectOffset(20, 20, 12, 12), TextAnchor.MiddleCenter);

            var settings = ui.Button("Settings", bar, "⚙", () => app.Navigation.Navigate(AppRoute.Settings), false);
            settings.GetComponent<LayoutElement>().preferredWidth = 78;
            settings.GetComponent<LayoutElement>().flexibleWidth = 0;

            var walletPanel = ui.Panel("Wallet", bar, new Color32(9, 67, 115, 250), new Color32(3, 25, 55, 250), ui.Theme.gold, 20, 4);
            var walletLayout = walletPanel.gameObject.AddComponent<HorizontalLayoutGroup>();
            walletLayout.padding = new RectOffset(16, 12, 8, 8);
            walletLayout.spacing = 8;
            walletLayout.childAlignment = TextAnchor.MiddleCenter;
            walletLayout.childControlHeight = true;
            walletLayout.childControlWidth = true;
            walletLayout.childForceExpandWidth = false;
            walletLayout.childForceExpandHeight = true;
            var walletElement = walletPanel.gameObject.AddComponent<LayoutElement>();
            walletElement.preferredWidth = 260;
            walletElement.flexibleWidth = 0;
            ui.IconBadge("Coin", walletPanel.transform, "♛", new Color32(190, 114, 11, 255), 54);
            var coinText = ui.Text("Coins", walletPanel.transform, profile.Wallet.coins.ToString("N0"), 28, ui.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            coinText.gameObject.AddComponent<LayoutElement>().preferredWidth = 120;
            var add = ui.Button("Add", walletPanel.transform, "+", () => app.Navigation.Navigate(AppRoute.Shop), false);
            add.GetComponent<LayoutElement>().preferredWidth = 52;
            add.GetComponent<LayoutElement>().flexibleWidth = 0;

            var level = ui.Panel("Level", bar, new Color32(12, 79, 139, 255), new Color32(2, 29, 68, 255), ui.Theme.gold, 24, 5);
            level.gameObject.AddComponent<LayoutElement>().preferredWidth = 105;
            level.gameObject.GetComponent<LayoutElement>().flexibleWidth = 0;
            var levelText = ui.Text("LevelText", level.transform, profile.Profile.level.ToString(), 38, ui.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            levelText.rectTransform.anchorMin = Vector2.zero;
            levelText.rectTransform.anchorMax = Vector2.one;
            levelText.rectTransform.offsetMin = Vector2.zero;
            levelText.rectTransform.offsetMax = Vector2.zero;

            var name = ui.Text("Name", bar, profile.Profile.displayName, 31, ui.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            name.gameObject.AddComponent<LayoutElement>().preferredWidth = 170;

            var avatar = ui.Panel("Avatar", bar, new Color32(20, 83, 126, 255), new Color32(3, 27, 57, 255), ui.Theme.gold, 34, 5);
            avatar.gameObject.AddComponent<LayoutElement>().preferredWidth = 88;
            avatar.gameObject.GetComponent<LayoutElement>().flexibleWidth = 0;
            var avatarText = ui.Text("AvatarIcon", avatar.transform, "♔", 46, ui.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            avatarText.rectTransform.anchorMin = Vector2.zero;
            avatarText.rectTransform.anchorMax = Vector2.one;
            avatarText.rectTransform.offsetMin = Vector2.zero;
            avatarText.rectTransform.offsetMax = Vector2.zero;
        }

        public static void BuildBottomNavigation(RoyalGameApp app, Transform parent, AppRoute active)
        {
            var ui = app.UI;
            var nav = ui.Panel("BottomNavigation", parent, new Color32(7, 48, 86, 252), new Color32(2, 19, 43, 252), ui.Theme.gold, 26, 5);
            var rect = nav.rectTransform;
            rect.anchorMin = new Vector2(0, 0);
            rect.anchorMax = new Vector2(1, 0);
            rect.pivot = new Vector2(0.5f, 0);
            rect.sizeDelta = new Vector2(-24, 142);
            rect.anchoredPosition = new Vector2(0, 6);
            var layout = ui.Horizontal(nav.transform, 8, new RectOffset(18, 18, 12, 10), TextAnchor.MiddleCenter);
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            BuildNavItem(app, nav.transform, "♜", "فروشگاه", AppRoute.Shop, active == AppRoute.Shop, false);
            BuildNavItem(app, nav.transform, "⌂", "خانه", AppRoute.Home, active == AppRoute.Home, true);
            BuildNavItem(app, nav.transform, "♙", "پروفایل", AppRoute.Profile, active == AppRoute.Profile, false);
        }

        private static void BuildNavItem(RoyalGameApp app, Transform parent, string icon, string label, AppRoute route, bool active, bool elevated)
        {
            var ui = app.UI;
            var button = ui.Button("Nav_" + route, parent, string.Empty, () => app.Navigation.Reset(route), false);
            var element = button.GetComponent<LayoutElement>();
            element.preferredHeight = elevated ? 122 : 102;
            var rect = button.GetComponent<RectTransform>();
            if (elevated) rect.anchoredPosition = new Vector2(0, 14);
            button.image.sprite = RoyalSpriteCache.Rounded(
                active || elevated ? new Color32(0, 165, 190, 255) : new Color32(10, 64, 105, 255),
                active || elevated ? new Color32(0, 76, 108, 255) : new Color32(3, 28, 57, 255),
                ui.Theme.gold,
                elevated ? 28 : 20,
                active ? 6 : 4);

            var iconGraphic = ui.Icon("Icon", button.transform, icon, ui.Theme.lightGold);
            iconGraphic.rectTransform.anchorMin = new Vector2(0.30f, 0.40f);
            iconGraphic.rectTransform.anchorMax = new Vector2(0.70f, 0.92f);
            iconGraphic.rectTransform.offsetMin = Vector2.zero;
            iconGraphic.rectTransform.offsetMax = Vector2.zero;
            var labelText = ui.Text("Text", button.transform, label, elevated ? 27 : 24, ui.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            labelText.rectTransform.anchorMin = new Vector2(0, 0);
            labelText.rectTransform.anchorMax = new Vector2(1, 0.38f);
            labelText.rectTransform.offsetMin = Vector2.zero;
            labelText.rectTransform.offsetMax = Vector2.zero;
        }

        public static RectTransform BuildHeader(RoyalGameApp app, Transform parent, string title, bool back = true)
        {
            var ui = app.UI;
            var row = ui.Rect("HeaderRow", parent).GetComponent<RectTransform>();
            var layout = ui.Horizontal(row, 12, new RectOffset(0, 0, 0, 0), TextAnchor.MiddleCenter);
            layout.childForceExpandHeight = true;
            row.gameObject.AddComponent<LayoutElement>().preferredHeight = 94;

            if (back)
            {
                var backButton = ui.Button("Back", row, "←", app.Navigation.HandleBack, false);
                backButton.GetComponent<LayoutElement>().preferredWidth = 82;
                backButton.GetComponent<LayoutElement>().flexibleWidth = 0;
            }
            else
            {
                var spacer = ui.Rect("Spacer", row);
                spacer.AddComponent<LayoutElement>().preferredWidth = 82;
                spacer.GetComponent<LayoutElement>().flexibleWidth = 0;
            }

            var banner = ui.Panel("TitleBanner", row, new Color32(10, 73, 123, 255), new Color32(2, 30, 65, 255), ui.Theme.gold, 22, 5);
            banner.gameObject.AddComponent<LayoutElement>().preferredHeight = 86;
            var titleText = ui.Text("Title", banner.transform, title, ui.Theme.titleSize, ui.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            titleText.rectTransform.anchorMin = Vector2.zero;
            titleText.rectTransform.anchorMax = Vector2.one;
            titleText.rectTransform.offsetMin = new Vector2(10, 2);
            titleText.rectTransform.offsetMax = new Vector2(-10, -2);

            var rightSpacer = ui.Rect("RightSpacer", row);
            rightSpacer.AddComponent<LayoutElement>().preferredWidth = 82;
            rightSpacer.GetComponent<LayoutElement>().flexibleWidth = 0;
            return row;
        }
    }
}
