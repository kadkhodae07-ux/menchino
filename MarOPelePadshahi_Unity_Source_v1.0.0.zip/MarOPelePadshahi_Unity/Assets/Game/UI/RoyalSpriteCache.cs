using System.Collections.Generic;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.UI
{
    public static class RoyalSpriteCache
    {
        private static readonly Dictionary<string, Sprite> Cache = new Dictionary<string, Sprite>();

        public static Sprite Rounded(Color top, Color bottom, Color border, int radius = 18, int borderWidth = 4)
        {
            var key = $"{ColorUtility.ToHtmlStringRGBA(top)}_{ColorUtility.ToHtmlStringRGBA(bottom)}_{ColorUtility.ToHtmlStringRGBA(border)}_{radius}_{borderWidth}";
            if (Cache.TryGetValue(key, out var sprite) && sprite != null) return sprite;

            const int size = 64;
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false)
            {
                name = "RoyalRoundedTexture",
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear
            };
            var pixels = new Color32[size * size];
            for (var y = 0; y < size; y++)
            {
                var t = y / (float)(size - 1);
                var fill = Color.Lerp(bottom, top, t);
                for (var x = 0; x < size; x++)
                {
                    var distance = RoundedDistance(x, y, size, radius);
                    var index = y * size + x;
                    if (distance > 0f)
                    {
                        pixels[index] = new Color32(0, 0, 0, 0);
                    }
                    else if (distance > -borderWidth)
                    {
                        pixels[index] = border;
                    }
                    else
                    {
                        pixels[index] = fill;
                    }
                }
            }
            texture.SetPixels32(pixels);
            texture.Apply(false, true);
            sprite = Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(radius, radius, radius, radius));
            sprite.name = "RoyalRoundedSprite";
            Cache[key] = sprite;
            return sprite;
        }

        public static Sprite Solid(Color color)
        {
            var key = "solid_" + ColorUtility.ToHtmlStringRGBA(color);
            if (Cache.TryGetValue(key, out var sprite) && sprite != null) return sprite;
            var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false)
            {
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear
            };
            texture.SetPixels(new[] { color, color, color, color });
            texture.Apply(false, true);
            sprite = Sprite.Create(texture, new Rect(0, 0, 2, 2), new Vector2(0.5f, 0.5f), 100f);
            Cache[key] = sprite;
            return sprite;
        }

        private static float RoundedDistance(int x, int y, int size, int radius)
        {
            var px = Mathf.Min(x, size - 1 - x);
            var py = Mathf.Min(y, size - 1 - y);
            if (px >= radius || py >= radius) return -Mathf.Min(px, py);
            var dx = radius - px;
            var dy = radius - py;
            return Mathf.Sqrt(dx * dx + dy * dy) - radius;
        }
    }
}
