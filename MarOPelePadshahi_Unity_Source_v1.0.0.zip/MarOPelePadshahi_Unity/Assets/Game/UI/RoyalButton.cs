using System.Collections;
using Menchino.RoyalSnakesLadders.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    [RequireComponent(typeof(Button))]
    public sealed class RoyalButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        private Vector3 _baseScale;
        private Coroutine _scaleRoutine;
        private Button _button;
        private IAudioService _audio;

        public void Initialize(IAudioService audio)
        {
            _audio = audio;
            _button = GetComponent<Button>();
            _button.onClick.AddListener(() => _audio?.PlayClick());
        }

        private void Awake()
        {
            _baseScale = transform.localScale;
            _button = GetComponent<Button>();
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (_button != null && !_button.interactable) return;
            AnimateTo(_baseScale * 0.96f, 0.08f);
        }

        public void OnPointerUp(PointerEventData eventData) => AnimateTo(_baseScale, 0.10f);
        public void OnPointerExit(PointerEventData eventData) => AnimateTo(_baseScale, 0.10f);

        private void AnimateTo(Vector3 target, float duration)
        {
            if (_scaleRoutine != null) StopCoroutine(_scaleRoutine);
            _scaleRoutine = StartCoroutine(ScaleRoutine(target, duration));
        }

        private IEnumerator ScaleRoutine(Vector3 target, float duration)
        {
            var start = transform.localScale;
            var elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                transform.localScale = Vector3.Lerp(start, target, Mathf.Clamp01(elapsed / duration));
                yield return null;
            }
            transform.localScale = target;
            _scaleRoutine = null;
        }
    }
}
