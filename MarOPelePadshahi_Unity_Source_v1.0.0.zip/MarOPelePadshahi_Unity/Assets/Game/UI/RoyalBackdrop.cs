using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    public static class RoyalBackdrop
    {
        public static void Build(RoyalUIFactory ui, RectTransform root)
        {
            var background = ui.Image("NightGradient", root, Color.white, RoyalSpriteCache.Rounded(new Color32(5, 35, 75, 255), new Color32(1, 9, 27, 255), new Color32(1, 9, 27, 255), 0, 0));
            background.rectTransform.anchorMin = Vector2.zero;
            background.rectTransform.anchorMax = Vector2.one;
            background.rectTransform.offsetMin = Vector2.zero;
            background.rectTransform.offsetMax = Vector2.zero;

            var random = new System.Random(3319);
            for (var i = 0; i < 42; i++)
            {
                var star = ui.Image("Star", root, new Color(1f, 0.9f, 0.55f, (float)(0.25 + random.NextDouble() * 0.65)), RoyalSpriteCache.Solid(Color.white));
                var rect = star.rectTransform;
                var size = random.Next(2, 7);
                rect.anchorMin = rect.anchorMax = new Vector2((float)random.NextDouble(), (float)(0.28 + random.NextDouble() * 0.72));
                rect.sizeDelta = new Vector2(size, size);
                rect.anchoredPosition = Vector2.zero;
            }

            BuildCastle(ui, root, true);
            BuildCastle(ui, root, false);
            var glow = ui.Image("BottomGlow", root, new Color(0f, 0.35f, 0.52f, 0.22f), RoyalSpriteCache.Rounded(new Color(0f, 0.5f, 0.7f, 0.4f), Color.clear, Color.clear, 30, 0));
            glow.rectTransform.anchorMin = new Vector2(0, 0);
            glow.rectTransform.anchorMax = new Vector2(1, 0.28f);
            glow.rectTransform.offsetMin = new Vector2(-40, -50);
            glow.rectTransform.offsetMax = new Vector2(40, 0);
        }

        private static void BuildCastle(RoyalUIFactory ui, Transform root, bool left)
        {
            var group = ui.Rect(left ? "CastleLeft" : "CastleRight", root).GetComponent<RectTransform>();
            group.anchorMin = group.anchorMax = new Vector2(left ? 0.05f : 0.95f, 0.48f);
            group.sizeDelta = new Vector2(220, 760);
            group.anchoredPosition = new Vector2(left ? 15 : -15, 0);
            group.localScale = new Vector3(left ? 1 : -1, 1, 1);

            for (var i = 0; i < 4; i++)
            {
                var tower = ui.Panel("Tower", group, new Color32(8, 31, 68, 210), new Color32(2, 12, 31, 235), new Color32(20, 73, 125, 120), 10, 2);
                var rect = tower.rectTransform;
                rect.anchorMin = rect.anchorMax = new Vector2(0.15f + i * 0.2f, 0.15f + i * 0.05f);
                rect.sizeDelta = new Vector2(58 - i * 4, 300 + i * 85);
                var roof = ui.Image("Roof", tower.transform, new Color32(5, 18, 45, 240), RoyalSpriteCache.Solid(Color.white));
                roof.rectTransform.anchorMin = roof.rectTransform.anchorMax = new Vector2(0.5f, 1f);
                roof.rectTransform.sizeDelta = new Vector2(45, 45);
                roof.rectTransform.anchoredPosition = new Vector2(0, 12);
                roof.rectTransform.localRotation = Quaternion.Euler(0, 0, 45);
                for (var w = 0; w < 4; w++)
                {
                    var window = ui.Image("Window", tower.transform, new Color(1f, 0.62f, 0.18f, 0.55f), RoyalSpriteCache.Rounded(Color.yellow, new Color(1f, 0.35f, 0f, 1f), Color.clear, 5, 0));
                    window.rectTransform.anchorMin = window.rectTransform.anchorMax = new Vector2(0.5f, 0.2f + w * 0.18f);
                    window.rectTransform.sizeDelta = new Vector2(9, 17);
                }
            }
        }
    }
}
