using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using UnityEngine;

namespace Menchino.RoyalSnakesLadders.UI
{
    public abstract class RoyalScreenBase : MonoBehaviour
    {
        protected RoyalGameApp App { get; private set; }
        protected RoyalUIFactory UI => App.UI;
        protected RoyalServiceRegistry Services => App.Services;
        protected RectTransform Root { get; private set; }
        private bool _initialized;

        public abstract AppRoute Route { get; }
        public virtual bool ShowBottomNavigation => false;
        public virtual bool ShowTopStatusBar => false;

        public void Initialize(RoyalGameApp app)
        {
            if (_initialized) return;
            _initialized = true;
            App = app;
            Root = gameObject.GetComponent<RectTransform>() ?? gameObject.AddComponent<RectTransform>();
            Root.anchorMin = Vector2.zero;
            Root.anchorMax = Vector2.one;
            Root.offsetMin = Vector2.zero;
            Root.offsetMax = Vector2.zero;
            BuildScreen();
        }

        protected abstract void BuildScreen();

        protected RectTransform CreatePageRoot(bool scroll = false)
        {
            var page = UI.FullRect("Page", Root);
            var topInset = ShowTopStatusBar ? 140f : 20f;
            var bottomInset = ShowBottomNavigation ? 155f : 20f;
            page.offsetMin = new Vector2(24, bottomInset);
            page.offsetMax = new Vector2(-24, -topInset);
            if (ShowTopStatusBar) RoyalChrome.BuildTopStatusBar(App, Root);
            if (ShowBottomNavigation) RoyalChrome.BuildBottomNavigation(App, Root, Route);
            return page;
        }

        protected void Navigate(AppRoute route) => App.Navigation.Navigate(route);
        protected void Back() => App.Navigation.HandleBack();
        protected void Toast(string message) => RoyalPopupService.ShowToast(App, message);
        protected void Confirm(string title, string message, string primary, System.Action onPrimary, string secondary = "لغو")
            => RoyalPopupService.ShowConfirm(App, title, message, primary, onPrimary, secondary);

        protected T Get<T>() where T : class => Services.Resolve<T>();
    }
}
