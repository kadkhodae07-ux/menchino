using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class HomeScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Home;
        public override bool ShowBottomNavigation => true;
        public override bool ShowTopStatusBar => true;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 14, 4);
            var shortcuts = UI.Rect("Shortcuts", column);
            shortcuts.AddComponent<LayoutElement>().preferredHeight = 102;
            var shortcutsLayout = UI.Horizontal(shortcuts.transform, 10, new RectOffset(0, 0, 0, 0), TextAnchor.MiddleCenter);
            shortcutsLayout.childForceExpandHeight = true;
            UI.Button("Daily", shortcuts.transform, "جایزه روزانه", () => Navigate(AppRoute.RewardChest), false);
            UI.Button("Mission", shortcuts.transform, "مأموریت‌ها", () => Navigate(AppRoute.Missions), false);
            UI.Button("League", shortcuts.transform, "لیگ", () => Navigate(AppRoute.League), false);

            var hero = UI.Panel("Hero", column, new Color32(10, 65, 109, 255), new Color32(2, 24, 52, 255), UI.Theme.gold, 30, 7);
            hero.gameObject.AddComponent<LayoutElement>().preferredHeight = 920;
            var heroColumn = UI.Vertical(hero.transform, 12, new RectOffset(32, 32, 30, 28), TextAnchor.MiddleCenter);
            heroColumn.childForceExpandWidth = true;
            var crown = UI.IconBadge("Crown", hero.transform, "♛", new Color32(176, 107, 13, 255), 104);
            var preview = BuildBoardPreview(hero.transform);
            preview.gameObject.AddComponent<LayoutElement>().preferredHeight = 390;
            var title = UI.Text("GameTitle", hero.transform, "مار و پله", 74, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 110;
            var subtitle = UI.Text("GameSubtitle", hero.transform, "پادشاهی", 38, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            subtitle.gameObject.AddComponent<LayoutElement>().preferredHeight = 55;
            UI.Button("Start", hero.transform, "شروع بازی", () => Navigate(AppRoute.ModeSelection), true);
            var hint = UI.Text("Hint", hero.transform, "بازی سریع و رقابتی", 24, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            hint.gameObject.AddComponent<LayoutElement>().preferredHeight = 44;
        }

        private RectTransform BuildBoardPreview(Transform parent)
        {
            var board = UI.Panel("PreviewBoard", parent, new Color32(79, 55, 31, 255), new Color32(24, 24, 25, 255), UI.Theme.gold, 22, 5);
            var root = board.rectTransform;
            var grid = UI.Rect("Grid", root).GetComponent<RectTransform>();
            grid.anchorMin = new Vector2(0.08f, 0.10f);
            grid.anchorMax = new Vector2(0.92f, 0.90f);
            grid.offsetMin = Vector2.zero;
            grid.offsetMax = Vector2.zero;
            for (var y = 0; y < 5; y++)
                for (var x = 0; x < 7; x++)
                {
                    var isBlue = (x + y) % 2 == 0;
                    var cell = UI.Panel("Cell", grid, isBlue ? new Color32(27, 92, 140, 255) : new Color32(212, 178, 116, 255), isBlue ? new Color32(11, 54, 96, 255) : new Color32(150, 107, 55, 255), new Color32(72, 50, 29, 255), 3, 1);
                    cell.rectTransform.anchorMin = new Vector2(x / 7f, y / 5f);
                    cell.rectTransform.anchorMax = new Vector2((x + 1) / 7f, (y + 1) / 5f);
                    cell.rectTransform.offsetMin = new Vector2(1, 1);
                    cell.rectTransform.offsetMax = new Vector2(-1, -1);
                }
            var snake = UI.Icon("Snake", root, "snake", new Color32(65, 174, 80, 255));
            snake.rectTransform.anchorMin = new Vector2(0.08f, 0.25f);
            snake.rectTransform.anchorMax = new Vector2(0.32f, 0.82f);
            snake.rectTransform.offsetMin = Vector2.zero;
            snake.rectTransform.offsetMax = Vector2.zero;
            var ladder = UI.Icon("Ladder", root, "ladder", UI.Theme.gold);
            ladder.rectTransform.anchorMin = new Vector2(0.63f, 0.18f);
            ladder.rectTransform.anchorMax = new Vector2(0.84f, 0.80f);
            ladder.rectTransform.offsetMin = Vector2.zero;
            ladder.rectTransform.offsetMax = Vector2.zero;
            ladder.rectTransform.localRotation = Quaternion.Euler(0, 0, -18f);
            return root;
        }
    }
}
