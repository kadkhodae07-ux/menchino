using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class ProductDetailsScreen : RoyalScreenBase
    {
        public static string SelectedProductId = "emerald_snake";
        public override AppRoute Route => AppRoute.ProductDetails;
        public override bool ShowTopStatusBar => true;

        protected override void BuildScreen()
        {
            var catalog = Get<ICatalogService>();
            var product = catalog.FindProduct(SelectedProductId) ?? catalog.Products[0];
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 16, 14);
            RoyalChrome.BuildHeader(App, column, "جزئیات محصول");
            var panel = UI.Panel("Product", column, new Color32(9, 61, 101, 255), new Color32(2, 23, 49, 255), UI.Theme.gold, 28, 6);
            panel.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(panel.transform, 16, new RectOffset(28, 28, 28, 28), TextAnchor.MiddleCenter);
            UI.IconBadge("ProductIcon", panel.transform, product.category == ProductCategory.Dice ? "⚄" : product.category == ProductCategory.Bundle ? "▣" : "♟", UI.Theme.gold, 180);
            var title = UI.Text("Title", panel.transform, product.title, 47, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 82;
            var description = UI.Text("Description", panel.transform, product.description, 27, UI.Theme.textPrimary, TextAlignmentOptions.Center);
            description.gameObject.AddComponent<LayoutElement>().preferredHeight = 120;
            ScreenWidgets.ListRow(App, panel.transform, "✓", "وضعیت مالکیت", product.owned ? "این محصول در اختیار شماست" : "هنوز خریداری نشده", product.owned ? "دارید" : "ندارید", product.owned ? UI.Theme.success : UI.Theme.warning);
            var priceText = product.currency == CurrencyType.Rial ? product.price.ToString("N0") + " ریال" : product.price.ToString("N0") + (product.currency == CurrencyType.Gem ? " الماس" : " سکه");
            var price = UI.Text("Price", panel.transform, priceText, 38, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            price.gameObject.AddComponent<LayoutElement>().preferredHeight = 64;
            var actionLabel = product.owned ? product.selected ? "انتخاب‌شده" : "انتخاب" : "خرید";
            var action = UI.Button("Action", column, actionLabel, () => Act(product), true);
            action.interactable = !(product.owned && product.selected) && product.currency != CurrencyType.Rial;
        }

        private void Act(ShopProduct product)
        {
            var catalog = Get<ICatalogService>();
            if (product.owned)
            {
                if (catalog.Select(product.id)) Toast("محصول انتخاب شد");
                else Toast("انتخاب محصول انجام نشد");
            }
            else
            {
                Confirm("تأیید خرید", $"خرید «{product.title}» انجام شود؟", "خرید", () =>
                {
                    if (catalog.Buy(product.id))
                    {
                        Toast("خرید با موفقیت انجام شد");
                        App.Navigation.Replace(AppRoute.ProductDetails);
                    }
                    else Toast("موجودی کافی نیست یا خرید نیازمند فروشگاه واقعی است");
                });
            }
        }
    }
}
