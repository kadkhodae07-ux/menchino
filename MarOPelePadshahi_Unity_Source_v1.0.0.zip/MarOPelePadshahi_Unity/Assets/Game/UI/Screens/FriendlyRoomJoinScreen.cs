using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class FriendlyRoomJoinScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.FriendlyRoomJoin;
        public override bool ShowTopStatusBar => true;
        private TMP_InputField _code;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 20, 28);
            RoyalChrome.BuildHeader(App, column, "ورود به اتاق");
            var spacer = UI.Rect("Spacer", column);
            spacer.AddComponent<LayoutElement>().preferredHeight = 120;
            UI.IconBadge("RoomIcon", column, "⌗", UI.Theme.royalBlue, 120);
            var hint = UI.Text("Hint", column, "کد شش‌رقمی اتاق را وارد کنید", 29, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            hint.gameObject.AddComponent<LayoutElement>().preferredHeight = 72;
            _code = ScreenWidgets.Input(App, column, "کد اتاق", string.Empty, true);
            _code.characterLimit = 6;
            UI.Button("Join", column, "ورود", Join, true);
            UI.Button("Create", column, "ساخت اتاق جدید", () => Navigate(AppRoute.FriendlyRoomCreate), false);
        }

        private void Join()
        {
            var room = Get<INetworkService>().JoinRoom(_code.text);
            if (!string.Equals(room.status, "متصل شدید"))
            {
                Toast(room.status ?? "اتاق پیدا نشد");
                return;
            }
            FriendlyLobbyScreen.PendingRoom = room;
            Navigate(AppRoute.FriendlyLobby);
        }
    }
}
