using System.Linq;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class FriendsScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Friends;
        public override bool ShowTopStatusBar => true;
        private RectTransform _content;
        private TMP_InputField _search;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 6);
            RoyalChrome.BuildHeader(App, column, "دوستان");
            _search = ScreenWidgets.Input(App, column, "جست‌وجوی نام یا شناسه");
            _search.onValueChanged.AddListener(_ => BuildList());
            var tabs = UI.Rect("Tabs", column);
            tabs.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(tabs.transform, 8);
            UI.Button("FriendsTab", tabs.transform, "دوستان", BuildList, false);
            UI.Button("RequestsTab", tabs.transform, "درخواست‌ها", () => Toast("درخواست دوستی جدیدی ندارید"), false);
            UI.Button("Messages", tabs.transform, "پیام‌ها", () => Navigate(AppRoute.Messages), false);
            var scroll = UI.ScrollView("FriendsList", column, out _content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(_content, 7, new RectOffset(8, 8, 8, 8), TextAnchor.UpperCenter);
            BuildList();
        }

        private void BuildList()
        {
            if (_content == null) return;
            foreach (Transform child in _content) Destroy(child.gameObject);
            var query = _search == null ? string.Empty : (_search.text ?? string.Empty).Trim();
            var list = Get<ICatalogService>().Friends.Where(x => string.IsNullOrEmpty(query) || x.name.Contains(query) || x.userId.Contains(query)).ToList();
            if (list.Count == 0)
            {
                var empty = UI.Text("Empty", _content, "کاربری پیدا نشد", 29, UI.Theme.textSecondary, TextAlignmentOptions.Center);
                empty.gameObject.AddComponent<LayoutElement>().preferredHeight = 120;
                return;
            }
            foreach (var friend in list)
            {
                var trailing = friend.online ? "آنلاین" : "آفلاین";
                ScreenWidgets.ListRow(App, _content, "♙", friend.name, friend.online ? "آماده بازی" : "آخرین بازدید ثبت شده", trailing, friend.online ? UI.Theme.success : UI.Theme.disabled, () =>
                {
                    if (friend.online) Confirm("دعوت به بازی", $"برای {friend.name} دعوت‌نامه ارسال شود؟", "ارسال", () => Toast("دعوت‌نامه ارسال شد"));
                    else Toast("این دوست در حال حاضر آفلاین است");
                }, 96);
            }
        }
    }
}
