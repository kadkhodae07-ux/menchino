using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class LocalTwoPlayerScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.LocalTwoPlayer;
        public override bool ShowTopStatusBar => true;
        private TMP_InputField _firstName;
        private TMP_InputField _secondName;
        private int _firstColor;
        private int _secondColor = 1;
        private TMP_Text _firstColorText;
        private TMP_Text _secondColorText;
        private readonly RuleSet _rules = new RuleSet();
        private readonly string[] _colorNames = { "آبی", "قرمز", "سبز", "بنفش" };

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 12, 6);
            RoyalChrome.BuildHeader(App, column, "بازی دونفره روی یک گوشی");
            var scroll = UI.ScrollView("Scroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 12, new RectOffset(12, 12, 12, 12), TextAnchor.UpperCenter);

            BuildPlayerCard(content, true);
            BuildPlayerCard(content, false);
            ScreenWidgets.SectionTitle(App, content, "قوانین بازی");
            ScreenWidgets.SettingRow(App, content, "6", "نوبت اضافه با ۶", "با عدد ۶ یک نوبت دیگر", _rules.extraTurnOnSix, v => _rules.extraTurnOnSix = v);
            ScreenWidgets.SettingRow(App, content, "100", "عدد دقیق خانه ۱۰۰", "حرکت اضافه انجام نمی‌شود", _rules.exactRollToFinish, v => _rules.exactRollToFinish = v);
            ScreenWidgets.SettingRow(App, content, "↶", "برخورد مهره‌ها", "برگرداندن مهره حریف", _rules.captureEnabled, v => _rules.captureEnabled = v);
            UI.Button("Start", column, "شروع بازی", StartMatch, true);
        }

        private void BuildPlayerCard(Transform parent, bool first)
        {
            var panel = UI.Panel(first ? "PlayerOne" : "PlayerTwo", parent, first ? new Color32(10, 87, 144, 255) : new Color32(144, 43, 43, 255), UI.Theme.navy, UI.Theme.gold, 22, 4);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 255;
            UI.Vertical(panel.transform, 10, new RectOffset(18, 18, 15, 15), TextAnchor.MiddleCenter);
            var title = UI.Text("Title", panel.transform, first ? "بازیکن اول" : "بازیکن دوم", 31, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 48;
            var input = ScreenWidgets.Input(App, panel.transform, first ? "نام بازیکن اول" : "نام بازیکن دوم", first ? "شاهین" : "بازیکن دوم");
            if (first) _firstName = input; else _secondName = input;
            var colorRow = UI.Rect("ColorRow", panel.transform);
            colorRow.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(colorRow.transform, 8);
            var colorText = UI.Text("SelectedColor", colorRow.transform, first ? _colorNames[_firstColor] : _colorNames[_secondColor], 23, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            colorText.gameObject.AddComponent<LayoutElement>().preferredWidth = 125;
            colorText.gameObject.GetComponent<LayoutElement>().flexibleWidth = 0;
            if (first) _firstColorText = colorText; else _secondColorText = colorText;
            for (var i = 0; i < 4; i++)
            {
                var captured = i;
                var button = UI.Button("Color" + i, colorRow.transform, (i + 1).ToString(), () => SelectColor(first, captured), false);
                button.image.color = ColorFor(i);
            }
        }

        private void SelectColor(bool first, int color)
        {
            if (first && color == _secondColor || !first && color == _firstColor)
            {
                Toast("این رنگ قبلاً انتخاب شده است");
                return;
            }
            if (first)
            {
                _firstColor = color;
                UI.SetText(_firstColorText, _colorNames[color]);
            }
            else
            {
                _secondColor = color;
                UI.SetText(_secondColorText, _colorNames[color]);
            }
        }

        private void StartMatch()
        {
            if (_firstColor == _secondColor)
            {
                Toast("رنگ مهره‌های دو بازیکن باید متفاوت باشد");
                return;
            }
            var names = new List<string> { _firstName.text, _secondName.text };
            var config = MatchConfigFactory.CreateLocalMatch(names, _rules);
            config.players[0].colorIndex = _firstColor;
            config.players[1].colorIndex = _secondColor;
            var session = Get<IMatchSessionService>();
            session.CurrentConfig = config;
            session.ModeName = "دونفره روی یک گوشی";
            Navigate(AppRoute.Gameplay);
        }

        private static Color ColorFor(int index)
        {
            return index == 0 ? new Color32(43, 133, 224, 255)
                : index == 1 ? new Color32(219, 68, 51, 255)
                : index == 2 ? new Color32(54, 181, 74, 255)
                : new Color32(139, 74, 211, 255);
        }
    }
}
