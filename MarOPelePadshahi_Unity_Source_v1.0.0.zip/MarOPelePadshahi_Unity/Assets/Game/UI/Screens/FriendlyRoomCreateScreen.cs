using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class FriendlyRoomCreateScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.FriendlyRoomCreate;
        public override bool ShowTopStatusBar => true;
        private int _playerCount = 2;
        private bool _privateRoom = true;
        private TMP_Text _count;
        private readonly RuleSet _rules = new RuleSet();

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 14, 8);
            RoyalChrome.BuildHeader(App, column, "ساخت اتاق دوستانه");
            var panel = UI.Panel("CreatePanel", column, new Color32(9, 65, 108, 255), new Color32(2, 24, 53, 255), UI.Theme.gold, 25, 5);
            panel.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(panel.transform, 16, new RectOffset(24, 24, 22, 22), TextAnchor.UpperCenter);
            ScreenWidgets.SectionTitle(App, panel.transform, "تعداد بازیکنان");
            _count = UI.Text("Count", panel.transform, "۲ بازیکن", 31, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            _count.gameObject.AddComponent<LayoutElement>().preferredHeight = 52;
            var countRow = UI.Rect("CountRow", panel.transform);
            countRow.AddComponent<LayoutElement>().preferredHeight = 76;
            UI.Horizontal(countRow.transform, 12);
            UI.Button("Two", countRow.transform, "۲", () => SetCount(2), false);
            UI.Button("Three", countRow.transform, "۳", () => SetCount(3), false);
            UI.Button("Four", countRow.transform, "۴", () => SetCount(4), false);
            ScreenWidgets.SettingRow(App, panel.transform, "◇", "اتاق خصوصی", "ورود فقط با کد اتاق", _privateRoom, v => _privateRoom = v);
            ScreenWidgets.SettingRow(App, panel.transform, "6", "نوبت اضافه با عدد ۶", "قانون استاندارد مسابقه", _rules.extraTurnOnSix, v => _rules.extraTurnOnSix = v);
            ScreenWidgets.SettingRow(App, panel.transform, "100", "عدد دقیق خانه ۱۰۰", "پایان دقیق مسابقه", _rules.exactRollToFinish, v => _rules.exactRollToFinish = v);
            UI.Button("JoinInstead", panel.transform, "ورود با کد اتاق", () => Navigate(AppRoute.FriendlyRoomJoin), false);
            UI.Button("Create", column, "ساخت اتاق", CreateRoom, true);
        }

        private void SetCount(int count)
        {
            _playerCount = Mathf.Clamp(count, 2, 4);
            UI.SetText(_count, $"{_playerCount} بازیکن");
        }

        private void CreateRoom()
        {
            var room = Get<INetworkService>().CreateRoom(_playerCount, _rules);
            if (string.IsNullOrEmpty(room.code))
            {
                Toast(room.status ?? "ساخت اتاق انجام نشد");
                return;
            }
            FriendlyLobbyScreen.PendingRoom = room;
            Navigate(AppRoute.FriendlyLobby);
        }
    }
}
