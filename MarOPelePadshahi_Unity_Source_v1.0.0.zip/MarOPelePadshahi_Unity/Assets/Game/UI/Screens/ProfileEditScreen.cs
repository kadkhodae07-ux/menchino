using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class ProfileEditScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.ProfileEdit;
        public override bool ShowTopStatusBar => true;
        private TMP_InputField _name;

        protected override void BuildScreen()
        {
            var profile = Get<IProfileService>().Profile;
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 12, 10);
            RoyalChrome.BuildHeader(App, column, "ویرایش پروفایل");
            var scroll = UI.ScrollView("EditScroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 12, new RectOffset(14, 14, 14, 14), TextAnchor.UpperCenter);
            UI.IconBadge("Avatar", content, "♔", new Color32(153, 91, 12, 255), 132);
            _name = ScreenWidgets.Input(App, content, "نام بازیکن", profile.displayName);
            ScreenWidgets.ListRow(App, content, "♙", "انتخاب آواتار", "آواتار پیش‌فرض سلطنتی", "تغییر", UI.Theme.royalBlue, () => Navigate(AppRoute.PiecePickerPopup));
            ScreenWidgets.ListRow(App, content, "▣", "قاب پروفایل", "قاب طلایی سلطنتی", "انتخاب", UI.Theme.gold, () => Toast("قاب طلایی انتخاب شد"));
            ScreenWidgets.ListRow(App, content, "★", "عنوان بازیکن", "قهرمان پادشاهی", "انتخاب", new Color32(113, 66, 187, 255), () => Toast("عنوان انتخاب شد"));
            ScreenWidgets.ListRow(App, content, "IR", "پرچم", "ایران", "تغییر", UI.Theme.teal, () => Toast("انتخاب پرچم آماده است"));
            ScreenWidgets.ListRow(App, content, "♟", "مهره پیش‌فرض", "مار زمردی", "تغییر", UI.Theme.success, () => Navigate(AppRoute.Shop));
            var id = UI.Text("Id", content, "شناسه: " + profile.userId, 22, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            id.gameObject.AddComponent<LayoutElement>().preferredHeight = 50;
            UI.Button("Save", column, "ذخیره تغییرات", Save, true);
        }

        private void Save()
        {
            try
            {
                Get<IProfileService>().UpdateName(_name.text);
                Toast("تغییرات پروفایل ذخیره شد");
                Back();
            }
            catch (System.Exception exception)
            {
                Toast(exception.Message);
            }
        }
    }
}
