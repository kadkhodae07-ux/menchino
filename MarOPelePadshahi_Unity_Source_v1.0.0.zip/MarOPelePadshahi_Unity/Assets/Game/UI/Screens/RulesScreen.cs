using Menchino.RoyalSnakesLadders.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class RulesScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Rules;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 6);
            RoyalChrome.BuildHeader(App, column, "قوانین بازی");
            var scroll = UI.ScrollView("RulesScroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 10, new RectOffset(14, 14, 14, 14), TextAnchor.UpperCenter);
            AddSection(content, "هدف بازی", "بازیکنی که زودتر و با عدد دقیق به خانه ۱۰۰ برسد، رتبه نخست را کسب می‌کند.");
            AddSection(content, "شروع بازی", "همه مهره‌ها از خانه صفر شروع می‌کنند. در قوانین استاندارد برای ورود به تخته نیازی به عدد ۶ نیست.");
            AddSection(content, "حرکت مهره", "پس از تعیین نتیجه تاس، مهره خانه‌به‌خانه و در مسیر مارپیچی تخته حرکت می‌کند.");
            AddSection(content, "نردبان‌ها", "قرارگرفتن روی ابتدای نردبان باعث صعود به خانه انتهایی نردبان می‌شود.");
            AddSection(content, "مارها", "قرارگرفتن روی سر مار باعث پایین‌آمدن مهره تا انتهای مسیر مار می‌شود.");
            AddSection(content, "خانه ۱۰۰", "در حالت استاندارد عدد دقیق لازم است. اگر نتیجه تاس بیشتر باشد، مهره در جای خود می‌ماند.");
            AddSection(content, "عدد ۶", "با فعال‌بودن قانون نوبت اضافه، عدد ۶ یک پرتاب دیگر می‌دهد. سومین ۶ متوالی می‌تواند نوبت را بسوزاند.");
            AddSection(content, "قوانین سفارشی", "برخورد مهره‌ها، خانه‌های امن، شروع با ۶، حرکت برگشتی و زمان محدود از تنظیمات مسابقه کنترل می‌شوند.");
            AddSection(content, "بازی آنلاین", "نتیجه تاس باید توسط سرور معتبر تعیین شود و کلاینت فقط انیمیشن نتیجه تأییدشده را اجرا کند.");
            AddSection(content, "قطع اتصال", "اتاق آنلاین باید بازیکن را برای بازه بازیابی نگه دارد و پس از اتصال، Snapshot کامل مسابقه را دریافت کند.");
            AddSection(content, "پایان بازی", "رتبه‌ها بر اساس ترتیب رسیدن به خانه ۱۰۰ ثبت می‌شوند و جوایز پس از ثبت قطعی نتیجه پرداخت می‌شوند.");
        }

        private void AddSection(Transform parent, string title, string body)
        {
            var panel = UI.Panel("Rule", parent, new Color32(8, 54, 91, 248), new Color32(2, 23, 49, 248), UI.Theme.darkGold, 18, 2);
            UI.Vertical(panel.transform, 5, new RectOffset(16, 16, 12, 12), TextAnchor.MiddleRight);
            var heading = UI.Text("Heading", panel.transform, title, 27, UI.Theme.lightGold, TextAlignmentOptions.Right, FontStyles.Bold);
            heading.gameObject.AddComponent<LayoutElement>().preferredHeight = 46;
            var text = UI.Text("Body", panel.transform, body, 22, UI.Theme.textPrimary, TextAlignmentOptions.Right);
            text.gameObject.AddComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        }
    }
}
