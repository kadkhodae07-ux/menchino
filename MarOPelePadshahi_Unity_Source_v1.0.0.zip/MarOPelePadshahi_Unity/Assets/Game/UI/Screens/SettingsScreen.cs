using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class SettingsScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Settings;
        private ISaveService _save;

        protected override void BuildScreen()
        {
            _save = Get<ISaveService>();
            var settings = _save.Current.settings;
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 6);
            RoyalChrome.BuildHeader(App, column, "تنظیمات");
            var scroll = UI.ScrollView("SettingsScroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 9, new RectOffset(10, 10, 10, 10), TextAnchor.UpperCenter);

            ScreenWidgets.SectionTitle(App, content, "صدا و تجربه بازی");
            BuildSliderRow(content, "♫", "موسیقی", settings.musicVolume, value =>
            {
                settings.musicVolume = value;
                SaveAndApplyAudio();
            });
            BuildSliderRow(content, "♪", "افکت صوتی", settings.sfxVolume, value =>
            {
                settings.sfxVolume = value;
                SaveAndApplyAudio();
            });
            ScreenWidgets.SettingRow(App, content, "≈", "لرزش", "بازخورد لمسی هنگام تاس و حرکت", settings.vibrationEnabled, value => { settings.vibrationEnabled = value; _save.Save(); });
            ScreenWidgets.SettingRow(App, content, "!", "اعلان‌ها", "جوایز، دعوت‌ها و رویدادها", settings.notificationsEnabled, value => { settings.notificationsEnabled = value; _save.Save(); });
            ScreenWidgets.SettingRow(App, content, "◒", "کاهش مصرف باتری", "کاهش افکت‌ها و نرخ فریم در پس‌زمینه", settings.lowPowerMode, value => { settings.lowPowerMode = value; Application.targetFrameRate = value ? 45 : 60; _save.Save(); });

            ScreenWidgets.SectionTitle(App, content, "نمایش و حساب");
            ScreenWidgets.ListRow(App, content, "文", "زبان", settings.language == "fa" ? "فارسی" : "English", "تغییر", UI.Theme.teal, () => Navigate(AppRoute.Language));
            ScreenWidgets.ListRow(App, content, "◇", "کیفیت گرافیک", QualityLabel(settings.graphicsQuality), "تغییر", UI.Theme.royalBlue, CycleQuality);
            ScreenWidgets.ListRow(App, content, "?", "راهنما و آموزش", "اجرای دوباره آموزش اولیه", "بازکردن", UI.Theme.gold, () => Navigate(AppRoute.Tutorial));
            ScreenWidgets.ListRow(App, content, "§", "قوانین بازی", "قوانین استاندارد و سفارشی", "مطالعه", UI.Theme.royalBlue, () => Navigate(AppRoute.Rules));
            ScreenWidgets.ListRow(App, content, "☎", "پشتیبانی", "پرسش‌های متداول و ارسال پیام", "تماس", UI.Theme.success, () => Navigate(AppRoute.Support));
            ScreenWidgets.ListRow(App, content, "□", "حریم خصوصی", "مدیریت داده‌ها و مجوزها", "مشاهده", UI.Theme.disabled, () => Toast("متن حریم خصوصی باید با نسخه نهایی سرویس جایگزین شود"));
            UI.Button("Logout", content, "خروج از حساب", () => Confirm("خروج از حساب", "از حساب فعلی خارج می‌شوید؟", "خروج", () => App.Navigation.Reset(AppRoute.Login)), false, true);
            UI.Button("Delete", content, "حذف حساب", () => Confirm("حذف حساب", "حذف حساب پس از اتصال Backend باید با تأیید مجدد سرور انجام شود.", "درخواست حذف", () => Toast("درخواست حذف ثبت محلی شد")), false, true);
        }

        private void BuildSliderRow(Transform parent, string icon, string title, float value, System.Action<float> changed)
        {
            var panel = UI.Panel("SliderRow", parent, new Color32(9, 52, 88, 250), new Color32(3, 23, 49, 250), UI.Theme.darkGold, 16, 2);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 112;
            UI.Vertical(panel.transform, 4, new RectOffset(14, 14, 8, 8), TextAnchor.MiddleCenter);
            var header = UI.Rect("Header", panel.transform);
            header.AddComponent<LayoutElement>().preferredHeight = 42;
            UI.Horizontal(header.transform, 10);
            UI.IconBadge("Icon", header.transform, icon, UI.Theme.royalBlue, 42);
            var text = UI.Text("Title", header.transform, title, 23, UI.Theme.textPrimary, TextAlignmentOptions.Right, FontStyles.Bold);
            text.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1;
            UI.Slider("Slider", panel.transform, value, valueChanged => changed?.Invoke(valueChanged));
        }

        private void SaveAndApplyAudio()
        {
            _save.Save();
            Get<IAudioService>().SetVolumes(_save.Current.settings.musicVolume, _save.Current.settings.sfxVolume);
        }

        private void CycleQuality()
        {
            var settings = _save.Current.settings;
            settings.graphicsQuality = (settings.graphicsQuality + 1) % 3;
            QualitySettings.SetQualityLevel(Mathf.Clamp(settings.graphicsQuality, 0, QualitySettings.names.Length - 1), true);
            _save.Save();
            Toast("کیفیت گرافیک: " + QualityLabel(settings.graphicsQuality));
        }

        private static string QualityLabel(int value) => value <= 0 ? "اقتصادی" : value == 1 ? "متعادل" : "بالا";
    }
}
