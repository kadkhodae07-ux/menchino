using System;
using System.Linq;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class ShopScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Shop;
        public override bool ShowBottomNavigation => true;
        public override bool ShowTopStatusBar => true;
        private ProductCategory _category = ProductCategory.Piece;
        private RectTransform _grid;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 12, 4);
            RoyalChrome.BuildHeader(App, column, "فروشگاه", false);
            var tabs = UI.Rect("Tabs", column);
            tabs.AddComponent<LayoutElement>().preferredHeight = 76;
            UI.Horizontal(tabs.transform, 8);
            UI.Button("Pieces", tabs.transform, "مهره", () => SetCategory(ProductCategory.Piece), false);
            UI.Button("Dice", tabs.transform, "تاس", () => SetCategory(ProductCategory.Dice), false);
            UI.Button("Avatars", tabs.transform, "آواتار", () => SetCategory(ProductCategory.Avatar), false);
            UI.Button("Bundles", tabs.transform, "باندل", () => SetCategory(ProductCategory.Bundle), false);

            var scroll = UI.ScrollView("Products", column, out _grid);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            var gridLayout = _grid.gameObject.AddComponent<GridLayoutGroup>();
            gridLayout.cellSize = new Vector2(400, 270);
            gridLayout.spacing = new Vector2(14, 14);
            gridLayout.padding = new RectOffset(12, 12, 12, 12);
            gridLayout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            gridLayout.constraintCount = 2;
            gridLayout.childAlignment = TextAnchor.UpperCenter;
            var fitter = _grid.GetComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            BuildProducts();
        }

        private void SetCategory(ProductCategory category)
        {
            _category = category;
            BuildProducts();
        }

        private void BuildProducts()
        {
            foreach (Transform child in _grid) Destroy(child.gameObject);
            var products = Get<ICatalogService>().Products.Where(p => p.category == _category).ToList();
            if (products.Count == 0)
            {
                var empty = UI.Text("Empty", _grid, "محصولی در این دسته ثبت نشده است", 28, UI.Theme.textSecondary, TextAlignmentOptions.Center);
                empty.gameObject.AddComponent<LayoutElement>().preferredHeight = 120;
                return;
            }
            foreach (var product in products) BuildProductCard(product);
        }

        private void BuildProductCard(ShopProduct product)
        {
            var panel = UI.Panel("Product_" + product.id, _grid, new Color32(9, 59, 98, 255), new Color32(2, 24, 51, 255), product.selected ? UI.Theme.lightGold : UI.Theme.darkGold, 20, product.selected ? 6 : 3);
            UI.Vertical(panel.transform, 7, new RectOffset(12, 12, 12, 12), TextAnchor.MiddleCenter);
            UI.IconBadge("Icon", panel.transform, SymbolFor(product), AccentFor(product), 96);
            var title = UI.Text("Title", panel.transform, product.title, 25, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 55;
            var status = product.owned ? product.selected ? "انتخاب‌شده" : "دارید" : PriceText(product);
            var price = UI.Text("Status", panel.transform, status, 22, product.owned ? UI.Theme.success : UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            price.gameObject.AddComponent<LayoutElement>().preferredHeight = 42;
            var button = panel.gameObject.AddComponent<Button>();
            button.targetGraphic = panel;
            button.onClick.AddListener(() =>
            {
                ProductDetailsScreen.SelectedProductId = product.id;
                Navigate(AppRoute.ProductDetails);
            });
        }

        private static string SymbolFor(ShopProduct p)
        {
            switch (p.category)
            {
                case ProductCategory.Piece: return p.iconKey.Contains("snake") ? "S" : "♟";
                case ProductCategory.Dice: return "⚄";
                case ProductCategory.Avatar: return "♔";
                case ProductCategory.Bundle: return "▣";
                default: return "♦";
            }
        }

        private Color AccentFor(ShopProduct p)
        {
            if (p.iconKey.Contains("red")) return new Color32(195, 55, 45, 255);
            if (p.iconKey.Contains("blue")) return new Color32(47, 125, 205, 255);
            if (p.iconKey.Contains("green")) return new Color32(55, 164, 72, 255);
            return UI.Theme.gold;
        }

        private static string PriceText(ShopProduct p)
        {
            if (p.currency == CurrencyType.Rial) return p.price.ToString("N0") + " ریال";
            return p.price.ToString("N0") + (p.currency == CurrencyType.Gem ? " الماس" : " سکه");
        }
    }
}
