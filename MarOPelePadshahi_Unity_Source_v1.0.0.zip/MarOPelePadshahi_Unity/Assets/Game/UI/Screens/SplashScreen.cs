using System;
using System.Collections;
using Menchino.RoyalSnakesLadders.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class SplashScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Splash;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 18, 42);
            var spacer = UI.Rect("TopSpacer", column);
            spacer.AddComponent<LayoutElement>().preferredHeight = 210;
            var crown = UI.IconBadge("Crown", column, "♛", new Color32(151, 92, 10, 255), 150);
            var title = UI.Text("Title", column, "مار و پله", 86, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 130;
            var subtitle = UI.Text("Subtitle", column, "پادشاهی", 46, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            subtitle.gameObject.AddComponent<LayoutElement>().preferredHeight = 72;
            var info = UI.Text("Info", column, "در حال آماده‌سازی پادشاهی...", 27, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            info.gameObject.AddComponent<LayoutElement>().preferredHeight = 56;
            var progressRoot = UI.Panel("Progress", column, UI.Theme.navy, new Color32(1, 12, 28, 255), UI.Theme.gold, 18, 4);
            progressRoot.gameObject.AddComponent<LayoutElement>().preferredHeight = 38;
            var fill = UI.Panel("Fill", progressRoot.transform, UI.Theme.lightGold, UI.Theme.gold, UI.Theme.gold, 14, 1);
            fill.rectTransform.anchorMin = Vector2.zero;
            fill.rectTransform.anchorMax = new Vector2(0.05f, 1);
            fill.rectTransform.offsetMin = new Vector2(4, 4);
            fill.rectTransform.offsetMax = new Vector2(-4, -4);
            var version = UI.Text("Version", column, "نسخه " + Application.version, 20, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            version.gameObject.AddComponent<LayoutElement>().preferredHeight = 44;
            StartCoroutine(LoadRoutine(fill.rectTransform));
        }

        private IEnumerator LoadRoutine(RectTransform fill)
        {
            var elapsed = 0f;
            const float duration = 1.35f;
            while (elapsed < duration)
            {
                elapsed += Time.unscaledDeltaTime;
                var value = Mathf.SmoothStep(0.05f, 1f, Mathf.Clamp01(elapsed / duration));
                fill.anchorMax = new Vector2(value, 1);
                yield return null;
            }
            var save = Get<Menchino.RoyalSnakesLadders.Services.ISaveService>();
            App.Navigation.Reset(ResolveStartupRoute(save));
        }
        private static AppRoute ResolveStartupRoute(Menchino.RoyalSnakesLadders.Services.ISaveService save)
        {
            if (save == null || save.Current == null || save.Current.settings == null || !save.Current.settings.tutorialCompleted)
                return AppRoute.Language;
            if (!Enum.TryParse(save.Current.lastValidRoute, out AppRoute route))
                return AppRoute.Home;
            switch (route)
            {
                case AppRoute.Home:
                case AppRoute.ModeSelection:
                case AppRoute.BotSetup:
                case AppRoute.LocalTwoPlayer:
                case AppRoute.FriendlyRoomCreate:
                case AppRoute.FriendlyRoomJoin:
                case AppRoute.Shop:
                case AppRoute.ProductDetails:
                case AppRoute.RewardChest:
                case AppRoute.League:
                case AppRoute.Missions:
                case AppRoute.Friends:
                case AppRoute.Messages:
                case AppRoute.Profile:
                case AppRoute.ProfileEdit:
                case AppRoute.Settings:
                case AppRoute.Rules:
                case AppRoute.Support:
                    return route;
                default:
                    return AppRoute.Home;
            }
        }

    }
}
