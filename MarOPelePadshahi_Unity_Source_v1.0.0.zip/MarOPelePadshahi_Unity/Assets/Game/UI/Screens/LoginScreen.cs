using System.Collections;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class LoginScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Login;
        private TMP_InputField _mobile;
        private TMP_InputField _code;
        private TMP_Text _expiry;
        private GameObject _otpGroup;
        private float _expiresAt;
        private bool _acceptedRules = true;
        private string _verificationCode = "123456";
        private Coroutine _timerRoutine;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 13, 40);
            var spacer = UI.Rect("Spacer", column);
            spacer.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.IconBadge("King", column, "crown", new Color32(165, 99, 12, 255), 116);
            var title = UI.Text("Title", column, "به پادشاهی خوش آمدید", 46, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 80;

            _mobile = ScreenWidgets.Input(App, column, "شماره موبایل", string.Empty, true);
            UI.Button("SendCode", column, "دریافت کد تأیید", SendCode, true);

            _otpGroup = UI.Panel("OtpGroup", column, new Color32(8, 54, 92, 248), new Color32(2, 24, 50, 248), UI.Theme.darkGold, 18, 3).gameObject;
            _otpGroup.AddComponent<LayoutElement>().preferredHeight = 250;
            UI.Vertical(_otpGroup.transform, 8, new RectOffset(14, 14, 12, 12), TextAnchor.MiddleCenter);
            var otpTitle = UI.Text("OtpTitle", _otpGroup.transform, "کد شش‌رقمی را وارد کنید", 25, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            otpTitle.gameObject.AddComponent<LayoutElement>().preferredHeight = 42;
            _code = ScreenWidgets.Input(App, _otpGroup.transform, "کد تأیید", string.Empty, true);
            _code.characterLimit = 6;
            _expiry = UI.Text("Expiry", _otpGroup.transform, "اعتبار کد: ۰۲:۰۰", 20, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            _expiry.gameObject.AddComponent<LayoutElement>().preferredHeight = 36;
            var otpButtons = UI.Rect("OtpButtons", _otpGroup.transform);
            otpButtons.AddComponent<LayoutElement>().preferredHeight = 66;
            UI.Horizontal(otpButtons.transform, 8);
            UI.Button("Verify", otpButtons.transform, "ورود", VerifyCode, true);
            UI.Button("Resend", otpButtons.transform, "ارسال مجدد", SendCode, false);
            _otpGroup.SetActive(false);

            UI.Button("ExistingAccount", column, "ورود به حساب موجود", FocusMobile, false);
            UI.Button("Guest", column, "ادامه به‌عنوان مهمان", ContinueAsGuest, false);
            ScreenWidgets.SettingRow(App, column, "check", "قوانین و حریم خصوصی", "شرایط استفاده و حریم خصوصی را می‌پذیرم", _acceptedRules, value => _acceptedRules = value);
        }

        private void SendCode()
        {
            if (!_acceptedRules)
            {
                Toast("ابتدا قوانین و حریم خصوصی را بپذیرید");
                return;
            }
            if (!Get<INetworkService>().IsOnline)
            {
                Toast("اتصال اینترنت در دسترس نیست");
                return;
            }
            var number = (_mobile.text ?? string.Empty).Trim();
            if (number.Length < 10 || number.Length > 15)
            {
                Toast("شماره موبایل معتبر نیست");
                return;
            }

            _verificationCode = "123456";
            _expiresAt = Time.unscaledTime + 120f;
            _otpGroup.SetActive(true);
            _code.text = string.Empty;
            _code.Select();
            _code.ActivateInputField();
            if (_timerRoutine != null) StopCoroutine(_timerRoutine);
            _timerRoutine = StartCoroutine(UpdateExpiry());
            Toast("کد آزمایشی ۱۲۳۴۵۶ ارسال شد؛ در نسخه انتشار به سرویس OTP متصل شود");
        }

        private void VerifyCode()
        {
            if (!_otpGroup.activeSelf)
            {
                Toast("ابتدا کد تأیید را دریافت کنید");
                return;
            }
            if (Time.unscaledTime >= _expiresAt)
            {
                Toast("اعتبار کد پایان یافته است؛ دوباره ارسال کنید");
                return;
            }
            if ((_code.text ?? string.Empty).Trim() != _verificationCode)
            {
                Toast("کد تأیید اشتباه است");
                return;
            }
            var save = Get<ISaveService>();
            save.Current.settings.tutorialCompleted = false;
            save.Save();
            Navigate(AppRoute.Tutorial);
        }

        private IEnumerator UpdateExpiry()
        {
            while (_otpGroup != null && _otpGroup.activeSelf)
            {
                var seconds = Mathf.Max(0, Mathf.CeilToInt(_expiresAt - Time.unscaledTime));
                UI.SetText(_expiry, $"اعتبار کد: {seconds / 60:00}:{seconds % 60:00}");
                if (seconds <= 0)
                {
                    UI.SetText(_expiry, "اعتبار کد پایان یافته است");
                    _timerRoutine = null;
                    yield break;
                }
                yield return new WaitForSecondsRealtime(0.25f);
            }
            _timerRoutine = null;
        }

        private void FocusMobile()
        {
            _mobile.Select();
            _mobile.ActivateInputField();
            Toast("شماره حساب موجود را وارد کنید");
        }

        private void ContinueAsGuest()
        {
            if (!_acceptedRules)
            {
                Toast("ابتدا قوانین و حریم خصوصی را بپذیرید");
                return;
            }
            var save = Get<ISaveService>();
            save.Current.settings.tutorialCompleted = false;
            save.Save();
            Navigate(AppRoute.Tutorial);
        }

        private void OnDestroy()
        {
            if (_timerRoutine != null) StopCoroutine(_timerRoutine);
        }
    }
}
