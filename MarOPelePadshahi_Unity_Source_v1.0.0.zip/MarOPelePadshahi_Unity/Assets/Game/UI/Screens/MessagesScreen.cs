using Menchino.RoyalSnakesLadders.Core;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class MessagesScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Messages;
        public override bool ShowTopStatusBar => true;
        private RectTransform _content;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 6);
            RoyalChrome.BuildHeader(App, column, "پیام‌ها و دعوت‌ها");
            var tabs = UI.Rect("Tabs", column);
            tabs.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(tabs.transform, 8);
            UI.Button("System", tabs.transform, "سیستمی", ShowSystemMessages, false);
            UI.Button("Invites", tabs.transform, "دعوت‌ها", ShowInvites, false);
            UI.Button("Rewards", tabs.transform, "جوایز", ShowRewards, false);
            var scroll = UI.ScrollView("Messages", column, out _content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(_content, 8, new RectOffset(8, 8, 8, 8), TextAnchor.UpperCenter);
            ShowSystemMessages();
        }

        private void ShowSystemMessages()
        {
            ClearRows();
            ScreenWidgets.ListRow(App, _content, "crown", "خوش‌آمدگویی پادشاهی", "هدیه ورود شما آماده دریافت است", "جدید", UI.Theme.gold, () => Navigate(AppRoute.RewardChest), 108);
            ScreenWidgets.ListRow(App, _content, "gem", "فصل جدید لیگ", "فصل لیگ الماس آغاز شد", "امروز", new Color32(119, 67, 193, 255), () => Navigate(AppRoute.League), 108);
            ScreenWidgets.ListRow(App, _content, "star", "مأموریت روزانه", "مأموریت‌های جدید فعال شدند", "امروز", UI.Theme.teal, () => Navigate(AppRoute.Missions), 108);
        }

        private void ShowInvites()
        {
            ClearRows();
            ScreenWidgets.ListRow(App, _content, "room", "دعوت یلدا", "اتاق دوستانه چهار نفره", "ورود", UI.Theme.success, () => Navigate(AppRoute.FriendlyLobby), 108);
            ScreenWidgets.ListRow(App, _content, "return", "دعوت آرمان", "دعوت بازی دوستانه منقضی شد", "منقضی", UI.Theme.disabled, () => Toast("این دعوت منقضی شده است"), 108);
        }

        private void ShowRewards()
        {
            ClearRows();
            ScreenWidgets.ListRow(App, _content, "chest", "صندوق روزانه", "یک صندوق برای دریافت آماده است", "دریافت", UI.Theme.gold, () => Navigate(AppRoute.RewardChest), 108);
            ScreenWidgets.ListRow(App, _content, "trophy", "جایزه لیگ", "پیشرفت فصل و جوایز رتبه را ببینید", "مشاهده", new Color32(119, 67, 193, 255), () => Navigate(AppRoute.League), 108);
            ScreenWidgets.ListRow(App, _content, "star", "پاداش مأموریت", "مأموریت‌های تکمیل‌شده را دریافت کنید", "مشاهده", UI.Theme.teal, () => Navigate(AppRoute.Missions), 108);
        }

        private void ClearRows()
        {
            if (_content == null) return;
            for (var index = _content.childCount - 1; index >= 0; index--)
            {
                var child = _content.GetChild(index).gameObject;
                child.SetActive(false);
                Destroy(child);
            }
        }
    }
}
