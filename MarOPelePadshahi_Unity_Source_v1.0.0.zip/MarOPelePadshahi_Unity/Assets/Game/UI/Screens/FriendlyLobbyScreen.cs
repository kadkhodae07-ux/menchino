using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class FriendlyLobbyScreen : RoyalScreenBase
    {
        public static FriendlyRoomSnapshot PendingRoom;
        public override AppRoute Route => AppRoute.FriendlyLobby;
        public override bool ShowTopStatusBar => true;
        private FriendlyRoomSnapshot _room;
        private RectTransform _playersRoot;
        private Button _start;

        protected override void BuildScreen()
        {
            _room = PendingRoom ?? new FriendlyRoomSnapshot { code = "000000", isHost = true, maxPlayers = 4, status = "در انتظار بازیکن", playerNames = { "شاهین" } };
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 13, 8);
            RoyalChrome.BuildHeader(App, column, "لابی اتاق دوستانه");
            var codePanel = UI.Panel("Code", column, new Color32(11, 80, 130, 255), new Color32(3, 28, 60, 255), UI.Theme.gold, 22, 4);
            codePanel.gameObject.AddComponent<LayoutElement>().preferredHeight = 130;
            UI.Vertical(codePanel.transform, 2, new RectOffset(14, 14, 12, 12), TextAnchor.MiddleCenter);
            var label = UI.Text("Label", codePanel.transform, "کد اتاق", 22, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            label.gameObject.AddComponent<LayoutElement>().preferredHeight = 34;
            var code = UI.Text("Value", codePanel.transform, _room.code, 46, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            code.gameObject.AddComponent<LayoutElement>().preferredHeight = 62;
            UI.Button("Share", column, "اشتراک کد و دعوت دوست", () =>
            {
                GUIUtility.systemCopyBuffer = _room.code;
                Toast("کد اتاق کپی شد");
            }, false);

            _playersRoot = UI.Panel("Players", column, new Color32(7, 52, 89, 250), new Color32(2, 22, 47, 250), UI.Theme.darkGold, 22, 3).rectTransform;
            _playersRoot.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(_playersRoot, 10, new RectOffset(14, 14, 14, 14), TextAnchor.UpperCenter);
            BuildPlayers();
            _start = UI.Button("Start", column, _room.isHost ? "شروع بازی" : "آماده هستم", StartMatch, true);
            _start.interactable = _room.isHost ? _room.playerNames.Count >= 2 : true;
            UI.Button("Leave", column, "خروج از اتاق", () => Confirm("خروج از اتاق", "از اتاق دوستانه خارج می‌شوید؟", "خروج", () => Navigate(AppRoute.Home)), false);
        }

        private void BuildPlayers()
        {
            foreach (Transform child in _playersRoot) Destroy(child.gameObject);
            for (var i = 0; i < _room.maxPlayers; i++)
            {
                if (i < _room.playerNames.Count)
                    ScreenWidgets.ListRow(App, _playersRoot, "♙", _room.playerNames[i], i == 0 ? "میزبان" : "آماده", "●", i == 0 ? UI.Theme.gold : UI.Theme.success);
                else
                    ScreenWidgets.ListRow(App, _playersRoot, "+", "جای خالی", "در انتظار بازیکن", "...", UI.Theme.disabled);
            }
        }

        private void StartMatch()
        {
            var names = new List<string>(_room.playerNames);
            while (names.Count < Mathf.Max(2, _room.maxPlayers)) names.Add("ربات مهمان " + names.Count);
            var config = MatchConfigFactory.CreateLocalMatch(names, new RuleSet());
            for (var i = _room.playerNames.Count; i < config.players.Count; i++) config.players[i].controlType = PlayerControlType.Bot;
            var session = Get<IMatchSessionService>();
            session.CurrentConfig = config;
            session.ModeName = "اتاق دوستانه";
            Navigate(AppRoute.Gameplay);
        }
    }
}
