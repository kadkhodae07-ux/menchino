using Menchino.RoyalSnakesLadders.Core;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class ModeSelectionScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.ModeSelection;
        public override bool ShowTopStatusBar => true;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 14, 6);
            RoyalChrome.BuildHeader(App, column, "حالت بازی را انتخاب کنید");
            var scroll = UI.ScrollView("ModesScroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 14, new RectOffset(12, 12, 12, 12), TextAnchor.UpperCenter);
            ScreenWidgets.InfoCard(App, content, "♙", "بازی با ربات", "با ربات‌های چندسطحی تمرین و رقابت کنید", new Color32(24, 111, 181, 255), () => Navigate(AppRoute.BotSetup), 155);
            ScreenWidgets.InfoCard(App, content, "♟", "دونفره روی یک گوشی", "دو بازیکن در کنار هم روی یک دستگاه", new Color32(54, 145, 68, 255), () => Navigate(AppRoute.LocalTwoPlayer), 155);
            ScreenWidgets.InfoCard(App, content, "◎", "بازی آنلاین", "حریف‌یابی و مسابقه رتبه‌بندی‌شده", new Color32(105, 58, 174, 255), () => Navigate(AppRoute.Matchmaking), 155);
            ScreenWidgets.InfoCard(App, content, "♜", "بازی با دوستان", "اتاق خصوصی بسازید یا با کد وارد شوید", new Color32(181, 101, 24, 255), () => Navigate(AppRoute.FriendlyRoomCreate), 155);
            ScreenWidgets.InfoCard(App, content, "4", "چهارنفره خصوصی", "اتاق اختصاصی برای چهار بازیکن", new Color32(166, 59, 87, 255), () => Navigate(AppRoute.FriendlyRoomCreate), 155);
            ScreenWidgets.InfoCard(App, content, "?", "تمرین", "آموزش قوانین و حرکت‌ها بدون محدودیت", new Color32(28, 136, 143, 255), () => Navigate(AppRoute.Tutorial), 155);
        }
    }
}
