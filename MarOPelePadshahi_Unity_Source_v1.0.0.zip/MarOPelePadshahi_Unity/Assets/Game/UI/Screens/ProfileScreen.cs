using System;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class ProfileScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Profile;
        public override bool ShowBottomNavigation => true;

        protected override void BuildScreen()
        {
            var profile = Get<IProfileService>().Profile;
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 9, 6);
            RoyalChrome.BuildHeader(App, column, "پروفایل", true);
            var card = UI.Panel("ProfileCard", column, new Color32(9, 61, 102, 255), new Color32(2, 23, 50, 255), UI.Theme.gold, 26, 5);
            card.gameObject.AddComponent<LayoutElement>().preferredHeight = 610;
            UI.Vertical(card.transform, 9, new RectOffset(18, 18, 16, 16), TextAnchor.MiddleCenter);
            UI.IconBadge("Avatar", card.transform, "♔", new Color32(153, 91, 12, 255), 142);
            var name = UI.Text("Name", card.transform, profile.displayName, 48, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            name.gameObject.AddComponent<LayoutElement>().preferredHeight = 72;
            var id = UI.Text("Id", card.transform, "شناسه کاربری: " + profile.userId, 22, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            id.gameObject.AddComponent<LayoutElement>().preferredHeight = 42;
            var league = ScreenWidgets.ListRow(App, card.transform, "♦", "لیگ فعلی", profile.league, "سطح " + profile.level, new Color32(116, 65, 188, 255), () => Navigate(AppRoute.League), 88);
            var xpLabel = UI.Text("XPLabel", card.transform, $"XP {profile.xp:N0} / {profile.xpForNextLevel:N0}", 22, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            xpLabel.gameObject.AddComponent<LayoutElement>().preferredHeight = 36;
            UI.Progress("XP", card.transform, profile.xp / (float)Mathf.Max(1, profile.xpForNextLevel), UI.Theme.gold);
            ScreenWidgets.SectionTitle(App, card.transform, "آمار کلی");
            var statsOne = UI.Rect("StatsOne", card.transform);
            statsOne.AddComponent<LayoutElement>().preferredHeight = 120;
            UI.Horizontal(statsOne.transform, 8);
            ScreenWidgets.StatTile(App, statsOne.transform, "♟", "تعداد بازی", profile.gamesPlayed.ToString(), UI.Theme.royalBlue);
            ScreenWidgets.StatTile(App, statsOne.transform, "♛", "تعداد برد", profile.wins.ToString(), UI.Theme.gold);
            ScreenWidgets.StatTile(App, statsOne.transform, "★", "نرخ برد", profile.WinRatePercent + "%", UI.Theme.success);
            var statsTwo = UI.Rect("StatsTwo", card.transform);
            statsTwo.AddComponent<LayoutElement>().preferredHeight = 120;
            UI.Horizontal(statsTwo.transform, 8);
            ScreenWidgets.StatTile(App, statsTwo.transform, "♜", "تعداد جام", profile.trophies.ToString("N0"), UI.Theme.gold);
            ScreenWidgets.StatTile(App, statsTwo.transform, "♙", "مهره محبوب", "مار زمردی", new Color32(51, 159, 70, 255));

            ScreenWidgets.SectionTitle(App, column, "دستاوردهای من");
            var achievements = UI.Rect("Achievements", column);
            achievements.AddComponent<LayoutElement>().preferredHeight = 105;
            UI.Horizontal(achievements.transform, 8);
            UI.IconBadge("A1", achievements.transform, "1", UI.Theme.gold, 78);
            UI.IconBadge("A2", achievements.transform, "100", UI.Theme.royalBlue, 78);
            UI.IconBadge("A3", achievements.transform, "♛", UI.Theme.success, 78);
            UI.IconBadge("A4", achievements.transform, "⚄", new Color32(119, 65, 190, 255), 78);
            UI.IconBadge("A5", achievements.transform, "╫", UI.Theme.teal, 78);
            UI.Button("Edit", column, "ویرایش پروفایل", () => Navigate(AppRoute.ProfileEdit), true);
        }
    }
}
