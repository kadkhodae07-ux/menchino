using System;
using System.Linq;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class ResultsScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Results;

        protected override void BuildScreen()
        {
            var session = Get<IMatchSessionService>();
            var snapshot = session.LastSnapshot;
            if (snapshot == null)
            {
                snapshot = new MatchSnapshot
                {
                    phase = MatchPhase.Finished,
                    players = MatchConfigFactory.CreateBotMatch(2, new RuleSet()).players
                };
                snapshot.players[0].finishRank = 1;
                snapshot.players[1].finishRank = 2;
            }

            ApplyRewardsOnce(snapshot);

            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 14, 24);
            var spacer = UI.Rect("Spacer", column);
            spacer.AddComponent<LayoutElement>().preferredHeight = 70;
            UI.IconBadge("Trophy", column, "♛", new Color32(176, 106, 12, 255), 132);
            var winner = snapshot.players.OrderBy(p => p.finishRank <= 0 ? int.MaxValue : p.finishRank).First();
            var title = UI.Text("Title", column, winner.id == "local" || winner.id.StartsWith("local_") ? "پیروز شدی!" : "پایان مسابقه", 62, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 100;
            var subtitle = UI.Text("Subtitle", column, $"برنده: {winner.displayName}", 30, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            subtitle.gameObject.AddComponent<LayoutElement>().preferredHeight = 60;

            var ranking = UI.Panel("Ranking", column, new Color32(8, 58, 98, 250), new Color32(2, 23, 50, 250), UI.Theme.gold, 24, 4);
            ranking.gameObject.AddComponent<LayoutElement>().preferredHeight = Mathf.Clamp(snapshot.players.Count * 105 + 50, 270, 480);
            UI.Vertical(ranking.transform, 10, new RectOffset(18, 18, 15, 15), TextAnchor.UpperCenter);
            var rankTitle = UI.Text("RankTitle", ranking.transform, "رتبه‌بندی", 33, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            rankTitle.gameObject.AddComponent<LayoutElement>().preferredHeight = 50;
            foreach (var player in snapshot.players.OrderBy(p => p.finishRank <= 0 ? 99 : p.finishRank))
            {
                var rank = player.finishRank <= 0 ? "-" : player.finishRank.ToString();
                ScreenWidgets.ListRow(App, ranking.transform, player.finishRank == 1 ? "♛" : "♙", player.displayName, $"خانه پایانی: {player.position}", $"رتبه {rank}", player.finishRank == 1 ? UI.Theme.gold : UI.Theme.royalBlue, null, 88);
            }

            var localPlayer = snapshot.players.FirstOrDefault(p => p.id == "local" || (p.id != null && p.id.StartsWith("local_")));
            var localWon = localPlayer != null && localPlayer.finishRank == 1;
            var coinReward = localWon ? 250 : 100;
            var xpReward = localWon ? 120 : 60;
            var trophyReward = localWon ? 18 : -6;
            var rewards = UI.Rect("Rewards", column);
            rewards.AddComponent<LayoutElement>().preferredHeight = 130;
            UI.Horizontal(rewards.transform, 10);
            ScreenWidgets.StatTile(App, rewards.transform, "coin", "سکه", $"+{coinReward}", UI.Theme.gold);
            ScreenWidgets.StatTile(App, rewards.transform, "XP", "تجربه", $"+{xpReward}", UI.Theme.teal);
            ScreenWidgets.StatTile(App, rewards.transform, "trophy", "امتیاز لیگ", trophyReward >= 0 ? $"+{trophyReward}" : trophyReward.ToString(), new Color32(113, 66, 191, 255));

            UI.Button("Replay", column, "بازی مجدد", Replay, true);
            var bottom = UI.Rect("BottomButtons", column);
            bottom.AddComponent<LayoutElement>().preferredHeight = 76;
            UI.Horizontal(bottom.transform, 12);
            UI.Button("Home", bottom.transform, "بازگشت به خانه", () => App.Navigation.Reset(AppRoute.Home), false);
            UI.Button("Share", bottom.transform, "اشتراک نتیجه", () =>
            {
                GUIUtility.systemCopyBuffer = $"نتیجه بازی مار و پله پادشاهی: {winner.displayName} برنده شد";
                Toast("متن نتیجه کپی شد");
            }, false);
        }


        private void ApplyRewardsOnce(MatchSnapshot snapshot)
        {
            if (snapshot == null || string.IsNullOrWhiteSpace(snapshot.matchId)) return;
            var local = snapshot.players.FirstOrDefault(p => p.id == "local" || (p.id != null && p.id.StartsWith("local_")));
            if (local == null) return;
            var won = local.finishRank == 1;
            var applied = Get<IProfileService>().TryApplyMatchRewards(snapshot.matchId, won, won ? 250 : 100, won ? 120 : 60, won ? 18 : -6);
            if (applied)
            {
                var mode = Get<IMatchSessionService>().ModeName ?? string.Empty;
                Get<ICatalogService>().RecordMatchCompleted(mode.Contains("آنلاین"), won);
            }
        }

        private void Replay()
        {
            var session = Get<IMatchSessionService>();
            if (session.CurrentConfig == null)
                session.CurrentConfig = MatchConfigFactory.CreateBotMatch(2, new RuleSet());
            session.CurrentConfig.matchId = Guid.NewGuid().ToString("N");
            session.LastSnapshot = null;
            Navigate(AppRoute.Gameplay);
        }
    }
}
