using Menchino.RoyalSnakesLadders.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class SupportScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Support;
        private TMP_InputField _message;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 6);
            RoyalChrome.BuildHeader(App, column, "پشتیبانی");
            var scroll = UI.ScrollView("SupportScroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 10, new RectOffset(12, 12, 12, 12), TextAnchor.UpperCenter);
            ScreenWidgets.SectionTitle(App, content, "پرسش‌های متداول");
            ScreenWidgets.ListRow(App, content, "?", "چرا بازی آنلاین متصل نمی‌شود؟", "اتصال اینترنت و نسخه بازی را بررسی کنید", "پاسخ", UI.Theme.royalBlue, () => Toast("در نسخه آنلاین، وضعیت سرور نیز نمایش داده می‌شود"));
            ScreenWidgets.ListRow(App, content, "●", "سکه خریداری‌شده نمایش داده نمی‌شود", "خرید باید پس از اعتبارسنجی رسید بازیابی شود", "پاسخ", UI.Theme.gold, () => Toast("رسید خرید را از فروشگاه بازیابی کنید"));
            ScreenWidgets.ListRow(App, content, "♟", "چگونه مهره را تغییر دهم؟", "از فروشگاه یا ویرایش پروفایل", "بازکردن", UI.Theme.success, () => Navigate(AppRoute.Shop));
            ScreenWidgets.ListRow(App, content, "§", "قوانین مسابقه چیست؟", "قوانین استاندارد و سفارشی", "مشاهده", UI.Theme.teal, () => Navigate(AppRoute.Rules));
            ScreenWidgets.SectionTitle(App, content, "ارسال پیام");
            _message = ScreenWidgets.Input(App, content, "شرح مشکل یا پیشنهاد");
            _message.lineType = TMP_InputField.LineType.MultiLineNewline;
            _message.characterLimit = 500;
            _message.GetComponent<LayoutElement>().preferredHeight = 180;
            UI.Button("Send", content, "ارسال پیام", Send, true);
            var device = UI.Text("Device", content, $"نسخه: {Application.version} | دستگاه: {SystemInfo.deviceModel}", 18, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            device.gameObject.AddComponent<LayoutElement>().preferredHeight = 50;
        }

        private void Send()
        {
            if (string.IsNullOrWhiteSpace(_message.text) || _message.text.Trim().Length < 8)
            {
                Toast("پیام باید حداقل ۸ نویسه داشته باشد");
                return;
            }
            Toast("پیام در صف ارسال قرار گرفت؛ اتصال API پشتیبانی برای انتشار لازم است");
            _message.text = string.Empty;
        }
    }
}
