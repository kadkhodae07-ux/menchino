using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class TutorialScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Tutorial;
        private readonly string[] _titles =
        {
            "معرفی تخته", "معرفی تاس", "پرتاب تاس", "حرکت مهره", "نردبان", "مار", "خانه ۱۰۰", "پایان آموزش"
        };
        private readonly string[] _descriptions =
        {
            "تخته ۱۰۰ خانه دارد و شماره‌ها در هر ردیف به‌صورت مارپیچی ادامه پیدا می‌کنند.",
            "تاس سه‌بعدی نتیجه حرکت را مشخص می‌کند و فقط در نوبت شما فعال است.",
            "دکمه پرتاب را لمس کنید؛ نتیجه ابتدا تعیین و سپس انیمیشن دقیقاً روی همان عدد متوقف می‌شود.",
            "مهره خانه‌به‌خانه حرکت می‌کند و تا پایان انیمیشن، ورودی دوباره پذیرفته نمی‌شود.",
            "اگر روی ابتدای نردبان قرار بگیرید، مهره به خانه بالاتر منتقل می‌شود.",
            "اگر روی سر مار قرار بگیرید، مهره در مسیر مار به خانه پایین‌تر می‌رود.",
            "برای رسیدن به خانه ۱۰۰ در قانون استاندارد، عدد دقیق لازم است.",
            "آموزش تمام شد. اکنون می‌توانید بازی اصلی را آغاز کنید."
        };
        private readonly string[] _symbols = { "▦", "⚄", "↻", "♟", "╫", "S", "100", "♛" };
        private int _step;
        private TMP_Text _title;
        private TMP_Text _description;
        private TMP_Text _symbol;
        private TMP_Text _stepText;
        private RectTransform _progressFill;
        private Button _next;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 16, 30);
            var top = UI.Rect("Top", column);
            top.AddComponent<LayoutElement>().preferredHeight = 76;
            UI.Horizontal(top.transform, 12);
            UI.Button("Skip", top.transform, "رد کردن", Finish, false);
            _stepText = UI.Text("Step", top.transform, "۱ از ۸", 25, UI.Theme.textSecondary, TextAlignmentOptions.Center, FontStyles.Bold);
            _stepText.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1;
            var spacer = UI.Rect("Spacer", top.transform);
            spacer.AddComponent<LayoutElement>().preferredWidth = 150;
            spacer.GetComponent<LayoutElement>().flexibleWidth = 0;

            var progress = UI.Panel("Progress", column, UI.Theme.navy, new Color32(1, 12, 28, 255), UI.Theme.darkGold, 14, 3);
            progress.gameObject.AddComponent<LayoutElement>().preferredHeight = 28;
            var fill = UI.Panel("Fill", progress.transform, UI.Theme.lightGold, UI.Theme.gold, UI.Theme.gold, 10, 1);
            _progressFill = fill.rectTransform;
            _progressFill.anchorMin = Vector2.zero;
            _progressFill.anchorMax = new Vector2(0.125f, 1);
            _progressFill.offsetMin = new Vector2(3, 3);
            _progressFill.offsetMax = new Vector2(-3, -3);

            var card = UI.Panel("TutorialCard", column, new Color32(9, 63, 104, 255), new Color32(2, 24, 50, 255), UI.Theme.gold, 30, 6);
            card.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(card.transform, 18, new RectOffset(34, 34, 40, 40), TextAnchor.MiddleCenter);
            _symbol = UI.Text("Symbol", card.transform, _symbols[0], 140, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            _symbol.gameObject.AddComponent<LayoutElement>().preferredHeight = 240;
            _title = UI.Text("Title", card.transform, _titles[0], 49, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            _title.gameObject.AddComponent<LayoutElement>().preferredHeight = 84;
            _description = UI.Text("Description", card.transform, _descriptions[0], 29, UI.Theme.textPrimary, TextAlignmentOptions.Center);
            _description.gameObject.AddComponent<LayoutElement>().preferredHeight = 230;
            var action = UI.Button("Action", card.transform, "نمایش مرحله", () => Toast("مرحله به‌صورت تعاملی نمایش داده شد"), false);
            action.GetComponent<LayoutElement>().preferredHeight = 66;
            _next = UI.Button("Next", column, "مرحله بعد", Next, true);
            Refresh();
        }

        private void Next()
        {
            if (_step >= _titles.Length - 1)
            {
                Finish();
                return;
            }
            _step++;
            Refresh();
        }

        private void Refresh()
        {
            UI.SetText(_title, _titles[_step]);
            UI.SetText(_description, _descriptions[_step]);
            UI.SetText(_symbol, _symbols[_step]);
            UI.SetText(_stepText, $"{_step + 1} از {_titles.Length}");
            _progressFill.anchorMax = new Vector2((_step + 1f) / _titles.Length, 1);
            var label = _next.GetComponentInChildren<TMP_Text>();
            UI.SetText(label, _step == _titles.Length - 1 ? "ورود به بازی" : "مرحله بعد");
        }

        private void Finish()
        {
            var save = Get<ISaveService>();
            save.Current.settings.tutorialCompleted = true;
            save.Save();
            App.Navigation.Reset(AppRoute.Home);
        }
    }
}
