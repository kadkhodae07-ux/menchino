using System.Linq;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class LeagueScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.League;
        public override bool ShowBottomNavigation => true;
        public override bool ShowTopStatusBar => true;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 4);
            RoyalChrome.BuildHeader(App, column, "لیگ و رتبه‌بندی");
            var leaguePanel = UI.Panel("LeaguePanel", column, new Color32(25, 46, 103, 255), new Color32(8, 21, 57, 255), UI.Theme.gold, 24, 5);
            leaguePanel.gameObject.AddComponent<LayoutElement>().preferredHeight = 360;
            UI.Vertical(leaguePanel.transform, 9, new RectOffset(18, 18, 16, 16), TextAnchor.MiddleCenter);
            var topRow = UI.Rect("TopRow", leaguePanel.transform);
            topRow.AddComponent<LayoutElement>().preferredHeight = 120;
            UI.Horizontal(topRow.transform, 12);
            UI.IconBadge("LeagueBadge", topRow.transform, "♦", new Color32(106, 59, 179, 255), 104);
            var leagueTextRoot = UI.Rect("LeagueTexts", topRow.transform);
            leagueTextRoot.AddComponent<LayoutElement>().flexibleWidth = 1;
            UI.Vertical(leagueTextRoot.transform, 0, new RectOffset(4, 4, 4, 4), TextAnchor.MiddleRight);
            var title = UI.Text("LeagueTitle", leagueTextRoot.transform, "لیگ الماس", 39, UI.Theme.lightGold, TextAlignmentOptions.Right, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 56;
            var range = UI.Text("Range", leagueTextRoot.transform, "۵۲۰۰ تا ۵۵۰۰ امتیاز", 24, UI.Theme.textSecondary, TextAlignmentOptions.Right);
            range.gameObject.AddComponent<LayoutElement>().preferredHeight = 42;
            var rank = UI.Text("Rank", topRow.transform, "رتبه ۲۴", 31, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            rank.gameObject.AddComponent<LayoutElement>().preferredWidth = 145;
            rank.gameObject.GetComponent<LayoutElement>().flexibleWidth = 0;
            UI.Progress("Progress", leaguePanel.transform, 0.40f, new Color32(134, 70, 205, 255));
            var season = UI.Text("Season", leaguePanel.transform, "پایان فصل: ۱۲ روز و ۸ ساعت", 23, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            season.gameObject.AddComponent<LayoutElement>().preferredHeight = 42;
            var rewards = UI.Rect("Rewards", leaguePanel.transform);
            rewards.AddComponent<LayoutElement>().preferredHeight = 115;
            UI.Horizontal(rewards.transform, 8);
            ScreenWidgets.StatTile(App, rewards.transform, "▣", "صندوق", "الماس", new Color32(110, 61, 177, 255));
            ScreenWidgets.StatTile(App, rewards.transform, "●", "سکه", "۵۰۰۰", UI.Theme.gold);
            ScreenWidgets.StatTile(App, rewards.transform, "♦", "الماس", "۳۰۰", new Color32(157, 78, 218, 255));

            ScreenWidgets.SectionTitle(App, column, "رتبه‌بندی بازیکنان");
            var scroll = UI.ScrollView("Ranking", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 6, new RectOffset(8, 8, 8, 8), TextAnchor.UpperCenter);
            var currentId = Get<IProfileService>().Profile.userId;
            foreach (var entry in Get<ICatalogService>().LeagueEntries.OrderBy(x => x.rank))
            {
                var current = entry.userId == currentId;
                ScreenWidgets.ListRow(App, content, entry.rank <= 3 ? "♛" : entry.rank.ToString(), entry.name, entry.league, entry.score.ToString("N0"), current ? UI.Theme.gold : new Color32(94, 58, 170, 255), null, current ? 100 : 88);
            }
            UI.Button("RewardsButton", column, "جوایز فصل", () => Toast("جوایز پس از پایان فصل قابل دریافت هستند"), true);
        }
    }
}
