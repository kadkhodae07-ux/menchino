using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class PausePopupScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.PausePopup;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var dim = UI.Image("Dim", page, new Color(0, 0, 0, 0.62f), RoyalSpriteCache.Solid(Color.white));
            dim.rectTransform.anchorMin = Vector2.zero;
            dim.rectTransform.anchorMax = Vector2.one;
            dim.rectTransform.offsetMin = Vector2.zero;
            dim.rectTransform.offsetMax = Vector2.zero;
            var dialog = UI.Panel("PauseDialog", page, new Color32(10, 67, 110, 255), new Color32(2, 24, 51, 255), UI.Theme.gold, 30, 6);
            dialog.rectTransform.anchorMin = new Vector2(0.17f, 0.24f);
            dialog.rectTransform.anchorMax = new Vector2(0.83f, 0.76f);
            dialog.rectTransform.offsetMin = Vector2.zero;
            dialog.rectTransform.offsetMax = Vector2.zero;
            UI.Vertical(dialog.transform, 14, new RectOffset(34, 34, 30, 30), TextAnchor.MiddleCenter);
            UI.IconBadge("Pause", dialog.transform, "Ⅱ", UI.Theme.royalBlue, 110);
            var title = UI.Text("Title", dialog.transform, "توقف بازی", 50, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 82;
            UI.Button("Continue", dialog.transform, "ادامه بازی", Back, true);
            UI.Button("Restart", dialog.transform, "شروع مجدد", Restart, false);
            UI.Button("Settings", dialog.transform, "تنظیمات صدا", () => Navigate(AppRoute.Settings), false);
            UI.Button("Home", dialog.transform, "خروج به خانه", () => Confirm("خروج از بازی", "مسابقه فعلی از دست می‌رود.", "خروج", () => App.Navigation.Reset(AppRoute.Home)), false, true);
        }

        private void Restart()
        {
            var session = Get<IMatchSessionService>();
            if (session.CurrentConfig == null) session.CurrentConfig = MatchConfigFactory.CreateBotMatch(2, new Menchino.RoyalSnakesLadders.Data.RuleSet());
            App.Navigation.Replace(AppRoute.Gameplay);
        }
    }
}
