using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class LanguageScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Language;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 22, 54);
            var spacer = UI.Rect("Spacer", column);
            spacer.AddComponent<LayoutElement>().preferredHeight = 180;
            UI.IconBadge("LanguageIcon", column, "文", UI.Theme.royalBlue, 126);
            var title = UI.Text("Title", column, "زبان بازی را انتخاب کنید", 52, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 100;
            UI.Button("Persian", column, "فارسی", () => Select("fa"), true);
            UI.Button("English", column, "English", () => Select("en"), false);
            UI.Button("Continue", column, "ادامه", () => Navigate(AppRoute.Login), true);
        }

        private void Select(string language)
        {
            Get<ILocalizationService>().SetLanguage(language);
            Toast(language == "fa" ? "زبان فارسی انتخاب شد" : "English selected");
        }
    }
}
