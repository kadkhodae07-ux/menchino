using System;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class MissionsScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Missions;
        public override bool ShowTopStatusBar => true;
        private RectTransform _content;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 10, 6);
            RoyalChrome.BuildHeader(App, column, "مأموریت‌های روزانه");
            var tabs = UI.Rect("Tabs", column);
            tabs.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(tabs.transform, 8);
            UI.Button("Daily", tabs.transform, "روزانه", BuildMissions, false);
            UI.Button("Weekly", tabs.transform, "هفتگی", () => Toast("مأموریت‌های هفتگی در بروزرسانی داده نمایش داده می‌شوند"), false);
            UI.Button("Season", tabs.transform, "فصلی", () => Navigate(AppRoute.League), false);
            UI.Button("Achievements", tabs.transform, "دستاوردها", () => Navigate(AppRoute.Profile), false);
            var scroll = UI.ScrollView("Missions", column, out _content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(_content, 11, new RectOffset(10, 10, 10, 10), TextAnchor.UpperCenter);
            BuildMissions();
        }

        private void BuildMissions()
        {
            if (_content == null) return;
            foreach (Transform child in _content) Destroy(child.gameObject);
            foreach (var mission in Get<ICatalogService>().Missions) BuildMissionCard(mission);
        }

        private void BuildMissionCard(MissionData mission)
        {
            var panel = UI.Panel("Mission_" + mission.id, _content, new Color32(8, 57, 95, 255), new Color32(2, 23, 49, 255), mission.claimed ? UI.Theme.success : UI.Theme.darkGold, 20, 3);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 185;
            UI.Vertical(panel.transform, 5, new RectOffset(16, 16, 12, 12), TextAnchor.MiddleCenter);
            var top = UI.Rect("Top", panel.transform);
            top.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(top.transform, 10);
            UI.IconBadge("Icon", top.transform, "★", mission.progress >= mission.target ? UI.Theme.success : UI.Theme.royalBlue, 58);
            var textRoot = UI.Rect("Texts", top.transform);
            textRoot.AddComponent<LayoutElement>().flexibleWidth = 1;
            UI.Vertical(textRoot.transform, 0, new RectOffset(2, 2, 2, 2), TextAnchor.MiddleRight);
            var title = UI.Text("Title", textRoot.transform, mission.title, 25, UI.Theme.textPrimary, TextAlignmentOptions.Right, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 38;
            var description = UI.Text("Description", textRoot.transform, mission.description, 18, UI.Theme.textSecondary, TextAlignmentOptions.Right);
            description.gameObject.AddComponent<LayoutElement>().preferredHeight = 28;
            var reward = UI.Text("Reward", top.transform, mission.rewardCoins + " سکه", 21, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            reward.gameObject.AddComponent<LayoutElement>().preferredWidth = 130;
            reward.gameObject.GetComponent<LayoutElement>().flexibleWidth = 0;
            UI.Progress("Progress", panel.transform, mission.Progress01, mission.progress >= mission.target ? UI.Theme.success : UI.Theme.gold);
            var bottom = UI.Rect("Bottom", panel.transform);
            bottom.AddComponent<LayoutElement>().preferredHeight = 52;
            UI.Horizontal(bottom.transform, 10);
            var progress = UI.Text("ProgressText", bottom.transform, $"{mission.progress} / {mission.target}", 21, UI.Theme.textSecondary, TextAlignmentOptions.Right, FontStyles.Bold);
            progress.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1;
            var button = UI.Button("Claim", bottom.transform, mission.claimed ? "دریافت‌شده" : mission.progress >= mission.target ? "دریافت" : "در حال انجام", () => Claim(mission.id), false);
            button.GetComponent<LayoutElement>().preferredWidth = 190;
            button.GetComponent<LayoutElement>().flexibleWidth = 0;
            button.interactable = !mission.claimed && mission.progress >= mission.target;
        }

        private void Claim(string id)
        {
            if (Get<ICatalogService>().ClaimMission(id))
            {
                Toast("جایزه مأموریت دریافت شد");
                BuildMissions();
            }
            else Toast("این مأموریت هنوز قابل دریافت نیست");
        }
    }
}
