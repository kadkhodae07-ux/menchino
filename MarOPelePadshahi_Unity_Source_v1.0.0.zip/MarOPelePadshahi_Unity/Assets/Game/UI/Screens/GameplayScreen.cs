using System.Collections;
using System.Collections.Generic;
using Menchino.RoyalSnakesLadders.Board;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Players;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class GameplayScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Gameplay;
        private MatchCoordinator _coordinator;
        private RoyalDie3D _die;
        private Button _rollButton;
        private TMP_Text _turnLabel;
        private readonly List<GameplayPlayerPanel> _panels = new List<GameplayPlayerPanel>();
        private bool _resultScheduled;

        protected override void BuildScreen()
        {
            var session = Get<IMatchSessionService>();
            var config = session.CurrentConfig ?? MatchConfigFactory.CreateBotMatch(2, new RuleSet());
            var page = CreatePageRoot();
            page.offsetMin = new Vector2(12, 10);
            page.offsetMax = new Vector2(-12, -10);

            BuildHeader(page, session.ModeName);
            BuildPlayerPanels(page, config);

            var boardObject = UI.Rect("Board", page);
            var boardRect = boardObject.GetComponent<RectTransform>();
            boardRect.anchorMin = new Vector2(0.01f, 0.285f);
            boardRect.anchorMax = new Vector2(0.99f, 0.80f);
            boardRect.offsetMin = Vector2.zero;
            boardRect.offsetMax = Vector2.zero;
            var aspect = boardObject.AddComponent<AspectRatioFitter>();
            aspect.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
            aspect.aspectRatio = 1f;
            var board = boardObject.AddComponent<BoardView>();
            board.Build(UI, config.board);

            var diePanel = UI.Panel("DiePanel", page, new Color32(8, 56, 92, 245), new Color32(2, 22, 46, 245), UI.Theme.gold, 26, 5);
            diePanel.rectTransform.anchorMin = new Vector2(0.25f, 0.015f);
            diePanel.rectTransform.anchorMax = new Vector2(0.75f, 0.265f);
            diePanel.rectTransform.offsetMin = Vector2.zero;
            diePanel.rectTransform.offsetMax = Vector2.zero;
            var raw = UI.Rect("DieRender", diePanel.transform).AddComponent<RawImage>();
            raw.rectTransform.anchorMin = new Vector2(0.15f, 0.24f);
            raw.rectTransform.anchorMax = new Vector2(0.85f, 0.98f);
            raw.rectTransform.offsetMin = Vector2.zero;
            raw.rectTransform.offsetMax = Vector2.zero;
            _die = raw.gameObject.AddComponent<RoyalDie3D>();
            _die.Initialize(Get<IAudioService>());
            _rollButton = UI.Button("Roll", diePanel.transform, "تاس را بینداز", RequestRoll, true);
            var rollRect = _rollButton.GetComponent<RectTransform>();
            rollRect.anchorMin = new Vector2(0.08f, 0.02f);
            rollRect.anchorMax = new Vector2(0.92f, 0.28f);
            rollRect.offsetMin = Vector2.zero;
            rollRect.offsetMax = Vector2.zero;

            var emoji = UI.Button("Emoji", page, "☺", () => Toast("واکنش ارسال شد"), false);
            var emojiRect = emoji.GetComponent<RectTransform>();
            emojiRect.anchorMin = new Vector2(0.01f, 0.06f);
            emojiRect.anchorMax = new Vector2(0.16f, 0.13f);
            emojiRect.offsetMin = Vector2.zero;
            emojiRect.offsetMax = Vector2.zero;
            var rules = UI.Button("Rules", page, "قوانین", () => Navigate(AppRoute.Rules), false);
            var rulesRect = rules.GetComponent<RectTransform>();
            rulesRect.anchorMin = new Vector2(0.01f, 0.145f);
            rulesRect.anchorMax = new Vector2(0.19f, 0.215f);
            rulesRect.offsetMin = Vector2.zero;
            rulesRect.offsetMax = Vector2.zero;

            _coordinator = gameObject.AddComponent<MatchCoordinator>();
            _coordinator.Initialize(App, config, board, _die, OnMatchChanged, session.BotDifficulty);
        }

        private void BuildHeader(RectTransform page, string modeName)
        {
            var close = UI.Button("Close", page, "×", () => Confirm("خروج از بازی", "مسابقه فعلی را ترک می‌کنید؟", "خروج", () => Navigate(AppRoute.Home)), false, true);
            var closeRect = close.GetComponent<RectTransform>();
            closeRect.anchorMin = new Vector2(0.01f, 0.93f);
            closeRect.anchorMax = new Vector2(0.13f, 0.99f);
            closeRect.offsetMin = Vector2.zero;
            closeRect.offsetMax = Vector2.zero;
            var sound = UI.Button("Sound", page, "♪", () => Toast("تنظیمات صدا از صفحه تنظیمات در دسترس است"), false);
            var soundRect = sound.GetComponent<RectTransform>();
            soundRect.anchorMin = new Vector2(0.87f, 0.93f);
            soundRect.anchorMax = new Vector2(0.99f, 0.99f);
            soundRect.offsetMin = Vector2.zero;
            soundRect.offsetMax = Vector2.zero;
            var title = UI.Text("GameTitle", page, "مار و پله پادشاهی", 46, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.rectTransform.anchorMin = new Vector2(0.14f, 0.935f);
            title.rectTransform.anchorMax = new Vector2(0.86f, 0.995f);
            title.rectTransform.offsetMin = Vector2.zero;
            title.rectTransform.offsetMax = Vector2.zero;
            _turnLabel = UI.Text("Turn", page, modeName, 22, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            _turnLabel.rectTransform.anchorMin = new Vector2(0.25f, 0.895f);
            _turnLabel.rectTransform.anchorMax = new Vector2(0.75f, 0.935f);
            _turnLabel.rectTransform.offsetMin = Vector2.zero;
            _turnLabel.rectTransform.offsetMax = Vector2.zero;
        }

        private void BuildPlayerPanels(RectTransform page, MatchConfig config)
        {
            var positions = GetPanelAnchors(config.players.Count);
            var accents = new[]
            {
                new Color32(34, 125, 211, 255),
                new Color32(207, 61, 49, 255),
                new Color32(56, 171, 72, 255),
                new Color32(128, 67, 197, 255)
            };
            for (var i = 0; i < config.players.Count; i++)
            {
                var go = UI.Rect("PlayerPanel_" + i, page);
                var rect = go.GetComponent<RectTransform>();
                rect.anchorMin = positions[i].min;
                rect.anchorMax = positions[i].max;
                rect.offsetMin = Vector2.zero;
                rect.offsetMax = Vector2.zero;
                var panel = go.AddComponent<GameplayPlayerPanel>();
                panel.Build(UI, config.players[i], accents[config.players[i].colorIndex]);
                _panels.Add(panel);
            }
        }

        private static List<(Vector2 min, Vector2 max)> GetPanelAnchors(int count)
        {
            if (count == 2)
                return new List<(Vector2, Vector2)> { (new Vector2(0.02f, 0.805f), new Vector2(0.48f, 0.89f)), (new Vector2(0.52f, 0.805f), new Vector2(0.98f, 0.89f)) };
            if (count == 3)
                return new List<(Vector2, Vector2)>
                {
                    (new Vector2(0.02f, 0.805f), new Vector2(0.48f, 0.89f)),
                    (new Vector2(0.52f, 0.805f), new Vector2(0.98f, 0.89f)),
                    (new Vector2(0.02f, 0.19f), new Vector2(0.25f, 0.275f))
                };
            return new List<(Vector2, Vector2)>
            {
                (new Vector2(0.02f, 0.805f), new Vector2(0.48f, 0.89f)),
                (new Vector2(0.52f, 0.805f), new Vector2(0.98f, 0.89f)),
                (new Vector2(0.02f, 0.19f), new Vector2(0.25f, 0.275f)),
                (new Vector2(0.75f, 0.19f), new Vector2(0.98f, 0.275f))
            };
        }

        private void RequestRoll()
        {
            _coordinator?.RequestRoll();
        }

        private void OnMatchChanged(MatchSnapshot snapshot)
        {
            if (snapshot == null) return;
            UI.SetText(_turnLabel, snapshot.statusText);
            for (var i = 0; i < _panels.Count && i < snapshot.players.Count; i++)
                _panels[i].UpdateState(snapshot.players[i], i == snapshot.activePlayerIndex && snapshot.phase != MatchPhase.Finished);
            _rollButton.interactable = snapshot.phase == MatchPhase.AwaitingRoll && snapshot.ActivePlayer.controlType == PlayerControlType.LocalHuman && !_coordinator.IsAnimating;
            if (snapshot.phase == MatchPhase.Finished && !_resultScheduled)
            {
                _resultScheduled = true;
                var session = Get<IMatchSessionService>();
                session.LastSnapshot = snapshot;
                StartCoroutine(OpenResults());
            }
        }

        private IEnumerator OpenResults()
        {
            yield return new WaitForSecondsRealtime(1.1f);
            Navigate(AppRoute.Results);
        }
    }
}
