using Menchino.RoyalSnakesLadders.Bots;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class BotSetupScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.BotSetup;
        public override bool ShowTopStatusBar => true;
        private int _playerCount = 2;
        private BotDifficulty _difficulty = BotDifficulty.Medium;
        private readonly RuleSet _rules = new RuleSet();
        private TMP_Text _countLabel;
        private TMP_Text _difficultyLabel;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 12, 6);
            RoyalChrome.BuildHeader(App, column, "تنظیمات بازی با ربات");
            var scroll = UI.ScrollView("Scroll", column, out var content);
            scroll.gameObject.AddComponent<LayoutElement>().flexibleHeight = 1;
            UI.Vertical(content, 13, new RectOffset(12, 12, 12, 12), TextAnchor.UpperCenter);

            ScreenWidgets.SectionTitle(App, content, "تعداد بازیکنان");
            _countLabel = UI.Text("CountValue", content, "۲ بازیکن", 30, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            _countLabel.gameObject.AddComponent<LayoutElement>().preferredHeight = 50;
            var countRow = UI.Rect("CountButtons", content);
            countRow.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(countRow.transform, 10);
            UI.Button("Two", countRow.transform, "۲", () => SetPlayerCount(2), false);
            UI.Button("Three", countRow.transform, "۳", () => SetPlayerCount(3), false);
            UI.Button("Four", countRow.transform, "۴", () => SetPlayerCount(4), false);

            ScreenWidgets.SectionTitle(App, content, "سطح ربات");
            _difficultyLabel = UI.Text("DifficultyValue", content, "متوسط", 29, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            _difficultyLabel.gameObject.AddComponent<LayoutElement>().preferredHeight = 48;
            var difficultyRow = UI.Rect("DifficultyButtons", content);
            difficultyRow.AddComponent<LayoutElement>().preferredHeight = 72;
            UI.Horizontal(difficultyRow.transform, 8);
            UI.Button("Easy", difficultyRow.transform, "آسان", () => SetDifficulty(BotDifficulty.Easy), false);
            UI.Button("Medium", difficultyRow.transform, "متوسط", () => SetDifficulty(BotDifficulty.Medium), false);
            UI.Button("Hard", difficultyRow.transform, "سخت", () => SetDifficulty(BotDifficulty.Hard), false);
            UI.Button("Pro", difficultyRow.transform, "حرفه‌ای", () => SetDifficulty(BotDifficulty.Professional), false);

            ScreenWidgets.SectionTitle(App, content, "قوانین");
            ScreenWidgets.SettingRow(App, content, "6", "نوبت اضافه با عدد ۶", "با آوردن ۶ دوباره تاس بینداز", _rules.extraTurnOnSix, v => _rules.extraTurnOnSix = v);
            ScreenWidgets.SettingRow(App, content, "Ⅲ", "سوختن سومین ۶", "سه عدد ۶ متوالی نوبت را می‌سوزاند", _rules.burnTurnOnThirdSix, v => _rules.burnTurnOnThirdSix = v);
            ScreenWidgets.SettingRow(App, content, "100", "عدد دقیق خانه ۱۰۰", "برای پایان باید دقیقاً به خانه ۱۰۰ رسید", _rules.exactRollToFinish, v => _rules.exactRollToFinish = v);
            ScreenWidgets.SettingRow(App, content, "↶", "برخورد مهره‌ها", "مهره حریف به خانه شروع برگردد", _rules.captureEnabled, v => _rules.captureEnabled = v);

            var start = UI.Button("Start", column, "شروع بازی", StartMatch, true);
            start.GetComponent<LayoutElement>().preferredHeight = 82;
        }

        private void SetPlayerCount(int value)
        {
            _playerCount = Mathf.Clamp(value, 2, 4);
            UI.SetText(_countLabel, $"{_playerCount} بازیکن");
        }

        private void SetDifficulty(BotDifficulty value)
        {
            _difficulty = value;
            UI.SetText(_difficultyLabel, DifficultyLabel(value));
        }

        private static string DifficultyLabel(BotDifficulty value)
        {
            return value == BotDifficulty.Easy ? "آسان"
                : value == BotDifficulty.Medium ? "متوسط"
                : value == BotDifficulty.Hard ? "سخت"
                : "حرفه‌ای";
        }

        private void StartMatch()
        {
            var session = Get<IMatchSessionService>();
            session.CurrentConfig = MatchConfigFactory.CreateBotMatch(_playerCount, _rules);
            session.ModeName = "بازی با ربات - " + DifficultyLabel(_difficulty);
            session.BotDifficulty = _difficulty;
            Navigate(AppRoute.Gameplay);
        }
    }
}
