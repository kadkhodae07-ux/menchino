using System.Linq;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class PiecePickerPopupScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.PiecePickerPopup;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var dim = UI.Image("Dim", page, new Color(0, 0, 0, 0.52f), RoyalSpriteCache.Solid(Color.white));
            dim.rectTransform.anchorMin = Vector2.zero;
            dim.rectTransform.anchorMax = Vector2.one;
            dim.rectTransform.offsetMin = Vector2.zero;
            dim.rectTransform.offsetMax = Vector2.zero;
            var dialog = UI.Panel("Dialog", page, new Color32(9, 61, 101, 255), new Color32(2, 23, 49, 255), UI.Theme.gold, 28, 6);
            dialog.rectTransform.anchorMin = new Vector2(0.08f, 0.20f);
            dialog.rectTransform.anchorMax = new Vector2(0.92f, 0.82f);
            dialog.rectTransform.offsetMin = Vector2.zero;
            dialog.rectTransform.offsetMax = Vector2.zero;
            UI.Vertical(dialog.transform, 12, new RectOffset(24, 24, 22, 22), TextAnchor.UpperCenter);
            var title = UI.Text("Title", dialog.transform, "کدام مهره را انتخاب می‌کنید؟", 38, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 74;
            var gridRoot = UI.Rect("Grid", dialog.transform);
            gridRoot.AddComponent<LayoutElement>().flexibleHeight = 1;
            var grid = gridRoot.AddComponent<GridLayoutGroup>();
            grid.cellSize = new Vector2(250, 180);
            grid.spacing = new Vector2(12, 12);
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = 3;
            grid.childAlignment = TextAnchor.UpperCenter;
            foreach (var product in Get<ICatalogService>().Products.Where(x => x.category == ProductCategory.Piece && x.owned))
            {
                var item = UI.Panel("Piece", gridRoot.transform, product.selected ? UI.Theme.success : UI.Theme.royalBlue, UI.Theme.navy, product.selected ? UI.Theme.lightGold : UI.Theme.darkGold, 18, product.selected ? 5 : 2);
                UI.Vertical(item.transform, 4, new RectOffset(8, 8, 8, 8), TextAnchor.MiddleCenter);
                UI.IconBadge("Icon", item.transform, "♟", product.iconKey.Contains("green") ? UI.Theme.success : UI.Theme.gold, 74);
                var label = UI.Text("Label", item.transform, product.title, 20, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
                label.gameObject.AddComponent<LayoutElement>().preferredHeight = 50;
                var button = item.gameObject.AddComponent<Button>();
                button.targetGraphic = item;
                button.onClick.AddListener(() =>
                {
                    Get<ICatalogService>().Select(product.id);
                    Toast("مهره انتخاب شد");
                    Back();
                });
            }
            UI.Button("Close", dialog.transform, "بستن", Back, false);
        }
    }
}
