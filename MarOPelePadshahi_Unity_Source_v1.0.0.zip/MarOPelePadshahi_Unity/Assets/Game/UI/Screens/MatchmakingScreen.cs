using System.Collections;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Game;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class MatchmakingScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.Matchmaking;
        public override bool ShowTopStatusBar => true;
        private TMP_Text _status;
        private TMP_Text _timer;
        private bool _cancelled;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 20, 36);
            RoyalChrome.BuildHeader(App, column, "حریف‌یابی آنلاین");
            var spacer = UI.Rect("Spacer", column);
            spacer.AddComponent<LayoutElement>().preferredHeight = 140;
            UI.IconBadge("Search", column, "VS", new Color32(94, 62, 176, 255), 150);
            _status = UI.Text("Status", column, "در حال جست‌وجوی حریف...", 38, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            _status.gameObject.AddComponent<LayoutElement>().preferredHeight = 80;
            _timer = UI.Text("Timer", column, "۰۰:۰۰", 30, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            _timer.gameObject.AddComponent<LayoutElement>().preferredHeight = 60;
            var league = UI.Text("League", column, "محدوده جست‌وجو: لیگ الماس", 24, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            league.gameObject.AddComponent<LayoutElement>().preferredHeight = 54;
            var hint = UI.Text("Hint", column, "در صورت طولانی‌شدن انتظار، ربات هم‌سطح جایگزین می‌شود.", 22, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            hint.gameObject.AddComponent<LayoutElement>().preferredHeight = 80;
            UI.Button("Cancel", column, "لغو جست‌وجو", Cancel, false, true);
            StartCoroutine(SearchRoutine());
        }

        private IEnumerator SearchRoutine()
        {
            var status = Get<INetworkService>().StartMatchmaking();
            if (status.state == "قطع اینترنت")
            {
                UI.SetText(_status, "اتصال اینترنت در دسترس نیست");
                yield break;
            }
            var elapsed = 0f;
            while (elapsed < 3.2f && !_cancelled)
            {
                elapsed += Time.unscaledDeltaTime;
                UI.SetText(_timer, $"۰۰:{Mathf.FloorToInt(elapsed):00}");
                yield return null;
            }
            if (_cancelled) yield break;
            UI.SetText(_status, "حریف پیدا شد");
            yield return new WaitForSecondsRealtime(0.8f);
            var session = Get<IMatchSessionService>();
            session.CurrentConfig = MatchConfigFactory.CreateOnlinePreview();
            session.ModeName = "بازی آنلاین آزمایشی";
            Navigate(AppRoute.Gameplay);
        }

        private void Cancel()
        {
            _cancelled = true;
            Get<INetworkService>().CancelMatchmaking();
            Back();
        }
    }
}
