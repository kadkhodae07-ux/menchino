using System;
using Menchino.RoyalSnakesLadders.Core;
using Menchino.RoyalSnakesLadders.Data;
using Menchino.RoyalSnakesLadders.Services;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI.Screens
{
    public sealed class RewardChestScreen : RoyalScreenBase
    {
        public override AppRoute Route => AppRoute.RewardChest;
        public override bool ShowTopStatusBar => true;
        private Button _claimButton;
        private TMP_Text _timer;

        protected override void BuildScreen()
        {
            var page = CreatePageRoot();
            var column = ScreenWidgets.MainColumn(App, page, 14, 12);
            RoyalChrome.BuildHeader(App, column, "صندوق جوایز");
            var panel = UI.Panel("ChestPanel", column, new Color32(10, 65, 107, 255), new Color32(2, 24, 50, 255), UI.Theme.gold, 28, 6);
            panel.gameObject.AddComponent<LayoutElement>().preferredHeight = 520;
            UI.Vertical(panel.transform, 14, new RectOffset(24, 24, 24, 24), TextAnchor.MiddleCenter);
            UI.IconBadge("Chest", panel.transform, "▣", new Color32(138, 73, 175, 255), 190);
            var title = UI.Text("Title", panel.transform, "صندوق سلطنتی روزانه", 42, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 74;
            _timer = UI.Text("Timer", panel.transform, NextClaimText(), 25, UI.Theme.textSecondary, TextAlignmentOptions.Center);
            _timer.gameObject.AddComponent<LayoutElement>().preferredHeight = 58;
            _claimButton = UI.Button("Claim", panel.transform, "دریافت جایزه", Claim, true);
            _claimButton.interactable = CanClaim();

            ScreenWidgets.SectionTitle(App, column, "تقویم هفت‌روزه");
            var days = UI.Rect("Days", column);
            days.AddComponent<LayoutElement>().preferredHeight = 170;
            UI.Horizontal(days.transform, 7, new RectOffset(0, 0, 0, 0), TextAnchor.MiddleCenter);
            var streak = Get<ISaveService>().Current.dailyRewardStreak;
            for (var day = 1; day <= 7; day++)
            {
                var panelDay = UI.Panel("Day" + day, days.transform, day <= streak ? UI.Theme.success : UI.Theme.royalBlue, UI.Theme.navy, day == streak + 1 ? UI.Theme.lightGold : UI.Theme.darkGold, 16, day == streak + 1 ? 5 : 2);
                UI.Vertical(panelDay.transform, 2, new RectOffset(5, 5, 8, 8), TextAnchor.MiddleCenter);
                var dayText = UI.Text("DayLabel", panelDay.transform, "روز " + day, 18, UI.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
                dayText.gameObject.AddComponent<LayoutElement>().preferredHeight = 38;
                var reward = UI.Text("Reward", panelDay.transform, day == 7 ? "۵۰۰" : (day * 50).ToString(), 23, UI.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
                reward.gameObject.AddComponent<LayoutElement>().preferredHeight = 45;
                var type = UI.Text("Type", panelDay.transform, "سکه", 17, UI.Theme.textSecondary, TextAlignmentOptions.Center);
                type.gameObject.AddComponent<LayoutElement>().preferredHeight = 30;
            }
            ScreenWidgets.InfoCard(App, column, "♜", "صندوق معمولی", "پس از سه مسابقه قابل بازشدن", UI.Theme.royalBlue, () => Toast("۲ مسابقه تا بازشدن باقی مانده"), 125);
            ScreenWidgets.InfoCard(App, column, "♛", "صندوق طلایی", "جایزه ویژه بردهای پیاپی", UI.Theme.gold, () => Toast("برای این صندوق ۳ برد پیاپی لازم است"), 125);
        }

        private bool CanClaim()
        {
            var last = Get<ISaveService>().Current.dailyRewardLastClaimUnix;
            if (last <= 0) return true;
            return DateTimeOffset.UtcNow.ToUnixTimeSeconds() - last >= 86400;
        }

        private string NextClaimText()
        {
            if (CanClaim()) return "جایزه امروز آماده دریافت است";
            var remaining = 86400 - (DateTimeOffset.UtcNow.ToUnixTimeSeconds() - Get<ISaveService>().Current.dailyRewardLastClaimUnix);
            var hours = Mathf.Max(0, Mathf.CeilToInt(remaining / 3600f));
            return $"دریافت بعدی حدود {hours} ساعت دیگر";
        }

        private void Claim()
        {
            if (!CanClaim())
            {
                Toast("جایزه امروز قبلاً دریافت شده است");
                return;
            }
            var save = Get<ISaveService>();
            save.Current.dailyRewardLastClaimUnix = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            save.Current.dailyRewardStreak = save.Current.dailyRewardStreak >= 7 ? 1 : save.Current.dailyRewardStreak + 1;
            var amount = save.Current.dailyRewardStreak == 7 ? 500 : save.Current.dailyRewardStreak * 50;
            Get<IProfileService>().Add(CurrencyType.Coin, amount);
            save.Save();
            _claimButton.interactable = false;
            UI.SetText(_timer, NextClaimText());
            Toast($"{amount} سکه دریافت شد");
        }
    }
}
