using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    /// <summary>
    /// Lightweight procedural vector icons. Icons are rendered as UI geometry and never depend on emoji or screenshot crops.
    /// </summary>
    public sealed class RoyalIconGraphic : MaskableGraphic
    {
        public string iconKey = "star";

        public static bool CanRender(string token) => Resolve(token) != IconKind.Unknown;

        public void SetIcon(string token)
        {
            iconKey = token ?? string.Empty;
            SetVerticesDirty();
        }

        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();
            var rect = rectTransform.rect;
            var size = Mathf.Min(rect.width, rect.height);
            var center = rect.center;
            var scale = size * 0.42f;
            var kind = Resolve(iconKey);
            switch (kind)
            {
                case IconKind.Crown: Crown(vh, center, scale); break;
                case IconKind.Pawn: Pawn(vh, center, scale); break;
                case IconKind.Shop: Shop(vh, center, scale); break;
                case IconKind.Home: Home(vh, center, scale); break;
                case IconKind.Profile: Profile(vh, center, scale); break;
                case IconKind.Settings: Settings(vh, center, scale); break;
                case IconKind.Plus: Plus(vh, center, scale); break;
                case IconKind.Back: Back(vh, center, scale); break;
                case IconKind.Close: Close(vh, center, scale); break;
                case IconKind.Sound: Sound(vh, center, scale); break;
                case IconKind.Face: Face(vh, center, scale); break;
                case IconKind.Pause: Pause(vh, center, scale); break;
                case IconKind.Dice: Dice(vh, center, scale); break;
                case IconKind.Gem: Gem(vh, center, scale); break;
                case IconKind.Star: Star(vh, center, scale); break;
                case IconKind.Coin: Coin(vh, center, scale); break;
                case IconKind.Check: Check(vh, center, scale); break;
                case IconKind.Chest: Chest(vh, center, scale); break;
                case IconKind.Ladder: Ladder(vh, center, scale); break;
                case IconKind.Snake: Snake(vh, center, scale); break;
                case IconKind.Online: Online(vh, center, scale); break;
                case IconKind.Help: Help(vh, center, scale); break;
                case IconKind.Room: Room(vh, center, scale); break;
                case IconKind.Trophy: Trophy(vh, center, scale); break;
                case IconKind.Return: Return(vh, center, scale); break;
                case IconKind.Book: Book(vh, center, scale); break;
                case IconKind.Notification: Notification(vh, center, scale); break;
                case IconKind.Battery: Battery(vh, center, scale); break;
                case IconKind.Vibration: Vibration(vh, center, scale); break;
                case IconKind.Support: Support(vh, center, scale); break;
                default: Star(vh, center, scale); break;
            }
        }

        private enum IconKind
        {
            Unknown, Crown, Pawn, Shop, Home, Profile, Settings, Plus, Back, Close, Sound, Face, Pause,
            Dice, Gem, Star, Coin, Check, Chest, Ladder, Snake, Online, Help, Room, Trophy, Return, Book,
            Notification, Battery, Vibration, Support
        }

        private static IconKind Resolve(string token)
        {
            switch (token)
            {
                case "♔": case "♛": case "♚": case "crown": return IconKind.Crown;
                case "♟": case "♙": case "pawn": return IconKind.Pawn;
                case "♜": case "shop": return IconKind.Shop;
                case "⌂": case "home": return IconKind.Home;
                case "profile": case "user": return IconKind.Profile;
                case "⚙": case "settings": return IconKind.Settings;
                case "+": case "plus": return IconKind.Plus;
                case "←": case "back": return IconKind.Back;
                case "×": case "close": return IconKind.Close;
                case "♪": case "sound": return IconKind.Sound;
                case "☺": case "face": return IconKind.Face;
                case "Ⅱ": case "pause": return IconKind.Pause;
                case "⚄": case "dice": return IconKind.Dice;
                case "♦": case "◇": case "gem": return IconKind.Gem;
                case "★": case "star": return IconKind.Star;
                case "●": case "coin": return IconKind.Coin;
                case "✓": case "check": return IconKind.Check;
                case "▣": case "chest": return IconKind.Chest;
                case "╫": case "ladder": return IconKind.Ladder;
                case "S": case "snake": return IconKind.Snake;
                case "◎": case "online": return IconKind.Online;
                case "?": case "help": return IconKind.Help;
                case "⌗": case "room": return IconKind.Room;
                case "trophy": return IconKind.Trophy;
                case "↶": case "return": return IconKind.Return;
                case "book": return IconKind.Book;
                case "!": case "notification": return IconKind.Notification;
                case "◒": case "battery": return IconKind.Battery;
                case "≈": case "vibration": return IconKind.Vibration;
                case "☎": case "support": return IconKind.Support;
                default: return IconKind.Unknown;
            }
        }

        private void AddQuad(VertexHelper vh, Vector2 min, Vector2 max)
        {
            var i = vh.currentVertCount;
            vh.AddVert(new Vector3(min.x, min.y), color, Vector2.zero);
            vh.AddVert(new Vector3(min.x, max.y), color, Vector2.up);
            vh.AddVert(new Vector3(max.x, max.y), color, Vector2.one);
            vh.AddVert(new Vector3(max.x, min.y), color, Vector2.right);
            vh.AddTriangle(i, i + 1, i + 2); vh.AddTriangle(i, i + 2, i + 3);
        }

        private void AddTriangle(VertexHelper vh, Vector2 a, Vector2 b, Vector2 c)
        {
            var i = vh.currentVertCount;
            vh.AddVert(a, color, Vector2.zero); vh.AddVert(b, color, Vector2.up); vh.AddVert(c, color, Vector2.one);
            vh.AddTriangle(i, i + 1, i + 2);
        }

        private void AddPolygon(VertexHelper vh, IList<Vector2> points)
        {
            if (points == null || points.Count < 3) return;
            var center = Vector2.zero;
            for (var i = 0; i < points.Count; i++) center += points[i];
            center /= points.Count;
            var ci = vh.currentVertCount;
            vh.AddVert(center, color, new Vector2(0.5f, 0.5f));
            for (var i = 0; i < points.Count; i++) vh.AddVert(points[i], color, Vector2.zero);
            for (var i = 0; i < points.Count; i++) vh.AddTriangle(ci, ci + 1 + i, ci + 1 + (i + 1) % points.Count);
        }

        private void AddCircle(VertexHelper vh, Vector2 center, float radius, int segments = 24)
        {
            var ci = vh.currentVertCount;
            vh.AddVert(center, color, new Vector2(0.5f, 0.5f));
            for (var i = 0; i <= segments; i++)
            {
                var angle = i * Mathf.PI * 2f / segments;
                vh.AddVert(center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius, color, Vector2.zero);
            }
            for (var i = 0; i < segments; i++) vh.AddTriangle(ci, ci + i + 1, ci + i + 2);
        }

        private void AddThickLine(VertexHelper vh, Vector2 a, Vector2 b, float width)
        {
            var n = new Vector2(-(b - a).y, (b - a).x).normalized * width * 0.5f;
            AddPolygon(vh, new[] { a - n, a + n, b + n, b - n });
        }

        private void Crown(VertexHelper vh, Vector2 c, float s)
        {
            AddPolygon(vh, new[] { c + new Vector2(-s, -s * .45f), c + new Vector2(-s, s * .45f), c + new Vector2(-s * .42f, 0), c, c + new Vector2(s * .42f, 0), c + new Vector2(s, s * .45f), c + new Vector2(s, -s * .45f) });
            AddQuad(vh, c + new Vector2(-s, -s * .70f), c + new Vector2(s, -s * .43f));
            AddCircle(vh, c + new Vector2(-s, s * .48f), s * .11f, 10); AddCircle(vh, c + new Vector2(0, s * .12f), s * .11f, 10); AddCircle(vh, c + new Vector2(s, s * .48f), s * .11f, 10);
        }

        private void Pawn(VertexHelper vh, Vector2 c, float s)
        {
            AddCircle(vh, c + new Vector2(0, s * .52f), s * .28f, 18);
            AddPolygon(vh, new[] { c + new Vector2(-s * .28f, s * .25f), c + new Vector2(s * .28f, s * .25f), c + new Vector2(s * .45f, -s * .45f), c + new Vector2(-s * .45f, -s * .45f) });
            AddQuad(vh, c + new Vector2(-s * .68f, -s * .70f), c + new Vector2(s * .68f, -s * .45f));
        }

        private void Shop(VertexHelper vh, Vector2 c, float s)
        {
            AddQuad(vh, c + new Vector2(-s * .78f, -s * .68f), c + new Vector2(s * .78f, s * .35f));
            AddPolygon(vh, new[] { c + new Vector2(-s, s * .35f), c + new Vector2(s, s * .35f), c + new Vector2(s * .72f, s * .82f), c + new Vector2(-s * .72f, s * .82f) });
            AddQuad(vh, c + new Vector2(-s * .17f, -s * .68f), c + new Vector2(s * .20f, s * .10f));
        }

        private void Home(VertexHelper vh, Vector2 c, float s)
        {
            AddTriangle(vh, c + new Vector2(-s, 0), c + new Vector2(0, s), c + new Vector2(s, 0));
            AddQuad(vh, c + new Vector2(-s * .72f, -s * .82f), c + new Vector2(s * .72f, s * .12f));
            AddQuad(vh, c + new Vector2(-s * .16f, -s * .82f), c + new Vector2(s * .18f, -s * .12f));
        }

        private void Profile(VertexHelper vh, Vector2 c, float s)
        {
            AddCircle(vh, c + new Vector2(0, s * .42f), s * .38f, 24);
            AddPolygon(vh, new[] { c + new Vector2(-s * .82f, -s * .72f), c + new Vector2(-s * .60f, s * .02f), c + new Vector2(s * .60f, s * .02f), c + new Vector2(s * .82f, -s * .72f) });
        }

        private void Settings(VertexHelper vh, Vector2 c, float s)
        {
            AddCircle(vh, c, s * .48f, 24);
            for (var i = 0; i < 8; i++)
            {
                var a = i * Mathf.PI / 4f;
                var dir = new Vector2(Mathf.Cos(a), Mathf.Sin(a));
                AddThickLine(vh, c + dir * s * .48f, c + dir * s * .88f, s * .22f);
            }
            var innerColor = color; color = new Color(color.r, color.g, color.b, 0f); AddCircle(vh, c, s * .18f, 16); color = innerColor;
        }

        private void Plus(VertexHelper vh, Vector2 c, float s) { AddQuad(vh, c + new Vector2(-s * .18f, -s), c + new Vector2(s * .18f, s)); AddQuad(vh, c + new Vector2(-s, -s * .18f), c + new Vector2(s, s * .18f)); }
        private void Back(VertexHelper vh, Vector2 c, float s) { AddThickLine(vh, c + new Vector2(-s * .75f, 0), c + new Vector2(s * .75f, 0), s * .24f); AddTriangle(vh, c + new Vector2(-s, 0), c + new Vector2(-s * .35f, s * .62f), c + new Vector2(-s * .35f, -s * .62f)); }
        private void Close(VertexHelper vh, Vector2 c, float s) { AddThickLine(vh, c + new Vector2(-s * .7f, -s * .7f), c + new Vector2(s * .7f, s * .7f), s * .25f); AddThickLine(vh, c + new Vector2(-s * .7f, s * .7f), c + new Vector2(s * .7f, -s * .7f), s * .25f); }
        private void Pause(VertexHelper vh, Vector2 c, float s) { AddQuad(vh, c + new Vector2(-s * .62f, -s), c + new Vector2(-s * .18f, s)); AddQuad(vh, c + new Vector2(s * .18f, -s), c + new Vector2(s * .62f, s)); }

        private void Sound(VertexHelper vh, Vector2 c, float s)
        {
            AddQuad(vh, c + new Vector2(-s, -s * .32f), c + new Vector2(-s * .58f, s * .32f));
            AddTriangle(vh, c + new Vector2(-s * .58f, -s * .32f), c + new Vector2(s * .02f, -s * .78f), c + new Vector2(s * .02f, s * .78f));
            for (var i = 0; i < 2; i++)
            {
                var r = s * (.48f + i * .28f);
                var points = new List<Vector2>();
                for (var j = -4; j <= 4; j++) { var a = j * Mathf.PI / 12f; points.Add(c + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * r + new Vector2(s * .10f, 0)); }
                for (var j = 0; j < points.Count - 1; j++) AddThickLine(vh, points[j], points[j + 1], s * .10f);
            }
        }

        private void Face(VertexHelper vh, Vector2 c, float s)
        {
            AddCircle(vh, c, s, 30); var old = color; color = new Color(0,0,0,0.55f);
            AddCircle(vh, c + new Vector2(-s * .34f, s * .24f), s * .10f, 10); AddCircle(vh, c + new Vector2(s * .34f, s * .24f), s * .10f, 10);
            var a = c + new Vector2(-s * .45f, -s * .18f); var b = c + new Vector2(0, -s * .48f); var d = c + new Vector2(s * .45f, -s * .18f); AddThickLine(vh,a,b,s*.10f); AddThickLine(vh,b,d,s*.10f); color = old;
        }

        private void Dice(VertexHelper vh, Vector2 c, float s)
        {
            AddQuad(vh, c + new Vector2(-s, -s), c + new Vector2(s, s)); var old = color; color = new Color(0,0,0,0.62f);
            foreach (var p in new[] { new Vector2(-.48f,.48f), new Vector2(.48f,.48f), Vector2.zero, new Vector2(-.48f,-.48f), new Vector2(.48f,-.48f) }) AddCircle(vh, c + p*s, s*.12f, 10); color = old;
        }

        private void Gem(VertexHelper vh, Vector2 c, float s) { AddPolygon(vh, new[] { c + new Vector2(-s, s*.30f), c + new Vector2(-s*.55f,s), c + new Vector2(s*.55f,s), c + new Vector2(s,s*.30f), c + new Vector2(0,-s) }); AddThickLine(vh,c+new Vector2(-s,s*.30f),c+new Vector2(s,s*.30f),s*.07f); }
        private void Star(VertexHelper vh, Vector2 c, float s) { var p=new List<Vector2>(); for(var i=0;i<10;i++){var a=Mathf.PI*.5f+i*Mathf.PI/5f;var r=i%2==0?s:s*.43f;p.Add(c+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*r);} AddPolygon(vh,p); }
        private void Coin(VertexHelper vh, Vector2 c, float s) { AddCircle(vh,c,s,28); AddCircle(vh,c,s*.58f,24); }
        private void Check(VertexHelper vh, Vector2 c, float s) { AddThickLine(vh,c+new Vector2(-s*.8f,-s*.05f),c+new Vector2(-s*.2f,-s*.65f),s*.25f); AddThickLine(vh,c+new Vector2(-s*.2f,-s*.65f),c+new Vector2(s*.9f,s*.65f),s*.25f); }
        private void Chest(VertexHelper vh, Vector2 c, float s) { AddQuad(vh,c+new Vector2(-s,-s*.75f),c+new Vector2(s,s*.35f)); AddPolygon(vh,new[]{c+new Vector2(-s,s*.35f),c+new Vector2(-s*.72f,s*.82f),c+new Vector2(s*.72f,s*.82f),c+new Vector2(s,s*.35f)}); AddQuad(vh,c+new Vector2(-s*.12f,-s*.2f),c+new Vector2(s*.12f,s*.3f)); }
        private void Ladder(VertexHelper vh, Vector2 c, float s) { AddThickLine(vh,c+new Vector2(-s*.55f,-s),c+new Vector2(-s*.55f,s),s*.16f); AddThickLine(vh,c+new Vector2(s*.55f,-s),c+new Vector2(s*.55f,s),s*.16f); for(var i=0;i<6;i++){var y=-s*.85f+i*s*.34f;AddThickLine(vh,c+new Vector2(-s*.55f,y),c+new Vector2(s*.55f,y),s*.13f);} }
        private void Snake(VertexHelper vh, Vector2 c, float s) { var p=new List<Vector2>(); for(var i=0;i<12;i++){var t=i/11f;p.Add(c+new Vector2(Mathf.Sin(t*Mathf.PI*3f)*s*.45f,Mathf.Lerp(-s,s,t)));} for(var i=0;i<p.Count-1;i++)AddThickLine(vh,p[i],p[i+1],s*.24f); AddCircle(vh,p[p.Count-1],s*.28f,16); }
        private void Online(VertexHelper vh, Vector2 c, float s) { AddCircle(vh,c,s,28); AddThickLine(vh,c+new Vector2(-s,0),c+new Vector2(s,0),s*.08f); AddThickLine(vh,c+new Vector2(0,-s),c+new Vector2(0,s),s*.08f); AddPolygon(vh,new[]{c+new Vector2(-s*.2f,-s),c+new Vector2(s*.2f,-s),c+new Vector2(s*.52f,0),c+new Vector2(s*.2f,s),c+new Vector2(-s*.2f,s),c+new Vector2(-s*.52f,0)}); }
        private void Help(VertexHelper vh, Vector2 c, float s) { AddCircle(vh,c,s,28); AddThickLine(vh,c+new Vector2(-s*.28f,s*.34f),c+new Vector2(0,s*.55f),s*.20f); AddThickLine(vh,c+new Vector2(0,s*.55f),c+new Vector2(s*.35f,s*.25f),s*.20f); AddThickLine(vh,c+new Vector2(s*.35f,s*.25f),c+new Vector2(0,-s*.12f),s*.20f); AddCircle(vh,c+new Vector2(0,-s*.55f),s*.10f,10); }
        private void Room(VertexHelper vh, Vector2 c, float s) { AddQuad(vh,c+new Vector2(-s,-s*.78f),c+new Vector2(s,s*.78f)); AddQuad(vh,c+new Vector2(-s*.18f,-s*.78f),c+new Vector2(s*.55f,s*.48f)); AddCircle(vh,c+new Vector2(s*.34f,-s*.10f),s*.10f,10); }
        private void Trophy(VertexHelper vh, Vector2 c, float s) { AddPolygon(vh,new[]{c+new Vector2(-s*.55f,s),c+new Vector2(s*.55f,s),c+new Vector2(s*.38f,0),c+new Vector2(0,-s*.25f),c+new Vector2(-s*.38f,0)}); AddThickLine(vh,c+new Vector2(0,-s*.25f),c+new Vector2(0,-s*.70f),s*.18f); AddQuad(vh,c+new Vector2(-s*.55f,-s),c+new Vector2(s*.55f,-s*.70f)); AddThickLine(vh,c+new Vector2(-s*.55f,s*.7f),c+new Vector2(-s,s*.45f),s*.14f); AddThickLine(vh,c+new Vector2(s*.55f,s*.7f),c+new Vector2(s,s*.45f),s*.14f); }
        private void Return(VertexHelper vh, Vector2 c, float s) { var p=new List<Vector2>(); for(var i=0;i<10;i++){var a=Mathf.Lerp(-Mathf.PI*.25f,Mathf.PI*1.15f,i/9f);p.Add(c+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*s*.7f);} for(var i=0;i<p.Count-1;i++)AddThickLine(vh,p[i],p[i+1],s*.15f); AddTriangle(vh,p[0],p[0]+new Vector2(s*.55f,-s*.12f),p[0]+new Vector2(s*.12f,s*.48f)); }
        private void Book(VertexHelper vh, Vector2 c, float s) { AddPolygon(vh,new[]{c+new Vector2(-s,-s*.8f),c+new Vector2(-s,s*.8f),c+new Vector2(0,s*.52f),c,c+new Vector2(0,-s*.8f)}); AddPolygon(vh,new[]{c,c+new Vector2(0,s*.52f),c+new Vector2(s,s*.8f),c+new Vector2(s,-s*.8f),c+new Vector2(0,-s*.8f)}); }
        private void Notification(VertexHelper vh, Vector2 c, float s) { AddPolygon(vh,new[]{c+new Vector2(-s*.65f,-s*.45f),c+new Vector2(-s*.45f,s*.55f),c,c+new Vector2(s*.45f,s*.55f),c+new Vector2(s*.65f,-s*.45f)}); AddQuad(vh,c+new Vector2(-s*.85f,-s*.62f),c+new Vector2(s*.85f,-s*.42f)); AddCircle(vh,c+new Vector2(0,-s*.78f),s*.18f,12); }
        private void Battery(VertexHelper vh, Vector2 c, float s) { AddQuad(vh,c+new Vector2(-s,-s*.58f),c+new Vector2(s*.78f,s*.58f)); AddQuad(vh,c+new Vector2(s*.78f,-s*.25f),c+new Vector2(s,s*.25f)); AddQuad(vh,c+new Vector2(-s*.78f,-s*.36f),c+new Vector2(s*.28f,s*.36f)); }
        private void Vibration(VertexHelper vh, Vector2 c, float s) { AddQuad(vh,c+new Vector2(-s*.38f,-s*.75f),c+new Vector2(s*.38f,s*.75f)); AddThickLine(vh,c+new Vector2(-s*.65f,-s*.55f),c+new Vector2(-s,-s*.2f),s*.10f); AddThickLine(vh,c+new Vector2(-s,-s*.2f),c+new Vector2(-s*.65f,s*.2f),s*.10f); AddThickLine(vh,c+new Vector2(s*.65f,-s*.55f),c+new Vector2(s,-s*.2f),s*.10f); AddThickLine(vh,c+new Vector2(s,-s*.2f),c+new Vector2(s*.65f,s*.2f),s*.10f); }
        private void Support(VertexHelper vh, Vector2 c, float s) { AddCircle(vh,c,s*.75f,24); AddQuad(vh,c+new Vector2(-s,-s*.15f),c+new Vector2(-s*.68f,s*.35f)); AddQuad(vh,c+new Vector2(s*.68f,-s*.15f),c+new Vector2(s,s*.35f)); AddThickLine(vh,c+new Vector2(s*.82f,-s*.15f),c+new Vector2(s*.42f,-s*.68f),s*.12f); }
    }
}
