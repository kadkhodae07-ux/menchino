using System;
using System.Collections;
using Menchino.RoyalSnakesLadders.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Menchino.RoyalSnakesLadders.UI
{
    public static class RoyalPopupService
    {
        private static GameObject _activePopup;
        private static GameObject _activeToast;

        public static bool HasPopup => _activePopup != null;

        public static void CloseActive()
        {
            if (_activePopup != null) UnityEngine.Object.Destroy(_activePopup);
            _activePopup = null;
        }

        public static void ShowConfirm(RoyalGameApp app, string title, string message, string primary, Action onPrimary, string secondary)
        {
            CloseActive();
            var ui = app.UI;
            var overlay = ui.FullRect("ModalOverlay", app.PopupHost).gameObject;
            _activePopup = overlay;
            var dim = ui.Image("Dim", overlay.transform, new Color(0, 0, 0, 0.72f), RoyalSpriteCache.Solid(Color.white));
            dim.rectTransform.anchorMin = Vector2.zero;
            dim.rectTransform.anchorMax = Vector2.one;
            dim.rectTransform.offsetMin = Vector2.zero;
            dim.rectTransform.offsetMax = Vector2.zero;
            var dimButton = dim.gameObject.AddComponent<Button>();
            dimButton.onClick.AddListener(CloseActive);

            var panel = ui.Panel("Dialog", overlay.transform, new Color32(10, 67, 112, 255), new Color32(2, 23, 52, 255), ui.Theme.gold, 28, 6);
            var rect = panel.rectTransform;
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = new Vector2(760, 500);
            ui.Vertical(panel.transform, 18, new RectOffset(34, 34, 30, 30), TextAnchor.MiddleCenter);

            var titleText = ui.Text("Title", panel.transform, title, 46, ui.Theme.lightGold, TextAlignmentOptions.Center, FontStyles.Bold);
            titleText.gameObject.AddComponent<LayoutElement>().preferredHeight = 78;
            var messageText = ui.Text("Message", panel.transform, message, 28, ui.Theme.textPrimary, TextAlignmentOptions.Center);
            messageText.gameObject.AddComponent<LayoutElement>().preferredHeight = 190;

            var buttons = ui.Rect("Buttons", panel.transform);
            ui.Horizontal(buttons.transform, 16, new RectOffset(0, 0, 0, 0), TextAnchor.MiddleCenter);
            buttons.AddComponent<LayoutElement>().preferredHeight = 86;
            ui.Button("Secondary", buttons.transform, secondary, CloseActive, false);
            ui.Button("Primary", buttons.transform, primary, () =>
            {
                CloseActive();
                onPrimary?.Invoke();
            }, true);
        }

        public static void ShowToast(RoyalGameApp app, string message)
        {
            if (_activeToast != null) UnityEngine.Object.Destroy(_activeToast);
            var ui = app.UI;
            var panel = ui.Panel("Toast", app.PopupHost, new Color32(17, 81, 116, 245), new Color32(3, 29, 54, 245), ui.Theme.gold, 20, 4);
            _activeToast = panel.gameObject;
            var rect = panel.rectTransform;
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.14f);
            rect.sizeDelta = new Vector2(720, 92);
            var text = ui.Text("Text", panel.transform, message, 27, ui.Theme.textPrimary, TextAlignmentOptions.Center, FontStyles.Bold);
            text.rectTransform.anchorMin = Vector2.zero;
            text.rectTransform.anchorMax = Vector2.one;
            text.rectTransform.offsetMin = new Vector2(16, 8);
            text.rectTransform.offsetMax = new Vector2(-16, -8);
            var runner = app.gameObject.GetComponent<PopupCoroutineRunner>() ?? app.gameObject.AddComponent<PopupCoroutineRunner>();
            runner.Run(HideToastAfter(panel.gameObject, 2.2f));
        }

        private static IEnumerator HideToastAfter(GameObject toast, float seconds)
        {
            yield return new WaitForSecondsRealtime(seconds);
            if (toast != null) UnityEngine.Object.Destroy(toast);
            if (_activeToast == toast) _activeToast = null;
        }

        private sealed class PopupCoroutineRunner : MonoBehaviour
        {
            public void Run(IEnumerator routine) => StartCoroutine(routine);
        }
    }
}
