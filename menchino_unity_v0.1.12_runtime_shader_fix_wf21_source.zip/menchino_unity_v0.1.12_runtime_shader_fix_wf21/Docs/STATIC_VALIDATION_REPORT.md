# گزارش اعتبارسنجی استاتیک نسخه 0.1.12

- تاریخ: 2026-07-20
- Unity: `2022.3.62f1`
- Workflow: `WF-21`
- اصلاح اصلی: حذف Package ID نامعتبر `com.unity.modules.inputlegacy`

## کنترل‌های مورد انتظار

- Manifest JSON معتبر است و `com.unity.modules.inputlegacy` در آن وجود ندارد.
- UGUI، Android JNI، Audio، IMGUI، JSON Serialize، Physics و UI با نسخه معتبر ثبت شده‌اند.
- Assembly Definition به `Unity.ugui` ارجاع دارد.
- `StandaloneInputModule` از UGUI استفاده می‌کند و به Package جداگانه نیاز ندارد.
- نسخه C#، ProjectSettings و نام ZIP همگام هستند.
- Workflow مستقل WF-21 داخل سورس و فایل تحویلی بایت‌به‌بایت یکسان است.
- Compile واقعی Unity و تولید APK در GitHub Actions انجام می‌شود.
