using System;
using System.Collections;
using System.Collections.Generic;
using Menchino.Data;
using Menchino.Gameplay;
using UnityEngine;

namespace Menchino.Presentation
{
    public static class WorldFactory
    {
        private static readonly Dictionary<string, Material> Materials = new Dictionary<string, Material>();

        private static Shader _builtInWorldShader;

        private static Shader ResolveBuiltInShader()
        {
            if (_builtInWorldShader != null && _builtInWorldShader.isSupported) return _builtInWorldShader;

            string[] shaderNames = { "Standard", "Mobile/Diffuse", "Unlit/Color" };
            foreach (string shaderName in shaderNames)
            {
                Shader shader = Shader.Find(shaderName);
                if (shader == null || !shader.isSupported) continue;
                _builtInWorldShader = shader;
                Debug.Log("Menchino world shader selected: " + shader.name);
                return shader;
            }

            throw new InvalidOperationException(
                "No supported built-in world shader was found. Candidates: " +
                string.Join(", ", shaderNames));
        }

        public static Material Material(string key, Color color, float metallic = .15f, float smoothness = .65f, bool emission = false)
        {
            if (Materials.TryGetValue(key, out var cached) && cached != null) return cached;
            Shader shader = ResolveBuiltInShader();
            var material = new Material(shader)
            {
                color = color,
                name = "MAT_" + key,
                hideFlags = HideFlags.DontSave
            };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", smoothness);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", smoothness);
            if (emission)
            {
                material.EnableKeyword("_EMISSION");
                if (material.HasProperty("_EmissionColor")) material.SetColor("_EmissionColor", color * 1.25f);
            }
            return Materials[key] = material;
        }

        public static GameObject CreatePrimitive(PrimitiveType type, string name, Transform parent, Vector3 localPosition, Vector3 localScale, Material material)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPosition;
            go.transform.localScale = localScale;
            if (material != null) go.GetComponent<Renderer>().sharedMaterial = material;
            var collider = go.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.Destroy(collider);
            return go;
        }

        public static Camera CreateCamera(Transform parent)
        {
            var go = new GameObject("GameplayCamera", typeof(Camera));
            go.transform.SetParent(parent, false);
            var camera = go.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.025f, .045f, .13f);
            camera.fieldOfView = 42f;
            camera.nearClipPlane = .1f;
            camera.farClipPlane = 80f;
            go.transform.position = new Vector3(0f, 12.8f, -13.7f);
            go.transform.rotation = Quaternion.LookRotation(new Vector3(0f, .4f, 1.4f) - go.transform.position, Vector3.up);
            return camera;
        }

        public static void CreateLighting(Transform parent)
        {
            var key = new GameObject("WarmKeyLight", typeof(Light));
            key.transform.SetParent(parent, false);
            key.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
            var kl = key.GetComponent<Light>();
            kl.type = LightType.Directional;
            kl.color = new Color(1f, .82f, .58f);
            kl.intensity = 1.25f;
            kl.shadows = LightShadows.Soft;

            var fill = new GameObject("BlueFill", typeof(Light));
            fill.transform.SetParent(parent, false);
            fill.transform.position = new Vector3(-4f, 6f, -4f);
            var fl = fill.GetComponent<Light>();
            fl.type = LightType.Point;
            fl.color = new Color(.24f, .48f, 1f);
            fl.range = 22f;
            fl.intensity = 1.55f;

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.25f, .38f, .62f);
            RenderSettings.ambientEquatorColor = new Color(.16f, .13f, .25f);
            RenderSettings.ambientGroundColor = new Color(.055f, .025f, .08f);
            RenderSettings.ambientIntensity = .78f;
        }

        public static Transform CreateBoard(Transform parent, BoardLayoutData layout, string themeId)
        {
            var board = new GameObject("RoyalBoard").transform;
            board.SetParent(parent, false);
            board.localPosition = new Vector3(0f, 0f, 2.3f);

            var gold = Material("gold", new Color(.93f, .52f, .06f), .72f, .86f);
            var wood = Material("wood", new Color(.24f, .075f, .032f), .1f, .35f);
            var cream = Material("cream", new Color(.95f, .86f, .72f), .05f, .55f);
            CreatePrimitive(PrimitiveType.Cube, "BoardShadow", board, new Vector3(0f, -.28f, 0f), new Vector3(9.65f, .34f, 9.65f), wood);
            CreatePrimitive(PrimitiveType.Cube, "GoldFrame", board, new Vector3(0f, -.11f, 0f), new Vector3(9.38f, .34f, 9.38f), gold);
            CreatePrimitive(PrimitiveType.Cube, "InnerBase", board, new Vector3(0f, .03f, 0f), new Vector3(8.86f, .18f, 8.86f), cream);

            Color[] colors = themeId == "night" ? new[]
            {
                new Color(.23f,.16f,.55f), new Color(.08f,.38f,.70f), new Color(.06f,.52f,.50f),
                new Color(.60f,.31f,.72f), new Color(.18f,.22f,.50f), new Color(.62f,.55f,.74f)
            } : new[]
            {
                new Color(.82f,.24f,.18f), new Color(.13f,.53f,.83f), new Color(.20f,.64f,.28f),
                new Color(.94f,.68f,.16f), new Color(.56f,.28f,.72f), new Color(.88f,.80f,.66f)
            };

            for (int number = 1; number <= 100; number++)
            {
                Vector3 pos = BoardMath.NumberToWorld(number, .22f);
                Color c = colors[(number * 7 + number / 10) % colors.Length];
                var mat = Material("tile_" + ((number * 7 + number / 10) % colors.Length), c, .08f, .58f);
                CreatePrimitive(PrimitiveType.Cube, "Cell_" + number, board, pos, new Vector3(BoardMath.CellSize * .94f, .23f, BoardMath.CellSize * .94f), mat);
                CreateCellNumber(board, number, pos + new Vector3(0f, .18f, 0f));
            }

            foreach (var ladder in layout.ladders) CreateLadder(board, ladder.from, ladder.to);
            int snakeIndex = 0;
            Color[] snakeColors = { new Color(.22f,.78f,.23f), new Color(.76f,.16f,.17f), new Color(.50f,.16f,.72f), new Color(.10f,.48f,.90f) };
            foreach (var snake in layout.snakes) CreateSnake(board, snake.from, snake.to, snakeColors[snakeIndex++ % snakeColors.Length]);
            CreateCornerOrnaments(board, gold);
            return board;
        }

        private static void CreateCellNumber(Transform board, int number, Vector3 pos)
        {
            var go = new GameObject("Number_" + number, typeof(TextMesh));
            go.transform.SetParent(board, false);
            go.transform.localPosition = pos;
            go.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            var text = go.GetComponent<TextMesh>();
            text.text = ToPersianDigits(number.ToString());
            text.font = UiFactory.Font;
            text.fontSize = 64;
            text.characterSize = .075f;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.color = new Color(.15f, .08f, .12f, .92f);
            var renderer = go.GetComponent<MeshRenderer>();
            if (text.font != null) renderer.sharedMaterial = text.font.material;
        }

        private static string ToPersianDigits(string input)
        {
            char[] result = input.ToCharArray();
            for (int i = 0; i < result.Length; i++) if (result[i] >= '0' && result[i] <= '9') result[i] = (char)('۰' + result[i] - '0');
            return new string(result);
        }

        private static void CreateCornerOrnaments(Transform board, Material gold)
        {
            float p = 4.72f;
            Vector3[] points = { new Vector3(-p,.16f,-p), new Vector3(p,.16f,-p), new Vector3(-p,.16f,p), new Vector3(p,.16f,p) };
            foreach (var point in points)
            {
                var gem = CreatePrimitive(PrimitiveType.Sphere, "CornerGem", board, point, new Vector3(.42f,.18f,.42f), gold);
                gem.transform.localRotation = Quaternion.Euler(0f,45f,0f);
            }
        }

        private static void CreateLadder(Transform board, int from, int to)
        {
            Vector3 a = BoardMath.NumberToWorld(from, .48f);
            Vector3 b = BoardMath.NumberToWorld(to, .48f);
            Vector3 direction = (b - a).normalized;
            Vector3 side = Vector3.Cross(Vector3.up, direction).normalized * .17f;
            var wood = Material("ladder_wood", new Color(.46f,.20f,.055f), .08f, .42f);
            var gold = Material("ladder_gold", new Color(1f,.64f,.08f), .55f, .78f);
            CreateCylinderBetween(board, a + side, b + side, .075f, wood, "LadderRail");
            CreateCylinderBetween(board, a - side, b - side, .075f, wood, "LadderRail");
            float distance = Vector3.Distance(a,b);
            int steps = Mathf.Max(3, Mathf.RoundToInt(distance / .47f));
            for (int i=0;i<=steps;i++)
            {
                float t=i/(float)steps;
                Vector3 center=Vector3.Lerp(a,b,t);
                CreateCylinderBetween(board, center-side, center+side, .055f, i%3==0?gold:wood, "LadderRung");
            }
        }

        private static void CreateSnake(Transform board, int from, int to, Color color)
        {
            Vector3 a = BoardMath.NumberToWorld(from, .62f);
            Vector3 b = BoardMath.NumberToWorld(to, .62f);
            Vector3 forward = b-a;
            Vector3 side = Vector3.Cross(Vector3.up, forward.normalized);
            int segments = Mathf.Clamp(Mathf.RoundToInt(Vector3.Distance(a,b)/.45f), 7, 18);
            var mat=Material("snake_"+ColorUtility.ToHtmlStringRGB(color), color, .12f, .86f);
            Vector3 previous=a;
            for(int i=1;i<=segments;i++)
            {
                float t=i/(float)segments;
                float wave=Mathf.Sin(t*Mathf.PI*3.5f)*.28f*Mathf.Sin(t*Mathf.PI);
                Vector3 current=Vector3.Lerp(a,b,t)+side*wave+Vector3.up*Mathf.Sin(t*Mathf.PI)*.09f;
                float radius=Mathf.Lerp(.13f,.085f,t);
                CreateCylinderBetween(board,previous,current,radius,mat,"SnakeBody");
                previous=current;
            }
            var head=CreatePrimitive(PrimitiveType.Sphere,"SnakeHead",board,a+Vector3.up*.04f,new Vector3(.42f,.22f,.5f),mat);
            head.transform.localRotation=Quaternion.LookRotation((b-a).normalized,Vector3.up);
            var eyeMat=Material("eye",Color.white,.05f,.8f);
            var pupilMat=Material("pupil",new Color(.03f,.02f,.02f),0f,.4f);
            Vector3 dir=(b-a).normalized;
            Vector3 eyeSide=Vector3.Cross(Vector3.up,dir).normalized*.13f;
            Vector3 eyeForward=dir*.13f+Vector3.up*.11f;
            foreach(float s in new[]{-1f,1f})
            {
                var eye=CreatePrimitive(PrimitiveType.Sphere,"SnakeEye",board,a+eyeForward+eyeSide*s,new Vector3(.09f,.09f,.09f),eyeMat);
                CreatePrimitive(PrimitiveType.Sphere,"SnakePupil",eye.transform,dir*.55f,new Vector3(.48f,.48f,.48f),pupilMat);
            }
        }

        public static GameObject CreatePawn(Transform parent, PieceColor pieceColor, int index)
        {
            Color color=ThemePalette.PieceColor((int)pieceColor);
            var root=new GameObject("Pawn_"+pieceColor);
            root.transform.SetParent(parent,false);
            var mat=Material("piece_"+pieceColor,color,.34f,.92f);
            var dark=Material("piece_dark_"+pieceColor,Color.Lerp(color,Color.black,.32f),.35f,.86f);
            CreatePrimitive(PrimitiveType.Cylinder,"Base",root.transform,new Vector3(0,.12f,0),new Vector3(.46f,.12f,.46f),dark);
            CreatePrimitive(PrimitiveType.Sphere,"Body",root.transform,new Vector3(0,.40f,0),new Vector3(.43f,.47f,.43f),mat);
            CreatePrimitive(PrimitiveType.Cylinder,"Neck",root.transform,new Vector3(0,.67f,0),new Vector3(.25f,.22f,.25f),mat);
            CreatePrimitive(PrimitiveType.Sphere,"Head",root.transform,new Vector3(0,.92f,0),new Vector3(.31f,.31f,.31f),mat);
            var glow=CreatePrimitive(PrimitiveType.Cylinder,"ActiveGlow",root.transform,new Vector3(0,.025f,0),new Vector3(.58f,.018f,.58f),Material("active_glow",new Color(1f,.78f,.08f),.2f,1f,true));
            glow.SetActive(false);
            root.AddComponent<PawnIdleAnimation>().phase=index*.7f;
            return root;
        }

        public static GameObject CreateDice(Transform parent)
        {
            var root=new GameObject("IvoryDice");
            root.transform.SetParent(parent,false);
            var body=Material("dice_body",new Color(.93f,.88f,.76f),.1f,.83f);
            var pip=Material("dice_pip",new Color(.025f,.018f,.015f),.05f,.55f);
            CreatePrimitive(PrimitiveType.Cube,"DiceCore",root.transform,Vector3.zero,new Vector3(1.04f,1.04f,1.04f),body);
            float corner=.47f;
            for(int x=-1;x<=1;x+=2)
            for(int y=-1;y<=1;y+=2)
            for(int z=-1;z<=1;z+=2)
                CreatePrimitive(PrimitiveType.Sphere,"RoundedCorner",root.transform,new Vector3(x*corner,y*corner,z*corner),Vector3.one*.27f,body);
            AddFacePips(root.transform, Vector3.up, Vector3.forward, 1, pip);
            AddFacePips(root.transform, Vector3.down, Vector3.back, 6, pip);
            AddFacePips(root.transform, Vector3.forward, Vector3.up, 2, pip);
            AddFacePips(root.transform, Vector3.back, Vector3.up, 5, pip);
            AddFacePips(root.transform, Vector3.right, Vector3.up, 3, pip);
            AddFacePips(root.transform, Vector3.left, Vector3.up, 4, pip);
            return root;
        }

        private static void AddFacePips(Transform root, Vector3 normal, Vector3 up, int value, Material material)
        {
            Vector3 right=Vector3.Cross(up,normal).normalized;
            up=Vector3.Cross(normal,right).normalized;
            Vector2[] layout;
            switch(value)
            {
                case 1: layout=new[]{Vector2.zero};break;
                case 2: layout=new[]{new Vector2(-.24f,.24f),new Vector2(.24f,-.24f)};break;
                case 3: layout=new[]{new Vector2(-.25f,.25f),Vector2.zero,new Vector2(.25f,-.25f)};break;
                case 4: layout=new[]{new Vector2(-.24f,.24f),new Vector2(.24f,.24f),new Vector2(-.24f,-.24f),new Vector2(.24f,-.24f)};break;
                case 5: layout=new[]{new Vector2(-.25f,.25f),new Vector2(.25f,.25f),Vector2.zero,new Vector2(-.25f,-.25f),new Vector2(.25f,-.25f)};break;
                default: layout=new[]{new Vector2(-.25f,.27f),new Vector2(-.25f,0),new Vector2(-.25f,-.27f),new Vector2(.25f,.27f),new Vector2(.25f,0),new Vector2(.25f,-.27f)};break;
            }
            foreach(var p in layout)
            {
                Vector3 pos=normal*.57f+right*p.x+up*p.y;
                var pip=CreatePrimitive(PrimitiveType.Sphere,"Pip",root,pos,Vector3.one*.105f,material);
                pip.transform.localScale = new Vector3(.105f,.105f,.105f);
            }
        }

        public static GameObject CreateDicePlatform(Transform parent)
        {
            var root=new GameObject("DicePlatform");
            root.transform.SetParent(parent,false);
            root.transform.localPosition=new Vector3(0f,.1f,-5.0f);
            CreatePrimitive(PrimitiveType.Cylinder,"GoldBase",root.transform,Vector3.zero,new Vector3(1.72f,.22f,1.72f),Material("platform_gold",ThemePalette.Gold,.65f,.88f));
            CreatePrimitive(PrimitiveType.Cylinder,"PurplePad",root.transform,new Vector3(0,.16f,0),new Vector3(1.48f,.13f,1.48f),Material("platform_purple",ThemePalette.Purple,.25f,.78f));
            return root;
        }

        public static void CreateCylinderBetween(Transform parent, Vector3 a, Vector3 b, float radius, Material material, string name)
        {
            Vector3 delta=b-a;
            var cylinder=CreatePrimitive(PrimitiveType.Cylinder,name,parent,(a+b)*.5f,new Vector3(radius,delta.magnitude*.5f,radius),material);
            cylinder.transform.localRotation=Quaternion.FromToRotation(Vector3.up,delta.normalized);
        }
    }

    public sealed class PawnIdleAnimation : MonoBehaviour
    {
        public float phase;
        private float _baseY;
        private void Start()=>_baseY=transform.localPosition.y;
        private void Update()
        {
            var p=transform.localPosition;
            p.y=_baseY+Mathf.Sin(Time.time*1.8f+phase)*.035f;
            transform.localPosition=p;
        }
    }

    public sealed class GameplayWorldView : MonoBehaviour
    {
        private readonly List<GameObject> _pieces=new List<GameObject>();
        private GameObject _dice;
        private Transform _board;
        private MatchController _match;
        private Vector3 _diceHome;

        public void Build(MatchController match)
        {
            _match=match;
            WorldFactory.CreateCamera(transform);
            WorldFactory.CreateLighting(transform);
            _board=WorldFactory.CreateBoard(transform,match.Board,match.State.boardId);
            for(int i=0;i<match.State.players.Count;i++)
            {
                var piece=WorldFactory.CreatePawn(_board,match.State.players[i].pieceColor,i);
                piece.transform.localPosition=BoardMath.NumberToWorld(match.State.players[i].currentCell,.43f)+StartOffset(i,match.State.players.Count);
                _pieces.Add(piece);
            }
            var platform=WorldFactory.CreateDicePlatform(transform);
            _dice=WorldFactory.CreateDice(platform.transform);
            _diceHome=new Vector3(0f,1.08f,0f);
            _dice.transform.localPosition=_diceHome;
            _dice.transform.localScale=Vector3.one*1.18f;

            match.TurnStarted+=OnTurnStarted;
            match.DiceRolled+=OnDiceRolled;
            match.PieceStepped+=OnPieceStepped;
            match.SpecialMoveStarted+=OnSpecialMove;
            match.PieceResetByCollision+=OnPieceReset;
        }

        private void OnDestroy()
        {
            if(_match==null)return;
            _match.TurnStarted-=OnTurnStarted;
            _match.DiceRolled-=OnDiceRolled;
            _match.PieceStepped-=OnPieceStepped;
            _match.SpecialMoveStarted-=OnSpecialMove;
            _match.PieceResetByCollision-=OnPieceReset;
        }

        private void OnTurnStarted(PlayerMatchState player)
        {
            for(int i=0;i<_pieces.Count;i++)
            {
                var glow=_pieces[i].transform.Find("ActiveGlow");
                if(glow!=null)glow.gameObject.SetActive(i==player.turnIndex);
            }
        }

        private void OnDiceRolled(int value)=>StartCoroutine(RollDice(value));

        private IEnumerator RollDice(int value)
        {
            Vector3 start=_diceHome;
            Quaternion startRot=_dice.transform.localRotation;
            Quaternion end=RotationForValue(value);
            float duration=.78f;
            float time=0f;
            while(time<duration)
            {
                time+=Time.deltaTime;
                float t=Mathf.Clamp01(time/duration);
                float eased=1f-Mathf.Pow(1f-t,3f);
                _dice.transform.localPosition=start+new Vector3(Mathf.Sin(t*Mathf.PI*2f)*.16f,Mathf.Sin(t*Mathf.PI)*1.0f,0f);
                Quaternion spin=Quaternion.Euler(t*900f,t*720f,t*540f);
                _dice.transform.localRotation=Quaternion.Slerp(startRot*spin,end,eased*eased);
                yield return null;
            }
            _dice.transform.localPosition=start;
            _dice.transform.localRotation=end;
            yield return Bounce(_dice.transform);
        }

        private static Quaternion RotationForValue(int value)
        {
            switch(value)
            {
                case 1:return Quaternion.identity;
                case 2:return Quaternion.Euler(-90,0,0);
                case 3:return Quaternion.Euler(0,0,90);
                case 4:return Quaternion.Euler(0,0,-90);
                case 5:return Quaternion.Euler(90,0,0);
                default:return Quaternion.Euler(180,0,0);
            }
        }

        private void OnPieceStepped(int playerIndex,int cell)
        {
            if(playerIndex<0||playerIndex>=_pieces.Count)return;
            StartCoroutine(MovePiece(_pieces[playerIndex].transform,BoardMath.NumberToWorld(cell,.43f),.13f,.16f));
        }

        private void OnSpecialMove(int playerIndex,int from,int to,bool ladder)
        {
            if(playerIndex<0||playerIndex>=_pieces.Count)return;
            StartCoroutine(MoveSpecial(_pieces[playerIndex].transform,BoardMath.NumberToWorld(from,.43f),BoardMath.NumberToWorld(to,.43f),ladder));
        }

        private void OnPieceReset(int playerIndex,int cell)
        {
            if(playerIndex<0||playerIndex>=_pieces.Count)return;
            StartCoroutine(MovePiece(_pieces[playerIndex].transform,BoardMath.NumberToWorld(cell,.43f)+StartOffset(playerIndex,_pieces.Count),.36f,.5f));
        }

        private static IEnumerator MovePiece(Transform target,Vector3 destination,float height,float duration)
        {
            Vector3 start=target.localPosition;
            float time=0f;
            while(time<duration)
            {
                time+=Time.deltaTime;
                float t=Mathf.Clamp01(time/duration);
                Vector3 p=Vector3.Lerp(start,destination,t);
                p.y+=Mathf.Sin(t*Mathf.PI)*height;
                target.localPosition=p;
                yield return null;
            }
            target.localPosition=destination;
        }

        private static IEnumerator MoveSpecial(Transform target,Vector3 from,Vector3 to,bool ladder)
        {
            Vector3 start=target.localPosition;
            float duration=.76f;
            float time=0f;
            while(time<duration)
            {
                time+=Time.deltaTime;
                float t=Mathf.Clamp01(time/duration);
                float eased=ladder?t*t*(3f-2f*t):1f-Mathf.Pow(1f-t,2f);
                Vector3 p=Vector3.Lerp(start,to,eased);
                Vector3 side=Vector3.Cross(Vector3.up,(to-from).normalized);
                p+=side*Mathf.Sin(t*Mathf.PI*2.5f)*(ladder ? .04f : .18f)*Mathf.Sin(t*Mathf.PI);
                p.y+=Mathf.Sin(t*Mathf.PI)*(ladder ? .34f : .16f);
                target.localPosition=p;
                target.localRotation=Quaternion.Euler(0f,t*(ladder ? 180f : 430f),0f);
                yield return null;
            }
            target.localPosition=to;
            target.localRotation=Quaternion.identity;
        }

        private static IEnumerator Bounce(Transform target)
        {
            Vector3 start=target.localScale;
            float time=0f;
            while(time<.18f)
            {
                time+=Time.deltaTime;
                float t=time/.18f;
                target.localScale=start*(1f+Mathf.Sin(t*Mathf.PI)*.08f);
                yield return null;
            }
            target.localScale=start;
        }

        private static Vector3 StartOffset(int index,int count)
        {
            float spacing=.58f;
            return new Vector3((index-(count-1)*.5f)*spacing,0f,0f);
        }
    }
}
