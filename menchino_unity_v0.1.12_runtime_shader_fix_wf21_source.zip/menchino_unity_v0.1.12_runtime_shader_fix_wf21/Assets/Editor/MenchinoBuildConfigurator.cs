#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;

namespace Menchino.Editor
{
    [InitializeOnLoad]
    public static class MenchinoBuildConfigurator
    {
        public const string VersionName = "0.1.12";
        public const int VersionCode = 12;

        static MenchinoBuildConfigurator()
        {
            EditorApplication.delayCall += Apply;
        }

        [MenuItem("Menchino/Apply Android Configuration")]
        public static void Apply()
        {
            PlayerSettings.companyName = "Menchino Studio";
            PlayerSettings.productName = "منچینو";
            PlayerSettings.bundleVersion = VersionName;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.menchino.game");
            PlayerSettings.Android.bundleVersionCode = VersionCode;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.useCustomKeystore = false;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetIl2CppCompilerConfiguration(BuildTargetGroup.Android, Il2CppCompilerConfiguration.Release);
            PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Medium);
            EditorUserBuildSettings.buildAppBundle = false;

            // Keep the project on the built-in render pipeline. Runtime UI and world objects
            // are created entirely from code, so their shaders are not referenced by scenes.
            // Explicit retention prevents Unity's Android build stripping from replacing them
            // with the magenta internal-error shader in the player.
            GraphicsSettings.renderPipelineAsset = null;
            QualitySettings.renderPipeline = null;
            RetainRuntimeShaders();

            Texture2D icon = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Art/AppIcon/menchino_icon_512.png");
            if (icon != null)
            {
                PlayerSettings.SetIconsForTargetGroup(BuildTargetGroup.Android, new[] { icon });
            }

            AssetDatabase.SaveAssets();
        }

        private static void RetainRuntimeShaders()
        {
            string[] requiredShaderNames =
            {
                "UI/Default",
                "Standard"
            };
            string[] optionalShaderNames =
            {
                "GUI/Text Shader",
                "Sprites/Default",
                "Unlit/Color",
                "Mobile/Diffuse"
            };

            UnityEngine.Object graphicsSettingsObject = GraphicsSettings.GetGraphicsSettings();
            if (graphicsSettingsObject == null)
            {
                throw new InvalidOperationException("Unity GraphicsSettings object could not be loaded.");
            }

            var serializedSettings = new SerializedObject(graphicsSettingsObject);
            SerializedProperty includedShaders = serializedSettings.FindProperty("m_AlwaysIncludedShaders");
            if (includedShaders == null || !includedShaders.isArray)
            {
                throw new InvalidOperationException("GraphicsSettings.m_AlwaysIncludedShaders is unavailable.");
            }

            var retainedNames = new HashSet<string>(StringComparer.Ordinal);
            for (int index = 0; index < includedShaders.arraySize; index++)
            {
                Shader existing = includedShaders.GetArrayElementAtIndex(index).objectReferenceValue as Shader;
                if (existing != null) retainedNames.Add(existing.name);
            }

            foreach (string shaderName in requiredShaderNames.Concat(optionalShaderNames))
            {
                Shader shader = Shader.Find(shaderName);
                if (shader == null)
                {
                    if (requiredShaderNames.Contains(shaderName))
                    {
                        throw new InvalidOperationException(
                            "Required runtime shader was not found in the Unity Editor: " + shaderName);
                    }
                    Debug.LogWarning("Optional runtime shader was not found: " + shaderName);
                    continue;
                }

                if (retainedNames.Add(shader.name))
                {
                    int index = includedShaders.arraySize;
                    includedShaders.InsertArrayElementAtIndex(index);
                    includedShaders.GetArrayElementAtIndex(index).objectReferenceValue = shader;
                }
            }

            serializedSettings.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(graphicsSettingsObject);
            AssetDatabase.SaveAssets();

            foreach (string shaderName in requiredShaderNames)
            {
                bool retained = false;
                for (int index = 0; index < includedShaders.arraySize; index++)
                {
                    Shader shader = includedShaders.GetArrayElementAtIndex(index).objectReferenceValue as Shader;
                    if (shader != null && shader.name == shaderName)
                    {
                        retained = true;
                        break;
                    }
                }
                if (!retained)
                {
                    throw new InvalidOperationException(
                        "Required runtime shader was not retained in Graphics Settings: " + shaderName);
                }
            }

            Debug.Log("Menchino runtime shaders retained: " + string.Join(", ", retainedNames.OrderBy(name => name)));
        }
    }

    public static class AndroidBuilder
    {
        private static readonly string[] Scenes =
        {
            "Assets/Scenes/Boot.unity",
            "Assets/Scenes/Home.unity",
            "Assets/Scenes/ModeSelect.unity",
            "Assets/Scenes/SnakesSetup.unity",
            "Assets/Scenes/SnakesGameplay.unity",
            "Assets/Scenes/Result.unity",
            "Assets/Scenes/DailyReward.unity",
            "Assets/Scenes/Missions.unity",
            "Assets/Scenes/Shop.unity",
            "Assets/Scenes/Profile.unity",
            "Assets/Scenes/Settings.unity"
        };

        private const string OutputDirectory = "Builds/Android";
        private const string LogsDirectory = "Builds/Logs";
        private const string SummaryLog = LogsDirectory + "/menchino-build-summary.log";
        private const string CapturedUnityLog = LogsDirectory + "/unity-captured.log";
        private static readonly object LogLock = new object();

        [MenuItem("Menchino/Build Two Android APKs")]
        public static void BuildFromMenu()
        {
            Build();
        }

        // GitHub Actions entry point. Produces exactly two independent APK builds.
        public static void Build()
        {
            PrepareOutputDirectories();
            Application.logMessageReceived += CaptureUnityLog;

            try
            {
                if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                {
                    AppendSummary("Switching active build target to Android.");
                    if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
                    {
                        throw new InvalidOperationException("Unity could not switch the active build target to Android.");
                    }
                }

                MenchinoBuildConfigurator.Apply();
                ValidateProjectInputs();

                BuildVariant(
                    "Menchino-arm64-v8a.apk",
                    AndroidArchitecture.ARM64,
                    "ARM64-only");

                BuildVariant(
                    "Menchino-universal.apk",
                    AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64,
                    "ARMv7+ARM64 universal");

                string[] apks = Directory.GetFiles(OutputDirectory, "*.apk", SearchOption.TopDirectoryOnly);
                if (apks.Length != 2)
                {
                    throw new InvalidOperationException(
                        $"Expected exactly two APK files, but found {apks.Length} in {OutputDirectory}.");
                }

                AppendSummary("SUCCESS: exactly two APK files were produced.");
                Debug.Log("Menchino dual APK build completed successfully.");
            }
            catch (Exception exception)
            {
                AppendSummary("FAILURE: " + exception);
                Debug.LogException(exception);
                throw;
            }
            finally
            {
                Application.logMessageReceived -= CaptureUnityLog;
                PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
                AssetDatabase.SaveAssets();
            }
        }

        private static void ValidateProjectInputs()
        {
            var missing = new StringBuilder();
            foreach (string scene in Scenes)
            {
                if (!File.Exists(scene))
                {
                    missing.AppendLine(scene);
                }
            }

            if (missing.Length > 0)
            {
                throw new FileNotFoundException("Required build scenes are missing:\n" + missing);
            }

            string manifest = File.ReadAllText("Packages/manifest.json");
            string[] requiredPackages =
            {
                "com.unity.ugui",
                "com.unity.modules.androidjni",
                "com.unity.modules.audio",
                "com.unity.modules.imgui",
                "com.unity.modules.jsonserialize",
                "com.unity.modules.physics",
                "com.unity.modules.ui"
            };
            foreach (string packageName in requiredPackages)
            {
                if (!manifest.Contains("\"" + packageName + "\""))
                {
                    throw new InvalidOperationException(
                        "Packages/manifest.json does not include required package " + packageName + ".");
                }
            }

            // Legacy Input Manager is built into Unity and is not a UPM package.
            // StandaloneInputModule is supplied by com.unity.ugui.
            if (manifest.Contains("\"com.unity.modules.inputlegacy\""))
            {
                throw new InvalidOperationException(
                    "Invalid package com.unity.modules.inputlegacy must be removed from Packages/manifest.json.");
            }

            string asmdef = File.ReadAllText("Assets/Scripts/Menchino.Runtime.asmdef");
            if (!asmdef.Contains("Unity.ugui"))
            {
                throw new InvalidOperationException("Menchino.Runtime.asmdef does not reference Unity.ugui.");
            }

            string uiFactory = File.ReadAllText("Assets/Scripts/Presentation/UiFactory.cs");
            string worldFactory = File.ReadAllText("Assets/Scripts/Presentation/WorldFactory.cs");
            if (!uiFactory.Contains("Shader.Find(\"UI/Default\")") ||
                !uiFactory.Contains("image.material = RuntimeUiMaterial") ||
                !uiFactory.Contains("uiText.material = RuntimeTextMaterial"))
            {
                throw new InvalidOperationException(
                    "Runtime UI shader assignment is missing; procedural UI can render magenta after shader stripping.");
            }
            if (worldFactory.Contains("Universal Render Pipeline/Lit") ||
                !worldFactory.Contains("Shader.Find(\"Standard\")"))
            {
                throw new InvalidOperationException(
                    "WorldFactory must use built-in-pipeline shaders and must not request URP/Lit.");
            }

            AppendSummary(
                "Preflight validation passed: scenes, valid packages, UGUI references and runtime shader-retention guards are present.");
        }

        private static void PrepareOutputDirectories()
        {
            if (Directory.Exists(OutputDirectory))
            {
                Directory.Delete(OutputDirectory, true);
            }

            Directory.CreateDirectory(OutputDirectory);
            Directory.CreateDirectory(LogsDirectory);
            File.WriteAllText(
                SummaryLog,
                $"Menchino Android build started at {DateTime.UtcNow:O}{Environment.NewLine}" +
                $"Version: {MenchinoBuildConfigurator.VersionName} ({MenchinoBuildConfigurator.VersionCode}){Environment.NewLine}" +
                $"Unity: {Application.unityVersion}{Environment.NewLine}");
            File.WriteAllText(CapturedUnityLog, string.Empty);
        }

        private static void BuildVariant(
            string fileName,
            AndroidArchitecture architectures,
            string label)
        {
            string output = Path.Combine(OutputDirectory, fileName);
            string reportPath = Path.Combine(LogsDirectory, Path.GetFileNameWithoutExtension(fileName) + "-build-report.log");
            PlayerSettings.Android.targetArchitectures = architectures;
            AssetDatabase.SaveAssets();

            AppendSummary($"START: {label} -> {output}; architectures={architectures}");

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = Scenes,
                locationPathName = output,
                target = BuildTarget.Android,
                options = BuildOptions.DetailedBuildReport
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            WriteBuildReport(report, reportPath, label);

            BuildSummary summary = report.summary;
            AppendSummary(
                $"RESULT: {label}; result={summary.result}; errors={summary.totalErrors}; " +
                $"warnings={summary.totalWarnings}; bytes={summary.totalSize}; duration={summary.totalTime}");

            if (summary.result != BuildResult.Succeeded)
            {
                throw new InvalidOperationException(
                    $"Android build failed for {label}: result={summary.result}, errors={summary.totalErrors}. " +
                    $"See {reportPath} and {CapturedUnityLog}.");
            }

            if (!File.Exists(output) || new FileInfo(output).Length <= 0)
            {
                throw new InvalidOperationException($"APK output is missing or empty: {output}");
            }

            Debug.Log($"Menchino APK built: {output} ({new FileInfo(output).Length} bytes)");
        }

        private static void WriteBuildReport(BuildReport report, string path, string label)
        {
            var text = new StringBuilder();
            BuildSummary summary = report.summary;
            text.AppendLine($"label={label}");
            text.AppendLine($"result={summary.result}");
            text.AppendLine($"errors={summary.totalErrors}");
            text.AppendLine($"warnings={summary.totalWarnings}");
            text.AppendLine($"totalSize={summary.totalSize}");
            text.AppendLine($"totalTime={summary.totalTime}");
            text.AppendLine($"outputPath={summary.outputPath}");
            text.AppendLine();

            foreach (BuildStep step in report.steps)
            {
                text.AppendLine($"STEP: {step.name}; duration={step.duration}; depth={step.depth}; messages={step.messages.Length}");
                foreach (BuildStepMessage message in step.messages)
                {
                    text.AppendLine($"  [{message.type}] {message.content}");
                }
            }

            File.WriteAllText(path, text.ToString());
        }

        private static void CaptureUnityLog(string condition, string stackTrace, LogType type)
        {
            lock (LogLock)
            {
                Directory.CreateDirectory(LogsDirectory);
                File.AppendAllText(
                    CapturedUnityLog,
                    $"[{DateTime.UtcNow:O}] [{type}] {condition}{Environment.NewLine}" +
                    (string.IsNullOrWhiteSpace(stackTrace) ? string.Empty : stackTrace + Environment.NewLine));
            }
        }

        private static void AppendSummary(string message)
        {
            Directory.CreateDirectory(LogsDirectory);
            File.AppendAllText(SummaryLog, $"[{DateTime.UtcNow:O}] {message}{Environment.NewLine}");
        }
    }
}
#endif
