import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';

class _DepthDecor extends StatelessWidget {
  final Widget child;
  final BorderRadius borderRadius;
  final Color baseColor;
  final Color accentColor;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final double glow;
  final double borderOpacity;
  final bool solid;

  const _DepthDecor({
    required this.child,
    required this.borderRadius,
    required this.baseColor,
    required this.accentColor,
    required this.padding,
    this.pressed = false,
    this.glow = 18,
    this.borderOpacity = .36,
    this.solid = false,
  });

  @override
  Widget build(BuildContext context) {
    final surface = Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(
          top: pressed ? 5 : 0,
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: borderRadius,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(.36),
                    Colors.black.withOpacity(.58),
                  ],
                ),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(.55), blurRadius: pressed ? 12 : 22, offset: Offset(0, pressed ? 7 : 16)),
                  BoxShadow(color: accentColor.withOpacity(.10), blurRadius: glow),
                ],
              ),
            ),
          ),
        ),
        AnimatedContainer(
          duration: const Duration(milliseconds: 110),
          margin: EdgeInsets.only(bottom: pressed ? 1 : 5),
          decoration: BoxDecoration(
            borderRadius: borderRadius,
            border: Border.all(color: accentColor.withOpacity(borderOpacity)),
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: solid
                  ? [baseColor.withOpacity(.98), baseColor.withOpacity(.90)]
                  : [accentColor.withOpacity(.18), baseColor.withOpacity(.98)],
            ),
            boxShadow: [
              BoxShadow(color: accentColor.withOpacity(.18), blurRadius: glow),
              BoxShadow(color: Colors.white.withOpacity(.035), blurRadius: 8, offset: const Offset(0, -2)),
            ],
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  margin: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular((borderRadius.topLeft.x - 5).clamp(8, 22).toDouble()),
                    border: Border.all(color: accentColor.withOpacity(.16)),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withOpacity(.045),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(12, 12, 12, 18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular((borderRadius.topLeft.x - 11).clamp(6, 18).toDouble()),
                    border: Border.all(color: Colors.white.withOpacity(.055)),
                  ),
                ),
              ),
              Padding(padding: padding, child: child),
            ],
          ),
        ),
      ],
    );

    return surface;
  }
}

class NeonButton extends StatefulWidget {
  final String label;
  final String? icon;
  final VoidCallback? onTap;
  final Color? color;
  final bool small;
  final bool expand;

  const NeonButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.color,
    this.small = false,
    this.expand = false,
  });

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = widget.color ?? theme.primary;
    final enabled = widget.onTap != null;
    final radius = BorderRadius.circular(widget.small ? 14 : 18);

    final content = AnimatedOpacity(
      duration: const Duration(milliseconds: 120),
      opacity: enabled ? 1 : .42,
      child: AnimatedScale(
        scale: _pressed && enabled ? .982 : 1,
        duration: const Duration(milliseconds: 90),
        child: _DepthDecor(
          borderRadius: radius,
          baseColor: theme.panel,
          accentColor: color,
          padding: EdgeInsets.symmetric(horizontal: widget.small ? 14 : 18, vertical: widget.small ? 11 : 13),
          pressed: _pressed && enabled,
          glow: widget.small ? 14 : 22,
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: widget.small ? 42 : 54),
            child: Row(
              mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.icon != null) ...[
                  AppIcons.icon(widget.icon!, size: widget.small ? 17 : 19, color: theme.text),
                  const SizedBox(width: 8),
                ],
                Flexible(
                  child: Text(
                    widget.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: theme.text,
                      fontWeight: FontWeight.w900,
                      fontSize: widget.small ? 14 : 17,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    return Semantics(
      button: true,
      enabled: enabled,
      label: widget.label,
      child: MouseRegion(
        cursor: enabled ? SystemMouseCursors.click : SystemMouseCursors.forbidden,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
          onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
          onTapUp: enabled
              ? (_) {
                  setState(() => _pressed = false);
                  widget.onTap?.call();
                }
              : null,
          child: widget.expand ? SizedBox(width: double.infinity, child: content) : content,
        ),
      ),
    );
  }
}

class NeonPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;

  const NeonPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = borderColor ?? theme.primary;
    return _DepthDecor(
      borderRadius: BorderRadius.circular(22),
      baseColor: theme.panel,
      accentColor: color,
      padding: padding,
      glow: 24,
      child: child,
    );
  }
}

class Chip3D extends StatelessWidget {
  final String text;
  final bool gem;

  const Chip3D({super.key, required this.text, this.gem = false});

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = gem ? theme.secondary : theme.accent;
    return _DepthDecor(
      borderRadius: BorderRadius.circular(14),
      baseColor: theme.panel,
      accentColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      glow: 14,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppIcons.icon(gem ? 'gem' : 'coin', size: 16, color: color),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class StatBadge extends StatelessWidget {
  final String text;
  final Color? color;

  const StatBadge(this.text, {super.key, this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final accent = color ?? theme.primary;
    return _DepthDecor(
      borderRadius: BorderRadius.circular(12),
      baseColor: theme.panel,
      accentColor: accent,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      glow: 10,
      borderOpacity: .22,
      child: Text(text, style: TextStyle(color: theme.dim, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

void showNeonMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message), duration: const Duration(milliseconds: 1900)));
}

Future<bool> showNeonConfirm(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'تأیید',
  bool danger = false,
}) async {
  final state = context.read<AppState>();
  final result = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      backgroundColor: state.theme.panel,
      title: Text(title, style: TextStyle(color: danger ? state.theme.danger : state.theme.text, fontWeight: FontWeight.w900)),
      content: Text(message, style: TextStyle(color: state.theme.dim, height: 1.7)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('انصراف')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: danger ? state.theme.danger : state.theme.primary),
          onPressed: () => Navigator.pop(dialogContext, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}
