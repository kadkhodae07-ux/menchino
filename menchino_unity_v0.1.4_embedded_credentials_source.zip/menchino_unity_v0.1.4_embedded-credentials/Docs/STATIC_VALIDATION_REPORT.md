# گزارش اعتبارسنجی استاتیک نسخه 0.1.4

- تاریخ تولید: 2026-07-18
- Unity: `2022.3.62f1`
- دامنه: ساختار پروژه، ZIP، Workflow، لایسنس تعبیه‌شده، JSON، Meta/GUID، Scene registration، تعادل نحوی C#، نسخه Android و آیکن‌ها
- نتیجه: کنترل‌های استاتیک اصلی موفق؛ خطای ساختاری شناسایی نشد

## کنترل‌های موفق

- فایل ZIP بدون خطای فشرده‌سازی باز می‌شود.
- ZIP دارای یک پوشه ریشه مشخص است.
- فایل `.unity-ci/Unity_lic.ulf` داخل سورس وجود دارد.
- لایسنس تعبیه‌شده با فایل ULF ورودی بایت‌به‌بایت یکسان است.
- Workflow از Secretهای `UNITY_LICENSE`، `UNITY_EMAIL` و `UNITY_PASSWORD` وابستگی ندارد.
- Workflow، سورس ZIP را با کنترل Path Traversal استخراج می‌کند.
- Workflow، لایسنس داخلی را با متغیر چندخطی `GITHUB_ENV` در اختیار GameCI قرار می‌دهد.
- Workflow از `game-ci/unity-test-runner@v4` و `game-ci/unity-builder@v4` استفاده می‌کند.
- Workflow از جدیدترین ZIP معتبر بر اساس SemVer استفاده می‌کند.
- Artifact موفق یک فایل ZIP مستقیم است که دقیقاً دو APK دارد.
- در شکست، لاگ‌های Unity و خلاصه خطا به‌صورت Artifact جداگانه تحویل می‌شوند.
- پس از موفقیت، Artifactها و Runهای قبلی منچینو حذف می‌شوند.
- `Assets`، `Packages` و `ProjectSettings` کامل هستند.
- نسخه Unity برابر `2022.3.62f1` باقی مانده است.
- نسخه اپ به `0.1.4` و Version Code به `4` ارتقا یافته است.
- خروجی Build برابر `Builds/Android/Menchino-arm64-v8a.apk` و `Builds/Android/Menchino-universal.apk` است.
- تمام JSONها معتبر هستند.
- GUIDهای Meta یکتا هستند.
- تمام Assetها و پوشه‌های داخل `Assets` فایل Meta دارند.
- تمام Sceneها در Build Settings ثبت شده‌اند.
- جداکننده‌های نحوی 20 فایل C# متعادل هستند.
- تمام آیکن‌های Android مربع و در ابعاد مورد انتظار هستند.

## محدودیت

Unity Editor و Android SDK در محیط بررسی نصب نبودند؛ بنابراین Compile واقعی Unity، اجرای Test Runner و تولید APK در این مرحله انجام نشد. این سه کنترل در GitHub Actions اجرا خواهند شد.
