import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';

class ShopScreen extends StatefulWidget {
  final bool embedded;
  final VoidCallback? onBack;

  const ShopScreen({super.key, this.embedded = false, this.onBack});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  String _tab = 'rackets';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;

    final content = SafeArea(
      top: true,
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
        child: Column(
          children: [
            GamePageHeader(
              title: 'فروشگاه PHONG',
              subtitle: 'تجهیزات، آواتار و بسته‌های سکه و جم',
              onBack: widget.onBack,
              actions: [
                Chip3D(text: '${state.coins}'),
                const SizedBox(width: 5),
                Chip3D(text: '${state.gems}', gem: true),
              ],
            ),
            const SizedBox(height: 12),
            NeonPanel(
              padding: const EdgeInsets.all(7),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _TabButton(label: 'راکت', icon: 'racket', active: _tab == 'rackets', onTap: () => setState(() => _tab = 'rackets')),
                    const SizedBox(width: 7),
                    _TabButton(label: 'توپ', icon: 'ball', active: _tab == 'balls', onTap: () => setState(() => _tab = 'balls')),
                    const SizedBox(width: 7),
                    _TabButton(label: 'آرنا', icon: 'arena', active: _tab == 'arenas', onTap: () => setState(() => _tab = 'arenas')),
                    const SizedBox(width: 7),
                    _TabButton(label: 'آواتار', icon: 'profile', active: _tab == 'avatars', onTap: () => setState(() => _tab = 'avatars')),
                    const SizedBox(width: 7),
                    _TabButton(label: 'سکه و جم', icon: 'gem', active: _tab == 'currency', onTap: () => setState(() => _tab = 'currency')),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(child: _buildTab(state)),
          ],
        ),
      ),
    );

    if (widget.embedded) return content;
    return Scaffold(backgroundColor: theme.bg, body: content);
  }

  Widget _buildTab(AppState state) {
    if (_tab == 'avatars') return _avatarStore(state);
    if (_tab == 'currency') return _currencyStore(state);
    return _equipmentStore(state);
  }

  Widget _equipmentStore(AppState state) {
    final theme = state.theme;
    final items = Catalog.of(_tab);
    return ListView.separated(
      padding: const EdgeInsets.only(bottom: 20),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final item = items[index];
        final owned = state.owned.contains(item.id);
        final equipped = state.selected[item.type] == item.id;
        final color = rarityColor[item.rarity] ?? theme.primary;
        return NeonPanel(
          borderColor: color,
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _ItemPreview(item: item, color: color),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: color.withOpacity(.08),
                      border: Border.all(color: color.withOpacity(.20)),
                    ),
                    child: Center(child: AppIcons.icon(item.icon, size: 24, color: color)),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 16)),
                        const SizedBox(height: 3),
                        Text(rarityLabel[item.rarity] ?? item.rarity, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(item.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim, fontSize: 12, height: 1.5)),
                      ],
                    ),
                  ),
                  if (equipped) StatBadge('فعال', color: theme.accent),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(spacing: 6, runSpacing: 6, children: _itemStats(item).map((text) => StatBadge(text, color: color)).toList()),
              const SizedBox(height: 12),
              Row(
                children: [
                  if (!owned) Chip3D(text: item.price == 0 ? 'رایگان' : '${item.price}'),
                  if (owned) StatBadge('خریداری شده', color: theme.accent),
                  const Spacer(),
                  if (equipped)
                    NeonButton(label: 'تجهیز شده', icon: 'check', small: true, color: theme.accent, onTap: null)
                  else if (owned)
                    NeonButton(
                      label: 'تجهیز',
                      icon: 'check',
                      small: true,
                      color: theme.accent,
                      onTap: () async {
                        await state.equip(item);
                        if (context.mounted) showNeonMessage(context, '${item.name} تجهیز شد.');
                      },
                    )
                  else
                    NeonButton(
                      label: 'خرید',
                      icon: 'shop',
                      small: true,
                      color: theme.gold,
                      onTap: () async {
                        final success = await state.buy(item);
                        if (!context.mounted) return;
                        showNeonMessage(context, success ? '${item.name} خریداری شد.' : 'سکه کافی نیست.');
                      },
                    ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _avatarStore(AppState state) {
    final theme = state.theme;
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 760 ? 4 : (constraints.maxWidth >= 390 ? 3 : 2);
        return GridView.builder(
          padding: const EdgeInsets.only(bottom: 22),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: columns >= 3 ? .82 : .76,
          ),
          itemCount: avatars.length,
          itemBuilder: (context, index) {
            final spec = avatars[index];
            final selected = state.avatar == index;
            return NeonPanel(
              borderColor: selected ? theme.accent : spec.shirt,
              padding: const EdgeInsets.all(9),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AvatarBadge(index: index, size: columns >= 3 ? 58 : 68),
                  const SizedBox(height: 7),
                  Text(spec.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: columns >= 3 ? 13 : 15)),
                  const SizedBox(height: 3),
                  Text('آواتار ${spec.gender}', style: TextStyle(color: theme.dim, fontSize: 11)),
                  const Spacer(),
                  if (selected)
                    StatBadge('انتخاب شده', color: theme.accent)
                  else
                    NeonButton(
                      label: 'انتخاب',
                      icon: 'profile',
                      small: true,
                      color: spec.shirt,
                      onTap: () async {
                        await state.setAvatar(index);
                        if (context.mounted) showNeonMessage(context, 'آواتار ${spec.name} انتخاب شد.');
                      },
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _currencyStore(AppState state) {
    final theme = state.theme;
    final packs = <_CurrencyPack>[
      const _CurrencyPack('سکه استارتر', 'coin', '1,000 سکه', 'به‌زودی • ۲۹ هزار تومان', false),
      const _CurrencyPack('سکه پرو', 'coin', '5,000 سکه', 'به‌زودی • ۹۹ هزار تومان', false),
      const _CurrencyPack('سکه الیت', 'coin', '12,000 سکه', 'به‌زودی • ۱۹۹ هزار تومان', false),
      const _CurrencyPack('جم استارتر', 'gem', '50 جم', 'به‌زودی • ۴۹ هزار تومان', true),
      const _CurrencyPack('جم پرو', 'gem', '150 جم', 'به‌زودی • ۱۱۹ هزار تومان', true),
      const _CurrencyPack('باندل قهرمان', 'crown', '6,000 سکه + 100 جم', 'به‌زودی • ۱۶۹ هزار تومان', true),
    ];
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        NeonPanel(
          borderColor: theme.gold,
          child: Row(
            children: [
              AppIcons.icon('shop', size: 30, color: theme.gold),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'بسته‌های سکه و جم آماده‌اند. پرداخت در نسخه نهایی بازار و مایکت فعال می‌شود و تا آن زمان موجودی تغییر نمی‌کند.',
                  style: TextStyle(color: theme.dim, height: 1.65, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        for (final pack in packs) ...[
          NeonPanel(
            borderColor: pack.gem ? theme.secondary : theme.gold,
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (pack.gem ? theme.secondary : theme.gold).withOpacity(.10),
                    border: Border.all(color: (pack.gem ? theme.secondary : theme.gold).withOpacity(.28)),
                  ),
                  child: Center(child: AppIcons.icon(pack.icon, size: 27, color: pack.gem ? theme.secondary : theme.gold)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(pack.title, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text(pack.amount, style: TextStyle(color: pack.gem ? theme.secondary : theme.gold, fontWeight: FontWeight.w900, fontSize: 14)),
                      const SizedBox(height: 3),
                      Text(pack.price, style: TextStyle(color: theme.dim, fontSize: 11)),
                    ],
                  ),
                ),
                NeonButton(
                  label: 'خرید',
                  icon: 'shop',
                  small: true,
                  color: pack.gem ? theme.secondary : theme.gold,
                  onTap: () => showNeonMessage(context, 'پرداخت این بسته در نسخه نهایی بازار و مایکت فعال می‌شود.'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }

  List<String> _itemStats(Item item) {
    final stats = item.stats;
    final result = <String>[];
    void add(String key, String label, {double defaultValue = 1}) {
      final value = stats[key];
      if (value != null && value != defaultValue) result.add('$label ×${_fmt(value)}');
    }

    add('widthMult', 'عرض');
    add('spinMult', 'اسپین');
    add('moveSpeedMult', 'سرعت حرکت');
    add('speedMult', 'سرعت توپ');
    add('radiusMult', 'اندازه');
    add('powerRate', 'پاورآپ');
    add('speedIncrementMult', 'رشد سرعت');
    add('baseSpeedMult', 'سرعت پایه');
    add('maxSpeedMult', 'حداکثر سرعت');
    add('powerDurationMult', 'مدت پاورآپ');
    add('aiSpeedMult', 'سرعت حریف');
    if ((stats['hitSpeed'] ?? 0) > 0) result.add('ضربه +${_fmt(stats['hitSpeed']!)}');
    if ((stats['magnet'] ?? 0) > 0) result.add('جذب توپ');
    if ((stats['startShield'] ?? 0) > 0) result.add('سپر ابتدایی');
    if ((stats['echoSlow'] ?? 0) > 0) result.add('اکو');
    if ((stats['aiErrorBonus'] ?? 0) > 0) result.add('خطای دید حریف');
    if ((stats['coinBonus'] ?? 0) > 0) result.add('سکه +${(stats['coinBonus']! * 100).round()}٪');
    if ((stats['curve'] ?? 0) > 0) result.add('مسیر خمیده');
    if ((stats['minVerticalBonus'] ?? 0) > 0) result.add('کنترل بیشتر');
    if ((stats['sideInset'] ?? 0) > 0) result.add('زمین فشرده');
    if (result.isEmpty) result.add('متعادل');
    return result;
  }

  String _fmt(double value) => value == value.roundToDouble() ? value.round().toString() : value.toStringAsFixed(2);
}

class _CurrencyPack {
  final String title;
  final String icon;
  final String amount;
  final String price;
  final bool gem;

  const _CurrencyPack(this.title, this.icon, this.amount, this.price, this.gem);
}

class _TabButton extends StatelessWidget {
  final String label;
  final String icon;
  final bool active;
  final VoidCallback onTap;

  const _TabButton({required this.label, required this.icon, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        constraints: const BoxConstraints(minWidth: 78),
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: active ? theme.primary.withOpacity(.14) : Colors.transparent,
          border: Border.all(color: active ? theme.primary.withOpacity(.38) : theme.dim.withOpacity(.08)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppIcons.icon(icon, size: 15, color: active ? theme.primary : theme.dim),
            const SizedBox(width: 5),
            Text(label, maxLines: 1, style: TextStyle(color: active ? theme.text : theme.dim, fontWeight: FontWeight.w900, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _ItemPreview extends StatelessWidget {
  final Item item;
  final Color color;

  const _ItemPreview({required this.item, required this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return SizedBox(
      height: 104,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: CustomPaint(
          painter: _PreviewPainter(item: item, color: color, bg: theme.canvasBg, grid: theme.grid),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

class _PreviewPainter extends CustomPainter {
  final Item item;
  final Color color;
  final Color bg;
  final Color grid;

  _PreviewPainter({required this.item, required this.color, required this.bg, required this.grid});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = bg);
    canvas.drawCircle(Offset(size.width * .22, size.height * .35), size.height * .65, Paint()..color = color.withOpacity(.10));
    canvas.drawCircle(Offset(size.width * .80, size.height * .70), size.height * .55, Paint()..color = color.withOpacity(.06));

    if (item.type == 'racket') {
      final length = (size.width * (.34 * (item.stats['widthMult'] ?? 1)).clamp(.25, .48)).toDouble();
      final r = Rect.fromCenter(center: Offset(size.width / 2, size.height / 2), width: length, height: 16);
      canvas.drawRRect(RRect.fromRectAndRadius(r.inflate(7), const Radius.circular(16)), Paint()..color = color.withOpacity(.10));
      canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(12)), Paint()..color = color);
      if (item.id.contains('spin') || item.id.contains('flux')) {
        canvas.drawCircle(r.center, 9, Paint()..color = Colors.white.withOpacity(.38)..style = PaintingStyle.stroke..strokeWidth = 2);
      } else if (item.id.contains('turbo') || item.id.contains('blade')) {
        for (var i = -2; i <= 2; i++) {
          canvas.drawLine(Offset(r.center.dx + i * 18, r.top + 2), Offset(r.center.dx + i * 18 + 9, r.bottom - 2), Paint()..color = Colors.white.withOpacity(.28)..strokeWidth = 2);
        }
      } else if (item.id.contains('guardian') || item.id.contains('iron')) {
        canvas.drawRRect(RRect.fromRectAndRadius(r.inflate(7), const Radius.circular(18)), Paint()..color = color.withOpacity(.75)..style = PaintingStyle.stroke..strokeWidth = 2);
      }
    } else if (item.type == 'ball') {
      final radius = (14 * (item.stats['radiusMult'] ?? 1)).toDouble();
      final center = Offset(size.width / 2, size.height / 2);
      final ballColor = item.color ?? color;
      canvas.drawCircle(center, radius + 12, Paint()..color = ballColor.withOpacity(.10));
      canvas.drawCircle(center, radius, Paint()..color = ballColor);
      if (item.id.contains('gold') || item.id.contains('solar')) {
        canvas.drawCircle(center, radius + 5, Paint()..color = color.withOpacity(.85)..style = PaintingStyle.stroke..strokeWidth = 2);
      } else if (item.id.contains('plasma') || item.id.contains('nebula')) {
        canvas.drawCircle(center, radius + 7, Paint()..color = ballColor.withOpacity(.60)..style = PaintingStyle.stroke..strokeWidth = 1.5);
        canvas.drawCircle(center, radius + 13, Paint()..color = ballColor.withOpacity(.25)..style = PaintingStyle.stroke..strokeWidth = 1);
      } else if (item.id.contains('ghost')) {
        canvas.drawCircle(center + const Offset(8, 0), radius, Paint()..color = ballColor.withOpacity(.22));
      }
    } else {
      final line = Paint()..color = grid.withOpacity(.55)..strokeWidth = 1;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(12, 12, size.width - 24, size.height - 24), const Radius.circular(18)), Paint()..color = color.withOpacity(.45)..style = PaintingStyle.stroke..strokeWidth = 1.2);
      canvas.drawLine(Offset(size.width / 2, 12), Offset(size.width / 2, size.height - 12), line);
      canvas.drawCircle(Offset(size.width / 2, size.height / 2), 13, Paint()..color = color.withOpacity(.34)..style = PaintingStyle.stroke..strokeWidth = 1.2);
      if (item.id.contains('speed') || item.id.contains('blaze')) {
        for (var y = 28.0; y < size.height - 18; y += 24) {
          canvas.drawLine(Offset(28, y), Offset(50, y), Paint()..color = color.withOpacity(.34)..strokeWidth = 3);
          canvas.drawLine(Offset(size.width - 50, y), Offset(size.width - 28, y), Paint()..color = color.withOpacity(.34)..strokeWidth = 3);
        }
      } else if (item.id.contains('void') || item.id.contains('orbit')) {
        canvas.drawCircle(Offset(size.width / 2, size.height / 2), 30, Paint()..color = Colors.black.withOpacity(.40));
        canvas.drawCircle(Offset(size.width / 2, size.height / 2), 34, Paint()..color = color.withOpacity(.40)..style = PaintingStyle.stroke..strokeWidth = 1.4);
      } else if (item.id.contains('fortune') || item.id.contains('elite')) {
        canvas.drawCircle(const Offset(30, 30), 5, Paint()..color = color);
        canvas.drawCircle(Offset(size.width - 30, size.height - 30), 5, Paint()..color = color);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PreviewPainter oldDelegate) => oldDelegate.item.id != item.id || oldDelegate.color != color || oldDelegate.bg != bg;
}
