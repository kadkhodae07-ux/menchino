import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';

class RankScreen extends StatelessWidget {
  final bool embedded;
  final VoidCallback? onBack;

  const RankScreen({super.key, this.embedded = false, this.onBack});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = state.theme;
    final tier = _tierFor(state.leaguePoints);
    final next = _nextTier(state.leaguePoints);
    final rangeEnd = next?.min ?? tier.min + 500;
    final progress = ((state.leaguePoints - tier.min) / max(1, rangeEnd - tier.min)).clamp(0.0, 1.0).toDouble();
    final matches = state.stats['matches'] ?? 0;
    final wins = state.stats['wins'] ?? 0;
    final losses = state.stats['losses'] ?? 0;
    final winRate = matches > 0 ? (wins * 100 / matches).round() : 0;

    final content = SafeArea(
      top: true,
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GamePageHeader(
              title: 'رتبه‌بندی',
              subtitle: 'پیشرفت فصل، جایگاه لیگ و رکوردهای رقابتی',
              onBack: onBack,
            ),
            const SizedBox(height: 14),
            NeonPanel(
              borderColor: tier.color,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 15),
              child: Row(
                children: [
                  Container(
                    width: 78,
                    height: 78,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [tier.color.withOpacity(.22), tier.color.withOpacity(.05), Colors.transparent],
                      ),
                      border: Border.all(color: tier.color.withOpacity(.32)),
                      boxShadow: [BoxShadow(color: tier.color.withOpacity(.14), blurRadius: 22)],
                    ),
                    child: Center(child: AppIcons.icon('rank', size: 36, color: tier.color)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('جایگاه فصل', style: TextStyle(color: theme.dim, fontSize: 11, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text(tier.name, style: TextStyle(color: theme.text, fontSize: 23, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 3),
                        Text('${state.leaguePoints} امتیاز', style: TextStyle(color: tier.color, fontSize: 15, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 10),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(99),
                          child: LinearProgressIndicator(
                            minHeight: 9,
                            value: progress,
                            color: tier.color,
                            backgroundColor: tier.color.withOpacity(.10),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          next == null ? 'بالاترین لیگ فعلی' : '${max(0, next.min - state.leaguePoints)} امتیاز تا ${next.name}',
                          style: TextStyle(color: theme.dim, fontSize: 10.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: _MetricCard(label: 'برد', value: '$wins', icon: 'crown', color: theme.accent)),
                const SizedBox(width: 10),
                Expanded(child: _MetricCard(label: 'درصد برد', value: '$winRate٪', icon: 'rank', color: theme.primary)),
                const SizedBox(width: 10),
                Expanded(child: _MetricCard(label: 'رالی', value: '${state.stats['bestRally'] ?? 0}', icon: 'fast', color: theme.secondary)),
              ],
            ),
            const SizedBox(height: 14),
            NeonPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      AppIcons.icon('rank', size: 23, color: theme.primary),
                      const SizedBox(width: 9),
                      Expanded(child: Text('جدول لیگ‌ها', style: TextStyle(color: theme.text, fontSize: 17, fontWeight: FontWeight.w900))),
                      StatBadge('فصل ${state.season}', color: theme.primary),
                    ],
                  ),
                  const SizedBox(height: 14),
                  for (var index = 0; index < _tiers.length; index++) ...[
                    _LeagueRow(
                      tier: _tiers[index],
                      active: _tiers[index].name == tier.name,
                      reached: state.leaguePoints >= _tiers[index].min,
                    ),
                    if (index != _tiers.length - 1) const SizedBox(height: 9),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 14),
            NeonPanel(
              borderColor: theme.secondary,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('رکورد رقابتی', style: TextStyle(color: theme.text, fontSize: 17, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  _statRow(theme, 'مسابقه‌های ثبت‌شده', '$matches'),
                  _divider(theme),
                  _statRow(theme, 'بردها', '$wins'),
                  _divider(theme),
                  _statRow(theme, 'باخت‌ها', '$losses'),
                  _divider(theme),
                  _statRow(theme, 'بهترین برد پیاپی', '${state.stats['bestStreak'] ?? 0}'),
                  _divider(theme),
                  _statRow(theme, 'پاورآپ جمع‌شده', '${state.stats['powerCollected'] ?? 0}'),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'جدول جهانی بعد از اتصال بخش آنلاین به همین صفحه اضافه می‌شود.',
              textAlign: TextAlign.center,
              style: TextStyle(color: theme.dim.withOpacity(.72), fontSize: 10.5),
            ),
          ],
        ),
      ),
    );

    if (embedded) return content;
    return Scaffold(backgroundColor: theme.bg, body: content);
  }

  Widget _statRow(dynamic theme, String label, String value) => Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: theme.dim, fontSize: 13))),
          Text(value, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
        ],
      );

  Widget _divider(dynamic theme) => Divider(height: 20, color: theme.dim.withOpacity(.09));

  _LeagueTier _tierFor(int points) {
    var current = _tiers.first;
    for (final tier in _tiers) {
      if (points >= tier.min) current = tier;
    }
    return current;
  }

  _LeagueTier? _nextTier(int points) {
    for (final tier in _tiers) {
      if (tier.min > points) return tier;
    }
    return null;
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final String icon;
  final Color color;

  const _MetricCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return NeonPanel(
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      child: Column(
        children: [
          AppIcons.icon(icon, size: 20, color: color),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(color: theme.text, fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.dim, fontSize: 9.5, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _LeagueRow extends StatelessWidget {
  final _LeagueTier tier;
  final bool active;
  final bool reached;

  const _LeagueRow({required this.tier, required this.active, required this.reached});

  @override
  Widget build(BuildContext context) {
    final theme = context.read<AppState>().theme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: active ? tier.color.withOpacity(.10) : theme.bg.withOpacity(.16),
        border: Border.all(color: active ? tier.color.withOpacity(.36) : theme.dim.withOpacity(.08)),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(shape: BoxShape.circle, color: tier.color.withOpacity(reached ? .15 : .05)),
            child: Center(child: AppIcons.icon(reached ? 'rank' : 'lock', size: 17, color: reached ? tier.color : theme.dim.withOpacity(.45))),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(tier.name, style: TextStyle(color: active ? theme.text : theme.dim, fontWeight: FontWeight.w900))),
          Text('${tier.min}+ امتیاز', style: TextStyle(color: reached ? tier.color : theme.dim.withOpacity(.6), fontSize: 11, fontWeight: FontWeight.w800)),
          if (active) ...[
            const SizedBox(width: 8),
            StatBadge('فعلی', color: tier.color),
          ],
        ],
      ),
    );
  }
}

class _LeagueTier {
  final String name;
  final int min;
  final Color color;

  const _LeagueTier(this.name, this.min, this.color);
}

const _tiers = [
  _LeagueTier('برنزی', 0, Color(0xFFC98055)),
  _LeagueTier('نقره‌ای', 200, Color(0xFFC7D2E5)),
  _LeagueTier('طلایی', 500, Color(0xFFFFD66A)),
  _LeagueTier('پلاتینیوم', 900, Color(0xFF62E6FF)),
  _LeagueTier('الماس', 1400, Color(0xFF9A84FF)),
];
