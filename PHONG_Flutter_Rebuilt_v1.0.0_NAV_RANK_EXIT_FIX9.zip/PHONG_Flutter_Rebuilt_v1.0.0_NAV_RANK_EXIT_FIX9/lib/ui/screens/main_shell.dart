import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../widgets/neon.dart';
import 'lobby_screen.dart';
import 'missions_screen.dart';
import 'profile_screen.dart';
import 'rank_screen.dart';
import 'shop_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 2;
  bool _exitDialogOpen = false;

  void _selectTab(int index) {
    if (index < 0 || index > 4) return;
    setState(() => _index = index);
  }

  void _backToHome() => _selectTab(2);

  Future<void> _handleBack() async {
    if (_index != 2) {
      _backToHome();
      return;
    }
    if (_exitDialogOpen || !mounted) return;
    _exitDialogOpen = true;
    final exit = await showNeonConfirm(
      context,
      title: 'خروج از PHONG',
      message: 'می‌خوای از بازی خارج بشی؟',
      confirmLabel: 'خروج',
      cancelLabel: 'ماندن',
      danger: true,
    );
    _exitDialogOpen = false;
    if (exit) {
      await SystemNavigator.pop();
    }
  }

  static const _tabs = [
    ('shop', 'فروشگاه'),
    ('mission', 'ماموریت'),
    ('home', 'خانه'),
    ('rank', 'رتبه‌بندی'),
    ('profile', 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        if (!didPop) _handleBack();
      },
      child: Scaffold(
        backgroundColor: theme.bg,
        body: IndexedStack(
          index: _index,
          children: [
            ShopScreen(embedded: true, onBack: _backToHome),
            MissionsScreen(embedded: true, onBack: _backToHome),
            LobbyScreen(onTabSelected: _selectTab),
            RankScreen(embedded: true, onBack: _backToHome),
            ProfileScreen(embedded: true, onBack: _backToHome),
          ],
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          minimum: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: NeonPanel(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
            child: SizedBox(
              height: 60,
              child: Row(
                children: List.generate(_tabs.length, (index) {
                  final active = index == _index;
                  final home = index == 2;
                  final color = active ? theme.primary : theme.dim;
                  return Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        context.read<AppState>().audio.play('tap');
                        _selectTab(index);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 170),
                        transform: Matrix4.translationValues(0, home && active ? -2 : 0, 0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 170),
                              width: home ? 38 : 34,
                              height: home ? 38 : 34,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: active ? theme.primary.withOpacity(.12) : Colors.transparent,
                                border: Border.all(color: active ? theme.primary.withOpacity(.28) : Colors.transparent),
                                boxShadow: active ? [BoxShadow(color: theme.primary.withOpacity(.10), blurRadius: 12)] : null,
                              ),
                              child: Center(child: AppIcons.icon(_tabs[index].$1, size: home ? 20 : 18, color: color)),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              _tabs[index].$2,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: active ? theme.text : theme.dim.withOpacity(.68),
                                fontSize: 8.5,
                                fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
