import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show Ticker;
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/data.dart';
import '../../core/icons.dart';
import '../../core/state/app_state.dart';
import '../../core/theme.dart';
import '../../game/engine.dart';
import '../widgets/avatar_badge.dart';
import '../widgets/neon.dart';

class GameScreen extends StatefulWidget {
  final String? modeOverride;
  final String? friendName;
  final Tournament? tournament;
  final int tournamentRound;

  const GameScreen({
    super.key,
    this.modeOverride,
    this.friendName,
    this.tournament,
    this.tournamentRound = 0,
  });

  factory GameScreen.fromSetup() => const GameScreen();
  factory GameScreen.local(String friendName) => GameScreen(modeOverride: 'local', friendName: friendName);
  factory GameScreen.tournament(Tournament tournament, int round) =>
      GameScreen(modeOverride: 'tournament', tournament: tournament, tournamentRound: round);

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AppState _state;
  late final Engine engine;
  late final Ticker _ticker;
  Duration? _lastTick;
  Size _lastSize = Size.zero;
  bool _resultHandled = false;
  bool _started = false;
  bool _prepared = false;
  bool _retryPending = false;
  bool _confirmingExit = false;
  double _physicsAccumulator = 0;
  int _stableOrientationFrames = 0;
  Completer<void>? _portraitLayoutWaiter;

  static const double _physicsStep = 1 / 60;
  static const int _maxPhysicsStepsPerFrame = 4;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _state = context.read<AppState>();
    final setup = _state.matchSetup;
    final mode = widget.modeOverride ?? (setup['mode'] as String? ?? 'quick');
    final difficulty = mode == 'tournament'
        ? widget.tournament?.difficulty ?? 'hard'
        : mode == 'challenge'
            ? 'hard'
            : setup['difficulty'] as String? ?? 'medium';
    final entry = mode == 'practice' || mode == 'local' || mode == 'tournament'
        ? 0
        : setup['entry'] as int? ?? 0;

    engine = Engine(
      state: _state,
      mode: mode,
      difficulty: difficulty,
      orientation: setup['orientation'] as String? ?? 'portrait',
      entry: entry,
      twoPlayer: mode == 'local',
      friendName: widget.friendName,
      tournament: widget.tournament,
      tournamentRound: widget.tournamentRound,
    );
    engine.addListener(_engineChanged);
    _ticker = createTicker(_tick);

    WidgetsBinding.instance.addPostFrameCallback((_) => _prepare());
  }

  Future<void> _applyGameplayOrientation() async {
    await SystemChrome.setPreferredOrientations(
      engine.isLandscape
          ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
          : [DeviceOrientation.portraitUp],
    );
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Future<void> _restorePortrait({bool waitForLayout = false}) async {
    if (waitForLayout && engine.isLandscape) {
      _portraitLayoutWaiter = Completer<void>();
    }
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    if (waitForLayout && _portraitLayoutWaiter != null) {
      if (_lastSize != Size.zero && _lastSize.height >= _lastSize.width) {
        if (!_portraitLayoutWaiter!.isCompleted) _portraitLayoutWaiter!.complete();
      }
      try {
        await _portraitLayoutWaiter!.future.timeout(const Duration(milliseconds: 1200));
      } on TimeoutException {
        // Some Android skins report the new orientation one frame late.
      } finally {
        _portraitLayoutWaiter = null;
      }
    }
  }

  Future<void> _prepare() async {
    if (!mounted) return;
    await _applyGameplayOrientation();
    if (!mounted) return;
    if (engine.entry > 0) {
      if (_state.coins < engine.entry) {
        showNeonMessage(context, 'سکه کافی برای ورودی مسابقه نداری.');
        Navigator.pop(context);
        return;
      }
      _state.addCoins(-engine.entry);
      await _state.save();
    }
    if (!mounted) return;
    _prepared = true;
    _tryStart();
  }

  bool _matchesRequestedOrientation(Size size) {
    if (size == Size.zero) return false;
    return engine.isLandscape ? size.width > size.height : size.height >= size.width;
  }

  void _tryStart() {
    if (!_prepared || _started || _lastSize == Size.zero || !mounted) return;
    if (!_matchesRequestedOrientation(_lastSize)) return;
    if (_stableOrientationFrames < 2) return;
    engine.resize(_lastSize.width, _lastSize.height);
    engine.start();
    _started = true;
    _lastTick = null;
    _physicsAccumulator = 0;
    if (!_ticker.isActive) _ticker.start();
  }

  void _tryRestart() {
    if (!_retryPending || _lastSize == Size.zero || !mounted) return;
    if (!_matchesRequestedOrientation(_lastSize)) return;
    if (_stableOrientationFrames < 2) return;
    _retryPending = false;
    engine.resize(_lastSize.width, _lastSize.height);
    engine.restart();
    _started = true;
    _lastTick = null;
    _physicsAccumulator = 0;
    if (!_ticker.isActive) _ticker.start();
  }

  void _tick(Duration elapsed) {
    final previous = _lastTick;
    _lastTick = elapsed;
    if (previous == null) return;
    final frameDt = ((elapsed - previous).inMicroseconds / 1000000.0).clamp(0.0, .10).toDouble();
    _physicsAccumulator += frameDt;
    var steps = 0;
    while (_physicsAccumulator >= _physicsStep && steps < _maxPhysicsStepsPerFrame) {
      engine.update(_physicsStep);
      _physicsAccumulator -= _physicsStep;
      steps++;
    }
    if (steps == _maxPhysicsStepsPerFrame && _physicsAccumulator > _physicsStep * 2) {
      _physicsAccumulator = _physicsStep;
    }
  }

  void _engineChanged() {
    if (engine.finished && !_resultHandled) {
      _resultHandled = true;
      _ticker.stop();
      WidgetsBinding.instance.addPostFrameCallback((_) => _finishMatch());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed && engine.started && !engine.paused) {
      engine.setPaused(true);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    engine.removeListener(_engineChanged);
    engine.dispose();
    _ticker.dispose();
    unawaited(_restorePortrait());
    super.dispose();
  }

  Future<void> _finishMatch() async {
    if (!mounted) return;
    final won = engine.bottomScore > engine.topScore;
    _state.stats['matches'] = (_state.stats['matches'] ?? 0) + 1;
    if (won) {
      _state.stats['wins'] = (_state.stats['wins'] ?? 0) + 1;
      _state.stats['streak'] = (_state.stats['streak'] ?? 0) + 1;
      _state.stats['bestStreak'] = max(_state.stats['bestStreak'] ?? 0, _state.stats['streak'] ?? 0).toInt();
    } else {
      _state.stats['losses'] = (_state.stats['losses'] ?? 0) + 1;
      _state.stats['streak'] = 0;
    }
    _state.stats['bestRally'] = max(_state.stats['bestRally'] ?? 0, engine.longestRally).toInt();
    _state.incMission('play');
    if (won) _state.incMission('win');
    if (engine.longestRally >= 10) _state.incMission('rally10');
    if ((engine.difficulty == 'hard' || engine.difficulty == 'pro') && won && engine.mode != 'local') _state.incMission('hardWin');

    if (engine.mode == 'tournament' && engine.tournament != null) {
      await _finishTournament(won);
      return;
    }

    final difficultyBonus = const {'easy': 5, 'medium': 10, 'hard': 18, 'pro': 28}[engine.difficulty] ?? 5;
    final modeBonus = engine.mode == 'challenge' ? 16 : difficultyBonus;
    final scoreDifference = max(0, engine.bottomScore - engine.topScore).toInt();
    final rallyBonus = engine.longestRally ~/ 3;
    var xp = 18 + modeBonus + scoreDifference * 2 + rallyBonus;
    var baseCoins = 8 + modeBonus ~/ 2 + engine.playerGold;
    if (won) {
      xp += 26;
      baseCoins += 14;
    }
    if (engine.mode == 'practice') {
      baseCoins = 0;
      xp ~/= 2;
    }
    if (engine.mode == 'challenge' && won) baseCoins += 20;
    baseCoins = (baseCoins * (1 + engine.coinBonus)).floor();
    final entryPrize = won ? (engine.entry * 2 * .75).floor() : 0;
    final totalCoins = baseCoins + entryPrize;

    _state.addXp(xp);
    _state.addCoins(totalCoins);
    if (engine.mode == 'quick' || engine.mode == 'challenge') {
      _state.leaguePoints = max(0, _state.leaguePoints + (won ? 18 : -8)).toInt();
    }
    await _state.audio.play(won ? 'win' : 'lose');
    await _state.save();
    await _restorePortrait(waitForLayout: true);
    if (!mounted) return;

    final action = await _showResult(
      title: won ? 'پیروزی' : 'شکست',
      win: won,
      info: '+$xp تجربه\nپاداش مسابقه: +$baseCoins سکه\nپاداش ورودی: +$entryPrize سکه\nلیگ: ${_state.leaguePoints} امتیاز\nرالی: ${engine.longestRally}',
      allowRetry: true,
    );
    if (!mounted) return;
    if (action == 'retry') {
      await _retry();
    } else {
      Navigator.pop(context);
    }
  }

  Future<void> _finishTournament(bool won) async {
    final tournament = engine.tournament!;
    final round = max(1, engine.tournamentRound).toInt();
    if (won && round < tournament.rounds) {
      _state.tournament = {'activeId': tournament.id, 'round': round + 1};
      _state.addXp(35);
      await _state.audio.play('win');
      await _state.save();
      await _restorePortrait(waitForLayout: true);
      if (!mounted) return;
      await _showResult(
        title: 'پیروزی',
        win: true,
        info: 'به دور ${round + 1} رفتی\n+35 تجربه',
        allowRetry: false,
      );
    } else if (won) {
      _state.addCoins(tournament.prize);
      _state.addXp(90);
      _state.tournament = {'activeId': null, 'round': 0};
      await _state.audio.play('win');
      await _state.save();
      await _restorePortrait(waitForLayout: true);
      if (!mounted) return;
      await _showResult(
        title: 'قهرمان شدی',
        win: true,
        info: 'پاداش تورنمنت: +${tournament.prize} سکه\n+90 تجربه',
        allowRetry: false,
      );
    } else {
      _state.tournament = {'activeId': null, 'round': 0};
      _state.addXp(10);
      await _state.audio.play('lose');
      await _state.save();
      await _restorePortrait(waitForLayout: true);
      if (!mounted) return;
      await _showResult(
        title: 'حذف شدی',
        win: false,
        info: 'در تورنمنت حذف شدی\n+10 تجربه',
        allowRetry: false,
      );
    }
    if (mounted) Navigator.pop(context);
  }

  Future<String?> _showResult({
    required String title,
    required bool win,
    required String info,
    required bool allowRetry,
  }) {
    final theme = _state.theme;
    final accent = win ? theme.accent : theme.danger;
    final infoLines = info.split('\n').where((line) => line.trim().isNotEmpty).toList();
    return showGeneralDialog<String>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(.72),
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (dialogContext, animation, secondaryAnimation) => SafeArea(
        child: Material(
          color: Colors.transparent,
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: NeonPanel(
                  borderColor: accent,
                  padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 74,
                        height: 74,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: accent.withOpacity(.10),
                          border: Border.all(color: accent.withOpacity(.30)),
                          boxShadow: [BoxShadow(color: accent.withOpacity(.12), blurRadius: 24)],
                        ),
                        child: Center(
                          child: AppIcons.icon(win ? 'crown' : 'close', size: 34, color: accent),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(title, textAlign: TextAlign.center, style: TextStyle(color: accent, fontSize: 28, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          color: theme.bg.withOpacity(.36),
                          border: Border.all(color: theme.dim.withOpacity(.10)),
                        ),
                        child: Text(
                          '${engine.bottomScore}  :  ${engine.topScore}',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: theme.text, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 1.4),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        alignment: WrapAlignment.center,
                        children: infoLines.map((line) => StatBadge(line, color: accent)).toList(),
                      ),
                      const SizedBox(height: 18),
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final compact = constraints.maxWidth < 310;
                          final exit = NeonButton(
                            label: allowRetry ? 'بازگشت به لابی' : 'باشه',
                            small: true,
                            expand: true,
                            onTap: () => Navigator.pop(dialogContext, 'exit'),
                          );
                          final retry = NeonButton(
                            label: 'بازی مجدد',
                            icon: 'restart',
                            small: true,
                            expand: true,
                            color: theme.accent,
                            onTap: () => Navigator.pop(dialogContext, 'retry'),
                          );
                          if (!allowRetry) return exit;
                          if (compact) {
                            return Column(children: [retry, const SizedBox(height: 10), exit]);
                          }
                          return Row(
                            children: [
                              Expanded(child: retry),
                              const SizedBox(width: 10),
                              Expanded(child: exit),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      transitionBuilder: (context, animation, secondaryAnimation, child) => FadeTransition(
        opacity: animation,
        child: ScaleTransition(scale: Tween<double>(begin: .96, end: 1).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)), child: child),
      ),
    );
  }

  Future<void> _retry() async {
    if (engine.entry > 0) {
      if (_state.coins < engine.entry) {
        if (mounted) showNeonMessage(context, 'سکه کافی برای بازی مجدد نداری.');
        if (mounted) Navigator.pop(context);
        return;
      }
      _state.addCoins(-engine.entry);
      await _state.save();
    }
    _resultHandled = false;
    _lastTick = null;
    _started = false;
    _retryPending = true;
    await _applyGameplayOrientation();
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryRestart());
  }

  Future<void> _exitGame() async {
    await _restorePortrait(waitForLayout: engine.isLandscape);
    if (!mounted) return;
    engine.abandon();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        await _confirmMatchExit(resumeOnCancel: true);
      },
      child: Scaffold(
        backgroundColor: theme.bg,
        body: LayoutBuilder(
          builder: (context, constraints) {
            final size = Size(constraints.maxWidth, constraints.maxHeight);
            if (size != _lastSize) {
              final orientationMatches = _matchesRequestedOrientation(size);
              final previousMatched = _matchesRequestedOrientation(_lastSize);
              _stableOrientationFrames = orientationMatches && previousMatched ? _stableOrientationFrames + 1 : (orientationMatches ? 1 : 0);
              _lastSize = size;
              if (size.height >= size.width && _portraitLayoutWaiter != null && !_portraitLayoutWaiter!.isCompleted) {
                _portraitLayoutWaiter!.complete();
              }
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                if (_matchesRequestedOrientation(size)) {
                  engine.resize(size.width, size.height);
                }
                _tryRestart();
                _tryStart();
                if (_matchesRequestedOrientation(size) && _stableOrientationFrames < 2) {
                  setState(() {});
                }
              });
            } else if (_matchesRequestedOrientation(size) && _stableOrientationFrames < 2) {
              _stableOrientationFrames++;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                _tryRestart();
                _tryStart();
              });
            }
            return AnimatedBuilder(
              animation: engine,
              builder: (context, _) => Stack(
                children: [
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTapDown: (details) => _handle(details.localPosition),
                      onPanDown: (details) => _handle(details.localPosition),
                      onPanUpdate: (details) => _handle(details.localPosition),
                      child: CustomPaint(painter: _GamePainter(engine, theme)),
                    ),
                  ),
                  Positioned(
                    top: MediaQuery.paddingOf(context).top + 18,
                    left: 12,
                    right: 12,
                    child: _hud(theme),
                  ),
                  if (engine.phase == 'countdown')
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                engine.countdown > 0 ? '${engine.countdown}' : 'شروع',
                                style: TextStyle(
                                  color: theme.primary,
                                  fontSize: 72,
                                  fontWeight: FontWeight.w900,
                                  shadows: [Shadow(color: theme.primary, blurRadius: 30)],
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                engine.twoPlayer
                                    ? (engine.isLandscape
                                        ? 'بازیکن ۱: سمت راست • بازیکن ۲: سمت چپ'
                                        : 'بازیکن ۱: پایین • بازیکن ۲: بالا')
                                    : (engine.isLandscape ? 'حرکت راکت با لمس نیمه راست' : 'حرکت راکت با لمس پایین صفحه'),
                                textAlign: TextAlign.center,
                                style: TextStyle(color: theme.dim),
                              ),
                              if (engine.mode == 'tournament' && engine.tournament != null)
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Text('${engine.tournament!.name} • دور ${engine.tournamentRound}', style: TextStyle(color: theme.dim)),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (engine.paused && !_confirmingExit) _pauseOverlay(theme),
                  if (engine.lastPowerup != null && engine.phase == 'playing')
                    Positioned(
                      top: MediaQuery.paddingOf(context).top + 96,
                      left: 0,
                      right: 0,
                      child: IgnorePointer(
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: theme.panel.withOpacity(.9),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: theme.primary.withOpacity(.32)),
                              boxShadow: [BoxShadow(color: theme.primary.withOpacity(.12), blurRadius: 18)],
                            ),
                            child: Text(engine.lastPowerup!, style: TextStyle(color: theme.text, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _hud(GameTheme theme) {
    final topLabel = engine.twoPlayer ? 'بازیکن ۲' : 'حریف';
    final bottomLabel = engine.twoPlayer ? 'بازیکن ۱' : 'شما';

    return Row(
      children: [
        _floatingScore(
          topLabel,
          engine.topScore,
          theme,
          theme.top,
          avatarIndex: (_state.avatar + (engine.twoPlayer ? 1 : 2)) % avatars.length,
        ),
        const Spacer(),
        _floatingScore(
          bottomLabel,
          engine.bottomScore,
          theme,
          theme.bottom,
          avatarIndex: _state.avatar,
          reverse: true,
        ),
      ],
    );
  }

  Widget _floatingScore(
    String label,
    int value,
    GameTheme theme,
    Color accent, {
    required int avatarIndex,
    bool reverse = false,
  }) {
    final avatar = Opacity(
      opacity: .42,
      child: AvatarBadge(index: avatarIndex, size: 23),
    );
    final text = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: reverse ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          '$value',
          style: TextStyle(
            color: theme.text.withOpacity(.94),
            fontSize: 28,
            height: .95,
            fontWeight: FontWeight.w900,
            shadows: [
              Shadow(color: Colors.black.withOpacity(.70), blurRadius: 8, offset: const Offset(0, 2)),
              Shadow(color: accent.withOpacity(.25), blurRadius: 13),
            ],
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: theme.dim.withOpacity(.82),
            fontSize: 9,
            fontWeight: FontWeight.w800,
            shadows: [Shadow(color: Colors.black.withOpacity(.70), blurRadius: 5)],
          ),
        ),
      ],
    );
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: reverse ? [text, const SizedBox(width: 6), avatar] : [avatar, const SizedBox(width: 6), text],
    );
  }

  Widget _pauseOverlay(GameTheme theme) => Positioned.fill(
        child: Container(
          color: Colors.black.withOpacity(.48),
          alignment: Alignment.center,
          padding: const EdgeInsets.all(18),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 310),
            child: NeonPanel(
              borderColor: theme.primary,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 15),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AppIcons.icon('pause', size: 22, color: theme.primary),
                      const SizedBox(width: 9),
                      Text('توقف', style: TextStyle(color: theme.text, fontSize: 24, fontWeight: FontWeight.w900)),
                    ],
                  ),
                  const SizedBox(height: 13),
                  NeonButton(label: 'ادامه', icon: 'resume', small: true, color: theme.accent, expand: true, onTap: () => engine.setPaused(false)),
                  const SizedBox(height: 9),
                  NeonButton(
                    label: 'شروع مجدد',
                    icon: 'restart',
                    small: true,
                    color: theme.secondary,
                    expand: true,
                    onTap: () {
                      _resultHandled = false;
                      _lastTick = null;
                      engine.restart();
                    },
                  ),
                  const SizedBox(height: 9),
                  NeonButton(
                    label: 'خروج از مسابقه',
                    icon: 'exit',
                    small: true,
                    color: theme.danger,
                    expand: true,
                    onTap: () => _confirmMatchExit(resumeOnCancel: false),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

  Future<void> _confirmMatchExit({required bool resumeOnCancel}) async {
    if (_confirmingExit || !mounted) return;
    setState(() => _confirmingExit = true);
    engine.setPaused(true);
    final exit = await showNeonConfirm(
      context,
      title: 'خروج از مسابقه',
      message: 'مسابقه فعلی بدون ثبت نتیجه بسته می‌شود.',
      confirmLabel: 'خروج',
      danger: true,
    );
    if (!mounted) return;
    setState(() => _confirmingExit = false);
    if (exit) {
      await _exitGame();
    } else if (resumeOnCancel) {
      engine.setPaused(false);
    }
  }

  void _handle(Offset position) {
    if (engine.paused || !engine.started || engine.finished) return;
    String owner;
    if (engine.twoPlayer) {
      owner = engine.isLandscape
          ? (position.dx < engine.width / 2 ? 'top' : 'bottom')
          : (position.dy < engine.height / 2 ? 'top' : 'bottom');
    } else {
      final inPlayerZone = engine.isLandscape
          ? position.dx >= engine.width * .40
          : position.dy >= engine.height * .40;
      if (!inPlayerZone) return;
      owner = 'bottom';
    }
    engine.setTarget(owner, engine.isLandscape ? position.dy : position.dx);
  }


}

class _GamePainter extends CustomPainter {
  final Engine engine;
  final GameTheme theme;

  _GamePainter(this.engine, this.theme) : super(repaint: engine);

  @override
  void paint(Canvas canvas, Size size) {
    final width = engine.width > 0 ? engine.width : size.width;
    final height = engine.height > 0 ? engine.height : size.height;
    final rect = Rect.fromLTWH(0, 0, width, height);

    final bg = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          theme.canvasBg,
          Color.lerp(theme.canvasBg, Colors.black, theme.brightness == Brightness.dark ? .20 : .04)!,
          Color.lerp(theme.canvasBg, theme.primary, theme.brightness == Brightness.dark ? .025 : .015)!,
        ],
      ).createShader(rect);
    canvas.drawRect(rect, bg);

    final vignette = Paint()
      ..shader = RadialGradient(
        center: Alignment.center,
        radius: .98,
        colors: [
          Colors.transparent,
          Colors.black.withOpacity(theme.brightness == Brightness.dark ? .12 : .02),
          Colors.black.withOpacity(theme.brightness == Brightness.dark ? .38 : .08),
        ],
        stops: const [0.0, .76, 1.0],
      ).createShader(rect);
    canvas.drawRect(rect, vignette);

    _drawArenaLights(canvas, width, height);
    _drawThemeAtmosphere(canvas, width, height);
    _drawArenaSurface(canvas, width, height);
    _drawCenterline(canvas, width, height);
    _drawGoalZones(canvas, width, height);
    _drawScorePulse(canvas, width, height);
    _drawWalls(canvas, width, height);
    _drawTrail(canvas);
    _drawPowerups(canvas);

    final glow = switch (engine.state.quality) {
      'low' => 0.0,
      'high' => 18.0,
      _ => 10.0,
    };

    _drawBall(canvas, glow);
    _drawPaddle(canvas, engine.top, theme.top, engine.effects['top']!['shield']! > 0, glow, side: 'top');
    _drawPaddle(canvas, engine.bottom, theme.bottom, engine.effects['bottom']!['shield']! > 0, glow, side: 'bottom');

    if (engine.state.debug) {
      final textPainter = TextPainter(
        textDirection: TextDirection.ltr,
        text: TextSpan(
          text: 'phase ${engine.phase}\n${engine.hypot.round()} px/s\n${engine.powerups.length} powerups',
          style: TextStyle(color: theme.text.withOpacity(.72), fontSize: 10),
        ),
      )..layout();
      textPainter.paint(canvas, const Offset(10, 92));
    }
  }

  void _drawThemeAtmosphere(Canvas canvas, double width, double height) {
    final id = theme.id;
    if (id == 'girly') {
      final paint = Paint()..color = theme.primary.withOpacity(.055);
      for (final p in [
        Offset(width * .15, height * .18),
        Offset(width * .84, height * .31),
        Offset(width * .22, height * .78),
        Offset(width * .78, height * .84),
      ]) {
        canvas.drawCircle(p, 18, paint);
        canvas.drawCircle(p + const Offset(13, 4), 10, Paint()..color = theme.secondary.withOpacity(.045));
      }
    } else if (id == 'boyish') {
      final paint = Paint()..color = theme.accent.withOpacity(.07)..strokeWidth = 1.4;
      for (var i = 0; i < 4; i++) {
        final d = 28.0 + i * 16;
        canvas.drawLine(Offset(12, d), Offset(44, d - 18), paint);
        canvas.drawLine(Offset(width - 12, height - d), Offset(width - 44, height - d + 18), paint);
      }
    } else if (id == 'child') {
      final dots = [theme.primary, theme.secondary, theme.accent, theme.gold];
      for (var i = 0; i < dots.length; i++) {
        final x = width * (.14 + i * .23);
        canvas.drawCircle(Offset(x, height * .13), 3.5, Paint()..color = dots[i].withOpacity(.13));
        canvas.drawCircle(Offset(width - x, height * .87), 3.5, Paint()..color = dots[i].withOpacity(.10));
      }
    } else if (id == 'light') {
      final p = Paint()..color = theme.primary.withOpacity(.055)..style = PaintingStyle.stroke..strokeWidth = 1;
      canvas.drawArc(Rect.fromCircle(center: Offset(width * .12, height * .16), radius: 54), -.4, 1.7, false, p);
      canvas.drawArc(Rect.fromCircle(center: Offset(width * .88, height * .84), radius: 54), 2.7, 1.7, false, p);
    } else {
      final left = Rect.fromLTWH(0, height * .22, 42, height * .56);
      final right = Rect.fromLTWH(width - 42, height * .22, 42, height * .56);
      canvas.drawRect(left, Paint()..shader = LinearGradient(begin: Alignment.centerLeft, end: Alignment.centerRight, colors: [theme.primary.withOpacity(.045), Colors.transparent]).createShader(left));
      canvas.drawRect(right, Paint()..shader = LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [theme.secondary.withOpacity(.04), Colors.transparent]).createShader(right));
    }
  }

  void _drawArenaLights(Canvas canvas, double width, double height) {
    final id = engine.state.arena.id;
    final topIntensity = id == 'a_void' ? .10 : id == 'a_speed' ? .30 : .20;
    final bottomIntensity = id == 'a_fortune' ? .26 : id == 'a_control' ? .12 : .16;

    final topRect = Rect.fromLTWH(width * .22, 0, width * .56, height * .16);
    canvas.drawRect(
      topRect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [theme.secondary.withOpacity(topIntensity), Colors.transparent],
        ).createShader(topRect),
    );

    final bottomRect = Rect.fromLTWH(width * .16, height * .80, width * .68, height * .20);
    canvas.drawRect(
      bottomRect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [theme.accent.withOpacity(bottomIntensity), Colors.transparent],
        ).createShader(bottomRect),
    );
  }

  void _drawArenaSurface(Canvas canvas, double width, double height) {
    final frameRect = Rect.fromLTWH(11, 11, width - 22, height - 22);
    final frame = RRect.fromRectAndRadius(frameRect, const Radius.circular(26));
    canvas.drawRRect(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.15
        ..color = theme.grid.withOpacity(.48),
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(frameRect.deflate(18), const Radius.circular(22)),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = theme.grid.withOpacity(.20),
    );

    final id = engine.state.arena.id;
    if (id == 'a_speed') {
      _drawSpeedArena(canvas, width, height);
    } else if (id == 'a_control') {
      _drawControlArena(canvas, width, height);
    } else if (id == 'a_void') {
      _drawVoidArena(canvas, width, height);
    } else if (id == 'a_narrow') {
      _drawNarrowArena(canvas, width, height);
    } else if (id == 'a_fortune') {
      _drawFortuneArena(canvas, width, height);
    } else if (id == 'a_time') {
      _drawTimeArena(canvas, width, height);
    } else if (id == 'a_mirror') {
      _drawMirrorArena(canvas, width, height);
    } else {
      _drawDefaultArena(canvas, width, height);
    }
  }

  void _drawDefaultArena(Canvas canvas, double width, double height) {
    final line = Paint()..color = theme.grid.withOpacity(.20)..strokeWidth = 1;
    if (engine.isLandscape) {
      canvas.drawLine(Offset(22, height * .24), Offset(width - 22, height * .24), line);
      canvas.drawLine(Offset(22, height * .76), Offset(width - 22, height * .76), line);
    } else {
      canvas.drawLine(Offset(width * .24, 22), Offset(width * .24, height - 22), line);
      canvas.drawLine(Offset(width * .76, 22), Offset(width * .76, height - 22), line);
    }
  }

  void _drawSpeedArena(Canvas canvas, double width, double height) {
    final paint = Paint()..color = theme.primary.withOpacity(.20)..strokeWidth = 2.2..strokeCap = StrokeCap.round;
    if (engine.isLandscape) {
      for (var y = 46.0; y < height - 30; y += 34) {
        canvas.drawLine(Offset(width * .18, y), Offset(width * .23, y), paint);
        canvas.drawLine(Offset(width * .77, y), Offset(width * .82, y), paint);
      }
    } else {
      for (var x = 46.0; x < width - 30; x += 34) {
        canvas.drawLine(Offset(x, height * .18), Offset(x, height * .23), paint);
        canvas.drawLine(Offset(x, height * .77), Offset(x, height * .82), paint);
      }
    }
  }

  void _drawControlArena(Canvas canvas, double width, double height) {
    final paint = Paint()..color = theme.accent.withOpacity(.16)..style = PaintingStyle.stroke..strokeWidth = 1.2;
    final center = Offset(width / 2, height / 2);
    for (final r in [42.0, 82.0, 122.0]) {
      canvas.drawCircle(center, r, paint);
    }
  }

  void _drawVoidArena(Canvas canvas, double width, double height) {
    final center = Offset(width / 2, height / 2);
    canvas.drawCircle(center, min(width, height) * .17, Paint()..color = Colors.black.withOpacity(.30));
    canvas.drawCircle(center, min(width, height) * .19, Paint()..color = theme.secondary.withOpacity(.18)..style = PaintingStyle.stroke..strokeWidth = 1.2);
  }

  void _drawNarrowArena(Canvas canvas, double width, double height) {
    final paint = Paint()..color = theme.danger.withOpacity(.17)..strokeWidth = 1.2;
    if (engine.isLandscape) {
      canvas.drawLine(Offset(18, engine.sideInset), Offset(width - 18, engine.sideInset), paint);
      canvas.drawLine(Offset(18, height - engine.sideInset), Offset(width - 18, height - engine.sideInset), paint);
    } else {
      canvas.drawLine(Offset(engine.sideInset, 18), Offset(engine.sideInset, height - 18), paint);
      canvas.drawLine(Offset(width - engine.sideInset, 18), Offset(width - engine.sideInset, height - 18), paint);
    }
  }

  void _drawFortuneArena(Canvas canvas, double width, double height) {
    final gold = Paint()..color = theme.gold.withOpacity(.24);
    const radius = 4.0;
    for (final point in [
      Offset(width * .18, height * .28),
      Offset(width * .82, height * .28),
      Offset(width * .18, height * .72),
      Offset(width * .82, height * .72),
    ]) {
      canvas.drawCircle(point, radius, gold);
      canvas.drawCircle(point, radius + 5, Paint()..color = theme.gold.withOpacity(.08));
    }
  }

  void _drawTimeArena(Canvas canvas, double width, double height) {
    final center = Offset(width / 2, height / 2);
    final radius = min(width, height) * .13;
    final p = Paint()..color = theme.secondary.withOpacity(.17)..style = PaintingStyle.stroke..strokeWidth = 1.2;
    canvas.drawCircle(center, radius, p);
    for (var i = 0; i < 12; i++) {
      final a = pi * 2 * i / 12;
      final p1 = Offset(center.dx + cos(a) * (radius - 6), center.dy + sin(a) * (radius - 6));
      final p2 = Offset(center.dx + cos(a) * radius, center.dy + sin(a) * radius);
      canvas.drawLine(p1, p2, p);
    }
  }

  void _drawMirrorArena(Canvas canvas, double width, double height) {
    final p = Paint()..color = Colors.white.withOpacity(.06)..strokeWidth = 1;
    if (engine.isLandscape) {
      canvas.drawLine(Offset(width * .25, 20), Offset(width * .25, height - 20), p);
      canvas.drawLine(Offset(width * .75, 20), Offset(width * .75, height - 20), p);
    } else {
      canvas.drawLine(Offset(20, height * .25), Offset(width - 20, height * .25), p);
      canvas.drawLine(Offset(20, height * .75), Offset(width - 20, height * .75), p);
    }
  }

  void _drawCenterline(Canvas canvas, double width, double height) {
    final linePaint = Paint()..color = theme.center.withOpacity(.34)..strokeWidth = 1.6;
    if (engine.isLandscape) {
      canvas.drawLine(Offset(width / 2, 18), Offset(width / 2, height - 18), linePaint);
    } else {
      canvas.drawLine(Offset(18, height / 2), Offset(width - 18, height / 2), linePaint);
    }
    canvas.drawCircle(Offset(width / 2, height / 2), 20, Paint()..color = theme.center.withOpacity(.035));
    canvas.drawCircle(Offset(width / 2, height / 2), 20, Paint()..color = theme.center.withOpacity(.22)..style = PaintingStyle.stroke..strokeWidth = 1.1);
  }

  void _drawGoalZones(Canvas canvas, double width, double height) {
    if (engine.isLandscape) {
      final leftRect = Rect.fromLTWH(0, height * .18, 88, height * .64);
      final rightRect = Rect.fromLTWH(width - 88, height * .18, 88, height * .64);
      canvas.drawRect(leftRect, Paint()..shader = LinearGradient(begin: Alignment.centerLeft, end: Alignment.centerRight, colors: [theme.top.withOpacity(.12), Colors.transparent]).createShader(leftRect));
      canvas.drawRect(rightRect, Paint()..shader = LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [theme.bottom.withOpacity(.12), Colors.transparent]).createShader(rightRect));
    } else {
      final topRect = Rect.fromLTWH(width * .18, 0, width * .64, 88);
      final bottomRect = Rect.fromLTWH(width * .18, height - 88, width * .64, 88);
      canvas.drawRect(topRect, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [theme.top.withOpacity(.10), Colors.transparent]).createShader(topRect));
      canvas.drawRect(bottomRect, Paint()..shader = LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [theme.bottom.withOpacity(.10), Colors.transparent]).createShader(bottomRect));
    }
  }

  void _drawScorePulse(Canvas canvas, double width, double height) {
    if (engine.phase != 'point' || engine.lastScorer == null) return;
    final scorerColor = engine.lastScorer == 'bottom' ? theme.bottom : theme.top;
    final progress = (engine.phaseTimer / .65).clamp(0.0, 1.0).toDouble();
    final alpha = sin(progress * pi).abs() * .22;
    if (alpha <= .001) return;
    if (engine.isLandscape) {
      final rect = engine.lastScorer == 'bottom'
          ? Rect.fromLTWH(0, 0, width * .22, height)
          : Rect.fromLTWH(width * .78, 0, width * .22, height);
      canvas.drawRect(
        rect,
        Paint()..shader = LinearGradient(
          begin: engine.lastScorer == 'bottom' ? Alignment.centerLeft : Alignment.centerRight,
          end: engine.lastScorer == 'bottom' ? Alignment.centerRight : Alignment.centerLeft,
          colors: [scorerColor.withOpacity(alpha), Colors.transparent],
        ).createShader(rect),
      );
    } else {
      final rect = engine.lastScorer == 'bottom'
          ? Rect.fromLTWH(0, 0, width, height * .18)
          : Rect.fromLTWH(0, height * .82, width, height * .18);
      canvas.drawRect(
        rect,
        Paint()..shader = LinearGradient(
          begin: engine.lastScorer == 'bottom' ? Alignment.topCenter : Alignment.bottomCenter,
          end: engine.lastScorer == 'bottom' ? Alignment.bottomCenter : Alignment.topCenter,
          colors: [scorerColor.withOpacity(alpha), Colors.transparent],
        ).createShader(rect),
      );
    }
  }

  void _drawWalls(Canvas canvas, double width, double height) {
    if (engine.sideInset <= 0) return;
    final wall = Paint()..color = Colors.white.withOpacity(.045);
    if (engine.isLandscape) {
      canvas.drawRect(Rect.fromLTWH(0, 0, width, engine.sideInset), wall);
      canvas.drawRect(Rect.fromLTWH(0, height - engine.sideInset, width, engine.sideInset), wall);
    } else {
      canvas.drawRect(Rect.fromLTWH(0, 0, engine.sideInset, height), wall);
      canvas.drawRect(Rect.fromLTWH(width - engine.sideInset, 0, engine.sideInset, height), wall);
    }
  }

  void _drawTrail(Canvas canvas) {
    if (!engine.state.trail || engine.trail.length < 2) return;
    final color = engine.state.ball.trailColor ?? theme.trail;
    for (var i = 1; i < engine.trail.length; i++) {
      final a = engine.trail[i - 1];
      final b = engine.trail[i];
      final ratio = i / engine.trail.length;
      canvas.drawLine(
        Offset(a.x, a.y),
        Offset(b.x, b.y),
        Paint()
          ..color = color.withOpacity(.05 + ratio * .22)
          ..strokeWidth = max(1.0, engine.ball.radius * ratio * .72)
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  void _drawPowerups(Canvas canvas) {
    for (final powerup in engine.powerups) {
      final color = _powerColor(powerup.type);
      final center = Offset(powerup.x, powerup.y);
      final path = Path();
      for (var i = 0; i < 6; i++) {
        final angle = -pi / 2 + i * pi / 3;
        final point = Offset(center.dx + cos(angle) * (powerup.radius + 2), center.dy + sin(angle) * (powerup.radius + 2));
        if (i == 0) {
          path.moveTo(point.dx, point.dy);
        } else {
          path.lineTo(point.dx, point.dy);
        }
      }
      path.close();
      canvas.drawCircle(center, powerup.radius + 10, Paint()..color = color.withOpacity(.08));
      canvas.drawPath(path, Paint()..color = color.withOpacity(.14));
      canvas.drawPath(path, Paint()..color = color.withOpacity(.72)..style = PaintingStyle.stroke..strokeWidth = 1.6);
      _drawPowerGlyph(canvas, powerup, color);
    }
  }

  void _drawBall(Canvas canvas, double glow) {
    final item = engine.state.ball;
    final center = Offset(engine.ball.x, engine.ball.y);
    final radius = engine.ball.radius;
    final color = item.color ?? theme.ball;

    if (item.id == 'b_ghost') {
      canvas.drawCircle(center + const Offset(7, 0), radius * .95, Paint()..color = color.withOpacity(.12));
      canvas.drawCircle(center + const Offset(13, 0), radius * .80, Paint()..color = color.withOpacity(.06));
    }
    if (item.id == 'b_plasma') {
      canvas.drawCircle(center, radius + 10, Paint()..color = color.withOpacity(.16));
      canvas.drawCircle(center, radius + 6, Paint()..color = color.withOpacity(.45)..style = PaintingStyle.stroke..strokeWidth = 1.2);
    } else if (item.id == 'b_gold') {
      canvas.drawCircle(center, radius + 5, Paint()..color = theme.gold.withOpacity(.62)..style = PaintingStyle.stroke..strokeWidth = 1.8);
    } else if (item.id == 'b_moon') {
      canvas.drawCircle(center, radius + 7, Paint()..color = color.withOpacity(.10));
    } else {
      canvas.drawCircle(center, radius + 8, Paint()..color = color.withOpacity(.08));
    }

    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = item.id == 'b_ghost' ? color.withOpacity(.78) : color
        ..maskFilter = glow > 0 ? MaskFilter.blur(BlurStyle.normal, glow * .55) : null,
    );

    if (item.id == 'b_moon') {
      canvas.drawCircle(center + Offset(radius * .38, -radius * .12), radius * .72, Paint()..color = theme.canvasBg.withOpacity(.74));
    } else if (item.id == 'b_rubber') {
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius * .68), -.8, 1.6, false, Paint()..color = Colors.white.withOpacity(.34)..style = PaintingStyle.stroke..strokeWidth = 1.3);
    }
  }

  void _drawPaddle(Canvas canvas, PaddleState paddle, Color color, bool shield, double glow, {required String side}) {
    final racket = engine.state.racket;
    final rect = Rect.fromCenter(center: Offset(paddle.x, paddle.y), width: paddle.width, height: paddle.height);
    final radius = racket.id == 'r_phantom' ? 18.0 : 14.0;
    final outer = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    final alpha = racket.id == 'r_phantom' ? .72 : .96;

    canvas.drawRRect(outer.inflate(5), Paint()..color = color.withOpacity(racket.id == 'r_phantom' ? .05 : .08));
    canvas.drawRRect(
      outer,
      Paint()
        ..color = color.withOpacity(.13)
        ..maskFilter = glow > 0 ? MaskFilter.blur(BlurStyle.normal, glow) : null,
    );
    canvas.drawRRect(
      outer,
      Paint()
        ..shader = LinearGradient(
          begin: engine.isLandscape ? Alignment.topCenter : Alignment.centerLeft,
          end: engine.isLandscape ? Alignment.bottomCenter : Alignment.centerRight,
          colors: [
            Colors.white.withOpacity(.20 * alpha),
            color.withOpacity(alpha),
            color.withOpacity(.66 * alpha),
          ],
        ).createShader(rect),
    );

    final coreRect = engine.isLandscape
        ? Rect.fromCenter(center: rect.center, width: max(4, paddle.width - 7).toDouble(), height: paddle.height * .58)
        : Rect.fromCenter(center: rect.center, width: paddle.width * .58, height: max(4, paddle.height - 7).toDouble());
    canvas.drawRRect(RRect.fromRectAndRadius(coreRect, const Radius.circular(10)), Paint()..color = Colors.white.withOpacity(racket.id == 'r_phantom' ? .09 : .16));

    if (racket.id == 'r_spin') {
      canvas.drawCircle(rect.center, engine.isLandscape ? paddle.width * .42 : paddle.height * .42, Paint()..color = Colors.white.withOpacity(.32)..style = PaintingStyle.stroke..strokeWidth = 1.4);
    } else if (racket.id == 'r_turbo') {
      final stripe = Paint()..color = Colors.white.withOpacity(.24)..strokeWidth = 1.8;
      if (engine.isLandscape) {
        for (var y = rect.top + 12; y < rect.bottom - 8; y += 22) {
          canvas.drawLine(Offset(rect.left + 3, y), Offset(rect.right - 3, y + 7), stripe);
        }
      } else {
        for (var x = rect.left + 12; x < rect.right - 8; x += 22) {
          canvas.drawLine(Offset(x, rect.top + 3), Offset(x + 7, rect.bottom - 3), stripe);
        }
      }
    } else if (racket.id == 'r_guardian') {
      canvas.drawRRect(RRect.fromRectAndRadius(rect.inflate(6), const Radius.circular(18)), Paint()..color = color.withOpacity(.68)..style = PaintingStyle.stroke..strokeWidth = 1.7);
    } else if (racket.id == 'r_magnet') {
      canvas.drawCircle(rect.center, 9, Paint()..color = theme.primary.withOpacity(.34)..style = PaintingStyle.stroke..strokeWidth = 1.4);
      canvas.drawCircle(rect.center, 14, Paint()..color = theme.primary.withOpacity(.14)..style = PaintingStyle.stroke..strokeWidth = 1);
    } else if (racket.id == 'r_echo') {
      final offset = engine.isLandscape ? const Offset(5, 0) : const Offset(0, 5);
      canvas.drawRRect(RRect.fromRectAndRadius(rect.shift(offset), const Radius.circular(14)), Paint()..color = color.withOpacity(.10)..style = PaintingStyle.stroke..strokeWidth = 1.2);
    }

    if (shield) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect.inflate(9), const Radius.circular(19)),
        Paint()..color = theme.secondary.withOpacity(.82)..style = PaintingStyle.stroke..strokeWidth = 2,
      );
    }
  }

  void _drawPowerGlyph(Canvas canvas, Powerup powerup, Color color) {
    final painter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      text: TextSpan(
        text: switch (powerup.type) {
          'big' => '+',
          'shrink' => '−',
          'slow' => '◷',
          'fast' => '⚡',
          'shield' => '◇',
          _ => '¢',
        },
        style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900),
      ),
    )..layout();
    painter.paint(canvas, Offset(powerup.x - painter.width / 2, powerup.y - painter.height / 2));
  }

  Color _powerColor(String type) => switch (type) {
        'big' => const Color(0xFF00E9BB),
        'shrink' => const Color(0xFFFF4C95),
        'slow' => const Color(0xFF35CFF2),
        'fast' => const Color(0xFFFFB75A),
        'shield' => const Color(0xFF8A74FF),
        _ => const Color(0xFFFFD66A),
      };

  @override
  bool shouldRepaint(covariant _GamePainter oldDelegate) => oldDelegate.theme != theme || oldDelegate.engine != engine;
}
