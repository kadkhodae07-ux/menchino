import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/icons.dart';
import '../../core/state/app_state.dart';

class _DepthDecor extends StatelessWidget {
  final Widget child;
  final BorderRadius borderRadius;
  final Color baseColor;
  final Color accentColor;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final double glow;
  final double borderOpacity;

  const _DepthDecor({
    required this.child,
    required this.borderRadius,
    required this.baseColor,
    required this.accentColor,
    required this.padding,
    this.pressed = false,
    this.glow = 18,
    this.borderOpacity = .36,
  });

  @override
  Widget build(BuildContext context) {
    final isLight = Theme.of(context).brightness == Brightness.light;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(
          top: pressed ? 5 : 0,
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: borderRadius,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(isLight ? .07 : .36),
                    Colors.black.withOpacity(isLight ? .14 : .58),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(isLight ? .16 : .55),
                    blurRadius: pressed ? 12 : 22,
                    offset: Offset(0, pressed ? 5 : (isLight ? 9 : 16)),
                  ),
                  BoxShadow(color: accentColor.withOpacity(.10), blurRadius: glow),
                ],
              ),
            ),
          ),
        ),
        AnimatedContainer(
          duration: const Duration(milliseconds: 110),
          margin: EdgeInsets.only(bottom: pressed ? 1 : 5),
          decoration: BoxDecoration(
            borderRadius: borderRadius,
            border: Border.all(color: accentColor.withOpacity(borderOpacity)),
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [accentColor.withOpacity(.18), baseColor.withOpacity(.98)],
            ),
            boxShadow: [
              BoxShadow(color: accentColor.withOpacity(.18), blurRadius: glow),
              BoxShadow(color: Colors.white.withOpacity(isLight ? .20 : .035), blurRadius: 8, offset: const Offset(0, -2)),
            ],
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  margin: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular((borderRadius.topLeft.x - 5).clamp(8, 22).toDouble()),
                    border: Border.all(color: accentColor.withOpacity(.16)),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withOpacity(.045),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(12, 12, 12, 18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular((borderRadius.topLeft.x - 11).clamp(6, 18).toDouble()),
                    border: Border.all(color: Colors.white.withOpacity(.055)),
                  ),
                ),
              ),
              Padding(padding: padding, child: child),
            ],
          ),
        ),
      ],
    );
  }
}

class NeonButton extends StatefulWidget {
  final String label;
  final String? icon;
  final VoidCallback? onTap;
  final Color? color;
  final bool small;
  final bool expand;

  const NeonButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.color,
    this.small = false,
    this.expand = false,
  });

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = widget.color ?? theme.primary;
    final enabled = widget.onTap != null;
    final radius = BorderRadius.circular(widget.small ? 14 : 18);

    final content = AnimatedOpacity(
      duration: const Duration(milliseconds: 120),
      opacity: enabled ? 1 : .42,
      child: AnimatedScale(
        scale: _pressed && enabled ? .982 : 1,
        duration: const Duration(milliseconds: 90),
        child: _DepthDecor(
          borderRadius: radius,
          baseColor: theme.panel,
          accentColor: color,
          padding: EdgeInsets.symmetric(horizontal: widget.small ? 14 : 18, vertical: widget.small ? 11 : 13),
          pressed: _pressed && enabled,
          glow: widget.small ? 14 : 22,
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: widget.small ? 42 : 54),
            child: Row(
              mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.icon != null) ...[
                  AppIcons.icon(widget.icon!, size: widget.small ? 17 : 19, color: theme.text),
                  const SizedBox(width: 8),
                ],
                Flexible(
                  child: Text(
                    widget.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: theme.text,
                      fontWeight: FontWeight.w900,
                      fontSize: widget.small ? 14 : 17,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    return Semantics(
      button: true,
      enabled: enabled,
      label: widget.label,
      child: MouseRegion(
        cursor: enabled ? SystemMouseCursors.click : SystemMouseCursors.forbidden,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
          onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
          onTapUp: enabled
              ? (_) {
                  setState(() => _pressed = false);
                  widget.onTap?.call();
                }
              : null,
          child: widget.expand ? SizedBox(width: double.infinity, child: content) : content,
        ),
      ),
    );
  }
}

class NeonPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;

  const NeonPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = borderColor ?? theme.primary;
    return _DepthDecor(
      borderRadius: BorderRadius.circular(22),
      baseColor: theme.panel,
      accentColor: color,
      padding: padding,
      glow: 24,
      child: child,
    );
  }
}

class Chip3D extends StatelessWidget {
  final String text;
  final bool gem;

  const Chip3D({super.key, required this.text, this.gem = false});

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final color = gem ? theme.secondary : theme.accent;
    return _DepthDecor(
      borderRadius: BorderRadius.circular(14),
      baseColor: theme.panel,
      accentColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      glow: 14,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AppIcons.icon(gem ? 'gem' : 'coin', size: 16, color: color),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(color: theme.text, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class StatBadge extends StatelessWidget {
  final String text;
  final Color? color;

  const StatBadge(this.text, {super.key, this.color});

  @override
  Widget build(BuildContext context) {
    final theme = context.select<AppState, dynamic>((state) => state.theme);
    final accent = color ?? theme.primary;
    return _DepthDecor(
      borderRadius: BorderRadius.circular(12),
      baseColor: theme.panel,
      accentColor: accent,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      glow: 10,
      borderOpacity: .22,
      child: Text(text, style: TextStyle(color: theme.dim, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

void showNeonMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message), duration: const Duration(milliseconds: 1900)));
}

Future<bool> showNeonConfirm(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'تأیید',
  String cancelLabel = 'انصراف',
  bool danger = false,
}) async {
  final state = context.read<AppState>();
  final theme = state.theme;
  final result = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 360),
        child: NeonPanel(
          borderColor: danger ? theme.danger : theme.primary,
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: danger ? theme.danger : theme.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 23,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: theme.dim, height: 1.75, fontSize: 14),
                ),
                const SizedBox(height: 18),
                LayoutBuilder(
                  builder: (context, constraints) {
                    final compact = constraints.maxWidth < 310;
                    final cancel = NeonButton(
                      label: cancelLabel,
                      small: true,
                      expand: true,
                      onTap: () => Navigator.pop(dialogContext, false),
                    );
                    final confirm = NeonButton(
                      label: confirmLabel,
                      icon: danger ? 'exit' : 'check',
                      small: true,
                      expand: true,
                      color: danger ? theme.danger : theme.primary,
                      onTap: () => Navigator.pop(dialogContext, true),
                    );
                    if (compact) {
                      return Column(
                        children: [
                          cancel,
                          const SizedBox(height: 10),
                          confirm,
                        ],
                      );
                    }
                    return Row(
                      children: [
                        Expanded(child: cancel),
                        const SizedBox(width: 10),
                        Expanded(child: confirm),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
  return result ?? false;
}


class GameBackButton extends StatefulWidget {
  final VoidCallback? onTap;
  final String tooltip;

  const GameBackButton({super.key, this.onTap, this.tooltip = 'برگشت'});

  @override
  State<GameBackButton> createState() => _GameBackButtonState();
}

class _GameBackButtonState extends State<GameBackButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    final rtl = Directionality.of(context) == TextDirection.rtl;
    return Semantics(
      button: true,
      label: widget.tooltip,
      child: Tooltip(
        message: widget.tooltip,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => setState(() => _pressed = true),
          onTapCancel: () => setState(() => _pressed = false),
          onTapUp: (_) {
            setState(() => _pressed = false);
            if (widget.onTap != null) {
              widget.onTap!();
            } else {
              Navigator.maybePop(context);
            }
          },
          child: AnimatedScale(
            scale: _pressed ? .96 : 1,
            duration: const Duration(milliseconds: 90),
            child: SizedBox(
              width: 48,
              height: 48,
              child: _DepthDecor(
                borderRadius: BorderRadius.circular(16),
                baseColor: theme.panel,
                accentColor: theme.primary,
                padding: const EdgeInsets.all(12),
                pressed: _pressed,
                glow: 16,
                borderOpacity: .30,
                child: Transform.rotate(
                  angle: rtl ? math.pi : 0,
                  child: AppIcons.icon('back', size: 20, color: theme.text),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GamePageHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback? onBack;
  final List<Widget> actions;
  final bool showBack;

  const GamePageHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.onBack,
    this.actions = const [],
    this.showBack = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppState>().theme;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        if (showBack) ...[
          GameBackButton(onTap: onBack),
          const SizedBox(width: 11),
        ],
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: theme.text, fontWeight: FontWeight.w900, fontSize: 22),
              ),
              if (subtitle != null && subtitle!.isNotEmpty) ...[
                const SizedBox(height: 3),
                Text(
                  subtitle!,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: theme.dim, fontSize: 11.5, height: 1.45),
                ),
              ],
            ],
          ),
        ),
        if (actions.isNotEmpty) ...[
          const SizedBox(width: 10),
          ...actions,
        ],
      ],
    );
  }
}

Route<T> phongRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 220),
      reverseTransitionDuration: const Duration(milliseconds: 170),
      pageBuilder: (_, animation, secondaryAnimation) => page,
      transitionsBuilder: (_, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            scale: Tween<double>(begin: .975, end: 1).animate(curved),
            child: child,
          ),
        );
      },
    );
