import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../widgets/neon_pressable.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _ambientController;
  BotDifficulty _difficulty = BotDifficulty.tactical;
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    _ambientController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 9),
    )..repeat();
    unawaited(AudioManager.instance.startBgm());
  }

  @override
  void dispose() {
    _ambientController.dispose();
    super.dispose();
  }

  Future<void> _startGame() async {
    if (_leaving) return;
    setState(() => _leaving = true);
    await AudioManager.instance.importantImpact();
    await Future<void>.delayed(const Duration(milliseconds: 120));
    if (!mounted) return;
    await SceneTransitionManager.openGame(
      context,
      config: GameConfig.forDifficulty(_difficulty),
    );
  }

  void _showMessage(String message) {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 900),
          behavior: SnackBarBehavior.floating,
          backgroundColor: const Color(0xF20A1222),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
            side: const BorderSide(color: Color(0x775CE8FF)),
          ),
          content: Text(
            message,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
      );
  }

  Future<void> _showSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: const Color(0xD9000208),
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setSheetState) {
            return SafeArea(
              minimum: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: _NeonPanel(
                colors: const <Color>[Color(0xFF32DFFF), Color(0xFFFF42B5)],
                cut: 24,
                padding: const EdgeInsets.fromLTRB(18, 15, 18, 18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: 54,
                      height: 4,
                      decoration: BoxDecoration(
                        color: const Color(0xFF526179),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    const SizedBox(height: 13),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.settings_rounded, color: Color(0xFFFF69C5), size: 29),
                        SizedBox(width: 9),
                        Text(
                          'تنظیمات مسابقه',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'سطح ربات',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(fontSize: 13, color: Color(0xFFBFD1E8), fontWeight: FontWeight.w800),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: BotDifficulty.values.map((BotDifficulty value) {
                        final bool selected = value == _difficulty;
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 3),
                            child: NeonPressable(
                              semanticLabel: value.title,
                              onTap: () {
                                setState(() => _difficulty = value);
                                setSheetState(() {});
                              },
                              builder: (_, __) => AnimatedContainer(
                                duration: const Duration(milliseconds: 110),
                                height: 50,
                                decoration: BoxDecoration(
                                  color: selected ? const Color(0xFF0D6E91) : const Color(0xFF11192A),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: selected ? const Color(0xFF67EBFF) : const Color(0x445E7194),
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  value.title,
                                  textDirection: TextDirection.rtl,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    color: selected ? Colors.white : const Color(0xFF9EABC2),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    _SettingsToggle(
                      icon: AudioManager.instance.soundEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                      label: 'صدای بازی',
                      enabled: AudioManager.instance.soundEnabled,
                      onTap: () async {
                        await AudioManager.instance.setSoundEnabled(!AudioManager.instance.soundEnabled);
                        if (mounted) setState(() {});
                        setSheetState(() {});
                      },
                    ),
                    const SizedBox(height: 8),
                    _SettingsToggle(
                      icon: AudioManager.instance.vibrationEnabled ? Icons.vibration_rounded : Icons.mobile_off_rounded,
                      label: 'بازخورد لرزشی',
                      enabled: AudioManager.instance.vibrationEnabled,
                      onTap: () {
                        AudioManager.instance.vibrationEnabled = !AudioManager.instance.vibrationEnabled;
                        setState(() {});
                        setSheetState(() {});
                      },
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'قانون مسابقه: هر بازیکنی که زودتر ۱۰ گل دریافت کند، بازنده است.',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 11, color: Color(0xFFAEBBD0), fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _selectNav(int index) {
    if (index == 0) return;
    const List<String> labels = <String>['خانه', 'پروفایل', 'ماموریت‌ها', 'فروشگاه'];
    _showMessage(labels[index]);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_leaving,
      child: Scaffold(
        backgroundColor: const Color(0xFF02040B),
        body: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 310),
          curve: Curves.easeOutCubic,
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              AnimatedBuilder(
                animation: _ambientController,
                builder: (_, __) => RepaintBoundary(
                  child: CustomPaint(
                    painter: _HomeBackgroundPainter(progress: _ambientController.value),
                  ),
                ),
              ),
              SafeArea(
                bottom: false,
                child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    final double horizontal = constraints.maxWidth < 390 ? 12.0 : 18.0;
                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(horizontal, 10, horizontal, 18),
                      child: Column(
                        children: <Widget>[
                          _TopStatusBar(
                            onProfile: () => _showMessage('شون رنجر — سطح ۱۸'),
                            onEnergy: () => _showMessage('انرژی فعلی: 2,450'),
                            onCredit: () => _showMessage('اعتبار فعلی: 860'),
                          ),
                          SizedBox(height: constraints.maxHeight < 720 ? 15 : 22),
                          const _GameTitle(),
                          SizedBox(height: constraints.maxHeight < 720 ? 12 : 18),
                          AnimatedBuilder(
                            animation: _ambientController,
                            builder: (_, __) => _ArenaPreview(
                              progress: _ambientController.value,
                            ),
                          ),
                          SizedBox(height: constraints.maxHeight < 720 ? 14 : 18),
                          _PrimaryStartButton(onTap: _startGame),
                          const SizedBox(height: 11),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: _SecondaryButton(
                                  label: 'بازی آفلاین',
                                  icon: Icons.gps_fixed_rounded,
                                  color: const Color(0xFF32DFFF),
                                  onTap: _startGame,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: _SecondaryButton(
                                  label: 'تنظیمات',
                                  icon: Icons.settings_rounded,
                                  color: const Color(0xFFFF4DB5),
                                  onTap: _showSettings,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 220),
          child: _BottomNavigation(
            selectedIndex: 0,
            onSelected: _selectNav,
          ),
        ),
      ),
    );
  }
}

class _TopStatusBar extends StatelessWidget {
  const _TopStatusBar({
    required this.onProfile,
    required this.onEnergy,
    required this.onCredit,
  });

  final VoidCallback onProfile;
  final VoidCallback onEnergy;
  final VoidCallback onCredit;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 78,
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 54,
            child: NeonPressable(
              semanticLabel: 'پروفایل شون رنجر',
              onTap: onProfile,
              builder: (_, bool pressed) => _NeonPanel(
                pressed: pressed,
                colors: const <Color>[Color(0xFF32DFFF), Color(0xFF0876AC)],
                cut: 15,
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const RadialGradient(
                          colors: <Color>[Color(0xFFFF58C2), Color(0xFF6437A8), Color(0xFF07111E)],
                        ),
                        border: Border.all(color: const Color(0xFF5DEBFF), width: 1.5),
                      ),
                      child: const Icon(Icons.sports_motorsports_rounded, color: Colors.white, size: 35),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          const Text(
                            'شون رنجر',
                            textDirection: TextDirection.rtl,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'سطح 18',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(fontSize: 10, color: Color(0xFF4CE5FF), fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 5),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: const LinearProgressIndicator(
                                    value: 0.75,
                                    minHeight: 4,
                                    backgroundColor: Color(0xFF17283B),
                                    valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF23CEFA)),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 5),
                              const Text('75%', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 46,
            child: Row(
              children: <Widget>[
                Expanded(
                  child: _ResourceCapsule(
                    icon: Icons.bolt_rounded,
                    value: '2,450',
                    color: const Color(0xFFFFC928),
                    borderColor: const Color(0xFF34DFFF),
                    onTap: onEnergy,
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: _ResourceCapsule(
                    icon: Icons.adjust_rounded,
                    value: '860',
                    color: const Color(0xFFFF55CF),
                    borderColor: const Color(0xFFFF4DB5),
                    onTap: onCredit,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ResourceCapsule extends StatelessWidget {
  const _ResourceCapsule({
    required this.icon,
    required this.value,
    required this.color,
    required this.borderColor,
    required this.onTap,
  });

  final IconData icon;
  final String value;
  final Color color;
  final Color borderColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: value,
      onTap: onTap,
      builder: (_, bool pressed) => _NeonPanel(
        pressed: pressed,
        colors: <Color>[borderColor, borderColor.withValues(alpha: 0.55)],
        cut: 12,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 9),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, color: color, size: 20),
                const SizedBox(width: 4),
                Flexible(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 3),
            Icon(Icons.add_rounded, color: borderColor, size: 15),
          ],
        ),
      ),
    );
  }
}

class _GameTitle extends StatelessWidget {
  const _GameTitle();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        FittedBox(
          fit: BoxFit.scaleDown,
          child: RichText(
            text: const TextSpan(
              style: TextStyle(fontSize: 43, fontWeight: FontWeight.w900, letterSpacing: 1.5),
              children: <InlineSpan>[
                TextSpan(
                  text: 'PULSE ',
                  style: TextStyle(
                    color: Color(0xFFE8FDFF),
                    shadows: <Shadow>[
                      Shadow(color: Color(0xFF20D8FF), blurRadius: 15),
                      Shadow(color: Color(0xFF20D8FF), blurRadius: 30),
                    ],
                  ),
                ),
                TextSpan(
                  text: 'ARENA',
                  style: TextStyle(
                    color: Color(0xFFFFE8FA),
                    shadows: <Shadow>[
                      Shadow(color: Color(0xFFFF32B4), blurRadius: 15),
                      Shadow(color: Color(0xFFFF32B4), blurRadius: 30),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(width: 52, height: 1.5, color: const Color(0xFF37DFFF)),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 13),
              child: Text(
                'نبرد پالس‌ها',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFFEFEAFF),
                  shadows: <Shadow>[Shadow(color: Color(0xFF9D5CFF), blurRadius: 13)],
                ),
              ),
            ),
            Container(width: 52, height: 1.5, color: const Color(0xFFFF4DB5)),
          ],
        ),
      ],
    );
  }
}

class _ArenaPreview extends StatelessWidget {
  const _ArenaPreview({required this.progress});

  final double progress;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.42,
      child: Stack(
        clipBehavior: Clip.none,
        children: <Widget>[
          Positioned.fill(
            child: RepaintBoundary(
              child: CustomPaint(
                painter: _ArenaPreviewPainter(progress: progress),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: -13,
            child: Center(
              child: _NeonPanel(
                colors: const <Color>[Color(0xFF2BDFFF), Color(0xFFFF48B5)],
                cut: 12,
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    _AbilityIndicator(icon: Icons.shield_rounded, text: 'x2', color: Color(0xFF38DFFF)),
                    _AbilityDivider(),
                    _AbilityIndicator(icon: Icons.bolt_rounded, text: 'x1', color: Color(0xFFFFD13A)),
                    _AbilityDivider(),
                    _AbilityIndicator(icon: Icons.graphic_eq_rounded, text: 'x2', color: Color(0xFFFF53C7)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AbilityIndicator extends StatelessWidget {
  const _AbilityIndicator({required this.icon, required this.text, required this.color});

  final IconData icon;
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 4),
        Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _AbilityDivider extends StatelessWidget {
  const _AbilityDivider();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 22,
      margin: const EdgeInsets.symmetric(horizontal: 13),
      color: const Color(0xFF34435A),
    );
  }
}

class _PrimaryStartButton extends StatelessWidget {
  const _PrimaryStartButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'شروع بازی',
      pressedScale: 0.955,
      onTap: onTap,
      builder: (_, bool pressed) => SizedBox(
        height: 70,
        width: double.infinity,
        child: _NeonPanel(
          pressed: pressed,
          colors: const <Color>[Color(0xFF2CDFFF), Color(0xFF7A4FFF), Color(0xFFFF42B5)],
          cut: 18,
          padding: const EdgeInsets.symmetric(horizontal: 22),
          innerGradient: LinearGradient(
            colors: <Color>[
              const Color(0xFF092E53).withValues(alpha: pressed ? 0.95 : 0.80),
              const Color(0xFF351251).withValues(alpha: pressed ? 0.95 : 0.82),
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.chevron_left_rounded, color: Color(0x8860E7FF), size: 30),
              SizedBox(width: 14),
              Text(
                'شروع بازی',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  shadows: <Shadow>[Shadow(color: Color(0xFFB453FF), blurRadius: 16)],
                ),
              ),
              SizedBox(width: 14),
              Icon(Icons.chevron_right_rounded, color: Color(0x88FF5AC8), size: 30),
            ],
          ),
        ),
      ),
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  const _SecondaryButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) => SizedBox(
        height: 54,
        child: _NeonPanel(
          pressed: pressed,
          colors: <Color>[color, color.withValues(alpha: 0.55)],
          cut: 14,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: color, size: 25),
              const SizedBox(width: 9),
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    label,
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation({required this.selectedIndex, required this.onSelected});

  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    const List<IconData> icons = <IconData>[
      Icons.home_rounded,
      Icons.person_outline_rounded,
      Icons.gps_fixed_rounded,
      Icons.shopping_cart_outlined,
    ];
    const List<String> labels = <String>['خانه', 'پروفایل', 'ماموریت‌ها', 'فروشگاه'];

    return ColoredBox(
      color: const Color(0xFF02040B),
      child: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(12, 5, 12, 8),
        child: _NeonPanel(
          colors: const <Color>[Color(0xFF29DFFF), Color(0xFF34436E), Color(0xFFFF43B4)],
          cut: 16,
          padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
          child: SizedBox(
            height: 67,
            child: Row(
              children: List<Widget>.generate(icons.length, (int index) {
                final bool selected = index == selectedIndex;
                final Color color = selected ? const Color(0xFF53E8FF) : const Color(0xFF7780B0);
                return Expanded(
                  child: NeonPressable(
                    semanticLabel: labels[index],
                    onTap: () => onSelected(index),
                    builder: (_, __) => AnimatedContainer(
                      duration: const Duration(milliseconds: 130),
                      decoration: BoxDecoration(
                        color: selected ? const Color(0x2217CFFF) : Colors.transparent,
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Stack(
                            clipBehavior: Clip.none,
                            children: <Widget>[
                              Icon(
                                icons[index],
                                color: color,
                                size: selected ? 27 : 25,
                                shadows: selected
                                    ? const <Shadow>[Shadow(color: Color(0xFF32DFFF), blurRadius: 12)]
                                    : null,
                              ),
                              if (index == 2)
                                const Positioned(
                                  right: -4,
                                  top: -4,
                                  child: CircleAvatar(radius: 3.5, backgroundColor: Color(0xFFFF3F9F)),
                                ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            labels[index],
                            textDirection: TextDirection.rtl,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 10.5, color: color, fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 3),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 130),
                            width: selected ? 28 : 0,
                            height: 2.5,
                            decoration: BoxDecoration(
                              color: const Color(0xFF39E2FF),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _SettingsToggle extends StatelessWidget {
  const _SettingsToggle({
    required this.icon,
    required this.label,
    required this.enabled,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = enabled ? const Color(0xFF4CE6FF) : const Color(0xFF7D879D);
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) => AnimatedContainer(
        duration: const Duration(milliseconds: 110),
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 13),
        decoration: BoxDecoration(
          color: pressed ? const Color(0xFF151F31) : const Color(0xFF111827),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: 0.42)),
        ),
        child: Row(
          children: <Widget>[
            Icon(icon, color: color),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                label,
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.right,
                style: TextStyle(color: color, fontWeight: FontWeight.w800),
              ),
            ),
            Switch(value: enabled, onChanged: (_) => onTap()),
          ],
        ),
      ),
    );
  }
}

class _NeonPanel extends StatelessWidget {
  const _NeonPanel({
    required this.colors,
    required this.child,
    this.cut = 14,
    this.padding = const EdgeInsets.all(10),
    this.pressed = false,
    this.innerGradient,
  });

  final List<Color> colors;
  final Widget child;
  final double cut;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final Gradient? innerGradient;

  @override
  Widget build(BuildContext context) {
    final List<Color> borderColors = colors
        .map((Color color) => color.withValues(alpha: pressed ? 0.72 : 0.98))
        .toList(growable: false);
    return ClipPath(
      clipper: _TechClipper(cut),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 95),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.all(pressed ? 1.0 : 1.45),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: borderColors),
        ),
        child: ClipPath(
          clipper: _TechClipper(math.max(2.0, cut - 1.5)),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 95),
            padding: padding,
            decoration: BoxDecoration(
              gradient: innerGradient ??
                  LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[
                      pressed ? const Color(0xFF0D1728) : const Color(0xF20A1221),
                      pressed ? const Color(0xFF100D20) : const Color(0xF20A0A17),
                    ],
                  ),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _TechClipper extends CustomClipper<Path> {
  const _TechClipper(this.cut);

  final double cut;

  @override
  Path getClip(Size size) {
    final double c = math.min(cut, math.min(size.width, size.height) * 0.24);
    return Path()
      ..moveTo(c, 0)
      ..lineTo(size.width - c, 0)
      ..lineTo(size.width, c)
      ..lineTo(size.width, size.height - c)
      ..lineTo(size.width - c, size.height)
      ..lineTo(c, size.height)
      ..lineTo(0, size.height - c)
      ..lineTo(0, c)
      ..close();
  }

  @override
  bool shouldReclip(covariant _TechClipper oldClipper) => oldClipper.cut != cut;
}

class _HomeBackgroundPainter extends CustomPainter {
  const _HomeBackgroundPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF02040A), Color(0xFF050716), Color(0xFF03040B)],
        ).createShader(rect),
    );

    final double pulse = 0.5 + 0.5 * math.sin(progress * math.pi * 2);
    final Paint cyanGlow = Paint()
      ..shader = RadialGradient(
        colors: <Color>[
          Color.fromRGBO(27, 199, 255, 0.12 + pulse * 0.035),
          const Color(0x001BC7FF),
        ],
      ).createShader(Rect.fromCircle(center: Offset(size.width * 0.14, size.height * 0.35), radius: size.width * 0.72));
    final Paint pinkGlow = Paint()
      ..shader = RadialGradient(
        colors: <Color>[
          Color.fromRGBO(255, 39, 166, 0.11 + (1 - pulse) * 0.035),
          const Color(0x00FF27A6),
        ],
      ).createShader(Rect.fromCircle(center: Offset(size.width * 0.88, size.height * 0.42), radius: size.width * 0.72));
    canvas.drawRect(rect, cyanGlow);
    canvas.drawRect(rect, pinkGlow);

    final Paint gridPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.55
      ..color = const Color(0x182F82AA);
    const double radius = 18;
    final double hexHeight = math.sqrt(3) * radius;
    for (double x = -radius; x < size.width + radius; x += radius * 3) {
      final int column = ((x + radius) / (radius * 3)).round();
      for (double y = -hexHeight; y < size.height + hexHeight; y += hexHeight) {
        _drawHex(canvas, Offset(x, y + (column.isOdd ? hexHeight / 2 : 0)), radius, gridPaint);
        _drawHex(canvas, Offset(x + radius * 1.5, y + hexHeight / 2 + (column.isOdd ? hexHeight / 2 : 0)), radius, gridPaint);
      }
    }

    final Paint scanPaint = Paint()..strokeWidth = 1;
    for (int i = 0; i < 5; i++) {
      final double y = (size.height * ((progress + i / 5) % 1));
      scanPaint.color = i.isEven ? const Color(0x1837DEFF) : const Color(0x16FF44B3);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), scanPaint);
    }
  }

  static void _drawHex(Canvas canvas, Offset center, double radius, Paint paint) {
    final Path path = Path();
    for (int i = 0; i < 6; i++) {
      final double angle = math.pi / 3 * i;
      final Offset point = center + Offset(math.cos(angle) * radius, math.sin(angle) * radius);
      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _HomeBackgroundPainter oldDelegate) => oldDelegate.progress != progress;
}

class _ArenaPreviewPainter extends CustomPainter {
  const _ArenaPreviewPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final RRect field = RRect.fromRectAndRadius(
      Rect.fromLTWH(1.5, 1.5, size.width - 3, size.height - 3),
      const Radius.circular(22),
    );
    canvas.drawRRect(
      field,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF03162A), Color(0xFF071126), Color(0xFF24051F)],
        ).createShader(rect),
    );

    canvas.save();
    canvas.clipRRect(field);
    final Paint grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.55
      ..color = const Color(0x263E6C94);
    const double radius = 17;
    final double hexHeight = math.sqrt(3) * radius;
    for (double x = -radius; x < size.width + radius; x += radius * 3) {
      final int column = ((x + radius) / (radius * 3)).round();
      for (double y = -hexHeight; y < size.height + hexHeight; y += hexHeight) {
        _HomeBackgroundPainter._drawHex(canvas, Offset(x, y + (column.isOdd ? hexHeight / 2 : 0)), radius, grid);
        _HomeBackgroundPainter._drawHex(canvas, Offset(x + radius * 1.5, y + hexHeight / 2 + (column.isOdd ? hexHeight / 2 : 0)), radius, grid);
      }
    }
    canvas.restore();

    final Path border = Path()..addRRect(field);
    final Paint borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..shader = const LinearGradient(
        colors: <Color>[Color(0xFF28DFFF), Color(0xFF7555FF), Color(0xFFFF43B5)],
      ).createShader(rect);
    canvas.drawPath(border, borderPaint);

    final double midX = size.width / 2;
    final double midY = size.height / 2;
    final Paint centerLine = Paint()
      ..strokeWidth = 1
      ..color = const Color(0x555F5DFF);
    canvas.drawLine(Offset(midX, 15), Offset(midX, size.height - 15), centerLine);
    for (int i = 0; i < 9; i++) {
      final double y = 20 + (size.height - 40) * i / 8;
      final double r = 1.5 + 1.2 * math.sin(progress * math.pi * 2 + i);
      canvas.drawCircle(Offset(midX, y), r, Paint()..color = const Color(0xFFAA52FF));
    }

    final double paddleHeight = size.height * 0.43;
    final RRect leftPaddle = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(size.width * 0.11, midY), width: 11, height: paddleHeight),
      const Radius.circular(8),
    );
    final RRect rightPaddle = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(size.width * 0.89, midY), width: 11, height: paddleHeight),
      const Radius.circular(8),
    );
    canvas.drawRRect(leftPaddle, Paint()..color = const Color(0xFF39E6FF));
    canvas.drawRRect(rightPaddle, Paint()..color = const Color(0xFFFF4DB9));
    canvas.drawRRect(
      leftPaddle.deflate(3),
      Paint()..color = const Color(0xFFBDF8FF),
    );
    canvas.drawRRect(
      rightPaddle.deflate(3),
      Paint()..color = const Color(0xFFFFC2E7),
    );

    final double angle = progress * math.pi * 2;
    final Offset core = Offset(midX, midY);
    final double orbRadius = 15 + math.sin(angle) * 1.2;
    final Paint beam = Paint()
      ..strokeWidth = 1.3
      ..shader = const LinearGradient(
        colors: <Color>[Color(0xFF34E3FF), Color(0xFF9F5DFF), Color(0xFFFF4CB8)],
      ).createShader(Rect.fromPoints(Offset(size.width * 0.14, midY), Offset(size.width * 0.86, midY)));
    canvas.drawLine(Offset(size.width * 0.14, midY + math.sin(angle) * 8), core, beam);
    canvas.drawLine(core, Offset(size.width * 0.86, midY - math.sin(angle) * 8), beam);

    for (int i = 0; i < 3; i++) {
      final double radiusRing = 27 + i * 10 + math.sin(angle + i) * 2;
      final Paint ring = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = i == 0 ? 2 : 1
        ..shader = const SweepGradient(
          colors: <Color>[Color(0xFF33E1FF), Color(0xFF694EFF), Color(0xFFFF45B7), Color(0xFF33E1FF)],
        ).createShader(Rect.fromCircle(center: core, radius: radiusRing));
      canvas.drawCircle(core, radiusRing, ring);
    }
    canvas.drawCircle(
      core,
      orbRadius,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Colors.white, Color(0xFF7A4DFF), Color(0xFF170B31)],
        ).createShader(Rect.fromCircle(center: core, radius: orbRadius)),
    );

    for (int i = 0; i < 12; i++) {
      final double particleAngle = angle + i * math.pi * 2 / 12;
      final double distance = 44.0 + (i % 3) * 11;
      final Offset p = core + Offset(math.cos(particleAngle) * distance, math.sin(particleAngle) * distance);
      canvas.drawCircle(
        p,
        1.2 + (i % 2) * 0.8,
        Paint()..color = i.isEven ? const Color(0xAA3FE7FF) : const Color(0xAAFF4DC0),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ArenaPreviewPainter oldDelegate) => oldDelegate.progress != progress;
}
