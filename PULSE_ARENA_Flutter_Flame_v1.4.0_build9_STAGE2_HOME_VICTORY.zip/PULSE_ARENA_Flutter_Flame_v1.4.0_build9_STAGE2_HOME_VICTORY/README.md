# PULSE ARENA – Stage 2 Home & Victory

Version: `1.4.0+9`

This package continues the optimized Build 8 gameplay and adds the coded Stage 2 home lobby plus a dedicated real-player victory celebration.

## Implemented

- Portrait home lobby recreated in Flutter code from the approved visual reference.
- No screenshot or generated image is used as the home screen.
- Profile, level progress, energy, credit, title, animated arena preview, ability inventory, start button, offline button, settings, and bottom navigation are separate widgets.
- Every interactive home item uses a reusable compressed press state (`AnimatedScale`, default scale `0.96`) with short audio and haptic feedback.
- Settings sheet controls bot difficulty, sound, and vibration.
- Home is portrait; gameplay switches to landscape; returning to the menu restores portrait orientation.
- When the real player wins, the arena enters a cyan victory-glow state and the result overlay displays animated rays, particles, scan lighting, a trophy pulse, `VICTORY`, the final score, statistics, replay, and home actions.
- Bot victory uses a separate restrained loss result state.
- Match target remains 10 goals received: the first side to concede 10 goals loses.

## Build

The included `.github/workflows/build-apk.yml` is WF4. It:

- selects the newest valid Flutter source ZIP;
- validates the Stage 2 home, compressed interaction, runtime orientation, victory effect, and 10-goal rule;
- runs `flutter analyze` and all tests;
- builds separate Bazaar and Myket release APKs;
- removes previous PULSE ARENA artifacts before uploading the new output;
- uploads complete diagnostics if any stage fails.
