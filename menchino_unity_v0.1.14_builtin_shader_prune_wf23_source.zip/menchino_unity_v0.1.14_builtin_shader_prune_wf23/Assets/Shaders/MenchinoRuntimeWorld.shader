Shader "Menchino/RuntimeWorld"
{
    Properties
    {
        _Color ("Color", Color) = (1,1,1,1)
        _Metallic ("Metallic Accent", Range(0,1)) = 0.15
        _Glossiness ("Highlight", Range(0,1)) = 0.65
        [HDR] _EmissionColor ("Emission", Color) = (0,0,0,0)
    }

    SubShader
    {
        Tags { "Queue"="Geometry" "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            Cull Back
            ZWrite On
            ZTest LEqual

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 2.0
            #pragma multi_compile_fwdbase

            #include "UnityCG.cginc"
            #include "Lighting.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
            };

            struct v2f
            {
                float4 position : SV_POSITION;
                float3 worldPosition : TEXCOORD0;
                half3 worldNormal : TEXCOORD1;
            };

            fixed4 _Color;
            half _Metallic;
            half _Glossiness;
            fixed4 _EmissionColor;

            v2f vert(appdata input)
            {
                v2f output;
                output.position = UnityObjectToClipPos(input.vertex);
                output.worldPosition = mul(unity_ObjectToWorld, input.vertex).xyz;
                output.worldNormal = UnityObjectToWorldNormal(input.normal);
                return output;
            }

            fixed4 frag(v2f input) : SV_Target
            {
                half3 normal = normalize(input.worldNormal);
                half3 lightDirection = normalize(UnityWorldSpaceLightDir(input.worldPosition));
                half diffuseFactor = saturate(dot(normal, lightDirection));
                half3 ambient = ShadeSH9(half4(normal, 1.0));
                half3 diffuse = _LightColor0.rgb * diffuseFactor;

                half3 viewDirection = normalize(_WorldSpaceCameraPos.xyz - input.worldPosition);
                half rim = pow(1.0h - saturate(dot(normal, viewDirection)), lerp(4.0h, 1.5h, _Glossiness));
                half3 accent = _LightColor0.rgb * rim * (0.08h + _Metallic * 0.16h);

                half3 color = _Color.rgb * (ambient + diffuse * 0.78h + 0.18h) + accent + _EmissionColor.rgb;
                return fixed4(color, _Color.a);
            }
            ENDCG
        }
    }
    Fallback Off
}
