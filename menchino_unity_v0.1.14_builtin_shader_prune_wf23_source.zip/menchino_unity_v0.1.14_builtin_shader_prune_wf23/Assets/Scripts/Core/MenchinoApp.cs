using System;
using System.Collections;
using Menchino.Data;
using Menchino.Presentation;
using Menchino.Services;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Menchino.Core
{
    public sealed class MenchinoApp : MonoBehaviour
    {
        public static MenchinoApp Instance { get; private set; }
        public GameServices Services { get; private set; }
        public PendingMatchSettings PendingMatch { get; set; }
        public MatchResultData LastResult { get; set; }
        public bool ResumeRequested { get; set; }
        public ScreenBase CurrentScreen { get; private set; }
        public Canvas PopupCanvas { get; private set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void RuntimeBoot()
        {
            if (Instance != null) return;
            var root = new GameObject("MenchinoApp", typeof(MenchinoApp));
            DontDestroyOnLoad(root);
        }

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Application.targetFrameRate = 60;
            Screen.orientation = ScreenOrientation.Portrait;
            QualitySettings.vSyncCount = 0;
            UiFactory.EnsureRuntimeShaders();
            UiFactory.EnsureEventSystem();
            if (GetComponent<AudioListener>() == null) gameObject.AddComponent<AudioListener>();
            Services = new GameServices(this);
            PendingMatch = DefaultContent.CreatePendingSettings(GameMode.VsBots, Services.Save.Data.profile);
            SceneManager.sceneLoaded += OnSceneLoaded;
        }

        private IEnumerator Start()
        {
            yield return null;
            if (SceneManager.GetActiveScene().name == "Boot") Navigate(ScreenId.Home);
            else BuildForScene(SceneManager.GetActiveScene().name);
        }

        private void OnDestroy()
        {
            if (Instance == this) SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        public void Navigate(ScreenId screen)
        {
            Time.timeScale = 1f;
            string name = screen.ToString();
            if (SceneManager.GetActiveScene().name == name) { BuildForScene(name); return; }
            SceneManager.LoadScene(name);
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode) => BuildForScene(scene.name);

        private void BuildForScene(string sceneName)
        {
            if (CurrentScreen != null) Destroy(CurrentScreen.gameObject);
            if (PopupCanvas != null) Destroy(PopupCanvas.gameObject);
            PopupCanvas = UiFactory.CreateCanvas("PopupCanvas");
            PopupCanvas.sortingOrder = 100;
            DontDestroyOnLoad(PopupCanvas.gameObject);
            CurrentScreen = ScreenComposer.Create(sceneName, this);
        }

        public void ShowPopup(string title, string message, string primaryLabel, Action primary, string secondaryLabel = "", Action secondary = null)
        {
            if (PopupCanvas == null) return;
            for (int i = PopupCanvas.transform.childCount - 1; i >= 0; i--) Destroy(PopupCanvas.transform.GetChild(i).gameObject);
            var shade = UiFactory.CreateImage(PopupCanvas.transform, "Shade", null, new Color(0f, 0f, 0f, .72f));
            UiFactory.Stretch(shade.rectTransform);
            var panel = UiFactory.CreatePanel(shade.transform, "PopupPanel");
            panel.rectTransform.anchorMin = panel.rectTransform.anchorMax = new Vector2(.5f, .5f);
            panel.rectTransform.sizeDelta = new Vector2(800, 570);
            panel.rectTransform.anchoredPosition = Vector2.zero;
            var titleText = UiFactory.CreateText(panel.transform, title, 50, ThemePalette.GoldLight);
            titleText.rectTransform.anchorMin = new Vector2(.07f, .72f); titleText.rectTransform.anchorMax = new Vector2(.93f, .94f);
            titleText.rectTransform.offsetMin = titleText.rectTransform.offsetMax = Vector2.zero;
            var body = UiFactory.CreateText(panel.transform, message, 31, ThemePalette.Cream, TextAnchor.MiddleCenter, FontStyle.Normal);
            body.rectTransform.anchorMin = new Vector2(.09f, .30f); body.rectTransform.anchorMax = new Vector2(.91f, .73f);
            body.rectTransform.offsetMin = body.rectTransform.offsetMax = Vector2.zero;

            void Close()
            {
                if (shade != null) Destroy(shade.gameObject);
            }

            var primaryButton = UiFactory.CreateButton(panel.transform, primaryLabel, ProceduralSpriteFactory.GreenButton(), () => { Close(); primary?.Invoke(); }, Services.Audio, 34);
            primaryButton.GetComponent<RectTransform>().anchorMin = new Vector2(.52f, .07f);
            primaryButton.GetComponent<RectTransform>().anchorMax = new Vector2(.91f, .25f);
            primaryButton.GetComponent<RectTransform>().offsetMin = primaryButton.GetComponent<RectTransform>().offsetMax = Vector2.zero;
            if (!string.IsNullOrWhiteSpace(secondaryLabel))
            {
                var secondaryButton = UiFactory.CreateButton(panel.transform, secondaryLabel, ProceduralSpriteFactory.RedButton(), () => { Close(); secondary?.Invoke(); }, Services.Audio, 34);
                secondaryButton.GetComponent<RectTransform>().anchorMin = new Vector2(.09f, .07f);
                secondaryButton.GetComponent<RectTransform>().anchorMax = new Vector2(.48f, .25f);
                secondaryButton.GetComponent<RectTransform>().offsetMin = secondaryButton.GetComponent<RectTransform>().offsetMax = Vector2.zero;
            }
            panel.transform.localScale = Vector3.zero;
            StartCoroutine(AnimatePopup(panel.transform));
        }

        private static IEnumerator AnimatePopup(Transform panel)
        {
            float time = 0f;
            while (time < .28f)
            {
                time += Time.unscaledDeltaTime;
                float t = Mathf.Clamp01(time / .28f);
                float elastic = 1f - Mathf.Pow(1f - t, 3f) + Mathf.Sin(t * Mathf.PI) * .08f;
                panel.localScale = Vector3.one * elastic;
                yield return null;
            }
            panel.localScale = Vector3.one;
        }
    }
}
