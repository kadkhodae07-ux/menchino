import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('complete game hub includes every production page', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();
    final String app = File('lib/app/pulse_arena_app.dart').readAsStringSync();

    expect(app, contains('HubScreen'));
    expect(hub, contains('class HubScreen'));
    expect(hub, contains('class _ProfilePage'));
    expect(hub, contains('class _MissionsPage'));
    expect(hub, contains('class _RankingPage'));
    expect(hub, contains('class _ShopPage'));
    expect(hub, contains('class _SettingsScreen'));
    expect(hub, contains('رتبه‌بندی'));
    expect(hub, contains('فروشگاه آرنا'));
    expect(hub, contains('پروفایل فرمانده'));
    expect(hub, contains('ماموریت‌ها'));
  });

  test('home navigation is centered and has five graphical items', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();

    expect(hub, contains('class _HomeNavItem'));
    expect(hub, contains('left: 0'));
    expect(hub, contains('right: 0'));
    expect(hub, contains('Center('));
    expect(hub, contains("_NavData(Icons.leaderboard_rounded, 'رتبه‌بندی')"));
    expect(hub, contains("_NavData(Icons.home_rounded, 'خانه')"));
  });

  test('all main surfaces use lifted graphic painters instead of flat cards', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();

    expect(hub, contains('class _LiftedPanelPainter'));
    expect(hub, contains('MaskFilter.blur'));
    expect(hub, contains('canvas.translate(0, pressed ? 1.5 : 3.5)'));
    expect(hub, contains('class _ActionButtonPainter'));
    expect(hub, isNot(contains('ElevatedButton(')));
    expect(RegExp(r'(^|[^A-Za-z0-9_])Card\(').hasMatch(hub), isFalse);
  });

  test('home layout expands arena and anchors actions near bottom', () {
    final String hub = File('lib/screens/hub_screen.dart').readAsStringSync();

    expect(hub, contains('MainAxisAlignment.spaceBetween'));
    expect(hub, contains('final double arenaHeight = (height * .37)'));
    expect(hub, contains('class _SeasonRibbon'));
    expect(hub, contains('PULSE ARENA'));
    expect(hub, contains('شروع بازی'));
  });
}
