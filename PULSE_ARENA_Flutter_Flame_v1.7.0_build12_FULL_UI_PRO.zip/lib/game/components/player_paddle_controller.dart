import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

class PlayerPaddleController extends PositionComponent {
  PlayerPaddleController({
    required this.moveSpeed,
    this.acceleration = 52000,
    this.response = 46,
  });

  final double moveSpeed;
  final double acceleration;
  final double response;

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  bool movementEnabled = true;
  double verticalVelocity = 0;

  bool _pointerActive = false;
  int _lastInputMicros = 0;
  double _lastInputPosition = 0;
  double _motionEnergy = 0;
  double _hitEnergy = 0;
  Path _bodyPath = Path();
  Rect _localBounds = Rect.zero;

  late Paint _bodyPaint;
  final Paint _ghostPaint = Paint();
  final Paint _glowPaint = Paint()..style = PaintingStyle.stroke;
  final Paint _outlinePaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.7
    ..color = const Color(0xEFFFFFFF);
  final Paint _whitePaint = Paint()..color = const Color(0xFFFFFFFF);
  final Paint _detailPaint = Paint()..color = const Color(0xB8073458);

  static const Color _cyan = Color(0xFF25E2FF);

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) /
                movementBounds.height)
            .clamp(0.0, 1.0)
            .toDouble();

    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.024).clamp(23.0, 35.0).toDouble(),
      (arena.height * 0.275).clamp(86.0, 138.0).toDouble(),
    );
    position.x =
        arena.left + (arena.width * 0.032).clamp(24.0, 42.0).toDouble();
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
    _lastInputPosition = position.y;
    _rebuildVisuals();
  }

  void _rebuildVisuals() {
    _localBounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * 0.32;
    _bodyPath = Path()
      ..moveTo(cut, 0)
      ..lineTo(size.x - cut * 0.22, 0)
      ..lineTo(size.x, cut)
      ..lineTo(size.x, size.y - cut)
      ..lineTo(size.x - cut * 0.22, size.y)
      ..lineTo(cut, size.y)
      ..lineTo(0, size.y - cut * 0.65)
      ..lineTo(0, cut * 0.65)
      ..close();
    _bodyPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: <Color>[
          Color(0xFF063F68),
          Color(0xFF25E2FF),
          Color(0xFFF2FFFF),
        ],
      ).createShader(_localBounds);
  }

  /// The paddle follows the finger immediately. Velocity is still measured so
  /// paddle motion can influence the ball angle without adding input latency.
  void setTargetFromTouch(double touchY, {int? eventMicros}) {
    if (!movementEnabled || movementBounds.isEmpty) return;
    final double nextTarget = (touchY - size.y / 2)
        .clamp(movementBounds.top, movementBounds.bottom - size.y)
        .toDouble();

    final int now = eventMicros ?? DateTime.now().microsecondsSinceEpoch;
    if (_lastInputMicros != 0) {
      final double seconds = (now - _lastInputMicros) / 1000000;
      if (seconds > 0.0004 && seconds < 0.12) {
        final double sample = (nextTarget - _lastInputPosition) / seconds;
        verticalVelocity = (verticalVelocity * 0.18 + sample * 0.82)
            .clamp(-6800.0, 6800.0)
            .toDouble();
      }
    }

    _pointerActive = true;
    _lastInputMicros = now;
    _lastInputPosition = nextTarget;
    targetY = nextTarget;
    position.y = nextTarget;
    _updateMotionEnergy();
  }

  void endTouch() {
    _pointerActive = false;
    _lastInputMicros = 0;
    _lastInputPosition = position.y;
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    verticalVelocity = 0;
    _motionEnergy = 0;
    _lastInputPosition = targetY;
    _lastInputMicros = 0;
    _pointerActive = false;
  }

  void registerHit({required bool perfect}) {
    _hitEnergy = perfect ? 1.35 : 0.9;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final double frameDt = dt.clamp(1 / 300, 1 / 20).toDouble();
    _hitEnergy = math.max(0.0, _hitEnergy - frameDt * 6.2);
    if (!movementEnabled || movementBounds.isEmpty) return;

    if (!_pointerActive) {
      final double delta = targetY - position.y;
      if (delta.abs() > 0.05) {
        final double desiredVelocity =
            (delta * response).clamp(-moveSpeed, moveSpeed).toDouble();
        final double maxVelocityChange = acceleration * frameDt;
        verticalVelocity += (desiredVelocity - verticalVelocity)
            .clamp(-maxVelocityChange, maxVelocityChange)
            .toDouble();
        position.y += verticalVelocity * frameDt;
      } else {
        position.y = targetY;
        verticalVelocity *= math.exp(-24 * frameDt);
      }
    } else {
      // Finger events already place the paddle. Only decay measured velocity so
      // a stale swipe cannot keep influencing later ball collisions.
      verticalVelocity *= math.exp(-13 * frameDt);
    }

    final double minY = movementBounds.top;
    final double maxY = movementBounds.bottom - size.y;
    position.y = position.y.clamp(minY, maxY).toDouble();
    _updateMotionEnergy(frameDt: frameDt);
  }

  void _updateMotionEnergy({double frameDt = 1 / 60}) {
    final double targetEnergy =
        (verticalVelocity.abs() / 3600).clamp(0.0, 1.0).toDouble();
    _motionEnergy +=
        (targetEnergy - _motionEnergy) * (1 - math.exp(-20 * frameDt));
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final double ghostDistance = 2.3 + _motionEnergy * 6.0;
    for (int i = 2; i >= 1; i--) {
      canvas.save();
      canvas.translate(-i * ghostDistance, 0);
      _ghostPaint.color = _cyan.withValues(
        alpha: .02 + _motionEnergy * (.05 / i),
      );
      canvas.drawPath(_bodyPath, _ghostPaint);
      canvas.restore();
    }

    _glowPaint
      ..strokeWidth = 6 + _hitEnergy * 2.6
      ..color = _cyan.withValues(alpha: .13 + _hitEnergy * .10);
    canvas.drawPath(_bodyPath, _glowPaint);
    canvas.drawPath(_bodyPath, _bodyPaint);
    canvas.drawPath(_bodyPath, _outlinePaint);

    final Rect energyChannel =
        Rect.fromLTWH(size.x * .20, size.y * .10, size.x * .22, size.y * .80);
    canvas.drawRRect(
      RRect.fromRectAndRadius(energyChannel, Radius.circular(size.x * .12)),
      _whitePaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(size.x * .66, size.y * .5),
          width: size.x * (.48 + _hitEnergy * .08),
          height: size.x * (.48 + _hitEnergy * .08),
        ),
        Radius.circular(size.x),
      ),
      _whitePaint,
    );

    for (final double y in <double>[.16, .84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(size.x * .58, size.y * y),
            width: size.x * .54,
            height: size.x * .14,
          ),
          Radius.circular(size.x * .07),
        ),
        _detailPaint,
      );
    }
  }
}
