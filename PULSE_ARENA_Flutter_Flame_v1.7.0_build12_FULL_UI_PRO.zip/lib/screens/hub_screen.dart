import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../game/config/game_config.dart';
import '../game/managers/audio_manager.dart';
import '../game/managers/scene_transition_manager.dart';
import '../widgets/neon_pressable.dart';

class HubScreen extends StatefulWidget {
  const HubScreen({super.key});

  @override
  State<HubScreen> createState() => _HubScreenState();
}

class _HubScreenState extends State<HubScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ambient;
  int _tabIndex = 2;
  BotDifficulty _difficulty = BotDifficulty.tactical;
  bool _leaving = false;
  OverlayEntry? _toastEntry;

  @override
  void initState() {
    super.initState();
    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
    unawaited(AudioManager.instance.startBgm());
  }

  @override
  void dispose() {
    _toastEntry?.remove();
    _ambient.dispose();
    super.dispose();
  }

  Future<void> _startGame() async {
    if (_leaving) return;
    setState(() => _leaving = true);
    await AudioManager.instance.importantImpact();
    await Future<void>.delayed(const Duration(milliseconds: 100));
    if (!mounted) return;
    await SceneTransitionManager.openGame(
      context,
      config: GameConfig.forDifficulty(_difficulty),
    );
    if (mounted) setState(() => _leaving = false);
  }

  void _showToast(String message) {
    _toastEntry?.remove();
    final OverlayState overlay = Overlay.of(context);
    final OverlayEntry entry = OverlayEntry(
      builder: (BuildContext context) {
        return Positioned(
          left: 42,
          right: 42,
          bottom: MediaQuery.paddingOf(context).bottom + 106,
          child: IgnorePointer(
            child: Material(
              color: Colors.transparent,
              child: _LiftedPanel(
                colors: const <Color>[
                  Color(0xFF2FE5FF),
                  Color(0xFFFF45BA),
                ],
                cut: 15,
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 12,
                ),
                child: Text(
                  message,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
    _toastEntry = entry;
    overlay.insert(entry);
    Future<void>.delayed(const Duration(milliseconds: 1250), () {
      if (_toastEntry == entry) {
        entry.remove();
        _toastEntry = null;
      }
    });
  }

  Future<void> _openSettings() async {
    final BotDifficulty? value = await Navigator.of(context).push<BotDifficulty>(
      PageRouteBuilder<BotDifficulty>(
        transitionDuration: const Duration(milliseconds: 300),
        reverseTransitionDuration: const Duration(milliseconds: 220),
        pageBuilder: (_, Animation<double> animation, __) {
          return FadeTransition(
            opacity: CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
            ),
            child: _SettingsScreen(initialDifficulty: _difficulty),
          );
        },
      ),
    );
    if (value != null && mounted) {
      setState(() => _difficulty = value);
    }
  }

  Widget _pageForIndex(int index) {
    switch (index) {
      case 0:
        return _ProfilePage(
          key: const ValueKey<String>('profile'),
          onMessage: _showToast,
        );
      case 1:
        return _MissionsPage(
          key: const ValueKey<String>('missions'),
          onMessage: _showToast,
        );
      case 3:
        return _RankingPage(
          key: const ValueKey<String>('ranking'),
          onMessage: _showToast,
        );
      case 4:
        return _ShopPage(
          key: const ValueKey<String>('shop'),
          onMessage: _showToast,
        );
      case 2:
      default:
        return _HomePage(
          key: const ValueKey<String>('home'),
          ambient: _ambient,
          onStart: _startGame,
          onOffline: _startGame,
          onSettings: _openSettings,
          onProfile: () => setState(() => _tabIndex = 0),
          onEnergy: () => _showToast('انرژی فعلی: ۲٬۴۵۰'),
          onCredit: () => _showToast('اعتبار فعلی: ۸۶۰'),
          onRanking: () => setState(() => _tabIndex = 3),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_leaving,
      child: Scaffold(
        backgroundColor: const Color(0xFF01030A),
        body: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 250),
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              const RepaintBoundary(
                child: CustomPaint(painter: _HubBackgroundPainter()),
              ),
              SafeArea(
                child: Column(
                  children: <Widget>[
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 240),
                        switchInCurve: Curves.easeOutCubic,
                        switchOutCurve: Curves.easeInCubic,
                        transitionBuilder: (Widget child, Animation<double> a) {
                          return FadeTransition(
                            opacity: a,
                            child: ScaleTransition(
                              scale: Tween<double>(begin: .985, end: 1).animate(a),
                              child: child,
                            ),
                          );
                        },
                        child: _pageForIndex(_tabIndex),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(10, 2, 10, 7),
                      child: _BottomNavigation(
                        activeIndex: _tabIndex,
                        onTap: (int index) {
                          if (_tabIndex == index) return;
                          setState(() => _tabIndex = index);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomePage extends StatelessWidget {
  const _HomePage({
    required this.ambient,
    required this.onStart,
    required this.onOffline,
    required this.onSettings,
    required this.onProfile,
    required this.onEnergy,
    required this.onCredit,
    required this.onRanking,
    super.key,
  });

  final Animation<double> ambient;
  final VoidCallback onStart;
  final VoidCallback onOffline;
  final VoidCallback onSettings;
  final VoidCallback onProfile;
  final VoidCallback onEnergy;
  final VoidCallback onCredit;
  final VoidCallback onRanking;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double scale = constraints.maxWidth / 430;
        final double logicalHeight = constraints.maxHeight / scale;
        return Align(
          alignment: Alignment.topCenter,
          child: FittedBox(
            fit: BoxFit.fitWidth,
            alignment: Alignment.topCenter,
            child: SizedBox(
              width: 430,
              height: logicalHeight,
              child: _HomeStage(
                height: logicalHeight,
                ambient: ambient,
                onStart: onStart,
                onOffline: onOffline,
                onSettings: onSettings,
                onProfile: onProfile,
                onEnergy: onEnergy,
                onCredit: onCredit,
                onRanking: onRanking,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _HomeStage extends StatelessWidget {
  const _HomeStage({
    required this.height,
    required this.ambient,
    required this.onStart,
    required this.onOffline,
    required this.onSettings,
    required this.onProfile,
    required this.onEnergy,
    required this.onCredit,
    required this.onRanking,
  });

  final double height;
  final Animation<double> ambient;
  final VoidCallback onStart;
  final VoidCallback onOffline;
  final VoidCallback onSettings;
  final VoidCallback onProfile;
  final VoidCallback onEnergy;
  final VoidCallback onCredit;
  final VoidCallback onRanking;

  @override
  Widget build(BuildContext context) {
    final double arenaHeight = (height * .37).clamp(270.0, 335.0).toDouble();
    return Padding(
      padding: const EdgeInsets.fromLTRB(11, 8, 11, 6),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          SizedBox(
            height: 69,
            child: Row(
              children: <Widget>[
                SizedBox(
                  width: 194,
                  child: _ProfileCard(onTap: onProfile),
                ),
                const SizedBox(width: 4),
                SizedBox(
                  width: 101,
                  child: _ResourceCard(
                    color: const Color(0xFFFFC62F),
                    value: '2,450',
                    icon: Icons.bolt_rounded,
                    onTap: onEnergy,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: _ResourceCard(
                    color: const Color(0xFFFF47BC),
                    value: '860',
                    icon: Icons.motion_photos_on_rounded,
                    onTap: onCredit,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 76, child: _GameTitle()),
          SizedBox(
            height: arenaHeight,
            child: Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                Positioned.fill(
                  bottom: 17,
                  child: RepaintBoundary(
                    child: AnimatedBuilder(
                      animation: ambient,
                      builder: (_, __) {
                        return CustomPaint(
                          painter: _ArenaPreviewPainter(progress: ambient.value),
                        );
                      },
                    ),
                  ),
                ),
                const Positioned(
                  left: 115,
                  right: 115,
                  bottom: 0,
                  height: 42,
                  child: _PowerStrip(),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 336,
            height: 74,
            child: _PrimaryButton(onTap: onStart),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                width: 160,
                height: 58,
                child: _SecondaryButton(
                  label: 'بازی آفلاین',
                  icon: Icons.gps_fixed_rounded,
                  color: const Color(0xFF32E6FF),
                  onTap: onOffline,
                ),
              ),
              const SizedBox(width: 16),
              SizedBox(
                width: 160,
                height: 58,
                child: _SecondaryButton(
                  label: 'تنظیمات',
                  icon: Icons.settings_rounded,
                  color: const Color(0xFFFF47B8),
                  onTap: onSettings,
                ),
              ),
            ],
          ),
          SizedBox(
            width: 336,
            height: 44,
            child: _SeasonRibbon(onTap: onRanking),
          ),
        ],
      ),
    );
  }
}

class _SeasonRibbon extends StatelessWidget {
  const _SeasonRibbon({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'مشاهده رتبه‌بندی',
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: const <Color>[Color(0xFFFFC832), Color(0xFFFF48BB)],
          cut: 13,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 13),
          child: const Row(
            children: <Widget>[
              Icon(Icons.leaderboard_rounded, color: Color(0xFFFFD451), size: 22),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'لیگ پلاتینیوم  •  رتبه ۵',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              Icon(Icons.chevron_left_rounded, color: Color(0xFFFF4BBB), size: 22),
            ],
          ),
        );
      },
    );
  }
}

class _PageScaffold extends StatelessWidget {
  const _PageScaffold({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
    required this.children,
    super.key,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 16),
      child: Column(
        children: <Widget>[
          _PageHeader(
            title: title,
            subtitle: subtitle,
            icon: icon,
            colors: colors,
          ),
          const SizedBox(height: 14),
          ...children,
        ],
      ),
    );
  }
}

class _ProfilePage extends StatelessWidget {
  const _ProfilePage({required this.onMessage, super.key});

  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      title: 'پروفایل فرمانده',
      subtitle: 'هویت، آمار نبرد و افتخارات شما',
      icon: Icons.person_rounded,
      colors: const <Color>[Color(0xFF2DE7FF), Color(0xFF755BFF)],
      children: <Widget>[
        _LiftedPanel(
          colors: const <Color>[Color(0xFF2CE7FF), Color(0xFFFF48BC)],
          cut: 24,
          padding: const EdgeInsets.all(16),
          child: Row(
            children: <Widget>[
              const SizedBox(
                width: 92,
                height: 92,
                child: CustomPaint(painter: _AvatarPainter()),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    const Text(
                      'شون رنجر',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 23,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    const Text(
                      'فرمانده پالس • سطح ۱۸',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: Color(0xFF48E7FF),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 11),
                    const _NeonProgress(
                      value: .75,
                      label: '۷۵٪ تا سطح ۱۹',
                      colors: <Color>[Color(0xFF2DE5FF), Color(0xFFB95DFF)],
                    ),
                    const SizedBox(height: 12),
                    _GraphicButton(
                      label: 'ویرایش پروفایل',
                      icon: Icons.edit_rounded,
                      colors: const <Color>[
                        Color(0xFF2DE6FF),
                        Color(0xFF7360FF),
                      ],
                      onTap: () => onMessage('ویرایش پروفایل در مرحله اتصال حساب فعال می‌شود'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const Row(
          children: <Widget>[
            Expanded(
              child: _MetricPanel(
                value: '۸۶',
                label: 'پیروزی',
                icon: Icons.emoji_events_rounded,
                color: Color(0xFFFFC832),
              ),
            ),
            SizedBox(width: 9),
            Expanded(
              child: _MetricPanel(
                value: '۱۲۴',
                label: 'مسابقه',
                icon: Icons.sports_esports_rounded,
                color: Color(0xFF39E5FF),
              ),
            ),
            SizedBox(width: 9),
            Expanded(
              child: _MetricPanel(
                value: '۶۹٪',
                label: 'نرخ برد',
                icon: Icons.auto_graph_rounded,
                color: Color(0xFFFF4DB9),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        _SectionTitle(
          title: 'افتخارات اخیر',
          icon: Icons.military_tech_rounded,
          color: const Color(0xFFFFC832),
        ),
        const SizedBox(height: 9),
        _AchievementTile(
          title: 'شکارچی پالس',
          subtitle: '۵۰ پیروزی در نبردهای آفلاین',
          progress: 1,
          icon: Icons.flash_on_rounded,
          color: const Color(0xFFFFC832),
          onTap: () => onMessage('نشان شکارچی پالس دریافت شده است'),
        ),
        const SizedBox(height: 9),
        _AchievementTile(
          title: 'دیوار نفوذناپذیر',
          subtitle: '۳۰ مهار کامل با سپر انرژی',
          progress: .73,
          icon: Icons.shield_rounded,
          color: const Color(0xFF34E5FF),
          onTap: () => onMessage('۲۲ از ۳۰ مهار کامل ثبت شده'),
        ),
        const SizedBox(height: 9),
        _AchievementTile(
          title: 'فرمانروای آرنا',
          subtitle: 'ورود به لیگ الماس',
          progress: .42,
          icon: Icons.workspace_premium_rounded,
          color: const Color(0xFFFF4ABB),
          onTap: () => onMessage('برای لیگ الماس به امتیاز بیشتری نیاز دارید'),
        ),
      ],
    );
  }
}

class _MissionsPage extends StatefulWidget {
  const _MissionsPage({required this.onMessage, super.key});

  final ValueChanged<String> onMessage;

  @override
  State<_MissionsPage> createState() => _MissionsPageState();
}

class _MissionsPageState extends State<_MissionsPage> {
  int _segment = 0;
  final Set<int> _claimed = <int>{};

  @override
  Widget build(BuildContext context) {
    final List<_MissionData> missions = _segment == 0
        ? const <_MissionData>[
            _MissionData('سه نبرد کامل', '۳ مسابقه انجام بده', 3, 3, 120, Icons.sports_esports_rounded),
            _MissionData('پالس دقیق', '۱۰ برخورد متوالی ثبت کن', 8, 10, 80, Icons.track_changes_rounded),
            _MissionData('سپر فعال', '۲ بار از سپر استفاده کن', 1, 2, 60, Icons.shield_rounded),
          ]
        : const <_MissionData>[
            _MissionData('قهرمان هفته', '۲۰ مسابقه را برنده شو', 14, 20, 600, Icons.emoji_events_rounded),
            _MissionData('نبرد طولانی', '۱۰۰ امتیاز در مجموع بگیر', 73, 100, 450, Icons.timeline_rounded),
            _MissionData('استاد تقویت', '۱۵ تقویت موفق اجرا کن', 9, 15, 350, Icons.bolt_rounded),
          ];

    return _PageScaffold(
      title: 'ماموریت‌ها',
      subtitle: 'پاداش‌های روزانه و هفتگی نبرد',
      icon: Icons.track_changes_rounded,
      colors: const <Color>[Color(0xFF825CFF), Color(0xFFFF47BB)],
      children: <Widget>[
        _LiftedPanel(
          colors: const <Color>[Color(0xFF38E5FF), Color(0xFFFF48BB)],
          cut: 22,
          padding: const EdgeInsets.fromLTRB(15, 13, 15, 15),
          child: Column(
            children: <Widget>[
              const Row(
                children: <Widget>[
                  _MetricPanel(
                    value: '۳',
                    label: 'فعال',
                    icon: Icons.bolt_rounded,
                    color: Color(0xFFFFC832),
                    compact: true,
                  ),
                  SizedBox(width: 8),
                  _MetricPanel(
                    value: '۸۶۰',
                    label: 'پاداش امروز',
                    icon: Icons.motion_photos_on_rounded,
                    color: Color(0xFFFF4BBB),
                    compact: true,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _SegmentButton(
                      label: 'روزانه',
                      selected: _segment == 0,
                      color: const Color(0xFF38E5FF),
                      onTap: () => setState(() => _segment = 0),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _SegmentButton(
                      label: 'هفتگی',
                      selected: _segment == 1,
                      color: const Color(0xFFFF4BBB),
                      onTap: () => setState(() => _segment = 1),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 13),
        for (int i = 0; i < missions.length; i++) ...<Widget>[
          _MissionTile(
            data: missions[i],
            claimed: _claimed.contains(i),
            onTap: () {
              final bool completed = missions[i].current >= missions[i].target;
              if (!completed) {
                widget.onMessage('این ماموریت هنوز کامل نشده است');
                return;
              }
              if (_claimed.contains(i)) {
                widget.onMessage('پاداش این ماموریت قبلاً دریافت شده');
                return;
              }
              setState(() => _claimed.add(i));
              widget.onMessage('${missions[i].reward} پالس دریافت شد');
            },
          ),
          if (i != missions.length - 1) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _RankingPage extends StatelessWidget {
  const _RankingPage({required this.onMessage, super.key});

  final ValueChanged<String> onMessage;

  @override
  Widget build(BuildContext context) {
    const List<_RankData> players = <_RankData>[
      _RankData(1, 'NOVA-X', 4820, Color(0xFFFFC832)),
      _RankData(2, 'PulseQueen', 4665, Color(0xFFC9D6EF)),
      _RankData(3, 'ShadowArc', 4510, Color(0xFFFF9A62)),
      _RankData(4, 'NeonWolf', 4280, Color(0xFF45E7FF)),
      _RankData(5, 'شون رنجر', 4125, Color(0xFFFF4BBB)),
      _RankData(6, 'VoltMaster', 3990, Color(0xFF8B74FF)),
      _RankData(7, 'ArenaGhost', 3845, Color(0xFF5E6D91)),
    ];

    return _PageScaffold(
      title: 'رتبه‌بندی جهانی',
      subtitle: 'جایگاه شما میان فرماندهان آرنا',
      icon: Icons.leaderboard_rounded,
      colors: const <Color>[Color(0xFFFFC832), Color(0xFFFF47BA)],
      children: <Widget>[
        _LiftedPanel(
          colors: const <Color>[Color(0xFFFFC832), Color(0xFFFF47BA)],
          cut: 24,
          padding: const EdgeInsets.all(15),
          child: Column(
            children: <Widget>[
              const Row(
                children: <Widget>[
                  SizedBox(
                    width: 76,
                    height: 76,
                    child: CustomPaint(painter: _LeagueEmblemPainter()),
                  ),
                  SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          'لیگ پلاتینیوم',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'رتبه فعلی: ۵',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: Color(0xFFFFD45A),
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 10),
                        _NeonProgress(
                          value: .62,
                          label: '۳۷۵ امتیاز تا لیگ الماس',
                          colors: <Color>[Color(0xFFFFC832), Color(0xFFFF4BBB)],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _GraphicButton(
                label: 'جوایز فصل',
                icon: Icons.card_giftcard_rounded,
                colors: const <Color>[Color(0xFFFFC832), Color(0xFFFF4BBB)],
                onTap: () => onMessage('جوایز فصل در پایان دوره فعال می‌شوند'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const _Podium(),
        const SizedBox(height: 14),
        _SectionTitle(
          title: 'برترین بازیکنان',
          icon: Icons.format_list_numbered_rounded,
          color: const Color(0xFFFFC832),
        ),
        const SizedBox(height: 9),
        for (final _RankData player in players) ...<Widget>[
          _RankingRow(
            data: player,
            isCurrentUser: player.name == 'شون رنجر',
            onTap: () => onMessage('${player.name} — ${player.score} امتیاز'),
          ),
          const SizedBox(height: 8),
        ],
      ],
    );
  }
}

class _ShopPage extends StatefulWidget {
  const _ShopPage({required this.onMessage, super.key});

  final ValueChanged<String> onMessage;

  @override
  State<_ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<_ShopPage> {
  int _category = 0;
  int _selectedItem = 0;

  @override
  Widget build(BuildContext context) {
    const List<String> categories = <String>['راکت‌ها', 'توپ‌ها', 'افکت‌ها'];
    final List<_ShopItemData> items = _category == 0
        ? const <_ShopItemData>[
            _ShopItemData('راکت نوا', 650, Color(0xFF35E6FF), Icons.view_stream_rounded),
            _ShopItemData('راکت فانتوم', 820, Color(0xFFFF49BA), Icons.blur_linear_rounded),
            _ShopItemData('راکت تایتان', 1100, Color(0xFFFFC832), Icons.vertical_align_center_rounded),
            _ShopItemData('راکت کریستال', 1350, Color(0xFF9B68FF), Icons.diamond_rounded),
          ]
        : _category == 1
            ? const <_ShopItemData>[
                _ShopItemData('گوی پلاسما', 540, Color(0xFF37E7FF), Icons.circle_rounded),
                _ShopItemData('گوی خورشیدی', 760, Color(0xFFFFC832), Icons.wb_sunny_rounded),
                _ShopItemData('گوی سایه', 940, Color(0xFF8C6CFF), Icons.blur_circular_rounded),
                _ShopItemData('گوی کوانتوم', 1250, Color(0xFFFF48BA), Icons.motion_photos_on_rounded),
              ]
            : const <_ShopItemData>[
                _ShopItemData('رد پالس', 430, Color(0xFF35E6FF), Icons.timeline_rounded),
                _ShopItemData('انفجار نئون', 690, Color(0xFFFF49BA), Icons.auto_awesome_rounded),
                _ShopItemData('موج طلایی', 880, Color(0xFFFFC832), Icons.waves_rounded),
                _ShopItemData('شکاف فضایی', 1180, Color(0xFF9B68FF), Icons.blur_on_rounded),
              ];

    return _PageScaffold(
      title: 'فروشگاه آرنا',
      subtitle: 'ظاهر میدان و تجهیزات نبرد را ارتقا بده',
      icon: Icons.shopping_cart_rounded,
      colors: const <Color>[Color(0xFFFF47BA), Color(0xFF8B66FF)],
      children: <Widget>[
        const Row(
          children: <Widget>[
            Expanded(
              child: _CurrencyPanel(
                value: '2,450',
                label: 'انرژی',
                icon: Icons.bolt_rounded,
                color: Color(0xFFFFC832),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _CurrencyPanel(
                value: '860',
                label: 'پالس',
                icon: Icons.motion_photos_on_rounded,
                color: Color(0xFFFF48BB),
              ),
            ),
          ],
        ),
        const SizedBox(height: 13),
        _LiftedPanel(
          colors: const <Color>[Color(0xFF2DE6FF), Color(0xFFFF49BA)],
          cut: 22,
          padding: const EdgeInsets.all(13),
          child: Row(
            children: <Widget>[
              const SizedBox(
                width: 104,
                height: 104,
                child: CustomPaint(painter: _FeaturedItemPainter()),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    const Text(
                      'بسته نئون دوگانه',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'راکت، توپ و افکت برخورد هماهنگ',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: Color(0xFF9EACC4),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _GraphicButton(
                      label: '۱٬۶۵۰ پالس',
                      icon: Icons.shopping_bag_rounded,
                      colors: const <Color>[Color(0xFF2DE6FF), Color(0xFFFF49BA)],
                      onTap: () => widget.onMessage('برای خرید این بسته پالس کافی نیست'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 13),
        Row(
          children: <Widget>[
            for (int i = 0; i < categories.length; i++) ...<Widget>[
              Expanded(
                child: _SegmentButton(
                  label: categories[i],
                  selected: _category == i,
                  color: i == 0
                      ? const Color(0xFF35E6FF)
                      : i == 1
                          ? const Color(0xFFFF49BA)
                          : const Color(0xFF9C6BFF),
                  onTap: () {
                    setState(() {
                      _category = i;
                      _selectedItem = 0;
                    });
                  },
                ),
              ),
              if (i != categories.length - 1) const SizedBox(width: 7),
            ],
          ],
        ),
        const SizedBox(height: 13),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: .88,
          ),
          itemBuilder: (BuildContext context, int index) {
            return _ShopItem(
              data: items[index],
              selected: _selectedItem == index,
              onTap: () => setState(() => _selectedItem = index),
              onBuy: () => widget.onMessage('${items[index].title} به سبد انتخاب اضافه شد'),
            );
          },
        ),
      ],
    );
  }
}

class _SettingsScreen extends StatefulWidget {
  const _SettingsScreen({required this.initialDifficulty});

  final BotDifficulty initialDifficulty;

  @override
  State<_SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<_SettingsScreen> {
  late BotDifficulty _difficulty;

  @override
  void initState() {
    super.initState();
    _difficulty = widget.initialDifficulty;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF01030A),
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const CustomPaint(painter: _HubBackgroundPainter()),
          SafeArea(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
                  child: _LiftedPanel(
                    colors: const <Color>[Color(0xFF2DE6FF), Color(0xFFFF47BA)],
                    cut: 20,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    child: Row(
                      children: <Widget>[
                        _MiniIconButton(
                          icon: Icons.arrow_back_rounded,
                          color: const Color(0xFF39E6FF),
                          onTap: () => Navigator.of(context).pop(_difficulty),
                        ),
                        const Expanded(
                          child: Column(
                            children: <Widget>[
                              Text(
                                'تنظیمات',
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 21,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              Text(
                                'کنترل تجربه و سطح مسابقه',
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  color: Color(0xFF91A2BD),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(14, 8, 14, 18),
                    child: Column(
                      children: <Widget>[
                        _SectionTitle(
                          title: 'سطح ربات',
                          icon: Icons.smart_toy_rounded,
                          color: const Color(0xFF38E5FF),
                        ),
                        const SizedBox(height: 10),
                        for (final BotDifficulty value in BotDifficulty.values) ...<Widget>[
                          _DifficultyTile(
                            value: value,
                            selected: value == _difficulty,
                            onTap: () => setState(() => _difficulty = value),
                          ),
                          const SizedBox(height: 9),
                        ],
                        const SizedBox(height: 5),
                        _SectionTitle(
                          title: 'صدا و بازخورد',
                          icon: Icons.tune_rounded,
                          color: const Color(0xFFFF4ABB),
                        ),
                        const SizedBox(height: 10),
                        _SettingToggleTile(
                          icon: Icons.volume_up_rounded,
                          label: 'صدای بازی',
                          subtitle: 'موسیقی، برخورد و اعلام نتیجه',
                          enabled: AudioManager.instance.soundEnabled,
                          color: const Color(0xFF38E5FF),
                          onTap: () async {
                            await AudioManager.instance.setSoundEnabled(
                              !AudioManager.instance.soundEnabled,
                            );
                            if (mounted) setState(() {});
                          },
                        ),
                        const SizedBox(height: 9),
                        _SettingToggleTile(
                          icon: Icons.vibration_rounded,
                          label: 'بازخورد لرزشی',
                          subtitle: 'لرزش کوتاه هنگام برخورد و لمس',
                          enabled: AudioManager.instance.vibrationEnabled,
                          color: const Color(0xFFFF4ABB),
                          onTap: () {
                            AudioManager.instance.vibrationEnabled =
                                !AudioManager.instance.vibrationEnabled;
                            setState(() {});
                          },
                        ),
                        const SizedBox(height: 14),
                        _LiftedPanel(
                          colors: const <Color>[Color(0xFFFFC832), Color(0xFFFF4ABB)],
                          cut: 20,
                          padding: const EdgeInsets.all(14),
                          child: const Row(
                            children: <Widget>[
                              Icon(Icons.info_rounded, color: Color(0xFFFFD34E), size: 30),
                              SizedBox(width: 11),
                              Expanded(
                                child: Text(
                                  'قانون مسابقه: هر بازیکنی که زودتر ۱۰ گل دریافت کند، بازنده است.',
                                  textDirection: TextDirection.rtl,
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                    color: Color(0xFFE6ECF8),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        _GraphicButton(
                          label: 'ذخیره و بازگشت',
                          icon: Icons.check_circle_rounded,
                          colors: const <Color>[Color(0xFF2DE6FF), Color(0xFFFF47BA)],
                          tall: true,
                          onTap: () => Navigator.of(context).pop(_difficulty),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation({required this.activeIndex, required this.onTap});

  final int activeIndex;
  final ValueChanged<int> onTap;

  static const List<_NavData> _items = <_NavData>[
    _NavData(Icons.person_outline_rounded, 'پروفایل'),
    _NavData(Icons.track_changes_rounded, 'ماموریت‌ها', badge: true),
    _NavData(Icons.home_rounded, 'خانه'),
    _NavData(Icons.leaderboard_rounded, 'رتبه‌بندی'),
    _NavData(Icons.shopping_cart_outlined, 'فروشگاه'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: Stack(
        clipBehavior: Clip.none,
        children: <Widget>[
          Positioned.fill(
            top: 12,
            child: _LiftedPanel(
              colors: const <Color>[Color(0xFF2FE5FF), Color(0xFFFF48BB)],
              cut: 18,
              padding: const EdgeInsets.fromLTRB(5, 9, 5, 5),
              child: Row(
                children: <Widget>[
                  for (int i = 0; i < _items.length; i++)
                    Expanded(
                      child: i == 2
                          ? const SizedBox.shrink()
                          : _NavItem(
                              index: i,
                              data: _items[i],
                              active: activeIndex == i,
                              onTap: onTap,
                            ),
                    ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: Center(
              child: _HomeNavItem(
                active: activeIndex == 2,
                onTap: () => onTap(2),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.index,
    required this.data,
    required this.active,
    required this.onTap,
  });

  final int index;
  final _NavData data;
  final bool active;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = active
        ? (index < 2 ? const Color(0xFF42E8FF) : const Color(0xFFFF50BD))
        : const Color(0xFF7F8BAE);
    return NeonPressable(
      semanticLabel: data.label,
      pressedScale: .90,
      onTap: () => onTap(index),
      builder: (_, bool pressed) {
        return CustomPaint(
          painter: _NavCellPainter(
            color: color,
            active: active,
            pressed: pressed,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  Icon(
                    data.icon,
                    color: color,
                    size: 25,
                    shadows: active
                        ? <Shadow>[Shadow(color: color, blurRadius: 12)]
                        : null,
                  ),
                  if (data.badge)
                    const Positioned(
                      right: -5,
                      top: -3,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Color(0xFFFF3C96),
                          shape: BoxShape.circle,
                          boxShadow: <BoxShadow>[
                            BoxShadow(color: Color(0xAAFF3C96), blurRadius: 7),
                          ],
                        ),
                        child: SizedBox(width: 7, height: 7),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                data.label,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                style: TextStyle(
                  color: color,
                  fontSize: 9.5,
                  fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HomeNavItem extends StatelessWidget {
  const _HomeNavItem({required this.active, required this.onTap});

  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 78,
      height: 78,
      child: NeonPressable(
        semanticLabel: 'خانه',
        pressedScale: .90,
        onTap: onTap,
        builder: (_, bool pressed) {
          return CustomPaint(
            painter: _HomeNavPainter(active: active, pressed: pressed),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  Icons.home_rounded,
                  size: 32,
                  color: active ? Colors.white : const Color(0xFF99A5C5),
                  shadows: active
                      ? const <Shadow>[
                          Shadow(color: Color(0xFF35E7FF), blurRadius: 14),
                          Shadow(color: Color(0xFFFF49BA), blurRadius: 18),
                        ]
                      : null,
                ),
                const SizedBox(height: 2),
                Text(
                  'خانه',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: active ? Colors.white : const Color(0xFF99A5C5),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _PageHeader extends StatelessWidget {
  const _PageHeader({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;

  @override
  Widget build(BuildContext context) {
    return _LiftedPanel(
      colors: colors,
      cut: 22,
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
      child: Row(
        children: <Widget>[
          _IconCore(icon: icon, color: colors.first, size: 50),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: Color(0xFF96A5BE),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileCard extends StatelessWidget {
  const _ProfileCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'پروفایل بازیکن',
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: const <Color>[Color(0xFF31E7FF), Color(0xFF0B7EC9)],
          cut: 15,
          pressed: pressed,
          padding: const EdgeInsets.fromLTRB(9, 7, 10, 7),
          child: Row(
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  const SizedBox(
                    width: 55,
                    height: 55,
                    child: CustomPaint(painter: _AvatarPainter()),
                  ),
                  Positioned(
                    right: -2,
                    bottom: -2,
                    child: _LevelBadge(level: '18'),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      'شون رنجر',
                      textDirection: TextDirection.rtl,
                      maxLines: 1,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 1),
                    Text(
                      'سطح 18',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: Color(0xFF37E4FF),
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 4),
                    _NeonProgress(
                      value: .75,
                      label: '75%',
                      colors: <Color>[Color(0xFF2FE4FF), Color(0xFF72F2FF)],
                      compact: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ResourceCard extends StatelessWidget {
  const _ResourceCard({
    required this.color,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  final Color color;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: value,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: <Color>[color, color.withValues(alpha: .65)],
          cut: 14,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
          child: Row(
            children: <Widget>[
              _IconCore(icon: icon, color: color, size: 28),
              const SizedBox(width: 5),
              Expanded(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    value,
                    maxLines: 1,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
              Icon(Icons.add_rounded, color: color, size: 17),
            ],
          ),
        );
      },
    );
  }
}

class _GameTitle extends StatelessWidget {
  const _GameTitle();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ShaderMask(
          shaderCallback: (Rect rect) {
            return const LinearGradient(
              colors: <Color>[
                Color(0xFF47E8FF),
                Color(0xFFEAFDFF),
                Color(0xFFB673FF),
                Color(0xFFFF4BBC),
              ],
              stops: <double>[0, .39, .62, 1],
            ).createShader(rect);
          },
          child: const Text(
            'PULSE ARENA',
            maxLines: 1,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 42,
              letterSpacing: 1.4,
              fontWeight: FontWeight.w900,
              shadows: <Shadow>[
                Shadow(color: Color(0xAA2DE7FF), blurRadius: 18),
                Shadow(color: Color(0x88FF47B8), blurRadius: 22),
              ],
            ),
          ),
        ),
        const SizedBox(height: 1),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _LightLine(color: const Color(0xFF37E7FF)),
            const SizedBox(width: 12),
            const Text(
              'نبرد پالس‌ها',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                color: Colors.white,
                fontSize: 19,
                fontWeight: FontWeight.w900,
                shadows: <Shadow>[
                  Shadow(color: Color(0xAA3CE6FF), blurRadius: 11),
                  Shadow(color: Color(0xAAFF4ABB), blurRadius: 12),
                ],
              ),
            ),
            const SizedBox(width: 12),
            _LightLine(color: const Color(0xFFFF4ABB), reverse: true),
          ],
        ),
      ],
    );
  }
}

class _LightLine extends StatelessWidget {
  const _LightLine({required this.color, this.reverse = false});

  final Color color;
  final bool reverse;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 61,
      height: 2,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: reverse
              ? <Color>[color, Colors.transparent]
              : <Color>[Colors.transparent, color],
        ),
        boxShadow: <BoxShadow>[BoxShadow(color: color, blurRadius: 6)],
      ),
    );
  }
}

class _PowerStrip extends StatelessWidget {
  const _PowerStrip();

  @override
  Widget build(BuildContext context) {
    return _LiftedPanel(
      colors: const <Color>[Color(0xFF2FE5FF), Color(0xFFFF49BC)],
      cut: 11,
      padding: const EdgeInsets.symmetric(horizontal: 11),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _PowerItem(Icons.shield_rounded, 'x2', Color(0xFF41E6FF)),
          _PowerDivider(),
          _PowerItem(Icons.bolt_rounded, 'x1', Color(0xFFFFC832)),
          _PowerDivider(),
          _PowerItem(Icons.graphic_eq_rounded, 'x2', Color(0xFFFF53C4)),
        ],
      ),
    );
  }
}

class _PowerItem extends StatelessWidget {
  const _PowerItem(this.icon, this.value, this.color);

  final IconData icon;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(
          value,
          style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900),
        ),
      ],
    );
  }
}

class _PowerDivider extends StatelessWidget {
  const _PowerDivider();

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 21, color: const Color(0x554D5C78));
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: 'شروع بازی',
      pressedScale: .95,
      onTap: onTap,
      builder: (_, bool pressed) {
        return CustomPaint(
          painter: _ActionButtonPainter(
            pressed: pressed,
            cyan: const Color(0xFF2BE4FF),
            magenta: const Color(0xFFFF46BB),
            strong: true,
          ),
          child: const Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(Icons.keyboard_double_arrow_right_rounded, color: Color(0x8838E7FF), size: 28),
                SizedBox(width: 17),
                Text(
                  'شروع بازی',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 31,
                    fontWeight: FontWeight.w900,
                    shadows: <Shadow>[
                      Shadow(color: Color(0xCCFFFFFF), blurRadius: 8),
                      Shadow(color: Color(0xAA8B5CFF), blurRadius: 16),
                    ],
                  ),
                ),
                SizedBox(width: 17),
                Icon(Icons.keyboard_double_arrow_left_rounded, color: Color(0x88FF45B9), size: 28),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  const _SecondaryButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: <Color>[color, color.withValues(alpha: .7)],
          cut: 15,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 11),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: color, size: 27),
              const SizedBox(width: 9),
              Flexible(
                child: Text(
                  label,
                  textDirection: TextDirection.rtl,
                  maxLines: 1,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _GraphicButton extends StatelessWidget {
  const _GraphicButton({
    required this.label,
    required this.icon,
    required this.colors,
    required this.onTap,
    this.tall = false,
  });

  final String label;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback onTap;
  final bool tall;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: tall ? 62 : 46,
      child: NeonPressable(
        semanticLabel: label,
        onTap: onTap,
        builder: (_, bool pressed) {
          return _LiftedPanel(
            colors: colors,
            cut: tall ? 18 : 13,
            pressed: pressed,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, color: colors.first, size: tall ? 26 : 21),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    label,
                    textDirection: TextDirection.rtl,
                    maxLines: 1,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: tall ? 18 : 13,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _SegmentButton extends StatelessWidget {
  const _SegmentButton({
    required this.label,
    required this.selected,
    required this.color,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 45,
      child: NeonPressable(
        semanticLabel: label,
        onTap: onTap,
        builder: (_, bool pressed) {
          return _LiftedPanel(
            colors: <Color>[
              color,
              selected ? color : const Color(0xFF4A5874),
            ],
            cut: 12,
            pressed: pressed,
            intensity: selected ? 1 : .48,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Center(
              child: Text(
                label,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                style: TextStyle(
                  color: selected ? Colors.white : const Color(0xFFA2AEC2),
                  fontSize: 12.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _MetricPanel extends StatelessWidget {
  const _MetricPanel({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
    this.compact = false,
  });

  final String value;
  final String label;
  final IconData icon;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final Widget content = _LiftedPanel(
      colors: <Color>[color, color.withValues(alpha: .55)],
      cut: 15,
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 10 : 8,
        vertical: compact ? 9 : 11,
      ),
      child: compact
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(icon, color: color, size: 23),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(value, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                    Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9DABC1), fontSize: 10, fontWeight: FontWeight.w700)),
                  ],
                ),
              ],
            )
          : Column(
              children: <Widget>[
                Icon(icon, color: color, size: 27),
                const SizedBox(height: 5),
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9DABC1), fontSize: 10.5, fontWeight: FontWeight.w700)),
              ],
            ),
    );
    return compact ? Expanded(child: content) : content;
  }
}

class _CurrencyPanel extends StatelessWidget {
  const _CurrencyPanel({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });

  final String value;
  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return _LiftedPanel(
      colors: <Color>[color, color.withValues(alpha: .55)],
      cut: 18,
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      child: Row(
        children: <Widget>[
          _IconCore(icon: icon, color: color, size: 40),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9FAEC4), fontSize: 11, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          Icon(Icons.add_circle_outline_rounded, color: color, size: 22),
        ],
      ),
    );
  }
}

class _AchievementTile extends StatelessWidget {
  const _AchievementTile({
    required this.title,
    required this.subtitle,
    required this.progress,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final double progress;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: title,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: <Color>[color, color.withValues(alpha: .55)],
          cut: 18,
          pressed: pressed,
          padding: const EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              _IconCore(icon: icon, color: color, size: 50),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(title, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 2),
                    Text(subtitle, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF97A6BD), fontSize: 10.5, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    _NeonProgress(
                      value: progress,
                      label: '${(progress * 100).round()}٪',
                      colors: <Color>[color, color.withValues(alpha: .65)],
                      compact: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MissionTile extends StatelessWidget {
  const _MissionTile({
    required this.data,
    required this.claimed,
    required this.onTap,
  });

  final _MissionData data;
  final bool claimed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool completed = data.current >= data.target;
    final Color color = completed ? const Color(0xFFFFC832) : const Color(0xFF42E7FF);
    return _LiftedPanel(
      colors: <Color>[color, const Color(0xFFFF48BB)],
      cut: 19,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: <Widget>[
          _IconCore(icon: data.icon, color: color, size: 55),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(data.title, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                Text(data.subtitle, textDirection: TextDirection.rtl, style: const TextStyle(color: Color(0xFF9AA9C0), fontSize: 10.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                _NeonProgress(
                  value: data.current / data.target,
                  label: '${data.current}/${data.target}',
                  colors: <Color>[color, const Color(0xFFFF48BB)],
                  compact: true,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 78,
            child: _GraphicButton(
              label: claimed ? 'دریافت شد' : '${data.reward}',
              icon: claimed ? Icons.check_rounded : Icons.card_giftcard_rounded,
              colors: <Color>[color, const Color(0xFFFF48BB)],
              onTap: onTap,
            ),
          ),
        ],
      ),
    );
  }
}

class _RankingRow extends StatelessWidget {
  const _RankingRow({
    required this.data,
    required this.isCurrentUser,
    required this.onTap,
  });

  final _RankData data;
  final bool isCurrentUser;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: data.name,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: isCurrentUser
              ? const <Color>[Color(0xFF2FE5FF), Color(0xFFFF49BC)]
              : <Color>[data.color, data.color.withValues(alpha: .45)],
          cut: 16,
          intensity: isCurrentUser ? 1 : .55,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          child: Row(
            children: <Widget>[
              SizedBox(
                width: 35,
                child: Text(
                  '${data.rank}',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: data.color, fontSize: 18, fontWeight: FontWeight.w900),
                ),
              ),
              const SizedBox(width: 8),
              _IconCore(icon: Icons.person_rounded, color: data.color, size: 38),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  data.name,
                  maxLines: 1,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(color: isCurrentUser ? Colors.white : const Color(0xFFD5DCEC), fontSize: 14, fontWeight: FontWeight.w900),
                ),
              ),
              Text(
                '${data.score}',
                style: TextStyle(color: data.color, fontSize: 14, fontWeight: FontWeight.w900),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Podium extends StatelessWidget {
  const _Podium();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 175,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: <Widget>[
          Positioned(
            left: 8,
            bottom: 0,
            width: 112,
            height: 119,
            child: _PodiumPlayer(
              rank: 2,
              name: 'PulseQueen',
              score: '4665',
              color: const Color(0xFFC9D6EF),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Center(
              child: SizedBox(
                width: 126,
                height: 164,
                child: _PodiumPlayer(
                  rank: 1,
                  name: 'NOVA-X',
                  score: '4820',
                  color: const Color(0xFFFFC832),
                ),
              ),
            ),
          ),
          Positioned(
            right: 8,
            bottom: 0,
            width: 112,
            height: 106,
            child: _PodiumPlayer(
              rank: 3,
              name: 'ShadowArc',
              score: '4510',
              color: const Color(0xFFFF9A62),
            ),
          ),
        ],
      ),
    );
  }
}

class _PodiumPlayer extends StatelessWidget {
  const _PodiumPlayer({
    required this.rank,
    required this.name,
    required this.score,
    required this.color,
  });

  final int rank;
  final String name;
  final String score;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return _LiftedPanel(
      colors: <Color>[color, color.withValues(alpha: .55)],
      cut: 17,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(
            rank == 1 ? Icons.emoji_events_rounded : Icons.military_tech_rounded,
            color: color,
            size: rank == 1 ? 40 : 31,
            shadows: <Shadow>[Shadow(color: color, blurRadius: 14)],
          ),
          Text('#$rank', style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(name, maxLines: 1, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(height: 2),
          Text(score, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _ShopItem extends StatelessWidget {
  const _ShopItem({
    required this.data,
    required this.selected,
    required this.onTap,
    required this.onBuy,
  });

  final _ShopItemData data;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onBuy;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: data.title,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: <Color>[data.color, selected ? const Color(0xFFFF48BB) : data.color.withValues(alpha: .42)],
          cut: 18,
          intensity: selected ? 1 : .58,
          pressed: pressed,
          padding: const EdgeInsets.all(9),
          child: Column(
            children: <Widget>[
              Expanded(
                child: Center(
                  child: SizedBox(
                    width: 74,
                    height: 74,
                    child: CustomPaint(
                      painter: _ShopIconPainter(color: data.color, icon: data.icon),
                    ),
                  ),
                ),
              ),
              Text(
                data.title,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              SizedBox(
                width: double.infinity,
                child: _GraphicButton(
                  label: '${data.price}',
                  icon: Icons.motion_photos_on_rounded,
                  colors: <Color>[data.color, const Color(0xFFFF48BB)],
                  onTap: onBuy,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _DifficultyTile extends StatelessWidget {
  const _DifficultyTile({
    required this.value,
    required this.selected,
    required this.onTap,
  });

  final BotDifficulty value;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color color = selected ? const Color(0xFF3DE7FF) : const Color(0xFF687897);
    return NeonPressable(
      semanticLabel: value.title,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: <Color>[color, selected ? const Color(0xFFFF48BB) : color.withValues(alpha: .45)],
          cut: 18,
          intensity: selected ? 1 : .5,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
          child: Row(
            children: <Widget>[
              _IconCore(
                icon: selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                color: color,
                size: 43,
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(value.title, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    Text(value.description, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF98A7BD), fontSize: 10.5, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SettingToggleTile extends StatelessWidget {
  const _SettingToggleTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.enabled,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final String subtitle;
  final bool enabled;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return NeonPressable(
      semanticLabel: label,
      onTap: onTap,
      builder: (_, bool pressed) {
        return _LiftedPanel(
          colors: <Color>[color, enabled ? const Color(0xFFFF48BB) : color.withValues(alpha: .4)],
          cut: 18,
          intensity: enabled ? 1 : .5,
          pressed: pressed,
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
          child: Row(
            children: <Widget>[
              _IconCore(icon: icon, color: color, size: 45),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(label, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    Text(subtitle, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF96A5BB), fontSize: 10.5, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              _CustomToggle(enabled: enabled, color: color),
            ],
          ),
        );
      },
    );
  }
}

class _CustomToggle extends StatelessWidget {
  const _CustomToggle({required this.enabled, required this.color});

  final bool enabled;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 170),
      width: 50,
      height: 28,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: enabled ? color : const Color(0xFF56637E), width: 1.2),
        gradient: LinearGradient(
          colors: enabled
              ? <Color>[color.withValues(alpha: .42), const Color(0x55382558)]
              : const <Color>[Color(0xFF101827), Color(0xFF080D18)],
        ),
        boxShadow: enabled ? <BoxShadow>[BoxShadow(color: color.withValues(alpha: .45), blurRadius: 10)] : null,
      ),
      child: AnimatedAlign(
        duration: const Duration(milliseconds: 170),
        curve: Curves.easeOutCubic,
        alignment: enabled ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: enabled ? color : const Color(0xFF71809C),
            boxShadow: enabled ? <BoxShadow>[BoxShadow(color: color, blurRadius: 8)] : null,
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.icon, required this.color});

  final String title;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        Expanded(
          child: Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: <Color>[Colors.transparent, color.withValues(alpha: .75)]),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          textDirection: TextDirection.rtl,
          style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900),
        ),
        const SizedBox(width: 7),
        Icon(icon, color: color, size: 23, shadows: <Shadow>[Shadow(color: color, blurRadius: 10)]),
      ],
    );
  }
}

class _IconCore extends StatelessWidget {
  const _IconCore({required this.icon, required this.color, required this.size});

  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _IconCorePainter(color: color),
        child: Icon(icon, color: color, size: size * .5),
      ),
    );
  }
}

class _LevelBadge extends StatelessWidget {
  const _LevelBadge({required this.level});

  final String level;

  @override
  Widget build(BuildContext context) {
    return _LiftedPanel(
      colors: const <Color>[Color(0xFF31E7FF), Color(0xFF755BFF)],
      cut: 6,
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
      child: Text(
        level,
        style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _NeonProgress extends StatelessWidget {
  const _NeonProgress({
    required this.value,
    required this.label,
    required this.colors,
    this.compact = false,
  });

  final double value;
  final String label;
  final List<Color> colors;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: SizedBox(
            height: compact ? 5 : 7,
            child: CustomPaint(
              painter: _ProgressPainter(value: value, colors: colors),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          textDirection: TextDirection.rtl,
          style: TextStyle(
            color: const Color(0xFFEAF7FF),
            fontSize: compact ? 9 : 10.5,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

class _MiniIconButton extends StatelessWidget {
  const _MiniIconButton({required this.icon, required this.color, required this.onTap});

  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 46,
      height: 46,
      child: NeonPressable(
        semanticLabel: 'بازگشت',
        onTap: onTap,
        builder: (_, bool pressed) {
          return _LiftedPanel(
            colors: <Color>[color, color.withValues(alpha: .55)],
            cut: 12,
            pressed: pressed,
            child: Icon(icon, color: color, size: 25),
          );
        },
      ),
    );
  }
}

class _LiftedPanel extends StatelessWidget {
  const _LiftedPanel({
    required this.colors,
    required this.child,
    this.cut = 18,
    this.padding = EdgeInsets.zero,
    this.pressed = false,
    this.intensity = 1,
  });

  final List<Color> colors;
  final Widget child;
  final double cut;
  final EdgeInsetsGeometry padding;
  final bool pressed;
  final double intensity;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _LiftedPanelPainter(
        colors: colors,
        cut: cut,
        pressed: pressed,
        intensity: intensity,
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}

class _LiftedPanelPainter extends CustomPainter {
  const _LiftedPanelPainter({
    required this.colors,
    required this.cut,
    required this.pressed,
    required this.intensity,
  });

  final List<Color> colors;
  final double cut;
  final bool pressed;
  final double intensity;

  Path _shape(Size size, double inset) {
    final double c = math.max(4.0, cut - inset * .45);
    final double l = inset;
    final double t = inset;
    final double r = size.width - inset;
    final double b = size.height - inset;
    return Path()
      ..moveTo(l + c, t)
      ..lineTo(r - c, t)
      ..lineTo(r, t + c)
      ..lineTo(r, b - c)
      ..lineTo(r - c, b)
      ..lineTo(l + c, b)
      ..lineTo(l, b - c)
      ..lineTo(l, t + c)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final Rect rect = Offset.zero & size;
    final Path outer = _shape(size, 2.2);
    final Path bevel = _shape(size, 5.5);
    final Path inner = _shape(size, 8.2);
    final Color left = colors.first;
    final Color right = colors.length > 1 ? colors.last : colors.first;
    final double press = pressed ? .62 : 1;
    final double glow = intensity * press;

    canvas.save();
    canvas.translate(0, pressed ? 1.5 : 3.5);
    canvas.drawPath(
      outer,
      Paint()
        ..color = Colors.black.withValues(alpha: pressed ? .32 : .72)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
    );
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 12
        ..shader = LinearGradient(
          colors: <Color>[
            left.withValues(alpha: .26 * glow),
            right.withValues(alpha: .26 * glow),
          ],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
    );

    canvas.drawPath(
      outer,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            const Color(0xFF172740),
            Color.lerp(const Color(0xFF0A1222), left, .045)!,
            const Color(0xFF070B16),
            Color.lerp(const Color(0xFF060A14), right, .06)!,
          ],
          stops: const <double>[0, .38, .68, 1],
        ).createShader(rect),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height * .46),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Colors.white.withValues(alpha: pressed ? .018 : .085),
            Colors.transparent,
          ],
        ).createShader(rect),
    );
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            left.withValues(alpha: .07 * intensity),
            Colors.transparent,
            right.withValues(alpha: .07 * intensity),
          ],
        ).createShader(rect),
    );
    final Paint scan = Paint()
      ..color = Colors.white.withValues(alpha: .018)
      ..strokeWidth = .6;
    for (double y = 12; y < size.height; y += 9) {
      canvas.drawLine(Offset(8, y), Offset(size.width - 8, y), scan);
    }
    canvas.restore();

    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..shader = LinearGradient(
          colors: <Color>[left, const Color(0xFF8091C5), right],
          stops: const <double>[0, .5, 1],
        ).createShader(rect),
    );
    canvas.drawPath(
      bevel,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .9
        ..shader = LinearGradient(
          colors: <Color>[
            left.withValues(alpha: .7),
            const Color(0x204F607F),
            right.withValues(alpha: .7),
          ],
        ).createShader(rect),
    );

    final Paint corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    corner.color = left;
    canvas.drawLine(const Offset(12, 5), Offset(math.min(42.0, size.width * .22), 5), corner);
    canvas.drawLine(Offset(5, 12), Offset(5, math.min(35.0, size.height * .42)), corner);
    corner.color = right;
    canvas.drawLine(Offset(size.width - 12, size.height - 5), Offset(size.width - math.min(42.0, size.width * .22), size.height - 5), corner);
    canvas.drawLine(Offset(size.width - 5, size.height - 12), Offset(size.width - 5, size.height - math.min(35.0, size.height * .42)), corner);

    final Paint boltPaint = Paint()..color = const Color(0xFF8091B7).withValues(alpha: .7);
    for (final Offset p in <Offset>[
      const Offset(10, 10),
      Offset(size.width - 10, 10),
      Offset(10, size.height - 10),
      Offset(size.width - 10, size.height - 10),
    ]) {
      canvas.drawCircle(p, 1.15, boltPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _LiftedPanelPainter oldDelegate) {
    return oldDelegate.pressed != pressed ||
        oldDelegate.intensity != intensity ||
        oldDelegate.colors != colors ||
        oldDelegate.cut != cut;
  }
}

class _ActionButtonPainter extends CustomPainter {
  const _ActionButtonPainter({
    required this.pressed,
    required this.cyan,
    required this.magenta,
    required this.strong,
  });

  final bool pressed;
  final Color cyan;
  final Color magenta;
  final bool strong;

  Path _path(Size size, double inset) {
    final double cut = 19 - inset * .35;
    return Path()
      ..moveTo(inset + cut, inset)
      ..lineTo(size.width - inset - cut, inset)
      ..lineTo(size.width - inset, inset + cut)
      ..lineTo(size.width - inset, size.height - inset - cut)
      ..lineTo(size.width - inset - cut, size.height - inset)
      ..lineTo(inset + cut, size.height - inset)
      ..lineTo(inset, size.height - inset - cut)
      ..lineTo(inset, inset + cut)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Path path = _path(size, 2);
    final Path inner = _path(size, 7);
    final double p = pressed ? .55 : 1;

    canvas.save();
    canvas.translate(0, pressed ? 1 : 4);
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.black.withValues(alpha: .8)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 11),
    );
    canvas.restore();

    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strong ? 15 : 10
        ..shader = LinearGradient(
          colors: <Color>[cyan.withValues(alpha: .28 * p), magenta.withValues(alpha: .28 * p)],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[
            Color.lerp(const Color(0xFF08182C), cyan, .18)!,
            const Color(0xFF221A55),
            Color.lerp(const Color(0xFF2A0B2D), magenta, .20)!,
          ],
        ).createShader(rect),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..shader = LinearGradient(colors: <Color>[cyan, const Color(0xFFE6F9FF), magenta]).createShader(rect),
    );
    canvas.drawPath(
      inner,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .9
        ..shader = LinearGradient(colors: <Color>[cyan.withValues(alpha: .6), Colors.white.withValues(alpha: .18), magenta.withValues(alpha: .6)]).createShader(rect),
    );
    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height * .44),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Colors.white.withValues(alpha: pressed ? .025 : .11), Colors.transparent],
        ).createShader(rect),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ActionButtonPainter oldDelegate) {
    return oldDelegate.pressed != pressed;
  }
}

class _HubBackgroundPainter extends CustomPainter {
  const _HubBackgroundPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color(0xFF020510),
            Color(0xFF07101D),
            Color(0xFF02040B),
          ],
          stops: <double>[0, .45, 1],
        ).createShader(rect),
    );
    canvas.drawCircle(
      Offset(-size.width * .15, size.height * .38),
      size.width * .75,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Color(0x2033E8FF), Colors.transparent],
        ).createShader(Rect.fromCircle(center: Offset(-size.width * .15, size.height * .38), radius: size.width * .75)),
    );
    canvas.drawCircle(
      Offset(size.width * 1.12, size.height * .43),
      size.width * .78,
      Paint()
        ..shader = const RadialGradient(
          colors: <Color>[Color(0x20FF3EBC), Colors.transparent],
        ).createShader(Rect.fromCircle(center: Offset(size.width * 1.12, size.height * .43), radius: size.width * .78)),
    );

    const double side = 34;
    final double h = math.sqrt(3) * side;
    final Paint grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .65
      ..color = const Color(0x183C5777);
    for (double y = -h; y < size.height + h; y += h) {
      final int row = ((y / h).round());
      final double shift = row.isEven ? 0 : side * 1.5;
      for (double x = -side * 3 + shift; x < size.width + side * 3; x += side * 3) {
        final Path hex = Path();
        for (int i = 0; i < 6; i++) {
          final double a = math.pi / 3 * i;
          final Offset p = Offset(x + math.cos(a) * side, y + math.sin(a) * side);
          if (i == 0) {
            hex.moveTo(p.dx, p.dy);
          } else {
            hex.lineTo(p.dx, p.dy);
          }
        }
        hex.close();
        canvas.drawPath(hex, grid);
      }
    }

    final Paint scan = Paint()
      ..color = const Color(0x0BFFFFFF)
      ..strokeWidth = .5;
    for (double y = 4; y < size.height; y += 6) {
      canvas.drawLine(Offset.zero.translate(0, y), Offset(size.width, y), scan);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ArenaPreviewPainter extends CustomPainter {
  const _ArenaPreviewPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final double cut = 27;
    final Path frame = Path()
      ..moveTo(cut, 2)
      ..lineTo(size.width - cut, 2)
      ..lineTo(size.width - 2, cut)
      ..lineTo(size.width - 2, size.height - cut)
      ..lineTo(size.width - cut, size.height - 2)
      ..lineTo(cut, size.height - 2)
      ..lineTo(2, size.height - cut)
      ..lineTo(2, cut)
      ..close();

    canvas.save();
    canvas.translate(0, 4);
    canvas.drawPath(
      frame,
      Paint()
        ..color = Colors.black.withValues(alpha: .75)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    canvas.restore();

    canvas.drawPath(
      frame,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF06192B), Color(0xFF100B22), Color(0xFF25081F)],
        ).createShader(rect),
    );
    canvas.save();
    canvas.clipPath(frame);
    _paintHexGrid(canvas, size);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x132BE5FF), Colors.transparent, Color(0x16FF42B8)],
        ).createShader(rect),
    );
    canvas.restore();

    canvas.drawPath(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.8
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF33E8FF), Color(0xFF6D6BFF), Color(0xFFFF43BA)],
        ).createShader(rect),
    );
    canvas.drawPath(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 12
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x4433E8FF), Color(0x226D6BFF), Color(0x44FF43BA)],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
    );

    final Offset center = Offset(size.width / 2, size.height / 2);
    final Paint divider = Paint()
      ..color = const Color(0x554F42A5)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(center.dx, 20), Offset(center.dx, size.height - 20), divider);
    for (double y = 24; y < size.height - 20; y += 18) {
      canvas.drawCircle(Offset(center.dx, y), 2.1, Paint()..color = const Color(0xAA8B49FF));
    }

    final double t = progress * math.pi * 2;
    final double ballX = center.dx + math.sin(t) * size.width * .24;
    final double ballY = center.dy + math.sin(t * 1.7) * size.height * .09;
    final Offset ball = Offset(ballX, ballY);
    final Offset leftPaddle = Offset(36, center.dy + math.sin(t * 1.3) * size.height * .16);
    final Offset rightPaddle = Offset(size.width - 36, center.dy - math.sin(t * 1.1) * size.height * .16);

    _drawPaddle(canvas, leftPaddle, const Color(0xFF36E7FF), size.height * .28);
    _drawPaddle(canvas, rightPaddle, const Color(0xFFFF45B8), size.height * .28);

    canvas.drawLine(
      Offset(leftPaddle.dx + 9, leftPaddle.dy),
      ball,
      Paint()
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF36E7FF), Colors.transparent]).createShader(Rect.fromPoints(leftPaddle, ball))
        ..strokeWidth = 1.8,
    );
    canvas.drawLine(
      ball,
      Offset(rightPaddle.dx - 9, rightPaddle.dy),
      Paint()
        ..shader = const LinearGradient(colors: <Color>[Colors.transparent, Color(0xFFFF45B8)]).createShader(Rect.fromPoints(ball, rightPaddle))
        ..strokeWidth = 1.8,
    );

    for (int i = 0; i < 4; i++) {
      final double radius = 27 + i * 13 + math.sin(t + i) * 2;
      canvas.drawCircle(
        ball,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 2.2 : 1
          ..shader = const SweepGradient(colors: <Color>[Color(0xFF35E7FF), Color(0xFF8368FF), Color(0xFFFF45B8), Color(0xFF35E7FF)]).createShader(Rect.fromCircle(center: ball, radius: radius)),
      );
    }
    canvas.drawCircle(
      ball,
      14,
      Paint()
        ..shader = const RadialGradient(colors: <Color>[Colors.white, Color(0xFFB865FF), Color(0xFF37127B)]).createShader(Rect.fromCircle(center: ball, radius: 14))
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
    );
    canvas.drawCircle(ball, 21, Paint()..color = const Color(0x553D67FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12));
  }

  void _paintHexGrid(Canvas canvas, Size size) {
    const double side = 19;
    final double h = math.sqrt(3) * side;
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .55
      ..color = const Color(0x243B5575);
    for (double y = -h; y < size.height + h; y += h) {
      final int row = (y / h).round();
      final double shift = row.isEven ? 0 : side * 1.5;
      for (double x = -side * 3 + shift; x < size.width + side * 3; x += side * 3) {
        final Path path = Path();
        for (int i = 0; i < 6; i++) {
          final double angle = math.pi / 3 * i;
          final Offset p = Offset(x + math.cos(angle) * side, y + math.sin(angle) * side);
          if (i == 0) {
            path.moveTo(p.dx, p.dy);
          } else {
            path.lineTo(p.dx, p.dy);
          }
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }

  void _drawPaddle(Canvas canvas, Offset center, Color color, double height) {
    final RRect paddle = RRect.fromRectAndRadius(
      Rect.fromCenter(center: center, width: 13, height: height),
      const Radius.circular(8),
    );
    canvas.drawRRect(
      paddle,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 11
        ..color = color.withValues(alpha: .3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawRRect(paddle, Paint()..color = color);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: center, width: 4, height: height - 12), const Radius.circular(3)),
      Paint()..color = Colors.white.withValues(alpha: .8),
    );
  }

  @override
  bool shouldRepaint(covariant _ArenaPreviewPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}

class _AvatarPainter extends CustomPainter {
  const _AvatarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = size.shortestSide / 2 - 3;
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFF06101C));
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const SweepGradient(colors: <Color>[Color(0xFF2CE8FF), Color(0xFFFF45BA), Color(0xFF7C5FFF), Color(0xFF2CE8FF)]).createShader(Rect.fromCircle(center: c, radius: r)),
    );
    final Path helmet = Path()
      ..moveTo(c.dx - r * .62, c.dy - r * .12)
      ..quadraticBezierTo(c.dx - r * .48, c.dy - r * .72, c.dx, c.dy - r * .76)
      ..quadraticBezierTo(c.dx + r * .48, c.dy - r * .72, c.dx + r * .62, c.dy - r * .12)
      ..lineTo(c.dx + r * .46, c.dy + r * .56)
      ..quadraticBezierTo(c.dx, c.dy + r * .76, c.dx - r * .46, c.dy + r * .56)
      ..close();
    canvas.drawPath(
      helmet,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFFB342D7), Color(0xFF5A206F), Color(0xFF0C1426), Color(0xFF2CE4FF)],
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );
    final RRect visor = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(c.dx, c.dy - r * .05), width: r * 1.18, height: r * .52),
      Radius.circular(r * .24),
    );
    canvas.drawRRect(visor, Paint()..color = const Color(0xFF02050C));
    canvas.drawRRect(
      visor,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF2CE8FF), Color(0xFFFF45BA)]).createShader(visor.outerRect),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _IconCorePainter extends CustomPainter {
  const _IconCorePainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = size.shortestSide / 2 - 2;
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFF07101D));
    canvas.drawCircle(c, r, Paint()..color = color.withValues(alpha: .16)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
    canvas.drawCircle(c, r - 1, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.4..color = color);
    canvas.drawCircle(c, r - 5, Paint()..style = PaintingStyle.stroke..strokeWidth = .6..color = color.withValues(alpha: .45));
  }

  @override
  bool shouldRepaint(covariant _IconCorePainter oldDelegate) => oldDelegate.color != color;
}

class _ProgressPainter extends CustomPainter {
  const _ProgressPainter({required this.value, required this.colors});

  final double value;
  final List<Color> colors;

  @override
  void paint(Canvas canvas, Size size) {
    final RRect track = RRect.fromRectAndRadius(Offset.zero & size, Radius.circular(size.height));
    canvas.drawRRect(track, Paint()..color = const Color(0xFF142238));
    final double width = size.width * value.clamp(0.0, 1.0).toDouble();
    if (width <= 0) return;
    final RRect fill = RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, width, size.height), Radius.circular(size.height));
    final Rect shaderRect = Rect.fromLTWH(0, 0, math.max(width, 1.0), size.height);
    canvas.drawRRect(fill, Paint()..shader = LinearGradient(colors: colors).createShader(shaderRect));
    canvas.drawRRect(fill, Paint()..color = colors.first.withValues(alpha: .38)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
  }

  @override
  bool shouldRepaint(covariant _ProgressPainter oldDelegate) {
    return oldDelegate.value != value || oldDelegate.colors != colors;
  }
}

class _HomeNavPainter extends CustomPainter {
  const _HomeNavPainter({required this.active, required this.pressed});

  final bool active;
  final bool pressed;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Path hex = Path()
      ..moveTo(size.width * .28, 2)
      ..lineTo(size.width * .72, 2)
      ..lineTo(size.width - 2, size.height * .28)
      ..lineTo(size.width - 2, size.height * .72)
      ..lineTo(size.width * .72, size.height - 2)
      ..lineTo(size.width * .28, size.height - 2)
      ..lineTo(2, size.height * .72)
      ..lineTo(2, size.height * .28)
      ..close();
    final double glow = pressed ? .45 : 1;
    canvas.drawPath(
      hex,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 13
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF2DE7FF), Color(0xFFFF49BA)]).createShader(rect)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 10 * glow),
    );
    canvas.drawPath(
      hex,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: active
              ? const <Color>[Color(0xFF0D4D6A), Color(0xFF251957), Color(0xFF51133D)]
              : const <Color>[Color(0xFF14213A), Color(0xFF0A0F1D)],
        ).createShader(rect),
    );
    canvas.drawPath(
      hex,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..shader = const LinearGradient(colors: <Color>[Color(0xFF2DE7FF), Colors.white, Color(0xFFFF49BA)]).createShader(rect),
    );
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 24, Paint()..color = const Color(0x2235E7FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
  }

  @override
  bool shouldRepaint(covariant _HomeNavPainter oldDelegate) {
    return oldDelegate.active != active || oldDelegate.pressed != pressed;
  }
}

class _NavCellPainter extends CustomPainter {
  const _NavCellPainter({required this.color, required this.active, required this.pressed});

  final Color color;
  final bool active;
  final bool pressed;

  @override
  void paint(Canvas canvas, Size size) {
    if (!active) return;
    final Rect rect = Offset.zero & size;
    final RRect r = RRect.fromRectAndRadius(rect.deflate(3), const Radius.circular(13));
    canvas.drawRRect(
      r,
      Paint()
        ..shader = LinearGradient(colors: <Color>[color.withValues(alpha: .14), color.withValues(alpha: .03)]).createShader(rect),
    );
    canvas.drawLine(
      Offset(size.width * .28, size.height - 4),
      Offset(size.width * .72, size.height - 4),
      Paint()
        ..color = color
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
  }

  @override
  bool shouldRepaint(covariant _NavCellPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.active != active || oldDelegate.pressed != pressed;
  }
}

class _LeagueEmblemPainter extends CustomPainter {
  const _LeagueEmblemPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = Offset.zero & size;
    final Offset c = Offset(size.width / 2, size.height / 2);
    final Path diamond = Path()
      ..moveTo(c.dx, 3)
      ..lineTo(size.width - 5, c.dy)
      ..lineTo(c.dx, size.height - 3)
      ..lineTo(5, c.dy)
      ..close();
    canvas.drawPath(diamond, Paint()..shader = const LinearGradient(colors: <Color>[Color(0xFFFFD64D), Color(0xFF9C63FF), Color(0xFFFF4ABB)]).createShader(rect));
    canvas.drawPath(diamond, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = Colors.white.withValues(alpha: .7));
    canvas.drawPath(diamond, Paint()..style = PaintingStyle.stroke..strokeWidth = 11..color = const Color(0x55FFB832)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawCircle(c, 18, Paint()..color = const Color(0xFF080C17));
    canvas.drawCircle(c, 17, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFFFFD64D));
    final TextPainter tp = TextPainter(
      text: const TextSpan(text: 'P', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FeaturedItemPainter extends CustomPainter {
  const _FeaturedItemPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(c, size.width * .39, Paint()..color = const Color(0x223DE7FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13));
    for (int i = 0; i < 3; i++) {
      canvas.drawCircle(
        c,
        31 + i * 9,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = i == 0 ? 2 : 1
          ..shader = const SweepGradient(colors: <Color>[Color(0xFF2DE7FF), Color(0xFF9367FF), Color(0xFFFF49BA), Color(0xFF2DE7FF)]).createShader(Rect.fromCircle(center: c, radius: 50)),
      );
    }
    final RRect left = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx - 19, c.dy), width: 9, height: 62), const Radius.circular(5));
    final RRect right = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(c.dx + 19, c.dy), width: 9, height: 62), const Radius.circular(5));
    canvas.drawRRect(left, Paint()..color = const Color(0xFF2DE7FF));
    canvas.drawRRect(right, Paint()..color = const Color(0xFFFF49BA));
    canvas.drawCircle(c, 12, Paint()..shader = const RadialGradient(colors: <Color>[Colors.white, Color(0xFFB45EFF), Color(0xFF42127E)]).createShader(Rect.fromCircle(center: c, radius: 12)));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ShopIconPainter extends CustomPainter {
  const _ShopIconPainter({required this.color, required this.icon});

  final Color color;
  final IconData icon;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(c, size.width * .38, Paint()..color = color.withValues(alpha: .18)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
    canvas.drawCircle(c, size.width * .34, Paint()..color = const Color(0xFF07101D));
    canvas.drawCircle(c, size.width * .34, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = color);
    final TextPainter painter = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(icon.codePoint),
        style: TextStyle(
          fontFamily: icon.fontFamily,
          package: icon.fontPackage,
          color: color,
          fontSize: size.width * .43,
          shadows: <Shadow>[Shadow(color: color, blurRadius: 10)],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(canvas, c - Offset(painter.width / 2, painter.height / 2));
  }

  @override
  bool shouldRepaint(covariant _ShopIconPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.icon != icon;
  }
}

class _NavData {
  const _NavData(this.icon, this.label, {this.badge = false});

  final IconData icon;
  final String label;
  final bool badge;
}

class _MissionData {
  const _MissionData(
    this.title,
    this.subtitle,
    this.current,
    this.target,
    this.reward,
    this.icon,
  );

  final String title;
  final String subtitle;
  final int current;
  final int target;
  final int reward;
  final IconData icon;
}

class _RankData {
  const _RankData(this.rank, this.name, this.score, this.color);

  final int rank;
  final String name;
  final int score;
  final Color color;
}

class _ShopItemData {
  const _ShopItemData(this.title, this.price, this.color, this.icon);

  final String title;
  final int price;
  final Color color;
  final IconData icon;
}
