# PULSE ARENA — Build 12 Full UI Pro

Version: `1.7.0+12`
Workflow: `WF7`

## Build 12 scope

This release preserves the optimized low-latency gameplay from Build 11 and replaces the lobby layer with a complete production game hub.

Implemented pages:

- Home lobby with adaptive spacing and a larger animated arena preview
- Player profile and achievements
- Daily and weekly missions
- Global ranking and league progress
- Shop with equipment categories and selectable items
- Full graphical settings screen

## UI rules enforced

- No `Card` or `ElevatedButton` is used in the production hub.
- Panels, buttons, mission rows, ranking rows, shop items, navigation cells, and settings controls use custom multi-layer painters.
- Every interactive surface has a pressed-scale state through `NeonPressable`.
- All panels include a visible offset shadow, inner bevel, neon perimeter, top highlight, and corner details so they remain separated from the background.
- Bottom navigation contains five items and the Home control is elevated in the exact center.
- Ranking is a first-class bottom-navigation destination.

## Gameplay retained

- Immediate finger-following player paddle
- Responsive predictive bot paddle
- Bounded 120 Hz swept ball physics
- Sustained-performance governor
- Ten-goal loss rule
- Dedicated professional real-player victory celebration

## GitHub Actions

`.github/workflows/build-apk.yml` is WF7. It selects the newest valid Flutter source ZIP, validates Build 12 UI and Build 11 performance safeguards, runs `flutter analyze` and all tests, then builds separate release APKs for Bazaar and Myket. Failure logs are uploaded automatically.
