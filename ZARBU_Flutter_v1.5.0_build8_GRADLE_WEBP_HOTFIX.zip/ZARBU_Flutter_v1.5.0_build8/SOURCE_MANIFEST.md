# فهرست بسته ZARBU 1.5.0+8

نسخه: `1.5.0+8`  
Package: `mk.kadkhodai.zarbu`  
Workflow: `ZARBU_BUILD_LATEST_ZIP_AUTO_FIXED_V7_FINAL_STORES.yml`

## فایل‌های بسته

- `.github/workflows/ZARBU_BUILD_LATEST_ZIP_AUTO_FIXED_V7_FINAL_STORES.yml`
- `FINAL_RELEASE_CANDIDATE_v1.5.0_build8.md`
- `PREDELIVERY_VERIFICATION_v1.5.0_build8.md`
- `QA_MATRIX_v1.5.0_build8.md`
- `README_FA.md`
- `STORE_BILLING_REQUIREMENTS.md`
- `analysis_options.yaml`
- `assets/images/avatars/01_default_male.webp`
- `assets/images/avatars/02_default_female.webp`
- `assets/images/avatars/03_premium_male.webp`
- `assets/images/avatars/04_premium_female.webp`
- `assets/images/avatars/05_premium_male_visor.webp`
- `assets/images/avatars/06_premium_female_commander.webp`
- `assets/images/avatars/07_premium_male_masked.webp`
- `assets/images/avatars/08_premium_female_gamer.webp`
- `assets/images/avatars/09_premium_male_dual_neon.webp`
- `assets/images/avatars/10_premium_female_armor.webp`
- `assets/images/zarbu_league_cup.webp`
- `docs/history/AVATAR_HUD_SIZE_BALANCE_FIX_v1.3.1_build6.md`
- `docs/history/BUILD_FIX_113.md`
- `docs/history/BUILD_FIX_121.md`
- `docs/history/BUILD_FIX_RUN135.md`
- `docs/history/FIRST_FIVE_COMPLETION_v1.2.0_build4.md`
- `docs/history/GAMEPLAY_STABILITY_FIX8.md`
- `docs/history/MATCH_EXPERIENCE_STAGE6_v1.3.0_build5.md`
- `docs/history/NAV_RANK_EXIT_FIX9.md`
- `docs/history/PRODUCTION_POLISH_FIX6.md`
- `docs/history/QA_PREDELIVERY_v1.2.0_build4.md`
- `docs/history/QA_REPORT_ZARBU_1.1.0_BUILD3.md`
- `docs/history/QUALITY_REPORT.md`
- `docs/history/QUALITY_REPORT_FIX6.md`
- `docs/history/QUALITY_REPORT_FIX8.md`
- `docs/history/QUALITY_REPORT_FIX9.md`
- `docs/history/README.md`
- `docs/history/SHOP_AVATAR_UPDATE_v1.2.0.md`
- `docs/history/UI_ORIENTATION_FIX2.md`
- `docs/history/UI_POLISH_FIX3.md`
- `docs/history/UI_THEME_FIX5.md`
- `docs/history/WORKFLOW_AUTO_RUN_FIX_FA.md`
- `docs/history/WORKFLOW_FIX_V2_FA.md`
- `docs/history/ZARBU_LEAGUE_CUP_INTEGRATION.md`
- `docs/history/ZARBU_LEAGUE_UI_REBUILD.md`
- `docs/history/v1.4.0_build7/BUILD_FIX_RUN147.md`
- `docs/history/v1.4.0_build7/OFFLINE_RELEASE_CANDIDATE_v1.4.0_build7.md`
- `docs/history/v1.4.0_build7/PREDELIVERY_VERIFICATION_v1.4.0_build7.md`
- `docs/history/v1.4.0_build7/QA_MATRIX_v1.4.0_build7.md`
- `lib/core/balance.dart`
- `lib/core/data.dart`
- `lib/core/icons.dart`
- `lib/core/league.dart`
- `lib/core/services/audio_service.dart`
- `lib/core/services/storage_service.dart`
- `lib/core/state/app_state.dart`
- `lib/core/store/store_billing_service.dart`
- `lib/core/store/store_config.dart`
- `lib/core/store/store_product.dart`
- `lib/core/theme.dart`
- `lib/game/engine.dart`
- `lib/main.dart`
- `lib/ui/screens/friends_screen.dart`
- `lib/ui/screens/game_screen.dart`
- `lib/ui/screens/lobby_screen.dart`
- `lib/ui/screens/main_shell.dart`
- `lib/ui/screens/match_setup_dialog.dart`
- `lib/ui/screens/missions_screen.dart`
- `lib/ui/screens/profile_screen.dart`
- `lib/ui/screens/rank_screen.dart`
- `lib/ui/screens/rewards_screen.dart`
- `lib/ui/screens/settings_screen.dart`
- `lib/ui/screens/shop_screen.dart`
- `lib/ui/screens/splash_screen.dart`
- `lib/ui/screens/tournament_screen.dart`
- `lib/ui/widgets/avatar_badge.dart`
- `lib/ui/widgets/neon.dart`
- `pubspec.yaml`
- `release/bazikhone_release_key.jks`
- `release/key.properties`
- `test/balance_test.dart`
- `test/data_test.dart`
- `test/engine_rules_test.dart`
- `test/league_test.dart`
- `test/settlement_state_test.dart`
- `test/state_rules_test.dart`
- `test/storage_service_test.dart`
- `test/store_config_test.dart`
- `test/store_ledger_test.dart`
- `tool/materialize_project.sh`
- `tool/prepare_android.py`
- `tool/release_gate.py`

## Release Gates

- Release Gate قبل از Analyze/Test/Build اجرا می‌شود.
- تست Store Ledger در حالت Bazaar و Myket با dart-define جداگانه در CI اجرا می‌شود.
- APK آفلاین همیشه ساخته می‌شود.
- APK بازار و مایکت فقط با RSA واقعی همان مارکت ساخته می‌شوند.
- Package ID، امضا، اندازه APK و SHA-256 بعد از Build کنترل می‌شوند.
- تست دستگاه واقعی و Checkout مارکت پس از خروجی CI انجام می‌شود.
