import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter_poolakey/flutter_poolakey.dart';
import 'package:myket_iap/myket_iap.dart';
import 'package:myket_iap/util/inventory.dart';
import 'package:myket_iap/util/purchase.dart' as myket;

import 'store_config.dart';
import 'store_product.dart';

class StoreBillingService {
  bool _ready = false;
  bool _disposed = false;

  bool get ready => _ready && !_disposed;

  Future<bool> initialize() async {
    if (_disposed || !StoreConfig.isConfigured) return false;
    if (_ready) return true;

    try {
      switch (StoreConfig.activeStore) {
        case ZarbuStore.bazaar:
          final completer = Completer<bool>();
          await FlutterPoolakey.connect(
            StoreConfig.rsaKey,
            onSucceed: () {
              _ready = true;
              if (!completer.isCompleted) completer.complete(true);
            },
            onFailed: () {
              _ready = false;
              if (!completer.isCompleted) completer.complete(false);
            },
            onDisconnected: () => _ready = false,
          );
          return await completer.future.timeout(
            const Duration(seconds: 10),
            onTimeout: () {
              _ready = false;
              return false;
            },
          );
        case ZarbuStore.myket:
          final result = await MyketIAP.init(rsaKey: StoreConfig.rsaKey, enableDebugLogging: false);
          _ready = result?.isSuccess() == true;
          return _ready;
        case ZarbuStore.offline:
          return false;
      }
    } catch (_) {
      _ready = false;
      return false;
    }
  }

  Future<Map<String, String>> loadPrices() async {
    if (!ready && !await initialize()) throw const StoreBillingException('اتصال به فروشگاه برقرار نشد.');
    final skus = StoreConfig.products.map((item) => item.sku).toList(growable: false);
    try {
      switch (StoreConfig.activeStore) {
        case ZarbuStore.bazaar:
          final details = await FlutterPoolakey.getInAppSkuDetails(skus);
          return {for (final item in details) item.sku: item.price};
        case ZarbuStore.myket:
          final result = await MyketIAP.queryInventory(querySkuDetails: true, skus: skus);
          final inventory = result[MyketIAP.INVENTORY] as Inventory?;
          if (inventory == null) return const {};
          return {
            for (final entry in inventory.mSkuMap.entries)
              if (entry.value.mPrice.trim().isNotEmpty) entry.key: entry.value.mPrice,
          };
        case ZarbuStore.offline:
          return const {};
      }
    } on PlatformException catch (error) {
      throw StoreBillingException(error.message ?? 'دریافت قیمت از فروشگاه ناموفق بود.');
    } catch (_) {
      throw const StoreBillingException('دریافت قیمت از فروشگاه ناموفق بود.');
    }
  }

  Future<StoreReceipt> purchase(StoreProduct product) async {
    if (!product.isValid) throw const StoreBillingException('محصول فروشگاه معتبر نیست.');
    if (!ready && !await initialize()) throw const StoreBillingException('اتصال به فروشگاه برقرار نشد.');

    final payload = 'zarbu:${product.id}:${DateTime.now().microsecondsSinceEpoch}';
    try {
      switch (StoreConfig.activeStore) {
        case ZarbuStore.bazaar:
          final info = await FlutterPoolakey.purchase(product.sku, payload: payload);
          if (info.productId != product.sku || info.payload != payload || info.packageName != 'mk.kadkhodai.zarbu' || info.purchaseState != PurchaseState.PURCHASED) {
            throw const StoreBillingException('اعتبار خرید بازار تأیید نشد.');
          }
          return StoreReceipt(
            store: 'bazaar',
            token: info.purchaseToken,
            sku: info.productId,
            payload: info.payload,
          );
        case ZarbuStore.myket:
          final map = await MyketIAP.launchPurchaseFlow(sku: product.sku, payload: payload);
          final result = map[MyketIAP.RESULT];
          final purchase = map[MyketIAP.PURCHASE] as myket.Purchase?;
          if (result == null || result.isSuccess() != true || purchase == null) {
            throw const StoreBillingException('خرید مایکت کامل نشد.');
          }
          if (purchase.mSku != product.sku || purchase.mDeveloperPayload != payload || purchase.mPackageName != 'mk.kadkhodai.zarbu') {
            throw const StoreBillingException('اعتبار خرید مایکت تأیید نشد.');
          }
          return StoreReceipt(
            store: 'myket',
            token: purchase.mToken,
            sku: purchase.mSku,
            payload: purchase.mDeveloperPayload ?? '',
            nativePurchase: purchase,
          );
        case ZarbuStore.offline:
          throw const StoreBillingException('پرداخت در نسخه آفلاین فعال نیست.');
      }
    } on StoreBillingException {
      rethrow;
    } on PlatformException catch (error) {
      throw StoreBillingException(error.message ?? 'فرآیند خرید لغو یا ناموفق شد.');
    } catch (_) {
      throw const StoreBillingException('فرآیند خرید لغو یا ناموفق شد.');
    }
  }

  Future<bool> consume(StoreReceipt receipt) async {
    if (!ready && !await initialize()) return false;
    try {
      switch (StoreConfig.activeStore) {
        case ZarbuStore.bazaar:
          return await FlutterPoolakey.consume(receipt.token);
        case ZarbuStore.myket:
          final native = receipt.nativePurchase;
          if (native is! myket.Purchase) return _recoverMyketConsume(receipt.sku, receipt.token);
          final map = await MyketIAP.consume(purchase: native);
          final result = map[MyketIAP.RESULT];
          return result != null && result.isSuccess() == true;
        case ZarbuStore.offline:
          return false;
      }
    } catch (_) {
      return false;
    }
  }

  Future<bool> recoverConsume({required String store, required String sku, required String token}) async {
    if (!ready && !await initialize()) return false;
    try {
      if (store == 'bazaar' && StoreConfig.activeStore == ZarbuStore.bazaar) {
        final purchase = await FlutterPoolakey.queryPurchasedProduct(sku);
        if (purchase == null) return true;
        if (purchase.purchaseToken != token) return false;
        return await FlutterPoolakey.consume(token);
      }
      if (store == 'myket' && StoreConfig.activeStore == ZarbuStore.myket) {
        return _recoverMyketConsume(sku, token);
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> _recoverMyketConsume(String sku, String token) async {
    final map = await MyketIAP.queryInventory(querySkuDetails: false, skus: [sku]);
    final result = map[MyketIAP.RESULT];
    final inventory = map[MyketIAP.INVENTORY] as Inventory?;
    if (result == null || result.isSuccess() != true || inventory == null) return false;
    final purchase = inventory.mPurchaseMap[sku];
    if (purchase == null) return true;
    if (purchase.mToken != token) return false;
    final consumeMap = await MyketIAP.consume(purchase: purchase);
    final consumeResult = consumeMap[MyketIAP.RESULT];
    return consumeResult != null && consumeResult.isSuccess() == true;
  }

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _ready = false;
    try {
      switch (StoreConfig.activeStore) {
        case ZarbuStore.bazaar:
          await FlutterPoolakey.disconnect();
          break;
        case ZarbuStore.myket:
          await MyketIAP.dispose();
          break;
        case ZarbuStore.offline:
          break;
      }
    } catch (_) {
      // Disconnection must never block app shutdown.
    }
  }
}
