import 'package:flutter/material.dart';

import '../../screens/game_screen.dart';
import '../../screens/start_screen.dart';
import '../config/game_config.dart';

class SceneTransitionManager {
  const SceneTransitionManager._();

  static Future<void> openGame(BuildContext context, {GameConfig config = const GameConfig()}) async {
    await Navigator.of(context).pushReplacement(_fadeRoute(GameScreen(config: config)));
  }

  static Future<void> openStart(BuildContext context) async {
    await Navigator.of(context).pushReplacement(_fadeRoute(const StartScreen()));
  }

  static PageRouteBuilder<void> _fadeRoute(Widget page) {
    return PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 440),
      reverseTransitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (_, animation, __) => FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
        child: page,
      ),
    );
  }
}
