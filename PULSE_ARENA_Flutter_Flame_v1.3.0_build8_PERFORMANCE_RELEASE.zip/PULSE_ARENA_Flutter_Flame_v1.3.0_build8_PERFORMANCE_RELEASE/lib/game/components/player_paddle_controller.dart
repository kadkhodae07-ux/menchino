import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

class PlayerPaddleController extends PositionComponent {
  PlayerPaddleController({
    required this.moveSpeed,
    this.acceleration = 16800,
    this.response = 22,
  });

  final double moveSpeed;
  final double acceleration;
  final double response;

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  bool movementEnabled = true;

  double verticalVelocity = 0;
  double _motionEnergy = 0;
  double _hitEnergy = 0;
  double _fixedAccumulator = 0;
  Path _bodyPath = Path();
  Rect _localBounds = Rect.zero;

  static const double _fixedStep = 1 / 120;
  static const Color _cyan = Color(0xFF25E2FF);

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) / movementBounds.height)
            .clamp(0.0, 1.0)
            .toDouble();

    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.024).clamp(23.0, 35.0).toDouble(),
      (arena.height * 0.275).clamp(86.0, 138.0).toDouble(),
    );
    position.x = arena.left + (arena.width * 0.032).clamp(24.0, 42.0).toDouble();
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
    _rebuildVisuals();
  }

  void _rebuildVisuals() {
    _localBounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * 0.32;
    _bodyPath = Path()
      ..moveTo(cut, 0)
      ..lineTo(size.x - cut * 0.22, 0)
      ..lineTo(size.x, cut)
      ..lineTo(size.x, size.y - cut)
      ..lineTo(size.x - cut * 0.22, size.y)
      ..lineTo(cut, size.y)
      ..lineTo(0, size.y - cut * 0.65)
      ..lineTo(0, cut * 0.65)
      ..close();
  }

  void setTargetFromTouch(double touchY) {
    if (movementBounds.isEmpty) return;
    targetY = (touchY - size.y / 2)
        .clamp(movementBounds.top, movementBounds.bottom - size.y)
        .toDouble();
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    verticalVelocity = 0;
    _fixedAccumulator = 0;
    _motionEnergy = 0;
  }

  void registerHit({required bool perfect}) {
    _hitEnergy = perfect ? 1.35 : 0.9;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _hitEnergy = math.max(0, _hitEnergy - dt * 5.4);
    if (!movementEnabled || movementBounds.isEmpty) return;

    _fixedAccumulator += dt.clamp(0.0, 0.05).toDouble();
    int iterations = 0;
    while (_fixedAccumulator >= _fixedStep && iterations < 8) {
      _simulate(_fixedStep);
      _fixedAccumulator -= _fixedStep;
      iterations++;
    }
    if (iterations == 8) _fixedAccumulator = 0;
  }

  void _simulate(double dt) {
    final double delta = targetY - position.y;
    final double desiredVelocity = (delta * response).clamp(-moveSpeed, moveSpeed).toDouble();
    final double maxVelocityChange = acceleration * dt;
    verticalVelocity += (desiredVelocity - verticalVelocity)
        .clamp(-maxVelocityChange, maxVelocityChange)
        .toDouble();

    if (delta.abs() < 0.35 && verticalVelocity.abs() < 10) {
      position.y = targetY;
      verticalVelocity = 0;
    } else {
      position.y += verticalVelocity * dt;
    }

    final double minY = movementBounds.top;
    final double maxY = movementBounds.bottom - size.y;
    if (position.y <= minY) {
      position.y = minY;
      if (verticalVelocity < 0) verticalVelocity = 0;
    } else if (position.y >= maxY) {
      position.y = maxY;
      if (verticalVelocity > 0) verticalVelocity = 0;
    }

    final double targetEnergy = (verticalVelocity.abs() / math.max(1.0, moveSpeed)).clamp(0.0, 1.0).toDouble();
    _motionEnergy += (targetEnergy - _motionEnergy) * (1 - math.exp(-13 * dt));
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final double ghostDistance = 3 + _motionEnergy * 6;
    for (int i = 3; i >= 1; i--) {
      canvas.save();
      canvas.translate(-i * ghostDistance, 0);
      canvas.drawPath(
        _bodyPath,
        Paint()..color = _cyan.withValues(alpha: 0.025 + _motionEnergy * (0.055 / i)),
      );
      canvas.restore();
    }

    canvas.drawPath(
      _bodyPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8 + _hitEnergy * 3
        ..color = _cyan.withValues(alpha: 0.16 + _hitEnergy * 0.10),
    );
    canvas.drawPath(
      _bodyPath,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFF063F68), Color(0xFF25E2FF), Color(0xFFF2FFFF)],
        ).createShader(_localBounds),
    );
    canvas.drawPath(
      _bodyPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.7
        ..color = const Color(0xEFFFFFFF),
    );

    final Rect energyChannel = Rect.fromLTWH(size.x * 0.20, size.y * 0.10, size.x * 0.22, size.y * 0.80);
    canvas.drawRRect(
      RRect.fromRectAndRadius(energyChannel, Radius.circular(size.x * 0.12)),
      Paint()..color = const Color(0xEAF5FFFF),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(size.x * 0.66, size.y * 0.5),
          width: size.x * (0.48 + _hitEnergy * 0.08),
          height: size.x * (0.48 + _hitEnergy * 0.08),
        ),
        Radius.circular(size.x),
      ),
      Paint()..color = const Color(0xFFFFFFFF),
    );

    final Paint detailPaint = Paint()..color = const Color(0xB8073458);
    for (final double y in <double>[0.16, 0.84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(size.x * 0.58, size.y * y),
            width: size.x * 0.54,
            height: size.x * 0.14,
          ),
          Radius.circular(size.x * 0.07),
        ),
        detailPaint,
      );
    }
  }
}
