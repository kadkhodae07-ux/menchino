import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter/painting.dart' show Alignment, LinearGradient;

import '../config/game_config.dart';
import 'ball_controller.dart';

class BotPaddleController extends PositionComponent {
  BotPaddleController({
    required this.config,
    required this.ball,
    required this.playerScore,
    required this.isPulseActive,
    int Function()? botScore,
  }) : botScore = botScore ?? _zeroScore;

  static int _zeroScore() => 0;

  final GameConfig config;
  final BallController ball;
  final int Function() playerScore;
  final int Function() botScore;
  final bool Function() isPulseActive;
  final math.Random _random = math.Random(9721);

  Rect movementBounds = Rect.zero;
  double targetY = 0;
  double verticalVelocity = 0;
  bool movementEnabled = true;

  double _reactionTimer = 0;
  double _fixedAccumulator = 0;
  double _motionEnergy = 0;
  double _hitEnergy = 0;
  Path _bodyPath = Path();
  Rect _localBounds = Rect.zero;

  static const double _fixedStep = 1 / 120;
  static const Color _magenta = Color(0xFFFF43AE);

  void layout(Rect arena) {
    final bool firstLayout = movementBounds.isEmpty;
    final double previousCenterRatio = firstLayout
        ? 0.5
        : ((position.y + size.y / 2 - movementBounds.top) / movementBounds.height)
            .clamp(0.0, 1.0)
            .toDouble();

    movementBounds = arena;
    size = Vector2(
      (arena.width * 0.024).clamp(23.0, 35.0).toDouble(),
      (arena.height * 0.275).clamp(86.0, 138.0).toDouble(),
    );
    position.x = arena.right - (arena.width * 0.032).clamp(24.0, 42.0).toDouble() - size.x;
    position.y = (arena.top + arena.height * previousCenterRatio - size.y / 2)
        .clamp(arena.top, arena.bottom - size.y)
        .toDouble();
    targetY = position.y;
    _rebuildVisuals();
  }

  void _rebuildVisuals() {
    _localBounds = Offset.zero & Size(size.x, size.y);
    final double cut = size.x * 0.32;
    _bodyPath = Path()
      ..moveTo(cut * 0.22, 0)
      ..lineTo(size.x - cut, 0)
      ..lineTo(size.x, cut * 0.65)
      ..lineTo(size.x, size.y - cut * 0.65)
      ..lineTo(size.x - cut, size.y)
      ..lineTo(cut * 0.22, size.y)
      ..lineTo(0, size.y - cut)
      ..lineTo(0, cut)
      ..close();
  }

  void resetToCenter() {
    if (movementBounds.isEmpty) return;
    targetY = movementBounds.center.dy - size.y / 2;
    position.y = targetY;
    verticalVelocity = 0;
    _reactionTimer = 0;
    _fixedAccumulator = 0;
    _motionEnergy = 0;
  }

  void registerHit() {
    _hitEnergy = 0.95;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _hitEnergy = math.max(0, _hitEnergy - dt * 5.4);
    if (!movementEnabled || movementBounds.isEmpty) return;

    _fixedAccumulator += dt.clamp(0.0, 0.05).toDouble();
    int iterations = 0;
    while (_fixedAccumulator >= _fixedStep && iterations < 8) {
      _simulate(_fixedStep);
      _fixedAccumulator -= _fixedStep;
      iterations++;
    }
    if (iterations == 8) _fixedAccumulator = 0;
  }

  void _simulate(double dt) {
    final int lead = botScore() - playerScore();
    final double rubberBand = lead >= 3 ? 0.84 : (lead <= -3 ? 1.07 : 1.0);

    _reactionTimer -= dt;
    if (_reactionTimer <= 0) {
      final double leadDelay = lead >= 3 ? 1.20 : (lead <= -3 ? 0.92 : 1.0);
      _reactionTimer = config.botReactionDelay * leadDelay * (0.90 + _random.nextDouble() * 0.20);
      _chooseTarget(lead);
    }

    final double pulseFactor = isPulseActive() ? config.pulseSlowFactor : 1.0;
    final double maxSpeed = config.botPaddleSpeed * pulseFactor * rubberBand;
    final double maxAcceleration = config.botPaddleAcceleration * pulseFactor * rubberBand;
    final double delta = targetY - position.y;
    final double desiredVelocity = (delta * 12.5).clamp(-maxSpeed, maxSpeed).toDouble();
    final double maxVelocityChange = maxAcceleration * dt;
    verticalVelocity += (desiredVelocity - verticalVelocity)
        .clamp(-maxVelocityChange, maxVelocityChange)
        .toDouble();

    if (delta.abs() < 0.45 && verticalVelocity.abs() < 8) {
      position.y = targetY;
      verticalVelocity = 0;
    } else {
      position.y += verticalVelocity * dt;
    }

    final double minY = movementBounds.top;
    final double maxY = movementBounds.bottom - size.y;
    if (position.y <= minY) {
      position.y = minY;
      if (verticalVelocity < 0) verticalVelocity = 0;
    } else if (position.y >= maxY) {
      position.y = maxY;
      if (verticalVelocity > 0) verticalVelocity = 0;
    }

    final double targetEnergy = (verticalVelocity.abs() / math.max(1.0, maxSpeed)).clamp(0.0, 1.0).toDouble();
    _motionEnergy += (targetEnergy - _motionEnergy) * (1 - math.exp(-11 * dt));
  }

  void _chooseTarget(int lead) {
    final bool ballThreatening = ball.active && ball.velocity.x > 0;
    if (!ballThreatening) {
      final double idleOffset = math.sin(ball.visualTime * 1.35) * movementBounds.height * 0.035;
      targetY = (movementBounds.center.dy - size.y / 2 + idleOffset)
          .clamp(movementBounds.top, movementBounds.bottom - size.y)
          .toDouble();
      return;
    }

    final double interceptX = position.x - ball.radius;
    final double travelX = interceptX - ball.position.x;
    final double travelTime = travelX / math.max(1.0, ball.velocity.x);
    double predictedY = ball.position.y + ball.velocity.y * math.max(0, travelTime);
    predictedY = _reflectY(
      predictedY,
      movementBounds.top + ball.radius,
      movementBounds.bottom - ball.radius,
    );

    double error = config.botBaseAimError;
    if (lead >= 3) error *= 1.35;
    if (lead <= -3) error *= 0.78;
    if (_random.nextDouble() < config.botErrorChance * (lead >= 3 ? 1.30 : 1.0)) {
      error *= 1.75;
    }
    predictedY += (_random.nextDouble() * 2 - 1) * error;
    targetY = (predictedY - size.y / 2)
        .clamp(movementBounds.top, movementBounds.bottom - size.y)
        .toDouble();
  }

  double _reflectY(double y, double top, double bottom) {
    final double height = bottom - top;
    if (height <= 0) return top;
    double local = (y - top) % (height * 2);
    if (local < 0) local += height * 2;
    if (local > height) local = height * 2 - local;
    return top + local;
  }

  Rect get rect => Rect.fromLTWH(position.x, position.y, size.x, size.y);

  @override
  void render(Canvas canvas) {
    final double ghostDistance = 3 + _motionEnergy * 6;
    for (int i = 3; i >= 1; i--) {
      canvas.save();
      canvas.translate(i * ghostDistance, 0);
      canvas.drawPath(
        _bodyPath,
        Paint()..color = _magenta.withValues(alpha: 0.025 + _motionEnergy * (0.055 / i)),
      );
      canvas.restore();
    }

    canvas.drawPath(
      _bodyPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8 + _hitEnergy * 3
        ..color = _magenta.withValues(alpha: 0.16 + _hitEnergy * 0.10),
    );
    canvas.drawPath(
      _bodyPath,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: <Color>[Color(0xFFFFF1F8), Color(0xFFFF43AE), Color(0xFF68124F)],
        ).createShader(_localBounds),
    );
    canvas.drawPath(
      _bodyPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.7
        ..color = const Color(0xEFFFFFFF),
    );

    final Rect energyChannel = Rect.fromLTWH(size.x * 0.58, size.y * 0.10, size.x * 0.22, size.y * 0.80);
    canvas.drawRRect(
      RRect.fromRectAndRadius(energyChannel, Radius.circular(size.x * 0.12)),
      Paint()..color = const Color(0xEAFEF4FA),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(size.x * 0.34, size.y * 0.5),
          width: size.x * (0.48 + _hitEnergy * 0.08),
          height: size.x * (0.48 + _hitEnergy * 0.08),
        ),
        Radius.circular(size.x),
      ),
      Paint()..color = const Color(0xFFFFFFFF),
    );

    final Paint detailPaint = Paint()..color = const Color(0xB859124A);
    for (final double y in <double>[0.16, 0.84]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(size.x * 0.42, size.y * y),
            width: size.x * 0.54,
            height: size.x * 0.14,
          ),
          Radius.circular(size.x * 0.07),
        ),
        detailPaint,
      );
    }
  }
}
