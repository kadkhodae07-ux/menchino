enum BotDifficulty { trainee, tactical, champion }

extension BotDifficultyLabel on BotDifficulty {
  String get title {
    switch (this) {
      case BotDifficulty.trainee:
        return 'تمرینی';
      case BotDifficulty.tactical:
        return 'تاکتیکی';
      case BotDifficulty.champion:
        return 'قهرمان';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.trainee:
        return 'واکنش آرام و خطای بیشتر';
      case BotDifficulty.tactical:
        return 'متعادل و مناسب مسابقه اصلی';
      case BotDifficulty.champion:
        return 'سریع، دقیق و کم‌اشتباه';
    }
  }
}

class GameConfig {
  const GameConfig({
    this.difficulty = BotDifficulty.tactical,
    this.targetScore = 10,
    this.ballBaseSpeed = 540,
    this.ballMaximumSpeed = 980,
    this.ballSpeedIncreasePerSecond = 2.6,
    this.playerPaddleSpeed = 1780,
    this.playerPaddleAcceleration = 16800,
    this.playerResponse = 22,
    this.botPaddleSpeed = 630,
    this.botPaddleAcceleration = 6800,
    this.botReactionDelay = 0.17,
    this.botErrorChance = 0.22,
    this.botBaseAimError = 62,
    this.countdownDuration = 2.7,
    this.pointServeDelay = 0.62,
    this.shieldDuration = 4,
    this.pulseDuration = 4.5,
    this.pulseSlowFactor = 0.56,
    this.boostMultiplier = 1.30,
    this.shieldUses = 2,
    this.boostUses = 2,
    this.pulseUses = 2,
  });

  factory GameConfig.forDifficulty(BotDifficulty difficulty) {
    switch (difficulty) {
      case BotDifficulty.trainee:
        return const GameConfig(
          difficulty: BotDifficulty.trainee,
          botPaddleSpeed: 520,
          botPaddleAcceleration: 5100,
          botReactionDelay: 0.235,
          botErrorChance: 0.34,
          botBaseAimError: 88,
          ballBaseSpeed: 500,
          ballMaximumSpeed: 900,
        );
      case BotDifficulty.tactical:
        return const GameConfig();
      case BotDifficulty.champion:
        return const GameConfig(
          difficulty: BotDifficulty.champion,
          botPaddleSpeed: 735,
          botPaddleAcceleration: 8500,
          botReactionDelay: 0.115,
          botErrorChance: 0.12,
          botBaseAimError: 38,
          ballBaseSpeed: 570,
          ballMaximumSpeed: 1040,
        );
    }
  }

  final BotDifficulty difficulty;
  final int targetScore;
  final double ballBaseSpeed;
  final double ballMaximumSpeed;
  final double ballSpeedIncreasePerSecond;
  final double playerPaddleSpeed;
  final double playerPaddleAcceleration;
  final double playerResponse;
  final double botPaddleSpeed;
  final double botPaddleAcceleration;
  final double botReactionDelay;
  final double botErrorChance;
  final double botBaseAimError;
  final double countdownDuration;
  final double pointServeDelay;
  final double shieldDuration;
  final double pulseDuration;
  final double pulseSlowFactor;
  final double boostMultiplier;
  final int shieldUses;
  final int boostUses;
  final int pulseUses;
}
