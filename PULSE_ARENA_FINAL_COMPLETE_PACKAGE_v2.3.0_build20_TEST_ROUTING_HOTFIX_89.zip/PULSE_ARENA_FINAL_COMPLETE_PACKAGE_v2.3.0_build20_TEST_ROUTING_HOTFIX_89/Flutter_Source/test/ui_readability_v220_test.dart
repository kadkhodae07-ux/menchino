import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';

String _read(String path) => File(path).readAsStringSync();

void main() {
  test('2.2 visual system is calmer, higher contrast, and compact', () {
    final String tokens = _read('lib/core/design/pulse_tokens.dart');
    final String panel = _read('lib/core/design/pulse_panel.dart');
    final String hub = _read('lib/screens/hub_screen.dart');

    expect(tokens, contains('Color(0xFFC0C8D2)'));
    expect(tokens, contains('class PulseRadii'));
    expect(panel, contains('calm three-layer construction'));
    expect(panel, contains('The small top-right shoulder'));
    expect(hub, contains('height: 60'));
    expect(hub, contains('EdgeInsets.fromLTRB(12, 8, 12, 32)'));
    expect(hub, contains('انتخاب حالت نبرد'));
    expect(hub, isNot(contains("fontSize: 42")));
  });

  test('shop and settings remove duplicated oversized surfaces', () {
    final String shop = _read('lib/screens/hub/shop_page.dart');
    final String settings = _read('lib/screens/hub/settings_page.dart');

    expect(shop, contains('class _ShopWalletStrip'));
    expect(shop, contains('childAspectRatio: 1.02'));
    expect(shop, isNot(contains('_CurrencyPanel(')));
    expect(settings, contains('class _DifficultyChoice'));
    expect(settings, contains('حالت ۹۰ فریم فقط روی نمایشگر و دستگاه سازگار'));
    expect(settings, contains('روشن؛ لرزش کوتاه'));
    expect(settings, contains('PULSE ARENA • 2.3.0+20'));
  });

  test('mode selection and result overlays are compact and safe', () {
    final String modes = _read('lib/screens/mode_selection_screen.dart');
    final String result = _read('lib/screens/game_screen.dart');

    expect(modes, contains('height: 154'));
    expect(modes, contains('شروع نبرد'));
    expect(modes, contains('حالت آنلاین فقط پس از اتصال به زیرساخت واقعی'));
    expect(result, contains('SafeArea('));
    expect(result, contains("minimum: const EdgeInsets.fromLTRB(18, 22, 18, 14)"));
    expect(result, contains("'فرمانده'"));
    expect(result, contains("'نوا'"));
    expect(result, contains('_rewardChip'));
    expect(result, isNot(contains("'VICTORY'")));
  });

  test('serve and bot difficulty remain controllable and distinct', () {
    const GameConfig tactical = GameConfig();
    final GameConfig trainee = GameConfig.forDifficulty(BotDifficulty.trainee);
    final GameConfig champion = GameConfig.forDifficulty(BotDifficulty.champion);

    expect(tactical.serveSpeedFactor, lessThanOrEqualTo(.60));
    expect(tactical.serveRampDuration, greaterThanOrEqualTo(1.4));
    expect(trainee.botReactionDelay, greaterThan(tactical.botReactionDelay));
    expect(trainee.botErrorChance, greaterThan(tactical.botErrorChance));
    expect(champion.botReactionDelay, lessThan(tactical.botReactionDelay));
    expect(champion.botErrorChance, lessThan(tactical.botErrorChance));
  });
}
