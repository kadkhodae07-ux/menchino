import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

String _hubLibrary() {
  final StringBuffer source = StringBuffer(
    File('lib/screens/hub_screen.dart').readAsStringSync(),
  );
  for (final FileSystemEntity entity in Directory('lib/screens/hub')
      .listSync()
      .where((FileSystemEntity entity) => entity.path.endsWith('.dart'))) {
    source.write((entity as File).readAsStringSync());
  }
  return source.toString();
}

void main() {
  test('complete game hub includes every production page', () {
    final String hub = _hubLibrary();
    final String app = File('lib/app/pulse_arena_app.dart').readAsStringSync();

    expect(app, contains('HubScreen'));
    expect(hub, contains('class HubScreen'));
    expect(hub, contains('class _ProfilePage'));
    expect(hub, contains('class _MissionsPage'));
    expect(hub, contains('class _RankingPage'));
    expect(hub, contains('class _ShopPage'));
    expect(hub, contains('class _SettingsPage'));
    expect(hub, contains('رتبه‌بندی آفلاین'));
    expect(hub, contains('فروشگاه آرنا'));
    expect(hub, contains('پروفایل فرمانده'));
    expect(hub, contains('ماموریت‌ها'));
  });

  test('compact navigation has three focused persistent destinations', () {
    final String hub = _hubLibrary();

    expect(hub, contains('height: 64'));
    expect(hub, contains('intensity: .34'));
    expect(hub, contains("_NavData(Icons.emoji_events_rounded, 'رقابت‌ها'"));
    expect(hub, contains("_NavData(Icons.shopping_cart_rounded, 'فروشگاه')"));
    expect(hub, contains("_NavData(Icons.home_rounded, 'خانه')"));
  });

  test('all main surfaces use modular multi-layer graphical panels', () {
    final String hub = _hubLibrary();
    final String panel =
        File('lib/core/design/pulse_panel.dart').readAsStringSync();

    expect(hub, contains('PulsePanel('));
    expect(panel, contains('class PulsePanelPainter'));
    expect(panel, contains('final double lift = pressed ? 1.5 : 4.5'));
    expect(panel, contains('canvas.translate(0, lift)'));
    expect(panel, contains('canvas.drawShadow'));
    expect(panel, contains('calm three-layer construction'));
    expect(panel, contains('final Path inner'));
    expect(hub, contains('static Picture? _staticPicture'));
    expect(hub, contains('class _ActionButtonPainter'));
    expect(hub, isNot(contains('ElevatedButton(')));
    expect(RegExp(r'(^|[^A-Za-z0-9_])Card\(').hasMatch(hub), isFalse);
  });

  test('home layout expands arena and anchors actions near bottom', () {
    final String hub = _hubLibrary();

    expect(hub, contains('constraints: BoxConstraints(minHeight: constraints.maxHeight - 26)'));
    expect(hub, contains('height: 286'));
    expect(hub, contains('BoxConstraints(maxWidth: 430)'));
    expect(hub, contains('class _SeasonRibbon'));
    expect(hub, contains('PULSE ARENA'));
    expect(hub, contains('انتخاب حالت نبرد'));
  });
}
