import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:pulse_arena/game/config/game_config.dart';

String _read(String path) => File(path).readAsStringSync();

void main() {
  test('2.3 lobby is built from editable layered Flutter widgets', () {
    final String lobby = _read('lib/features/lobby/lobby_home.dart');
    final String panel = _read('lib/core/design/layered_game_panel.dart');

    expect(lobby, contains('class LobbyHome'));
    expect(lobby, contains("'PONG'"));
    expect(lobby, contains("'شروع بازی'"));
    expect(lobby, contains("'تک‌نفره'"));
    expect(lobby, contains("'دو نفره'"));
    expect(lobby, contains('PongLobbyArenaPainter'));
    expect(lobby, contains('CustomClipper<Path>'));
    expect(panel, contains('class LayeredGamePanel'));
    expect(panel, contains('canvas.drawShadow'));
    expect(panel, contains('AnimatedScale'));
    expect(lobby, isNot(contains('Image.asset(')));
  });

  test('local two-player mode is wired to real game input', () {
    final GameConfig config = GameConfig.localDuel();
    final String game = _read('lib/game/pulse_arena_game.dart');
    final String input = _read('lib/screens/game_screen.dart');
    final String bot = _read('lib/game/components/bot_paddle_controller.dart');

    expect(config.mode, GameMode.localDuel);
    expect(config.trackProgress, isFalse);
    expect(game, contains('secondPlayer'));
    expect(input, contains('_pointerSides'));
    expect(input, contains('event.localPosition.dx >= width / 2'));
    expect(bot, contains('setTargetFromTouch'));
    expect(bot, contains('config.mode == GameMode.localDuel'));
  });
}
