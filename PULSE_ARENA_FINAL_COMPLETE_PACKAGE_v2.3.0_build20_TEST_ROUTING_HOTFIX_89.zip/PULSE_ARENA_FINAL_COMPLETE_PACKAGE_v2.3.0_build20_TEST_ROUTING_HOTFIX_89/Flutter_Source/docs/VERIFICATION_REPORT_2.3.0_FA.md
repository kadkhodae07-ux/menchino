# گزارش اعتبارسنجی نسخه 2.3.0+20

## موارد موفق

- ساختار فایل‌های Dart و Test از نظر توازن براکت‌ها و Importهای محلی بررسی شد.
- XMLهای Android با Parser استاندارد بررسی شدند.
- نسخه `2.3.0+20` و Package Name ثابت تأیید شد.
- Flavorهای بازار و مایکت حفظ شدند.
- فایل‌های Branding و Audio موجود و معتبر هستند.
- لابی جدید، `LayeredGamePanel`، زمین `CustomPainter` و اتصال دکمه‌ها تأیید شد.
- حالت `localDuel`، ورودی بازیکن دوم و غیرفعال‌شدن AI در آن حالت تأیید شد.
- اسکریپت `python3 tool/validate_release.py` بدون خطا پایان یافت.

## محدودیت محیط

Flutter SDK و Android SDK در محیط محلی موجود نبود. در نتیجه اجرای واقعی دستورات زیر در این محیط ممکن نبود:

- `flutter pub get`
- `dart format .`
- `flutter analyze`
- `flutter test`
- `flutter build apk --debug`

این مراحل باید در GitHub Actions یا سیستم دارای Flutter SDK اجرا شوند.
