import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../game/managers/audio_manager.dart';

/// Reusable five-layer mechanical game surface.
///
/// The panel is entirely painted at runtime and contains no screenshot-based UI.
class LayeredGamePanel extends StatefulWidget {
  const LayeredGamePanel({
    required this.child,
    required this.accentColor,
    this.borderRadius = 18,
    this.depth = 9,
    this.padding = EdgeInsets.zero,
    this.onTap,
    this.selected = false,
    this.enableGlow = true,
    this.enablePressAnimation = true,
    this.playSound = true,
    this.hapticFeedback = true,
    this.semanticLabel,
    super.key,
  });

  final Widget child;
  final Color accentColor;
  final double borderRadius;
  final double depth;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool selected;
  final bool enableGlow;
  final bool enablePressAnimation;
  final bool playSound;
  final bool hapticFeedback;
  final String? semanticLabel;

  @override
  State<LayeredGamePanel> createState() => _LayeredGamePanelState();
}

class _LayeredGamePanelState extends State<LayeredGamePanel> {
  bool _pressed = false;
  int _lastActivationMicros = 0;

  void _setPressed(bool value) {
    if (!widget.enablePressAnimation || widget.onTap == null || _pressed == value) {
      return;
    }
    setState(() => _pressed = value);
  }

  void _activate() {
    final VoidCallback? callback = widget.onTap;
    if (callback == null) return;
    final int now = DateTime.now().microsecondsSinceEpoch;
    if (now - _lastActivationMicros < 240000) return;
    _lastActivationMicros = now;
    _setPressed(false);
    if (widget.playSound) {
      unawaited(AudioManager.instance.playButton());
    }
    if (widget.hapticFeedback) {
      unawaited(AudioManager.instance.lightImpact());
    }
    callback();
  }

  @override
  Widget build(BuildContext context) {
    final bool enabled = widget.onTap != null;
    final double pressDepth = _pressed ? math.min(4.0, widget.depth * .45) : 0.0;
    final double scale = _pressed ? .985 : 1;

    return Semantics(
      button: enabled,
      selected: widget.selected,
      label: widget.semanticLabel,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: enabled ? (_) => _setPressed(true) : null,
        onTapCancel: enabled ? () => _setPressed(false) : null,
        onTapUp: enabled ? (_) => _setPressed(false) : null,
        onTap: enabled ? _activate : null,
        child: AnimatedScale(
          scale: scale,
          duration: const Duration(milliseconds: 90),
          curve: Curves.easeOutCubic,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            curve: Curves.easeOutCubic,
            transform: Matrix4.translationValues(0, pressDepth, 0),
            child: RepaintBoundary(
              child: CustomPaint(
                painter: LayeredGamePanelPainter(
                  accentColor: widget.accentColor,
                  borderRadius: widget.borderRadius,
                  depth: widget.depth,
                  pressed: _pressed,
                  selected: widget.selected,
                  enableGlow: widget.enableGlow,
                ),
                child: Padding(padding: widget.padding, child: widget.child),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LayeredGamePanelPainter extends CustomPainter {
  const LayeredGamePanelPainter({
    required this.accentColor,
    required this.borderRadius,
    required this.depth,
    required this.pressed,
    required this.selected,
    required this.enableGlow,
  });

  final Color accentColor;
  final double borderRadius;
  final double depth;
  final bool pressed;
  final bool selected;
  final bool enableGlow;

  Path _panelPath(Size size, double inset) {
    final double left = inset;
    final double top = inset;
    final double right = size.width - inset;
    final double bottom = size.height - inset;
    final double cut = math.min(
      math.max(9.0, borderRadius * .62),
      math.min(size.width, size.height) * .22,
    );

    return Path()
      ..moveTo(left + cut, top)
      ..lineTo(right - cut, top)
      ..lineTo(right, top + cut)
      ..lineTo(right, bottom - cut)
      ..lineTo(right - cut, bottom)
      ..lineTo(left + cut, bottom)
      ..lineTo(left, bottom - cut)
      ..lineTo(left, top + cut)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final Rect rect = Offset.zero & size;
    final Path outer = _panelPath(size, 1.2);
    final Path frame = _panelPath(size, 5.2);
    final Path inner = _panelPath(size, 9.0);
    final double state = pressed ? .58 : 1;
    final double glow = selected ? 1.25 : 1;
    final double lift = pressed ? math.max(1.0, depth * .22) : depth;

    canvas.drawShadow(
      outer.shift(Offset(0, lift)),
      const Color(0xE6000000),
      pressed ? 7 : 18,
      false,
    );

    if (enableGlow) {
      canvas.drawPath(
        outer,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = selected ? 7 : 5
          ..color = accentColor.withValues(alpha: .10 * glow * state)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
      );
    }

    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color(0xFF1A2940),
            Color(0xFF091224),
            Color(0xFF030815),
          ],
          stops: <double>[0, .58, 1],
        ).createShader(rect),
    );

    canvas.drawPath(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0
        ..color = const Color(0xFF01040A),
    );

    canvas.drawPath(
      frame,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = selected ? 1.8 : 1.25
        ..color = accentColor.withValues(alpha: (selected ? .92 : .62) * state),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[
            Color.lerp(const Color(0xFF122746), accentColor, .09)!,
            const Color(0xFF081428),
            const Color(0xFF050B17),
          ],
          stops: const <double>[0, .48, 1],
        ).createShader(rect),
    );
    canvas.drawRect(
      Rect.fromLTWH(10, 9, math.max(0.0, size.width - 20), 1.1),
      Paint()..color = Colors.white.withValues(alpha: .15 * state),
    );
    canvas.drawRect(
      Rect.fromLTWH(12, size.height - 10, math.max(0.0, size.width - 24), 1.2),
      Paint()..color = const Color(0xD9000207),
    );
    canvas.restore();

    final Paint rail = Paint()
      ..strokeCap = StrokeCap.round
      ..strokeWidth = selected ? 2.8 : 2.0
      ..color = accentColor.withValues(alpha: (selected ? .95 : .58) * state);
    canvas.drawLine(
      const Offset(18, 5.2),
      Offset(math.min(size.width * .36, 86.0), 5.2),
      rail,
    );
    canvas.drawLine(
      Offset(size.width - math.min(size.width * .25, 62.0), size.height - 5.2),
      Offset(size.width - 18, size.height - 5.2),
      rail..color = accentColor.withValues(alpha: .36 * state),
    );
  }

  @override
  bool shouldRepaint(covariant LayeredGamePanelPainter oldDelegate) {
    return oldDelegate.accentColor != accentColor ||
        oldDelegate.borderRadius != borderRadius ||
        oldDelegate.depth != depth ||
        oldDelegate.pressed != pressed ||
        oldDelegate.selected != selected ||
        oldDelegate.enableGlow != enableGlow;
  }
}
