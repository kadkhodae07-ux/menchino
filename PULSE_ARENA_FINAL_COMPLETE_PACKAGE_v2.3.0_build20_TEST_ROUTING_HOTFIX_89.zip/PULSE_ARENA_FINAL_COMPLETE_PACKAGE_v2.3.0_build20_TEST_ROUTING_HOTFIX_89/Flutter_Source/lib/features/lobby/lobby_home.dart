import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/design/layered_game_panel.dart';
import '../../core/design/pulse_tokens.dart';
import '../../player/player_progress_controller.dart';

enum LobbyGameMode { singlePlayer, localTwoPlayer }

class LobbyHome extends StatefulWidget {
  const LobbyHome({
    required this.ambient,
    required this.progress,
    required this.onSinglePlayer,
    required this.onLocalTwoPlayer,
    required this.onProfile,
    required this.onSettings,
    required this.onShop,
    required this.onCompetitions,
    super.key,
  });

  final Animation<double> ambient;
  final PlayerProgressController progress;
  final VoidCallback onSinglePlayer;
  final VoidCallback onLocalTwoPlayer;
  final VoidCallback onProfile;
  final VoidCallback onSettings;
  final VoidCallback onShop;
  final VoidCallback onCompetitions;

  @override
  State<LobbyHome> createState() => _LobbyHomeState();
}

class _LobbyHomeState extends State<LobbyHome> {
  LobbyGameMode _selectedMode = LobbyGameMode.singlePlayer;

  void _startSelectedMode() {
    switch (_selectedMode) {
      case LobbyGameMode.singlePlayer:
        widget.onSinglePlayer();
        return;
      case LobbyGameMode.localTwoPlayer:
        widget.onLocalTwoPlayer();
        return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          final double horizontal = constraints.maxWidth < 390 ? 10 : 14;
          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.fromLTRB(horizontal, 8, horizontal, 18),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: constraints.maxHeight - 26,
              ),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 470),
                  child: Column(
                    children: <Widget>[
                      _LobbyTopBar(
                        progress: widget.progress,
                        onProfile: widget.onProfile,
                        onSettings: widget.onSettings,
                        onCurrency: widget.onShop,
                      ),
                      const SizedBox(height: 15),
                      const _PongLogo(),
                      const SizedBox(height: 11),
                      SizedBox(
                        height: constraints.maxWidth < 390 ? 202 : 224,
                        child: RepaintBoundary(
                          child: AnimatedBuilder(
                            animation: widget.ambient,
                            builder: (_, __) => CustomPaint(
                              painter: PongLobbyArenaPainter(
                                progress: widget.ambient.value,
                              ),
                              child: const SizedBox.expand(),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      SizedBox(
                        width: double.infinity,
                        height: constraints.maxWidth < 390 ? 72 : 80,
                        child: _PrimaryPlayButton(
                          selectedMode: _selectedMode,
                          onTap: _startSelectedMode,
                        ),
                      ),
                      const SizedBox(height: 13),
                      LayeredGamePanel(
                        accentColor: const Color(0xFF233D66),
                        depth: 8,
                        enableGlow: false,
                        padding: const EdgeInsets.all(9),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: SizedBox(
                                height: constraints.maxWidth < 390 ? 124 : 136,
                                child: _ModeCard(
                                  title: 'تک‌نفره',
                                  subtitle: 'رقابت با ربات',
                                  icon: Icons.smart_toy_rounded,
                                  accent: PulseColors.cyan,
                                  selected: _selectedMode ==
                                      LobbyGameMode.singlePlayer,
                                  onTap: () => setState(
                                    () => _selectedMode =
                                        LobbyGameMode.singlePlayer,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: SizedBox(
                                height: constraints.maxWidth < 390 ? 124 : 136,
                                child: _ModeCard(
                                  title: 'دو نفره',
                                  subtitle: 'بازی دوستانه محلی',
                                  icon: Icons.group_rounded,
                                  accent: PulseColors.gold,
                                  selected: _selectedMode ==
                                      LobbyGameMode.localTwoPlayer,
                                  onTap: () => setState(
                                    () => _selectedMode =
                                        LobbyGameMode.localTwoPlayer,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 11),
                      _CompetitionRibbon(onTap: widget.onCompetitions),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _LobbyTopBar extends StatelessWidget {
  const _LobbyTopBar({
    required this.progress,
    required this.onProfile,
    required this.onSettings,
    required this.onCurrency,
  });

  final PlayerProgressController progress;
  final VoidCallback onProfile;
  final VoidCallback onSettings;
  final VoidCallback onCurrency;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final Widget profile = SizedBox(
          height: 67,
          child: LayeredGamePanel(
            accentColor: PulseColors.cyan,
            depth: 8,
            padding: const EdgeInsets.fromLTRB(9, 7, 10, 7),
            semanticLabel: 'پروفایل بازیکن',
            onTap: onProfile,
            child: Row(
              children: <Widget>[
                SizedBox(
                  width: 50,
                  height: 50,
                  child: CustomPaint(
                    painter: _LobbyAvatarPainter(level: progress.level),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        progress.playerName,
                        textDirection: TextDirection.rtl,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: PulseColors.textPrimary,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'سطح ${progress.level}',
                        textDirection: TextDirection.rtl,
                        style: const TextStyle(
                          color: PulseColors.cyan,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 5),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: Container(
                          height: 6,
                          color: const Color(0xFF061020),
                          alignment: Alignment.centerLeft,
                          child: FractionallySizedBox(
                            widthFactor: progress.levelProgress,
                            heightFactor: 1,
                            child: const DecoratedBox(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: <Color>[
                                    PulseColors.cyan,
                                    PulseColors.blue,
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );

        final Widget settings = SizedBox(
          width: 58,
          height: 58,
          child: LayeredGamePanel(
            accentColor: const Color(0xFF8EA4C6),
            depth: 8,
            semanticLabel: 'تنظیمات',
            onTap: onSettings,
            child: const Center(
              child: Icon(
                Icons.settings_rounded,
                color: PulseColors.textPrimary,
                size: 27,
              ),
            ),
          ),
        );

        final Widget coins = _CurrencyPanel(
          icon: Icons.monetization_on_rounded,
          value: _groupDigits(progress.energy),
          color: PulseColors.gold,
          semanticLabel: 'سکه‌ها',
          onTap: onCurrency,
        );
        final Widget gems = _CurrencyPanel(
          icon: Icons.diamond_rounded,
          value: _groupDigits(progress.pulse),
          color: PulseColors.cyan,
          semanticLabel: 'الماس‌ها',
          onTap: onCurrency,
        );

        if (constraints.maxWidth >= 440) {
          return SizedBox(
            height: 67,
            child: Row(
              children: <Widget>[
                Expanded(flex: 7, child: profile),
                const SizedBox(width: 8),
                Expanded(flex: 4, child: coins),
                const SizedBox(width: 8),
                Expanded(flex: 4, child: gems),
                const SizedBox(width: 8),
                settings,
              ],
            ),
          );
        }

        return Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(child: profile),
                const SizedBox(width: 9),
                settings,
              ],
            ),
            const SizedBox(height: 9),
            SizedBox(
              height: 51,
              child: Row(
                children: <Widget>[
                  Expanded(child: coins),
                  const SizedBox(width: 9),
                  Expanded(child: gems),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _CurrencyPanel extends StatelessWidget {
  const _CurrencyPanel({
    required this.icon,
    required this.value,
    required this.color,
    required this.semanticLabel,
    required this.onTap,
  });

  final IconData icon;
  final String value;
  final Color color;
  final String semanticLabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return LayeredGamePanel(
      accentColor: color,
      depth: 7,
      semanticLabel: semanticLabel,
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
      child: Row(
        children: <Widget>[
          Icon(icon, color: color, size: 25),
          const SizedBox(width: 5),
          Expanded(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: const Color(0xFF101B2E),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: color.withValues(alpha: .52)),
            ),
            child: Icon(Icons.add_rounded, color: color, size: 18),
          ),
        ],
      ),
    );
  }
}

class _PongLogo extends StatelessWidget {
  const _PongLogo();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (Rect bounds) => const LinearGradient(
            colors: <Color>[
              Color(0xFFF9FDFF),
              Color(0xFF8EDCFF),
              Color(0xFFF9FDFF),
              Color(0xFFFFD55A),
              Color(0xFFFFB818),
            ],
            stops: <double>[0, .34, .58, .74, 1],
          ).createShader(bounds),
          child: const Text(
            'PONG',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 50,
              height: .92,
              fontWeight: FontWeight.w900,
              fontStyle: FontStyle.italic,
              letterSpacing: 1.2,
              shadows: <Shadow>[
                Shadow(color: Color(0xCC000000), blurRadius: 12, offset: Offset(0, 7)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'فونگ آرنا',
          textDirection: TextDirection.rtl,
          style: TextStyle(
            color: PulseColors.textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: .3,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const _LogoRail(color: PulseColors.cyan, width: 28),
            const SizedBox(width: 7),
            const _LogoRail(color: PulseColors.cyan, width: 8),
            const SizedBox(width: 7),
            const _LogoRail(color: PulseColors.gold, width: 8),
            const SizedBox(width: 7),
            const _LogoRail(color: PulseColors.gold, width: 28),
          ],
        ),
      ],
    );
  }
}

class _LogoRail extends StatelessWidget {
  const _LogoRail({required this.color, required this.width});
  final Color color;
  final double width;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 4,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(99),
        boxShadow: <BoxShadow>[
          BoxShadow(color: color.withValues(alpha: .25), blurRadius: 6),
        ],
      ),
    );
  }
}

class _PrimaryPlayButton extends StatelessWidget {
  const _PrimaryPlayButton({
    required this.selectedMode,
    required this.onTap,
  });

  final LobbyGameMode selectedMode;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final String subtitle = selectedMode == LobbyGameMode.singlePlayer
        ? 'تک‌نفره با ربات'
        : 'دو نفره محلی';
    return LayeredGamePanel(
      accentColor: PulseColors.gold,
      borderRadius: 24,
      depth: 12,
      semanticLabel: 'شروع بازی $subtitle',
      onTap: onTap,
      padding: const EdgeInsets.all(10),
      child: ClipPath(
        clipper: const _MechanicalClipper(cut: 13),
        child: DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[
                Color(0xFFFFE27B),
                Color(0xFFFFBE22),
                Color(0xFFE58C00),
              ],
              stops: <double>[0, .48, 1],
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              Positioned(
                left: 18,
                right: 18,
                top: 2,
                child: Container(
                  height: 1.4,
                  color: Colors.white.withValues(alpha: .64),
                ),
              ),
              Row(
                children: <Widget>[
                  const SizedBox(width: 20),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: Color(0xFF3C2A00),
                    size: 34,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        const Text(
                          'شروع بازی',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: Color(0xFF211A08),
                            fontSize: 25,
                            fontWeight: FontWeight.w900,
                            shadows: <Shadow>[
                              Shadow(color: Color(0x33FFFFFF), offset: Offset(0, 1)),
                            ],
                          ),
                        ),
                        Text(
                          subtitle,
                          textDirection: TextDirection.rtl,
                          style: const TextStyle(
                            color: Color(0xB82A210B),
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 54),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return LayeredGamePanel(
      accentColor: accent,
      depth: 9,
      selected: selected,
      semanticLabel: '$title، $subtitle',
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(8, 11, 8, 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            width: 48,
            height: 43,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: <Color>[
                  accent.withValues(alpha: .25),
                  Colors.transparent,
                ],
              ),
            ),
            child: Icon(icon, color: accent, size: 33),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            textDirection: TextDirection.rtl,
            style: const TextStyle(
              color: PulseColors.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              subtitle,
              textDirection: TextDirection.rtl,
              maxLines: 1,
              style: const TextStyle(
                color: PulseColors.textSecondary,
                fontSize: 10.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 5),
          Icon(
            selected ? Icons.check_circle_rounded : Icons.chevron_left_rounded,
            color: accent,
            size: selected ? 18 : 20,
          ),
        ],
      ),
    );
  }
}

class _CompetitionRibbon extends StatelessWidget {
  const _CompetitionRibbon({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 45,
      child: LayeredGamePanel(
        accentColor: PulseColors.gold,
        depth: 6,
        enableGlow: false,
        semanticLabel: 'مشاهده رقابت‌ها و رتبه‌بندی',
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: const Row(
          children: <Widget>[
            Icon(Icons.emoji_events_rounded, color: PulseColors.gold, size: 20),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                'رقابت‌ها و رتبه‌بندی آفلاین',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: PulseColors.textSecondary,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Icon(Icons.chevron_left_rounded, color: PulseColors.textMuted, size: 21),
          ],
        ),
      ),
    );
  }
}

class _MechanicalClipper extends CustomClipper<Path> {
  const _MechanicalClipper({required this.cut});
  final double cut;

  @override
  Path getClip(Size size) {
    return Path()
      ..moveTo(cut, 0)
      ..lineTo(size.width - cut, 0)
      ..lineTo(size.width, cut)
      ..lineTo(size.width, size.height - cut)
      ..lineTo(size.width - cut, size.height)
      ..lineTo(cut, size.height)
      ..lineTo(0, size.height - cut)
      ..lineTo(0, cut)
      ..close();
  }

  @override
  bool shouldReclip(covariant _MechanicalClipper oldClipper) {
    return oldClipper.cut != cut;
  }
}

class _LobbyAvatarPainter extends CustomPainter {
  const _LobbyAvatarPainter({required this.level});
  final int level;

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = size.center(Offset.zero);
    final double radius = math.min(size.width, size.height) * .47;
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF1C466F), Color(0xFF061126)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = PulseColors.cyan,
    );
    canvas.drawCircle(
      Offset(center.dx, center.dy - radius * .20),
      radius * .28,
      Paint()..color = const Color(0xFFFFC38A),
    );
    final Rect body = Rect.fromCenter(
      center: Offset(center.dx, center.dy + radius * .36),
      width: radius * 1.05,
      height: radius * .64,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(body, Radius.circular(radius * .25)),
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFF138DE3), Color(0xFF08325B)],
        ).createShader(body),
    );
    canvas.drawArc(
      Rect.fromCircle(
        center: Offset(center.dx, center.dy - radius * .36),
        radius: radius * .33,
      ),
      math.pi,
      math.pi,
      true,
      Paint()..color = const Color(0xFF342116),
    );
  }

  @override
  bool shouldRepaint(covariant _LobbyAvatarPainter oldDelegate) {
    return oldDelegate.level != level;
  }
}

class PongLobbyArenaPainter extends CustomPainter {
  const PongLobbyArenaPainter({required this.progress});
  final double progress;

  Path _arenaShape(Size size, double inset) {
    final double cut = math.min(22.0, size.width * .07);
    return Path()
      ..moveTo(inset + cut, inset)
      ..lineTo(size.width - inset - cut, inset)
      ..lineTo(size.width - inset, inset + cut)
      ..lineTo(size.width - inset, size.height - inset - cut)
      ..lineTo(size.width - inset - cut, size.height - inset)
      ..lineTo(inset + cut, size.height - inset)
      ..lineTo(inset, size.height - inset - cut)
      ..lineTo(inset, inset + cut)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final Rect rect = Offset.zero & size;
    final Path outer = _arenaShape(size, 5);
    final Path inner = _arenaShape(size, 15);

    canvas.drawShadow(
      outer.shift(const Offset(0, 11)),
      const Color(0xF2000000),
      18,
      false,
    );
    canvas.drawPath(
      outer,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF1A2A45), Color(0xFF050914)],
        ).createShader(rect),
    );
    canvas.drawPath(
      outer,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF6B7890),
    );

    canvas.save();
    canvas.clipPath(inner);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF0E274B), Color(0xFF061021)],
        ).createShader(rect),
    );
    canvas.drawCircle(
      Offset(size.width * .28, size.height * .48),
      size.width * .38,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            PulseColors.cyan.withValues(alpha: .17),
            Colors.transparent,
          ],
        ).createShader(
          Rect.fromCircle(
            center: Offset(size.width * .28, size.height * .48),
            radius: size.width * .38,
          ),
        ),
    );
    canvas.drawCircle(
      Offset(size.width * .78, size.height * .50),
      size.width * .30,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            PulseColors.gold.withValues(alpha: .12),
            Colors.transparent,
          ],
        ).createShader(
          Rect.fromCircle(
            center: Offset(size.width * .78, size.height * .50),
            radius: size.width * .30,
          ),
        ),
    );
    canvas.restore();

    final Path leftRail = Path()
      ..moveTo(17, 31)
      ..lineTo(17, size.height - 31);
    final Path rightRail = Path()
      ..moveTo(size.width - 17, 31)
      ..lineTo(size.width - 17, size.height - 31);
    canvas.drawPath(
      leftRail,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round
        ..color = PulseColors.cyan
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
    canvas.drawPath(
      rightRail,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round
        ..color = PulseColors.gold
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );

    final Paint centerLine = Paint()
      ..color = Colors.white.withValues(alpha: .66)
      ..strokeWidth = 1.4;
    for (double y = 28; y < size.height - 28; y += 13) {
      canvas.drawLine(
        Offset(size.width / 2, y),
        Offset(size.width / 2, math.min(y + 6, size.height - 28)),
        centerLine,
      );
    }

    final double paddleH = size.height * .34;
    final RRect leftPaddle = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(size.width * .105, size.height * .50),
        width: 17,
        height: paddleH,
      ),
      const Radius.circular(9),
    );
    final RRect rightPaddle = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(size.width * .895, size.height * .50),
        width: 17,
        height: paddleH,
      ),
      const Radius.circular(9),
    );
    canvas.drawRRect(
      leftPaddle,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFFFFFFFF), PulseColors.cyan, Color(0xFF075493)],
        ).createShader(leftPaddle.outerRect),
    );
    canvas.drawRRect(
      rightPaddle,
      Paint()
        ..shader = const LinearGradient(
          colors: <Color>[Color(0xFFFFFFFF), PulseColors.gold, Color(0xFF9B5E00)],
        ).createShader(rightPaddle.outerRect),
    );

    final double phase = math.sin(progress * math.pi * 2);
    final Offset ball = Offset(
      size.width * (.5 + phase * .075),
      size.height * (.52 + math.cos(progress * math.pi * 2) * .035),
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(ball.dx, ball.dy + 14),
        width: 28,
        height: 8,
      ),
      Paint()
        ..color = Colors.white.withValues(alpha: .11)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
    );
    canvas.drawCircle(
      ball,
      13,
      Paint()
        ..color = Colors.white.withValues(alpha: .24)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawCircle(
      ball,
      9,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-.35, -.35),
          colors: <Color>[Colors.white, Color(0xFFD8ECFF), Color(0xFF7FA7D8)],
        ).createShader(Rect.fromCircle(center: ball, radius: 9)),
    );

    canvas.drawPath(
      inner,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..color = const Color(0xFF8293AE).withValues(alpha: .48),
    );
  }

  @override
  bool shouldRepaint(covariant PongLobbyArenaPainter oldDelegate) {
    return (oldDelegate.progress - progress).abs() > .0001;
  }
}

String _groupDigits(int value) {
  return value.toString().replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (_) => '٬',
  );
}
