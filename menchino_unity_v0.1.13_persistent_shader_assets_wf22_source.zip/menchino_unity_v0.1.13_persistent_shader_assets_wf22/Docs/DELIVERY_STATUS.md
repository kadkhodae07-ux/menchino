# وضعیت تحویل 0.1.13

## انجام‌شده

- خطای Package Manager مربوط به `com.unity.modules.inputlegacy@1.0.0 cannot be found` رفع شد.
- Package ID نامعتبر از Manifest و کنترل‌های Build حذف شد.
- Legacy Input Manager به‌عنوان قابلیت داخلی Unity در نظر گرفته می‌شود و `StandaloneInputModule` از UGUI تأمین می‌شود.
- `com.unity.modules.physics` برای رفع خطای `UnityEngine.Collider` حفظ شد.
- نسخه اپ `0.1.13` و Version Code برابر `11` است.
- Workflow مستقل `WF-22` دارای Valid Package Preflight است.
- مسیر فعال‌سازی موفق، ذخیره‌سازی Docker روی `/mnt`، ساخت دو APK، لاگ خطا و پاک‌سازی خروجی‌های قبلی حفظ شده‌اند.

## نیازمند اجرای GitHub Actions

- Resolve پکیج‌ها و Compile واقعی Unity
- تولید دو APK و نصب روی دستگاه ARM64
- تست عملکرد، Safe Area، زبان فارسی و نرخ فریم
- امضای Release با keystore مالک پروژه
